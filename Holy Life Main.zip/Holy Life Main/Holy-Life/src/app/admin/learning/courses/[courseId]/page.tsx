import { notFound } from "next/navigation";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{ courseId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "learning.courses.course.edit",
    "/admin/learning/courses",
  );
  const { courseId } = await params;
  const query = await searchParams;
  const [course, categories, instructors] = await Promise.all([
    db.course.findUnique({
      where: { id: courseId },
      include: {
        category: true,
        instructor: true,
        modules: {
          include: { lessons: { orderBy: { position: "asc" } }, quizzes: true },
          orderBy: { position: "asc" },
        },
        _count: { select: { enrollments: true, reviews: true } },
      },
    }),
    db.courseCategory.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    db.instructorProfile.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" },
    }),
  ]);
  if (!course) notFound();

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Learning"
        title={course.title}
        description={`${course.category.name} · ${course._count.enrollments} learners`}
        actions={
          <StatusBadge
            tone={course.status === "PUBLISHED" ? "success" : "warning"}
          >
            {course.status}
          </StatusBadge>
        }
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}

      <SectionCard
        title="Course content & commercial settings"
        description="Everything below is permission-controlled and can be updated without direct database editing."
      >
        <form
          action={`/api/admin/learning/courses/${course.id}`}
          className="panel-form"
          method="post"
        >
          <input name="intent" type="hidden" value="details" />
          <div className="form-grid two">
            <label>
              Title (English)
              <input
                defaultValue={course.title}
                maxLength={160}
                name="title"
                required
              />
            </label>
            <label>
              শিরোনাম (বাংলা)
              <input
                defaultValue={course.titleBn ?? ""}
                maxLength={160}
                name="titleBn"
              />
            </label>
            <label>
              Slug
              <input
                defaultValue={course.slug}
                maxLength={120}
                name="slug"
                required
              />
            </label>
            <label>
              Category
              <select
                defaultValue={course.categoryId}
                name="categoryId"
                required
              >
                {categories.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                    {item.nameBn ? ` / ${item.nameBn}` : ""}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Instructor
              <select
                defaultValue={course.instructorId ?? ""}
                name="instructorId"
              >
                <option value="">Holy Life Academy</option>
                {instructors.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                    {item.nameBn ? ` / ${item.nameBn}` : ""}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Level
              <select defaultValue={course.level} name="level">
                <option value="BEGINNER">Beginner</option>
                <option value="INTERMEDIATE">Intermediate</option>
                <option value="ADVANCED">Advanced</option>
                <option value="ALL_LEVELS">All levels</option>
              </select>
            </label>
            <label className="span-2">
              Short description (English)
              <textarea
                defaultValue={course.shortDescription ?? ""}
                maxLength={500}
                name="shortDescription"
                rows={2}
              />
            </label>
            <label className="span-2">
              সংক্ষিপ্ত বিবরণ (বাংলা)
              <textarea
                defaultValue={course.shortDescriptionBn ?? ""}
                maxLength={500}
                name="shortDescriptionBn"
                rows={2}
              />
            </label>
            <label className="span-2">
              Description (English)
              <textarea
                defaultValue={course.description ?? ""}
                maxLength={10000}
                name="description"
                rows={5}
              />
            </label>
            <label className="span-2">
              বিস্তারিত বিবরণ (বাংলা)
              <textarea
                defaultValue={course.descriptionBn ?? ""}
                maxLength={10000}
                name="descriptionBn"
                rows={5}
              />
            </label>
            <label className="span-2">
              Thumbnail image URL
              <input
                defaultValue={course.thumbnailUrl ?? ""}
                maxLength={1000}
                name="thumbnailUrl"
                type="url"
              />
            </label>
            <label className="span-2">
              Trailer / intro URL
              <input
                defaultValue={course.trailerUrl ?? ""}
                maxLength={1000}
                name="trailerUrl"
                type="url"
              />
            </label>
            <label>
              Teaching language
              <input
                defaultValue={course.language}
                maxLength={60}
                name="language"
              />
            </label>
            <label>
              Estimated minutes
              <input
                defaultValue={course.estimatedMinutes}
                min="0"
                name="estimatedMinutes"
                type="number"
              />
            </label>
            <label>
              Price (BDT)
              <input
                defaultValue={Number(course.price)}
                min="0"
                name="price"
                step="0.01"
                type="number"
              />
            </label>
            <label>
              Compare-at price (BDT)
              <input
                defaultValue={
                  course.compareAtPrice ? Number(course.compareAtPrice) : ""
                }
                min="0"
                name="compareAtPrice"
                step="0.01"
                type="number"
              />
            </label>
            <label className="span-2">
              Learning outcomes (English)
              <textarea
                defaultValue={course.learningOutcomes.join("\n")}
                maxLength={3000}
                name="learningOutcomes"
                rows={5}
              />
            </label>
            <label className="span-2">
              শেখার ফলাফল (বাংলা)
              <textarea
                defaultValue={course.learningOutcomesBn.join("\n")}
                maxLength={3000}
                name="learningOutcomesBn"
                rows={5}
              />
            </label>
            <label className="span-2">
              Requirements (English)
              <textarea
                defaultValue={course.requirements.join("\n")}
                maxLength={3000}
                name="requirements"
                rows={4}
              />
            </label>
            <label className="span-2">
              প্রয়োজনীয় প্রস্তুতি (বাংলা)
              <textarea
                defaultValue={course.requirementsBn.join("\n")}
                maxLength={3000}
                name="requirementsBn"
                rows={4}
              />
            </label>
            <label>
              Featured
              <select
                defaultValue={course.isFeatured ? "true" : "false"}
                name="isFeatured"
              >
                <option value="true">Yes</option>
                <option value="false">No</option>
              </select>
            </label>
            <label>
              Self enrollment
              <select
                defaultValue={course.allowSelfEnrollment ? "true" : "false"}
                name="allowSelfEnrollment"
              >
                <option value="true">Allowed</option>
                <option value="false">Disabled</option>
              </select>
            </label>
            <label>
              Certificate
              <select
                defaultValue={course.certificateEnabled ? "true" : "false"}
                name="certificateEnabled"
              >
                <option value="true">Enabled</option>
                <option value="false">Disabled</option>
              </select>
            </label>
          </div>
          <button className="ui-button ui-button-primary" type="submit">
            Save course details
          </button>
        </form>
      </SectionCard>

      <div className="admin-two-column">
        <SectionCard
          description={`${course.modules.length} module(s)`}
          title="Curriculum"
        >
          <div className="learning-admin-modules">
            {course.modules.map((module) => (
              <details className="managed-record" key={module.id}>
                <summary>
                  <span>
                    <strong>
                      {module.position}. {module.title}
                      {module.titleBn ? ` / ${module.titleBn}` : ""}
                    </strong>
                    <small>{module.lessons.length} lesson(s)</small>
                  </span>
                  <StatusBadge
                    tone={module.isPublished ? "success" : "neutral"}
                  >
                    {module.isPublished ? "Published" : "Hidden"}
                  </StatusBadge>
                </summary>
                <form
                  action={`/api/admin/learning/modules/${module.id}`}
                  className="panel-form compact-top"
                  method="post"
                >
                  <input name="courseId" type="hidden" value={course.id} />
                  <div className="form-grid two">
                    <label>
                      Title (English)
                      <input
                        defaultValue={module.title}
                        maxLength={160}
                        name="title"
                        required
                      />
                    </label>
                    <label>
                      শিরোনাম (বাংলা)
                      <input
                        defaultValue={module.titleBn ?? ""}
                        maxLength={160}
                        name="titleBn"
                      />
                    </label>
                    <label>
                      Position
                      <input
                        defaultValue={module.position}
                        min="1"
                        name="position"
                        type="number"
                      />
                    </label>
                    <label>
                      Visibility
                      <select
                        defaultValue={module.isPublished ? "true" : "false"}
                        name="isPublished"
                      >
                        <option value="true">Published</option>
                        <option value="false">Hidden</option>
                      </select>
                    </label>
                    <label className="span-2">
                      Description (English)
                      <textarea
                        defaultValue={module.description ?? ""}
                        maxLength={1000}
                        name="description"
                        rows={2}
                      />
                    </label>
                    <label className="span-2">
                      বিবরণ (বাংলা)
                      <textarea
                        defaultValue={module.descriptionBn ?? ""}
                        maxLength={1000}
                        name="descriptionBn"
                        rows={2}
                      />
                    </label>
                  </div>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Save module
                  </button>
                </form>
                <div className="managed-child-list">
                  {module.lessons.map((lesson) => (
                    <details
                      className="managed-record managed-record-child"
                      key={lesson.id}
                    >
                      <summary>
                        <span>
                          <strong>
                            {lesson.position}. {lesson.title}
                            {lesson.titleBn ? ` / ${lesson.titleBn}` : ""}
                          </strong>
                          <small>
                            {lesson.type} · {lesson.durationMinutes} min
                          </small>
                        </span>
                        <StatusBadge
                          tone={lesson.isPublished ? "success" : "neutral"}
                        >
                          {lesson.isPublished ? "Published" : "Hidden"}
                        </StatusBadge>
                      </summary>
                      <form
                        action={`/api/admin/learning/lessons/${lesson.id}`}
                        className="panel-form compact-top"
                        method="post"
                      >
                        <input
                          name="courseId"
                          type="hidden"
                          value={course.id}
                        />
                        <input
                          name="moduleId"
                          type="hidden"
                          value={module.id}
                        />
                        <div className="form-grid two">
                          <label>
                            Title (English)
                            <input
                              defaultValue={lesson.title}
                              maxLength={180}
                              name="title"
                              required
                            />
                          </label>
                          <label>
                            শিরোনাম (বাংলা)
                            <input
                              defaultValue={lesson.titleBn ?? ""}
                              maxLength={180}
                              name="titleBn"
                            />
                          </label>
                          <label>
                            Type
                            <select defaultValue={lesson.type} name="type">
                              <option value="VIDEO">Video</option>
                              <option value="ARTICLE">Article</option>
                              <option value="DOCUMENT">Document</option>
                              <option value="LIVE">Live</option>
                            </select>
                          </label>
                          <label>
                            Duration minutes
                            <input
                              defaultValue={lesson.durationMinutes}
                              min="0"
                              name="durationMinutes"
                              type="number"
                            />
                          </label>
                          <label>
                            Position
                            <input
                              defaultValue={lesson.position}
                              min="1"
                              name="position"
                              type="number"
                            />
                          </label>
                          <label>
                            Visibility
                            <select
                              defaultValue={
                                lesson.isPublished ? "true" : "false"
                              }
                              name="isPublished"
                            >
                              <option value="true">Published</option>
                              <option value="false">Hidden</option>
                            </select>
                          </label>
                          <label className="span-2">
                            Summary (English)
                            <textarea
                              defaultValue={lesson.summary ?? ""}
                              maxLength={1000}
                              name="summary"
                              rows={2}
                            />
                          </label>
                          <label className="span-2">
                            সারসংক্ষেপ (বাংলা)
                            <textarea
                              defaultValue={lesson.summaryBn ?? ""}
                              maxLength={1000}
                              name="summaryBn"
                              rows={2}
                            />
                          </label>
                          <label className="span-2">
                            Content (English)
                            <textarea
                              defaultValue={lesson.content ?? ""}
                              maxLength={20000}
                              name="content"
                              rows={5}
                            />
                          </label>
                          <label className="span-2">
                            পাঠের বিষয়বস্তু (বাংলা)
                            <textarea
                              defaultValue={lesson.contentBn ?? ""}
                              maxLength={20000}
                              name="contentBn"
                              rows={5}
                            />
                          </label>
                          <label>
                            Video URL
                            <input
                              defaultValue={lesson.videoUrl ?? ""}
                              maxLength={1000}
                              name="videoUrl"
                              type="url"
                            />
                          </label>
                          <label>
                            Document URL
                            <input
                              defaultValue={lesson.documentUrl ?? ""}
                              maxLength={1000}
                              name="documentUrl"
                              type="url"
                            />
                          </label>
                          <label>
                            Preview
                            <select
                              defaultValue={lesson.isPreview ? "true" : "false"}
                              name="isPreview"
                            >
                              <option value="false">Member only</option>
                              <option value="true">Public preview</option>
                            </select>
                          </label>
                        </div>
                        <button
                          className="ui-button ui-button-secondary"
                          type="submit"
                        >
                          Save lesson
                        </button>
                      </form>
                    </details>
                  ))}
                </div>
              </details>
            ))}
          </div>

          <form
            action="/api/admin/learning/modules"
            className="panel-form compact-top"
            method="post"
          >
            <input name="courseId" type="hidden" value={course.id} />
            <div className="form-grid two">
              <label>
                New module title (English)
                <input maxLength={160} name="title" required />
              </label>
              <label>
                নতুন মডিউলের শিরোনাম (বাংলা)
                <input maxLength={160} name="titleBn" />
              </label>
              <label>
                Position
                <input
                  defaultValue={course.modules.length + 1}
                  min="1"
                  name="position"
                  type="number"
                />
              </label>
              <label className="span-2">
                Description (English)
                <textarea maxLength={1000} name="description" rows={2} />
              </label>
              <label className="span-2">
                বিবরণ (বাংলা)
                <textarea maxLength={1000} name="descriptionBn" rows={2} />
              </label>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Add module
            </button>
          </form>
        </SectionCard>

        <SectionCard
          title="Publishing"
          description="Archive rather than hard-delete a course so enrollment and certificate history remains intact."
        >
          <form
            action={`/api/admin/learning/courses/${course.id}`}
            className="panel-form"
            method="post"
          >
            <input name="intent" type="hidden" value="status" />
            <label>
              Status
              <select defaultValue={course.status} name="status">
                <option value="DRAFT">Draft</option>
                <option value="PUBLISHED">Published</option>
                <option value="UNPUBLISHED">Unpublished</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            </label>
            <button className="ui-button ui-button-primary" type="submit">
              Update status
            </button>
          </form>
          <p>Instructor: {course.instructor?.name ?? "Holy Life Academy"}</p>
          <p>Reviews: {course._count.reviews}</p>
        </SectionCard>
      </div>

      {course.modules.map((module) => (
        <SectionCard
          key={`add-${module.id}`}
          title={`Add lesson to ${module.title}`}
        >
          <form
            action="/api/admin/learning/lessons"
            className="panel-form"
            method="post"
          >
            <input name="courseId" type="hidden" value={course.id} />
            <input name="moduleId" type="hidden" value={module.id} />
            <div className="form-grid two">
              <label>
                Lesson title (English)
                <input maxLength={180} name="title" required />
              </label>
              <label>
                পাঠের শিরোনাম (বাংলা)
                <input maxLength={180} name="titleBn" />
              </label>
              <label>
                Type
                <select name="type">
                  <option value="VIDEO">Video</option>
                  <option value="ARTICLE">Article</option>
                  <option value="DOCUMENT">Document</option>
                  <option value="LIVE">Live</option>
                </select>
              </label>
              <label>
                Duration minutes
                <input
                  defaultValue="10"
                  min="0"
                  name="durationMinutes"
                  type="number"
                />
              </label>
              <label>
                Position
                <input
                  defaultValue={module.lessons.length + 1}
                  min="1"
                  name="position"
                  type="number"
                />
              </label>
              <label className="span-2">
                Summary (English)
                <textarea maxLength={1000} name="summary" rows={2} />
              </label>
              <label className="span-2">
                সারসংক্ষেপ (বাংলা)
                <textarea maxLength={1000} name="summaryBn" rows={2} />
              </label>
              <label className="span-2">
                Lesson content (English)
                <textarea maxLength={20000} name="content" rows={5} />
              </label>
              <label className="span-2">
                পাঠের বিষয়বস্তু (বাংলা)
                <textarea maxLength={20000} name="contentBn" rows={5} />
              </label>
              <label>
                Video URL
                <input maxLength={1000} name="videoUrl" type="url" />
              </label>
              <label>
                Document URL
                <input maxLength={1000} name="documentUrl" type="url" />
              </label>
              <label className="form-check span-2">
                <input name="isPreview" type="checkbox" value="true" />
                <span>
                  <strong>Public preview</strong>
                </span>
              </label>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Add lesson
            </button>
          </form>
        </SectionCard>
      ))}
    </div>
  );
}
