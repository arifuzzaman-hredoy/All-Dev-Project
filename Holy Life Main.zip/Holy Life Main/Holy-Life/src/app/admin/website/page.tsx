import {
  ButtonLink,
  MetricCard,
  PageHeader,
  SectionCard,
} from "@/components/ui/panel-ui";
import { WebsitePageStatusBadge } from "@/components/cms/page-status";
import { requireWebsitePermission } from "@/lib/cms/admin";
import { db } from "@/lib/db";

export default async function WebsiteCmsPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const params = await searchParams;
  await requireWebsitePermission("website.cms.content.view");
  const pages = await db.websitePage.findMany({
    orderBy: [{ status: "asc" }, { isSystem: "desc" }, { title: "asc" }],
    include: {
      _count: { select: { sections: true, revisions: true } },
      updatedBy: { select: { name: true } },
    },
  });
  const published = pages.filter((page) => page.status === "PUBLISHED").length;
  const draft = pages.filter((page) => page.status === "DRAFT").length;
  const visible = pages.filter(
    (page) => page.showInHeader || page.showInFooter,
  ).length;
  return (
    <>
      <PageHeader
        eyebrow="Public website CMS"
        title="Website content management"
        description="Create pages, edit structured sections, manage public navigation, preview drafts, publish safely, and restore previous revisions."
        breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Website" }]}
        actions={
          <div className="page-header-actions">
            <ButtonLink href="/admin/website/media" variant="secondary">
              Media library
            </ButtonLink>
            <ButtonLink href="/admin/website/settings" variant="secondary">
              Brand settings
            </ButtonLink>
            <ButtonLink href="/admin/website/pages/create">
              Create page
            </ButtonLink>
          </div>
        }
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      {params.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {params.success}
        </div>
      ) : null}
      <div className="metric-grid cms-metric-grid">
        <MetricCard
          icon="globe"
          label="Total pages"
          value={String(pages.length)}
          helper="CMS records"
        />
        <MetricCard
          icon="permission"
          label="Published"
          value={String(published)}
          helper="Publicly visible"
          tone="success"
        />
        <MetricCard
          icon="file"
          label="Draft"
          value={String(draft)}
          helper="Awaiting publish"
          tone="warning"
        />
        <MetricCard
          icon="menu"
          label="In navigation"
          value={String(visible)}
          helper="Header or footer"
        />
      </div>
      <SectionCard
        title="Website pages"
        description="System pages can be edited and published but remain protected from archive. Custom pages support draft, publish, archive, and revision restore."
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Page</th>
                <th>Status</th>
                <th>Content</th>
                <th>Navigation</th>
                <th>Updated</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {pages.map((page) => (
                <tr key={page.id}>
                  <td>
                    <strong>{page.title}</strong>
                    <span>
                      /{page.slug === "home" ? "" : page.slug}
                      {page.isSystem ? " · system" : " · custom"}
                    </span>
                  </td>
                  <td>
                    <WebsitePageStatusBadge status={page.status} />
                  </td>
                  <td>
                    <strong>{page._count.sections} sections</strong>
                    <span>
                      {page._count.revisions} revisions · v{page.version}
                    </span>
                  </td>
                  <td>
                    <strong>{page.showInHeader ? "Header" : "—"}</strong>
                    <span>
                      {page.showInFooter ? "Footer" : "Not in footer"}
                    </span>
                  </td>
                  <td>
                    <strong>
                      {page.updatedAt.toLocaleDateString("en-GB")}
                    </strong>
                    <span>{page.updatedBy?.name ?? "System"}</span>
                  </td>
                  <td>
                    <ButtonLink
                      href={`/admin/website/pages/${page.id}`}
                      variant="secondary"
                    >
                      Edit page
                    </ButtonLink>
                  </td>
                </tr>
              ))}
              {pages.length === 0 ? (
                <tr>
                  <td colSpan={6}>
                    No CMS pages are available yet. Create or publish the
                    required public pages before launch.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </>
  );
}
