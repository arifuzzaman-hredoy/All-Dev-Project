import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireWebsitePermission } from "@/lib/cms/admin";

export default async function CreateWebsitePage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;
  await requireWebsitePermission(
    "website.cms.content.create",
    "/admin/website/pages/create",
  );
  return (
    <>
      <PageHeader
        eyebrow="New CMS page"
        title="Create website page"
        description="Create the page metadata first, then add and order structured content sections."
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Website", href: "/admin/website" },
          { label: "Create page" },
        ]}
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      <SectionCard
        title="Page details"
        description="The slug becomes the public URL. Reserved application paths cannot be used."
      >
        <form
          action="/api/admin/website/pages"
          className="rbac-form"
          method="post"
        >
          <div className="rbac-form-grid">
            <label>
              <span>Page title</span>
              <input name="title" required maxLength={120} />
            </label>
            <label>
              <span>URL slug</span>
              <input
                name="slug"
                placeholder="healthy-living"
                required
                maxLength={80}
              />
            </label>
            <label>
              <span>Navigation label</span>
              <input name="navigationLabel" maxLength={60} />
            </label>
            <label>
              <span>SEO title</span>
              <input name="seoTitle" maxLength={70} />
            </label>
            <label className="rbac-form-span">
              <span>Short excerpt / SEO description</span>
              <textarea name="excerpt" rows={3} maxLength={300} />
            </label>
            <label>
              <span>Header order</span>
              <input name="headerOrder" type="number" defaultValue={100} />
            </label>
            <label>
              <span>Footer order</span>
              <input name="footerOrder" type="number" defaultValue={100} />
            </label>
          </div>
          <div className="cms-check-row">
            <label>
              <input name="showInHeader" type="checkbox" /> Show in header
            </label>
            <label>
              <input name="showInFooter" type="checkbox" /> Show in footer
            </label>
          </div>
          <div className="rbac-form-actions">
            <button className="ui-button ui-button-primary" type="submit">
              Create draft page
            </button>
          </div>
        </form>
      </SectionCard>
    </>
  );
}
