import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { WebsitePageStatusBadge } from "@/components/cms/page-status";
import { contentTemplate, prettyContent } from "@/lib/cms/content";
import { requireWebsitePermission } from "@/lib/cms/admin";
import { WEBSITE_SECTION_TYPES } from "@/lib/cms/types";
import { db } from "@/lib/db";

export default async function EditWebsitePage({
  params,
  searchParams,
}: {
  params: Promise<{ pageId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const [{ pageId }, query] = await Promise.all([params, searchParams]);
  await requireWebsitePermission(
    "website.cms.content.view",
    `/admin/website/pages/${pageId}`,
  );
  const page = await db.websitePage.findUnique({
    where: { id: pageId },
    include: {
      sections: { orderBy: [{ position: "asc" }, { createdAt: "asc" }] },
      revisions: {
        orderBy: { createdAt: "desc" },
        take: 12,
        include: { createdBy: { select: { name: true } } },
      },
    },
  });
  if (!page) notFound();
  const publicHref = page.slug === "home" ? "/" : `/${page.slug}`;
  return (
    <>
      <PageHeader
        eyebrow="Website page editor"
        title={page.title}
        description={`/${page.slug === "home" ? "" : page.slug} · version ${page.version}`}
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Website", href: "/admin/website" },
          { label: page.title },
        ]}
        actions={
          <div className="page-header-actions">
            <WebsitePageStatusBadge status={page.status} />
            <Link
              className="ui-button ui-button-secondary"
              href={`/website-preview/${page.id}`}
              target="_blank"
            >
              Preview current content
            </Link>
            {page.status === "PUBLISHED" ? (
              <Link
                className="ui-button ui-button-secondary"
                href={publicHref}
                target="_blank"
              >
                Open public page
              </Link>
            ) : null}
          </div>
        }
      />
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      <SectionCard
        title="Page metadata"
        description="Changing metadata creates a restorable revision before the update is applied."
      >
        <form
          action={`/api/admin/website/pages/${page.id}`}
          className="rbac-form"
          method="post"
        >
          <div className="rbac-form-grid">
            <label>
              <span>Title</span>
              <input
                defaultValue={page.title}
                name="title"
                required
                maxLength={120}
              />
            </label>
            <label>
              <span>URL slug</span>
              <input
                defaultValue={page.slug}
                name="slug"
                required
                maxLength={80}
                disabled={page.slug === "home"}
              />
              {page.slug === "home" ? (
                <input type="hidden" name="slug" value="home" />
              ) : null}
            </label>
            <label>
              <span>Navigation label</span>
              <input
                defaultValue={page.navigationLabel ?? ""}
                name="navigationLabel"
                maxLength={60}
              />
            </label>
            <label>
              <span>Canonical path</span>
              <input
                defaultValue={page.canonicalPath ?? publicHref}
                name="canonicalPath"
                maxLength={120}
              />
            </label>
            <label>
              <span>SEO title</span>
              <input
                defaultValue={page.seoTitle ?? ""}
                name="seoTitle"
                maxLength={70}
              />
            </label>
            <label>
              <span>SEO description</span>
              <input
                defaultValue={page.seoDescription ?? ""}
                name="seoDescription"
                maxLength={170}
              />
            </label>
            <label className="rbac-form-span">
              <span>Excerpt</span>
              <textarea
                defaultValue={page.excerpt ?? ""}
                name="excerpt"
                rows={3}
                maxLength={300}
              />
            </label>
            <label>
              <span>Header order</span>
              <input
                defaultValue={page.headerOrder}
                name="headerOrder"
                type="number"
              />
            </label>
            <label>
              <span>Footer order</span>
              <input
                defaultValue={page.footerOrder}
                name="footerOrder"
                type="number"
              />
            </label>
          </div>
          <div className="cms-check-row">
            <label>
              <input
                defaultChecked={page.showInHeader}
                name="showInHeader"
                type="checkbox"
              />{" "}
              Show in header
            </label>
            <label>
              <input
                defaultChecked={page.showInFooter}
                name="showInFooter"
                type="checkbox"
              />{" "}
              Show in footer
            </label>
          </div>
          <div className="rbac-form-actions">
            <button className="ui-button ui-button-primary" type="submit">
              Save page metadata
            </button>
          </div>
        </form>
      </SectionCard>

      <SectionCard
        title="Content sections"
        description="Sections render in position order. Content is stored as validated JSON so every page can use the same secure renderer."
      >
        <div className="cms-section-stack">
          {page.sections.map((section) => (
            <article className="cms-editor-card" key={section.id}>
              <header>
                <div>
                  <strong>{section.title}</strong>
                  <span>
                    {section.type} · key: {section.key} · position{" "}
                    {section.position}
                  </span>
                </div>
                <StatusBadge tone={section.isEnabled ? "success" : "neutral"}>
                  {section.isEnabled ? "ENABLED" : "HIDDEN"}
                </StatusBadge>
              </header>
              <form
                action={`/api/admin/website/pages/${page.id}/sections/${section.id}`}
                className="rbac-form"
                method="post"
              >
                <div className="rbac-form-grid">
                  <label>
                    <span>Section title</span>
                    <input defaultValue={section.title} name="title" required />
                  </label>
                  <label>
                    <span>Key</span>
                    <input defaultValue={section.key} name="key" required />
                  </label>
                  <label>
                    <span>Type</span>
                    <select defaultValue={section.type} name="type">
                      {WEBSITE_SECTION_TYPES.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    <span>Position</span>
                    <input
                      defaultValue={section.position}
                      name="position"
                      type="number"
                    />
                  </label>
                  <label className="rbac-form-span">
                    <span>Content JSON</span>
                    <textarea
                      className="cms-json-editor"
                      defaultValue={prettyContent(section.content)}
                      name="content"
                      rows={14}
                      spellCheck={false}
                    />
                  </label>
                </div>
                <div className="cms-check-row">
                  <label>
                    <input
                      defaultChecked={section.isEnabled}
                      name="isEnabled"
                      type="checkbox"
                    />{" "}
                    Enabled
                  </label>
                </div>
                <div className="rbac-form-actions">
                  <button className="ui-button ui-button-primary" type="submit">
                    Save section
                  </button>
                  <button
                    className="ui-button ui-button-secondary"
                    formAction={`/api/admin/website/pages/${page.id}/sections/${section.id}/delete`}
                    type="submit"
                  >
                    Remove section
                  </button>
                </div>
              </form>
            </article>
          ))}
        </div>
        <div className="cms-new-section">
          <h3>Add a section</h3>
          <p>
            Select a type and paste or adjust the starter JSON. The server
            validates that the content is a JSON object.
          </p>
          <form
            action={`/api/admin/website/pages/${page.id}/sections`}
            className="rbac-form"
            method="post"
          >
            <div className="rbac-form-grid">
              <label>
                <span>Section title</span>
                <input name="title" required defaultValue="New section" />
              </label>
              <label>
                <span>Key</span>
                <input
                  name="key"
                  required
                  defaultValue={`section-${page.sections.length + 1}`}
                />
              </label>
              <label>
                <span>Type</span>
                <select name="type" defaultValue="RICH_TEXT">
                  {WEBSITE_SECTION_TYPES.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                <span>Position</span>
                <input
                  name="position"
                  type="number"
                  defaultValue={(page.sections.at(-1)?.position ?? 0) + 10}
                />
              </label>
              <label className="rbac-form-span">
                <span>Content JSON</span>
                <textarea
                  className="cms-json-editor"
                  defaultValue={prettyContent(contentTemplate("RICH_TEXT"))}
                  name="content"
                  rows={12}
                  spellCheck={false}
                />
              </label>
            </div>
            <div className="cms-check-row">
              <label>
                <input defaultChecked name="isEnabled" type="checkbox" />{" "}
                Enabled
              </label>
            </div>
            <div className="rbac-form-actions">
              <button className="ui-button ui-button-primary" type="submit">
                Add section
              </button>
            </div>
          </form>
        </div>
      </SectionCard>

      <SectionCard
        title="Publishing and lifecycle"
        description="Publishing makes the current page and enabled sections publicly visible. System pages cannot be archived."
      >
        <div className="cms-action-row">
          <form
            action={`/api/admin/website/pages/${page.id}/publish`}
            method="post"
          >
            <button className="ui-button ui-button-primary" type="submit">
              {page.status === "PUBLISHED"
                ? "Publish latest changes"
                : "Publish page"}
            </button>
          </form>
          <form
            action={`/api/admin/website/pages/${page.id}/draft`}
            method="post"
          >
            <button className="ui-button ui-button-secondary" type="submit">
              Move to draft
            </button>
          </form>
          {!page.isSystem ? (
            <form
              action={`/api/admin/website/pages/${page.id}/archive`}
              method="post"
            >
              <button className="ui-button ui-button-secondary" type="submit">
                Archive custom page
              </button>
            </form>
          ) : null}
        </div>
      </SectionCard>

      <SectionCard
        title="Recent revisions"
        description="Restoring creates a new revision first, then replaces page metadata and sections with the selected snapshot."
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Version</th>
                <th>Created</th>
                <th>Reason</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {page.revisions.map((revision) => (
                <tr key={revision.id}>
                  <td>
                    <strong>v{revision.version}</strong>
                    <span>Snapshot</span>
                  </td>
                  <td>
                    <strong>
                      {revision.createdAt.toLocaleString("en-GB")}
                    </strong>
                    <span>{revision.createdBy?.name ?? "System"}</span>
                  </td>
                  <td>{revision.note ?? "Content change"}</td>
                  <td>
                    <form
                      action={`/api/admin/website/pages/${page.id}/revisions/${revision.id}/restore`}
                      method="post"
                    >
                      <button
                        className="ui-button ui-button-secondary"
                        type="submit"
                      >
                        Restore
                      </button>
                    </form>
                  </td>
                </tr>
              ))}
              {page.revisions.length === 0 ? (
                <tr>
                  <td colSpan={4}>No revisions yet.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </>
  );
}
