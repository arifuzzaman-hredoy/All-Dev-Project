/* eslint-disable @next/next/no-img-element */
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requireWebsitePermission } from "@/lib/cms/admin";
import { db } from "@/lib/db";

export default async function WebsiteMediaPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const query = await searchParams;
  await requireWebsitePermission(
    "website.cms.content.view",
    "/admin/website/media",
  );
  const media = await db.websiteMedia.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return (
    <>
      <PageHeader
        eyebrow="Website media"
        title="Media URL library"
        description="Register secure HTTPS image URLs with mandatory alt text. Binary upload/storage is intentionally provider-agnostic for client delivery."
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Website", href: "/admin/website" },
          { label: "Media" },
        ]}
      />
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      <SectionCard
        title="Add media URL"
        description="Use an HTTPS URL from the client-approved media provider. Alt text is required for accessibility."
      >
        <form
          action="/api/admin/website/media"
          className="rbac-form"
          method="post"
        >
          <div className="rbac-form-grid">
            <label>
              <span>Name</span>
              <input name="name" required />
            </label>
            <label>
              <span>HTTPS URL</span>
              <input name="url" type="url" required />
            </label>
            <label className="rbac-form-span">
              <span>Alt text</span>
              <input name="altText" required maxLength={180} />
            </label>
            <label>
              <span>MIME type</span>
              <input name="mimeType" placeholder="image/webp" />
            </label>
            <label>
              <span>Width</span>
              <input name="width" type="number" min={1} />
            </label>
            <label>
              <span>Height</span>
              <input name="height" type="number" min={1} />
            </label>
          </div>
          <div className="rbac-form-actions">
            <button className="ui-button ui-button-primary" type="submit">
              Add media
            </button>
          </div>
        </form>
      </SectionCard>
      <SectionCard
        title="Media records"
        description="Archived records remain in audit history but should not be selected for new content."
      >
        <div className="cms-media-grid">
          {media.map((item) => (
            <article className="cms-media-card" key={item.id}>
              <div className="cms-media-preview">
                <img src={item.url} alt={item.altText} />
              </div>
              <div>
                <strong>{item.name}</strong>
                <span>
                  {item.provider} · {item.mimeType ?? "type unknown"}
                </span>
                <p>{item.altText}</p>
                <StatusBadge tone={item.isArchived ? "neutral" : "success"}>
                  {item.isArchived ? "ARCHIVED" : "ACTIVE"}
                </StatusBadge>
              </div>
              {!item.isArchived ? (
                <form
                  action={`/api/admin/website/media/${item.id}/archive`}
                  method="post"
                >
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Archive
                  </button>
                </form>
              ) : null}
            </article>
          ))}
        </div>
      </SectionCard>
    </>
  );
}
