import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { DEFAULT_WEBSITE_BRANDING } from "@/lib/cms/defaults";
import { requireWebsitePermission } from "@/lib/cms/admin";
import { getWebsiteBranding } from "@/lib/cms/queries";

export default async function WebsiteSettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const query = await searchParams;
  await requireWebsitePermission(
    "website.cms.content.edit",
    "/admin/website/settings",
  );
  const branding = await getWebsiteBranding().catch(
    () => DEFAULT_WEBSITE_BRANDING,
  );
  return (
    <>
      <PageHeader
        eyebrow="Website configuration"
        title="Brand and support settings"
        description="These values drive the public header, footer, contact details, and client delivery defaults."
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Website", href: "/admin/website" },
          { label: "Settings" },
        ]}
      />
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      <SectionCard title="Public brand settings">
        <form
          action="/api/admin/website/settings"
          className="rbac-form"
          method="post"
        >
          <div className="rbac-form-grid">
            <label>
              <span>Brand name</span>
              <input name="name" defaultValue={branding.name} required />
            </label>
            <label>
              <span>Tagline</span>
              <input name="tagline" defaultValue={branding.tagline} required />
            </label>
            <label>
              <span>Support email</span>
              <input
                name="supportEmail"
                type="email"
                defaultValue={branding.supportEmail}
                required
              />
            </label>
            <label>
              <span>Support phone</span>
              <input
                name="supportPhone"
                defaultValue={branding.supportPhone}
                required
              />
            </label>
            <label>
              <span>Address</span>
              <input name="address" defaultValue={branding.address} required />
            </label>
            <label>
              <span>Support hours</span>
              <input name="hours" defaultValue={branding.hours} required />
            </label>
          </div>
          <div className="rbac-form-actions">
            <button className="ui-button ui-button-primary" type="submit">
              Save brand settings
            </button>
          </div>
        </form>
      </SectionCard>
    </>
  );
}
