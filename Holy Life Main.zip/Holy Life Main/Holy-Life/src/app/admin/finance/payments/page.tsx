import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import type {
  PaymentAccountStatus,
  PaymentDomain,
} from "@/generated/prisma/client";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { listFinanceAccounts } from "@/lib/finance/queries";
import { paymentStatusLabel } from "@/lib/finance/status";

export const dynamic = "force-dynamic";

function tone(
  status: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "PAID" || status === "VERIFIED") return "success";
  if (status === "FAILED" || status === "REJECTED") return "danger";
  if (
    status === "PARTIAL" ||
    status === "PENDING_VERIFICATION" ||
    status === "PENDING"
  )
    return "warning";
  if (status === "REFUNDED") return "info";
  return "neutral";
}

export default async function FinancePaymentsPage({
  searchParams,
}: {
  searchParams: Promise<{
    domain?: string;
    status?: string;
    search?: string;
    success?: string;
    error?: string;
  }>;
}) {
  await requirePermission(
    "system.finance.payment.view",
    "/admin/finance/payments",
  );
  const query = await searchParams;
  const domain = ["HEALTHCARE", "COMMERCE", "LEARNING"].includes(
    query.domain ?? "",
  )
    ? (query.domain as PaymentDomain)
    : null;
  const status = [
    "UNPAID",
    "PENDING_VERIFICATION",
    "PARTIAL",
    "PAID",
    "FAILED",
    "REFUNDED",
  ].includes(query.status ?? "")
    ? (query.status as PaymentAccountStatus)
    : null;

  const accounts = await listFinanceAccounts({
    domain,
    status,
    search: query.search,
  });

  return (
    <div className="admin-page">
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Finance" },
          { label: "Payments" },
        ]}
        eyebrow="Manual payment operations"
        title="Payment verification"
        description="Cash, bKash, Nagad, Rocket, bank transfer, and other manual references are verified locally. No gateway callback can mark an account paid."
      />

      {query.success ? (
        <div className="notice-box notice-success">
          <strong>Success</strong>
          <p>{query.success}</p>
        </div>
      ) : null}
      {query.error ? (
        <div className="notice-box notice-danger">
          <strong>Action required</strong>
          <p>{query.error}</p>
        </div>
      ) : null}

      <SectionCard title="Filters">
        <form className="finance-filter-form" method="get">
          <input
            defaultValue={query.search ?? ""}
            name="search"
            placeholder="Reference, user, email or phone"
          />
          <select defaultValue={domain ?? ""} name="domain">
            <option value="">All departments</option>
            <option value="HEALTHCARE">Healthcare</option>
            <option value="COMMERCE">Commerce</option>
            <option value="LEARNING">Learning</option>
          </select>
          <select defaultValue={status ?? ""} name="status">
            <option value="">All statuses</option>
            <option value="UNPAID">Unpaid</option>
            <option value="PENDING_VERIFICATION">Pending verification</option>
            <option value="PARTIAL">Partial</option>
            <option value="PAID">Paid</option>
            <option value="FAILED">Failed</option>
            <option value="REFUNDED">Refunded</option>
          </select>
          <button className="ui-button ui-button-secondary" type="submit">
            Apply filters
          </button>
        </form>
      </SectionCard>

      <div className="content-stack">
        {accounts.map((account) => {
          const pending = account.transactions.filter(
            (transaction) => transaction.status === "PENDING",
          );
          return (
            <SectionCard
              key={account.id}
              title={`${account.referenceCode} · ${account.user?.name ?? "Unlinked account"}`}
              description={`${paymentStatusLabel(account.domain)} · ${account.description}`}
              action={
                <StatusBadge tone={tone(account.status)}>
                  {paymentStatusLabel(account.status)}
                </StatusBadge>
              }
            >
              <div className="finance-balance-grid">
                <div>
                  <span>Amount due</span>
                  <strong>
                    {formatMoney(account.amountDue, account.currency)}
                  </strong>
                </div>
                <div>
                  <span>Verified paid</span>
                  <strong>
                    {formatMoney(account.paidAmount, account.currency)}
                  </strong>
                </div>
                <div>
                  <span>Refunded</span>
                  <strong>
                    {formatMoney(account.refundedAmount, account.currency)}
                  </strong>
                </div>
              </div>

              {pending.length ? (
                <div className="finance-pending-stack">
                  <h3>Pending user submissions</h3>
                  {pending.map((transaction) => (
                    <form
                      action={`/api/admin/finance/transactions/${transaction.id}/review`}
                      className="finance-review-row"
                      key={transaction.id}
                      method="post"
                    >
                      <div>
                        <strong>
                          {transaction.code} ·{" "}
                          {formatMoney(transaction.amount, account.currency)}
                        </strong>
                        <span>
                          {transaction.method
                            ? paymentStatusLabel(transaction.method)
                            : "Manual"}{" "}
                          · {transaction.transactionReference ?? "No reference"}
                        </span>
                      </div>
                      <input
                        maxLength={500}
                        name="note"
                        placeholder="Review note"
                      />
                      <button
                        className="ui-button ui-button-primary"
                        name="status"
                        type="submit"
                        value="VERIFIED"
                      >
                        Verify
                      </button>
                      <button
                        className="ui-button ui-button-secondary"
                        name="status"
                        type="submit"
                        value="REJECTED"
                      >
                        Reject
                      </button>
                    </form>
                  ))}
                </div>
              ) : null}

              <div className="finance-admin-actions">
                <form
                  action="/api/admin/finance/payments/record"
                  className="finance-payment-form"
                  method="post"
                >
                  <input name="accountId" type="hidden" value={account.id} />
                  <input name="type" type="hidden" value="PAYMENT" />
                  <label className="form-field">
                    <span>Payment amount</span>
                    <input
                      min="0.01"
                      name="amount"
                      required
                      step="0.01"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Method</span>
                    <select defaultValue="CASH" name="method">
                      <option value="CASH">Cash</option>
                      <option value="BKASH">bKash</option>
                      <option value="NAGAD">Nagad</option>
                      <option value="ROCKET">Rocket</option>
                      <option value="BANK_TRANSFER">Bank transfer</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </label>
                  <label className="form-field">
                    <span>Reference</span>
                    <input maxLength={160} name="transactionReference" />
                  </label>
                  <label className="form-field">
                    <span>Note</span>
                    <input maxLength={500} name="note" />
                  </label>
                  <button className="ui-button ui-button-primary" type="submit">
                    Record verified payment
                  </button>
                </form>

                <form
                  action="/api/admin/finance/payments/record"
                  className="finance-payment-form"
                  method="post"
                >
                  <input name="accountId" type="hidden" value={account.id} />
                  <input name="type" type="hidden" value="REFUND" />
                  <label className="form-field">
                    <span>Refund amount</span>
                    <input
                      min="0.01"
                      name="amount"
                      required
                      step="0.01"
                      type="number"
                    />
                  </label>
                  <input name="method" type="hidden" value="OTHER" />
                  <label className="form-field">
                    <span>Reference</span>
                    <input maxLength={160} name="transactionReference" />
                  </label>
                  <label className="form-field">
                    <span>Reason/note</span>
                    <input maxLength={500} name="note" required />
                  </label>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Record refund
                  </button>
                </form>
              </div>
            </SectionCard>
          );
        })}
        {!accounts.length ? (
          <SectionCard title="Payment accounts">
            <p>No finance account matches the current filters.</p>
          </SectionCard>
        ) : null}
      </div>
    </div>
  );
}
