import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { listFinanceTransactions } from "@/lib/finance/queries";
import { paymentStatusLabel } from "@/lib/finance/status";
import { reportDate } from "@/lib/finance/validation";

export const dynamic = "force-dynamic";

export default async function FinanceTransactionsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  await requirePermission(
    "system.finance.payment.view",
    "/admin/finance/transactions",
  );
  const query = await searchParams;
  const transactions = await listFinanceTransactions({
    from: reportDate(query.from),
    to: reportDate(query.to, true),
  });

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Finance ledger"
        title="Transaction history"
        description="Every recorded payment, refund, verification, and rejection remains in the auditable finance ledger."
      />
      <SectionCard title="Date filter">
        <form className="finance-filter-form" method="get">
          <input defaultValue={query.from ?? ""} name="from" type="date" />
          <input defaultValue={query.to ?? ""} name="to" type="date" />
          <button className="ui-button ui-button-secondary" type="submit">
            Filter
          </button>
        </form>
      </SectionCard>
      <SectionCard
        title="Transactions"
        description={`${transactions.length} record${transactions.length === 1 ? "" : "s"}`}
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Receipt</th>
                <th>Reference</th>
                <th>User</th>
                <th>Type</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Verified by</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((transaction) => (
                <tr key={transaction.id}>
                  <td>
                    <strong>{transaction.code}</strong>
                    <span>
                      {transaction.createdAt.toLocaleString("en-BD", {
                        timeZone: "Asia/Dhaka",
                      })}
                    </span>
                  </td>
                  <td>
                    <strong>{transaction.account.referenceCode}</strong>
                    <span>
                      {paymentStatusLabel(transaction.account.domain)}
                    </span>
                  </td>
                  <td>
                    {transaction.account.user?.name ?? "—"}
                    <span>
                      {transaction.account.user?.phone ??
                        transaction.account.user?.email ??
                        ""}
                    </span>
                  </td>
                  <td>
                    {paymentStatusLabel(transaction.type)}
                    <span>
                      {transaction.method
                        ? paymentStatusLabel(transaction.method)
                        : transaction.gatewayAttemptId
                          ? "Online gateway"
                          : "—"}
                    </span>
                  </td>
                  <td>
                    <StatusBadge
                      tone={
                        transaction.status === "VERIFIED"
                          ? "success"
                          : transaction.status === "REJECTED"
                            ? "danger"
                            : "warning"
                      }
                    >
                      {paymentStatusLabel(transaction.status)}
                    </StatusBadge>
                  </td>
                  <td>
                    {formatMoney(
                      transaction.amount,
                      transaction.account.currency,
                    )}
                  </td>
                  <td>{transaction.verifiedBy?.name ?? "Pending"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
