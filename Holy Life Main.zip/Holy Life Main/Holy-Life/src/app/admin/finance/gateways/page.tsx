import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { listAdminGatewayAttempts } from "@/lib/payments/gateway/queries";

export const dynamic = "force-dynamic";

function tone(
  status: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "SUCCEEDED") return "success";
  if (status === "FAILED" || status === "EXPIRED") return "danger";
  if (status === "REVIEW_REQUIRED" || status === "VALIDATING") return "warning";
  if (status === "SESSION_CREATED") return "info";
  return "neutral";
}

export default async function GatewayAttemptsPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  await requirePermission(
    "system.finance.gateway.view",
    "/admin/finance/gateways",
  );
  const query = await searchParams;
  const attempts = await listAdminGatewayAttempts();

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Online payments"
        title="Gateway attempts"
        description="SSLCOMMERZ callbacks never credit the ledger directly. Every completed payment is independently validated against the provider before a verified finance transaction is created."
      />
      {query.success ? (
        <div className="notice-box notice-success">
          <strong>Success</strong>
          <p>{query.success}</p>
        </div>
      ) : null}
      {query.error ? (
        <div className="notice-box notice-danger">
          <strong>Action required</strong>
          <p>{query.error}</p>
        </div>
      ) : null}
      <SectionCard
        title="Recent gateway attempts"
        description={`${attempts.length} record${attempts.length === 1 ? "" : "s"}`}
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Attempt</th>
                <th>Account</th>
                <th>User</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Provider evidence</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {attempts.map((attempt) => (
                <tr key={attempt.id}>
                  <td>
                    <strong>{attempt.code}</strong>
                    <span>
                      {attempt.createdAt.toLocaleString("en-BD", {
                        timeZone: "Asia/Dhaka",
                      })}
                    </span>
                  </td>
                  <td>
                    <strong>{attempt.account.referenceCode}</strong>
                    <span>{attempt.account.description}</span>
                  </td>
                  <td>
                    {attempt.user.name}
                    <span>
                      {attempt.user.phone ?? attempt.user.email ?? ""}
                    </span>
                  </td>
                  <td>
                    <StatusBadge tone={tone(attempt.status)}>
                      {attempt.status.replaceAll("_", " ")}
                    </StatusBadge>
                    <span>
                      {attempt.reviewReason ?? attempt.failureReason ?? ""}
                    </span>
                  </td>
                  <td>{formatMoney(attempt.amount, attempt.currency)}</td>
                  <td>
                    <strong>{attempt.providerTransactionId}</strong>
                    <span>
                      {attempt.bankTransactionId ??
                        attempt.validationId ??
                        "No validated bank reference yet"}
                    </span>
                  </td>
                  <td>
                    {attempt.status !== "SUCCEEDED" ? (
                      <form
                        action={`/api/admin/finance/gateways/${attempt.id}/revalidate`}
                        method="post"
                      >
                        <button
                          className="ui-button ui-button-secondary"
                          type="submit"
                        >
                          Revalidate
                        </button>
                      </form>
                    ) : (
                      <span>{attempt.transaction?.code ?? "Verified"}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!attempts.length ? (
          <p className="muted-copy">
            No online payment attempt has been created yet.
          </p>
        ) : null}
      </SectionCard>
    </div>
  );
}
