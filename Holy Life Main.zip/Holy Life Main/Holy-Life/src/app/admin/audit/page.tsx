import Link from "next/link";
import {
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireGlobalPermission } from "@/lib/auth/authorization";
import { hasGlobalPermission } from "@/lib/auth/session";
import { auditSummary, listAuditEvents } from "@/lib/audit/queries";
import {
  AUDIT_ACTIONS,
  AUDIT_DEPARTMENTS,
  auditFilters,
} from "@/lib/audit/validation";

export const dynamic = "force-dynamic";

function eventTone(
  action: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (action === "ACCOUNT_LOCKED" || action === "DELETE") return "danger";
  if (
    action === "VIEW_SENSITIVE_DATA" ||
    action.includes("PERMISSION") ||
    action.includes("ROLE")
  )
    return "warning";
  if (action === "LOGIN" || action === "VERIFY") return "success";
  return "neutral";
}

export default async function AuditPage({
  searchParams,
}: {
  searchParams: Promise<{
    from?: string;
    to?: string;
    action?: string;
    department?: string;
    search?: string;
  }>;
}) {
  const session = await requireGlobalPermission(
    "system.audit.audit-log.view",
    "/admin/audit",
  );
  const query = await searchParams;
  const filters = auditFilters(query);
  const [summary, events] = await Promise.all([
    auditSummary(filters),
    listAuditEvents(filters, 200),
  ]);

  const exportQuery = new URLSearchParams();
  for (const key of ["from", "to", "action", "department", "search"] as const) {
    if (query[key]) exportQuery.set(key, query[key]!);
  }

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Security & accountability"
        title="Audit trail"
        description="Read-only actor, target, authentication, authorization, and sensitive-data access history."
        actions={
          hasGlobalPermission(session.user, "system.audit.audit-log.export") ? (
            <Link
              className="ui-button ui-button-secondary"
              href={`/api/admin/audit/export.csv?${exportQuery.toString()}`}
            >
              Export CSV
            </Link>
          ) : undefined
        }
      />

      <SectionCard title="Audit filters">
        <form className="finance-filter-form" method="get">
          <label className="form-field">
            <span>From</span>
            <input defaultValue={query.from ?? ""} name="from" type="date" />
          </label>
          <label className="form-field">
            <span>To</span>
            <input defaultValue={query.to ?? ""} name="to" type="date" />
          </label>
          <label className="form-field">
            <span>Department</span>
            <select defaultValue={query.department ?? ""} name="department">
              <option value="">All departments</option>
              {AUDIT_DEPARTMENTS.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </label>
          <label className="form-field">
            <span>Action</span>
            <select defaultValue={query.action ?? ""} name="action">
              <option value="">All actions</option>
              {AUDIT_ACTIONS.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </label>
          <label className="form-field">
            <span>Actor / target</span>
            <input
              defaultValue={query.search ?? ""}
              maxLength={120}
              name="search"
              placeholder="Name, email, target type or ID"
            />
          </label>
          <button className="ui-button ui-button-secondary" type="submit">
            Apply filters
          </button>
        </form>
      </SectionCard>

      <div className="metric-grid metric-grid-four">
        <MetricCard
          icon="shield"
          label="Audit events"
          value={String(summary.total)}
          helper="Selected range"
        />
        <MetricCard
          icon="lock"
          label="Sensitive-data views"
          value={String(summary.sensitiveViews)}
          helper="Clinical and protected reads"
          tone="warning"
        />
        <MetricCard
          icon="profile"
          label="Authentication events"
          value={String(summary.loginEvents)}
          helper="Login, logout, lockout"
          tone="success"
        />
        <MetricCard
          icon="permission"
          label="Authorization changes"
          value={String(summary.permissionChanges)}
          helper="Roles and permissions"
          tone="commerce"
        />
      </div>

      <SectionCard
        title="Recent audit events"
        description={`Showing up to 200 events. ${summary.total} matched the selected filters.`}
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Action</th>
                <th>Actor</th>
                <th>Department</th>
                <th>Target</th>
                <th>Source</th>
              </tr>
            </thead>
            <tbody>
              {events.map((event) => (
                <tr key={event.id}>
                  <td>
                    <strong>
                      {event.createdAt.toLocaleDateString("en-BD")}
                    </strong>
                    <span>{event.createdAt.toLocaleTimeString("en-BD")}</span>
                  </td>
                  <td>
                    <StatusBadge tone={eventTone(event.action)}>
                      {event.action}
                    </StatusBadge>
                  </td>
                  <td>
                    <strong>{event.actor?.name ?? "System / anonymous"}</strong>
                    <span>{event.actor?.email ?? ""}</span>
                  </td>
                  <td>{event.department ?? "SYSTEM"}</td>
                  <td>
                    <strong>{event.targetType}</strong>
                    <span>{event.targetId ?? "—"}</span>
                  </td>
                  <td>
                    <strong>{event.ipAddress ?? "—"}</strong>
                    <span>
                      {event.userAgent ? event.userAgent.slice(0, 72) : ""}
                    </span>
                  </td>
                </tr>
              ))}
              {!events.length ? (
                <tr>
                  <td colSpan={6}>
                    No audit events matched the selected filters.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
