import type { ReactNode } from "react";
import { PanelShell } from "@/components/layout/panel-shell";
import { adminNavigation } from "@/config/navigation";
import { requireAdminSession } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import { getUiPreferences } from "@/lib/i18n/server";
import { localizeRoleLabel } from "@/lib/i18n/navigation";
import { filterNavigation } from "@/lib/rbac/navigation";

export default async function AdminLayout({
  children,
}: {
  children: ReactNode;
}) {
  const [session, preferences] = await Promise.all([
    requireAdminSession("/admin"),
    getUiPreferences(),
  ]);
  const roleName = session.user.isSuperAdmin
    ? "Super Admin"
    : (session.user.roles.find((item) => item.isAdminRole)?.name ?? "Admin");
  const role = localizeRoleLabel(preferences.locale, roleName);
  const navigation = session.user.isSuperAdmin
    ? adminNavigation
    : filterNavigation(adminNavigation, (key) =>
        hasPermission(session.user, key),
      );

  return (
    <PanelShell
      locale={preferences.locale}
      navigation={navigation}
      subtitle={
        preferences.locale === "bn"
          ? "পরিচালনা কর্মক্ষেত্র"
          : "Operations workspace"
      }
      surface="admin"
      themePreference={preferences.themePreference}
      title={preferences.locale === "bn" ? "অ্যাডমিন প্যানেল" : "Admin panel"}
      userName={session.user.name}
      userRole={role}
    >
      {children}
    </PanelShell>
  );
}
