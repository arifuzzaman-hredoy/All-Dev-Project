import {
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireGlobalPermission } from "@/lib/auth/authorization";
import { launchReadinessSnapshot } from "@/lib/launch/queries";

export const dynamic = "force-dynamic";

function checkTone(
  status: "PASS" | "WARN" | "BLOCK",
): "success" | "warning" | "danger" {
  if (status === "PASS") return "success";
  if (status === "WARN") return "warning";
  return "danger";
}

function checkLabel(status: "PASS" | "WARN" | "BLOCK"): string {
  if (status === "PASS") return "PASS";
  if (status === "WARN") return "WARNING";
  return "BLOCKER";
}

export default async function LaunchReadinessPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const session = await requireGlobalPermission(
    "system.operations.launch-readiness.view",
    "/admin/launch-readiness",
  );
  const query = await searchParams;
  const data = await launchReadinessSnapshot();
  const owner = session.user.isSuperAdmin;

  const configuration = data.checks.filter(
    (check) => check.group === "CONFIGURATION",
  );
  const content = data.checks.filter((check) => check.group === "CONTENT");
  const operations = data.checks.filter(
    (check) => check.group === "OPERATIONS",
  );

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Launch assurance"
        title="Production launch readiness"
        description="A fail-closed launch gate. Holy Life is launch-ready only when automated blockers are cleared and every manual acceptance gate is signed off."
      />

      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}

      <div
        className="launch-readiness-banner"
        data-ready={data.summary.ready ? "true" : "false"}
      >
        <div>
          <span>
            {data.summary.ready ? "READY FOR LAUNCH" : "LAUNCH BLOCKED"}
          </span>
          <strong>
            {data.summary.ready
              ? "All automated and manual launch gates are satisfied."
              : `${data.summary.blockers} automated blocker(s) and ${data.summary.manualPending} manual gate(s) remain.`}
          </strong>
          <p>
            Warnings do not block launch, but must be understood by the Primary
            Super Admin before final sign-off.
          </p>
        </div>
        <StatusBadge tone={data.summary.ready ? "success" : "danger"}>
          {data.summary.ready ? "READY" : "NOT READY"}
        </StatusBadge>
      </div>

      <div className="metric-grid metric-grid-four">
        <MetricCard
          icon="shield"
          label="Automated blockers"
          value={String(data.summary.blockers)}
          helper="Must reach zero"
          tone={data.summary.blockers ? "warning" : "success"}
        />
        <MetricCard
          icon="activity"
          label="Warnings"
          value={String(data.summary.warnings)}
          helper="Review before launch"
          tone={data.summary.warnings ? "warning" : "success"}
        />
        <MetricCard
          icon="clipboard"
          label="Manual acceptance"
          value={`${data.summary.accepted}/${data.acceptanceGates.length}`}
          helper="Owner-controlled gates"
          tone={data.summary.manualPending ? "warning" : "success"}
        />
        <MetricCard
          icon="globe"
          label="Production origin"
          value={data.context.appOrigin.replace(/^https?:\/\//, "")}
          helper={`${data.context.paymentMode}/${data.context.paymentEnvironment}`}
          tone="neutral"
        />
      </div>

      <div className="two-column-grid">
        <SectionCard
          title="Configuration gates"
          description="Runtime settings are evaluated without exposing secret values."
        >
          <div className="launch-check-list">
            {configuration.map((check) => (
              <div className="launch-check-row" key={check.key}>
                <div>
                  <strong>{check.label}</strong>
                  <p>{check.detail}</p>
                </div>
                <StatusBadge tone={checkTone(check.status)}>
                  {checkLabel(check.status)}
                </StatusBadge>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard
          title="Content gates"
          description="Starter placeholders and unreviewed legal text intentionally block launch."
        >
          <div className="launch-check-list">
            {content.map((check) => (
              <div className="launch-check-row" key={check.key}>
                <div>
                  <strong>{check.label}</strong>
                  <p>{check.detail}</p>
                </div>
                <StatusBadge tone={checkTone(check.status)}>
                  {checkLabel(check.status)}
                </StatusBadge>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <SectionCard
        title="Operations gates"
        description="Backup/restore evidence is required for launch; local-only backup mode remains an explicit blocker."
      >
        <div className="launch-check-list launch-check-list-wide">
          {operations.map((check) => (
            <div className="launch-check-row" key={check.key}>
              <div>
                <strong>{check.label}</strong>
                <p>{check.detail}</p>
              </div>
              <StatusBadge tone={checkTone(check.status)}>
                {checkLabel(check.status)}
              </StatusBadge>
            </div>
          ))}
        </div>
      </SectionCard>

      <SectionCard
        title="Manual acceptance gates"
        description={
          owner
            ? "Only the Primary Super Admin can change these launch decisions. Every change is audited."
            : "Only the Primary Super Admin can change these launch decisions."
        }
      >
        <div className="launch-acceptance-list">
          {data.acceptanceGates.map((gate) => {
            const current = data.acceptance[gate.key];
            return (
              <article className="launch-acceptance-row" key={gate.key}>
                <div className="launch-acceptance-copy">
                  <div>
                    <strong>{gate.label}</strong>
                    <StatusBadge
                      tone={current.status === "PASSED" ? "success" : "warning"}
                    >
                      {current.status}
                    </StatusBadge>
                  </div>
                  <p>{gate.description}</p>
                  {current.updatedAt ? (
                    <small>
                      Last updated{" "}
                      {new Date(current.updatedAt).toLocaleString("en-BD")}
                      {current.updatedBy ? ` by ${current.updatedBy}` : ""}
                    </small>
                  ) : (
                    <small>No owner acceptance has been recorded.</small>
                  )}
                  {current.note ? (
                    <blockquote>{current.note}</blockquote>
                  ) : null}
                </div>

                {owner ? (
                  <form
                    action="/api/admin/launch-readiness/acceptance"
                    className="launch-acceptance-form"
                    method="post"
                  >
                    <input name="gate" type="hidden" value={gate.key} />
                    <textarea
                      defaultValue={current.note ?? ""}
                      maxLength={500}
                      name="note"
                      placeholder="Optional acceptance note"
                      rows={2}
                    />
                    <div>
                      <button
                        className="ui-button ui-button-secondary"
                        name="status"
                        type="submit"
                        value="PENDING"
                      >
                        Mark pending
                      </button>
                      <button
                        className="ui-button ui-button-primary"
                        name="status"
                        type="submit"
                        value="PASSED"
                      >
                        Accept gate
                      </button>
                    </div>
                  </form>
                ) : null}
              </article>
            );
          })}
        </div>
      </SectionCard>

      <SectionCard title="Launch boundaries">
        <div className="settings-list">
          <div>
            <span>
              <strong>No automatic completion tags</strong>
              <small>
                Required acceptance evidence remains visible until the owner
                records the final decision.
              </small>
            </span>
          </div>
          <div>
            <span>
              <strong>No secret disclosure</strong>
              <small>
                Readiness checks expose configuration state only, never provider
                passwords or operational secrets.
              </small>
            </span>
          </div>
          <div>
            <span>
              <strong>No automatic destructive rollback drill</strong>
              <small>
                Rollback readiness is verified through immutable image retention
                and an explicit manual procedure.
              </small>
            </span>
          </div>
        </div>
      </SectionCard>
    </div>
  );
}
