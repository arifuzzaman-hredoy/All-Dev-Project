import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function AdminNotificationsPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  await requirePermission(
    "system.notifications.notification.manage",
    "/admin/notifications",
  );
  const query = await searchParams;
  const recent = await db.dashboardNotification.findMany({
    where: { dedupeKey: { startsWith: "admin:" } },
    include: { user: { select: { name: true, email: true, phone: true } } },
    orderBy: { createdAt: "desc" },
    take: 40,
  });

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Local in-app notifications"
        title="Notification center"
        description="Send notifications inside the Holy Life dashboard only. Email, SMS, push, and external providers remain disabled."
      />
      {query.success ? (
        <div className="notice-box notice-success">
          <strong>Success</strong>
          <p>{query.success}</p>
        </div>
      ) : null}
      {query.error ? (
        <div className="notice-box notice-danger">
          <strong>Action required</strong>
          <p>{query.error}</p>
        </div>
      ) : null}

      <SectionCard title="Send in-app notification">
        <form
          action="/api/admin/notifications/send"
          className="admin-form-stack"
          method="post"
        >
          <div className="two-column-grid">
            <label className="form-field">
              <span>Target</span>
              <select defaultValue="ALL" name="target">
                <option value="ALL">All active users</option>
                <option value="USER">One user</option>
              </select>
            </label>
            <label className="form-field">
              <span>User email or phone</span>
              <input
                name="recipient"
                placeholder="Required only for One user"
              />
            </label>
          </div>
          <div className="two-column-grid">
            <label className="form-field">
              <span>Kind</span>
              <select defaultValue="INFO" name="kind">
                <option>INFO</option>
                <option>SUCCESS</option>
                <option>WARNING</option>
                <option>ACTION</option>
              </select>
            </label>
            <label className="form-field">
              <span>Department label</span>
              <select defaultValue="SYSTEM" name="department">
                <option>HEALTHCARE</option>
                <option>COMMERCE</option>
                <option>LEARNING</option>
                <option>SYSTEM</option>
              </select>
            </label>
          </div>
          <label className="form-field">
            <span>Title</span>
            <input maxLength={160} name="title" required />
          </label>
          <label className="form-field">
            <span>Message</span>
            <textarea maxLength={1000} name="message" rows={4} />
          </label>
          <label className="form-field">
            <span>Dashboard link</span>
            <input maxLength={300} name="href" placeholder="/dashboard/..." />
          </label>
          <button className="ui-button ui-button-primary" type="submit">
            Send in-app notification
          </button>
        </form>
      </SectionCard>

      <SectionCard title="Recent admin notifications">
        <div className="settings-list">
          {recent.map((item) => (
            <div key={item.id}>
              <span>
                <strong>{item.title}</strong>
                <small>
                  {item.user.name} · {item.message ?? "No message"}
                </small>
              </span>
              <StatusBadge tone={item.isRead ? "neutral" : "info"}>
                {item.isRead ? "Read" : "Unread"}
              </StatusBadge>
            </div>
          ))}
          {!recent.length ? (
            <p>No admin notification has been sent yet.</p>
          ) : null}
        </div>
      </SectionCard>
    </div>
  );
}
