import Link from "next/link";
import { MetricCard, PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import {
  financeReportSummary,
  listFinanceTransactions,
} from "@/lib/finance/queries";
import { reportDate } from "@/lib/finance/validation";

export const dynamic = "force-dynamic";

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  await requirePermission(
    "system.reports.financial-report.view",
    "/admin/reports",
  );
  const query = await searchParams;
  const range = {
    from: reportDate(query.from),
    to: reportDate(query.to, true),
  };
  const [summary, transactions] = await Promise.all([
    financeReportSummary(range),
    listFinanceTransactions(range, 20),
  ]);
  const exportQuery = new URLSearchParams();
  if (query.from) exportQuery.set("from", query.from);
  if (query.to) exportQuery.set("to", query.to);

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Financial reporting"
        title="Finance & revenue reports"
        description="Local verified payments, refunds, outstanding balances, and department revenue. No payment gateway or external notification service is enabled."
        actions={
          <Link
            className="ui-button ui-button-primary"
            href={`/api/admin/reports/finance.csv?${exportQuery.toString()}`}
          >
            Export CSV
          </Link>
        }
      />

      <SectionCard title="Report period">
        <form className="finance-filter-form" method="get">
          <label className="form-field">
            <span>From</span>
            <input defaultValue={query.from ?? ""} name="from" type="date" />
          </label>
          <label className="form-field">
            <span>To</span>
            <input defaultValue={query.to ?? ""} name="to" type="date" />
          </label>
          <button className="ui-button ui-button-secondary" type="submit">
            Apply date range
          </button>
        </form>
      </SectionCard>

      <div className="metric-grid metric-grid-four">
        <MetricCard
          icon="reports"
          label="Net verified revenue"
          value={formatMoney(summary.netRevenue)}
          helper="Opening balances + verified ledger"
          tone="success"
        />
        <MetricCard
          icon="file"
          label="Verified payments"
          value={formatMoney(summary.verifiedPayments)}
          helper="Selected transaction period"
          tone="commerce"
        />
        <MetricCard
          icon="activity"
          label="Verified refunds"
          value={formatMoney(summary.verifiedRefunds)}
          helper="Selected transaction period"
          tone="warning"
        />
        <MetricCard
          icon="cart"
          label="Current outstanding"
          value={formatMoney(summary.outstandingApprox)}
          helper={`All accounts · ${summary.unpaid} unpaid · ${summary.partial} partial`}
          tone="neutral"
        />
      </div>

      <div className="three-column-grid">
        <SectionCard title="Healthcare revenue">
          <strong className="finance-report-number">
            {formatMoney(summary.revenueByDomain.HEALTHCARE)}
          </strong>
        </SectionCard>
        <SectionCard title="Commerce revenue">
          <strong className="finance-report-number">
            {formatMoney(summary.revenueByDomain.COMMERCE)}
          </strong>
        </SectionCard>
        <SectionCard title="Learning revenue">
          <strong className="finance-report-number">
            {formatMoney(summary.revenueByDomain.LEARNING)}
          </strong>
        </SectionCard>
      </div>

      <SectionCard
        title="Recent finance activity"
        description={`${summary.pendingVerification} account${summary.pendingVerification === 1 ? "" : "s"} awaiting verification.`}
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Receipt</th>
                <th>Department</th>
                <th>Reference</th>
                <th>Type</th>
                <th>Status</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((transaction) => (
                <tr key={transaction.id}>
                  <td>
                    <strong>{transaction.code}</strong>
                    <span>
                      {transaction.createdAt.toLocaleDateString("en-BD")}
                    </span>
                  </td>
                  <td>{transaction.account.domain}</td>
                  <td>{transaction.account.referenceCode}</td>
                  <td>{transaction.type}</td>
                  <td>{transaction.status}</td>
                  <td>
                    {formatMoney(
                      transaction.amount,
                      transaction.account.currency,
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
