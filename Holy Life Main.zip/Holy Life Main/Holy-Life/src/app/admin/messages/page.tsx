import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { hasPermission } from "@/lib/auth/session";
import { requirePermission } from "@/lib/auth/authorization";
import { messagingConfig } from "@/lib/messaging/config";
import { messagingAdminSnapshot } from "@/lib/messaging/queries";
import { maskedTarget } from "@/lib/messaging/validation";

export const dynamic = "force-dynamic";

function tone(
  status: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "DELIVERED" || status === "COMPLETED" || status === "ACTIVE")
    return "success";
  if (status === "FAILED") return "danger";
  if (status === "QUEUED" || status === "PROCESSING" || status === "SENDING")
    return "warning";
  if (status === "SENT") return "info";
  return "neutral";
}

export default async function AdminMessagesPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const session = await requirePermission(
    "system.messaging.campaign.view",
    "/admin/messages",
  );
  const query = await searchParams;
  const canSend = hasPermission(session.user, "system.messaging.campaign.send");
  const canCancel = hasPermission(
    session.user,
    "system.messaging.campaign.cancel",
  );
  const canViewTemplates = hasPermission(
    session.user,
    "system.messaging.template.view",
  );
  const canManageTemplates = hasPermission(
    session.user,
    "system.messaging.template.manage",
  );
  const canViewDeliveries = hasPermission(
    session.user,
    "system.messaging.delivery.view",
  );
  const canRetry = hasPermission(
    session.user,
    "system.messaging.delivery.retry",
  );
  const snapshot = await messagingAdminSnapshot({
    includeTemplates: canViewTemplates || canManageTemplates,
    includeDeliveries: canViewDeliveries || canRetry,
  });
  const activeTemplates = snapshot.templates.filter(
    (template) => template.status === "ACTIVE",
  );

  return (
    <div className="admin-page">
      <PageHeader
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Communications" },
        ]}
        eyebrow="Messaging operations"
        title="Communications center"
        description="Queue service or consented marketing messages, manage reusable templates, and track external email, SMS, and WhatsApp delivery without coupling Holy Life to one provider."
      />

      {query.success ? (
        <div className="notice-box notice-success">
          <strong>Success</strong>
          <p>{query.success}</p>
        </div>
      ) : null}
      {query.error ? (
        <div className="notice-box notice-danger">
          <strong>Action required</strong>
          <p>{query.error}</p>
        </div>
      ) : null}

      <div className="three-column-grid">
        <SectionCard title="Provider mode">
          <strong className="finance-report-number">
            {messagingConfig.mode.toUpperCase()}
          </strong>
          <p>
            External dispatch remains inert until webhook mode and secrets are
            configured.
          </p>
        </SectionCard>
        {canViewDeliveries || canRetry ? (
          <SectionCard title="Queued">
            <strong className="finance-report-number">{snapshot.queued}</strong>
            <p>Persisted outbox deliveries waiting for dispatch.</p>
          </SectionCard>
        ) : null}
        {canViewDeliveries || canRetry ? (
          <SectionCard title="Failed">
            <strong className="finance-report-number">{snapshot.failed}</strong>
            <p>Terminal deliveries requiring admin review or retry.</p>
          </SectionCard>
        ) : null}
      </div>

      {canSend ? (
        <SectionCard
          title="Queue campaign"
          description={`Per-campaign hard limit: ${messagingConfig.campaignMaxRecipients.toLocaleString("en-BD")} eligible users.`}
        >
          <form
            action="/api/admin/messages/send"
            className="admin-form-stack"
            method="post"
          >
            <div className="two-column-grid">
              <label className="form-field">
                <span>Campaign name</span>
                <input maxLength={140} name="name" required />
              </label>
              <label className="form-field">
                <span>Channel</span>
                <select defaultValue="EMAIL" name="channel">
                  <option value="EMAIL">Email</option>
                  <option value="SMS">SMS</option>
                  <option value="WHATSAPP">WhatsApp</option>
                </select>
              </label>
            </div>
            <div className="two-column-grid">
              <label className="form-field">
                <span>Purpose</span>
                <select defaultValue="SERVICE" name="purpose">
                  <option value="SERVICE">Service / transactional</option>
                  <option value="MARKETING">
                    Marketing (explicit opt-in only)
                  </option>
                </select>
              </label>
              <label className="form-field">
                <span>Department</span>
                <select defaultValue="SYSTEM" name="department">
                  <option>HEALTHCARE</option>
                  <option>COMMERCE</option>
                  <option>LEARNING</option>
                  <option>WEBSITE</option>
                  <option>SYSTEM</option>
                </select>
              </label>
            </div>
            <div className="two-column-grid">
              <label className="form-field">
                <span>Audience</span>
                <select defaultValue="USER" name="audience">
                  <option value="USER">One active user</option>
                  <option value="ALL_ACTIVE">All eligible active users</option>
                </select>
              </label>
              <label className="form-field">
                <span>User email or phone</span>
                <input
                  maxLength={320}
                  name="recipient"
                  placeholder="Required for one-user campaign"
                />
              </label>
            </div>
            <div className="two-column-grid">
              <label className="form-field">
                <span>Active template</span>
                <select defaultValue="" name="templateId">
                  <option value="">
                    No template — use message fields below
                  </option>
                  {activeTemplates.map((template) => (
                    <option key={template.id} value={template.id}>
                      {template.code} · {template.channel}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Schedule</span>
                <input name="scheduledAt" type="datetime-local" />
              </label>
            </div>
            <label className="form-field">
              <span>Email subject</span>
              <input
                maxLength={240}
                name="subject"
                placeholder="Required for email when no template is selected"
              />
            </label>
            <label className="form-field">
              <span>Message body</span>
              <textarea
                maxLength={4000}
                name="body"
                placeholder="Supports {{name}}, {{email}}, {{phone}}, and {{appUrl}}"
                rows={5}
              />
            </label>
            <button className="ui-button ui-button-primary" type="submit">
              Queue campaign
            </button>
          </form>
        </SectionCard>
      ) : null}

      {canManageTemplates ? (
        <SectionCard
          title="Create message template"
          description="Templates are plain-text by design; no executable HTML or template expressions are evaluated."
        >
          <form
            action="/api/admin/messages/templates"
            className="admin-form-stack"
            method="post"
          >
            <div className="two-column-grid">
              <label className="form-field">
                <span>Code</span>
                <input
                  maxLength={80}
                  name="code"
                  placeholder="APPOINTMENT_REMINDER"
                  required
                />
              </label>
              <label className="form-field">
                <span>Name</span>
                <input maxLength={120} name="name" required />
              </label>
            </div>
            <div className="two-column-grid">
              <label className="form-field">
                <span>Channel</span>
                <select defaultValue="EMAIL" name="channel">
                  <option value="EMAIL">Email</option>
                  <option value="SMS">SMS</option>
                  <option value="WHATSAPP">WhatsApp</option>
                </select>
              </label>
              <label className="form-field">
                <span>Status</span>
                <select defaultValue="DRAFT" name="status">
                  <option value="DRAFT">Draft</option>
                  <option value="ACTIVE">Active</option>
                </select>
              </label>
            </div>
            <label className="form-field">
              <span>Department</span>
              <select defaultValue="SYSTEM" name="department">
                <option>HEALTHCARE</option>
                <option>COMMERCE</option>
                <option>LEARNING</option>
                <option>WEBSITE</option>
                <option>SYSTEM</option>
              </select>
            </label>
            <label className="form-field">
              <span>Email subject</span>
              <input maxLength={240} name="subject" />
            </label>
            <label className="form-field">
              <span>Body</span>
              <textarea
                maxLength={4000}
                name="body"
                placeholder="Supports {{name}}, {{email}}, {{phone}}, and {{appUrl}}"
                required
                rows={5}
              />
            </label>
            <button className="ui-button ui-button-secondary" type="submit">
              Create template
            </button>
          </form>
        </SectionCard>
      ) : null}

      {canViewTemplates || canManageTemplates ? (
        <SectionCard title="Templates">
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Template</th>
                  <th>Channel</th>
                  <th>Department</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {snapshot.templates.map((template) => (
                  <tr key={template.id}>
                    <td>
                      <strong>{template.code}</strong>
                      <span>{template.name}</span>
                    </td>
                    <td>{template.channel}</td>
                    <td>{template.department ?? "SYSTEM"}</td>
                    <td>
                      <StatusBadge tone={tone(template.status)}>
                        {template.status}
                      </StatusBadge>
                    </td>
                    <td>
                      {canManageTemplates ? (
                        <form
                          action={`/api/admin/messages/templates/${template.id}/status`}
                          method="post"
                        >
                          <select defaultValue={template.status} name="status">
                            <option value="DRAFT">Draft</option>
                            <option value="ACTIVE">Active</option>
                            <option value="ARCHIVED">Archived</option>
                          </select>
                          <button
                            className="ui-button ui-button-quiet"
                            type="submit"
                          >
                            Update
                          </button>
                        </form>
                      ) : (
                        "—"
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!snapshot.templates.length ? (
            <p>No message templates have been created.</p>
          ) : null}
        </SectionCard>
      ) : null}

      <SectionCard title="Recent campaigns">
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Campaign</th>
                <th>Channel</th>
                <th>Audience</th>
                <th>Progress</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {snapshot.campaigns.map((campaign) => (
                <tr key={campaign.id}>
                  <td>
                    <strong>{campaign.code}</strong>
                    <span>{campaign.name}</span>
                  </td>
                  <td>
                    {campaign.channel}
                    <span>{campaign.purpose}</span>
                  </td>
                  <td>
                    {campaign.audience}
                    <span>{campaign.recipientCount} eligible</span>
                  </td>
                  <td>
                    {campaign.deliveredCount} delivered · {campaign.failedCount}{" "}
                    failed
                  </td>
                  <td>
                    <StatusBadge tone={tone(campaign.status)}>
                      {campaign.status}
                    </StatusBadge>
                  </td>
                  <td>
                    {canCancel &&
                    (campaign.status === "QUEUED" ||
                      campaign.status === "PROCESSING") ? (
                      <form
                        action={`/api/admin/messages/campaigns/${campaign.id}/cancel`}
                        method="post"
                      >
                        <button
                          className="ui-button ui-button-quiet"
                          type="submit"
                        >
                          Cancel
                        </button>
                      </form>
                    ) : (
                      "—"
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!snapshot.campaigns.length ? (
          <p>No external message campaign has been queued.</p>
        ) : null}
      </SectionCard>

      {canViewDeliveries || canRetry ? (
        <SectionCard
          title="Recent deliveries"
          description="Targets are masked in the admin UI; full recipient identifiers remain server-side for provider dispatch and audit reconciliation."
        >
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Recipient</th>
                  <th>Channel</th>
                  <th>Status</th>
                  <th>Attempts</th>
                  <th>Provider</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {snapshot.deliveries.map((delivery) => (
                  <tr key={delivery.id}>
                    <td>
                      <strong>{delivery.user?.name ?? "Recipient"}</strong>
                      <span>{maskedTarget(delivery.target)}</span>
                    </td>
                    <td>
                      {delivery.channel}
                      <span>{delivery.purpose}</span>
                    </td>
                    <td>
                      <StatusBadge tone={tone(delivery.status)}>
                        {delivery.status}
                      </StatusBadge>
                      {delivery.lastError ? (
                        <span>{delivery.lastError}</span>
                      ) : null}
                    </td>
                    <td>
                      {delivery.attemptCount}/{delivery.maxAttempts}
                    </td>
                    <td>{delivery.providerStatus ?? "—"}</td>
                    <td>
                      {delivery.status === "FAILED" && canRetry ? (
                        <form
                          action={`/api/admin/messages/deliveries/${delivery.id}/retry`}
                          method="post"
                        >
                          <button
                            className="ui-button ui-button-quiet"
                            type="submit"
                          >
                            Retry
                          </button>
                        </form>
                      ) : (
                        "—"
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!snapshot.deliveries.length ? (
            <p>No external delivery records exist yet.</p>
          ) : null}
        </SectionCard>
      ) : null}
    </div>
  );
}
