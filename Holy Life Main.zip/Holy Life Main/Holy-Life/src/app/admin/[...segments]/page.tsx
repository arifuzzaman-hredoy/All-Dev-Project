import { ModulePage } from "@/components/ui/module-page";
import {
  requirePermission,
  requireAdminSession,
} from "@/lib/auth/authorization";
import {
  breadcrumbsFromSegments,
  pageTitleFromSegments,
} from "@/lib/panel-page";
import { permissionForAdminPath } from "@/lib/rbac/navigation";

export default async function AdminModulePage({
  params,
}: {
  params: Promise<{ segments: string[] }>;
}) {
  const { segments } = await params;
  const activePath = `/admin/${segments.join("/")}`;
  const permission = permissionForAdminPath(activePath);
  if (permission) await requirePermission(permission, activePath);
  else await requireAdminSession(activePath);

  const section = segments[0] ?? "operations";
  const title = pageTitleFromSegments(segments);
  return (
    <ModulePage
      activePath={activePath}
      baseHref={`/admin/${section}`}
      breadcrumbs={breadcrumbsFromSegments("Admin", "/admin", segments)}
      description={`Permission-protected ${title.toLowerCase()} workspace. Live business CRUD will be connected in its dedicated implementation phase.`}
      tabs={[{ label: title, href: activePath }]}
      title={title}
    />
  );
}
