/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{ productId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.catalog.product.view",
    "/admin/commerce/products",
  );
  const { productId } = await params;
  const query = await searchParams;
  const [product, categories, brands] = await Promise.all([
    db.product.findUnique({
      where: { id: productId },
      include: {
        category: true,
        brand: true,
        variants: { orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }] },
        images: { orderBy: [{ isPrimary: "desc" }, { position: "asc" }] },
      },
    }),
    db.productCategory.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    db.productBrand.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" },
    }),
  ]);
  if (!product) notFound();
  const primaryImage = product.images[0] ?? null;

  return (
    <div className="admin-page">
      <PageHeader
        actions={
          <Link
            className="ui-button ui-button-secondary"
            href="/admin/commerce/products"
          >
            Back
          </Link>
        }
        description={`${product.category.name} · ${product.slug}`}
        eyebrow="Product"
        title={product.name}
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}

      <div className="two-column-grid">
        <SectionCard title="Catalog record">
          <form
            action={`/api/admin/commerce/products/${product.id}`}
            className="panel-form"
            method="post"
          >
            <div className="form-grid two">
              <label>
                Name (English)
                <input
                  defaultValue={product.name}
                  maxLength={160}
                  name="name"
                  required
                />
              </label>
              <label>
                নাম (বাংলা)
                <input
                  defaultValue={product.nameBn ?? ""}
                  maxLength={160}
                  name="nameBn"
                />
              </label>
              <label>
                Slug
                <input
                  defaultValue={product.slug}
                  maxLength={100}
                  name="slug"
                  required
                />
              </label>
              <label>
                Category
                <select
                  defaultValue={product.categoryId}
                  name="categoryId"
                  required
                >
                  {categories.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Brand
                <select defaultValue={product.brandId ?? ""} name="brandId">
                  <option value="">No brand</option>
                  {brands.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Status
                <select defaultValue={product.status} name="status">
                  <option value="ACTIVE">Active</option>
                  <option value="DRAFT">Draft</option>
                  <option value="INACTIVE">Inactive</option>
                  <option value="ARCHIVED">Archived</option>
                </select>
              </label>
              <label>
                Featured
                <select
                  defaultValue={product.isFeatured ? "true" : "false"}
                  name="isFeatured"
                >
                  <option value="false">No</option>
                  <option value="true">Yes</option>
                </select>
              </label>
              <label className="span-2">
                Short description (English)
                <textarea
                  defaultValue={product.shortDescription ?? ""}
                  maxLength={300}
                  name="shortDescription"
                  rows={2}
                />
              </label>
              <label className="span-2">
                সংক্ষিপ্ত বিবরণ (বাংলা)
                <textarea
                  defaultValue={product.shortDescriptionBn ?? ""}
                  maxLength={300}
                  name="shortDescriptionBn"
                  rows={2}
                />
              </label>
              <label className="span-2">
                Description (English)
                <textarea
                  defaultValue={product.description ?? ""}
                  maxLength={5000}
                  name="description"
                  rows={5}
                />
              </label>
              <label className="span-2">
                বিস্তারিত বিবরণ (বাংলা)
                <textarea
                  defaultValue={product.descriptionBn ?? ""}
                  maxLength={5000}
                  name="descriptionBn"
                  rows={5}
                />
              </label>
            </div>

            <div className="admin-form-section compact-top">
              <div className="admin-form-section-heading">
                <strong>Primary photo</strong>
                <span>
                  Replace or remove the public catalog image without database
                  editing.
                </span>
              </div>
              {primaryImage ? (
                <div className="admin-media-preview">
                  <img
                    alt={primaryImage.altText ?? product.name}
                    src={primaryImage.url}
                  />
                  <span>{primaryImage.url}</span>
                </div>
              ) : null}
              <div className="form-grid two">
                <label className="span-2">
                  Image URL
                  <input
                    defaultValue={primaryImage?.url ?? ""}
                    maxLength={1000}
                    name="imageUrl"
                    type="url"
                  />
                </label>
                <label>
                  Alt text (English)
                  <input
                    defaultValue={primaryImage?.altText ?? product.name}
                    maxLength={200}
                    name="imageAlt"
                  />
                </label>
                <label>
                  ছবির বিকল্প লেখা (বাংলা)
                  <input
                    defaultValue={
                      primaryImage?.altTextBn ?? product.nameBn ?? ""
                    }
                    maxLength={200}
                    name="imageAltBn"
                  />
                </label>
                <label className="form-check span-2">
                  <input name="removePrimaryImage" type="checkbox" />
                  <span>
                    <strong>Remove primary image</strong>
                    <small>
                      Use this only when the current photo is no longer
                      approved.
                    </small>
                  </span>
                </label>
              </div>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Save product
            </button>
          </form>
        </SectionCard>

        <SectionCard title="Variants">
          <div className="settings-list">
            {product.variants.map((variant) => (
              <details className="managed-record" key={variant.id}>
                <summary>
                  <span>
                    <strong>
                      {variant.name}
                      {variant.nameBn ? ` / ${variant.nameBn}` : ""} ·{" "}
                      {variant.sku}
                    </strong>
                    <small>
                      {formatMoney(variant.price.toString())} · Stock{" "}
                      {variant.stockOnHand}
                    </small>
                  </span>
                  <StatusBadge tone={variant.isActive ? "success" : "neutral"}>
                    {variant.isActive ? "Active" : "Inactive"}
                  </StatusBadge>
                </summary>
                <form
                  action={`/api/admin/commerce/products/${product.id}/variants/${variant.id}`}
                  className="panel-form compact-top"
                  method="post"
                >
                  <div className="form-grid two">
                    <label>
                      Name (English)
                      <input
                        defaultValue={variant.name}
                        maxLength={100}
                        name="name"
                        required
                      />
                    </label>
                    <label>
                      নাম (বাংলা)
                      <input
                        defaultValue={variant.nameBn ?? ""}
                        maxLength={100}
                        name="nameBn"
                      />
                    </label>
                    <label>
                      Price
                      <input
                        defaultValue={Number(variant.price)}
                        min="0"
                        name="price"
                        step="0.01"
                        type="number"
                        required
                      />
                    </label>
                    <label>
                      Compare-at price
                      <input
                        defaultValue={
                          variant.compareAtPrice
                            ? Number(variant.compareAtPrice)
                            : ""
                        }
                        min="0"
                        name="compareAtPrice"
                        step="0.01"
                        type="number"
                      />
                    </label>
                    <label>
                      Low-stock threshold
                      <input
                        defaultValue={variant.lowStockAt}
                        min="0"
                        name="lowStockAt"
                        type="number"
                      />
                    </label>
                    <label>
                      Status
                      <select
                        defaultValue={variant.isActive ? "true" : "false"}
                        name="isActive"
                      >
                        <option value="true">Active</option>
                        <option value="false">Inactive</option>
                      </select>
                    </label>
                  </div>
                  <p className="form-note">
                    Stock quantity is intentionally managed from Inventory so
                    every adjustment keeps an auditable stock movement.
                  </p>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Save variant
                  </button>
                </form>
              </details>
            ))}
          </div>

          <form
            action={`/api/admin/commerce/products/${product.id}/variants`}
            className="panel-form compact-top"
            method="post"
          >
            <div className="form-grid two">
              <label>
                Variant name (English)
                <input maxLength={100} name="name" required />
              </label>
              <label>
                ভ্যারিয়েন্ট নাম (বাংলা)
                <input maxLength={100} name="nameBn" />
              </label>
              <label>
                SKU
                <input maxLength={80} name="sku" required />
              </label>
              <label>
                Price
                <input
                  min="0"
                  name="price"
                  step="0.01"
                  type="number"
                  required
                />
              </label>
              <label>
                Compare-at price
                <input
                  min="0"
                  name="compareAtPrice"
                  step="0.01"
                  type="number"
                />
              </label>
              <label>
                Opening stock
                <input
                  defaultValue="0"
                  min="0"
                  name="stockOnHand"
                  type="number"
                />
              </label>
              <label>
                Low-stock threshold
                <input
                  defaultValue="5"
                  min="0"
                  name="lowStockAt"
                  type="number"
                />
              </label>
            </div>
            <button className="ui-button ui-button-secondary" type="submit">
              Add variant
            </button>
          </form>
        </SectionCard>
      </div>
    </div>
  );
}
