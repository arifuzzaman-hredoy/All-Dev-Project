import { AdminProductList } from "@/components/commerce/admin-product-list";
import { requirePermission } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.catalog.product.view",
    "/admin/commerce/products",
  );
  const q = await searchParams;
  return <AdminProductList error={q.error} success={q.success} />;
}
