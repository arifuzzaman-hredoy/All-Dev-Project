import {
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.catalog.category.manage",
    "/admin/commerce/products/categories",
  );
  const query = await searchParams;
  const [categories, brands] = await Promise.all([
    db.productCategory.findMany({
      include: { _count: { select: { products: true } } },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    db.productBrand.findMany({
      include: { _count: { select: { products: true } } },
      orderBy: { name: "asc" },
    }),
  ]);

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Catalog"
        title="Categories & brands"
        description="Create, update and safely deactivate the structures used by public product discovery."
      />
      <TabBar
        items={[
          { label: "Products", href: "/admin/commerce/products" },
          {
            label: "Categories",
            href: "/admin/commerce/products/categories",
            active: true,
          },
          { label: "Inventory", href: "/admin/commerce/products/inventory" },
        ]}
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}

      <div className="two-column-grid">
        <SectionCard title="Categories">
          <form
            action="/api/admin/commerce/categories"
            className="panel-form"
            method="post"
          >
            <div className="form-grid two">
              <label>
                Name (English)
                <input maxLength={100} name="name" required />
              </label>
              <label>
                নাম (বাংলা)
                <input maxLength={100} name="nameBn" />
              </label>
              <label>
                Slug
                <input maxLength={100} name="slug" placeholder="optional" />
              </label>
              <label>
                Display order
                <input
                  defaultValue="100"
                  min="0"
                  name="displayOrder"
                  type="number"
                />
              </label>
              <label className="span-2">
                Description (English)
                <textarea maxLength={500} name="description" rows={2} />
              </label>
              <label className="span-2">
                বিবরণ (বাংলা)
                <textarea maxLength={500} name="descriptionBn" rows={2} />
              </label>
              <label className="span-2">
                Category image URL
                <input maxLength={1000} name="imageUrl" type="url" />
              </label>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Add category
            </button>
          </form>

          <div className="settings-list compact-top">
            {categories.map((item) => (
              <details className="managed-record" key={item.id}>
                <summary>
                  <span>
                    <strong>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </strong>
                    <small>
                      {item.slug} · {item._count.products} product(s)
                    </small>
                  </span>
                  <StatusBadge tone={item.isActive ? "success" : "neutral"}>
                    {item.isActive ? "Active" : "Inactive"}
                  </StatusBadge>
                </summary>
                <form
                  action={`/api/admin/commerce/categories/${item.id}`}
                  className="panel-form compact-top"
                  method="post"
                >
                  <div className="form-grid two">
                    <label>
                      Name (English)
                      <input
                        defaultValue={item.name}
                        maxLength={100}
                        name="name"
                        required
                      />
                    </label>
                    <label>
                      নাম (বাংলা)
                      <input
                        defaultValue={item.nameBn ?? ""}
                        maxLength={100}
                        name="nameBn"
                      />
                    </label>
                    <label>
                      Slug
                      <input
                        defaultValue={item.slug}
                        maxLength={100}
                        name="slug"
                        required
                      />
                    </label>
                    <label>
                      Display order
                      <input
                        defaultValue={item.displayOrder}
                        min="0"
                        name="displayOrder"
                        type="number"
                      />
                    </label>
                    <label>
                      Status
                      <select
                        defaultValue={item.isActive ? "true" : "false"}
                        name="isActive"
                      >
                        <option value="true">Active</option>
                        <option value="false">Inactive</option>
                      </select>
                    </label>
                    <label>
                      Image URL
                      <input
                        defaultValue={item.imageUrl ?? ""}
                        maxLength={1000}
                        name="imageUrl"
                        type="url"
                      />
                    </label>
                    <label className="span-2">
                      Description (English)
                      <textarea
                        defaultValue={item.description ?? ""}
                        maxLength={500}
                        name="description"
                        rows={2}
                      />
                    </label>
                    <label className="span-2">
                      বিবরণ (বাংলা)
                      <textarea
                        defaultValue={item.descriptionBn ?? ""}
                        maxLength={500}
                        name="descriptionBn"
                        rows={2}
                      />
                    </label>
                  </div>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Save category
                  </button>
                </form>
              </details>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Brands">
          <form
            action="/api/admin/commerce/brands"
            className="panel-form"
            method="post"
          >
            <div className="form-grid two">
              <label>
                Name (English)
                <input maxLength={100} name="name" required />
              </label>
              <label>
                নাম (বাংলা)
                <input maxLength={100} name="nameBn" />
              </label>
              <label>
                Slug
                <input maxLength={100} name="slug" placeholder="optional" />
              </label>
              <label>
                Logo URL
                <input maxLength={1000} name="logoUrl" type="url" />
              </label>
              <label className="span-2">
                Description (English)
                <textarea maxLength={500} name="description" rows={2} />
              </label>
              <label className="span-2">
                বিবরণ (বাংলা)
                <textarea maxLength={500} name="descriptionBn" rows={2} />
              </label>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Add brand
            </button>
          </form>

          <div className="settings-list compact-top">
            {brands.map((item) => (
              <details className="managed-record" key={item.id}>
                <summary>
                  <span>
                    <strong>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </strong>
                    <small>
                      {item.slug} · {item._count.products} product(s)
                    </small>
                  </span>
                  <StatusBadge tone={item.isActive ? "success" : "neutral"}>
                    {item.isActive ? "Active" : "Inactive"}
                  </StatusBadge>
                </summary>
                <form
                  action={`/api/admin/commerce/brands/${item.id}`}
                  className="panel-form compact-top"
                  method="post"
                >
                  <div className="form-grid two">
                    <label>
                      Name (English)
                      <input
                        defaultValue={item.name}
                        maxLength={100}
                        name="name"
                        required
                      />
                    </label>
                    <label>
                      নাম (বাংলা)
                      <input
                        defaultValue={item.nameBn ?? ""}
                        maxLength={100}
                        name="nameBn"
                      />
                    </label>
                    <label>
                      Slug
                      <input
                        defaultValue={item.slug}
                        maxLength={100}
                        name="slug"
                        required
                      />
                    </label>
                    <label>
                      Status
                      <select
                        defaultValue={item.isActive ? "true" : "false"}
                        name="isActive"
                      >
                        <option value="true">Active</option>
                        <option value="false">Inactive</option>
                      </select>
                    </label>
                    <label className="span-2">
                      Logo URL
                      <input
                        defaultValue={item.logoUrl ?? ""}
                        maxLength={1000}
                        name="logoUrl"
                        type="url"
                      />
                    </label>
                    <label className="span-2">
                      Description (English)
                      <textarea
                        defaultValue={item.description ?? ""}
                        maxLength={500}
                        name="description"
                        rows={2}
                      />
                    </label>
                    <label className="span-2">
                      বিবরণ (বাংলা)
                      <textarea
                        defaultValue={item.descriptionBn ?? ""}
                        maxLength={500}
                        name="descriptionBn"
                        rows={2}
                      />
                    </label>
                  </div>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Save brand
                  </button>
                </form>
              </details>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
