import Link from "next/link";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  await requirePermission(
    "commerce.catalog.product.create",
    "/admin/commerce/products/create",
  );
  const query = await searchParams;
  const [categories, brands] = await Promise.all([
    db.productCategory.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    db.productBrand.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" },
    }),
  ]);

  return (
    <div className="admin-page">
      <PageHeader
        actions={
          <Link
            className="ui-button ui-button-secondary"
            href="/admin/commerce/products"
          >
            Back
          </Link>
        }
        description="Create a production catalog item with bilingual copy, a primary photo, default variant and opening stock."
        eyebrow="Catalog"
        title="Create product"
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      <SectionCard title="Product information">
        <form
          action="/api/admin/commerce/products"
          className="panel-form"
          method="post"
        >
          <div className="admin-form-section">
            <div className="admin-form-section-heading">
              <strong>Public catalog copy</strong>
              <span>
                Bangla and English are stored separately; customers see the
                version matching their selected language.
              </span>
            </div>
            <div className="form-grid two">
              <label>
                Product name (English)
                <input maxLength={160} name="name" required />
              </label>
              <label>
                পণ্যের নাম (বাংলা)
                <input maxLength={160} name="nameBn" />
              </label>
              <label>
                Slug
                <input
                  maxLength={100}
                  name="slug"
                  placeholder="auto-from-English-name"
                />
              </label>
              <label>
                Category
                <select name="categoryId" required>
                  <option value="">Select category</option>
                  {categories.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Brand
                <select name="brandId">
                  <option value="">No brand</option>
                  {brands.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                      {item.nameBn ? ` / ${item.nameBn}` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Status
                <select defaultValue="ACTIVE" name="status">
                  <option value="ACTIVE">Active</option>
                  <option value="DRAFT">Draft</option>
                  <option value="INACTIVE">Inactive</option>
                </select>
              </label>
              <label className="span-2">
                Short description (English)
                <textarea maxLength={300} name="shortDescription" rows={2} />
              </label>
              <label className="span-2">
                সংক্ষিপ্ত বিবরণ (বাংলা)
                <textarea maxLength={300} name="shortDescriptionBn" rows={2} />
              </label>
              <label className="span-2">
                Description (English)
                <textarea maxLength={5000} name="description" rows={5} />
              </label>
              <label className="span-2">
                বিস্তারিত বিবরণ (বাংলা)
                <textarea maxLength={5000} name="descriptionBn" rows={5} />
              </label>
            </div>
          </div>

          <div className="admin-form-section">
            <div className="admin-form-section-heading">
              <strong>Primary product photo</strong>
              <span>
                Use an approved product photograph. The URL remains editable
                later from the product record.
              </span>
            </div>
            <div className="form-grid two">
              <label className="span-2">
                Primary image URL
                <input
                  maxLength={1000}
                  name="imageUrl"
                  placeholder="https://..."
                  type="url"
                />
              </label>
              <label>
                Image alt text (English)
                <input maxLength={200} name="imageAlt" />
              </label>
              <label>
                ছবির বিকল্প লেখা (বাংলা)
                <input maxLength={200} name="imageAltBn" />
              </label>
            </div>
          </div>

          <div className="admin-form-section">
            <div className="admin-form-section-heading">
              <strong>Default sellable variant</strong>
              <span>
                SKU and opening stock are created atomically. Future stock
                changes should use Inventory so the movement history remains
                correct.
              </span>
            </div>
            <div className="form-grid two">
              <label>
                SKU
                <input maxLength={80} name="sku" required />
              </label>
              <label>
                Variant name (English)
                <input
                  defaultValue="Standard"
                  maxLength={100}
                  name="variantName"
                  required
                />
              </label>
              <label>
                ভ্যারিয়েন্ট নাম (বাংলা)
                <input
                  maxLength={100}
                  name="variantNameBn"
                  placeholder="স্ট্যান্ডার্ড"
                />
              </label>
              <label>
                Price (BDT)
                <input
                  min="0"
                  name="price"
                  step="0.01"
                  type="number"
                  required
                />
              </label>
              <label>
                Compare-at price (BDT)
                <input
                  min="0"
                  name="compareAtPrice"
                  step="0.01"
                  type="number"
                />
              </label>
              <label>
                Opening stock
                <input
                  defaultValue="0"
                  min="0"
                  name="stockOnHand"
                  type="number"
                />
              </label>
              <label>
                Low stock threshold
                <input
                  defaultValue="5"
                  min="0"
                  name="lowStockAt"
                  type="number"
                />
              </label>
              <label className="form-check span-2">
                <input name="isFeatured" type="checkbox" />
                <span>
                  <strong>Featured product</strong>
                  <small>
                    Place this item earlier in public catalog ordering.
                  </small>
                </span>
              </label>
            </div>
          </div>
          <button className="ui-button ui-button-primary" type="submit">
            Create product
          </button>
        </form>
      </SectionCard>
    </div>
  );
}
