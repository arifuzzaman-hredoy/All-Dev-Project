import {
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.inventory.stock.view",
    "/admin/commerce/products/inventory",
  );
  const q = await searchParams;
  const variants = await db.productVariant.findMany({
    where: { isActive: true, product: { status: { not: "ARCHIVED" } } },
    include: {
      product: true,
      movements: { orderBy: { createdAt: "desc" }, take: 3 },
    },
    orderBy: [{ stockOnHand: "asc" }, { updatedAt: "desc" }],
  });
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Inventory"
        title="Stock ledger"
        description="Every stock change creates an immutable movement record."
      />
      <TabBar
        items={[
          { label: "Products", href: "/admin/commerce/products" },
          { label: "Categories", href: "/admin/commerce/products/categories" },
          {
            label: "Inventory",
            href: "/admin/commerce/products/inventory",
            active: true,
          },
        ]}
      />
      {q.error ? <div className="form-alert error">{q.error}</div> : null}
      {q.success ? <div className="form-alert success">{q.success}</div> : null}
      <SectionCard
        title="Variants"
        description={`${variants.length} active SKU${variants.length === 1 ? "" : "s"}`}
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Product / SKU</th>
                <th>Price</th>
                <th>On hand</th>
                <th>Threshold</th>
                <th>Adjust</th>
              </tr>
            </thead>
            <tbody>
              {variants.map((variant) => (
                <tr key={variant.id}>
                  <td>
                    <strong>{variant.product.name}</strong>
                    <span>
                      {variant.name} · {variant.sku}
                    </span>
                  </td>
                  <td>{formatMoney(variant.price.toString())}</td>
                  <td>
                    <StatusBadge
                      tone={
                        variant.stockOnHand <= variant.lowStockAt
                          ? "warning"
                          : "success"
                      }
                    >
                      {variant.stockOnHand}
                    </StatusBadge>
                  </td>
                  <td>{variant.lowStockAt}</td>
                  <td>
                    <form
                      action="/api/admin/commerce/inventory"
                      className="table-inline-form"
                      method="post"
                    >
                      <input
                        name="variantId"
                        type="hidden"
                        value={variant.id}
                      />
                      <select name="type">
                        <option value="PURCHASE">Purchase / in</option>
                        <option value="ADJUSTMENT_IN">Adjustment in</option>
                        <option value="ADJUSTMENT_OUT">Adjustment out</option>
                        <option value="DAMAGE_OUT">Damage out</option>
                        <option value="RETURN_IN">Return in</option>
                      </select>
                      <input
                        min="1"
                        name="quantity"
                        type="number"
                        defaultValue="1"
                      />
                      <input name="note" placeholder="Reason" />
                      <button
                        className="ui-button ui-button-quiet"
                        type="submit"
                      >
                        Post
                      </button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
