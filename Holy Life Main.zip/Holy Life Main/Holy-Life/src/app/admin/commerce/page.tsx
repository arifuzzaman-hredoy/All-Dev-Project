import { redirect } from "next/navigation";
export default function CommerceAdminPage() {
  redirect("/admin/commerce/products");
}
