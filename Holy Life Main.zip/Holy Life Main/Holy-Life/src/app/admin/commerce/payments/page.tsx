import { redirect } from "next/navigation";

export default function CommercePaymentsRedirect() {
  redirect("/admin/finance/payments?domain=COMMERCE");
}
