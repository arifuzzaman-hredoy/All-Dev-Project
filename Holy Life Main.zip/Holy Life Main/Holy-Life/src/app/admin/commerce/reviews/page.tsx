import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.catalog.product.edit",
    "/admin/commerce/reviews",
  );
  const q = await searchParams;
  const reviews = await db.productReview.findMany({
    include: {
      product: true,
      user: { select: { name: true } },
      order: { select: { code: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Trust"
        title="Product reviews"
        description="Only verified delivered-order reviews can enter moderation."
      />
      {q.error ? <div className="form-alert error">{q.error}</div> : null}
      {q.success ? <div className="form-alert success">{q.success}</div> : null}
      <SectionCard title="Moderation queue">
        {reviews.length ? (
          <div className="commerce-review-admin-list">
            {reviews.map((review) => (
              <article key={review.id}>
                <div>
                  <strong>
                    {"★".repeat(review.rating)} · {review.product.name}
                  </strong>
                  <span>
                    {review.user.name} · {review.order.code}
                  </span>
                  <h3>{review.title}</h3>
                  <p>{review.body}</p>
                </div>
                <form
                  action={`/api/admin/commerce/reviews/${review.id}`}
                  method="post"
                >
                  <select name="status" defaultValue={review.status}>
                    <option>PENDING</option>
                    <option>PUBLISHED</option>
                    <option>REJECTED</option>
                  </select>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Save
                  </button>
                </form>
                <StatusBadge
                  tone={
                    review.status === "PUBLISHED"
                      ? "success"
                      : review.status === "REJECTED"
                        ? "danger"
                        : "warning"
                  }
                >
                  {review.status}
                </StatusBadge>
              </article>
            ))}
          </div>
        ) : (
          <p>No reviews.</p>
        )}
      </SectionCard>
    </div>
  );
}
