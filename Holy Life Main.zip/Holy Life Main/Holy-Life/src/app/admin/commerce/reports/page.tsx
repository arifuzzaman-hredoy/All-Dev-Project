import { MetricCard, PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { commerceSummary } from "@/lib/commerce/queries";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  await requirePermission(
    "commerce.reports.commerce-report.view",
    "/admin/commerce/reports",
  );
  const [summary, topProducts, movements] = await Promise.all([
    commerceSummary(),
    db.commerceOrderItem.groupBy({
      by: ["productId", "productName"],
      _sum: { quantity: true, lineTotal: true },
      orderBy: { _sum: { lineTotal: "desc" } },
      take: 10,
    }),
    db.stockMovement.findMany({
      include: { variant: { include: { product: true } } },
      orderBy: { createdAt: "desc" },
      take: 20,
    }),
  ]);
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Commerce analytics"
        title="Sales & inventory reports"
        description="Reports use order snapshots and the stock movement ledger."
      />
      <div className="metric-grid">
        <MetricCard
          icon="reports"
          label="Tracked revenue"
          value={formatMoney(summary.revenue)}
          helper="Operational orders"
          tone="success"
        />
        <MetricCard
          icon="cart"
          label="Orders"
          value={String(summary.totalOrders)}
          helper="All time"
          tone="commerce"
        />
        <MetricCard
          icon="inventory"
          label="Low stock"
          value={String(summary.lowStock)}
          helper="Active variants"
          tone="warning"
        />
      </div>
      <div className="two-column-grid">
        <SectionCard title="Top products">
          <ol className="commerce-ranked-list">
            {topProducts.map((item) => (
              <li key={item.productId}>
                <strong>{item.productName}</strong>
                <span>
                  {item._sum.quantity ?? 0} sold ·{" "}
                  {formatMoney((item._sum.lineTotal ?? 0).toString())}
                </span>
              </li>
            ))}
          </ol>
        </SectionCard>
        <SectionCard title="Recent stock movement">
          <div className="settings-list">
            {movements.map((movement) => (
              <div key={movement.id}>
                <span>
                  <strong>
                    {movement.variant.product.name} · {movement.variant.sku}
                  </strong>
                  <small>
                    {movement.type} {movement.quantity > 0 ? "+" : ""}
                    {movement.quantity} · balance {movement.balanceAfter}
                  </small>
                </span>
                <time>{movement.createdAt.toLocaleDateString("en-BD")}</time>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
