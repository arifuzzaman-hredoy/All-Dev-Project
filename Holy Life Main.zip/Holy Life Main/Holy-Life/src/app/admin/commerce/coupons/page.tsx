import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.catalog.coupon.manage",
    "/admin/commerce/coupons",
  );
  const q = await searchParams;
  const coupons = await db.coupon.findMany({
    include: { _count: { select: { redemptions: true } } },
    orderBy: { createdAt: "desc" },
  });
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Promotion"
        title="Coupons & discounts"
        description="Usage limits and per-user limits are enforced inside checkout."
      />
      {q.error ? <div className="form-alert error">{q.error}</div> : null}
      {q.success ? <div className="form-alert success">{q.success}</div> : null}
      <div className="two-column-grid">
        <SectionCard title="Create coupon">
          <form
            action="/api/admin/commerce/coupons"
            className="panel-form"
            method="post"
          >
            <div className="form-grid two">
              <label>
                Code
                <input name="code" required />
              </label>
              <label>
                Name
                <input name="name" required />
              </label>
              <label>
                Type
                <select name="type">
                  <option>FIXED</option>
                  <option>PERCENTAGE</option>
                </select>
              </label>
              <label>
                Value
                <input
                  min="0"
                  name="value"
                  step="0.01"
                  type="number"
                  required
                />
              </label>
              <label>
                Minimum subtotal
                <input
                  min="0"
                  name="minimumSubtotal"
                  step="0.01"
                  type="number"
                />
              </label>
              <label>
                Maximum discount
                <input
                  min="0"
                  name="maximumDiscount"
                  step="0.01"
                  type="number"
                />
              </label>
              <label>
                Total usage limit
                <input min="1" name="usageLimit" type="number" />
              </label>
              <label>
                Per-user limit
                <input
                  min="1"
                  name="perUserLimit"
                  type="number"
                  defaultValue="1"
                />
              </label>
            </div>
            <button className="ui-button ui-button-primary" type="submit">
              Create coupon
            </button>
          </form>
        </SectionCard>
        <SectionCard title="Coupons">
          <div className="settings-list">
            {coupons.map((coupon) => (
              <div key={coupon.id}>
                <span>
                  <strong>
                    {coupon.code} · {coupon.name}
                  </strong>
                  <small>
                    {coupon.type === "FIXED"
                      ? formatMoney(coupon.value.toString())
                      : `${coupon.value.toString()}%`}{" "}
                    · {coupon._count.redemptions} use(s)
                  </small>
                </span>
                <StatusBadge tone={coupon.isActive ? "success" : "neutral"}>
                  {coupon.isActive ? "Active" : "Inactive"}
                </StatusBadge>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
