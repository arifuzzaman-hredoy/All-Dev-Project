import { AdminOrderList } from "@/components/commerce/admin-order-list";
import { requirePermission } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.orders.order.view",
    "/admin/commerce/orders/pending",
  );
  const q = await searchParams;
  return <AdminOrderList mode="pending" error={q.error} success={q.success} />;
}
