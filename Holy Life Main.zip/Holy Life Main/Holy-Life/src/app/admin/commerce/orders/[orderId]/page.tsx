import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { hasPermission } from "@/lib/auth/session";
import { formatMoney } from "@/lib/commerce/money";
import { orderStatusLabel } from "@/lib/commerce/status";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{ orderId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const session = await requirePermission(
    "commerce.orders.order.view",
    "/admin/commerce/orders",
  );
  const canViewFinance = hasPermission(
    session.user,
    "system.finance.payment.view",
  );
  const { orderId } = await params;
  const q = await searchParams;
  const order = await db.commerceOrder.findUnique({
    where: { id: orderId },
    include: {
      items: true,
      statusHistory: { orderBy: { createdAt: "asc" } },
      refundRequests: {
        include: { user: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
      },
    },
  });
  if (!order) notFound();
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Order operations"
        title={order.code}
        description={`${order.customerName} · ${order.customerPhone}`}
        actions={
          <Link
            className="ui-button ui-button-secondary"
            href="/admin/commerce/orders"
          >
            Back
          </Link>
        }
      />
      {q.error ? <div className="form-alert error">{q.error}</div> : null}
      {q.success ? <div className="form-alert success">{q.success}</div> : null}
      <div className="commerce-order-detail-grid">
        <SectionCard title="Order items">
          <div className="commerce-order-items">
            {order.items.map((item) => (
              <article key={item.id}>
                <div>
                  <strong>{item.productName}</strong>
                  <span>
                    {item.variantName} · {item.sku}
                  </span>
                </div>
                <span>
                  {item.quantity} × {formatMoney(item.unitPrice.toString())}
                </span>
                <strong>{formatMoney(item.lineTotal.toString())}</strong>
              </article>
            ))}
          </div>
        </SectionCard>
        <aside className="commerce-order-summary">
          <h2>Operations</h2>
          <StatusBadge
            tone={
              order.status === "DELIVERED"
                ? "success"
                : order.status === "CANCELLED"
                  ? "danger"
                  : "warning"
            }
          >
            {orderStatusLabel(order.status)}
          </StatusBadge>
          <div>
            <span>Payment</span>
            <strong>{order.paymentStatus.replaceAll("_", " ")}</strong>
          </div>
          <div>
            <span>Total</span>
            <strong>{formatMoney(order.grandTotal.toString())}</strong>
          </div>
          <form
            action={`/api/admin/commerce/orders/${order.id}/status`}
            method="post"
          >
            <label>
              Next status
              <select name="status" defaultValue={order.status}>
                <option>PENDING</option>
                <option>CONFIRMED</option>
                <option>PROCESSING</option>
                <option>SHIPPED</option>
                <option>DELIVERED</option>
                <option>CANCELLED</option>
              </select>
            </label>
            <input name="note" placeholder="Operational note" />
            <button className="ui-button ui-button-primary" type="submit">
              Update status
            </button>
          </form>
          <div className="admin-form-stack">
            <p className="muted-copy">
              Payment changes are recorded in the auditable manual finance
              ledger.
            </p>
            {canViewFinance ? (
              <Link
                className="ui-button ui-button-secondary"
                href={`/admin/finance/payments?search=${encodeURIComponent(order.code)}`}
              >
                Open finance ledger
              </Link>
            ) : (
              <p className="muted-copy">
                A Finance Manager or another admin with finance-view permission
                must record the payment.
              </p>
            )}
          </div>
        </aside>
      </div>
      <div className="two-column-grid">
        <SectionCard title="Delivery">
          <div className="commerce-address-card">
            <strong>{order.customerName}</strong>
            <span>{order.customerPhone}</span>
            <pre>{JSON.stringify(order.shippingAddress, null, 2)}</pre>
            <p>{order.customerNote}</p>
          </div>
        </SectionCard>
        <SectionCard title="Timeline">
          <ol className="commerce-timeline">
            {order.statusHistory.map((event) => (
              <li key={event.id}>
                <strong>{orderStatusLabel(event.toStatus)}</strong>
                <span>{event.createdAt.toLocaleString("en-BD")}</span>
                <p>{event.note}</p>
              </li>
            ))}
          </ol>
        </SectionCard>
      </div>
      {order.refundRequests.length ? (
        <SectionCard title="Refund requests">
          {order.refundRequests.map((refund) => (
            <form
              action={`/api/admin/commerce/refunds/${refund.id}`}
              className="commerce-refund-row"
              method="post"
              key={refund.id}
            >
              <div>
                <strong>
                  {refund.user.name} · {formatMoney(refund.amount.toString())}
                </strong>
                <p>{refund.reason}</p>
              </div>
              <select name="status" defaultValue={refund.status}>
                <option>REQUESTED</option>
                <option>APPROVED</option>
                <option>REJECTED</option>
                <option>COMPLETED</option>
              </select>
              <input name="resolutionNote" placeholder="Resolution note" />
              <button className="ui-button ui-button-secondary" type="submit">
                Resolve
              </button>
            </form>
          ))}
        </SectionCard>
      ) : null}
    </div>
  );
}
