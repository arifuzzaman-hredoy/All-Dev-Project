import Link from "next/link";
import {
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  await requirePermission(
    "commerce.orders.refund.approve",
    "/admin/commerce/orders/returns",
  );
  const refunds = await db.refundRequest.findMany({
    include: {
      order: true,
      user: { select: { name: true, email: true, phone: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Returns"
        title="Refund requests"
        description="Refund cannot exceed the captured order amount."
      />
      <TabBar
        items={[
          { label: "All orders", href: "/admin/commerce/orders" },
          { label: "Pending", href: "/admin/commerce/orders/pending" },
          {
            label: "Returns & refunds",
            href: "/admin/commerce/orders/returns",
            active: true,
          },
        ]}
      />
      <SectionCard title="Requests">
        {refunds.length ? (
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {refunds.map((refund) => (
                  <tr key={refund.id}>
                    <td>
                      <strong>{refund.order.code}</strong>
                      <span>{refund.createdAt.toLocaleString("en-BD")}</span>
                    </td>
                    <td>{refund.user.name}</td>
                    <td>{formatMoney(refund.amount.toString())}</td>
                    <td>
                      <StatusBadge
                        tone={
                          refund.status === "COMPLETED"
                            ? "success"
                            : refund.status === "REJECTED"
                              ? "danger"
                              : "warning"
                        }
                      >
                        {refund.status}
                      </StatusBadge>
                    </td>
                    <td>
                      <Link href={`/admin/commerce/orders/${refund.orderId}`}>
                        Open order
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p>No refund requests.</p>
        )}
      </SectionCard>
    </div>
  );
}
