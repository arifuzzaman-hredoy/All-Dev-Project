import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requirePermission } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  await requirePermission(
    "commerce.shipping.shipping.manage",
    "/admin/commerce/settings",
  );
  const query = await searchParams;
  const methods = await db.shippingMethod.findMany({
    orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
  });

  return (
    <div className="admin-page">
      <PageHeader
        eyebrow="Commerce settings"
        title="Shipping methods"
        description="ডেলিভারি পদ্ধতি, মূল্য এবং বাংলা/English public label permission অনুযায়ী পরিচালনা করুন।"
      />
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}
      <div className="two-column-grid">
        <SectionCard title="নতুন Shipping method">
          <form
            action="/api/admin/commerce/shipping"
            className="panel-form"
            method="post"
          >
            <div className="panel-form-grid">
              <label>
                Code
                <input maxLength={50} name="code" required />
              </label>
              <label>
                Display order
                <input
                  defaultValue={0}
                  min={0}
                  max={100000}
                  name="displayOrder"
                  type="number"
                />
              </label>
              <label>
                নাম (English)
                <input maxLength={120} name="name" required />
              </label>
              <label>
                নাম (বাংলা)
                <input maxLength={120} name="nameBn" />
              </label>
              <label>
                Fee
                <input min="0" name="fee" step="0.01" type="number" required />
              </label>
              <label>
                Free above
                <input min="0" name="freeAbove" step="0.01" type="number" />
              </label>
              <label>
                Estimated time (English)
                <input
                  maxLength={100}
                  name="estimatedDays"
                  placeholder="2-3 business days"
                />
              </label>
              <label>
                আনুমানিক সময় (বাংলা)
                <input
                  maxLength={100}
                  name="estimatedDaysBn"
                  placeholder="২–৩ কার্যদিবস"
                />
              </label>
              <label className="form-span-2">
                Description (English)
                <textarea maxLength={500} name="description" rows={3} />
              </label>
              <label className="form-span-2">
                বর্ণনা (বাংলা)
                <textarea maxLength={500} name="descriptionBn" rows={3} />
              </label>
            </div>
            <label className="form-checkbox">
              <input
                defaultChecked
                name="isActive"
                type="checkbox"
                value="true"
              />
              <span>Active রাখুন</span>
            </label>
            <button className="ui-button ui-button-primary" type="submit">
              Shipping method তৈরি করুন
            </button>
          </form>
        </SectionCard>

        <SectionCard
          title="বর্তমান Shipping methods"
          description={`${methods.length}টি configured method`}
        >
          <div className="managed-record-list">
            {methods.map((method) => (
              <details className="managed-record" key={method.id}>
                <summary>
                  <span>
                    <strong>
                      {method.nameBn || method.name} ·{" "}
                      {formatMoney(method.fee.toString())}
                    </strong>
                    <small>
                      {method.code} ·{" "}
                      {method.estimatedDaysBn ||
                        method.estimatedDays ||
                        "সময় নির্ধারিত নয়"}
                    </small>
                  </span>
                  <StatusBadge tone={method.isActive ? "success" : "neutral"}>
                    {method.isActive ? "ACTIVE" : "INACTIVE"}
                  </StatusBadge>
                </summary>
                <form
                  action={`/api/admin/commerce/shipping/${method.id}`}
                  className="panel-form managed-record-form"
                  method="post"
                >
                  <div className="panel-form-grid">
                    <label>
                      Code
                      <input
                        defaultValue={method.code}
                        maxLength={50}
                        name="code"
                        required
                      />
                    </label>
                    <label>
                      Display order
                      <input
                        defaultValue={method.displayOrder}
                        min={0}
                        max={100000}
                        name="displayOrder"
                        type="number"
                      />
                    </label>
                    <label>
                      নাম (English)
                      <input
                        defaultValue={method.name}
                        maxLength={120}
                        name="name"
                        required
                      />
                    </label>
                    <label>
                      নাম (বাংলা)
                      <input
                        defaultValue={method.nameBn ?? ""}
                        maxLength={120}
                        name="nameBn"
                      />
                    </label>
                    <label>
                      Fee
                      <input
                        defaultValue={method.fee.toString()}
                        min="0"
                        name="fee"
                        step="0.01"
                        type="number"
                        required
                      />
                    </label>
                    <label>
                      Free above
                      <input
                        defaultValue={method.freeAbove?.toString() ?? ""}
                        min="0"
                        name="freeAbove"
                        step="0.01"
                        type="number"
                      />
                    </label>
                    <label>
                      Estimated time (English)
                      <input
                        defaultValue={method.estimatedDays ?? ""}
                        maxLength={100}
                        name="estimatedDays"
                      />
                    </label>
                    <label>
                      আনুমানিক সময় (বাংলা)
                      <input
                        defaultValue={method.estimatedDaysBn ?? ""}
                        maxLength={100}
                        name="estimatedDaysBn"
                      />
                    </label>
                    <label className="form-span-2">
                      Description (English)
                      <textarea
                        defaultValue={method.description ?? ""}
                        maxLength={500}
                        name="description"
                        rows={3}
                      />
                    </label>
                    <label className="form-span-2">
                      বর্ণনা (বাংলা)
                      <textarea
                        defaultValue={method.descriptionBn ?? ""}
                        maxLength={500}
                        name="descriptionBn"
                        rows={3}
                      />
                    </label>
                  </div>
                  <label className="form-checkbox">
                    <input
                      defaultChecked={method.isActive}
                      name="isActive"
                      type="checkbox"
                      value="true"
                    />
                    <span>Active</span>
                  </label>
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    আপডেট করুন
                  </button>
                </form>
              </details>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
