import Link from "next/link";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { getUserGatewayAttemptByCode } from "@/lib/payments/gateway/queries";

export const dynamic = "force-dynamic";

function tone(
  status: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "SUCCEEDED") return "success";
  if (status === "FAILED" || status === "EXPIRED") return "danger";
  if (status === "REVIEW_REQUIRED" || status === "VALIDATING") return "warning";
  if (status === "SESSION_CREATED") return "info";
  return "neutral";
}

export default async function GatewayResultPage({
  searchParams,
}: {
  searchParams: Promise<{ attempt?: string; return?: string }>;
}) {
  const session = await requireAuthenticatedSession("/payment/gateway/result");
  const query = await searchParams;
  const attempt = query.attempt
    ? await getUserGatewayAttemptByCode(session.user.id, query.attempt)
    : null;

  return (
    <div className="dashboard-page">
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Payments", href: "/dashboard/payments" },
          { label: "Gateway result" },
        ]}
        eyebrow="Online payment"
        title="Payment result"
        description="The finance ledger is updated only after server-to-server gateway validation succeeds."
      />
      <SectionCard title={attempt ? attempt.code : "Payment status"}>
        {query.return === "failed" || query.return === "cancelled" ? (
          <div className="notice-box notice-warning">
            <strong>Gateway return received</strong>
            <p>
              The browser returned as {query.return}. Final payment state still
              comes from signed provider evidence and server-side
              reconciliation.
            </p>
          </div>
        ) : null}
        {attempt ? (
          <div className="content-stack">
            <div>
              <StatusBadge tone={tone(attempt.status)}>
                {attempt.status.replaceAll("_", " ")}
              </StatusBadge>
            </div>
            <div className="finance-balance-grid">
              <div>
                <span>Reference</span>
                <strong>{attempt.account.referenceCode}</strong>
              </div>
              <div>
                <span>Amount</span>
                <strong>{formatMoney(attempt.amount, attempt.currency)}</strong>
              </div>
              <div>
                <span>Finance receipt</span>
                <strong>
                  {attempt.transaction?.code ?? "Not credited yet"}
                </strong>
              </div>
            </div>
            {attempt.status === "REVIEW_REQUIRED" ? (
              <p>
                Your payment reached the gateway but requires finance review. Do
                not pay again unless finance rejects this attempt.
              </p>
            ) : null}
            {attempt.status === "SUCCEEDED" ? (
              <p>
                Your payment has been independently validated and credited to
                the finance ledger.
              </p>
            ) : null}
            {attempt.status === "FAILED" ||
            attempt.status === "CANCELLED" ||
            attempt.status === "EXPIRED" ? (
              <p>
                This attempt did not credit your account. You can start a new
                payment from Payments.
              </p>
            ) : null}
          </div>
        ) : (
          <p>
            We could not identify a payment attempt from this return. Check
            Payments for the latest status before trying again.
          </p>
        )}
        <div className="page-actions">
          <Link
            className="ui-button ui-button-primary"
            href="/dashboard/payments"
          >
            Open payments
          </Link>
        </div>
      </SectionCard>
    </div>
  );
}
