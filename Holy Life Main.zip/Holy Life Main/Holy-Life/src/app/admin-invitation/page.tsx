import { AuthRedirectForm } from "@/components/auth/auth-redirect-form";
import {
  AuthAlert,
  AuthShell,
  PasswordRequirements,
} from "@/components/auth/auth-shell";
import { PasswordInput } from "@/components/auth/password-input";
import { hashOpaqueToken } from "@/lib/auth/crypto";
import { db } from "@/lib/db";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function AdminInvitationPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string; error?: string; success?: string }>;
}) {
  const params = await searchParams;
  const { locale } = await getUiPreferences();
  const token = params.token ?? "";
  const invitation = token
    ? await db.adminInvitation.findUnique({
        where: { tokenHash: hashOpaqueToken(token) },
        include: { roles: { include: { role: true } } },
      })
    : null;
  const valid = Boolean(
    invitation &&
    !invitation.consumedAt &&
    !invitation.revokedAt &&
    invitation.expiresAt > new Date(),
  );

  return (
    <AuthShell
      description={uiText(locale, "auth.invitationDescription")}
      eyebrow={uiText(locale, "auth.adminInvitation")}
      title={
        valid
          ? `${locale === "bn" ? "স্বাগতম" : "Welcome"}, ${invitation?.name}`
          : uiText(locale, "auth.invitationUnavailable")
      }
    >
      {params.error ? <AuthAlert type="error">{params.error}</AuthAlert> : null}
      {params.success ? (
        <AuthAlert type="success">{params.success}</AuthAlert>
      ) : null}
      {!valid ? (
        <AuthAlert type="error">
          {uiText(locale, "auth.invitationInvalid")}
        </AuthAlert>
      ) : (
        <AuthRedirectForm
          action="/api/admin-invitation/accept"
          className="auth-form"
        >
          <input name="token" type="hidden" value={token} />
          <div className="auth-alert auth-alert-info">
            <strong>{invitation?.email}</strong>
            <br />
            {uiText(locale, "auth.roles")}:{" "}
            {invitation?.roles
              .map(({ role, dataScope }) => `${role.name} (${dataScope})`)
              .join(", ")}
          </div>
          <PasswordInput
            autoComplete="new-password"
            label={uiText(locale, "auth.newPassword")}
            name="password"
          />
          <PasswordInput
            autoComplete="new-password"
            label={uiText(locale, "auth.confirmNewPassword")}
            name="confirmPassword"
          />
          <PasswordRequirements />
          <button
            className="ui-button ui-button-primary auth-submit"
            type="submit"
          >
            {uiText(locale, "auth.acceptInvitation")}
          </button>
        </AuthRedirectForm>
      )}
    </AuthShell>
  );
}
