import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthRedirectForm } from "@/components/auth/auth-redirect-form";
import {
  AuthAlert,
  AuthShell,
  PasswordRequirements,
} from "@/components/auth/auth-shell";
import { PasswordInput } from "@/components/auth/password-input";
import { getCurrentSession } from "@/lib/auth/session";
import { safeReturnTo } from "@/lib/auth/request";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; returnTo?: string }>;
}) {
  const [params, preferences] = await Promise.all([
    searchParams,
    getUiPreferences(),
  ]);
  const returnTo = safeReturnTo(params.returnTo ?? null);
  const session = await getCurrentSession();
  const { locale } = preferences;
  if (session) redirect("/dashboard");

  return (
    <AuthShell
      eyebrow={uiText(locale, "auth.createAccountEyebrow")}
      title={uiText(locale, "auth.joinHolyLife")}
      description={uiText(locale, "auth.registerDescription")}
      footer={
        <p>
          {uiText(locale, "auth.alreadyRegistered")}{" "}
          <Link href={`/login?returnTo=${encodeURIComponent(returnTo)}`}>
            {uiText(locale, "public.signIn")}
          </Link>
        </p>
      }
    >
      {params.error ? <AuthAlert type="error">{params.error}</AuthAlert> : null}
      <AuthRedirectForm action="/api/auth/register" className="auth-form">
        <input name="returnTo" type="hidden" value={returnTo} />
        <label className="auth-field">
          <span>{uiText(locale, "auth.fullName")}</span>
          <input
            autoComplete="name"
            maxLength={100}
            minLength={2}
            name="name"
            placeholder={uiText(locale, "auth.yourFullName")}
            required
          />
        </label>
        <div className="auth-field-grid">
          <label className="auth-field">
            <span>{uiText(locale, "auth.emailAddress")}</span>
            <input
              autoComplete="email"
              maxLength={254}
              name="email"
              placeholder="name@example.com"
              type="email"
            />
          </label>
          <label className="auth-field">
            <span>{uiText(locale, "auth.mobileNumber")}</span>
            <input
              autoComplete="tel"
              inputMode="tel"
              maxLength={14}
              name="phone"
              placeholder="01XXXXXXXXX"
            />
          </label>
        </div>
        <p className="auth-field-help">{uiText(locale, "auth.contactHelp")}</p>
        <div className="auth-field-grid">
          <PasswordInput
            autoComplete="new-password"
            label={uiText(locale, "auth.password")}
            name="password"
          />
          <PasswordInput
            autoComplete="new-password"
            label={uiText(locale, "auth.confirmPassword")}
            name="confirmPassword"
          />
        </div>
        <PasswordRequirements />
        <button className="public-primary-button auth-submit" type="submit">
          {uiText(locale, "public.createAccount")}
        </button>
      </AuthRedirectForm>
    </AuthShell>
  );
}
