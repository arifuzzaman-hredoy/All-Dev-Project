import { ModulePage } from "@/components/ui/module-page";
import {
  breadcrumbsFromSegments,
  pageTitleFromSegments,
} from "@/lib/panel-page";

const dashboardTabs: Record<string, Array<{ label: string; href: string }>> = {
  healthcare: [
    { label: "Appointments", href: "/dashboard/healthcare/appointments" },
    { label: "Prescriptions", href: "/dashboard/healthcare/prescriptions" },
    { label: "Health records", href: "/dashboard/healthcare/records" },
    { label: "Wellness programs", href: "/dashboard/healthcare/programs" },
  ],
  learning: [
    { label: "My courses", href: "/dashboard/learning/courses" },
    { label: "Resources", href: "/dashboard/learning/resources" },
    { label: "Certificates", href: "/dashboard/learning/certificates" },
  ],
  shopping: [
    { label: "My orders", href: "/dashboard/shopping/orders" },
    { label: "Payments", href: "/dashboard/shopping/payments" },
    { label: "Refunds", href: "/dashboard/shopping/refunds" },
  ],
};

export default async function DashboardModulePage({
  params,
}: {
  params: Promise<{ segments: string[] }>;
}) {
  const { segments } = await params;
  const activePath = `/dashboard/${segments.join("/")}`;
  const department = segments[0] ?? "account";
  const title = pageTitleFromSegments(segments);
  const tabs = dashboardTabs[department] ?? [
    { label: title, href: activePath },
  ];

  return (
    <ModulePage
      activePath={activePath}
      actionHref={
        department === "healthcare"
          ? "/appointment"
          : department === "learning"
            ? "/courses"
            : department === "shopping"
              ? "/shop"
              : `${activePath}/edit`
      }
      actionLabel={
        department === "healthcare"
          ? "Book appointment"
          : department === "learning"
            ? "Browse courses"
            : department === "shopping"
              ? "Open shop"
              : "Update details"
      }
      baseHref={`/dashboard/${department}`}
      breadcrumbs={breadcrumbsFromSegments("Dashboard", "/dashboard", segments)}
      description={`Manage your ${title.toLowerCase()} from the unified Holy Life account.`}
      emptyDescription="No records are available in this section yet. When activity is added, it will appear here automatically according to your account access."
      emptyTitle={`No ${title.toLowerCase()} to show yet`}
      tabs={tabs}
      title={title}
    />
  );
}
