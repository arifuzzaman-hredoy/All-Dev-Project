import {
  EmptyState,
  PageHeader,
  SectionCard,
  TabBar,
} from "@/components/ui/panel-ui";
import { NotificationList } from "@/components/dashboard/notification-list";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { listDashboardNotifications } from "@/lib/dashboard/queries";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function NotificationsPage({
  searchParams,
}: {
  searchParams: Promise<{ view?: string; success?: string; error?: string }>;
}) {
  const query = await searchParams;
  const session = await requireAuthenticatedSession("/dashboard/notifications");
  const mode = query.view === "unread" ? "unread" : "all";
  const [notifications, unread, messagingPreference] = await Promise.all([
    listDashboardNotifications(session.user.id, mode),
    listDashboardNotifications(session.user.id, "unread"),
    db.messagingPreference.findUnique({ where: { userId: session.user.id } }),
  ]);

  return (
    <div className="dashboard-page">
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Notifications" },
        ]}
        eyebrow="Account updates"
        title="Notification center"
        description="Appointment, order, learning, certificate, and account updates in one place."
        actions={
          unread.length ? (
            <form action="/api/dashboard/notifications/read-all" method="post">
              <button className="ui-button ui-button-secondary" type="submit">
                Mark all read
              </button>
            </form>
          ) : undefined
        }
      />
      <TabBar
        items={[
          {
            label: "All",
            href: "/dashboard/notifications",
            active: mode === "all",
          },
          {
            label: "Unread",
            href: "/dashboard/notifications?view=unread",
            active: mode === "unread",
            count: String(unread.length),
          },
        ]}
      />
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}

      <SectionCard
        title="External messaging preferences"
        description="Service messages use verified contact details. Marketing delivery always requires explicit opt-in."
      >
        <form
          action="/api/dashboard/notifications/preferences"
          className="admin-form-stack"
          method="post"
        >
          <label className="form-field">
            <span>
              <input
                defaultChecked={messagingPreference?.emailEnabled ?? true}
                name="emailEnabled"
                type="checkbox"
              />{" "}
              Email service messages
            </span>
          </label>
          <label className="form-field">
            <span>
              <input
                defaultChecked={messagingPreference?.smsEnabled ?? true}
                name="smsEnabled"
                type="checkbox"
              />{" "}
              SMS service messages
            </span>
          </label>
          <label className="form-field">
            <span>
              <input
                defaultChecked={messagingPreference?.whatsappEnabled ?? false}
                name="whatsappEnabled"
                type="checkbox"
              />{" "}
              WhatsApp service messages
            </span>
          </label>
          <label className="form-field">
            <span>
              <input
                defaultChecked={messagingPreference?.marketingEnabled ?? false}
                name="marketingEnabled"
                type="checkbox"
              />{" "}
              Allow marketing messages on enabled channels
            </span>
          </label>
          <button className="ui-button ui-button-secondary" type="submit">
            Save messaging preferences
          </button>
        </form>
      </SectionCard>
      <SectionCard
        title={mode === "unread" ? "Unread notifications" : "All notifications"}
        description={`${notifications.length} update${notifications.length === 1 ? "" : "s"} in this view.`}
      >
        {notifications.length ? (
          <NotificationList notifications={notifications} />
        ) : (
          <EmptyState
            icon="bell"
            title="No notifications here"
            description="New account and department updates will appear automatically."
          />
        )}
      </SectionCard>
    </div>
  );
}
