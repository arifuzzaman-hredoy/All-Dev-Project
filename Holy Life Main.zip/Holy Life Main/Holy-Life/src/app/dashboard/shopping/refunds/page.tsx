import Link from "next/link";
import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  const session = await requireAuthenticatedSession(
    "/dashboard/shopping/refunds",
  );
  const refunds = await db.refundRequest.findMany({
    where: { userId: session.user.id },
    include: { order: true },
    orderBy: { createdAt: "desc" },
  });
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Shopping"
        title="Refund requests"
        description="Track submitted refund decisions and completion."
        actions={
          <Link
            className="ui-button ui-button-secondary"
            href="/dashboard/shopping/orders"
          >
            Orders
          </Link>
        }
      />
      <SectionCard title="Requests">
        {refunds.length ? (
          <div className="commerce-order-list">
            {refunds.map((refund) => (
              <Link
                className="commerce-order-row"
                href={`/dashboard/shopping/orders/detail?code=${encodeURIComponent(refund.order.code)}`}
                key={refund.id}
              >
                <div>
                  <strong>{refund.order.code}</strong>
                  <span>{refund.reason}</span>
                </div>
                <StatusBadge
                  tone={
                    refund.status === "COMPLETED"
                      ? "success"
                      : refund.status === "REJECTED"
                        ? "danger"
                        : "warning"
                  }
                >
                  {refund.status}
                </StatusBadge>
                <strong>{formatMoney(refund.amount.toString())}</strong>
              </Link>
            ))}
          </div>
        ) : (
          <EmptyState
            icon="package"
            title="No refund requests"
            description="Eligible delivered orders can be submitted from order details."
          />
        )}
      </SectionCard>
    </div>
  );
}
