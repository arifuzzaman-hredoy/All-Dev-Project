import Link from "next/link";
import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  const session = await requireAuthenticatedSession(
    "/dashboard/shopping/payments",
  );
  const orders = await db.commerceOrder.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Shopping"
        title="Payments"
        description="COD and manual-payment verification status for your orders."
        actions={
          <Link
            className="ui-button ui-button-secondary"
            href="/dashboard/shopping/orders"
          >
            Orders
          </Link>
        }
      />
      <SectionCard title="Payment records">
        {orders.length ? (
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Method</th>
                  <th>Reference</th>
                  <th>Status</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id}>
                    <td>
                      <Link
                        href={`/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`}
                      >
                        {order.code}
                      </Link>
                    </td>
                    <td>{order.paymentMethod.replaceAll("_", " ")}</td>
                    <td>{order.manualPaymentReference || "—"}</td>
                    <td>
                      <StatusBadge
                        tone={
                          order.paymentStatus === "PAID" ? "success" : "warning"
                        }
                      >
                        {order.paymentStatus}
                      </StatusBadge>
                    </td>
                    <td>{formatMoney(order.grandTotal.toString())}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="cart"
            title="No payment records"
            description="Payment status appears after your first order."
          />
        )}
      </SectionCard>
    </div>
  );
}
