import { CustomerOrderList } from "@/components/commerce/order-list";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const session = await requireAuthenticatedSession(
    "/dashboard/shopping/orders",
  );
  const q = await searchParams;
  return (
    <CustomerOrderList
      userId={session.user.id}
      mode="all"
      error={q.error}
      success={q.success}
    />
  );
}
