import { notFound } from "next/navigation";
import { CustomerOrderList } from "@/components/commerce/order-list";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{ view: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const { view } = await params;
  if (view !== "active" && view !== "history") notFound();
  const session = await requireAuthenticatedSession(
    `/dashboard/shopping/orders/${view}`,
  );
  const q = await searchParams;
  return (
    <CustomerOrderList
      userId={session.user.id}
      mode={view}
      error={q.error}
      success={q.success}
    />
  );
}
