import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { getCustomerOrder } from "@/lib/commerce/queries";
import { canCustomerCancel, orderStatusLabel } from "@/lib/commerce/status";
export const dynamic = "force-dynamic";
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ code?: string; error?: string; success?: string }>;
}) {
  const session = await requireAuthenticatedSession(
    "/dashboard/shopping/orders/detail",
  );
  const q = await searchParams;
  const order = q.code ? await getCustomerOrder(session.user.id, q.code) : null;
  if (!order) notFound();
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Order detail"
        title={order.code}
        description={`${order.createdAt.toLocaleString("en-BD")} · ${order.paymentMethod.replaceAll("_", " ")}`}
        actions={
          <Link
            className="ui-button ui-button-secondary"
            href="/dashboard/shopping/orders"
          >
            Back
          </Link>
        }
      />
      {q.error ? <div className="form-alert error">{q.error}</div> : null}
      {q.success ? <div className="form-alert success">{q.success}</div> : null}
      <div className="commerce-order-detail-grid">
        <SectionCard title="Items">
          <div className="commerce-order-items">
            {order.items.map((item) => (
              <article key={item.id}>
                <div>
                  <strong>{item.productName}</strong>
                  <span>
                    {item.variantName} · {item.sku}
                  </span>
                </div>
                <span>
                  {item.quantity} × {formatMoney(item.unitPrice.toString())}
                </span>
                <strong>{formatMoney(item.lineTotal.toString())}</strong>
                {order.status === "DELIVERED" ? (
                  <form
                    action="/api/dashboard/shopping/reviews"
                    method="post"
                    className="commerce-inline-review"
                  >
                    <input name="orderId" type="hidden" value={order.id} />
                    <input
                      name="productId"
                      type="hidden"
                      value={item.productId}
                    />
                    <select name="rating" defaultValue="5">
                      <option value="5">5 stars</option>
                      <option value="4">4 stars</option>
                      <option value="3">3 stars</option>
                      <option value="2">2 stars</option>
                      <option value="1">1 star</option>
                    </select>
                    <input name="title" placeholder="Review title" />
                    <button className="ui-button ui-button-quiet" type="submit">
                      Review
                    </button>
                  </form>
                ) : null}
              </article>
            ))}
          </div>
        </SectionCard>
        <aside className="commerce-order-summary">
          <h2>Order status</h2>
          <StatusBadge
            tone={
              order.status === "DELIVERED"
                ? "success"
                : order.status === "CANCELLED"
                  ? "danger"
                  : "warning"
            }
          >
            {orderStatusLabel(order.status)}
          </StatusBadge>
          <div>
            <span>Subtotal</span>
            <strong>{formatMoney(order.subtotal.toString())}</strong>
          </div>
          <div>
            <span>Discount</span>
            <strong>-{formatMoney(order.discountTotal.toString())}</strong>
          </div>
          <div>
            <span>Shipping</span>
            <strong>{formatMoney(order.shippingTotal.toString())}</strong>
          </div>
          <div>
            <span>Total</span>
            <strong>{formatMoney(order.grandTotal.toString())}</strong>
          </div>
          {canCustomerCancel(order.status) ? (
            <form
              action={`/api/dashboard/shopping/orders/${order.id}/cancel`}
              method="post"
            >
              <input name="reason" placeholder="Cancellation reason" />
              <button className="ui-button ui-button-secondary" type="submit">
                Cancel order
              </button>
            </form>
          ) : null}
          {order.status === "DELIVERED" &&
          !order.refundRequests.some((r) =>
            ["REQUESTED", "APPROVED"].includes(r.status),
          ) ? (
            <form
              action={`/api/dashboard/shopping/orders/${order.id}/refund`}
              method="post"
            >
              <textarea
                name="reason"
                required
                placeholder="Reason for refund"
              />
              <button className="ui-button ui-button-secondary" type="submit">
                Request refund
              </button>
            </form>
          ) : null}
        </aside>
      </div>
      <SectionCard title="Timeline">
        <ol className="commerce-timeline">
          {order.statusHistory.map((event) => (
            <li key={event.id}>
              <strong>{orderStatusLabel(event.toStatus)}</strong>
              <span>{event.createdAt.toLocaleString("en-BD")}</span>
              <p>{event.note}</p>
            </li>
          ))}
        </ol>
      </SectionCard>
    </div>
  );
}
