import {
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

const formatter = new Intl.DateTimeFormat("en-BD", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Dhaka",
});

export default async function SecurityPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const params = await searchParams;
  const current = await requireAuthenticatedSession(
    "/dashboard/profile/security",
  );
  const sessions = await db.session.findMany({
    where: {
      userId: current.user.id,
      revokedAt: null,
      expiresAt: { gt: new Date() },
    },
    orderBy: { lastSeenAt: "desc" },
    select: {
      id: true,
      deviceLabel: true,
      ipAddress: true,
      lastSeenAt: true,
      createdAt: true,
      expiresAt: true,
    },
  });
  const recentEvents = await db.auditLog.findMany({
    where: {
      actorId: current.user.id,
      action: {
        in: ["LOGIN", "LOGOUT", "VERIFY", "PASSWORD_CHANGE", "SESSION_REVOKE"],
      },
    },
    orderBy: { createdAt: "desc" },
    take: 8,
    select: { id: true, action: true, createdAt: true, ipAddress: true },
  });

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Profile", href: "/dashboard/profile" },
          { label: "Security & sessions" },
        ]}
        description="See where your account is signed in and revoke any session you do not recognize."
        eyebrow="Account security"
        title="Security & sessions"
      />
      <TabBar
        items={[
          { label: "Profile", href: "/dashboard/profile" },
          {
            label: "Security & sessions",
            href: "/dashboard/profile/security",
            active: true,
            count: String(sessions.length),
          },
        ]}
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      {params.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {params.success}
        </div>
      ) : null}
      <div className="content-stack">
        <SectionCard
          title="Active sessions"
          description={`A maximum of ${process.env.MAX_ACTIVE_SESSIONS ?? "8"} active sessions is allowed per account.`}
        >
          <div className="session-list">
            {sessions.map((item) => {
              const isCurrent = item.id === current.id;
              return (
                <article className="session-item" key={item.id}>
                  <div className="session-device-icon">
                    {(item.deviceLabel ?? "U").charAt(0)}
                  </div>
                  <div className="session-copy">
                    <div>
                      <strong>{item.deviceLabel ?? "Unknown device"}</strong>
                      {isCurrent ? (
                        <StatusBadge tone="success">Current</StatusBadge>
                      ) : null}
                    </div>
                    <span>
                      Last active {formatter.format(item.lastSeenAt)} · IP{" "}
                      {item.ipAddress ?? "Unavailable"}
                    </span>
                    <small>
                      Signed in {formatter.format(item.createdAt)} · Expires{" "}
                      {formatter.format(item.expiresAt)}
                    </small>
                  </div>
                  <form
                    action={`/api/auth/sessions/${item.id}/revoke`}
                    method="post"
                  >
                    <button
                      className="ui-button ui-button-secondary"
                      type="submit"
                    >
                      {isCurrent ? "Sign out" : "Revoke"}
                    </button>
                  </form>
                </article>
              );
            })}
          </div>
        </SectionCard>
        <SectionCard
          title="Recent security activity"
          description="Basic audit history for your own authentication events."
        >
          <div className="security-event-list">
            {recentEvents.length ? (
              recentEvents.map((event) => (
                <div key={event.id}>
                  <span>
                    <strong>{event.action.replaceAll("_", " ")}</strong>
                    <small>{event.ipAddress ?? "IP unavailable"}</small>
                  </span>
                  <time dateTime={event.createdAt.toISOString()}>
                    {formatter.format(event.createdAt)}
                  </time>
                </div>
              ))
            ) : (
              <p className="muted-copy">No security events recorded yet.</p>
            )}
          </div>
        </SectionCard>
      </div>
    </>
  );
}
