import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { addressBook } from "@/lib/dashboard/queries";

export const dynamic = "force-dynamic";

function AddressFields({
  address,
}: {
  address?: {
    label: string;
    recipientName: string;
    phone: string;
    addressLine1: string;
    addressLine2: string | null;
    area: string | null;
    city: string;
    district: string | null;
    postalCode: string | null;
    isDefault: boolean;
  };
}) {
  return (
    <>
      <label>
        Label
        <input
          defaultValue={address?.label ?? "Home"}
          maxLength={40}
          name="label"
          required
        />
      </label>
      <label>
        Recipient name
        <input
          defaultValue={address?.recipientName ?? ""}
          maxLength={120}
          name="recipientName"
          required
        />
      </label>
      <label>
        Phone
        <input
          defaultValue={address?.phone ?? ""}
          inputMode="tel"
          maxLength={30}
          name="phone"
          required
        />
      </label>
      <label>
        Address line 1
        <input
          defaultValue={address?.addressLine1 ?? ""}
          maxLength={250}
          name="addressLine1"
          required
        />
      </label>
      <label>
        Address line 2
        <input
          defaultValue={address?.addressLine2 ?? ""}
          maxLength={250}
          name="addressLine2"
        />
      </label>
      <div className="form-grid form-grid-two unified-address-subgrid">
        <label>
          Area
          <input
            defaultValue={address?.area ?? ""}
            maxLength={100}
            name="area"
          />
        </label>
        <label>
          City / upazila
          <input
            defaultValue={address?.city ?? ""}
            maxLength={100}
            name="city"
            required
          />
        </label>
        <label>
          District
          <input
            defaultValue={address?.district ?? ""}
            maxLength={100}
            name="district"
          />
        </label>
        <label>
          Postal code
          <input
            defaultValue={address?.postalCode ?? ""}
            maxLength={20}
            name="postalCode"
          />
        </label>
      </div>
      <label className="checkbox-row">
        <input
          defaultChecked={address?.isDefault ?? false}
          name="isDefault"
          type="checkbox"
        />
        Make this the default address
      </label>
    </>
  );
}

export default async function AddressBookPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const query = await searchParams;
  const session = await requireAuthenticatedSession(
    "/dashboard/profile/addresses",
  );
  const addresses = await addressBook(session.user.id);

  return (
    <div className="dashboard-page">
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Profile", href: "/dashboard/profile" },
          { label: "Address book" },
        ]}
        eyebrow="Account"
        title="Address book"
        description="Manage reusable delivery addresses for faster checkout."
      />
      <TabBar
        items={[
          { label: "Profile", href: "/dashboard/profile" },
          {
            label: "Address book",
            href: "/dashboard/profile/addresses",
            active: true,
            count: String(addresses.length),
          },
          {
            label: "Security & sessions",
            href: "/dashboard/profile/security",
          },
        ]}
      />
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}

      <div className="content-grid content-grid-main unified-address-layout">
        <SectionCard
          title="Saved addresses"
          description={`${addresses.length} address${addresses.length === 1 ? "" : "es"} saved.`}
        >
          {addresses.length ? (
            <div className="unified-address-list">
              {addresses.map((address) => (
                <article key={address.id}>
                  <div className="unified-address-summary">
                    <span className="content-kicker">{address.label}</span>
                    <h3>{address.recipientName}</h3>
                    <p>{address.phone}</p>
                    <address>
                      {address.addressLine1}
                      {address.addressLine2 ? `, ${address.addressLine2}` : ""}
                      {address.area ? `, ${address.area}` : ""}, {address.city}
                      {address.district ? `, ${address.district}` : ""}
                      {address.postalCode ? ` ${address.postalCode}` : ""}
                    </address>
                  </div>
                  <div className="unified-address-actions">
                    {address.isDefault ? (
                      <StatusBadge tone="success">Default</StatusBadge>
                    ) : (
                      <form
                        action={`/api/dashboard/addresses/${address.id}/default`}
                        method="post"
                      >
                        <button
                          className="ui-button ui-button-secondary"
                          type="submit"
                        >
                          Set default
                        </button>
                      </form>
                    )}
                    <details className="unified-address-edit">
                      <summary className="ui-button ui-button-quiet">
                        Edit
                      </summary>
                      <form
                        action={`/api/dashboard/addresses/${address.id}`}
                        className="unified-address-form"
                        method="post"
                      >
                        <AddressFields address={address} />
                        <button
                          className="ui-button ui-button-primary"
                          type="submit"
                        >
                          Update address
                        </button>
                      </form>
                    </details>
                    <form
                      action={`/api/dashboard/addresses/${address.id}/delete`}
                      method="post"
                    >
                      <button
                        className="ui-button ui-button-quiet"
                        type="submit"
                      >
                        Delete
                      </button>
                    </form>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              icon="home"
              title="No saved addresses"
              description="Add a delivery address using the form."
            />
          )}
        </SectionCard>

        <SectionCard
          title="Add address"
          description="This address can be selected during future checkout."
        >
          <form
            action="/api/dashboard/addresses"
            className="unified-address-form"
            method="post"
          >
            <AddressFields
              address={{
                label: "Home",
                recipientName: session.user.name,
                phone: session.user.phone ?? "",
                addressLine1: "",
                addressLine2: null,
                area: null,
                city: "",
                district: null,
                postalCode: null,
                isDefault: addresses.length === 0,
              }}
            />
            <button className="ui-button ui-button-primary" type="submit">
              Save address
            </button>
          </form>
        </SectionCard>
      </div>
    </div>
  );
}
