import {
  ButtonLink,
  PageHeader,
  ProgressBar,
  SectionCard,
  StatusBadge,
  TabBar,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { dashboardProfile } from "@/lib/dashboard/queries";
import { profileCompletion } from "@/lib/dashboard/status";

export const dynamic = "force-dynamic";

export default async function ProfilePage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const query = await searchParams;
  const session = await requireAuthenticatedSession("/dashboard/profile");
  const profile = await dashboardProfile(session.user.id);
  if (!profile) return null;

  const completion = profileCompletion({
    name: profile.name,
    email: profile.email,
    phone: profile.phone ?? profile.patientProfile?.phone,
    bloodGroup: profile.patientProfile?.bloodGroup,
    dateOfBirth: profile.patientProfile?.dateOfBirth,
    emergencyContactPhone: profile.patientProfile?.emergencyContactPhone,
    address: profile.patientProfile?.address,
  });

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Profile" },
        ]}
        description="Maintain one reusable identity for healthcare, shopping, and learning workflows."
        eyebrow="Account"
        title="Profile & health details"
        actions={
          <ButtonLink href="/dashboard/profile/security" icon="shield">
            Security sessions
          </ButtonLink>
        }
      />
      <TabBar
        items={[
          { label: "Profile", href: "/dashboard/profile", active: true },
          { label: "Address book", href: "/dashboard/profile/addresses" },
          { label: "Security & sessions", href: "/dashboard/profile/security" },
        ]}
      />
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}

      <div className="content-grid content-grid-main profile-grid unified-profile-grid">
        <div className="content-stack">
          <SectionCard
            title="Account identity"
            description="Email and phone changes continue to use the verified authentication workflow."
          >
            <dl className="account-detail-list">
              <div>
                <dt>Full name</dt>
                <dd>{profile.name}</dd>
              </div>
              <div>
                <dt>Email</dt>
                <dd>
                  {profile.email ?? "Not added"}{" "}
                  {profile.email ? (
                    <StatusBadge
                      tone={profile.emailVerifiedAt ? "success" : "warning"}
                    >
                      {profile.emailVerifiedAt ? "Verified" : "Not verified"}
                    </StatusBadge>
                  ) : null}
                  {profile.email && !profile.emailVerifiedAt ? (
                    <ButtonLink
                      href="/verify?channel=email&returnTo=/dashboard/profile"
                      variant="quiet"
                    >
                      Verify
                    </ButtonLink>
                  ) : null}
                </dd>
              </div>
              <div>
                <dt>Account phone</dt>
                <dd>
                  {profile.phone ?? "Not added"}{" "}
                  {profile.phone ? (
                    <StatusBadge
                      tone={profile.phoneVerifiedAt ? "success" : "warning"}
                    >
                      {profile.phoneVerifiedAt ? "Verified" : "Not verified"}
                    </StatusBadge>
                  ) : null}
                  {profile.phone && !profile.phoneVerifiedAt ? (
                    <ButtonLink
                      href="/verify?channel=phone&returnTo=/dashboard/profile"
                      variant="quiet"
                    >
                      Verify
                    </ButtonLink>
                  ) : null}
                </dd>
              </div>
              <div>
                <dt>Account status</dt>
                <dd>
                  <StatusBadge tone="success">{profile.status}</StatusBadge>
                </dd>
              </div>
            </dl>
          </SectionCard>

          <SectionCard
            title="Reusable profile"
            description="These details prefill healthcare and support workflows."
          >
            <form
              action="/api/dashboard/profile"
              className="unified-profile-form"
              method="post"
            >
              <div className="form-grid form-grid-two">
                <label>
                  Full name
                  <input
                    defaultValue={profile.name}
                    maxLength={120}
                    name="name"
                    required
                  />
                </label>
                <label>
                  Patient phone
                  <input
                    defaultValue={
                      profile.patientProfile?.phone ?? profile.phone ?? ""
                    }
                    inputMode="tel"
                    maxLength={30}
                    name="patientPhone"
                    required
                  />
                </label>
                <label>
                  Gender
                  <select
                    defaultValue={profile.patientProfile?.gender ?? ""}
                    name="gender"
                  >
                    <option value="">Prefer not to add</option>
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                    <option value="PREFER_NOT_TO_SAY">Prefer not to say</option>
                  </select>
                </label>
                <label>
                  Date of birth
                  <input
                    defaultValue={
                      profile.patientProfile?.dateOfBirth
                        ?.toISOString()
                        .slice(0, 10) ?? ""
                    }
                    name="dateOfBirth"
                    type="date"
                  />
                </label>
                <label>
                  Blood group
                  <input
                    defaultValue={profile.patientProfile?.bloodGroup ?? ""}
                    maxLength={10}
                    name="bloodGroup"
                    placeholder="Example: B+"
                  />
                </label>
                <label>
                  Emergency contact name
                  <input
                    defaultValue={
                      profile.patientProfile?.emergencyContactName ?? ""
                    }
                    maxLength={120}
                    name="emergencyContactName"
                  />
                </label>
                <label>
                  Emergency contact phone
                  <input
                    defaultValue={
                      profile.patientProfile?.emergencyContactPhone ?? ""
                    }
                    inputMode="tel"
                    maxLength={30}
                    name="emergencyContactPhone"
                  />
                </label>
              </div>
              <label>
                Primary address
                <textarea
                  defaultValue={profile.patientProfile?.address ?? ""}
                  maxLength={500}
                  name="address"
                  rows={3}
                />
              </label>
              <label>
                Allergies or important notes
                <textarea
                  defaultValue={profile.patientProfile?.allergies ?? ""}
                  maxLength={1000}
                  name="allergies"
                  rows={3}
                />
              </label>
              <button className="ui-button ui-button-primary" type="submit">
                Save profile
              </button>
            </form>
          </SectionCard>
        </div>

        <div className="content-stack">
          <SectionCard
            title="Profile readiness"
            description="Completion is calculated from reusable account and health fields."
          >
            <ProgressBar label="Profile completion" value={completion} />
            <p className="muted-copy">
              A complete profile reduces repeated data entry for appointments
              and delivery addresses.
            </p>
          </SectionCard>
          <SectionCard
            title="Access scope"
            description="Your current account roles."
          >
            <div className="role-chip-list">
              {profile.isSuperAdmin ? <span>Super Admin</span> : null}
              {session.user.roles.map((role) => (
                <span key={role.code}>{role.name}</span>
              ))}
            </div>
            <div className="notice-box account-notice-box">
              <strong>One account, separated data</strong>
              <p>
                Your healthcare, course, and shopping information share the same
                identity but remain grouped by department.
              </p>
            </div>
          </SectionCard>
          <SectionCard
            title="Address book"
            description="Save multiple delivery addresses and choose one default."
          >
            <ButtonLink
              href="/dashboard/profile/addresses"
              icon="home"
              variant="secondary"
            >
              Manage addresses
            </ButtonLink>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
