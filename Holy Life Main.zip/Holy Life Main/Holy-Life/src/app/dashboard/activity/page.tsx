import { DashboardActivityList } from "@/components/dashboard/activity-list";
import { EmptyState, PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { listDashboardActivity } from "@/lib/dashboard/queries";

export const dynamic = "force-dynamic";

export default async function ActivityPage() {
  const session = await requireAuthenticatedSession("/dashboard/activity");
  const activity = await listDashboardActivity(session.user.id, 50);

  return (
    <div className="dashboard-page">
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Activity" },
        ]}
        eyebrow="Unified history"
        title="Account activity"
        description="A date-ordered view of healthcare, shopping, learning, and certificate activity."
      />
      <SectionCard
        title="Recent activity"
        description={`${activity.length} recent record${activity.length === 1 ? "" : "s"}.`}
      >
        {activity.length ? (
          <DashboardActivityList items={activity} />
        ) : (
          <EmptyState
            icon="activity"
            title="No activity yet"
            description="Appointments, orders, and course activity will be listed here."
          />
        )}
      </SectionCard>
    </div>
  );
}
