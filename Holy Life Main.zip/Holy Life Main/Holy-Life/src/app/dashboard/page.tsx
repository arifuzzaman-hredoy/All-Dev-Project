import Link from "next/link";
import {
  ButtonLink,
  EmptyState,
  MetricCard,
  PageHeader,
  ProgressBar,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatDisplayDate, formatDisplayTime } from "@/lib/appointments/time";
import { formatMoney } from "@/lib/commerce/money";
import { dashboardOverview } from "@/lib/dashboard/queries";
import {
  dashboardStatusTone,
  greetingForHour,
  titleCaseStatus,
} from "@/lib/dashboard/status";

export const dynamic = "force-dynamic";

const dhakaHourFormatter = new Intl.DateTimeFormat("en-US", {
  hour: "2-digit",
  hour12: false,
  timeZone: "Asia/Dhaka",
});

const dhakaDateFormatter = new Intl.DateTimeFormat("en-BD", {
  weekday: "long",
  day: "2-digit",
  month: "long",
  year: "numeric",
  timeZone: "Asia/Dhaka",
});

export default async function DashboardPage() {
  const session = await requireAuthenticatedSession("/dashboard");
  const summary = await dashboardOverview(session.user.id);
  const firstName = session.user.name.split(" ")[0] ?? session.user.name;
  const hour = Number(dhakaHourFormatter.format(new Date()).slice(0, 2));
  const firstLesson = summary.activeEnrollment?.course.modules.flatMap(
    (module) => module.lessons,
  )[0];

  return (
    <>
      <PageHeader
        breadcrumbs={[{ label: "Dashboard" }]}
        description="Healthcare, shopping, learning, payments, and account activity in one live workspace."
        eyebrow={dhakaDateFormatter.format(new Date())}
        title={`${greetingForHour(hour)}, ${firstName}`}
        actions={
          <ButtonLink href="/appointment" icon="calendar">
            Book appointment
          </ButtonLink>
        }
      />

      <section
        className="metric-grid metric-grid-four"
        aria-label="Dashboard summary"
      >
        <MetricCard
          label="Upcoming appointments"
          value={String(summary.upcomingAppointments)}
          helper={
            summary.nextAppointment
              ? `${formatDisplayDate(summary.nextAppointment.appointmentDate)} · ${formatDisplayTime(summary.nextAppointment.startTime)}`
              : "Nothing scheduled"
          }
          icon="appointment"
          tone="health"
        />
        <MetricCard
          label="Active courses"
          value={String(summary.activeEnrollmentCount)}
          helper={
            summary.activeEnrollment
              ? `${summary.activeEnrollment.progressPercent}% latest progress`
              : "Browse the academy"
          }
          icon="learning"
          tone="learning"
        />
        <MetricCard
          label="Active orders"
          value={String(summary.activeOrderCount)}
          helper={
            summary.recentOrders[0]
              ? titleCaseStatus(summary.recentOrders[0].status)
              : "No current orders"
          }
          icon="package"
          tone="commerce"
        />
        <MetricCard
          label="Unread notifications"
          value={String(summary.unreadNotifications)}
          helper={`${summary.savedCount} saved item${summary.savedCount === 1 ? "" : "s"}`}
          icon="bell"
          tone="neutral"
        />
      </section>

      <div className="content-grid content-grid-main unified-dashboard-grid">
        <div className="content-stack">
          <SectionCard
            title="Upcoming healthcare"
            description="Your next consultations and recent appointment history."
            action={
              <ButtonLink
                href="/dashboard/healthcare/appointments"
                variant="quiet"
              >
                All appointments
              </ButtonLink>
            }
          >
            {summary.recentAppointments.length ? (
              <div className="compact-list">
                {summary.recentAppointments.map((appointment) => (
                  <Link
                    className="compact-list-item unified-list-link"
                    href={`/dashboard/healthcare/appointments/${appointment.id}`}
                    key={appointment.id}
                  >
                    <div className="list-avatar list-avatar-health">
                      {appointment.doctor.name
                        .split(" ")
                        .slice(1, 3)
                        .map((part) => part[0])
                        .join("") || "DR"}
                    </div>
                    <div className="compact-list-copy">
                      <strong>{appointment.doctor.name}</strong>
                      <span>
                        {appointment.code} · {appointment.serviceType}
                      </span>
                    </div>
                    <div className="compact-list-meta">
                      <strong>
                        {formatDisplayDate(appointment.appointmentDate)}
                      </strong>
                      <span>{formatDisplayTime(appointment.startTime)}</span>
                      <StatusBadge
                        tone={dashboardStatusTone(appointment.status)}
                      >
                        {titleCaseStatus(appointment.status)}
                      </StatusBadge>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState
                icon="appointment"
                title="No appointments yet"
                description="Book a verified doctor consultation and manage it from this dashboard."
                action={
                  <ButtonLink href="/appointment">Browse doctors</ButtonLink>
                }
              />
            )}
          </SectionCard>

          <SectionCard
            title="Continue learning"
            description="Resume your most recently active course."
            action={
              <ButtonLink href="/dashboard/learning/courses" variant="quiet">
                My courses
              </ButtonLink>
            }
          >
            {summary.activeEnrollment ? (
              <div className="course-progress-card">
                <div className="course-progress-art" aria-hidden="true">
                  HL
                </div>
                <div className="course-progress-copy">
                  <span className="content-kicker">
                    {summary.activeEnrollment.course.category.name}
                  </span>
                  <h3>{summary.activeEnrollment.course.title}</h3>
                  <p>
                    {summary.activeEnrollment.course.instructor?.name ??
                      "Holy Life Academy"}
                  </p>
                  <ProgressBar
                    label="Course completion"
                    value={summary.activeEnrollment.progressPercent}
                  />
                  <div className="unified-inline-actions">
                    {firstLesson ? (
                      <ButtonLink
                        href={`/courses/${summary.activeEnrollment.course.slug}/learn/${firstLesson.id}`}
                      >
                        Continue learning
                      </ButtonLink>
                    ) : null}
                    <ButtonLink href="/courses" variant="secondary">
                      Browse courses
                    </ButtonLink>
                  </div>
                </div>
              </div>
            ) : (
              <EmptyState
                icon="learning"
                title="No active course"
                description="Enroll in a Holy Life course to begin tracking lessons and certificates."
                action={<ButtonLink href="/courses">Browse courses</ButtonLink>}
              />
            )}
          </SectionCard>

          <SectionCard
            title="Recent orders"
            description="Latest product, payment, and delivery activity."
            action={
              <ButtonLink href="/dashboard/shopping/orders" variant="quiet">
                All orders
              </ButtonLink>
            }
          >
            {summary.recentOrders.length ? (
              <div className="simple-table-wrap">
                <table className="simple-table">
                  <thead>
                    <tr>
                      <th>Order</th>
                      <th>Status</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {summary.recentOrders.map((order) => (
                      <tr key={order.id}>
                        <td>
                          <Link
                            href={`/dashboard/shopping/orders/detail?code=${encodeURIComponent(order.code)}`}
                          >
                            <strong>
                              {order.items[0]?.productName ?? order.code}
                            </strong>
                            <span>
                              {order.code} · {order._count.items} item(s)
                            </span>
                          </Link>
                        </td>
                        <td>
                          <StatusBadge tone={dashboardStatusTone(order.status)}>
                            {titleCaseStatus(order.status)}
                          </StatusBadge>
                        </td>
                        <td>
                          <strong>
                            {formatMoney(
                              order.grandTotal.toString(),
                              order.currency,
                            )}
                          </strong>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState
                icon="cart"
                title="No orders yet"
                description="Products you order from the Holy Life shop will appear here."
                action={<ButtonLink href="/shop">Open shop</ButtonLink>}
              />
            )}
          </SectionCard>
        </div>

        <div className="content-stack">
          <SectionCard
            title="Quick actions"
            description="Move directly to your most common tasks."
          >
            <div className="quick-action-grid unified-quick-actions">
              <ButtonLink
                href="/appointment"
                icon="appointment"
                variant="secondary"
              >
                New appointment
              </ButtonLink>
              <ButtonLink href="/courses" icon="book" variant="secondary">
                Browse courses
              </ButtonLink>
              <ButtonLink href="/shop" icon="shop" variant="secondary">
                Open shop
              </ButtonLink>
              <ButtonLink
                href="/dashboard/payments"
                icon="file"
                variant="secondary"
              >
                Payments
              </ButtonLink>
              <ButtonLink
                href="/dashboard/saved"
                icon="heart"
                variant="secondary"
              >
                Saved items
              </ButtonLink>
              <ButtonLink
                href="/dashboard/activity"
                icon="activity"
                variant="secondary"
              >
                Activity
              </ButtonLink>
            </div>
          </SectionCard>

          <SectionCard
            title="Notifications"
            description={`${summary.unreadNotifications} unread update${summary.unreadNotifications === 1 ? "" : "s"}.`}
            action={
              <ButtonLink href="/dashboard/notifications" variant="quiet">
                Notification center
              </ButtonLink>
            }
          >
            {summary.notifications.length ? (
              <div className="unified-overview-notifications">
                {summary.notifications.map((notification) => (
                  <Link
                    className={notification.isRead ? "is-read" : "is-unread"}
                    href={notification.href ?? "/dashboard/notifications"}
                    key={notification.id}
                  >
                    <span>
                      <strong>{notification.title}</strong>
                      {notification.message ? (
                        <small>{notification.message}</small>
                      ) : null}
                    </span>
                    {!notification.isRead ? (
                      <span
                        className="unified-unread-dot"
                        aria-label="Unread"
                      />
                    ) : null}
                  </Link>
                ))}
              </div>
            ) : (
              <p className="muted-copy">No account notifications yet.</p>
            )}
          </SectionCard>

          <SectionCard
            title="Profile readiness"
            description="Complete your identity once and reuse it across every department."
          >
            <div className="unified-profile-progress">
              <ProgressBar
                label="Profile completion"
                value={summary.profileCompletion}
              />
              <p>
                {summary.profileCompletion === 100
                  ? "Your profile is ready for healthcare and checkout workflows."
                  : "Add health details, emergency contact, and an address for faster future actions."}
              </p>
              <div className="unified-inline-actions">
                <ButtonLink href="/dashboard/profile" variant="secondary">
                  Update profile
                </ButtonLink>
                <ButtonLink href="/dashboard/profile/addresses" variant="quiet">
                  Address book
                </ButtonLink>
              </div>
            </div>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
