import { randomUUID } from "node:crypto";
import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatMoney } from "@/lib/commerce/money";
import { listUserPaymentAccounts } from "@/lib/finance/queries";
import { paymentStatusLabel } from "@/lib/finance/status";
import { paymentGatewayAvailable } from "@/lib/payments/gateway/config";

export const dynamic = "force-dynamic";

const dateFormatter = new Intl.DateTimeFormat("en-BD", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Dhaka",
});

function tone(
  status: string,
): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "PAID" || status === "VERIFIED") return "success";
  if (status === "FAILED" || status === "REJECTED") return "danger";
  if (
    status === "PARTIAL" ||
    status === "PENDING_VERIFICATION" ||
    status === "PENDING"
  )
    return "warning";
  if (status === "REFUNDED") return "info";
  return "neutral";
}

export default async function UnifiedPaymentsPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const session = await requireAuthenticatedSession("/dashboard/payments");
  const query = await searchParams;
  const accounts = await listUserPaymentAccounts(session.user.id);
  const onlineGatewayAvailable = paymentGatewayAvailable();
  const onlineIdentityReady = Boolean(
    session.user.email &&
    session.user.emailVerifiedAt &&
    session.user.phone &&
    session.user.phoneVerifiedAt,
  );

  return (
    <div className="dashboard-page">
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Payments" },
        ]}
        eyebrow="Unified finance"
        title="Payments & receipts"
        description={
          onlineGatewayAvailable
            ? "Pay online through SSLCOMMERZ or submit a manual payment for finance verification."
            : "Manual finance remains available. Online gateway payments are currently disabled."
        }
      />

      {query.success ? (
        <div className="notice-box notice-success">
          <strong>Success</strong>
          <p>{query.success}</p>
        </div>
      ) : null}
      {query.error ? (
        <div className="notice-box notice-danger">
          <strong>Action required</strong>
          <p>{query.error}</p>
        </div>
      ) : null}

      {accounts.length ? (
        <div className="content-stack">
          {accounts.map((account) => (
            <SectionCard
              key={account.id}
              title={`${paymentStatusLabel(account.domain)} · ${account.referenceCode}`}
              description={account.description}
              action={
                <StatusBadge tone={tone(account.balance.status)}>
                  {paymentStatusLabel(account.balance.status)}
                </StatusBadge>
              }
            >
              <div className="finance-balance-grid">
                <div>
                  <span>Due</span>
                  <strong>
                    {formatMoney(account.balance.amountDue, account.currency)}
                  </strong>
                </div>
                <div>
                  <span>Verified paid</span>
                  <strong>
                    {formatMoney(account.balance.netPaid, account.currency)}
                  </strong>
                </div>
                <div>
                  <span>Outstanding</span>
                  <strong>
                    {formatMoney(account.balance.outstanding, account.currency)}
                  </strong>
                </div>
              </div>

              {onlineGatewayAvailable &&
              onlineIdentityReady &&
              account.balance.outstanding >= 10 &&
              account.currency === "BDT" &&
              account.balance.status !== "REFUNDED" ? (
                <form
                  action="/api/payments/gateway/sslcommerz/initiate"
                  className="finance-payment-form"
                  method="post"
                >
                  <input name="accountId" type="hidden" value={account.id} />
                  <input
                    name="requestKey"
                    type="hidden"
                    value={`dashboard:${account.id}:${randomUUID()}`}
                  />
                  <label className="form-field">
                    <span>Online amount</span>
                    <input
                      defaultValue={account.balance.outstanding.toFixed(2)}
                      max={account.balance.outstanding.toFixed(2)}
                      min="10.00"
                      name="amount"
                      required
                      step="0.01"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Billing address</span>
                    <input maxLength={120} name="addressLine1" required />
                  </label>
                  <label className="form-field">
                    <span>City</span>
                    <input maxLength={80} name="city" required />
                  </label>
                  <label className="form-field">
                    <span>District</span>
                    <input maxLength={80} name="district" />
                  </label>
                  <label className="form-field">
                    <span>Postal code</span>
                    <input maxLength={30} name="postalCode" />
                  </label>
                  <button className="ui-button ui-button-primary" type="submit">
                    Pay online with SSLCOMMERZ
                  </button>
                </form>
              ) : null}

              {onlineGatewayAvailable &&
              !onlineIdentityReady &&
              account.balance.outstanding > 0 ? (
                <p className="muted-copy">
                  Online payment requires both a verified email address and a
                  verified phone number.
                </p>
              ) : null}

              {account.balance.outstanding > 0 &&
              account.balance.status !== "REFUNDED" ? (
                <form
                  action="/api/dashboard/payments/submit"
                  className="finance-payment-form"
                  method="post"
                >
                  <input name="accountId" type="hidden" value={account.id} />
                  <label className="form-field">
                    <span>Amount</span>
                    <input
                      max={account.balance.outstanding.toFixed(2)}
                      min="0.01"
                      name="amount"
                      required
                      step="0.01"
                      type="number"
                    />
                  </label>
                  <label className="form-field">
                    <span>Method</span>
                    <select defaultValue="BKASH" name="method">
                      <option value="CASH">Cash</option>
                      <option value="BKASH">bKash</option>
                      <option value="NAGAD">Nagad</option>
                      <option value="ROCKET">Rocket</option>
                      <option value="BANK_TRANSFER">Bank transfer</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </label>
                  <label className="form-field">
                    <span>Transaction/reference number</span>
                    <input
                      maxLength={160}
                      name="transactionReference"
                      placeholder="Optional for cash"
                    />
                  </label>
                  <label className="form-field">
                    <span>Note</span>
                    <input
                      maxLength={500}
                      name="note"
                      placeholder="Optional note"
                    />
                  </label>
                  <button className="ui-button ui-button-primary" type="submit">
                    Submit for verification
                  </button>
                </form>
              ) : null}

              {account.transactions.length ? (
                <div className="data-table-wrap">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Receipt</th>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Method</th>
                        <th>Status</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {account.transactions.map((transaction) => (
                        <tr key={transaction.id}>
                          <td>
                            <strong>{transaction.code}</strong>
                            <span>
                              {transaction.transactionReference ??
                                "No external reference"}
                            </span>
                          </td>
                          <td>{dateFormatter.format(transaction.createdAt)}</td>
                          <td>{paymentStatusLabel(transaction.type)}</td>
                          <td>
                            {transaction.method
                              ? paymentStatusLabel(transaction.method)
                              : transaction.gatewayAttemptId
                                ? "Online gateway"
                                : "—"}
                          </td>
                          <td>
                            <StatusBadge tone={tone(transaction.status)}>
                              {paymentStatusLabel(transaction.status)}
                            </StatusBadge>
                          </td>
                          <td>
                            {formatMoney(transaction.amount, account.currency)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="muted-copy">
                  No verified finance transaction has been recorded yet.
                </p>
              )}
            </SectionCard>
          ))}
        </div>
      ) : (
        <SectionCard title="Payment accounts">
          <EmptyState
            icon="file"
            title="No payment account yet"
            description="Payment accounts appear after an appointment, order, or paid course enrollment."
          />
        </SectionCard>
      )}
    </div>
  );
}
