/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { listSavedDashboardItems } from "@/lib/dashboard/queries";
import { titleCaseStatus } from "@/lib/dashboard/status";

export const dynamic = "force-dynamic";

export default async function SavedItemsPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const query = await searchParams;
  const session = await requireAuthenticatedSession("/dashboard/saved");
  const items = await listSavedDashboardItems(session.user.id);

  return (
    <div className="dashboard-page">
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Saved items" },
        ]}
        eyebrow="Personal collection"
        title="Saved items"
        description="Keep doctors, products, and courses together for faster access later."
      />
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}
      <SectionCard
        title="Your saved collection"
        description={`${items.length} saved item${items.length === 1 ? "" : "s"}.`}
      >
        {items.length ? (
          <div className="unified-saved-grid">
            {items.map((item) => (
              <article key={item.id}>
                <Link className="unified-saved-media" href={item.href}>
                  {item.imageUrl ? (
                    <img alt="" src={item.imageUrl} />
                  ) : (
                    <span>HL</span>
                  )}
                </Link>
                <div className="unified-saved-copy">
                  <StatusBadge tone="info">
                    {titleCaseStatus(item.itemType)}
                  </StatusBadge>
                  <h2>
                    <Link href={item.href}>{item.title}</Link>
                  </h2>
                  <p>{item.description}</p>
                  <div className="unified-inline-actions">
                    <Link
                      className="ui-button ui-button-primary"
                      href={item.href}
                    >
                      Open
                    </Link>
                    <form action="/api/dashboard/saved/toggle" method="post">
                      <input
                        name="itemType"
                        type="hidden"
                        value={item.itemType}
                      />
                      <input
                        name="referenceId"
                        type="hidden"
                        value={item.referenceId}
                      />
                      <input
                        name="returnTo"
                        type="hidden"
                        value="/dashboard/saved"
                      />
                      <button
                        className="ui-button ui-button-secondary"
                        type="submit"
                      >
                        Remove
                      </button>
                    </form>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <EmptyState
            icon="heart"
            title="Nothing saved yet"
            description="Use Save for later on a doctor, product, or course page."
          />
        )}
      </SectionCard>
    </div>
  );
}
