import type { ReactNode } from "react";
import { PanelShell } from "@/components/layout/panel-shell";
import { dashboardNavigation } from "@/config/navigation";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import {
  dashboardNavigationWithUnread,
  dashboardUnreadCount,
} from "@/lib/dashboard/queries";
import { getUiPreferences } from "@/lib/i18n/server";
import { localizeRoleLabel } from "@/lib/i18n/navigation";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({
  children,
}: {
  children: ReactNode;
}) {
  const [session, preferences] = await Promise.all([
    requireAuthenticatedSession("/dashboard"),
    getUiPreferences(),
  ]);
  const roleName =
    session.user.roles.find((item) => item.code === "MEMBER")?.name ?? "Member";
  const role = localizeRoleLabel(preferences.locale, roleName);
  const unread = await dashboardUnreadCount(session.user.id);
  const navigation = dashboardNavigationWithUnread(dashboardNavigation, unread);

  return (
    <PanelShell
      locale={preferences.locale}
      navigation={navigation}
      subtitle={preferences.locale === "bn" ? "আমার Holy Life" : "My Holy Life"}
      surface="dashboard"
      themePreference={preferences.themePreference}
      title={
        preferences.locale === "bn" ? "সদস্য ড্যাশবোর্ড" : "User dashboard"
      }
      userName={session.user.name}
      userRole={role}
    >
      {children}
    </PanelShell>
  );
}
