import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { writeAuditLog } from "@/lib/auth/audit";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatDisplayDate } from "@/lib/appointments/time";
import {
  prescriptionStatusLabel,
  prescriptionStatusTone,
} from "@/lib/clinical/status";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function DashboardPrescriptionDetail({
  params,
}: {
  params: Promise<{ prescriptionId: string }>;
}) {
  const session = await requireAuthenticatedSession(
    "/dashboard/healthcare/prescriptions",
  );
  const { prescriptionId } = await params;
  const prescription = await db.prescription.findFirst({
    where: {
      id: prescriptionId,
      status: "SIGNED",
      patient: { userId: session.user.id },
    },
    include: {
      patient: true,
      doctor: true,
      appointment: true,
      items: { orderBy: { sortOrder: "asc" } },
      signedBy: { select: { name: true } },
      revisions: {
        where: { status: "SIGNED" },
        select: { id: true, code: true, version: true },
        orderBy: { version: "asc" },
      },
      supersedes: {
        select: { id: true, code: true, version: true, status: true },
      },
    },
  });
  if (!prescription) notFound();
  await writeAuditLog({
    actorId: session.user.id,
    action: "VIEW_SENSITIVE_DATA",
    department: "HEALTHCARE",
    targetType: "OwnPrescription",
    targetId: prescription.id,
    metadata: { version: prescription.version },
  });
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          {
            label: "Prescriptions",
            href: "/dashboard/healthcare/prescriptions",
          },
          { label: prescription.code },
        ]}
        description={`${prescription.doctor.name} · ${formatDisplayDate(prescription.appointment.appointmentDate)}`}
        eyebrow="Signed prescription"
        title={prescription.code}
        actions={
          <ButtonLink
            href={`/dashboard/healthcare/prescriptions/${prescription.id}/print`}
            icon="file"
          >
            Print / Save PDF
          </ButtonLink>
        }
      />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            action={
              <StatusBadge tone={prescriptionStatusTone(prescription.status)}>
                {prescriptionStatusLabel(prescription.status)}
              </StatusBadge>
            }
            title={`Prescription · Version ${prescription.version}`}
          >
            <div className="appointment-detail-copy">
              <div>
                <span>Diagnosis</span>
                <p>{prescription.diagnosis ?? "Not recorded"}</p>
              </div>
              <div>
                <span>Advice</span>
                <p>{prescription.advice ?? "Not recorded"}</p>
              </div>
              <div>
                <span>Follow-up</span>
                <p>
                  {prescription.followUpDate
                    ? formatDisplayDate(prescription.followUpDate)
                    : "As advised"}
                </p>
              </div>
            </div>
            <div className="data-table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Medicine</th>
                    <th>Dose</th>
                    <th>Frequency</th>
                    <th>Duration</th>
                    <th>Instructions</th>
                  </tr>
                </thead>
                <tbody>
                  {prescription.items.map((item) => (
                    <tr key={item.id}>
                      <td>
                        <strong>{item.medicineName}</strong>
                        <span>
                          {[item.genericName, item.strength]
                            .filter(Boolean)
                            .join(" · ")}
                        </span>
                      </td>
                      <td>
                        {item.dose}
                        {item.route ? <span>{item.route}</span> : null}
                      </td>
                      <td>{item.frequency}</td>
                      <td>
                        {item.duration}
                        {item.quantity ? (
                          <span>Qty {item.quantity}</span>
                        ) : null}
                      </td>
                      <td>{item.instructions ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </SectionCard>
        </div>
        <div className="content-stack">
          <SectionCard title="Visit">
            <div className="status-list">
              <div>
                <span>Patient</span>
                <strong>{prescription.patient.name}</strong>
              </div>
              <div>
                <span>Doctor</span>
                <strong>{prescription.doctor.name}</strong>
              </div>
              <div>
                <span>Appointment</span>
                <strong>{prescription.appointment.code}</strong>
              </div>
              <div>
                <span>Signed</span>
                <strong>
                  {prescription.signedAt
                    ? prescription.signedAt.toLocaleString("en-GB", {
                        timeZone: "Asia/Dhaka",
                      })
                    : "—"}
                </strong>
              </div>
              <div>
                <span>Signed by</span>
                <strong>
                  {prescription.signedBy?.name ?? prescription.doctor.name}
                </strong>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Version history">
            <div className="content-stack">
              {prescription.supersedes?.status === "SIGNED" ? (
                <Link
                  href={`/dashboard/healthcare/prescriptions/${prescription.supersedes.id}`}
                >
                  Previous version · {prescription.supersedes.code} v
                  {prescription.supersedes.version}
                </Link>
              ) : null}
              {prescription.revisions.map((revision) => (
                <Link
                  href={`/dashboard/healthcare/prescriptions/${revision.id}`}
                  key={revision.id}
                >
                  Revision · {revision.code} v{revision.version}
                </Link>
              ))}
              {!prescription.supersedes &&
              prescription.revisions.length === 0 ? (
                <p className="muted-copy">No signed revisions.</p>
              ) : null}
            </div>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
