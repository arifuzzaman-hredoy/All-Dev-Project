import { notFound } from "next/navigation";
import { writeAuditLog } from "@/lib/auth/audit";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatDisplayDate } from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function DashboardPrescriptionPrint({
  params,
}: {
  params: Promise<{ prescriptionId: string }>;
}) {
  const session = await requireAuthenticatedSession(
    "/dashboard/healthcare/prescriptions",
  );
  const { prescriptionId } = await params;
  const prescription = await db.prescription.findFirst({
    where: {
      id: prescriptionId,
      status: "SIGNED",
      patient: { userId: session.user.id },
    },
    include: {
      patient: true,
      doctor: { include: { department: true } },
      appointment: true,
      items: { orderBy: { sortOrder: "asc" } },
      signedBy: { select: { name: true } },
    },
  });
  if (!prescription) notFound();
  await writeAuditLog({
    actorId: session.user.id,
    action: "VIEW_SENSITIVE_DATA",
    department: "HEALTHCARE",
    targetType: "OwnPrescriptionPrint",
    targetId: prescription.id,
    metadata: { version: prescription.version },
  });
  return (
    <main className="appointment-print-page">
      <section className="appointment-print-sheet prescription-print-sheet">
        <header>
          <div>
            <span>HOLY LIFE</span>
            <h1>Prescription</h1>
            <p>Doctor-led Health, Fitness & Wellness · Rangpur</p>
          </div>
          <div>
            <strong>{prescription.code}</strong>
            <span>Version {prescription.version} · Signed</span>
          </div>
        </header>
        <div className="appointment-print-grid">
          <div>
            <span>Patient</span>
            <strong>{prescription.patient.name}</strong>
            <p>{prescription.patient.patientCode}</p>
            <p>{prescription.patient.phone}</p>
          </div>
          <div>
            <span>Doctor</span>
            <strong>{prescription.doctor.name}</strong>
            <p>{prescription.doctor.specialization}</p>
            <p>
              {prescription.doctor.qualifications ??
                prescription.doctor.department.name}
            </p>
          </div>
          <div>
            <span>Visit</span>
            <strong>
              {formatDisplayDate(prescription.appointment.appointmentDate)}
            </strong>
            <p>{prescription.appointment.code}</p>
          </div>
          <div>
            <span>Follow-up</span>
            <strong>
              {prescription.followUpDate
                ? formatDisplayDate(prescription.followUpDate)
                : "As advised"}
            </strong>
            <p>
              Signed{" "}
              {prescription.signedAt?.toLocaleString("en-GB", {
                timeZone: "Asia/Dhaka",
              }) ?? "—"}
            </p>
          </div>
        </div>
        <div className="appointment-print-note">
          <span>Diagnosis</span>
          <p>{prescription.diagnosis ?? "Not recorded"}</p>
        </div>
        <table className="prescription-print-table">
          <thead>
            <tr>
              <th>Medicine</th>
              <th>Dose & route</th>
              <th>Frequency</th>
              <th>Duration</th>
              <th>Instructions</th>
            </tr>
          </thead>
          <tbody>
            {prescription.items.map((item) => (
              <tr key={item.id}>
                <td>
                  <strong>{item.medicineName}</strong>
                  <small>
                    {[item.genericName, item.strength]
                      .filter(Boolean)
                      .join(" · ")}
                  </small>
                </td>
                <td>
                  {item.dose}
                  {item.route ? ` · ${item.route}` : ""}
                </td>
                <td>{item.frequency}</td>
                <td>
                  {item.duration}
                  {item.quantity ? ` · Qty ${item.quantity}` : ""}
                </td>
                <td>{item.instructions ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="appointment-print-note">
          <span>Advice</span>
          <p>{prescription.advice ?? "—"}</p>
        </div>
        <footer>
          <p>
            Signed in Holy Life by authenticated account:{" "}
            {prescription.signedBy?.name ?? prescription.doctor.name}.
          </p>
          <p>
            Printed{" "}
            {new Date().toLocaleString("en-GB", { timeZone: "Asia/Dhaka" })}
          </p>
        </footer>
      </section>
      <div className="appointment-print-actions">
        Use Ctrl+P to print or save as PDF.
      </div>
    </main>
  );
}
