import Link from "next/link";
import {
  EmptyState,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { writeAuditLog } from "@/lib/auth/audit";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatDisplayDate } from "@/lib/appointments/time";
import {
  prescriptionStatusLabel,
  prescriptionStatusTone,
} from "@/lib/clinical/status";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function DashboardPrescriptionsPage() {
  const session = await requireAuthenticatedSession(
    "/dashboard/healthcare/prescriptions",
  );
  const patient = await db.patientProfile.findUnique({
    where: { userId: session.user.id },
    select: { id: true, patientCode: true },
  });
  const prescriptions = patient
    ? await db.prescription.findMany({
        where: { patientId: patient.id, status: "SIGNED" },
        include: {
          doctor: true,
          appointment: true,
          _count: { select: { items: true } },
        },
        orderBy: [{ signedAt: "desc" }, { createdAt: "desc" }],
        take: 100,
      })
    : [];
  if (patient)
    await writeAuditLog({
      actorId: session.user.id,
      action: "VIEW_SENSITIVE_DATA",
      department: "HEALTHCARE",
      targetType: "OwnPrescriptions",
      targetId: patient.id,
      metadata: { resultCount: prescriptions.length },
    });
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Healthcare" },
          { label: "Prescriptions" },
        ]}
        description="Only finalized prescriptions signed for your linked patient profile appear here."
        eyebrow="Health records"
        title="My prescriptions"
      />
      <SectionCard title="Signed prescriptions">
        {prescriptions.length ? (
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Prescription</th>
                  <th>Visit</th>
                  <th>Doctor</th>
                  <th>Medicines</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {prescriptions.map((prescription) => (
                  <tr key={prescription.id}>
                    <td>
                      <Link
                        href={`/dashboard/healthcare/prescriptions/${prescription.id}`}
                      >
                        <strong>{prescription.code}</strong>
                        <span>Version {prescription.version}</span>
                      </Link>
                    </td>
                    <td>
                      <strong>
                        {formatDisplayDate(
                          prescription.appointment.appointmentDate,
                        )}
                      </strong>
                      <span>{prescription.appointment.code}</span>
                    </td>
                    <td>{prescription.doctor.name}</td>
                    <td>{prescription._count.items}</td>
                    <td>
                      <StatusBadge
                        tone={prescriptionStatusTone(prescription.status)}
                      >
                        {prescriptionStatusLabel(prescription.status)}
                      </StatusBadge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="file"
            title="No signed prescription yet"
            description="A signed prescription will appear here after your doctor finalizes it."
          />
        )}
      </SectionCard>
    </>
  );
}
