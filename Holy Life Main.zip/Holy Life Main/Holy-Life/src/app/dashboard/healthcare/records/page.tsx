import { EmptyState, PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { writeAuditLog } from "@/lib/auth/audit";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatDisplayDate } from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

function display(value: string | null | undefined): string {
  return value?.trim() || "Not recorded";
}

export default async function DashboardHealthRecordsPage() {
  const session = await requireAuthenticatedSession(
    "/dashboard/healthcare/records",
  );
  const patient = await db.patientProfile.findUnique({
    where: { userId: session.user.id },
    include: {
      clinicalProfile: true,
      vitals: { orderBy: { recordedAt: "desc" }, take: 30 },
      appointments: {
        where: { clinicalEncounter: { isNot: null } },
        include: { doctor: true, clinicalEncounter: true },
        orderBy: [{ appointmentDate: "desc" }, { startTime: "desc" }],
        take: 50,
      },
    },
  });
  if (!patient)
    return (
      <>
        <PageHeader
          breadcrumbs={[
            { label: "Dashboard", href: "/dashboard" },
            { label: "Healthcare" },
            { label: "Health records" },
          ]}
          description="Your linked Holy Life clinical history."
          eyebrow="Health records"
          title="My health record"
        />
        <SectionCard title="Clinical record">
          <EmptyState
            icon="activity"
            title="No linked patient record"
            description="A patient profile will appear here after your verified account is linked to an appointment."
          />
        </SectionCard>
      </>
    );
  await writeAuditLog({
    actorId: session.user.id,
    action: "VIEW_SENSITIVE_DATA",
    department: "HEALTHCARE",
    targetType: "OwnClinicalRecord",
    targetId: patient.id,
  });
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Healthcare" },
          { label: "Health records" },
        ]}
        description="Your longitudinal clinical profile, measurements, and consultation summaries."
        eyebrow="Sensitive health data"
        title="My health record"
      />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard title="Medical history">
            <div className="appointment-detail-copy">
              <div>
                <span>Allergies</span>
                <p>{display(patient.allergies)}</p>
              </div>
              <div>
                <span>Chronic conditions</span>
                <p>{display(patient.clinicalProfile?.chronicConditions)}</p>
              </div>
              <div>
                <span>Current medications</span>
                <p>{display(patient.clinicalProfile?.currentMedications)}</p>
              </div>
              <div>
                <span>Past medical history</span>
                <p>{display(patient.clinicalProfile?.pastMedicalHistory)}</p>
              </div>
              <div>
                <span>Surgical history</span>
                <p>{display(patient.clinicalProfile?.surgicalHistory)}</p>
              </div>
              <div>
                <span>Family history</span>
                <p>{display(patient.clinicalProfile?.familyHistory)}</p>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Consultation history">
            <div className="data-table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Doctor</th>
                    <th>Diagnosis</th>
                    <th>Advice / follow-up</th>
                  </tr>
                </thead>
                <tbody>
                  {patient.appointments.map((appointment) => (
                    <tr key={appointment.id}>
                      <td>
                        <strong>
                          {formatDisplayDate(appointment.appointmentDate)}
                        </strong>
                        <span>{appointment.code}</span>
                      </td>
                      <td>{appointment.doctor.name}</td>
                      <td>{appointment.clinicalEncounter?.diagnosis ?? "—"}</td>
                      <td>
                        <span>
                          {appointment.clinicalEncounter?.advice ?? "—"}
                        </span>
                        <span>
                          {appointment.clinicalEncounter?.followUpDate
                            ? `Follow-up ${formatDisplayDate(appointment.clinicalEncounter.followUpDate)}`
                            : ""}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {patient.appointments.length === 0 ? (
                <div className="table-empty">
                  No clinical consultation summary yet.
                </div>
              ) : null}
            </div>
          </SectionCard>
        </div>
        <div className="content-stack">
          <SectionCard title="Patient profile">
            <div className="status-list">
              <div>
                <span>Patient code</span>
                <strong>{patient.patientCode}</strong>
              </div>
              <div>
                <span>Blood group</span>
                <strong>{patient.bloodGroup ?? "—"}</strong>
              </div>
              <div>
                <span>Date of birth</span>
                <strong>
                  {patient.dateOfBirth
                    ? formatDisplayDate(patient.dateOfBirth)
                    : "—"}
                </strong>
              </div>
              <div>
                <span>Emergency contact</span>
                <strong>{patient.emergencyContactPhone ?? "—"}</strong>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Recent vitals">
            <div className="content-stack">
              {patient.vitals.map((vital) => (
                <div className="notice-box" key={vital.id}>
                  <strong>
                    {vital.recordedAt.toLocaleString("en-GB", {
                      timeZone: "Asia/Dhaka",
                    })}
                  </strong>
                  <p>
                    {vital.heightCm ? `${Number(vital.heightCm)} cm` : ""}{" "}
                    {vital.weightKg ? `· ${Number(vital.weightKg)} kg` : ""}{" "}
                    {vital.temperatureC
                      ? `· ${Number(vital.temperatureC)} °C`
                      : ""}
                  </p>
                  <p>
                    {vital.systolicMmHg && vital.diastolicMmHg
                      ? `BP ${vital.systolicMmHg}/${vital.diastolicMmHg}`
                      : ""}{" "}
                    {vital.pulseBpm ? `· Pulse ${vital.pulseBpm}` : ""}{" "}
                    {vital.oxygenSaturation !== null
                      ? `· SpO₂ ${vital.oxygenSaturation}%`
                      : ""}
                  </p>
                </div>
              ))}
              {patient.vitals.length === 0 ? (
                <p className="muted-copy">No vitals recorded yet.</p>
              ) : null}
            </div>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
