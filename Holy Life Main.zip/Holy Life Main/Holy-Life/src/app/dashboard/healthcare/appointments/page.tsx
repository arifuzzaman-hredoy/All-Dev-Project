import { DashboardAppointmentList } from "@/components/appointments/dashboard-appointment-list";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function MyAppointmentsPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const session = await requireAuthenticatedSession(
    "/dashboard/healthcare/appointments",
  );
  const query = await searchParams;
  return (
    <DashboardAppointmentList
      error={query.error}
      mode="all"
      success={query.success}
      userId={session.user.id}
    />
  );
}
