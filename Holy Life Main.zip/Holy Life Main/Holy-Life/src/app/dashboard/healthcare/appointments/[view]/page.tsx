import { notFound } from "next/navigation";
import {
  AppointmentFlash,
  AppointmentMeta,
  AppointmentMetaItem,
  AppointmentStatusBadge,
  DoctorAvatar,
} from "@/components/appointments/appointment-ui";
import { DashboardAppointmentList } from "@/components/appointments/dashboard-appointment-list";
import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { formatDisplayDate, formatDisplayTime } from "@/lib/appointments/time";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function AppointmentViewPage({
  params,
  searchParams,
}: {
  params: Promise<{ view: string }>;
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const [{ view }, query] = await Promise.all([params, searchParams]);
  const session = await requireAuthenticatedSession(
    `/dashboard/healthcare/appointments/${view}`,
  );
  if (view === "upcoming" || view === "history")
    return (
      <DashboardAppointmentList
        error={query.error}
        mode={view}
        success={query.success}
        userId={session.user.id}
      />
    );
  const appointment = await db.appointment.findFirst({
    where: { id: view, userId: session.user.id },
    include: { doctor: { include: { department: true } }, patient: true },
  });
  if (!appointment) notFound();
  const cancellable =
    appointment.status === "PENDING" || appointment.status === "CONFIRMED";
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Appointments", href: "/dashboard/healthcare/appointments" },
          { label: appointment.code },
        ]}
        description={`${appointment.doctor.name} · ${formatDisplayDate(appointment.appointmentDate)}`}
        eyebrow="Appointment details"
        title={appointment.code}
        actions={
          <ButtonLink href="/appointment" icon="appointment">
            Book another
          </ButtonLink>
        }
      />
      <AppointmentFlash error={query.error} success={query.success} />
      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            action={<AppointmentStatusBadge status={appointment.status} />}
            description="Keep this appointment code for reception and support."
            title="Consultation"
          >
            <div className="appointment-detail-doctor">
              <DoctorAvatar
                imageUrl={appointment.doctor.imageUrl}
                name={appointment.doctor.name}
              />
              <div>
                <span className="content-kicker">
                  {appointment.doctor.department.name}
                </span>
                <h3>{appointment.doctor.name}</h3>
                <p>{appointment.doctor.specialization}</p>
              </div>
            </div>
            <AppointmentMeta>
              <AppointmentMetaItem
                icon="calendar"
                label="Date"
                value={formatDisplayDate(appointment.appointmentDate)}
              />
              <AppointmentMetaItem
                icon="appointment"
                label="Time"
                value={`${formatDisplayTime(appointment.startTime)}–${formatDisplayTime(appointment.endTime)}`}
              />
              <AppointmentMetaItem
                icon="users"
                label="Serial"
                value={
                  appointment.serialNumber
                    ? `#${appointment.serialNumber}`
                    : "Pending"
                }
              />
              <AppointmentMetaItem
                icon="home"
                label="Location"
                value={appointment.doctor.location ?? "Holy Life, Rangpur"}
              />
              <AppointmentMetaItem
                icon="doctor"
                label="Room"
                value={
                  appointment.doctor.roomLabel ?? "Reception will guide you"
                }
              />
              <AppointmentMetaItem
                icon="activity"
                label="Fee"
                value={`৳${Number(appointment.fee).toLocaleString("en-BD")}`}
              />
            </AppointmentMeta>
            <div className="appointment-detail-copy">
              <div>
                <span>Reason for visit</span>
                <p>{appointment.reason ?? "Not provided"}</p>
              </div>
            </div>
          </SectionCard>
          {cancellable ? (
            <SectionCard
              description="Cancellation keeps the record in your history and releases the slot for another patient."
              title="Cancel appointment"
            >
              <form
                action={`/api/dashboard/appointments/${appointment.id}/cancel`}
                className="admin-form-stack"
                method="post"
              >
                <label className="form-field">
                  <span>Reason</span>
                  <textarea
                    maxLength={500}
                    name="reason"
                    placeholder="Tell Holy Life why you need to cancel."
                    rows={3}
                  />
                </label>
                <button className="ui-button ui-button-secondary" type="submit">
                  Cancel appointment
                </button>
              </form>
            </SectionCard>
          ) : null}
        </div>
        <div className="content-stack">
          <SectionCard title="Patient">
            <div className="patient-summary-card">
              <span className="list-avatar list-avatar-health">
                {appointment.patientName
                  .split(/\s+/)
                  .slice(0, 2)
                  .map((part) => part[0])
                  .join("")}
              </span>
              <h3>{appointment.patientName}</h3>
              <p>{appointment.patient.patientCode}</p>
              <div>
                <span>
                  Mobile<strong>{appointment.patientPhone}</strong>
                </span>
                <span>
                  Email
                  <strong>{appointment.patientEmail ?? "Not provided"}</strong>
                </span>
              </div>
            </div>
          </SectionCard>
          <SectionCard title="Status & payment">
            <div className="status-list">
              <div>
                <span>Appointment</span>
                <AppointmentStatusBadge status={appointment.status} />
              </div>
              <div>
                <span>Payment</span>
                <StatusBadge
                  tone={
                    appointment.paymentStatus === "PAID" ? "success" : "warning"
                  }
                >
                  {appointment.paymentStatus}
                </StatusBadge>
              </div>
              <div>
                <span>Source</span>
                <StatusBadge tone="info">{appointment.source}</StatusBadge>
              </div>
            </div>
          </SectionCard>
          {appointment.cancellationReason ? (
            <SectionCard title="Cancellation note">
              <div className="notice-box">
                <p>{appointment.cancellationReason}</p>
              </div>
            </SectionCard>
          ) : null}
        </div>
      </div>
    </>
  );
}
