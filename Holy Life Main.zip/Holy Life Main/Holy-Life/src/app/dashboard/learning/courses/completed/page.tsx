import { StudentCourseList } from "@/components/learning/student-course-list";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
export const dynamic = "force-dynamic";
export default async function Page() {
  const session = await requireAuthenticatedSession(
    "/dashboard/learning/courses/completed",
  );
  return <StudentCourseList userId={session.user.id} mode="completed" />;
}
