import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  const session = await requireAuthenticatedSession(
    "/dashboard/learning/certificates",
  );
  const certificates = await db.courseCertificate.findMany({
    where: { userId: session.user.id },
    include: { course: true },
    orderBy: { issuedAt: "desc" },
  });
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Learning"
        title="Certificates"
        description="Your verified Holy Life course completion credentials."
      />
      <SectionCard title="Credentials">
        <div className="learning-certificate-grid">
          {certificates.map((item) => (
            <article key={item.id}>
              <span className="page-eyebrow">Holy Life Certificate</span>
              <h2>{item.course.title}</h2>
              <strong>{item.code}</strong>
              <p>Issued {item.issuedAt.toLocaleDateString("en-BD")}</p>
              <StatusBadge
                tone={item.status === "ISSUED" ? "success" : "danger"}
              >
                {item.status}
              </StatusBadge>
            </article>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
