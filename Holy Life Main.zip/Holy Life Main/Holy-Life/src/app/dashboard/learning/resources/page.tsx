import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function Page() {
  const session = await requireAuthenticatedSession(
    "/dashboard/learning/resources",
  );
  const resources = await db.courseResource.findMany({
    where: {
      lesson: {
        module: {
          course: {
            enrollments: {
              some: {
                userId: session.user.id,
                status: { in: ["ACTIVE", "COMPLETED"] },
              },
            },
          },
        },
      },
    },
    include: { lesson: { include: { module: { include: { course: true } } } } },
    orderBy: { position: "asc" },
  });
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Learning"
        title="Resources"
        description="Downloadable materials from your enrolled courses."
      />
      <SectionCard title="Course resources">
        <div className="compact-list">
          {resources.map((item) => (
            <a href={item.url} key={item.id} target="_blank" rel="noreferrer">
              <strong>{item.title}</strong>
              <span>
                {item.lesson.module.course.title} · {item.lesson.title}
              </span>
            </a>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
