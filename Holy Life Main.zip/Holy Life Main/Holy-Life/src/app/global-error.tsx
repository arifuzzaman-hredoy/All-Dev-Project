"use client";

export default function GlobalError({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body>
        <main
          style={{
            minHeight: "100vh",
            display: "grid",
            placeItems: "center",
            padding: "24px",
            background: "#f5f7f8",
            color: "#17212b",
            fontFamily:
              'Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          }}
        >
          <section
            style={{
              width: "min(100%, 620px)",
              padding: "32px",
              borderRadius: "16px",
              background: "#fff",
            }}
          >
            <strong style={{ color: "#16705d" }}>Holy Life</strong>
            <h1 style={{ margin: "14px 0 10px" }}>
              The application could not finish loading.
            </h1>
            <p style={{ color: "#6d7a86", lineHeight: 1.6 }}>
              Retry the application. If the problem continues, contact the Holy
              Life administrator.
            </p>
            <button
              onClick={() => reset()}
              style={{
                minHeight: "42px",
                marginTop: "10px",
                padding: "0 16px",
                border: 0,
                borderRadius: "8px",
                color: "#fff",
                background: "#16705d",
                fontWeight: 700,
                cursor: "pointer",
              }}
              type="button"
            >
              Retry Holy Life
            </button>
          </section>
        </main>
      </body>
    </html>
  );
}
