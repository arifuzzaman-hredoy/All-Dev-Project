import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PublicPageRenderer } from "@/components/cms/public-page-renderer";
import { PublicShell } from "@/components/layout/public-shell";
import { requireWebsitePermission } from "@/lib/cms/admin";
import type { PublicWebsitePage } from "@/lib/cms/types";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Website draft preview",
  robots: { index: false, follow: false },
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

export default async function WebsiteDraftPreview({
  params,
}: {
  params: Promise<{ pageId: string }>;
}) {
  const { pageId } = await params;
  await requireWebsitePermission(
    "website.cms.content.view",
    `/website-preview/${pageId}`,
  );
  const page = await db.websitePage.findUnique({
    where: { id: pageId },
    include: {
      sections: { orderBy: [{ position: "asc" }, { createdAt: "asc" }] },
    },
  });
  if (!page) notFound();
  const preview: PublicWebsitePage = {
    id: page.id,
    slug: page.slug,
    title: page.title,
    navigationLabel: page.navigationLabel,
    excerpt: page.excerpt,
    seoTitle: page.seoTitle,
    seoDescription: page.seoDescription,
    canonicalPath: page.canonicalPath,
    sections: page.sections.map((section) => ({
      id: section.id,
      key: section.key,
      type: section.type,
      title: section.title,
      position: section.position,
      isEnabled: section.isEnabled,
      content: isRecord(section.content) ? section.content : {},
    })),
  };
  return (
    <PublicShell>
      <aside className="cms-preview-banner">
        Secure preview · {page.status} · version {page.version} · this URL
        requires CMS permission and is not indexed
      </aside>
      <PublicPageRenderer page={preview} />
    </PublicShell>
  );
}
