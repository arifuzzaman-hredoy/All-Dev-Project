import Link from "next/link";
import { AuthRedirectForm } from "@/components/auth/auth-redirect-form";
import {
  AuthAlert,
  AuthShell,
  PasswordRequirements,
} from "@/components/auth/auth-shell";
import { PasswordInput } from "@/components/auth/password-input";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string; error?: string }>;
}) {
  const [params, { locale }] = await Promise.all([
    searchParams,
    getUiPreferences(),
  ]);
  return (
    <AuthShell
      eyebrow={uiText(locale, "auth.chooseNewPassword")}
      title={uiText(locale, "auth.secureAccount")}
      description={uiText(locale, "auth.secureAccountDescription")}
      footer={
        <p>
          {uiText(locale, "auth.resetExpired")}{" "}
          <Link href="/forgot-password">
            {uiText(locale, "auth.requestNew")}
          </Link>
        </p>
      }
    >
      {params.error ? <AuthAlert type="error">{params.error}</AuthAlert> : null}
      {!params.token ? (
        <AuthAlert type="info">
          {uiText(locale, "auth.resetCodeHelp")}
        </AuthAlert>
      ) : null}
      <AuthRedirectForm action="/api/auth/reset-password" className="auth-form">
        {params.token ? (
          <input name="token" type="hidden" value={params.token} />
        ) : (
          <div className="auth-field-grid">
            <label className="auth-field">
              <span>{uiText(locale, "auth.emailOrPhone")}</span>
              <input
                autoComplete="username"
                maxLength={254}
                name="identifier"
                placeholder="name@example.com or 01XXXXXXXXX"
                required
              />
            </label>
            <label className="auth-field">
              <span>{uiText(locale, "auth.resetCode")}</span>
              <input
                autoComplete="one-time-code"
                inputMode="numeric"
                maxLength={6}
                minLength={6}
                name="code"
                pattern="[0-9]{6}"
                placeholder="000000"
                required
              />
            </label>
          </div>
        )}
        <PasswordInput
          autoComplete="new-password"
          label={uiText(locale, "auth.newPassword")}
          name="password"
        />
        <PasswordInput
          autoComplete="new-password"
          label={uiText(locale, "auth.confirmNewPassword")}
          name="confirmPassword"
        />
        <PasswordRequirements />
        <button className="public-primary-button auth-submit" type="submit">
          {uiText(locale, "auth.updatePassword")}
        </button>
      </AuthRedirectForm>
    </AuthShell>
  );
}
