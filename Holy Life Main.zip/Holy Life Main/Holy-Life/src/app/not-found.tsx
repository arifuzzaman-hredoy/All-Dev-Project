import Link from "next/link";

export default function NotFound() {
  return (
    <main className="launch-error-shell">
      <section className="launch-error-card" aria-labelledby="not-found-title">
        <span className="launch-error-code">404</span>
        <h1 id="not-found-title">This page could not be found.</h1>
        <p>The link may be outdated, private, or no longer published.</p>
        <div className="launch-error-actions">
          <Link className="ui-button ui-button-primary" href="/">
            Go to Holy Life
          </Link>
          <Link className="ui-button ui-button-secondary" href="/dashboard">
            Open dashboard
          </Link>
        </div>
      </section>
    </main>
  );
}
