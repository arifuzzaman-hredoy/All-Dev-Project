import type { Metadata } from "next";
import { PublicPageRenderer } from "@/components/cms/public-page-renderer";
import { HomeExperience } from "@/components/home/home-experience";
import { PublicShell } from "@/components/layout/public-shell";
import { getPublishedWebsitePage } from "@/lib/cms/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPublishedWebsitePage("home");
  return {
    title: page?.seoTitle ?? page?.title ?? "Holy Life",
    description: page?.seoDescription ?? page?.excerpt ?? undefined,
    alternates: { canonical: page?.canonicalPath ?? "/" },
  };
}

export default async function HomePage() {
  const page = await getPublishedWebsitePage("home");
  return (
    <PublicShell>
      {page ? (
        <PublicPageRenderer
          hideFinalCta
          insertBeforeFinalCta={<HomeExperience />}
          page={page}
        />
      ) : (
        <HomeExperience />
      )}
    </PublicShell>
  );
}
