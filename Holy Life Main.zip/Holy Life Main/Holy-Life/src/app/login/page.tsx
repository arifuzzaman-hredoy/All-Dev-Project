import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthRedirectForm } from "@/components/auth/auth-redirect-form";
import { AuthAlert, AuthShell } from "@/components/auth/auth-shell";
import { PasswordInput } from "@/components/auth/password-input";
import { authConfig } from "@/lib/auth/config";
import {
  getCurrentSession,
  hasVerifiedContact,
  isAdminUser,
} from "@/lib/auth/session";
import { safeMemberReturnTo } from "@/lib/auth/request";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{
    error?: string;
    success?: string;
    returnTo?: string;
  }>;
}) {
  const [params, preferences] = await Promise.all([
    searchParams,
    getUiPreferences(),
  ]);
  const returnTo = safeMemberReturnTo(params.returnTo ?? null);
  const session = await getCurrentSession();
  const { locale } = preferences;

  if (
    session &&
    (!authConfig.requireVerifiedContact || hasVerifiedContact(session.user))
  ) {
    redirect(
      session.user.isSuperAdmin
        ? "/super-admin"
        : isAdminUser(session.user)
          ? "/admin"
          : returnTo,
    );
  }

  return (
    <AuthShell
      eyebrow={uiText(locale, "auth.welcomeBack")}
      title={uiText(locale, "auth.signInTitle")}
      description={uiText(locale, "auth.signInDescription")}
      footer={
        <p>
          {uiText(locale, "auth.newToHolyLife")}{" "}
          <Link href={`/register?returnTo=${encodeURIComponent(returnTo)}`}>
            {uiText(locale, "public.createAccount")}
          </Link>
          {" · "}
          <Link href="/admin-login">{uiText(locale, "auth.adminSignIn")}</Link>
          {" · "}
          <Link href="/super-admin">
            {uiText(locale, "auth.superAdminSignIn")}
          </Link>
        </p>
      }
    >
      {params.error ? <AuthAlert type="error">{params.error}</AuthAlert> : null}
      {params.success ? (
        <AuthAlert type="success">{params.success}</AuthAlert>
      ) : null}
      <AuthRedirectForm action="/api/auth/login" className="auth-form">
        <input name="returnTo" type="hidden" value={returnTo} />
        <label className="auth-field">
          <span>{uiText(locale, "auth.emailOrPhone")}</span>
          <input
            autoComplete="username"
            maxLength={254}
            name="identifier"
            placeholder="name@example.com or 01XXXXXXXXX"
            required
          />
        </label>
        <PasswordInput
          autoComplete="current-password"
          label={uiText(locale, "auth.password")}
          name="password"
          placeholder={uiText(locale, "auth.enterPassword")}
        />
        <div className="auth-form-row">
          <span className="auth-security-note">
            {uiText(locale, "auth.secureSession")}
          </span>
          <Link href="/forgot-password">
            {uiText(locale, "auth.forgotPassword")}
          </Link>
        </div>
        <button className="public-primary-button auth-submit" type="submit">
          {uiText(locale, "public.signIn")}
        </button>
      </AuthRedirectForm>
    </AuthShell>
  );
}
