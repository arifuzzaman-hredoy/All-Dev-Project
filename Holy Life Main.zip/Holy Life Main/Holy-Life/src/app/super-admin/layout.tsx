import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { PanelShell } from "@/components/layout/panel-shell";
import { superAdminNavigation } from "@/config/navigation";
import { getCurrentSession, isAdminUser } from "@/lib/auth/session";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function SuperAdminLayout({
  children,
}: {
  children: ReactNode;
}) {
  const [session, preferences] = await Promise.all([
    getCurrentSession(),
    getUiPreferences(),
  ]);

  if (!session) return <>{children}</>;

  if (!session.user.isSuperAdmin) {
    redirect(
      isAdminUser(session.user)
        ? "/admin?error=owner-access-required"
        : "/dashboard?error=owner-access-required",
    );
  }

  return (
    <PanelShell
      locale={preferences.locale}
      navigation={superAdminNavigation}
      subtitle={
        preferences.locale === "bn"
          ? "মালিকের নিয়ন্ত্রণ কেন্দ্র"
          : "Owner control center"
      }
      surface="super-admin"
      themePreference={preferences.themePreference}
      title={preferences.locale === "bn" ? "সুপার অ্যাডমিন" : "Super Admin"}
      userName={session.user.name}
      userRole={preferences.locale === "bn" ? "সুপার অ্যাডমিন" : "Super Admin"}
    >
      {children}
    </PanelShell>
  );
}
