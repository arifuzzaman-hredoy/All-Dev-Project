import { redirect } from "next/navigation";
import { requireSuperAdminSession } from "@/lib/auth/authorization";

export default async function SuperAdminPublicSiteRedirect() {
  await requireSuperAdminSession();
  redirect("/admin/website");
}
