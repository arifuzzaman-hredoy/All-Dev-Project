import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

const formatter = new Intl.DateTimeFormat("en-BD", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Dhaka",
});

export default async function SuperAdminSecurityPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const params = await searchParams;
  await requireSuperAdminSession();
  const users = await db.user.findMany({
    where: { isSuperAdmin: false, status: { not: "ARCHIVED" } },
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      roles: { include: { role: true } },
      sessions: {
        where: { revokedAt: null, expiresAt: { gt: new Date() } },
        select: { id: true },
      },
    },
  });

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Security" },
        ]}
        description="Owner-only account status, session revocation, and verification overview."
        eyebrow="Owner security control"
        title="Accounts & active sessions"
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      {params.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {params.success}
        </div>
      ) : null}
      <SectionCard
        title="User and admin accounts"
        description="Suspending an account immediately revokes all active sessions. Owner accounts are protected from this interface."
      >
        <div className="data-table-wrap">
          <table className="data-table security-admin-table">
            <thead>
              <tr>
                <th>Account</th>
                <th>Role</th>
                <th>Verification</th>
                <th>Sessions</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>
                    <strong>{user.name}</strong>
                    <span>
                      {user.email ?? user.phone ?? "No contact"} · Joined{" "}
                      {formatter.format(user.createdAt)}
                    </span>
                  </td>
                  <td>
                    {user.roles.map(({ role }) => role.name).join(", ") ||
                      "No role"}
                  </td>
                  <td>
                    <div className="table-status-stack">
                      {user.email ? (
                        <StatusBadge
                          tone={user.emailVerifiedAt ? "success" : "warning"}
                        >
                          Email {user.emailVerifiedAt ? "verified" : "pending"}
                        </StatusBadge>
                      ) : null}
                      {user.phone ? (
                        <StatusBadge
                          tone={user.phoneVerifiedAt ? "success" : "warning"}
                        >
                          Phone {user.phoneVerifiedAt ? "verified" : "pending"}
                        </StatusBadge>
                      ) : null}
                    </div>
                  </td>
                  <td>
                    <strong>{user.sessions.length}</strong>
                    <span>active</span>
                  </td>
                  <td>
                    <StatusBadge
                      tone={user.status === "ACTIVE" ? "success" : "danger"}
                    >
                      {user.status}
                    </StatusBadge>
                  </td>
                  <td>
                    <div className="table-action-stack">
                      <form
                        action={`/api/super-admin/users/${user.id}/status`}
                        method="post"
                      >
                        <input
                          name="status"
                          type="hidden"
                          value={
                            user.status === "ACTIVE" ? "SUSPENDED" : "ACTIVE"
                          }
                        />
                        <button
                          className={`ui-button ${user.status === "ACTIVE" ? "ui-button-secondary" : "ui-button-primary"}`}
                          type="submit"
                        >
                          {user.status === "ACTIVE" ? "Suspend" : "Activate"}
                        </button>
                      </form>
                      <form
                        action={`/api/super-admin/users/${user.id}/revoke-sessions`}
                        method="post"
                      >
                        <button
                          className="ui-button ui-button-secondary"
                          disabled={user.sessions.length === 0}
                          type="submit"
                        >
                          Force logout
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))}
              {users.length === 0 ? (
                <tr>
                  <td colSpan={6}>
                    <span>No non-owner accounts have been created.</span>
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </>
  );
}
