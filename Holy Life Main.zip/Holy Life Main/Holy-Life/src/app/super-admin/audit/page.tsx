import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

const formatter = new Intl.DateTimeFormat("en-BD", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Dhaka",
});

const securityActions = new Set([
  "LOGIN",
  "LOGOUT",
  "REGISTER",
  "VERIFY",
  "PASSWORD_CHANGE",
  "SESSION_REVOKE",
  "STATUS_CHANGE",
  "ACCOUNT_LOCKED",
]);

export default async function AuditPage() {
  await requireSuperAdminSession();
  const events = await db.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { actor: { select: { name: true, email: true, phone: true } } },
  });

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Audit logs" },
        ]}
        description="Recent authentication, status, session, and system activity recorded by the platform."
        eyebrow="Owner visibility"
        title="Audit logs"
      />
      <SectionCard
        title="Recent events"
        description="The newest 200 events are shown. Sensitive metadata is intentionally summarized."
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Actor</th>
                <th>Action</th>
                <th>Target</th>
                <th>Source</th>
              </tr>
            </thead>
            <tbody>
              {events.map((event) => (
                <tr key={event.id}>
                  <td>
                    <strong>{formatter.format(event.createdAt)}</strong>
                    <span>{event.department ?? "SYSTEM"}</span>
                  </td>
                  <td>
                    <strong>{event.actor?.name ?? "System / anonymous"}</strong>
                    <span>
                      {event.actor?.email ?? event.actor?.phone ?? "No account"}
                    </span>
                  </td>
                  <td>
                    <StatusBadge
                      tone={
                        securityActions.has(event.action) ? "info" : "neutral"
                      }
                    >
                      {event.action.replaceAll("_", " ")}
                    </StatusBadge>
                  </td>
                  <td>
                    <strong>{event.targetType}</strong>
                    <span>{event.targetId ?? "No target ID"}</span>
                  </td>
                  <td>
                    <strong>{event.ipAddress ?? "Not recorded"}</strong>
                    <span>
                      Proxy trust:{" "}
                      {process.env.TRUST_PROXY === "true"
                        ? "enabled"
                        : "disabled"}
                    </span>
                  </td>
                </tr>
              ))}
              {events.length === 0 ? (
                <tr>
                  <td colSpan={5}>
                    <span>No audit events recorded yet.</span>
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </>
  );
}
