import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthAlert, AuthShell } from "@/components/auth/auth-shell";
import { PasswordInput } from "@/components/auth/password-input";
import {
  ButtonLink,
  MetricCard,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { getCurrentSession, isAdminUser } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export default async function SuperAdminPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; returnTo?: string }>;
}) {
  const params = await searchParams;
  const { locale } = await getUiPreferences();
  const session = await getCurrentSession();

  if (!session) {
    const returnTo =
      params.returnTo?.startsWith("/super-admin") &&
      !params.returnTo.startsWith("//")
        ? params.returnTo
        : "/super-admin";

    return (
      <AuthShell
        eyebrow={uiText(locale, "auth.ownerOnly")}
        title={uiText(locale, "auth.superAdminSignIn")}
        description={uiText(locale, "auth.ownerSignInDescription")}
        footer={
          <p>
            {uiText(locale, "auth.adminSignIn")}{" "}
            <Link href="/admin-login">{uiText(locale, "auth.openAdmin")}</Link>{" "}
            · {uiText(locale, "auth.memberAccount")}{" "}
            <Link href="/login">{uiText(locale, "auth.memberSignIn")}</Link>
          </p>
        }
      >
        {params.error ? (
          <AuthAlert type="error">{params.error}</AuthAlert>
        ) : null}
        <form
          action="/api/super-admin/login"
          className="auth-form"
          method="post"
        >
          <input name="returnTo" type="hidden" value={returnTo} />
          <label className="auth-field">
            <span>{uiText(locale, "auth.superAdminEmail")}</span>
            <input
              autoComplete="username"
              maxLength={254}
              name="email"
              placeholder={uiText(locale, "auth.superAdminEmail")}
              required
              type="email"
            />
          </label>
          <PasswordInput
            autoComplete="current-password"
            label={uiText(locale, "auth.superAdminPassword")}
            name="password"
            placeholder={uiText(locale, "auth.ownerPasswordPlaceholder")}
          />
          <p className="auth-field-help">
            {uiText(locale, "auth.ownerCredentialHelp")}
          </p>
          <button className="public-primary-button auth-submit" type="submit">
            {uiText(locale, "auth.openSuperAdmin")}
          </button>
        </form>
      </AuthShell>
    );
  }

  if (!session.user.isSuperAdmin) {
    redirect(
      isAdminUser(session.user)
        ? "/admin?error=owner-access-required"
        : "/dashboard?error=owner-access-required",
    );
  }

  const [
    admins,
    activeAdminCount,
    adminRoleCount,
    permissionCount,
    securityEvents,
  ] = await Promise.all([
    db.user.findMany({
      where: {
        isSuperAdmin: false,
        status: { not: "ARCHIVED" },
        roles: { some: { role: { isAdminRole: true } } },
      },
      include: {
        roles: {
          where: { role: { isAdminRole: true } },
          include: { role: true },
          orderBy: { assignedAt: "asc" },
        },
      },
      orderBy: { createdAt: "desc" },
      take: 6,
    }),
    db.user.count({
      where: {
        isSuperAdmin: false,
        status: "ACTIVE",
        roles: { some: { role: { isAdminRole: true } } },
      },
    }),
    db.role.count({ where: { isAdminRole: true, status: "ACTIVE" } }),
    db.permission.count(),
    db.auditLog.count(),
  ]);

  return (
    <>
      <PageHeader
        breadcrumbs={[{ label: "Super Admin" }, { label: "System overview" }]}
        description="Owner-level control for admins, permissions, departments, public content, and system safety."
        eyebrow="Owner control center"
        title="System overview"
        actions={
          <ButtonLink
            href="/super-admin/administration/admins/create"
            icon="users"
          >
            Create admin
          </ButtonLink>
        }
      />

      <section
        className="metric-grid metric-grid-four"
        aria-label="System summary"
      >
        <MetricCard
          label="Active admins"
          value={String(activeAdminCount)}
          helper={`${admins.length} recent accounts`}
          icon="users"
          tone="neutral"
        />
        <MetricCard
          label="Admin roles"
          value={String(adminRoleCount)}
          helper="Preset and custom roles"
          icon="permission"
          tone="health"
        />
        <MetricCard
          label="Permission rules"
          value={String(permissionCount)}
          helper="RBAC permission catalog"
          icon="shield"
          tone="learning"
        />
        <MetricCard
          label="Audit events"
          value={String(securityEvents)}
          helper="Recorded audit trail"
          icon="activity"
          tone="warning"
        />
      </section>

      <div className="content-grid content-grid-main">
        <div className="content-stack">
          <SectionCard
            title="Admin access overview"
            description="Current operational accounts and their assigned scope."
            action={
              <ButtonLink
                href="/super-admin/administration/admins"
                variant="quiet"
              >
                Manage admins
              </ButtonLink>
            }
          >
            <div className="data-table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Admin</th>
                    <th>Role</th>
                    <th>Scope</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {admins.map((admin) => (
                    <tr key={admin.id}>
                      <td>
                        <strong>{admin.name}</strong>
                        <span>
                          {admin.email ?? admin.phone ?? "No contact"}
                        </span>
                      </td>
                      <td>
                        {admin.roles.map(({ role }) => role.name).join(", ") ||
                          "No admin role"}
                      </td>
                      <td>
                        {admin.roles
                          .map(({ dataScope }) => dataScope)
                          .join(", ") || "—"}
                      </td>
                      <td>
                        <StatusBadge
                          tone={
                            admin.status === "ACTIVE"
                              ? "success"
                              : admin.status === "SUSPENDED"
                                ? "danger"
                                : "neutral"
                          }
                        >
                          {admin.status}
                        </StatusBadge>
                      </td>
                    </tr>
                  ))}
                  {admins.length === 0 ? (
                    <tr>
                      <td colSpan={4}>
                        <span>No admin account has been created yet.</span>
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </SectionCard>

          <SectionCard
            title="Platform surfaces"
            description="Visibility and control state for each major interface."
          >
            <div className="surface-control-list">
              <article>
                <div className="surface-control-icon">
                  <span>PU</span>
                </div>
                <div>
                  <strong>Public website</strong>
                  <p>Home, appointment, courses, shop, and public content.</p>
                </div>
                <StatusBadge tone="success">Published</StatusBadge>
              </article>
              <article>
                <div className="surface-control-icon">
                  <span>UD</span>
                </div>
                <div>
                  <strong>User dashboard</strong>
                  <p>Healthcare, learning, shopping, profile, and support.</p>
                </div>
                <StatusBadge tone="success">Enabled</StatusBadge>
              </article>
              <article>
                <div className="surface-control-icon">
                  <span>AP</span>
                </div>
                <div>
                  <strong>Admin panel</strong>
                  <p>Permission-aware operational workspace.</p>
                </div>
                <StatusBadge tone="success">Enabled</StatusBadge>
              </article>
            </div>
          </SectionCard>
        </div>

        <div className="content-stack">
          <SectionCard
            title="Department controls"
            description="The three primary Holy Life business areas."
          >
            <div className="department-control-grid">
              <article className="department-control-card department-health">
                <span>Healthcare</span>
                <strong>Enabled</strong>
                <small>24 permissions</small>
              </article>
              <article className="department-control-card department-commerce">
                <span>E-commerce</span>
                <strong>Enabled</strong>
                <small>31 permissions</small>
              </article>
              <article className="department-control-card department-learning">
                <span>Course & learning</span>
                <strong>Enabled</strong>
                <small>29 permissions</small>
              </article>
            </div>
          </SectionCard>

          <SectionCard
            title="Security & backup"
            description="Owner-only safeguards and operational status."
          >
            <div className="status-list">
              <div>
                <span>Failed-login protection</span>
                <StatusBadge tone="success">Configured</StatusBadge>
              </div>
              <div>
                <span>Audit logging foundation</span>
                <StatusBadge tone="success">Enabled</StatusBadge>
              </div>
              <div>
                <span>Backup mode</span>
                <StatusBadge tone="warning">Local-only UAT</StatusBadge>
              </div>
              <div>
                <span>Last restore test</span>
                <StatusBadge tone="neutral">Not run</StatusBadge>
              </div>
            </div>
          </SectionCard>

          <SectionCard
            title="Architecture note"
            description="Current deployment decision."
          >
            <div className="notice-box">
              <strong>Docker Compose is the correct current target</strong>
              <p>
                Kubernetes remains deferred until multi-node scaling or strict
                high availability becomes a real requirement.
              </p>
              <ButtonLink href="/super-admin/settings" variant="quiet">
                View platform settings
              </ButtonLink>
            </div>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
