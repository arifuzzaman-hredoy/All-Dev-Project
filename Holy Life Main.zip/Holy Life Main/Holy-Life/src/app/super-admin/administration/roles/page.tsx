import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export default async function RolesPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const params = await searchParams;
  await requireSuperAdminSession();
  const roles = await db.role.findMany({
    where: { isAdminRole: true },
    orderBy: [{ status: "asc" }, { displayOrder: "asc" }, { name: "asc" }],
    include: {
      _count: { select: { users: true, permissions: true } },
    },
  });
  return (
    <>
      <PageHeader
        actions={
          <ButtonLink href="/super-admin/administration/roles/create">
            Create custom role
          </ButtonLink>
        }
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Administration" },
          { label: "Roles & permissions" },
        ]}
        description="Preset and custom roles support multiple assignments, nested permissions, default data scopes, cloning, renaming, and archive-only removal."
        eyebrow="Role authorization"
        title="Roles & permission matrix"
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      {params.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {params.success}
        </div>
      ) : null}
      <SectionCard
        title="Admin roles"
        description="System roles can be renamed and their permissions customized, but protected roles cannot be archived."
      >
        <div className="role-card-grid">
          {roles.map((role) => (
            <article className="role-card" key={role.id}>
              <header>
                <div>
                  <strong>{role.name}</strong>
                  <code>{role.code}</code>
                </div>
                <StatusBadge
                  tone={role.status === "ACTIVE" ? "success" : "neutral"}
                >
                  {role.status}
                </StatusBadge>
              </header>
              <p>{role.description ?? "No description"}</p>
              <div className="role-card-meta">
                <span>{role._count.permissions} permissions</span>
                <span>{role._count.users} users</span>
                <span>{role.defaultDataScope} scope</span>
              </div>
              <div className="role-card-actions">
                <ButtonLink
                  href={`/super-admin/administration/roles/${role.id}`}
                  variant="secondary"
                >
                  Edit matrix
                </ButtonLink>
                <form
                  action={`/api/super-admin/roles/${role.id}/clone`}
                  method="post"
                >
                  <button
                    className="ui-button ui-button-secondary"
                    type="submit"
                  >
                    Clone
                  </button>
                </form>
              </div>
            </article>
          ))}
        </div>
      </SectionCard>
    </>
  );
}
