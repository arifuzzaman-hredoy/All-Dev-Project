import { notFound } from "next/navigation";
import { RoleForm } from "@/components/rbac/role-form";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

export default async function EditRolePage({
  params,
  searchParams,
}: {
  params: Promise<{ roleId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const [{ roleId }, query] = await Promise.all([params, searchParams]);
  await requireSuperAdminSession();
  const role = await db.role.findUnique({
    where: { id: roleId },
    include: {
      permissions: { where: { allowed: true }, include: { permission: true } },
      _count: { select: { users: true } },
    },
  });
  if (!role || !role.isAdminRole) notFound();
  const selected = new Set(
    role.permissions.map(({ permission }) => permission.key),
  );
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Roles", href: "/super-admin/administration/roles" },
          { label: role.name },
        ]}
        description={`${role._count.users} assigned user(s). Saving permissions revokes affected sessions so access changes apply immediately.`}
        eyebrow={role.isSystem ? "System role" : "Custom role"}
        title={role.name}
      />
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      <SectionCard
        title="Role and permission matrix"
        description="The primary owner bypasses this matrix and remains protected."
      >
        <RoleForm
          action={`/api/super-admin/roles/${role.id}`}
          role={role}
          selectedPermissions={selected}
          submitLabel="Save role and permissions"
        />
        {!role.isSystem && role.status === "ACTIVE" ? (
          <div className="danger-zone-row">
            <div>
              <strong>Archive custom role</strong>
              <p>
                Archive is blocked while users are assigned. Historical records
                remain intact.
              </p>
            </div>
            <form
              action={`/api/super-admin/roles/${role.id}/archive`}
              method="post"
            >
              <button className="ui-button ui-button-secondary" type="submit">
                Archive role
              </button>
            </form>
          </div>
        ) : null}
      </SectionCard>
    </>
  );
}
