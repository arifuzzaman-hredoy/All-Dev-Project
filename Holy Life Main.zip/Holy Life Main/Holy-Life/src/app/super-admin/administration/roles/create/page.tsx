import { RoleForm } from "@/components/rbac/role-form";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";

export default async function CreateRolePage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;
  await requireSuperAdminSession();
  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Roles", href: "/super-admin/administration/roles" },
          { label: "Create" },
        ]}
        description="Create a reusable custom role and choose exact permissions from the nested matrix."
        eyebrow="Custom authorization"
        title="Create custom role"
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      <SectionCard
        title="Role configuration"
        description="Role codes are immutable identifiers after creation."
      >
        <RoleForm
          action="/api/super-admin/roles"
          selectedPermissions={new Set()}
          submitLabel="Create role"
        />
      </SectionCard>
    </>
  );
}
