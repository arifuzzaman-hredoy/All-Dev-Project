import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import { appOrigin } from "@/lib/auth/config";
import { db } from "@/lib/db";
import { DATA_SCOPES } from "@/lib/rbac/catalog";

export default async function CreateAdminPage({
  searchParams,
}: {
  searchParams: Promise<{
    error?: string;
    success?: string;
    invitation?: string;
  }>;
}) {
  const params = await searchParams;
  await requireSuperAdminSession();
  const roles = await db.role.findMany({
    where: { isAdminRole: true, status: "ACTIVE" },
    orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
  });
  const invitationUrl = params.invitation
    ? `${appOrigin()}/admin-invitation?token=${encodeURIComponent(params.invitation)}`
    : null;

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Admins", href: "/super-admin/administration/admins" },
          { label: "Create" },
        ]}
        description="Use a direct password for immediate access or create a secure one-time email invitation. Multiple roles are supported."
        eyebrow="Admin onboarding"
        title="Create or invite admin"
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      {params.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {params.success}
        </div>
      ) : null}
      {invitationUrl ? (
        <div className="panel-inline-alert panel-inline-alert-success invitation-result">
          <strong>One-time invitation URL</strong>
          <code>{invitationUrl}</code>
          <span>
            Copy it now. Only its SHA-256 hash is stored in the database.
          </span>
        </div>
      ) : null}
      <SectionCard
        title="Account details"
        description="The data scope applies to every selected role in this onboarding step and can be changed later per role."
      >
        <form
          action="/api/super-admin/admins"
          className="rbac-form"
          method="post"
        >
          <div className="rbac-form-grid">
            <label>
              <span>Full name</span>
              <input autoComplete="name" name="name" required />
            </label>
            <label>
              <span>Email</span>
              <input autoComplete="email" name="email" required type="email" />
            </label>
            <label>
              <span>Creation mode</span>
              <select defaultValue="DIRECT" name="mode">
                <option value="DIRECT">Direct password</option>
                <option value="INVITATION">Email invitation</option>
              </select>
            </label>
            <label>
              <span>Initial password</span>
              <input
                autoComplete="new-password"
                minLength={6}
                name="password"
                placeholder="Required for direct mode"
                type="password"
              />
            </label>
            <label>
              <span>Data scope</span>
              <select defaultValue="DEPARTMENT" name="dataScope">
                {DATA_SCOPES.map((scope) => (
                  <option key={scope} value={scope}>
                    {scope}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <fieldset className="permission-fieldset">
            <legend>Assign one or more roles</legend>
            <div className="role-choice-grid">
              {roles.map((role) => (
                <label className="role-choice" key={role.id}>
                  <input name="roleId" type="checkbox" value={role.id} />
                  <span>
                    <strong>{role.name}</strong>
                    <small>
                      {role.description ?? role.code} · default{" "}
                      {role.defaultDataScope}
                    </small>
                  </span>
                </label>
              ))}
            </div>
          </fieldset>
          <div className="rbac-form-actions">
            <button className="ui-button ui-button-primary" type="submit">
              Create account or invitation
            </button>
          </div>
        </form>
      </SectionCard>
    </>
  );
}
