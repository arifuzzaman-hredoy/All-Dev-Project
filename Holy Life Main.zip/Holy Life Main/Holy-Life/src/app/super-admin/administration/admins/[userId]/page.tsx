import { notFound } from "next/navigation";
import { PageHeader, SectionCard, StatusBadge } from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
import { DATA_SCOPES } from "@/lib/rbac/catalog";

export default async function EditAdminPage({
  params,
  searchParams,
}: {
  params: Promise<{ userId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const [{ userId }, query] = await Promise.all([params, searchParams]);
  await requireSuperAdminSession();
  const [admin, roles, activities] = await Promise.all([
    db.user.findUnique({
      where: { id: userId },
      include: {
        roles: { include: { role: true } },
        sessions: { where: { revokedAt: null, expiresAt: { gt: new Date() } } },
      },
    }),
    db.role.findMany({
      where: { isAdminRole: true, status: "ACTIVE" },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    db.auditLog.findMany({
      where: { targetId: userId },
      orderBy: { createdAt: "desc" },
      take: 20,
      include: { actor: { select: { name: true } } },
    }),
  ]);
  if (!admin || admin.isSuperAdmin) notFound();
  const assignments = new Map(
    admin.roles.map((item) => [item.roleId, item.dataScope]),
  );

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Admins", href: "/super-admin/administration/admins" },
          { label: admin.name },
        ]}
        description="Edit identity, lifecycle status, multiple roles, and role-specific data scope. Every change revokes current sessions."
        eyebrow="Admin control"
        title={admin.name}
      />
      {query.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {query.error}
        </div>
      ) : null}
      {query.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {query.success}
        </div>
      ) : null}
      <SectionCard
        title="Admin configuration"
        description={`${admin.sessions.length} active session(s). Current status: ${admin.status}.`}
      >
        <form
          action={`/api/super-admin/admins/${admin.id}`}
          className="rbac-form"
          method="post"
        >
          <div className="rbac-form-grid">
            <label>
              <span>Full name</span>
              <input defaultValue={admin.name} name="name" required />
            </label>
            <label>
              <span>Email</span>
              <input
                defaultValue={admin.email ?? ""}
                name="email"
                required
                type="email"
              />
            </label>
            <label>
              <span>Status</span>
              <select defaultValue={admin.status} name="status">
                <option value="ACTIVE">ACTIVE</option>
                <option value="SUSPENDED">SUSPENDED</option>
              </select>
            </label>
          </div>
          <fieldset className="permission-fieldset">
            <legend>Roles and individual data scope</legend>
            <div className="role-assignment-grid">
              {roles.map((role) => {
                const scope = assignments.get(role.id) ?? role.defaultDataScope;
                return (
                  <article className="role-assignment-row" key={role.id}>
                    <label className="role-choice">
                      <input
                        defaultChecked={assignments.has(role.id)}
                        name="roleId"
                        type="checkbox"
                        value={role.id}
                      />
                      <span>
                        <strong>{role.name}</strong>
                        <small>{role.description ?? role.code}</small>
                      </span>
                    </label>
                    <select
                      aria-label={`${role.name} data scope`}
                      defaultValue={scope}
                      name={`scope_${role.id}`}
                    >
                      {DATA_SCOPES.map((item) => (
                        <option key={item} value={item}>
                          {item}
                        </option>
                      ))}
                    </select>
                  </article>
                );
              })}
            </div>
          </fieldset>
          <div className="rbac-form-actions">
            <button className="ui-button ui-button-primary" type="submit">
              Save and refresh permissions
            </button>
          </div>
        </form>
        <div className="danger-zone-row">
          <div>
            <strong>Archive admin account</strong>
            <p>
              Revokes all sessions and preserves the audit trail. Archived
              accounts cannot sign in.
            </p>
          </div>
          <form
            action={`/api/super-admin/admins/${admin.id}/archive`}
            method="post"
          >
            <button className="ui-button ui-button-secondary" type="submit">
              Archive account
            </button>
          </form>
        </div>
      </SectionCard>
      <SectionCard
        title="Recent admin action history"
        description="Latest account-targeted audit events."
      >
        <div className="activity-list">
          {activities.map((event) => (
            <article key={event.id}>
              <div>
                <strong>{event.action.replaceAll("_", " ")}</strong>
                <span>
                  {event.actor?.name ?? "System"} ·{" "}
                  {event.createdAt.toISOString()}
                </span>
              </div>
              <StatusBadge tone="info">{event.targetType}</StatusBadge>
            </article>
          ))}
          {activities.length === 0 ? (
            <p>No account activity recorded.</p>
          ) : null}
        </div>
      </SectionCard>
    </>
  );
}
