import {
  ButtonLink,
  PageHeader,
  SectionCard,
  StatusBadge,
} from "@/components/ui/panel-ui";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";

const formatter = new Intl.DateTimeFormat("en-BD", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Asia/Dhaka",
});

function statusTone(
  status: string,
): "success" | "warning" | "danger" | "neutral" {
  if (status === "ACTIVE") return "success";
  if (status === "INVITED") return "warning";
  if (status === "SUSPENDED") return "danger";
  return "neutral";
}

export default async function AdminManagementPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const params = await searchParams;
  await requireSuperAdminSession();
  const now = new Date();
  const [admins, invitations] = await Promise.all([
    db.user.findMany({
      where: {
        isSuperAdmin: false,
        roles: { some: { role: { isAdminRole: true } } },
      },
      orderBy: { createdAt: "desc" },
      include: {
        roles: { include: { role: true }, orderBy: { assignedAt: "asc" } },
        sessions: {
          where: { revokedAt: null, expiresAt: { gt: now } },
          select: { id: true },
        },
      },
    }),
    db.adminInvitation.findMany({
      where: { consumedAt: null, revokedAt: null, expiresAt: { gt: now } },
      orderBy: { createdAt: "desc" },
      include: { roles: { include: { role: true } } },
    }),
  ]);

  return (
    <>
      <PageHeader
        actions={
          <ButtonLink href="/super-admin/administration/admins/create">
            Create or invite admin
          </ButtonLink>
        }
        breadcrumbs={[
          { label: "Super Admin", href: "/super-admin" },
          { label: "Administration" },
          { label: "Admins" },
        ]}
        description="Create, invite, assign multiple roles, control data scope, suspend, archive, and revoke sessions. The primary owner is protected."
        eyebrow="Admin access control"
        title="Admin management"
      />
      {params.error ? (
        <div className="panel-inline-alert panel-inline-alert-error">
          {params.error}
        </div>
      ) : null}
      {params.success ? (
        <div className="panel-inline-alert panel-inline-alert-success">
          {params.success}
        </div>
      ) : null}

      <div className="metric-grid metric-grid-four rbac-summary-grid">
        <article className="rbac-summary-card">
          <span>Admin accounts</span>
          <strong>{admins.length}</strong>
        </article>
        <article className="rbac-summary-card">
          <span>Active</span>
          <strong>
            {admins.filter((item) => item.status === "ACTIVE").length}
          </strong>
        </article>
        <article className="rbac-summary-card">
          <span>Pending invites</span>
          <strong>{invitations.length}</strong>
        </article>
        <article className="rbac-summary-card">
          <span>Active sessions</span>
          <strong>
            {admins.reduce((sum, item) => sum + item.sessions.length, 0)}
          </strong>
        </article>
      </div>

      <SectionCard
        title="Admin accounts"
        description="Archive-only lifecycle preserves audit history. System owner accounts never appear in this list."
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Admin</th>
                <th>Roles & scope</th>
                <th>Sessions</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {admins.map((admin) => (
                <tr key={admin.id}>
                  <td>
                    <strong>{admin.name}</strong>
                    <span>
                      {admin.email ?? admin.phone ?? "No contact"}
                      <br />
                      Created {formatter.format(admin.createdAt)}
                    </span>
                  </td>
                  <td>
                    <div className="table-status-stack">
                      {admin.roles.map(({ role, dataScope }) => (
                        <StatusBadge
                          key={role.id}
                          tone={role.status === "ACTIVE" ? "info" : "neutral"}
                        >
                          {role.name} · {dataScope}
                        </StatusBadge>
                      ))}
                    </div>
                  </td>
                  <td>
                    <strong>{admin.sessions.length}</strong>
                    <span>active</span>
                  </td>
                  <td>
                    <StatusBadge tone={statusTone(admin.status)}>
                      {admin.status}
                    </StatusBadge>
                  </td>
                  <td>
                    <div className="table-action-stack">
                      <ButtonLink
                        href={`/super-admin/administration/admins/${admin.id}`}
                        variant="secondary"
                      >
                        Edit
                      </ButtonLink>
                      <form
                        action={`/api/super-admin/admins/${admin.id}/revoke-sessions`}
                        method="post"
                      >
                        <button
                          className="ui-button ui-button-secondary"
                          disabled={admin.sessions.length === 0}
                          type="submit"
                        >
                          Force logout
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))}
              {admins.length === 0 ? (
                <tr>
                  <td colSpan={5}>
                    <span>No admin account has been created.</span>
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>

      <SectionCard
        title="Pending invitations"
        description="Invitation links expire automatically and can only be consumed once."
      >
        <div className="data-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Invitee</th>
                <th>Roles</th>
                <th>Created</th>
                <th>Expires</th>
              </tr>
            </thead>
            <tbody>
              {invitations.map((invite) => (
                <tr key={invite.id}>
                  <td>
                    <strong>{invite.name}</strong>
                    <span>{invite.email}</span>
                  </td>
                  <td>
                    {invite.roles
                      .map(
                        ({ role, dataScope }) => `${role.name} (${dataScope})`,
                      )
                      .join(", ")}
                  </td>
                  <td>{formatter.format(invite.createdAt)}</td>
                  <td>{formatter.format(invite.expiresAt)}</td>
                </tr>
              ))}
              {invitations.length === 0 ? (
                <tr>
                  <td colSpan={4}>
                    <span>No active invitation.</span>
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </>
  );
}
