import { ModulePage } from "@/components/ui/module-page";
import { requireSuperAdminSession } from "@/lib/auth/authorization";
import {
  breadcrumbsFromSegments,
  pageTitleFromSegments,
} from "@/lib/panel-page";

const controlTabs = [
  { label: "Departments", href: "/super-admin/control/departments" },
  { label: "User dashboard", href: "/super-admin/control/dashboard" },
  { label: "Admin panel", href: "/super-admin/control/admin-panel" },
  { label: "Public website", href: "/super-admin/control/public-site" },
  { label: "Navigation", href: "/super-admin/control/navigation" },
];

const administrationTabs = [
  { label: "Admins", href: "/super-admin/administration/admins" },
  { label: "Roles & permissions", href: "/super-admin/administration/roles" },
];

export default async function SuperAdminModulePage({
  params,
}: {
  params: Promise<{ segments: string[] }>;
}) {
  const { segments } = await params;
  const activePath = `/super-admin/${segments.join("/")}`;
  await requireSuperAdminSession(activePath);
  const section = segments[0] ?? "system";
  const title = pageTitleFromSegments(segments);
  const tabs =
    section === "control"
      ? controlTabs
      : section === "administration"
        ? administrationTabs
        : [{ label: title, href: activePath }];

  return (
    <ModulePage
      activePath={activePath}
      actionLabel={section === "administration" ? "Create admin" : "Configure"}
      baseHref={`/super-admin/${section}`}
      breadcrumbs={breadcrumbsFromSegments(
        "Super Admin",
        "/super-admin",
        segments,
      )}
      description={`Owner-level configuration for ${title.toLowerCase()}. Every change will be permission protected and audit logged when the business phase is connected.`}
      tabs={tabs}
      title={title}
    />
  );
}
