import Link from "next/link";
import { PageHeader, SectionCard } from "@/components/ui/panel-ui";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function OrderSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string }>;
}) {
  const session = await requireAuthenticatedSession("/order-success");
  const { code } = await searchParams;
  const order = code
    ? await db.commerceOrder.findFirst({
        where: { code, userId: session.user.id },
      })
    : null;
  return (
    <div className="dashboard-page">
      <PageHeader
        eyebrow="Order received"
        title={order ? `Thank you, ${order.customerName}` : "Order submitted"}
        description={
          order
            ? `Your order ${order.code} is now ${order.status.toLowerCase()}.`
            : "Open your order history to review the latest status."
        }
      />
      <SectionCard title="What happens next">
        <div className="commerce-success-actions">
          <Link
            className="ui-button ui-button-primary"
            href="/dashboard/shopping/orders"
          >
            View my orders
          </Link>
          <Link className="ui-button ui-button-secondary" href="/shop">
            Continue shopping
          </Link>
        </div>
      </SectionCard>
    </div>
  );
}
