import type { Metadata } from "next";
import Link from "next/link";
import {
  AppointmentFlash,
  DoctorAvatar,
  DoctorCard,
  SlotPicker,
} from "@/components/appointments/appointment-ui";
import { PublicShell } from "@/components/layout/public-shell";
import { Icon } from "@/components/ui/icon";
import { getCurrentSession } from "@/lib/auth/session";
import {
  getDoctorAvailability,
  listActiveDoctors,
} from "@/lib/appointments/queries";
import {
  addDaysToDateInput,
  compareDateInputs,
  formatDisplayDate,
  isDateInput,
  todayInDhaka,
} from "@/lib/appointments/time";
import { db } from "@/lib/db";
import { intlLocale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import { localizedOptionalText, localizedText } from "@/lib/i18n/content";
import { getUiPreferences } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Doctors & Appointment | Holy Life",
  description:
    "Choose a Holy Life doctor, check real availability, and request an appointment online.",
  alternates: { canonical: "/appointment" },
};

type AppointmentPageSearch = {
  doctorId?: string;
  date?: string;
  department?: string;
  success?: string;
  error?: string;
};

export default async function AppointmentPage({
  searchParams,
}: {
  searchParams: Promise<AppointmentPageSearch>;
}) {
  const params = await searchParams;
  const { locale } = await getUiPreferences();
  const numberLocale = intlLocale(locale);
  const today = todayInDhaka();
  const maximumDate = addDaysToDateInput(today, 90);
  const requestedDate = isDateInput(params.date ?? "") ? params.date! : today;
  const selectedDate =
    compareDateInputs(requestedDate, today) >= 0 &&
    compareDateInputs(requestedDate, maximumDate) <= 0
      ? requestedDate
      : today;
  const [departments, doctors, session] = await Promise.all([
    db.medicalDepartment.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
    listActiveDoctors(params.department ?? null),
    getCurrentSession(),
  ]);
  const selectedDoctorId = doctors.some(
    (doctor) => doctor.id === params.doctorId,
  )
    ? params.doctorId!
    : (doctors[0]?.id ?? "");
  const availability = selectedDoctorId
    ? await getDoctorAvailability(selectedDoctorId, selectedDate)
    : null;
  const selectedDoctor =
    availability?.doctor ??
    doctors.find((doctor) => doctor.id === selectedDoctorId) ??
    null;
  const dateChoices = Array.from({ length: 7 }, (_, index) =>
    addDaysToDateInput(today, index),
  );

  return (
    <PublicShell>
      <section className="appointment-hero">
        <div className="public-container appointment-hero-grid">
          <div>
            <span className="public-eyebrow">
              {uiText(locale, "appointment.heroEyebrow")}
            </span>
            <h1>{uiText(locale, "appointment.heroTitle")}</h1>
            <p>{uiText(locale, "appointment.heroDescription")}</p>
            <div className="appointment-hero-actions">
              <Link className="public-primary-button" href="#book">
                {uiText(locale, "appointment.book")}
              </Link>
              <Link className="public-secondary-button" href="#doctors">
                {uiText(locale, "appointment.meetDoctors")}
              </Link>
            </div>
          </div>
          <div className="appointment-trust-card">
            <div>
              <Icon name="doctor" size={21} />
              <span>
                <strong>
                  {new Intl.NumberFormat(numberLocale).format(doctors.length)}
                </strong>{" "}
                {uiText(locale, "appointment.activeDoctors")}
              </span>
            </div>
            <div>
              <Icon name="calendar" size={21} />
              <span>
                <strong>{uiText(locale, "appointment.live")}</strong>{" "}
                {uiText(locale, "appointment.scheduleCapacity")}
              </span>
            </div>
            <div>
              <Icon name="shield" size={21} />
              <span>
                <strong>{uiText(locale, "appointment.secure")}</strong>{" "}
                {uiText(locale, "appointment.patientHistory")}
              </span>
            </div>
          </div>
        </div>
      </section>

      <section className="public-section" id="book">
        <div className="public-container">
          <AppointmentFlash error={params.error} success={params.success} />
          <div className="appointment-section-heading">
            <div>
              <span className="content-kicker">
                {uiText(locale, "appointment.availability")}
              </span>
              <h2>{uiText(locale, "appointment.chooseDoctorDateTime")}</h2>
              <p>{uiText(locale, "appointment.slotDescription")}</p>
            </div>
          </div>

          <div className="appointment-booking-layout">
            <aside className="appointment-selector-card">
              <form action="/appointment" method="get">
                <label className="form-field">
                  <span>{uiText(locale, "appointment.department")}</span>
                  <select
                    defaultValue={params.department ?? ""}
                    name="department"
                  >
                    <option value="">
                      {uiText(locale, "appointment.allDepartments")}
                    </option>
                    {departments.map((department) => (
                      <option key={department.id} value={department.slug}>
                        {localizedText(
                          locale,
                          department.name,
                          department.nameBn,
                        )}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="form-field">
                  <span>{uiText(locale, "appointment.doctor")}</span>
                  <select
                    defaultValue={selectedDoctorId}
                    name="doctorId"
                    required
                  >
                    {doctors.map((doctor) => (
                      <option key={doctor.id} value={doctor.id}>
                        {localizedText(locale, doctor.name, doctor.nameBn)} —{" "}
                        {localizedText(
                          locale,
                          doctor.specialization,
                          doctor.specializationBn,
                        )}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="form-field">
                  <span>{uiText(locale, "appointment.date")}</span>
                  <input
                    min={today}
                    max={maximumDate}
                    defaultValue={selectedDate}
                    name="date"
                    required
                    type="date"
                  />
                </label>
                <button
                  className="public-primary-button public-button-full"
                  type="submit"
                >
                  {uiText(locale, "appointment.checkLive")}
                </button>
              </form>

              <div
                className="appointment-date-shortcuts"
                aria-label={uiText(locale, "appointment.nextSevenDays")}
              >
                {dateChoices.map((date) => (
                  <Link
                    className={date === selectedDate ? "is-active" : ""}
                    href={`/appointment?doctorId=${encodeURIComponent(selectedDoctorId)}&date=${date}${params.department ? `&department=${encodeURIComponent(params.department)}` : ""}#book`}
                    key={date}
                  >
                    <strong>
                      {new Date(`${date}T00:00:00Z`).toLocaleDateString(
                        numberLocale,
                        { weekday: "short", timeZone: "UTC" },
                      )}
                    </strong>
                    <span>
                      {new Intl.NumberFormat(numberLocale).format(
                        Number(date.slice(8)),
                      )}
                    </span>
                  </Link>
                ))}
              </div>
            </aside>

            <div className="appointment-booking-card">
              {selectedDoctor ? (
                <>
                  <div className="appointment-selected-doctor">
                    <DoctorAvatar
                      imageUrl={selectedDoctor.imageUrl}
                      name={localizedText(
                        locale,
                        selectedDoctor.name,
                        selectedDoctor.nameBn,
                      )}
                    />
                    <div>
                      <span className="content-kicker">
                        {localizedText(
                          locale,
                          selectedDoctor.department.name,
                          selectedDoctor.department.nameBn,
                        )}
                      </span>
                      <h3>
                        {localizedText(
                          locale,
                          selectedDoctor.name,
                          selectedDoctor.nameBn,
                        )}
                      </h3>
                      <p>
                        {localizedText(
                          locale,
                          selectedDoctor.designation,
                          selectedDoctor.designationBn,
                        )}{" "}
                        ·{" "}
                        {localizedText(
                          locale,
                          selectedDoctor.specialization,
                          selectedDoctor.specializationBn,
                        )}
                      </p>
                      {localizedOptionalText(
                        locale,
                        selectedDoctor.qualifications,
                        selectedDoctor.qualificationsBn,
                      ) ? (
                        <small>
                          {localizedOptionalText(
                            locale,
                            selectedDoctor.qualifications,
                            selectedDoctor.qualificationsBn,
                          )}
                        </small>
                      ) : null}
                      <span>
                        {formatDisplayDate(selectedDate, numberLocale)} ·{" "}
                        {uiText(locale, "appointment.consultationFee")} ৳
                        {Number(selectedDoctor.consultationFee).toLocaleString(
                          numberLocale,
                        )}
                      </span>
                    </div>
                  </div>

                  {session ? (
                    <form
                      action="/api/appointments/book"
                      className="appointment-booking-form"
                      method="post"
                    >
                      <input
                        name="doctorId"
                        type="hidden"
                        value={selectedDoctor.id}
                      />
                      <input name="date" type="hidden" value={selectedDate} />
                      <div className="form-field">
                        <span>
                          {uiText(locale, "appointment.availableTime")}
                        </span>
                        <SlotPicker
                          locale={locale}
                          slots={availability?.slots ?? []}
                        />
                      </div>
                      <div className="appointment-form-grid">
                        <label className="form-field">
                          <span>
                            {uiText(locale, "appointment.patientName")}
                          </span>
                          <input
                            defaultValue={session.user.name}
                            maxLength={100}
                            name="patientName"
                            required
                          />
                        </label>
                        <label className="form-field">
                          <span>
                            {uiText(locale, "appointment.mobileNumber")}
                          </span>
                          <input
                            defaultValue={session.user.phone ?? ""}
                            inputMode="tel"
                            maxLength={20}
                            name="patientPhone"
                            placeholder="01XXXXXXXXX"
                            required
                          />
                        </label>
                        <label className="form-field">
                          <span>{uiText(locale, "appointment.email")}</span>
                          <input
                            defaultValue={session.user.email ?? ""}
                            maxLength={254}
                            name="patientEmail"
                            type="email"
                          />
                        </label>
                        <label className="form-field">
                          <span>{uiText(locale, "appointment.service")}</span>
                          <select
                            defaultValue="Consultation"
                            name="serviceType"
                          >
                            <option value="Consultation">
                              {uiText(
                                locale,
                                "appointment.serviceConsultation",
                              )}
                            </option>
                            <option value="Follow-up">
                              {uiText(locale, "appointment.serviceFollowUp")}
                            </option>
                            <option value="Nutrition consultation">
                              {uiText(locale, "appointment.serviceNutrition")}
                            </option>
                            <option value="Fitness assessment">
                              {uiText(locale, "appointment.serviceFitness")}
                            </option>
                          </select>
                        </label>
                      </div>
                      <label className="form-field">
                        <span>{uiText(locale, "appointment.reason")}</span>
                        <textarea
                          maxLength={1000}
                          name="reason"
                          placeholder={uiText(
                            locale,
                            "appointment.reasonPlaceholder",
                          )}
                          rows={4}
                        />
                      </label>
                      <button
                        className="public-primary-button public-button-full"
                        disabled={
                          !availability?.slots.some(
                            (slot) => slot.available > 0,
                          )
                        }
                        type="submit"
                      >
                        {uiText(locale, "appointment.request")}
                      </button>
                      <p className="appointment-form-note">
                        {uiText(locale, "appointment.pendingNote")}
                      </p>
                    </form>
                  ) : (
                    <div className="appointment-signin-prompt">
                      <Icon name="lock" size={23} />
                      <h3>{uiText(locale, "appointment.signInBefore")}</h3>
                      <p>{uiText(locale, "appointment.signInDescription")}</p>
                      <div>
                        <Link
                          className="public-primary-button"
                          href={`/login?returnTo=${encodeURIComponent(`/appointment?doctorId=${selectedDoctor.id}&date=${selectedDate}`)}`}
                        >
                          {uiText(locale, "appointment.signIn")}
                        </Link>
                        <Link
                          className="public-secondary-button"
                          href="/register"
                        >
                          {uiText(locale, "appointment.createAccount")}
                        </Link>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="appointment-empty-inline">
                  <Icon name="doctor" size={24} />
                  <div>
                    <strong>{uiText(locale, "appointment.noDoctor")}</strong>
                    <span>{uiText(locale, "appointment.noDoctorHelp")}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="public-section public-section-muted" id="doctors">
        <div className="public-container">
          <div className="appointment-section-heading">
            <div>
              <span className="content-kicker">
                {uiText(locale, "appointment.clinicalTeam")}
              </span>
              <h2>{uiText(locale, "appointment.meetHolyDoctors")}</h2>
              <p>{uiText(locale, "appointment.clinicalTeamDescription")}</p>
            </div>
          </div>
          <div className="doctor-card-grid">
            {doctors.map((doctor) => (
              <DoctorCard
                doctor={doctor}
                key={doctor.id}
                locale={locale}
                selectedDate={selectedDate}
              />
            ))}
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
