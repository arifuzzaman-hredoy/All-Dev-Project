import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/layout/public-shell";
import { Icon } from "@/components/ui/icon";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
import { formatDisplayDate, formatDisplayTime } from "@/lib/appointments/time";
import { localizedText } from "@/lib/i18n/content";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export const metadata: Metadata = {
  title: "Appointment requested | Holy Life",
  robots: { index: false, follow: false },
};
export const dynamic = "force-dynamic";

export default async function AppointmentSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string }>;
}) {
  const session = await requireAuthenticatedSession("/appointment/success");
  const [{ code = "" }, { locale }] = await Promise.all([
    searchParams,
    getUiPreferences(),
  ]);
  const appointment = code
    ? await db.appointment.findFirst({
        where: { code, userId: session.user.id },
        include: { doctor: true, department: true },
      })
    : null;

  return (
    <PublicShell>
      <section className="public-section appointment-success-page">
        <div className="public-container">
          <div className="appointment-success-card">
            <span className="appointment-success-icon">
              <Icon name="appointment" size={31} />
            </span>
            <span className="content-kicker">
              {uiText(locale, "appointmentSuccess.kicker")}
            </span>
            <h1>
              {uiText(
                locale,
                appointment
                  ? "appointmentSuccess.saved"
                  : "appointmentSuccess.submitted",
              )}
            </h1>
            <p>{uiText(locale, "appointmentSuccess.description")}</p>
            {appointment ? (
              <div className="appointment-confirmation-summary">
                <div>
                  <span>{uiText(locale, "appointmentSuccess.code")}</span>
                  <strong>{appointment.code}</strong>
                </div>
                <div>
                  <span>{uiText(locale, "appointmentSuccess.doctor")}</span>
                  <strong>
                    {localizedText(
                      locale,
                      appointment.doctor.name,
                      appointment.doctor.nameBn,
                    )}
                  </strong>
                </div>
                <div>
                  <span>{uiText(locale, "appointmentSuccess.date")}</span>
                  <strong>
                    {formatDisplayDate(appointment.appointmentDate, locale)}
                  </strong>
                </div>
                <div>
                  <span>{uiText(locale, "appointmentSuccess.time")}</span>
                  <strong>
                    {formatDisplayTime(appointment.startTime, locale)}
                  </strong>
                </div>
              </div>
            ) : null}
            <div className="appointment-success-actions">
              <Link
                className="public-primary-button"
                href="/dashboard/healthcare/appointments"
              >
                {uiText(locale, "appointmentSuccess.openAppointments")}
              </Link>
              <Link className="public-secondary-button" href="/appointment">
                {uiText(locale, "appointmentSuccess.bookAnother")}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
