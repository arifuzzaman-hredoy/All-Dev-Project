"use client";

import Link from "next/link";
import { useEffect } from "react";

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("Holy Life route error", error);
  }, [error]);

  return (
    <main className="launch-error-shell">
      <section
        className="launch-error-card"
        aria-labelledby="route-error-title"
      >
        <span className="launch-error-code">Something went wrong</span>
        <h1 id="route-error-title">Holy Life could not load this page.</h1>
        <p>
          Your data was not changed by this error. Retry the page or return to
          the dashboard.
        </p>
        <div className="launch-error-actions">
          <button
            className="ui-button ui-button-primary"
            onClick={() => reset()}
            type="button"
          >
            Try again
          </button>
          <Link className="ui-button ui-button-secondary" href="/dashboard">
            Open dashboard
          </Link>
        </div>
      </section>
    </main>
  );
}
