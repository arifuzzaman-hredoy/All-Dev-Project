import type { Metadata } from "next";
import Link from "next/link";
import { ProductCard } from "@/components/commerce/product-card";
import { PublicShell } from "@/components/layout/public-shell";
import { db } from "@/lib/db";
import { listStoreProducts } from "@/lib/commerce/queries";
import { intlLocale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import { localizedText } from "@/lib/i18n/content";
import { getUiPreferences } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Healthy Shop | Holy Life",
  description: "Shop trusted wellness, nutrition and health-support products.",
};

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; q?: string }>;
}) {
  const query = await searchParams;
  const { locale } = await getUiPreferences();
  const numberLocale = intlLocale(locale);
  const [products, categories] = await Promise.all([
    listStoreProducts({ category: query.category, q: query.q }),
    db.productCategory.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
  ]);
  return (
    <PublicShell>
      <section className="commerce-hero commerce-hero-rich">
        <div className="public-container commerce-hero-layout">
          <div>
            <span className="commerce-eyebrow">
              {uiText(locale, "commerce.shopEyebrow")}
            </span>
            <h1>{uiText(locale, "commerce.shopTitle")}</h1>
            <p>{uiText(locale, "commerce.shopDescription")}</p>
            <div className="commerce-hero-actions">
              <Link className="public-primary-button" href="/cart">
                {uiText(locale, "commerce.viewCart")}
              </Link>
              <Link
                className="public-login-link"
                href="/dashboard/shopping/orders"
              >
                {uiText(locale, "commerce.myOrders")}
              </Link>
            </div>
          </div>
          <div className="commerce-hero-showcase" aria-hidden="true">
            <span>HL</span>
            <div>
              <strong>
                {locale === "bn" ? "নির্বাচিত সুস্থতা পণ্য" : "Wellness picks"}
              </strong>
              <small>
                {locale === "bn"
                  ? "স্বচ্ছ মূল্য · সহজ অর্ডার ব্যবস্থাপনা"
                  : "Clear pricing · connected orders"}
              </small>
            </div>
          </div>
        </div>
      </section>
      <section className="public-container commerce-store-section">
        <form className="commerce-filter-bar" method="get">
          <input
            aria-label={uiText(locale, "commerce.searchProducts")}
            name="q"
            placeholder={uiText(locale, "commerce.searchProductPlaceholder")}
            defaultValue={query.q ?? ""}
          />
          <select
            aria-label={uiText(locale, "commerce.category")}
            name="category"
            defaultValue={query.category ?? ""}
          >
            <option value="">{uiText(locale, "commerce.allCategories")}</option>
            {categories.map((item) => (
              <option key={item.id} value={item.slug}>
                {localizedText(locale, item.name, item.nameBn)}
              </option>
            ))}
          </select>
          <button className="public-primary-button" type="submit">
            {uiText(locale, "common.search")}
          </button>
        </form>
        <div className="commerce-section-heading">
          <div>
            <span>{uiText(locale, "commerce.catalog")}</span>
            <h2>
              {new Intl.NumberFormat(numberLocale).format(products.length)}{" "}
              {uiText(
                locale,
                products.length === 1
                  ? "commerce.product"
                  : "commerce.products",
              )}
            </h2>
          </div>
          <Link href="/cart">{uiText(locale, "commerce.cart")} →</Link>
        </div>
        {products.length ? (
          <div className="commerce-product-grid">
            {products.map((product) => (
              <ProductCard key={product.id} locale={locale} product={product} />
            ))}
          </div>
        ) : (
          <div className="commerce-empty-public">
            <h2>{uiText(locale, "commerce.noProducts")}</h2>
            <p>{uiText(locale, "commerce.trySearch")}</p>
            <Link className="public-primary-button" href="/shop">
              {uiText(locale, "commerce.resetFilters")}
            </Link>
          </div>
        )}
      </section>
    </PublicShell>
  );
}
