/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { notFound } from "next/navigation";
import { SaveButton } from "@/components/dashboard/save-button";
import { PublicShell } from "@/components/layout/public-shell";
import { getCurrentSession } from "@/lib/auth/session";
import { formatMoney } from "@/lib/commerce/money";
import { getStoreProduct } from "@/lib/commerce/queries";
import { availableStock } from "@/lib/commerce/stock";
import { isSavedItem } from "@/lib/dashboard/queries";
import { intlLocale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import { localizedOptionalText, localizedText } from "@/lib/i18n/content";
import { getUiPreferences } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const [{ slug }, query, session, preferences] = await Promise.all([
    params,
    searchParams,
    getCurrentSession(),
    getUiPreferences(),
  ]);
  const { locale } = preferences;
  const numberLocale = intlLocale(locale);
  const product = await getStoreProduct(slug);
  if (!product) notFound();
  const primary = product.images[0];
  const saved = session
    ? await isSavedItem(session.user.id, "PRODUCT", product.id)
    : false;
  const productName = localizedText(locale, product.name, product.nameBn);
  const productDescription =
    localizedOptionalText(locale, product.description, product.descriptionBn) ??
    localizedOptionalText(
      locale,
      product.shortDescription,
      product.shortDescriptionBn,
    );
  const categoryName = localizedText(
    locale,
    product.category.name,
    product.category.nameBn,
  );
  const brandName = product.brand
    ? localizedText(locale, product.brand.name, product.brand.nameBn)
    : null;
  const imageAlt = primary
    ? (localizedOptionalText(locale, primary.altText, primary.altTextBn) ??
      productName)
    : productName;

  return (
    <PublicShell>
      <section className="public-container commerce-product-detail">
        <div className="commerce-detail-media">
          {primary ? (
            <img alt={imageAlt} src={primary.url} />
          ) : (
            <span>HOLY LIFE</span>
          )}
        </div>
        <div className="commerce-detail-copy">
          <Link className="commerce-back-link" href="/shop">
            ← {uiText(locale, "commerce.backShop")}
          </Link>
          <span className="commerce-kicker">
            {categoryName}
            {brandName ? ` · ${brandName}` : ""}
          </span>
          <h1>{productName}</h1>
          <p>{productDescription}</p>
          {query.error ? (
            <div className="form-alert error">{query.error}</div>
          ) : null}
          {query.success ? (
            <div className="form-alert success">{query.success}</div>
          ) : null}
          <form
            action="/api/commerce/cart/add"
            className="commerce-add-form"
            method="post"
          >
            <input name="returnSlug" type="hidden" value={product.slug} />
            <label>
              {uiText(locale, "commerce.productOption")}
              <select name="variantId" required>
                {product.variants.map((variant) => (
                  <option
                    disabled={
                      availableStock(
                        variant.stockOnHand,
                        variant.reservedStock,
                      ) <= 0
                    }
                    key={variant.id}
                    value={variant.id}
                  >
                    {localizedText(locale, variant.name, variant.nameBn)} ·{" "}
                    {formatMoney(variant.price.toString(), "BDT", numberLocale)}{" "}
                    ·{" "}
                    {new Intl.NumberFormat(numberLocale).format(
                      availableStock(
                        variant.stockOnHand,
                        variant.reservedStock,
                      ),
                    )}{" "}
                    {uiText(locale, "commerce.available")}
                  </option>
                ))}
              </select>
            </label>
            <label>
              {uiText(locale, "commerce.quantity")}
              <input
                defaultValue="1"
                max="100"
                min="1"
                name="quantity"
                type="number"
              />
            </label>
            <button
              className="public-primary-button"
              disabled={
                !product.variants.some(
                  (variant) =>
                    availableStock(variant.stockOnHand, variant.reservedStock) >
                    0,
                )
              }
              type="submit"
            >
              {uiText(locale, "commerce.addCart")}
            </button>
          </form>
          <SaveButton
            className="public-secondary-button"
            itemType="PRODUCT"
            referenceId={product.id}
            returnTo={`/shop/${product.slug}`}
            saved={saved}
          />
          <div className="commerce-trust-list">
            <span>✓ {uiText(locale, "commerce.secureCheckout")}</span>
            <span>✓ {uiText(locale, "commerce.stockVerified")}</span>
            <span>✓ {uiText(locale, "commerce.priceCaptured")}</span>
          </div>
        </div>
      </section>
      <section className="public-container commerce-review-section">
        <h2>{uiText(locale, "commerce.customerReviews")}</h2>
        {product.reviews.length ? (
          product.reviews.map((review) => (
            <article key={review.id}>
              <strong>
                {"★".repeat(review.rating)} · {review.user.name}
              </strong>
              <h3>{review.title}</h3>
              <p>{review.body}</p>
            </article>
          ))
        ) : (
          <p>{uiText(locale, "commerce.noReviews")}</p>
        )}
      </section>
    </PublicShell>
  );
}
