import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { DoctorAvatar } from "@/components/appointments/appointment-ui";
import { SaveButton } from "@/components/dashboard/save-button";
import { PublicShell } from "@/components/layout/public-shell";
import { Icon } from "@/components/ui/icon";
import { formatDisplayTime, todayInDhaka } from "@/lib/appointments/time";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { isSavedItem } from "@/lib/dashboard/queries";
import { intlLocale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import { localizedOptionalText, localizedText } from "@/lib/i18n/content";
import { getUiPreferences } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const doctor = await db.doctorProfile.findFirst({
    where: { slug, status: "ACTIVE" },
    select: { name: true, specialization: true },
  });
  return doctor
    ? {
        title: `${doctor.name} | Holy Life`,
        description: doctor.specialization,
      }
    : { title: "Doctor not found | Holy Life" };
}

function weekdayLabel(weekday: number, locale: string): string {
  const sunday = new Date(Date.UTC(2026, 7, 9 + weekday));
  return new Intl.DateTimeFormat(locale, {
    weekday: "long",
    timeZone: "UTC",
  }).format(sunday);
}

export default async function DoctorProfilePage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ success?: string; error?: string }>;
}) {
  const [{ slug }, query, session, preferences] = await Promise.all([
    params,
    searchParams,
    getCurrentSession(),
    getUiPreferences(),
  ]);
  const { locale } = preferences;
  const numberLocale = intlLocale(locale);
  const doctor = await db.doctorProfile.findFirst({
    where: { slug, status: "ACTIVE", department: { isActive: true } },
    include: {
      department: true,
      schedules: {
        where: { isActive: true },
        orderBy: [{ weekday: "asc" }, { startTime: "asc" }],
      },
    },
  });
  if (!doctor) notFound();
  const saved = session
    ? await isSavedItem(session.user.id, "DOCTOR", doctor.id)
    : false;
  const doctorName = localizedText(locale, doctor.name, doctor.nameBn);
  const departmentName = localizedText(
    locale,
    doctor.department.name,
    doctor.department.nameBn,
  );
  const designation = localizedText(
    locale,
    doctor.designation,
    doctor.designationBn,
  );
  const specialization = localizedText(
    locale,
    doctor.specialization,
    doctor.specializationBn,
  );
  const qualifications = localizedOptionalText(
    locale,
    doctor.qualifications,
    doctor.qualificationsBn,
  );
  const bio = localizedOptionalText(locale, doctor.bio, doctor.bioBn);
  const location = localizedOptionalText(
    locale,
    doctor.location,
    doctor.locationBn,
  );
  const roomLabel = localizedOptionalText(
    locale,
    doctor.roomLabel,
    doctor.roomLabelBn,
  );

  return (
    <PublicShell>
      <section className="public-section doctor-profile-page">
        <div className="public-container doctor-profile-grid">
          <aside className="doctor-profile-card">
            <div className="doctor-profile-portrait">
              <DoctorAvatar imageUrl={doctor.imageUrl} name={doctorName} />
            </div>
            <span className="content-kicker">{departmentName}</span>
            <h1>{doctorName}</h1>
            <p>
              {designation} · {specialization}
            </p>
            {query.success ? (
              <div className="form-alert success">{query.success}</div>
            ) : null}
            {query.error ? (
              <div className="form-alert error">{query.error}</div>
            ) : null}
            <div className="doctor-profile-facts">
              <span>
                <Icon name="file" size={17} />
                {qualifications ?? uiText(locale, "doctor.clinicalConsultant")}
              </span>
              <span>
                <Icon name="activity" size={17} />
                {new Intl.NumberFormat(numberLocale).format(
                  doctor.experienceYears,
                )}{" "}
                {uiText(locale, "doctor.yearsExperience")}
              </span>
              <span>
                <Icon name="appointment" size={17} />
                {uiText(locale, "doctor.consultation")} ৳
                {Number(doctor.consultationFee).toLocaleString(numberLocale)}
              </span>
              {location ? (
                <span>
                  <Icon name="home" size={17} />
                  {location}
                  {roomLabel ? ` · ${roomLabel}` : ""}
                </span>
              ) : null}
            </div>
            <div className="public-detail-actions">
              <Link
                className="public-primary-button"
                href={`/appointment?doctorId=${doctor.id}&date=${todayInDhaka()}#book`}
              >
                {uiText(locale, "doctor.checkAvailability")}
              </Link>
              <SaveButton
                className="public-secondary-button"
                itemType="DOCTOR"
                referenceId={doctor.id}
                returnTo={`/doctors/${doctor.slug}`}
                saved={saved}
              />
            </div>
          </aside>
          <div className="doctor-profile-content">
            <div>
              <span className="content-kicker">
                {uiText(locale, "doctor.about")}
              </span>
              <h2>{uiText(locale, "doctor.clinicalProfile")}</h2>
              <p>{bio ?? uiText(locale, "doctor.defaultBio")}</p>
            </div>
            <div className="doctor-schedule-public">
              <span className="content-kicker">
                {uiText(locale, "doctor.weeklySchedule")}
              </span>
              <h2>{uiText(locale, "doctor.regularHours")}</h2>
              <div className="doctor-schedule-list">
                {doctor.schedules.map((schedule) => (
                  <div key={schedule.id}>
                    <strong>
                      {weekdayLabel(schedule.weekday, numberLocale)}
                    </strong>
                    <span>
                      {formatDisplayTime(schedule.startTime, numberLocale)} –{" "}
                      {formatDisplayTime(schedule.endTime, numberLocale)}
                    </span>
                    <small>
                      {new Intl.NumberFormat(numberLocale).format(
                        schedule.slotMinutes,
                      )}
                      -{uiText(locale, "doctor.minuteSlots")}
                      {schedule.breakStart && schedule.breakEnd
                        ? ` · ${uiText(locale, "doctor.break")} ${formatDisplayTime(schedule.breakStart, numberLocale)}–${formatDisplayTime(schedule.breakEnd, numberLocale)}`
                        : ""}
                    </small>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
