import type { Metadata } from "next";
import Link from "next/link";
import { DoctorCard } from "@/components/appointments/appointment-ui";
import { PublicShell } from "@/components/layout/public-shell";
import { listActiveDoctors } from "@/lib/appointments/queries";
import { todayInDhaka } from "@/lib/appointments/time";
import { uiText } from "@/lib/i18n/dictionary";
import { getUiPreferences } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Doctors | Holy Life",
  description:
    "Review currently active Holy Life doctor profiles and continue to appointment availability.",
  alternates: { canonical: "/doctors" },
};

export default async function DoctorsPage() {
  const [{ locale }, doctors] = await Promise.all([
    getUiPreferences(),
    listActiveDoctors(),
  ]);
  const selectedDate = todayInDhaka();

  return (
    <PublicShell>
      <section className="public-section public-section-muted doctors-directory-hero">
        <div className="public-container">
          <div className="appointment-section-heading">
            <div>
              <span className="content-kicker">
                {uiText(locale, "doctors.eyebrow")}
              </span>
              <h1>{uiText(locale, "doctors.title")}</h1>
              <p>{uiText(locale, "doctors.description")}</p>
            </div>
            <Link className="public-primary-button" href="/appointment">
              {uiText(locale, "appointment.book")}
            </Link>
          </div>
        </div>
      </section>

      <section className="public-section doctors-directory-section">
        <div className="public-container">
          {doctors.length ? (
            <div className="doctor-card-grid">
              {doctors.map((doctor) => (
                <DoctorCard
                  doctor={doctor}
                  key={doctor.id}
                  locale={locale}
                  selectedDate={selectedDate}
                />
              ))}
            </div>
          ) : (
            <div className="commerce-empty-public">
              <h2>{uiText(locale, "doctors.emptyTitle")}</h2>
              <p>{uiText(locale, "doctors.emptyDescription")}</p>
              <Link className="public-secondary-button" href="/contact">
                {uiText(locale, "doctors.contactSupport")}
              </Link>
            </div>
          )}
        </div>
      </section>
    </PublicShell>
  );
}
