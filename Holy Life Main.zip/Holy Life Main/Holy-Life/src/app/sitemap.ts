import type { MetadataRoute } from "next";

const origin = (
  process.env.APP_URL ?? "https://holylife.techteamlead.com"
).replace(/\/+$/, "");

const routes = [
  { path: "/", changeFrequency: "weekly" as const, priority: 1 },
  { path: "/about", changeFrequency: "monthly" as const, priority: 0.7 },
  { path: "/doctors", changeFrequency: "daily" as const, priority: 0.9 },
  { path: "/appointment", changeFrequency: "weekly" as const, priority: 0.9 },
  { path: "/programs", changeFrequency: "monthly" as const, priority: 0.7 },
  { path: "/courses", changeFrequency: "daily" as const, priority: 0.8 },
  { path: "/shop", changeFrequency: "daily" as const, priority: 0.8 },
  { path: "/blog", changeFrequency: "weekly" as const, priority: 0.6 },
  { path: "/contact", changeFrequency: "monthly" as const, priority: 0.5 },
  { path: "/privacy", changeFrequency: "yearly" as const, priority: 0.3 },
  { path: "/terms", changeFrequency: "yearly" as const, priority: 0.3 },
];

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();
  return routes.map((route) => ({
    url: `${origin}${route.path === "/" ? "" : route.path}`,
    lastModified,
    changeFrequency: route.changeFrequency,
    priority: route.priority,
  }));
}
