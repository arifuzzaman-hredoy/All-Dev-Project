import Link from "next/link";
import { notFound } from "next/navigation";
import { SaveButton } from "@/components/dashboard/save-button";
import { PublicShell } from "@/components/layout/public-shell";
import { getCurrentSession } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { isSavedItem } from "@/lib/dashboard/queries";
import { getPublishedCourse } from "@/lib/learning/queries";
import { intlLocale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import {
  courseLevelLabel,
  languageLabel,
  localizedList,
  localizedOptionalText,
  localizedText,
} from "@/lib/i18n/content";
import { getUiPreferences } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";

export default async function CourseDetail({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const [{ slug }, query, session, preferences] = await Promise.all([
    params,
    searchParams,
    getCurrentSession(),
    getUiPreferences(),
  ]);
  const { locale } = preferences;
  const numberLocale = intlLocale(locale);
  const course = await getPublishedCourse(slug);
  if (!course) notFound();
  const [enrollment, saved] = await Promise.all([
    session
      ? db.courseEnrollment.findUnique({
          where: {
            courseId_userId: { courseId: course.id, userId: session.user.id },
          },
          select: { id: true, status: true, progressPercent: true },
        })
      : null,
    session ? isSavedItem(session.user.id, "COURSE", course.id) : false,
  ]);
  const lessonCount = course.modules.reduce(
    (sum, module) => sum + module.lessons.length,
    0,
  );
  const firstLesson = course.modules.flatMap((module) => module.lessons)[0];
  const courseTitle = localizedText(locale, course.title, course.titleBn);
  const courseDescription =
    localizedOptionalText(
      locale,
      course.shortDescription,
      course.shortDescriptionBn,
    ) ??
    localizedOptionalText(locale, course.description, course.descriptionBn);
  const categoryName = localizedText(
    locale,
    course.category.name,
    course.category.nameBn,
  );
  const instructorName = course.instructor
    ? localizedText(locale, course.instructor.name, course.instructor.nameBn)
    : "Holy Life Academy";
  const instructorTitle = course.instructor
    ? localizedOptionalText(
        locale,
        course.instructor.title,
        course.instructor.titleBn,
      )
    : null;
  const instructorBio = course.instructor
    ? localizedOptionalText(
        locale,
        course.instructor.bio,
        course.instructor.bioBn,
      )
    : null;
  const learningOutcomes = localizedList(
    locale,
    course.learningOutcomes,
    course.learningOutcomesBn,
  );
  const requirements = localizedList(
    locale,
    course.requirements,
    course.requirementsBn,
  );

  return (
    <PublicShell>
      <main className="public-container learning-detail">
        <section className="learning-detail-hero">
          <div>
            <span className="commerce-eyebrow">{categoryName}</span>
            <h1>{courseTitle}</h1>
            <p>{courseDescription}</p>
            <div className="learning-course-stats">
              <span>
                {new Intl.NumberFormat(numberLocale).format(lessonCount)}{" "}
                {uiText(locale, "learning.lessons")}
              </span>
              <span>{courseLevelLabel(locale, course.level)}</span>
              <span>{languageLabel(locale, course.language)}</span>
            </div>
          </div>
          <aside className="learning-enroll-panel">
            <strong>
              {Number(course.price) === 0
                ? uiText(locale, "learning.free")
                : `${course.currency} ${Number(course.price).toLocaleString(numberLocale)}`}
            </strong>
            <p>{instructorName}</p>
            {query.error ? (
              <div className="form-alert error">{query.error}</div>
            ) : null}
            {query.success ? (
              <div className="form-alert success">{query.success}</div>
            ) : null}
            {enrollment && firstLesson ? (
              <Link
                className="public-primary-button"
                href={`/courses/${course.slug}/learn/${firstLesson.id}`}
              >
                {uiText(locale, "learning.continue")} ·{" "}
                {new Intl.NumberFormat(numberLocale).format(
                  enrollment.progressPercent,
                )}
                %
              </Link>
            ) : (
              <form action="/api/learning/enroll" method="post">
                <input name="courseId" type="hidden" value={course.id} />
                <input
                  name="returnTo"
                  type="hidden"
                  value={`/courses/${course.slug}`}
                />
                <button className="public-primary-button" type="submit">
                  {session
                    ? uiText(locale, "learning.enrollNow")
                    : uiText(locale, "learning.signInEnroll")}
                </button>
              </form>
            )}
            <SaveButton
              className="public-secondary-button"
              itemType="COURSE"
              referenceId={course.id}
              returnTo={`/courses/${course.slug}`}
              saved={saved}
            />
          </aside>
        </section>
        <section className="learning-detail-grid">
          <article>
            <h2>{uiText(locale, "learning.whatLearn")}</h2>
            <ul>
              {learningOutcomes.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <h2>{uiText(locale, "learning.curriculum")}</h2>
            <div className="learning-curriculum">
              {course.modules.map((module) => (
                <details key={module.id} open>
                  <summary>
                    {localizedText(locale, module.title, module.titleBn)}
                    <span>
                      {new Intl.NumberFormat(numberLocale).format(
                        module.lessons.length,
                      )}{" "}
                      {uiText(locale, "learning.lessons")}
                    </span>
                  </summary>
                  {module.lessons.map((lesson) => (
                    <div className="learning-lesson-row" key={lesson.id}>
                      <span>{lesson.type}</span>
                      <strong>
                        {localizedText(locale, lesson.title, lesson.titleBn)}
                      </strong>
                      <small>
                        {new Intl.NumberFormat(numberLocale).format(
                          lesson.durationMinutes,
                        )}{" "}
                        {uiText(locale, "learning.minute")}
                        {lesson.isPreview
                          ? ` · ${uiText(locale, "learning.preview")}`
                          : ""}
                      </small>
                    </div>
                  ))}
                </details>
              ))}
            </div>
          </article>
          <aside>
            <h2>{uiText(locale, "learning.instructor")}</h2>
            <strong>{instructorName}</strong>
            <p>{instructorTitle}</p>
            <p>{instructorBio}</p>
            <h2>{uiText(locale, "learning.requirements")}</h2>
            <ul>
              {requirements.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </aside>
        </section>
      </main>
    </PublicShell>
  );
}
