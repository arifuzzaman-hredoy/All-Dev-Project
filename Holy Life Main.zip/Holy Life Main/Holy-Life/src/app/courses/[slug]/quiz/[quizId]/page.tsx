import { notFound, redirect } from "next/navigation";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function QuizPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string; quizId: string }>;
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const { slug, quizId } = await params;
  const query = await searchParams;
  const session = await requireAuthenticatedSession(
    `/courses/${slug}/quiz/${quizId}`,
  );
  const enrollment = await db.courseEnrollment.findFirst({
    where: {
      userId: session.user.id,
      status: { in: ["ACTIVE", "COMPLETED"] },
      course: { slug },
    },
    include: { course: true },
  });
  if (!enrollment)
    redirect(
      `/courses/${slug}?error=${encodeURIComponent("Enroll before taking a quiz.")}`,
    );
  const quiz = await db.quiz.findFirst({
    where: { id: quizId, courseId: enrollment.courseId, status: "PUBLISHED" },
    include: {
      questions: {
        include: { options: { orderBy: { position: "asc" } } },
        orderBy: { position: "asc" },
      },
      attempts: {
        where: { enrollmentId: enrollment.id },
        orderBy: { attemptNumber: "desc" },
        take: 1,
      },
    },
  });
  if (!quiz) notFound();
  return (
    <main className="learning-quiz-page">
      <header>
        <span className="page-eyebrow">{enrollment.course.title}</span>
        <h1>{quiz.title}</h1>
        <p>
          Passing score {quiz.passingScore}% · Maximum {quiz.maxAttempts}{" "}
          attempts
        </p>
        {quiz.attempts[0] ? (
          <strong>Last score: {quiz.attempts[0].score}%</strong>
        ) : null}
      </header>
      {query.error ? (
        <div className="form-alert error">{query.error}</div>
      ) : null}
      {query.success ? (
        <div className="form-alert success">{query.success}</div>
      ) : null}
      <form action={`/api/learning/quizzes/${quiz.id}/submit`} method="post">
        <input
          type="hidden"
          name="returnTo"
          value={`/courses/${slug}/quiz/${quiz.id}`}
        />
        {quiz.questions.map((question) => (
          <fieldset key={question.id}>
            <legend>
              {question.position}. {question.prompt}
            </legend>
            {question.options.map((option) => (
              <label key={option.id}>
                <input
                  type="radio"
                  name={`question:${question.id}`}
                  value={option.id}
                  required
                />{" "}
                {option.label}
              </label>
            ))}
          </fieldset>
        ))}
        <button className="ui-button ui-button-primary" type="submit">
          Submit quiz
        </button>
      </form>
    </main>
  );
}
