import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import { requireAuthenticatedSession } from "@/lib/auth/authorization";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export default async function LearnPage({
  params,
}: {
  params: Promise<{ slug: string; lessonId: string }>;
}) {
  const { slug, lessonId } = await params;
  const session = await requireAuthenticatedSession(
    `/courses/${slug}/learn/${lessonId}`,
  );
  const enrollment = await db.courseEnrollment.findFirst({
    where: {
      userId: session.user.id,
      course: { slug },
      status: { in: ["ACTIVE", "COMPLETED"] },
    },
    include: {
      course: {
        include: {
          modules: {
            where: { isPublished: true },
            include: {
              lessons: {
                where: { isPublished: true },
                include: { resources: { orderBy: { position: "asc" } } },
                orderBy: { position: "asc" },
              },
              quizzes: {
                where: { status: "PUBLISHED" },
                orderBy: { position: "asc" },
              },
            },
            orderBy: { position: "asc" },
          },
        },
      },
      lessonProgress: true,
    },
  });
  if (!enrollment)
    redirect(
      `/courses/${slug}?error=${encodeURIComponent("Enroll before opening lessons.")}`,
    );
  const lessons = enrollment.course.modules.flatMap((module) => module.lessons);
  const lesson = lessons.find((item) => item.id === lessonId);
  if (!lesson) notFound();
  const currentIndex = lessons.findIndex((item) => item.id === lesson.id);
  const previous = lessons[currentIndex - 1];
  const next = lessons[currentIndex + 1];
  const progress = enrollment.lessonProgress.find(
    (item) => item.lessonId === lesson.id,
  );
  return (
    <main className="learning-player">
      <aside className="learning-player-sidebar">
        <Link href="/dashboard/learning/courses">← My courses</Link>
        <h1>{enrollment.course.title}</h1>
        <div className="learning-player-list">
          {enrollment.course.modules.map((module) => (
            <section key={module.id}>
              <strong>{module.title}</strong>
              {module.lessons.map((item) => (
                <Link
                  className={item.id === lesson.id ? "is-active" : ""}
                  href={`/courses/${slug}/learn/${item.id}`}
                  key={item.id}
                >
                  {item.title}
                </Link>
              ))}
              {module.quizzes.map((quiz) => (
                <Link href={`/courses/${slug}/quiz/${quiz.id}`} key={quiz.id}>
                  Quiz: {quiz.title}
                </Link>
              ))}
            </section>
          ))}
        </div>
      </aside>
      <section className="learning-player-main">
        <header>
          <div>
            <span className="page-eyebrow">{lesson.type}</span>
            <h2>{lesson.title}</h2>
            <p>{lesson.summary}</p>
          </div>
          <span>{enrollment.progressPercent}% complete</span>
        </header>
        {lesson.videoUrl ? (
          <div className="learning-video-placeholder">
            <a href={lesson.videoUrl} rel="noreferrer" target="_blank">
              Open lesson video
            </a>
          </div>
        ) : null}
        {lesson.content ? (
          <article className="learning-lesson-content">
            {lesson.content.split("\n").map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </article>
        ) : null}
        {lesson.resources.length ? (
          <div className="learning-resources">
            <h3>Resources</h3>
            {lesson.resources.map((resource) => (
              <a
                href={resource.url}
                key={resource.id}
                rel="noreferrer"
                target="_blank"
              >
                {resource.title}
              </a>
            ))}
          </div>
        ) : null}
        <form
          action="/api/learning/progress"
          className="learning-complete-form"
          method="post"
        >
          <input type="hidden" name="enrollmentId" value={enrollment.id} />
          <input type="hidden" name="lessonId" value={lesson.id} />
          <input type="hidden" name="completed" value="true" />
          <input
            type="hidden"
            name="returnTo"
            value={`/courses/${slug}/learn/${next?.id ?? lesson.id}`}
          />
          <button className="ui-button ui-button-primary" type="submit">
            {progress?.status === "COMPLETED" ? "Completed ✓" : "Mark complete"}
          </button>
        </form>
        <footer>
          {previous ? (
            <Link href={`/courses/${slug}/learn/${previous.id}`}>
              ← Previous
            </Link>
          ) : (
            <span />
          )}
          {next ? (
            <Link href={`/courses/${slug}/learn/${next.id}`}>Next →</Link>
          ) : (
            <Link href="/dashboard/learning/courses">Course dashboard →</Link>
          )}
        </footer>
      </section>
    </main>
  );
}
