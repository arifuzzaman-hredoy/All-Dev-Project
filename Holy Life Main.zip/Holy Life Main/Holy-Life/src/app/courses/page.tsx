import type { Metadata } from "next";
import Link from "next/link";
import { CourseCard } from "@/components/learning/course-card";
import { PublicShell } from "@/components/layout/public-shell";
import { db } from "@/lib/db";
import { listPublishedCourses } from "@/lib/learning/queries";
import { intlLocale } from "@/lib/i18n/config";
import { uiText } from "@/lib/i18n/dictionary";
import { localizedText } from "@/lib/i18n/content";
import { getUiPreferences } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Courses | Holy Life",
  description:
    "Practical health, wellness and professional learning from Holy Life.",
};

export default async function CoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; q?: string }>;
}) {
  const query = await searchParams;
  const { locale } = await getUiPreferences();
  const numberLocale = intlLocale(locale);
  const [courses, categories] = await Promise.all([
    listPublishedCourses({ category: query.category, q: query.q }),
    db.courseCategory.findMany({
      where: { isActive: true },
      orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
    }),
  ]);
  const single = courses.length === 1;
  return (
    <PublicShell>
      <section className="learning-hero learning-hero-rich">
        <div className="public-container learning-hero-layout">
          <div>
            <span className="commerce-eyebrow">
              {uiText(locale, "learning.academy")}
            </span>
            <h1>{uiText(locale, "learning.heroTitle")}</h1>
            <p>{uiText(locale, "learning.heroDescription")}</p>
            <div className="commerce-hero-actions">
              <Link className="public-primary-button" href="#course-catalog">
                {uiText(locale, "learning.exploreCourses")}
              </Link>
              <Link
                className="public-login-link"
                href="/dashboard/learning/courses"
              >
                {uiText(locale, "learning.myLearning")}
              </Link>
            </div>
          </div>
          <div className="learning-hero-showcase" aria-hidden="true">
            <span>01</span>
            <div>
              <strong>
                {locale === "bn"
                  ? "শিখুন · অনুশীলন করুন · অগ্রগতি দেখুন"
                  : "Learn · Practice · Track"}
              </strong>
              <small>
                {locale === "bn"
                  ? "এক ড্যাশবোর্ডে শেখার অগ্রগতি"
                  : "Progress in one dashboard"}
              </small>
            </div>
          </div>
        </div>
      </section>
      <section
        className="public-container learning-catalog"
        id="course-catalog"
      >
        <form className="commerce-filter-bar" method="get">
          <input
            aria-label={uiText(locale, "learning.searchCourses")}
            name="q"
            placeholder={uiText(locale, "learning.searchPlaceholder")}
            defaultValue={query.q ?? ""}
          />
          <select
            aria-label={uiText(locale, "commerce.category")}
            name="category"
            defaultValue={query.category ?? ""}
          >
            <option value="">{uiText(locale, "learning.allCategories")}</option>
            {categories.map((item) => (
              <option key={item.id} value={item.slug}>
                {localizedText(locale, item.name, item.nameBn)}
              </option>
            ))}
          </select>
          <button className="public-primary-button" type="submit">
            {uiText(locale, "common.search")}
          </button>
        </form>
        <div className="commerce-section-heading">
          <div>
            <span>{uiText(locale, "learning.courseCatalog")}</span>
            <h2>
              {new Intl.NumberFormat(numberLocale).format(courses.length)}{" "}
              {uiText(
                locale,
                courses.length === 1 ? "learning.course" : "learning.courses",
              )}
            </h2>
          </div>
          <Link href="/dashboard/learning/courses">
            {uiText(locale, "learning.studentDashboard")} →
          </Link>
        </div>
        {courses.length ? (
          <div
            className={`learning-course-grid ${single ? "learning-course-grid-single" : ""}`}
          >
            {courses.map((course) => (
              <CourseCard
                course={course}
                featured={single}
                key={course.id}
                locale={locale}
              />
            ))}
            {single ? (
              <aside className="learning-coming-card">
                <span>{uiText(locale, "learning.academy")}</span>
                <h3>{uiText(locale, "learning.moreComing")}</h3>
                <p>{uiText(locale, "learning.moreComingDescription")}</p>
                <Link
                  className="public-secondary-button"
                  href="/dashboard/learning/courses"
                >
                  {uiText(locale, "learning.viewLearningDashboard")}
                </Link>
              </aside>
            ) : null}
          </div>
        ) : (
          <div className="commerce-empty-public">
            <h2>{uiText(locale, "learning.noCourses")}</h2>
            <p>{uiText(locale, "learning.tryAnother")}</p>
            <Link className="public-primary-button" href="/courses">
              {uiText(locale, "commerce.resetFilters")}
            </Link>
          </div>
        )}
      </section>
    </PublicShell>
  );
}
