import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PublicPageRenderer } from "@/components/cms/public-page-renderer";
import { PublicShell } from "@/components/layout/public-shell";
import { getPublishedWebsitePage } from "@/lib/cms/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const page = await getPublishedWebsitePage(slug);
  if (!page) return {};
  return {
    title: page.seoTitle ?? page.title,
    description: page.seoDescription ?? page.excerpt ?? undefined,
    alternates: { canonical: page.canonicalPath ?? `/${slug}` },
  };
}

export default async function DynamicWebsitePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const page = await getPublishedWebsitePage(slug);
  if (!page) notFound();
  return (
    <PublicShell>
      <PublicPageRenderer page={page} />
    </PublicShell>
  );
}
