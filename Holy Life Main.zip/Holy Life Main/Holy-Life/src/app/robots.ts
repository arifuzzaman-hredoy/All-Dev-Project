import type { MetadataRoute } from "next";

const origin = (
  process.env.APP_URL ?? "https://holylife.techteamlead.com"
).replace(/\/+$/, "");

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: [
        "/",
        "/about",
        "/doctors",
        "/appointment",
        "/programs",
        "/courses",
        "/shop",
        "/blog",
        "/contact",
        "/privacy",
        "/terms",
      ],
      disallow: [
        "/admin",
        "/super-admin",
        "/dashboard",
        "/api",
        "/login",
        "/register",
        "/verify",
        "/forgot-password",
        "/reset-password",
        "/admin-invitation",
        "/cart",
        "/checkout",
        "/order-success",
        "/payment",
        "/website-preview",
      ],
    },
    sitemap: `${origin}/sitemap.xml`,
    host: origin,
  };
}
