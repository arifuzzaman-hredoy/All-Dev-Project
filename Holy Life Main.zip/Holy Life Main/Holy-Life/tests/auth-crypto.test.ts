import assert from "node:assert/strict";
import test from "node:test";

process.env.AUTH_SECRET =
  "test-secret-that-is-longer-than-thirty-two-characters";

const cryptoModulePromise = import("../src/lib/auth/crypto");

test("password hashes verify only the original password", async () => {
  const cryptoModule = await cryptoModulePromise;
  const password = "StrongPassword9";
  const hash = await cryptoModule.hashPassword(password);
  assert.match(hash, /^scrypt\$/);
  assert.equal(await cryptoModule.verifyPassword(password, hash), true);
  assert.equal(
    await cryptoModule.verifyPassword("WrongPassword9", hash),
    false,
  );
});

test("numeric verification codes have the requested shape", async () => {
  const cryptoModule = await cryptoModulePromise;
  assert.match(cryptoModule.createNumericCode(), /^\d{6}$/);
  assert.match(cryptoModule.createNumericCode(8), /^\d{8}$/);
  assert.throws(() => cryptoModule.createNumericCode(3));
});

test("opaque and sensitive hashes are deterministic and separated", async () => {
  const cryptoModule = await cryptoModulePromise;
  assert.equal(
    cryptoModule.hashOpaqueToken("token"),
    cryptoModule.hashOpaqueToken("token"),
  );
  assert.equal(
    cryptoModule.hashSensitiveValue("value"),
    cryptoModule.hashSensitiveValue("value"),
  );
  assert.notEqual(
    cryptoModule.hashOpaqueToken("value"),
    cryptoModule.hashSensitiveValue("value"),
  );
});
