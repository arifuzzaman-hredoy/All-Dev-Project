import assert from "node:assert/strict";
import test from "node:test";
import { buildAppointmentSlots } from "../src/lib/appointments/availability";

const mondaySchedule = {
  id: "schedule-1",
  weekday: 1,
  startTime: "09:00",
  endTime: "11:00",
  slotMinutes: 30,
  maxPatients: 1,
  breakStart: "10:00",
  breakEnd: "10:30",
  isActive: true,
};

test("weekly schedule creates slots and excludes the break", () => {
  const slots = buildAppointmentSlots({
    date: "2026-08-03",
    schedules: [mondaySchedule],
  });
  assert.deepEqual(
    slots.map((slot) => slot.startTime),
    ["09:00", "09:30", "10:30"],
  );
});

test("booked capacity marks a slot full without hiding other slots", () => {
  const slots = buildAppointmentSlots({
    date: "2026-08-03",
    schedules: [mondaySchedule],
    bookings: [{ startTime: "09:30", status: "CONFIRMED" }],
  });
  assert.equal(slots.find((slot) => slot.startTime === "09:30")?.available, 0);
  assert.equal(slots.find((slot) => slot.startTime === "09:00")?.available, 1);
});

test("cancelled and no-show records do not consume current capacity", () => {
  const slots = buildAppointmentSlots({
    date: "2026-08-03",
    schedules: [mondaySchedule],
    bookings: [
      { startTime: "09:00", status: "CANCELLED" },
      { startTime: "09:30", status: "NO_SHOW" },
    ],
  });
  assert.equal(slots.find((slot) => slot.startTime === "09:00")?.available, 1);
  assert.equal(slots.find((slot) => slot.startTime === "09:30")?.available, 1);
});

test("full-day leave removes all appointment slots", () => {
  const slots = buildAppointmentSlots({
    date: "2026-08-03",
    schedules: [mondaySchedule],
    overrides: [{ kind: "LEAVE" }],
  });
  assert.deepEqual(slots, []);
});

test("special availability replaces the normal weekly schedule", () => {
  const slots = buildAppointmentSlots({
    date: "2026-08-03",
    schedules: [mondaySchedule],
    overrides: [
      {
        kind: "AVAILABLE",
        startTime: "15:00",
        endTime: "16:00",
        slotMinutes: 20,
        maxPatients: 2,
      },
    ],
  });
  assert.deepEqual(
    slots.map((slot) => [slot.startTime, slot.capacity]),
    [
      ["15:00", 2],
      ["15:20", 2],
      ["15:40", 2],
    ],
  );
});

test("a partial blocked override removes overlapping slots only", () => {
  const slots = buildAppointmentSlots({
    date: "2026-08-03",
    schedules: [{ ...mondaySchedule, breakStart: null, breakEnd: null }],
    overrides: [{ kind: "BLOCKED", startTime: "09:30", endTime: "10:30" }],
  });
  assert.deepEqual(
    slots.map((slot) => slot.startTime),
    ["09:00", "10:30"],
  );
});
