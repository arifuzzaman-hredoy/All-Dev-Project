import assert from "node:assert/strict";
import test from "node:test";
import {
  isWebsiteSectionType,
  normalizeWebsiteSlug,
  parseSectionContent,
  validateWebsiteSlug,
} from "../src/lib/cms/content";
import { DEFAULT_WEBSITE_PAGES } from "../src/lib/cms/defaults";

test("website slugs normalize and reserved application routes are rejected", () => {
  assert.equal(
    normalizeWebsiteSlug("  Healthy Living Tips!  "),
    "healthy-living-tips",
  );
  assert.equal(validateWebsiteSlug("healthy-living-tips"), null);
  assert.notEqual(validateWebsiteSlug("admin"), null);
  assert.notEqual(validateWebsiteSlug("API"), null);
});

test("CMS section content accepts objects and rejects arrays", () => {
  assert.deepEqual(parseSectionContent('{"title":"Hello"}'), {
    title: "Hello",
  });
  assert.throws(() => parseSectionContent('["not-an-object"]'));
  assert.throws(() =>
    parseSectionContent(
      JSON.stringify({
        items: Array.from({ length: 101 }, (_, index) => index),
      }),
    ),
  );
  assert.throws(() =>
    parseSectionContent(JSON.stringify({ body: "x".repeat(12_001) })),
  );
  assert.equal(isWebsiteSectionType("HERO"), true);
  assert.equal(isWebsiteSectionType("VIDEO"), false);
});

test("default website pages have unique slugs, section keys, and required system pages", () => {
  const slugs = DEFAULT_WEBSITE_PAGES.map((page) => page.slug);
  assert.equal(new Set(slugs).size, slugs.length);
  for (const page of DEFAULT_WEBSITE_PAGES) {
    const sectionKeys = page.sections.map((section) => section.key);
    assert.equal(
      new Set(sectionKeys).size,
      sectionKeys.length,
      `duplicate section key on ${page.slug}`,
    );
    assert.ok(page.sections.length > 0, `${page.slug} must include content`);
  }
  for (const required of [
    "home",
    "about",
    "appointment",
    "courses",
    "shop",
    "contact",
    "privacy",
    "terms",
  ]) {
    assert.ok(slugs.includes(required), `missing default page: ${required}`);
  }
});
