import assert from "node:assert/strict";
import test from "node:test";
import {
  signMessagingPayload,
  verifyMessagingSignature,
} from "../src/lib/messaging/signature";

test("messaging webhook signature validates exact body and timestamp", () => {
  const secret = "test-secret-that-is-long-enough";
  const timestamp = "1770000000";
  const body = JSON.stringify({
    deliveryId: "delivery-1",
    status: "DELIVERED",
  });
  const signature = signMessagingPayload(secret, timestamp, body);
  assert.equal(
    verifyMessagingSignature({
      secret,
      timestamp,
      body,
      signature,
      nowMs: 1770000000 * 1000,
    }),
    true,
  );
  assert.equal(
    verifyMessagingSignature({
      secret,
      timestamp,
      body: `${body}x`,
      signature,
      nowMs: 1770000000 * 1000,
    }),
    false,
  );
});

test("messaging webhook signature rejects stale timestamps", () => {
  const secret = "test-secret-that-is-long-enough";
  const timestamp = "1770000000";
  const body = "{}";
  const signature = signMessagingPayload(secret, timestamp, body);
  assert.equal(
    verifyMessagingSignature({
      secret,
      timestamp,
      body,
      signature,
      nowMs: 1770000601 * 1000,
    }),
    false,
  );
});
