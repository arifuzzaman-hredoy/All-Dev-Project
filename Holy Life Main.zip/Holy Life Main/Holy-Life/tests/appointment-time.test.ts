import assert from "node:assert/strict";
import test from "node:test";
import {
  addDaysToDateInput,
  addMinutes,
  formatDisplayTime,
  isDateInput,
  timeToMinutes,
  weekdayForDateInput,
} from "../src/lib/appointments/time";

test("appointment time helpers preserve HH:mm values", () => {
  assert.equal(timeToMinutes("09:30"), 570);
  assert.equal(addMinutes("09:30", 45), "10:15");
  assert.equal(formatDisplayTime("13:05"), "1:05 PM");
});

test("date helpers use stable UTC date-only calculations", () => {
  assert.equal(isDateInput("2026-08-03"), true);
  assert.equal(isDateInput("2026-02-30"), false);
  assert.equal(weekdayForDateInput("2026-08-03"), 1);
  assert.equal(addDaysToDateInput("2026-08-31", 1), "2026-09-01");
});
