import assert from "node:assert/strict";
import test from "node:test";
import {
  renderMessageTemplate,
  templateVariables,
} from "../src/lib/messaging/template";

test("message template renders allowlisted variable values without evaluation", () => {
  const rendered = renderMessageTemplate("Hello {{ name }}, open {{appUrl}}.", {
    name: "Amina",
    appUrl: "https://example.com",
  });
  assert.equal(rendered, "Hello Amina, open https://example.com.");
});

test("message template reports variables and rejects missing values", () => {
  assert.deepEqual(templateVariables("{{name}} {{name}} {{phone}}"), [
    "name",
    "phone",
  ]);
  assert.throws(
    () => renderMessageTemplate("Hi {{name}} {{unknown}}", { name: "Amina" }),
    /unknown/,
  );
});
