import assert from "node:assert/strict";
import test from "node:test";
import {
  isValidBangladeshPhone,
  isValidEmail,
  normalizeEmail,
  normalizePhone,
  validatePassword,
} from "../src/lib/auth/normalize";

test("email and Bangladesh phone normalization", () => {
  assert.equal(normalizeEmail("  USER@Example.COM "), "user@example.com");
  assert.equal(normalizePhone("+880 1712-345678"), "01712345678");
  assert.equal(isValidBangladeshPhone("01712345678"), true);
  assert.equal(isValidEmail("user@example.com"), true);
});

test("password policy requires length and character classes", () => {
  assert.equal(validatePassword("StrongPassword9"), null);
  assert.notEqual(validatePassword("short"), null);
  assert.notEqual(validatePassword("alllowercasepassword9"), null);
  assert.notEqual(validatePassword("ALLUPPERCASEPASSWORD9"), null);
  assert.notEqual(validatePassword("NoNumberPassword"), null);
});
