import assert from "node:assert/strict";
import test from "node:test";
import {
  PERMISSION_CATALOG,
  ROLE_PRESETS,
  permissionKeysForPatterns,
  permissionMatchesPattern,
} from "../src/lib/rbac/catalog";

test("permission catalog keys are unique", () => {
  const keys = PERMISSION_CATALOG.map((item) => item.key);
  assert.equal(new Set(keys).size, keys.length);
});

test("permission wildcard patterns match nested permission keys", () => {
  assert.equal(
    permissionMatchesPattern("commerce.orders.order.view", "commerce.*"),
    true,
  );
  assert.equal(
    permissionMatchesPattern(
      "healthcare.patients.clinical-record.view",
      "healthcare.prescriptions.*",
    ),
    false,
  );
  assert.ok(permissionKeysForPatterns(["learning.*"]).length >= 10);
});

test("finance manager preset covers the Phase 9 finance permissions", () => {
  const financeManager = ROLE_PRESETS.find(
    (role) => role.code === "FINANCE_MANAGER",
  );
  assert.ok(financeManager);
  const keys = permissionKeysForPatterns(financeManager.patterns);
  for (const required of [
    "system.finance.payment.view",
    "system.finance.payment.record",
    "system.finance.payment.verify",
    "system.finance.payment.refund",
    "system.finance.gateway.view",
    "system.finance.gateway.manage",
    "system.reports.financial-report.view",
    "system.reports.financial-report.export",
    "system.notifications.notification.manage",
  ]) {
    assert.ok(
      keys.includes(required),
      `${required} should be assigned to FINANCE_MANAGER`,
    );
  }
});
