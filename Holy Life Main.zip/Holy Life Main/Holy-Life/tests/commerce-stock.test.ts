import assert from "node:assert/strict";
import test from "node:test";
import {
  applyStockDelta,
  availableStock,
  stockMovementDelta,
} from "../src/lib/commerce/stock";
test("available stock excludes reservations", () =>
  assert.equal(availableStock(20, 4), 16));
test("stock cannot become negative", () => {
  assert.equal(applyStockDelta(10, -4), 6);
  assert.throws(() => applyStockDelta(2, -3));
});
test("movement type determines signed delta", () => {
  assert.equal(stockMovementDelta("PURCHASE", 5), 5);
  assert.equal(stockMovementDelta("SALE", 5), -5);
  assert.equal(stockMovementDelta("DAMAGE_OUT", 2), -2);
});
