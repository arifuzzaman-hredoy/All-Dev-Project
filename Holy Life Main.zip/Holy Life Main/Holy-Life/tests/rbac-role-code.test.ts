import assert from "node:assert/strict";
import test from "node:test";
import { normalizeRoleCode, validateRoleCode } from "../src/lib/rbac/role-code";

test("role codes are normalized and validated", () => {
  assert.equal(normalizeRoleCode("  Course manager 2  "), "COURSE_MANAGER_2");
  assert.equal(validateRoleCode("COURSE_MANAGER_2"), true);
  assert.equal(validateRoleCode("2_INVALID"), false);
});
