import test from "node:test";
import assert from "node:assert/strict";
import {
  calculatePaymentBalance,
  paymentStatusLabel,
} from "../src/lib/finance/status";

test("unpaid account remains unpaid", () => {
  assert.equal(calculatePaymentBalance({ amountDue: 1000 }).status, "UNPAID");
});

test("pending manual reference marks pending verification", () => {
  assert.equal(
    calculatePaymentBalance({ amountDue: 1000, pendingPayments: 400 }).status,
    "PENDING_VERIFICATION",
  );
});

test("partial verified payment reports outstanding balance", () => {
  const balance = calculatePaymentBalance({
    amountDue: 1000,
    verifiedPayments: 400,
  });
  assert.equal(balance.status, "PARTIAL");
  assert.equal(balance.netPaid, 400);
  assert.equal(balance.outstanding, 600);
});

test("full verified payment marks paid", () => {
  assert.equal(
    calculatePaymentBalance({ amountDue: 1000, verifiedPayments: 1000 }).status,
    "PAID",
  );
});

test("full refund marks refunded", () => {
  const balance = calculatePaymentBalance({
    amountDue: 1000,
    openingPaidAmount: 1000,
    verifiedRefunds: 1000,
  });
  assert.equal(balance.status, "REFUNDED");
  assert.equal(balance.outstanding, 1000);
});

test("rejected payment with no verified amount marks failed", () => {
  assert.equal(
    calculatePaymentBalance({ amountDue: 1000, rejectedPayments: 500 }).status,
    "FAILED",
  );
});

test("finance status label is title cased", () => {
  assert.equal(
    paymentStatusLabel("PENDING_VERIFICATION"),
    "Pending Verification",
  );
  assert.equal(paymentStatusLabel("BANK_TRANSFER"), "Bank Transfer");
});

test("pending verification takes priority over a partial balance", () => {
  const balance = calculatePaymentBalance({
    amountDue: 1000,
    verifiedPayments: 300,
    pendingPayments: 400,
  });
  assert.equal(balance.status, "PENDING_VERIFICATION");
  assert.equal(balance.netPaid, 300);
  assert.equal(balance.outstanding, 700);
});
