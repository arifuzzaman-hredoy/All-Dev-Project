import assert from "node:assert/strict";
import test from "node:test";
import {
  calculateCourseProgress,
  isCourseComplete,
  normalizeLessonProgress,
} from "../src/lib/learning/progress";
test("normalizes progress", () => {
  assert.deepEqual(normalizeLessonProgress({ progressPercent: 45 }), {
    status: "IN_PROGRESS",
    progressPercent: 45,
  });
  assert.equal(
    normalizeLessonProgress({ completed: true }).status,
    "COMPLETED",
  );
});
test("calculates course completion", () => {
  assert.equal(calculateCourseProgress(4, 3), 75);
  assert.equal(calculateCourseProgress(0, 0), 0);
  assert.equal(isCourseComplete(4, 4), true);
});
