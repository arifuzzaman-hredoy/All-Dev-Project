import assert from "node:assert/strict";
import test from "node:test";
import {
  canTransitionEnrollment,
  enrollmentStatusLabel,
} from "../src/lib/learning/status";
test("allows valid enrollment transitions", () => {
  assert.equal(canTransitionEnrollment("ACTIVE", "COMPLETED"), true);
  assert.equal(canTransitionEnrollment("COMPLETED", "ACTIVE"), false);
  assert.equal(canTransitionEnrollment("SUSPENDED", "ACTIVE"), true);
});
test("labels status", () =>
  assert.equal(enrollmentStatusLabel("IN_PROGRESS"), "In Progress"));
