import test from "node:test";
import assert from "node:assert/strict";
import { csvCell, csvRows } from "../src/lib/finance/csv";

test("CSV cells escape quotes", () => {
  assert.equal(csvCell('a"b'), '"a""b"');
});

test("CSV cells neutralize spreadsheet formulas", () => {
  assert.equal(csvCell("=2+2"), '"\'=2+2"');
  assert.equal(csvCell("  @SUM(A1:A2)"), '"\'  @SUM(A1:A2)"');
});

test("CSV rows use CRLF line endings", () => {
  assert.equal(
    csvRows([
      ["A", "B"],
      ["1", "2"],
    ]),
    '"A","B"\r\n"1","2"',
  );
});
