import assert from "node:assert/strict";
import test from "node:test";
import {
  availableAppointmentTransitions,
  canTransitionAppointment,
} from "../src/lib/appointments/status";

test("pending appointment can be confirmed or cancelled", () => {
  assert.equal(canTransitionAppointment("PENDING", "CONFIRMED"), true);
  assert.equal(canTransitionAppointment("PENDING", "CANCELLED"), true);
  assert.equal(canTransitionAppointment("PENDING", "COMPLETED"), false);
});

test("confirmed appointment follows reception and consultation workflow", () => {
  assert.equal(canTransitionAppointment("CONFIRMED", "CHECKED_IN"), true);
  assert.equal(canTransitionAppointment("CHECKED_IN", "IN_CONSULTATION"), true);
  assert.equal(canTransitionAppointment("IN_CONSULTATION", "COMPLETED"), true);
});

test("final appointment states cannot reopen", () => {
  assert.deepEqual(availableAppointmentTransitions("COMPLETED"), []);
  assert.deepEqual(availableAppointmentTransitions("CANCELLED"), []);
  assert.deepEqual(availableAppointmentTransitions("NO_SHOW"), []);
});
