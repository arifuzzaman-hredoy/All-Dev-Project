import assert from "node:assert/strict";
import test from "node:test";

import {
  dashboardStatusTone,
  greetingForHour,
  mergeDashboardActivity,
  profileCompletion,
  titleCaseStatus,
} from "../src/lib/dashboard/status";

test("dashboard status labels and tones are stable", () => {
  assert.equal(titleCaseStatus("PENDING_VERIFICATION"), "Pending Verification");
  assert.equal(titleCaseStatus("IN_PROGRESS"), "In Progress");
  assert.equal(dashboardStatusTone("COMPLETED"), "success");
  assert.equal(dashboardStatusTone("CANCELLED"), "danger");
  assert.equal(dashboardStatusTone("PENDING"), "warning");
  assert.equal(dashboardStatusTone("ACTIVE"), "info");
});

test("dashboard greeting follows Dhaka day periods", () => {
  assert.equal(greetingForHour(8), "Good morning");
  assert.equal(greetingForHour(14), "Good afternoon");
  assert.equal(greetingForHour(20), "Good evening");
});

test("dashboard activity merges newest first and honors its limit", () => {
  const result = mergeDashboardActivity(
    [
      [
        {
          id: "older",
          department: "HEALTHCARE",
          title: "Older",
          description: "Older event",
          href: "/dashboard",
          occurredAt: new Date("2026-08-01T00:00:00.000Z"),
        },
      ],
      [
        {
          id: "newer",
          department: "COMMERCE",
          title: "Newer",
          description: "Newer event",
          href: "/dashboard",
          occurredAt: new Date("2026-08-03T00:00:00.000Z"),
        },
      ],
    ],
    1,
  );

  assert.deepEqual(
    result.map((item) => item.id),
    ["newer"],
  );
});

test("profile completion counts reusable account and health fields", () => {
  assert.equal(profileCompletion({}), 0);
  assert.equal(
    profileCompletion({
      name: "Demo Member",
      email: "member@example.com",
      phone: "01712345678",
      bloodGroup: "B+",
      dateOfBirth: new Date("2000-01-01T00:00:00.000Z"),
      emergencyContactPhone: "01812345678",
      address: "Rangpur",
    }),
    100,
  );
});
