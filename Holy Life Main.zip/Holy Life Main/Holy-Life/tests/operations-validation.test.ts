import assert from "node:assert/strict";
import test from "node:test";
import { parseOperationalReport } from "../src/lib/operations/validation";

test("parseOperationalReport accepts a completed backup run", () => {
  const result = parseOperationalReport({
    runKey: "backup-host-20260809",
    kind: "BACKUP",
    status: "SUCCEEDED",
    startedAt: "2026-08-09T02:15:00Z",
    finishedAt: "2026-08-09T02:17:00Z",
    host: "holy-life-demo",
    release: "abcdef123456",
    snapshotId: "0123456789abcdef",
    summary: "Backup completed.",
    metadata: { databaseBytes: 1234 },
  });

  assert.equal(result.kind, "BACKUP");
  assert.equal(result.status, "SUCCEEDED");
  assert.equal(result.snapshotId, "0123456789abcdef");
});

test("parseOperationalReport rejects completed runs without finishedAt", () => {
  assert.throws(
    () =>
      parseOperationalReport({
        runKey: "backup-host-20260809",
        kind: "BACKUP",
        status: "FAILED",
        startedAt: "2026-08-09T02:15:00Z",
      }),
    /requires finishedAt/,
  );
});

test("parseOperationalReport rejects invalid run kinds", () => {
  assert.throws(
    () =>
      parseOperationalReport({
        runKey: "bad-run",
        kind: "UNKNOWN",
        status: "SUCCEEDED",
        startedAt: "2026-08-09T02:15:00Z",
        finishedAt: "2026-08-09T02:16:00Z",
      }),
    /kind is invalid/,
  );
});

test("parseOperationalReport rejects oversized metadata", () => {
  assert.throws(
    () =>
      parseOperationalReport({
        runKey: "large-run",
        kind: "BACKUP",
        status: "SUCCEEDED",
        startedAt: "2026-08-09T02:15:00Z",
        finishedAt: "2026-08-09T02:16:00Z",
        metadata: { value: "x".repeat(9000) },
      }),
    /metadata is too large/,
  );
});
