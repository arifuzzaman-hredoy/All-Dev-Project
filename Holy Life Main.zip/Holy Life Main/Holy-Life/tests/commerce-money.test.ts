import assert from "node:assert/strict";
import test from "node:test";
import { couponDiscount, lineTotal, money } from "../src/lib/commerce/money";
test("money rounds to two decimals", () => {
  assert.equal(money(10.005), 10.01);
  assert.equal(money("125.678"), 125.68);
});
test("line totals preserve captured unit price", () => {
  assert.equal(lineTotal("99.99", 3), 299.97);
  assert.throws(() => lineTotal(10, 0));
});
test("fixed coupon never exceeds subtotal", () => {
  assert.equal(
    couponDiscount({ subtotal: 500, type: "FIXED", value: 700 }),
    500,
  );
});
test("percentage coupon honors maximum discount", () => {
  assert.equal(
    couponDiscount({
      subtotal: 10000,
      type: "PERCENTAGE",
      value: 10,
      maximumDiscount: 500,
    }),
    500,
  );
});
