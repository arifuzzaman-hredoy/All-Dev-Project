import assert from "node:assert/strict";
import test from "node:test";
import { scoreQuiz } from "../src/lib/learning/quiz";
test("scores quiz by weighted points", () => {
  assert.deepEqual(
    scoreQuiz([
      { points: 2, selectedOptionId: "a", correctOptionId: "a" },
      { points: 1, selectedOptionId: "x", correctOptionId: "b" },
    ]),
    { earnedPoints: 2, totalPoints: 3, score: 67 },
  );
});
