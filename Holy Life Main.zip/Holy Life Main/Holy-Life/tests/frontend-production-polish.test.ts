import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

function read(path: string): string {
  return readFileSync(path, "utf8");
}

test("Bangla is the default UI and shared copy stays centralized", () => {
  const config = read("src/lib/i18n/config.ts");
  const dictionary = read("src/lib/i18n/dictionary.ts");
  const renderer = read("src/components/cms/public-page-renderer.tsx");

  assert.match(config, /DEFAULT_LOCALE: Locale = "bn"/);
  assert.match(dictionary, /"cart\.title": "আপনার কার্ট"/);
  assert.match(dictionary, /"checkout\.title": "ডেলিভারি ও পেমেন্ট"/);
  assert.match(renderer, /bn: "চিকিৎসকের নির্দেশনা"/);
  assert.match(renderer, /bn: "গোছানো পাঠ"/);
  assert.doesNotMatch(renderer, /bn: "Doctor-led guidance"/);
});

test("Bangla navigation and shared panel chrome are Bangla-first", () => {
  const navigation = read("src/lib/i18n/navigation.ts");
  const adminLayout = read("src/app/admin/layout.tsx");
  const dashboardLayout = read("src/app/dashboard/layout.tsx");
  const superLayout = read("src/app/super-admin/layout.tsx");

  assert.match(navigation, /Home: "হোম"/);
  assert.match(navigation, /Appointment: "অ্যাপয়েন্টমেন্ট"/);
  assert.match(navigation, /"Product management": "পণ্য ব্যবস্থাপনা"/);
  assert.match(navigation, /"Roles & permissions": "রোল ও পারমিশন"/);
  assert.match(adminLayout, /"পরিচালনা কর্মক্ষেত্র"/);
  assert.match(dashboardLayout, /"সদস্য ড্যাশবোর্ড"/);
  assert.match(superLayout, /"মালিকের নিয়ন্ত্রণ কেন্দ্র"/);
});

test("language and theme controls are separate and the theme menu closes on outside interaction", () => {
  const preferences = read("src/components/ui/preferences-menu.tsx");
  const css = read("src/app/globals.css");

  assert.match(preferences, /className="locale-switcher"/);
  assert.match(preferences, />\s*BN\s*<\/button>/);
  assert.match(preferences, />\s*EN\s*<\/button>/);
  assert.match(preferences, /className={`theme-selector/);
  assert.match(
    preferences,
    /document\.addEventListener\("pointerdown", onPointerDown\)/,
  );
  assert.match(preferences, /event\.key === "Escape"/);
  assert.match(css, /\.locale-switcher/);
  assert.match(css, /\.theme-selector-menu/);
});

test("dark theme parity and doctor-card repair use semantic surfaces", () => {
  const css = read("src/app/globals.css");

  assert.match(
    css,
    /html\[data-theme="dark"\] \.public-site :is\(\.appointment-hero, \.commerce-hero, \.learning-hero\)/,
  );
  assert.match(css, /html\[data-theme="dark"\] \.locale-switcher/);
  assert.match(
    css,
    /\.public-site \.doctor-card \{[\s\S]*grid-template-columns: minmax\(0, 1fr\) !important/,
  );
});

test("home removes only its final CMS CTA", () => {
  const home = read("src/app/page.tsx");
  const renderer = read("src/components/cms/public-page-renderer.tsx");

  assert.match(home, /hideFinalCta/);
  assert.match(
    renderer,
    /hideFinalCta && index === finalCtaIndex \? null : renderSection/,
  );
});

test("bilingual managed content fields are additive in Prisma", () => {
  const schema = read("prisma/schema.prisma");
  const migration = read(
    "prisma/migrations/20260810183000_phase15_bilingual_managed_content/migration.sql",
  );

  for (const field of [
    "nameBn",
    "descriptionBn",
    "titleBn",
    "shortDescriptionBn",
    "learningOutcomesBn",
    "requirementsBn",
    "estimatedDaysBn",
  ]) {
    assert.match(schema, new RegExp(`\\b${field}\\b`));
  }
  assert.match(migration, /ADD COLUMN "nameBn" TEXT/);
  assert.match(migration, /ShippingMethod/);
  assert.doesNotMatch(migration, /DROP\s+(TABLE|COLUMN|TYPE)/i);
});

test("permission-controlled Admin routes manage bilingual healthcare, commerce and learning content", () => {
  const doctorRoute = read(
    "src/app/api/admin/healthcare/doctors/[doctorId]/route.ts",
  );
  const productRoute = read(
    "src/app/api/admin/commerce/products/[productId]/route.ts",
  );
  const categoryRoute = read(
    "src/app/api/admin/commerce/categories/[categoryId]/route.ts",
  );
  const courseRoute = read(
    "src/app/api/admin/learning/courses/[courseId]/route.ts",
  );
  const lessonRoute = read(
    "src/app/api/admin/learning/lessons/[lessonId]/route.ts",
  );
  const instructorRoute = read(
    "src/app/api/admin/learning/instructors/[instructorId]/route.ts",
  );
  const shippingRoute = read(
    "src/app/api/admin/commerce/shipping/[shippingMethodId]/route.ts",
  );

  assert.match(doctorRoute, /healthcare\.doctors\.doctor\.edit/);
  assert.match(productRoute, /commerce\.catalog\.product\.edit/);
  assert.match(categoryRoute, /commerce\.catalog\.category\.manage/);
  assert.match(courseRoute, /learning\.courses\.course\.edit/);
  assert.match(lessonRoute, /learning\.courses\.lesson\.manage/);
  assert.match(instructorRoute, /learning\.courses\.course\.edit/);
  assert.match(shippingRoute, /commerce\.shipping\.shipping\.manage/);
});

test("public doctors directory renders only active database profiles", () => {
  const page = read("src/app/doctors/page.tsx");
  const queries = read("src/lib/appointments/queries.ts");

  assert.match(page, /listActiveDoctors\(\)/);
  assert.match(page, /<DoctorCard/);
  assert.match(queries, /status: "ACTIVE"/);
  assert.doesNotMatch(page, /Dr\. Nusrat Jahan|Dr\. Farhan Kabir/);
});

test("starter catalog uses real photography and hides legacy demo clinicians", () => {
  const seed = read("prisma/seed.ts");

  assert.match(seed, /images\.unsplash\.com\/photo-1763668331599-487470fb85b2/);
  assert.match(seed, /images\.unsplash\.com\/photo-1539279006849-35e5504ce752/);
  assert.match(seed, /images\.unsplash\.com\/photo-1767404890803-228d5390fcd4/);
  assert.match(seed, /images\.unsplash\.com\/photo-1767404890803-228d5390fcd4/);
  assert.match(seed, /status: "INACTIVE", isFeatured: false/);
  assert.match(seed, /Healthy Daily Habits/);
  assert.match(seed, /Balanced Meal Basics/);
  assert.match(seed, /Safe Home Movement/);
  assert.doesNotMatch(seed, /Phase 6 demo opening stock/);
  assert.doesNotMatch(seed, /Demo Member/);
});

test("cart, checkout and appointment confirmation consume localized database content", () => {
  const cart = read("src/components/commerce/cart-view.tsx");
  const checkout = read("src/app/checkout/page.tsx");
  const success = read("src/app/appointment/success/page.tsx");

  assert.match(
    cart,
    /localizedText\(locale, item\.variant\.product\.name, item\.variant\.product\.nameBn\)/,
  );
  assert.match(
    checkout,
    /localizedText\(locale, method\.name, method\.nameBn\)/,
  );
  assert.match(
    success,
    /localizedText\(locale, appointment\.doctor\.name, appointment\.doctor\.nameBn\)/,
  );
});

test("Phase B lint guard keeps seed and preference handlers React/Next-safe", () => {
  const seed = read("prisma/seed.ts");
  const preferences = read("src/components/ui/preferences-menu.tsx");

  assert.doesNotMatch(seed, /\b(?:const|let|var)\s+module\b/);
  assert.match(seed, /const courseModule = await prisma\.courseModule\.upsert/);
  assert.match(
    preferences,
    /document\.documentElement\.dataset\.locale = locale/,
  );
  assert.match(
    preferences,
    /document\.documentElement\.dataset\.themePreference = themePreference/,
  );
  assert.doesNotMatch(
    preferences,
    /writePreferenceCookie\(THEME_COOKIE, nextTheme\);\s*document\.documentElement/,
  );
  assert.doesNotMatch(
    preferences,
    /writePreferenceCookie\(LOCALE_COOKIE, nextLocale\);\s*document\.documentElement/,
  );
});

test("learning starter seed preserves existing lesson positions instead of colliding", () => {
  const seed = read("prisma/seed.ts");

  assert.match(seed, /const occupiedLessonPositions = new Set/);
  assert.match(
    seed,
    /resolveSeedPosition\(\s*lessonPosition,\s*occupiedLessonPositions,\s*\)/,
  );
  assert.match(seed, /position: resolvedLessonPosition/);
  assert.match(seed, /occupiedLessonPositions\.add\(createdLesson\.position\)/);
  assert.doesNotMatch(
    seed,
    /courseLesson\.create\(\{[\s\S]{0,1200}position: lessonPosition/,
  );
});
