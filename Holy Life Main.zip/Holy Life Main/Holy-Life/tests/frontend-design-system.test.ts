import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

function read(path: string): string {
  return readFileSync(path, "utf8");
}

test("root bootstraps locale and light/dark/system preference before hydration", () => {
  const layout = read("src/app/layout.tsx");
  const config = read("src/lib/i18n/config.ts");
  const preferences = read("src/components/ui/preferences-menu.tsx");

  assert.match(layout, /data-theme-preference=\{themePreference\}/);
  assert.match(layout, /dangerouslySetInnerHTML/);
  assert.match(layout, /prefers-color-scheme: dark/);
  assert.match(config, /export type Locale = "bn" \| "en"/);
  assert.match(
    config,
    /export type ThemePreference = "light" \| "dark" \| "system"/,
  );
  assert.match(preferences, /THEME_STORAGE_KEY/);
  assert.match(preferences, /LOCALE_STORAGE_KEY/);
  assert.match(preferences, /media\.addEventListener\("change"/);
});

test("bilingual UI is centralized and default CMS content is translated safely", () => {
  const dictionary = read("src/lib/i18n/dictionary.ts");
  const defaults = read("src/lib/i18n/default-cms.ts");
  const publicRenderer = read("src/components/cms/public-page-renderer.tsx");

  assert.match(dictionary, /const en = \{/);
  assert.match(dictionary, /const bn: Record<keyof typeof en, string> = \{/);
  assert.match(dictionary, /"home\.quickTitle": "আজ আপনি কী করতে চান\?"/);
  assert.match(
    defaults,
    /authorized editor enters in the CMS is preserved verbatim/,
  );
  assert.match(publicRenderer, /localizeDefaultCmsText/);
});

test("public heroes are context-aware instead of repeating one generic glass panel", () => {
  const renderer = read("src/components/cms/public-page-renderer.tsx");
  const css = read("src/app/globals.css");

  assert.match(
    renderer,
    /type HeroVisualVariant = "health" \| "doctors" \| "appointment" \| "learning" \| "commerce" \| "about"/,
  );
  assert.match(renderer, /cms-hero-visual-\$\{variant\}/);
  assert.doesNotMatch(renderer, /Care, learn, and live healthier/);
  assert.match(css, /\.cms-hero-visual-commerce/);
  assert.match(css, /\.cms-hero-visual-learning/);
});

test("mobile public navigation is truly off canvas and page-level horizontal overflow is blocked", () => {
  const css = read("src/app/globals.css");
  const menu = read("src/components/layout/public-mobile-menu.tsx");

  assert.match(css, /html,\s*\nbody \{[\s\S]*overflow-x: clip/);
  assert.match(
    css,
    /\.public-mobile-drawer \{[\s\S]*max-width: 320px;[\s\S]*visibility: hidden;[\s\S]*pointer-events: none;[\s\S]*translate3d\(104%,0,0\)/,
  );
  assert.match(
    css,
    /\.public-mobile-drawer\.is-open \{[\s\S]*visibility: visible;[\s\S]*pointer-events: auto;[\s\S]*translate3d\(0,0,0\)/,
  );
  assert.match(menu, /inert=\{!open \? true : undefined\}/);
  assert.match(menu, /document\.body\.style\.overflow = "hidden"/);
});

test("doctor cards cannot overlap action buttons and single-course catalog has an intentional featured state", () => {
  const css = read("src/app/globals.css");
  const courses = read("src/app/courses/page.tsx");

  assert.match(css, /\.doctor-card \{[\s\S]*grid-template-rows: auto 1fr auto/);
  assert.match(
    css,
    /\.doctor-card-actions \{[\s\S]*position: static !important;[\s\S]*grid-template-columns: repeat\(2,minmax\(0,1fr\)\)/,
  );
  assert.match(courses, /learning-course-grid-single/);
  assert.match(courses, /learning-coming-card/);
});

test("dark mode uses semantic layered surfaces across public, auth, panels, tables and forms", () => {
  const css = read("src/app/globals.css");

  assert.match(css, /--hl-background: #0b1417/);
  assert.match(css, /--hl-surface: #121c20/);
  assert.match(css, /--hl-surface-raised: #182428/);
  assert.match(css, /html\[data-theme="dark"\] \.public-site/);
  assert.match(css, /html\[data-theme="dark"\] \.auth-card/);
  assert.match(
    css,
    /html\[data-theme="dark"\] :is\(\.data-table,\.simple-table\) th/,
  );
  assert.match(css, /html\[data-theme="dark"\] :is\(input,select,textarea\)/);
});

test("Bangla and English share identical typography sizing and spacing rules", () => {
  const css = read("src/app/globals.css");

  assert.match(
    css,
    /font-family: Inter, "Noto Sans Bengali", "Hind Siliguri", "Nirmala UI"/,
  );
  assert.match(
    css,
    /body,\s*\nbutton,\s*\ninput,\s*\nselect,\s*\ntextarea \{\s*\n  font: inherit;/,
  );
  assert.doesNotMatch(css, /html\[lang\^="bn"\]/);
  assert.doesNotMatch(css, /line-height: 1\.68/);
  assert.match(css, /@media \(max-width: 480px\)/);
  assert.match(css, /@media \(max-width: 760px\)/);
  assert.match(css, /@media \(max-width: 900px\)/);
  assert.match(css, /@media \(max-width: 1180px\)/);
});

test("frontend shell avoids lint-unsafe render/effect patterns", () => {
  const menu = read("src/components/layout/public-mobile-menu.tsx");
  const layout = read("src/app/layout.tsx");

  assert.doesNotMatch(menu, /useEffect\(\(\) => close\(\), \[pathname\]\)/);
  assert.match(
    menu,
    /const \[openPath, setOpenPath\] = useState<string \| null>\(null\)/,
  );
  assert.match(menu, /const open = openPath === pathname/);
  assert.match(
    menu,
    /setOpenPath\(\(current\) => \(current === pathname \? null : pathname\)\)/,
  );
  assert.doesNotMatch(layout, /catch \(_\)/);
  assert.match(layout, /catch \{\}/);
});

test("public desktop header keeps navigation and account actions on one line", () => {
  const css = read("src/app/globals.css");
  const dictionary = read("src/lib/i18n/dictionary.ts");

  assert.match(css, /Public header single-line hardening/);
  assert.match(
    css,
    /\.public-header \.public-container \{[\s\S]*width: min\(1460px, calc\(100% - 48px\)\)/,
  );
  assert.match(
    css,
    /\.public-header \.public-nav-links a,[\s\S]*white-space: nowrap/,
  );
  assert.match(
    css,
    /\.public-header \.public-nav-actions \{[\s\S]*white-space: nowrap/,
  );
  assert.match(
    css,
    /@media \(min-width: 1025px\) and \(max-width: 1280px\) \{[\s\S]*\.public-header \.public-nav-links \{[\s\S]*display: none/,
  );
  assert.match(dictionary, /"public\.createAccount": "অ্যাকাউন্ট তৈরি"/);
  assert.match(dictionary, /"appointment\.createAccount": "অ্যাকাউন্ট তৈরি"/);
  assert.doesNotMatch(
    dictionary,
    /"public\.createAccount": "অ্যাকাউন্ট তৈরি করুন"/,
  );
});
