import assert from "node:assert/strict";
import test from "node:test";
import { broaderDataScope, effectiveDataScope } from "../src/lib/rbac/scope";

test("broader data scope wins across multiple roles", () => {
  assert.equal(broaderDataScope("ASSIGNED", "DEPARTMENT"), "DEPARTMENT");
  assert.equal(effectiveDataScope(["OWN", "ASSIGNED", "ALL"]), "ALL");
});
