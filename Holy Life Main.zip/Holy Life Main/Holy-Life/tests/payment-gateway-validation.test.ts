import assert from "node:assert/strict";
import test from "node:test";
import {
  gatewayAmount,
  gatewayEvidenceIssue,
  GatewayValidationError,
} from "../src/lib/payments/gateway/validation";

test("SSLCOMMERZ amount limits are enforced", () => {
  assert.equal(gatewayAmount("10"), 10);
  assert.equal(gatewayAmount("500000"), 500000);
  assert.throws(() => gatewayAmount("9.99"), GatewayValidationError);
  assert.throws(() => gatewayAmount("500000.01"), GatewayValidationError);
  assert.throws(() => gatewayAmount("10.001"), GatewayValidationError);
});

test("gateway evidence requires exact transaction, amount and currency", () => {
  const expected = {
    attemptId: "attempt-1",
    accountId: "account-1",
    transactionId: "HL123",
    amount: "100.00",
    currency: "BDT",
  };

  assert.equal(
    gatewayEvidenceIssue(expected, {
      status: "VALIDATED",
      transactionId: "HL123",
      amount: "100.00",
      currency: "BDT",
      attemptReference: "attempt-1",
      accountReference: "account-1",
      riskLevel: 0,
    }),
    null,
  );
  assert.equal(
    gatewayEvidenceIssue(expected, {
      status: "VALID",
      transactionId: "OTHER",
      amount: 100,
      currency: "BDT",
    }),
    "TRANSACTION_ID_MISMATCH",
  );
  assert.equal(
    gatewayEvidenceIssue(expected, {
      status: "VALID",
      transactionId: "HL123",
      amount: 101,
      currency: "BDT",
    }),
    "AMOUNT_MISMATCH",
  );
  assert.equal(
    gatewayEvidenceIssue(expected, {
      status: "VALID",
      transactionId: "HL123",
      amount: 100,
      currency: "USD",
    }),
    "CURRENCY_MISMATCH",
  );
});

test("high-risk gateway evidence requires review", () => {
  assert.equal(
    gatewayEvidenceIssue(
      {
        attemptId: "a",
        accountId: "b",
        transactionId: "c",
        amount: 100,
        currency: "BDT",
      },
      {
        status: "VALID",
        transactionId: "c",
        amount: 100,
        currency: "BDT",
        riskLevel: 1,
      },
    ),
    "RISK_LEVEL_HIGH",
  );
});

test("missing currency or risk evidence never auto-credits", () => {
  const expected = {
    attemptId: "attempt-1",
    accountId: "account-1",
    transactionId: "HL123",
    amount: "100.00",
    currency: "BDT",
  };

  assert.equal(
    gatewayEvidenceIssue(expected, {
      status: "VALID",
      transactionId: "HL123",
      amount: "100.00",
      riskLevel: 0,
    }),
    "CURRENCY_MISSING",
  );
  assert.equal(
    gatewayEvidenceIssue(expected, {
      status: "VALID",
      transactionId: "HL123",
      amount: "100.00",
      currency: "BDT",
    }),
    "RISK_LEVEL_MISSING",
  );
});
