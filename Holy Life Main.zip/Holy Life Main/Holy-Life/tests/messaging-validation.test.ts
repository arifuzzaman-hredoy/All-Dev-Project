import assert from "node:assert/strict";
import test from "node:test";
import { parseConfiguredChannels } from "../src/lib/messaging/config";
import {
  maskedTarget,
  messagingChannel,
  templateCode,
} from "../src/lib/messaging/validation";

test("configured messaging channels are normalized and deduplicated", () => {
  assert.deepEqual(parseConfiguredChannels(" email, SMS,email , whatsapp "), [
    "EMAIL",
    "SMS",
    "WHATSAPP",
  ]);
  assert.throws(() => parseConfiguredChannels("PUSH"), /unsupported channel/);
});

test("messaging validation accepts supported channels and strict template codes", () => {
  assert.equal(messagingChannel("email"), "EMAIL");
  assert.equal(templateCode("appointment_reminder"), "APPOINTMENT_REMINDER");
  assert.throws(() => templateCode("bad-code"), /Template code/);
});

test("recipient masking keeps only minimal delivery troubleshooting context", () => {
  assert.equal(maskedTarget("member@example.com"), "me***@example.com");
  assert.equal(maskedTarget("01700123456"), "*******3456");
});
