import assert from "node:assert/strict";
import test from "node:test";
import {
  appointmentAccessWhere,
  dataScopeForPermission,
} from "../src/lib/appointments/access";
import type { AuthenticatedUser } from "../src/lib/auth/session";

function user(
  scope: "OWN" | "ASSIGNED" | "DEPARTMENT" | "BRANCH" | "ALL",
  isSuperAdmin = false,
): AuthenticatedUser {
  return {
    id: "user-1",
    name: "User",
    email: null,
    phone: null,
    status: "ACTIVE",
    isSuperAdmin,
    emailVerifiedAt: null,
    phoneVerifiedAt: null,
    roles: [
      {
        code: "ROLE",
        name: "Role",
        isAdminRole: true,
        isMasterAdmin: false,
        status: "ACTIVE",
        dataScope: scope,
        permissions: ["healthcare.appointments.appointment.view"],
      },
    ],
  };
}

test("super admin receives all data scope", () => {
  assert.equal(
    dataScopeForPermission(
      user("OWN", true),
      "healthcare.appointments.appointment.view",
    ),
    "ALL",
  );
  assert.deepEqual(appointmentAccessWhere(user("OWN", true)), {});
});

test("assigned appointment scope restricts to linked doctor", () => {
  assert.deepEqual(appointmentAccessWhere(user("ASSIGNED")), {
    doctor: { userId: "user-1" },
  });
});

test("own appointment scope allows patient, creator, or linked doctor records", () => {
  const where = appointmentAccessWhere(user("OWN"));
  assert.ok(Array.isArray(where.OR));
  assert.equal(where.OR?.length, 3);
});
