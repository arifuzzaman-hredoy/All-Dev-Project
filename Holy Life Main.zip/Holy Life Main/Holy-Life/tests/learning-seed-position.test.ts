import assert from "node:assert/strict";
import test from "node:test";
import { resolveSeedPosition } from "../prisma/seed-utils";

test("seed lesson keeps its preferred position when it is free", () => {
  assert.equal(resolveSeedPosition(2, new Set([1, 3])), 2);
});

test("seed lesson moves forward without overwriting occupied positions", () => {
  assert.equal(resolveSeedPosition(1, new Set([1, 2, 3])), 4);
  assert.equal(resolveSeedPosition(2, new Set([2, 3, 5])), 4);
});

test("seed lesson normalizes invalid preferred positions to the first free positive slot", () => {
  assert.equal(resolveSeedPosition(0, new Set([1, 2])), 3);
  assert.equal(resolveSeedPosition(-5, new Set()), 1);
});
