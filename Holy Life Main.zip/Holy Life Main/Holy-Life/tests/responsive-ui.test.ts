import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

function read(path: string): string {
  return readFileSync(path, "utf8");
}

test("public navigation has a real mobile drawer", () => {
  const shell = read("src/components/layout/public-shell.tsx");
  const mobileMenu = read("src/components/layout/public-mobile-menu.tsx");
  const css = read("src/app/globals.css");

  assert.match(shell, /<PublicMobileMenu/);
  assert.match(mobileMenu, /public-mobile-drawer/);
  assert.match(mobileMenu, /aria-expanded=\{open\}/);
  assert.match(css, /@media \(max-width: 1024px\)/);
  assert.match(css, /\.public-mobile-menu-wrap \{ display: block; \}/);
});

test("responsive overhaul keeps panels, tables, forms and touch targets usable", () => {
  const css = read("src/app/globals.css");
  assert.match(css, /2026 responsive \+ typography system overhaul/);
  assert.match(css, /\.sidebar-link \{ min-height: 46px;/);
  assert.match(css, /\.simple-table,\s*\.data-table \{ min-width: 720px; \}/);
  assert.match(
    css,
    /\.filter-panel,[\s\S]*\.finance-review-row,[\s\S]*grid-template-columns: 1fr;/,
  );
  assert.match(css, /@media \(hover: none\) and \(pointer: coarse\)/);
});

test("home page keeps premium task and confidence sections but removes the mismatched final CTA", () => {
  const home = read("src/app/page.tsx");
  const renderer = read("src/components/cms/public-page-renderer.tsx");
  const experience = read("src/components/home/home-experience.tsx");

  assert.match(home, /insertBeforeFinalCta=\{<HomeExperience \/>\}/);
  assert.match(home, /hideFinalCta/);
  assert.match(renderer, /insertBeforeFinalCta\?: ReactNode/);
  assert.match(renderer, /hideFinalCta\?: boolean/);
  assert.match(experience, /home\.quickTitle/);
  assert.match(experience, /home\.confidenceTitle/);
  assert.match(experience, /getUiPreferences/);
});
test("public site keeps the premium multi-department color system scoped away from admin panels", () => {
  const css = read("src/app/globals.css");
  assert.match(css, /2026 public colorful premium refinement/);
  assert.match(css, /\.public-site \{\s*--public-health:/);
  assert.match(css, /\.public-site \.cms-hero-commerce/);
  assert.match(css, /\.public-site \.home-tone-learning/);
  assert.match(css, /\.public-site \.public-footer::before/);
  assert.doesNotMatch(css, /\.panel-app\s*\{[^}]*--public-health:/);
});
