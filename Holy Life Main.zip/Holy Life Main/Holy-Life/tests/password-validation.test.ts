import assert from "node:assert/strict";
import test from "node:test";
import { validatePassword } from "../src/lib/auth/normalize";

test("password policy accepts a valid six-character password", () => {
  assert.equal(validatePassword("Abc123"), null);
});

test("password policy rejects fewer than six characters", () => {
  assert.match(validatePassword("Ab12") ?? "", /at least 6 characters/);
});

test("password policy preserves letter and number requirements", () => {
  assert.match(validatePassword("abcdef") ?? "", /uppercase/);
  assert.match(validatePassword("ABCDEF") ?? "", /lowercase/);
  assert.match(validatePassword("Abcdef") ?? "", /number/);
});
