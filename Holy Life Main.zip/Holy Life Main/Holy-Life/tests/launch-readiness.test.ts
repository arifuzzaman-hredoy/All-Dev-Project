import assert from "node:assert/strict";
import test from "node:test";
import {
  LAUNCH_ACCEPTANCE_GATES,
  acceptedLaunchGateCount,
  launchAcceptanceNote,
  parseLaunchAcceptance,
  withLaunchAcceptanceUpdate,
} from "../src/lib/launch/validation";
import { evidenceCheck, readinessSummary } from "../src/lib/launch/status";

test("launch acceptance defaults every gate to pending", () => {
  const state = parseLaunchAcceptance(null);
  assert.equal(acceptedLaunchGateCount(state), 0);
  for (const gate of LAUNCH_ACCEPTANCE_GATES) {
    assert.equal(state[gate.key].status, "PENDING");
  }
});

test("launch acceptance preserves only supported values", () => {
  const state = parseLaunchAcceptance({
    paymentSandbox: {
      status: "PASSED",
      updatedAt: "2026-08-09T10:00:00.000Z",
      updatedBy: "Owner",
      note: "Verified.",
    },
    clinicalBrowser: {
      status: "UNKNOWN",
    },
  });

  assert.equal(state.paymentSandbox.status, "PASSED");
  assert.equal(state.clinicalBrowser.status, "PENDING");
});

test("launch acceptance update is immutable and counted", () => {
  const initial = parseLaunchAcceptance(null);
  const updated = withLaunchAcceptanceUpdate(initial, {
    key: "paymentSandbox",
    status: "PASSED",
    updatedAt: "2026-08-09T10:00:00.000Z",
    updatedBy: "Owner",
    note: null,
  });

  assert.equal(initial.paymentSandbox.status, "PENDING");
  assert.equal(updated.paymentSandbox.status, "PASSED");
  assert.equal(acceptedLaunchGateCount(updated), 1);
});

test("launch acceptance note rejects over-limit text", () => {
  assert.throws(() => launchAcceptanceNote("x".repeat(501)), /500 characters/);
});

test("evidenceCheck blocks missing and stale evidence", () => {
  const missing = evidenceCheck({
    key: "backup",
    label: "Backup",
    date: null,
    maxAgeHours: 36,
    missingDetail: "missing",
    staleDetail: (hours) => `stale ${hours}`,
  });
  assert.equal(missing.status, "BLOCK");

  const stale = evidenceCheck({
    key: "backup",
    label: "Backup",
    date: new Date("2026-08-01T00:00:00.000Z"),
    maxAgeHours: 36,
    missingDetail: "missing",
    staleDetail: (hours) => `stale ${hours}`,
  });
  assert.equal(stale.status, "BLOCK");
});

test("readinessSummary never marks ready while manual gates remain", () => {
  const state = parseLaunchAcceptance(null);
  const summary = readinessSummary(
    [
      {
        key: "https",
        label: "HTTPS",
        detail: "ok",
        status: "PASS",
        group: "CONFIGURATION",
      },
    ],
    state,
  );

  assert.equal(summary.blockers, 0);
  assert.equal(summary.manualPending, LAUNCH_ACCEPTANCE_GATES.length);
  assert.equal(summary.ready, false);
});

test("readinessSummary becomes ready only with zero blockers and all manual gates accepted", () => {
  let state = parseLaunchAcceptance(null);
  for (const gate of LAUNCH_ACCEPTANCE_GATES) {
    state = withLaunchAcceptanceUpdate(state, {
      key: gate.key,
      status: "PASSED",
      updatedAt: "2026-08-09T10:00:00.000Z",
      updatedBy: "Owner",
      note: null,
    });
  }

  const summary = readinessSummary(
    [
      {
        key: "https",
        label: "HTTPS",
        detail: "ok",
        status: "PASS",
        group: "CONFIGURATION",
      },
      {
        key: "messaging",
        label: "Messaging",
        detail: "optional",
        status: "WARN",
        group: "CONFIGURATION",
      },
    ],
    state,
  );

  assert.equal(summary.blockers, 0);
  assert.equal(summary.manualPending, 0);
  assert.equal(summary.ready, true);
});
