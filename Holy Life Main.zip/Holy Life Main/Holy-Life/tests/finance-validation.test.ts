import test from "node:test";
import assert from "node:assert/strict";
import {
  dashboardHref,
  manualPaymentMethod,
  optionalFinanceText,
  positiveMoney,
  reportDate,
} from "../src/lib/finance/validation";

test("positiveMoney accepts two decimal places", () => {
  assert.equal(positiveMoney("400.25"), 400.25);
});

test("positiveMoney rejects zero and negative values", () => {
  assert.throws(() => positiveMoney("0"));
  assert.throws(() => positiveMoney("-1"));
});

test("manual payment method accepts local options", () => {
  assert.equal(manualPaymentMethod("BKASH"), "BKASH");
  assert.equal(manualPaymentMethod("BANK_TRANSFER"), "BANK_TRANSFER");
});

test("manual payment method rejects gateway-like values", () => {
  assert.throws(() => manualPaymentMethod("SSLCOMMERZ"));
  assert.throws(() => manualPaymentMethod("STRIPE"));
});

test("optional finance text enforces maximum length", () => {
  assert.equal(optionalFinanceText(" ref-123 ", 20), "ref-123");
  assert.throws(() => optionalFinanceText("123456", 5));
});

test("report date resolves Bangladesh day boundaries", () => {
  assert.equal(
    reportDate("2026-08-08")?.toISOString(),
    "2026-08-07T18:00:00.000Z",
  );
  assert.equal(
    reportDate("2026-08-08", true)?.toISOString(),
    "2026-08-08T17:59:59.999Z",
  );
});

test("report date rejects impossible calendar dates", () => {
  assert.throws(() => reportDate("2026-02-30"));
  assert.throws(() => reportDate("2026-13-01"));
});

test("dashboard notification links stay internal", () => {
  assert.equal(dashboardHref("/dashboard/payments"), "/dashboard/payments");
  assert.throws(() => dashboardHref("https://example.com"));
  assert.throws(() => dashboardHref("//example.com"));
});
