import { createHash } from "node:crypto";
import assert from "node:assert/strict";
import test from "node:test";
import { verifySslCommerzIpnSignature } from "../src/lib/payments/gateway/signature";

function md5(value: string): string {
  return createHash("md5").update(value, "utf8").digest("hex");
}

function signedForm(storePassword: string) {
  const form = new FormData();
  form.set("amount", "100.00");
  form.set("status", "VALID");
  form.set("tran_id", "HL123");
  form.set("val_id", "VAL123");
  form.set("verify_key", "status,amount,val_id,tran_id");
  const hashString = [
    "amount=100.00",
    "status=VALID",
    `store_passwd=${md5(storePassword)}`,
    "tran_id=HL123",
    "val_id=VAL123",
  ].join("&");
  form.set("verify_sign", md5(hashString));
  return form;
}

test("SSLCOMMERZ IPN hash validation accepts untampered payload", () => {
  assert.equal(
    verifySslCommerzIpnSignature(
      signedForm("merchant-password"),
      "merchant-password",
    ),
    true,
  );
});

test("SSLCOMMERZ IPN hash validation rejects tampering", () => {
  const form = signedForm("merchant-password");
  form.set("amount", "999.00");
  assert.equal(verifySslCommerzIpnSignature(form, "merchant-password"), false);
});
