import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();
const read = (path: string) => readFileSync(join(root, path), "utf8");

test("primary auth forms use browser-native POST redirects", () => {
  const source = read("src/components/auth/auth-redirect-form.tsx");
  assert.match(source, /method="post"/);
  assert.doesNotMatch(source, /fetch\(/);
  assert.doesNotMatch(source, /onSubmit=/);
  assert.doesNotMatch(source, /useRouter/);
});

test("Super Admin has a dedicated /super-admin login backed by server env credentials", () => {
  const page = read("src/app/super-admin/page.tsx");
  const route = read("src/app/api/super-admin/login/route.ts");
  const dictionary = read("src/lib/i18n/dictionary.ts");

  assert.match(page, /uiText\(locale, "auth\.superAdminSignIn"\)/);
  assert.match(dictionary, /"auth\.superAdminSignIn": "Super Admin sign in"/);
  assert.match(page, /action="\/api\/super-admin\/login"/);
  assert.match(route, /INITIAL_SUPER_ADMIN_EMAIL/);
  assert.match(route, /INITIAL_SUPER_ADMIN_PASSWORD/);
  assert.match(route, /credentialSource: "SERVER_ENV"/);
});

test("Super Admin protected routes return to the dedicated owner surface", () => {
  const authorization = read("src/lib/auth/authorization.ts");
  const catchAll = read("src/app/super-admin/[...segments]/page.tsx");
  assert.match(authorization, /redirect\(`\/super-admin\?returnTo=/);
  assert.match(catchAll, /requireSuperAdminSession\(activePath\)/);
});

test("regular login cannot create a Super Admin session", () => {
  const source = read("src/app/api/auth/login/route.ts");
  assert.match(source, /if \(user\.isSuperAdmin\)/);
  assert.match(source, /dedicated\+Super\+Admin\+sign-in/);
});

test("public password recovery does not manage Super Admin env credentials", () => {
  const forgot = read("src/app/api/auth/forgot-password/route.ts");
  const reset = read("src/app/api/auth/reset-password/route.ts");
  assert.match(forgot, /!user\.isSuperAdmin/);
  assert.match(
    reset,
    /Super Admin credentials are managed from the server environment/,
  );
});

test("public header keeps a localized role-aware account destination", () => {
  const source = read("src/components/layout/public-shell.tsx");
  const dictionary = read("src/lib/i18n/dictionary.ts");

  assert.match(source, /uiText\(locale, "public\.myAccount"\)/);
  assert.match(dictionary, /"public\.myAccount": "My account"/);
  assert.match(source, /\/super-admin/);
  assert.match(source, /\/admin/);
  assert.match(source, /\/dashboard/);
});
test("production app container receives dedicated Super Admin env credentials", () => {
  const compose = read("compose.production.yml");
  const authEnvironment =
    compose
      .split("x-auth-environment: &auth-environment", 2)[1]
      ?.split("x-journald-logging:", 1)[0] ?? "";
  assert.match(
    authEnvironment,
    /INITIAL_SUPER_ADMIN_EMAIL:\s*\$\{INITIAL_SUPER_ADMIN_EMAIL\}/,
  );
  assert.match(
    authEnvironment,
    /INITIAL_SUPER_ADMIN_PASSWORD:\s*\$\{INITIAL_SUPER_ADMIN_PASSWORD\}/,
  );

  const appService = compose.split("\n  app:", 2)[1] ?? "";
  assert.match(appService, /<<:\s*\*auth-environment/);
});
test("Super Admin login redirects only to the configured public APP_URL origin", () => {
  const route = read("src/app/api/super-admin/login/route.ts");
  assert.match(route, /import \{ appOrigin \} from "@\/lib\/auth\/config"/);
  assert.match(route, /new URL\("\/super-admin", appOrigin\(\)\)/);
  assert.match(route, /new URL\(returnTo, appOrigin\(\)\)/);
  assert.doesNotMatch(route, /new URL\(returnTo, request\.url\)/);
  assert.doesNotMatch(route, /new URL\("\/super-admin", request\.url\)/);
});

test("Admin has a dedicated login surface and protected admin routes return there", () => {
  const page = read("src/app/admin-login/page.tsx");
  const route = read("src/app/api/admin/login/route.ts");
  const authorization = read("src/lib/auth/authorization.ts");

  assert.match(page, /action="\/api\/admin\/login"/);
  assert.match(page, /auth\.adminSignInTitle/);
  assert.match(route, /hasAdminRole/);
  assert.match(route, /surface: "ADMIN"/);
  assert.match(authorization, /redirect\(`\/admin-login\?returnTo=/);
});

test("member login stays on member/public destinations and uses configured public origin", () => {
  const route = read("src/app/api/auth/login/route.ts");
  const request = read("src/lib/auth/request.ts");

  assert.match(route, /safeMemberReturnTo/);
  assert.match(route, /new URL\(destination, appOrigin\(\)\)/);
  assert.match(route, /new URL\("\/login", appOrigin\(\)\)/);
  assert.match(request, /safeMemberReturnTo/);
  assert.match(request, /isPathWithin\(path, "\/admin"\)/);
  assert.match(request, /isPathWithin\(path, "\/super-admin"\)/);
});

test("regular member login sends staff credentials to the dedicated admin login", () => {
  const route = read("src/app/api/auth/login/route.ts");
  assert.match(route, /const isAdmin = user\.roles\.some/);
  assert.match(route, /new URL\("\/admin-login", appOrigin\(\)\)/);
  assert.match(route, /Use the dedicated Admin sign in/);
});

test("admin return paths cannot escape the admin surface", () => {
  const request = read("src/lib/auth/request.ts");
  assert.match(request, /safeAdminReturnTo/);
  assert.match(
    request,
    /return isPathWithin\(path, "\/admin"\) \? path : fallback/,
  );
});
