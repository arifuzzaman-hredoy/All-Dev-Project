import assert from "node:assert/strict";
import test from "node:test";
import { generatePrescriptionCode } from "../src/lib/clinical/code";

test("generatePrescriptionCode includes date and stable prefix", () => {
  const value = generatePrescriptionCode(new Date("2026-08-09T00:00:00.000Z"));
  assert.match(value, /^HLP-RX-20260809-[0-9A-F]{6}$/);
});
