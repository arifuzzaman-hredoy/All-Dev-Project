import assert from "node:assert/strict";
import test from "node:test";
import { analyticsRange } from "../src/lib/analytics/validation";

test("analyticsRange accepts a valid bounded Dhaka date range", () => {
  const result = analyticsRange("2026-08-01", "2026-08-09");
  assert.equal(result.from?.toISOString(), "2026-07-31T18:00:00.000Z");
  assert.equal(result.to?.toISOString(), "2026-08-09T17:59:59.999Z");
});

test("analyticsRange rejects inverted ranges", () => {
  assert.throws(
    () => analyticsRange("2026-08-10", "2026-08-09"),
    /cannot be after/,
  );
});

test("analyticsRange rejects impossible calendar dates", () => {
  assert.throws(() => analyticsRange("2026-02-30"), /invalid/);
});

test("analyticsRange rejects ranges over 366 days", () => {
  assert.throws(() => analyticsRange("2025-01-01", "2026-08-09"), /366 days/);
});
