import assert from "node:assert/strict";
import test from "node:test";
import { createCertificateCode } from "../src/lib/learning/code";
test("creates certificate code with date prefix", () => {
  const code = createCertificateCode(new Date("2026-08-02T00:00:00.000Z"));
  assert.match(code, /^HLC-20260802-[A-F0-9]{8}$/);
});
