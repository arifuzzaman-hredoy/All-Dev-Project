import assert from "node:assert/strict";
import test from "node:test";
import {
  readPrescriptionForm,
  readVitalForm,
} from "../src/lib/clinical/validation";

function prescriptionForm(): FormData {
  const form = new FormData();
  form.set("appointmentId", "apt-1");
  form.set("diagnosis", "Example diagnosis");
  form.append("medicineName", "Medicine A");
  form.append("genericName", "Generic A");
  form.append("strength", "10 mg");
  form.append("dose", "1 tablet");
  form.append("route", "Oral");
  form.append("frequency", "Twice daily");
  form.append("duration", "5 days");
  form.append("quantity", "10");
  form.append("instructions", "After food");
  return form;
}

test("prescription form requires complete medicine rows", () => {
  const form = prescriptionForm();
  const value = readPrescriptionForm(form);
  assert.equal(value.appointmentId, "apt-1");
  assert.equal(value.items.length, 1);
  assert.equal(value.items[0]?.medicineName, "Medicine A");
});

test("incomplete medicine row is rejected", () => {
  const form = prescriptionForm();
  form.set("frequency", "");
  assert.throws(
    () => readPrescriptionForm(form),
    /requires medicine, dose, frequency, and duration/,
  );
});

test("vital form accepts measurement and rejects an empty record", () => {
  const valid = new FormData();
  valid.set("weightKg", "65.4");
  assert.equal(readVitalForm(valid).weightKg, 65.4);
  assert.throws(
    () => readVitalForm(new FormData()),
    /at least one vital measurement or note/,
  );
});

test("vital form rejects values outside broad technical bounds", () => {
  const invalid = new FormData();
  invalid.set("oxygenSaturation", "101");
  assert.throws(() => readVitalForm(invalid), /oxygenSaturation is outside/);
});

test("clinical text over the configured limit is rejected instead of silently truncated", () => {
  const form = prescriptionForm();
  form.set("diagnosis", "x".repeat(8001));
  assert.throws(
    () => readPrescriptionForm(form),
    /exceeds the 8000-character limit/,
  );
});
