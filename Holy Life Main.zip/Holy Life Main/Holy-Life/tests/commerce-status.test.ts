import assert from "node:assert/strict";
import test from "node:test";
import {
  assertOrderTransition,
  assertRefundTransition,
  canCustomerCancel,
  canTransitionOrder,
  canTransitionRefund,
} from "../src/lib/commerce/status";
test("order lifecycle allows only controlled forward transitions", () => {
  assert.equal(canTransitionOrder("PENDING", "CONFIRMED"), true);
  assert.equal(canTransitionOrder("CONFIRMED", "PROCESSING"), true);
  assert.equal(canTransitionOrder("PROCESSING", "SHIPPED"), true);
  assert.equal(canTransitionOrder("SHIPPED", "DELIVERED"), true);
  assert.equal(canTransitionOrder("DELIVERED", "PENDING"), false);
});
test("customer cancellation closes before shipment", () => {
  assert.equal(canCustomerCancel("PENDING"), true);
  assert.equal(canCustomerCancel("CONFIRMED"), true);
  assert.equal(canCustomerCancel("PROCESSING"), false);
  assert.equal(canCustomerCancel("SHIPPED"), false);
});
test("invalid transition throws", () =>
  assert.throws(() => assertOrderTransition("SHIPPED", "CANCELLED")));

test("refund lifecycle requires approval before completion", () => {
  assert.equal(canTransitionRefund("REQUESTED", "APPROVED"), true);
  assert.equal(canTransitionRefund("APPROVED", "COMPLETED"), true);
  assert.equal(canTransitionRefund("REQUESTED", "COMPLETED"), false);
});
test("completed refunds are terminal", () =>
  assert.throws(() => assertRefundTransition("COMPLETED", "APPROVED")));
