import assert from "node:assert/strict";
import test from "node:test";

import {
  parseSavedItemType,
  readDashboardAddress,
  readDashboardProfile,
  validateDashboardAddress,
  validateDashboardProfile,
} from "../src/lib/dashboard/validation";

test("saved item types accept only supported dashboard targets", () => {
  assert.equal(parseSavedItemType("doctor"), "DOCTOR");
  assert.equal(parseSavedItemType("PRODUCT"), "PRODUCT");
  assert.equal(parseSavedItemType("course"), "COURSE");
  assert.equal(parseSavedItemType("article"), null);
});

test("dashboard profile form normalizes phones and validates dates", () => {
  const form = new FormData();
  form.set("name", "  Demo   Member  ");
  form.set("patientPhone", "+880 1712-345678");
  form.set("gender", "PREFER_NOT_TO_SAY");
  form.set("dateOfBirth", "2000-01-31");
  form.set("emergencyContactPhone", "01812 345678");

  const profile = readDashboardProfile(form);
  assert.equal(profile.name, "Demo Member");
  assert.equal(profile.patientPhone, "01712345678");
  assert.equal(profile.emergencyContactPhone, "01812345678");
  assert.equal(validateDashboardProfile(profile), null);

  assert.match(
    validateDashboardProfile({ ...profile, dateOfBirth: "31-01-2000" }) ?? "",
    /valid date/i,
  );
});

test("dashboard address form requires recipient, phone, street and city", () => {
  const form = new FormData();
  form.set("label", "Home");
  form.set("recipientName", "Demo Member");
  form.set("phone", "+880 1712-345678");
  form.set("addressLine1", "House 10, Road 2");
  form.set("city", "Rangpur");
  form.set("isDefault", "on");

  const address = readDashboardAddress(form);
  assert.equal(address.phone, "01712345678");
  assert.equal(address.isDefault, true);
  assert.equal(validateDashboardAddress(address), null);

  assert.match(
    validateDashboardAddress({ ...address, city: "" }) ?? "",
    /city|upazila/i,
  );
});
