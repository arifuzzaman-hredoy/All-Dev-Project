#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
ENV_FILE="$APP_DIR/.env.production"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"

test -f "$ENV_FILE"
test -f "$DOTENV_READER"

APP_URL="$(python3 "$DOTENV_READER" "$ENV_FILE" APP_URL)"
APP_URL="${APP_URL%/}"
[[ "$APP_URL" == https://* ]] || {
  echo "[smoke] APP_URL must use HTTPS: $APP_URL" >&2
  exit 1
}

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

request() {
  local name="$1" url="$2"
  shift 2
  local headers="$TMP_DIR/${name}.headers"
  local body="$TMP_DIR/${name}.body"
  local status
  status="$(curl \
    --silent \
    --show-error \
    --retry 5 \
    --retry-delay 2 \
    --retry-all-errors \
    --max-time 20 \
    --dump-header "$headers" \
    --output "$body" \
    --write-out '%{http_code}' \
    "$@" \
    "$url")"
  printf '%s' "$status"
}

require_status() {
  local name="$1" actual="$2"
  shift 2
  local wanted
  for wanted in "$@"; do
    [[ "$actual" == "$wanted" ]] && return 0
  done
  echo "[smoke] $name returned HTTP $actual; expected one of: $*" >&2
  exit 1
}

echo "[smoke] Production origin: $APP_URL"

health_status="$(request health "$APP_URL/api/health")"
require_status "health" "$health_status" 200
python3 - "$TMP_DIR/health.body" <<'PY'
import json
import sys
data = json.load(open(sys.argv[1], encoding="utf-8"))
if data.get("status") != "ok" or data.get("database") != "reachable":
    raise SystemExit("health payload did not confirm app/database readiness")
PY

home_status="$(request home "$APP_URL/")"
require_status "home" "$home_status" 200
for header in \
  "content-security-policy:" \
  "strict-transport-security:" \
  "x-content-type-options: nosniff" \
  "x-frame-options: DENY" \
  "referrer-policy: strict-origin-when-cross-origin"; do
  if ! grep -qi "^${header}" "$TMP_DIR/home.headers"; then
    echo "[smoke] Home response is missing required header: $header" >&2
    exit 1
  fi
done
if grep -qi '^x-powered-by:' "$TMP_DIR/home.headers"; then
  echo "[smoke] X-Powered-By must remain disabled." >&2
  exit 1
fi

robots_status="$(request robots "$APP_URL/robots.txt")"
require_status "robots" "$robots_status" 200
grep -q "Sitemap: ${APP_URL}/sitemap.xml" "$TMP_DIR/robots.body" || {
  echo "[smoke] robots.txt does not advertise the production sitemap." >&2
  exit 1
}
grep -q "Disallow: /admin" "$TMP_DIR/robots.body" || {
  echo "[smoke] robots.txt does not protect admin crawl paths." >&2
  exit 1
}

sitemap_status="$(request sitemap "$APP_URL/sitemap.xml")"
require_status "sitemap" "$sitemap_status" 200
grep -q '<urlset' "$TMP_DIR/sitemap.body" || {
  echo "[smoke] sitemap.xml is not a sitemap document." >&2
  exit 1
}

manifest_status="$(request manifest "$APP_URL/manifest.webmanifest")"
require_status "manifest" "$manifest_status" 200
python3 - "$TMP_DIR/manifest.body" <<'PY'
import json
import sys
data = json.load(open(sys.argv[1], encoding="utf-8"))
if data.get("name") != "Holy Life" or data.get("start_url") != "/":
    raise SystemExit("manifest.webmanifest does not contain expected Holy Life metadata")
PY

missing_status="$(request missing "$APP_URL/__holy-life-launch-smoke-not-found__")"
require_status "404 page" "$missing_status" 404

login_status="$(request login "$APP_URL/login")"
require_status "login" "$login_status" 200
if ! grep -qi '^cache-control: .*no-store' "$TMP_DIR/login.headers"; then
  echo "[smoke] Login response must be no-store." >&2
  exit 1
fi

admin_status="$(request admin "$APP_URL/admin")"
require_status "anonymous admin" "$admin_status" 302 303 307 308
if ! grep -qi '^location: .*login' "$TMP_DIR/admin.headers"; then
  echo "[smoke] Anonymous admin route did not redirect to login." >&2
  exit 1
fi

echo "[smoke] Health, public metadata, security headers, no-store policy, 404 UX, and admin redirect passed."
