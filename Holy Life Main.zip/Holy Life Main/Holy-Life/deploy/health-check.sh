#!/usr/bin/env bash
set -Eeuo pipefail

URL="${1:-http://127.0.0.1:3100/api/health}"
ATTEMPTS="${HEALTH_ATTEMPTS:-30}"
for ((i=1; i<=ATTEMPTS; i++)); do
  if curl --fail --silent --show-error --max-time 4 "$URL" >/dev/null; then
    echo "Health check passed: $URL"
    exit 0
  fi
  sleep 2
done

echo "Health check failed after $ATTEMPTS attempts: $URL" >&2
exit 1
