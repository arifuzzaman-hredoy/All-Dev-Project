#!/usr/bin/env bash
set -Eeuo pipefail

BACKUP_FILE="${1:?Backup file is required}"
APP_DIR="${APP_DIR:-/opt/holy-life}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"

test -s "$BACKUP_FILE"
test -f "$ENV_FILE"
test -f "$COMPOSE_FILE"
test -f "$DOTENV_READER"

POSTGRES_USER="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_USER)"
POSTGRES_DB="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_DB)"

gzip -dc "$BACKUP_FILE" | docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" "$POSTGRES_DB"
echo "Database restored from $BACKUP_FILE"
