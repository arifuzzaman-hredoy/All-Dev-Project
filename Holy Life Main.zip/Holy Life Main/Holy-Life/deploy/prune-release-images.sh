#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"
CURRENT_STATE="$APP_DIR/releases/current.env"
PREVIOUS_STATE="$APP_DIR/releases/previous.env"

test -f "$DOTENV_READER"
test -f "$CURRENT_STATE"

current_app="$(python3 "$DOTENV_READER" "$CURRENT_STATE" HOLY_LIFE_IMAGE)"
current_migrator="$(python3 "$DOTENV_READER" "$CURRENT_STATE" HOLY_LIFE_MIGRATOR_IMAGE)"

if [[ ! -s "$PREVIOUS_STATE" ]]; then
  echo "[image-retention] previous.env is missing; cleanup skipped to preserve rollback safety."
  exit 0
fi

previous_app="$(python3 "$DOTENV_READER" "$PREVIOUS_STATE" HOLY_LIFE_IMAGE)"
previous_migrator="$(python3 "$DOTENV_READER" "$PREVIOUS_STATE" HOLY_LIFE_MIGRATOR_IMAGE)"

for required in "$current_app" "$current_migrator" "$previous_app" "$previous_migrator"; do
  [[ -n "$required" ]] || {
    echo "[image-retention] Release state is incomplete; cleanup skipped." >&2
    exit 0
  }
done

current_running="$(docker inspect holy-life-production-app-1 --format '{{.Config.Image}}' 2>/dev/null || true)"
if [[ "$current_running" != "$current_app" ]]; then
  echo "[image-retention] Running app image does not match current release state; cleanup skipped." >&2
  exit 0
fi

repository_of() {
  local ref="$1"
  printf '%s\n' "${ref%:*}"
}

app_repo="$(repository_of "$current_app")"
migrator_repo="$(repository_of "$current_migrator")"

declare -A keep=()
keep["$current_app"]=1
keep["$previous_app"]=1
keep["$current_migrator"]=1
keep["$previous_migrator"]=1

remove_old_tags() {
  local repo="$1"
  local ref
  while IFS= read -r ref; do
    [[ -n "$ref" ]] || continue
    [[ "$ref" == *":<none>" ]] && continue
    if [[ -n "${keep[$ref]+x}" ]]; then
      echo "[image-retention] keep $ref"
      continue
    fi
    echo "[image-retention] remove old Holy Life tag $ref"
    docker image rm "$ref" >/dev/null
  done < <(docker image ls "$repo" --format '{{.Repository}}:{{.Tag}}')
}

before="$(df -P / | awk 'NR==2 {print $5}')"
remove_old_tags "$app_repo"
remove_old_tags "$migrator_repo"
after="$(df -P / | awk 'NR==2 {print $5}')"

echo "[image-retention] root usage: $before -> $after"
echo "[image-retention] current and previous app/migrator releases retained."
