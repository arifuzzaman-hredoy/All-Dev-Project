#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"
NEW_APP_IMAGE="${1:?Application image is required}"
NEW_MIGRATOR_IMAGE="${2:?Migrator image is required}"
RELEASE_SHA="${3:-unknown}"
STATE_DIR="$APP_DIR/releases"
CURRENT_STATE="$STATE_DIR/current.env"
PREVIOUS_STATE="$STATE_DIR/previous.env"
DEPLOY_LOCK="$APP_DIR/.deploy.lock"
DEPLOY_STARTED="$(date +%s)"

mkdir -p "$STATE_DIR" "$APP_DIR/backups"
chmod 700 "$STATE_DIR" "$APP_DIR/backups"
test -f "$ENV_FILE"
test -f "$COMPOSE_FILE"
test -f "$DOTENV_READER"

exec 9>"$DEPLOY_LOCK"
if ! flock -n 9; then
  echo "Another Holy Life deployment is already running." >&2
  exit 75
fi

elapsed() {
  local started="$1"
  echo "$(( $(date +%s) - started ))s"
}

CURRENT_MIGRATOR_IMAGE=""
if [[ -f "$CURRENT_STATE" ]]; then
  cp "$CURRENT_STATE" "$PREVIOUS_STATE"
  CURRENT_MIGRATOR_IMAGE="$(awk -F= '$1 == "HOLY_LIFE_MIGRATOR_IMAGE" {sub(/^[^=]*=/, ""); print; exit}' "$CURRENT_STATE")"
fi

MIGRATION_CHANGED=true
if [[ -n "$CURRENT_MIGRATOR_IMAGE" && "$CURRENT_MIGRATOR_IMAGE" == "$NEW_MIGRATOR_IMAGE" ]]; then
  MIGRATION_CHANGED=false
fi

python3 - "$ENV_FILE" "$NEW_APP_IMAGE" "$NEW_MIGRATOR_IMAGE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
updates = {"HOLY_LIFE_IMAGE": sys.argv[2], "HOLY_LIFE_MIGRATOR_IMAGE": sys.argv[3]}
lines = path.read_text(encoding="utf-8").splitlines()
seen = set()
out = []
for line in lines:
    key = line.split("=", 1)[0].strip() if "=" in line else ""
    if key in updates:
        out.append(f"{key}={updates[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in updates.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n", encoding="utf-8")
PY

APP_BIND_PORT="$(python3 "$DOTENV_READER" "$ENV_FILE" APP_BIND_PORT 3100)"

if [[ "$MIGRATION_CHANGED" == "true" ]]; then
  backup_started="$(date +%s)"
  echo "[deploy] Database backup and migration are required."
  "$APP_DIR/deploy/backup-database.sh"
  echo "[deploy] Backup step: $(elapsed "$backup_started")"
else
  echo "[deploy] Prisma inputs are unchanged; backup and migration are skipped."
fi

pull_started="$(date +%s)"
services=(app)
if [[ "$MIGRATION_CHANGED" == "true" ]]; then
  services+=(migrate)
fi

echo "[deploy] Pulling ${services[*]} with quiet parallel progress..."
if ! timeout 420 docker compose \
  --env-file "$ENV_FILE" \
  -f "$COMPOSE_FILE" \
  --parallel 2 \
  --progress quiet \
  pull --policy missing "${services[@]}"; then
  echo "[deploy] Quiet parallel pull failed; retrying once with diagnostic output." >&2
  timeout 420 docker compose \
    --env-file "$ENV_FILE" \
    -f "$COMPOSE_FILE" \
    --parallel 1 \
    --progress plain \
    pull --policy missing "${services[@]}"
fi
echo "[deploy] Image pull step: $(elapsed "$pull_started")"

runtime_started="$(date +%s)"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" \
  up -d --pull missing --wait --wait-timeout 90 db

if [[ "$MIGRATION_CHANGED" == "true" ]]; then
  # The seed is idempotent and must run whenever Prisma inputs change so new
  # permissions, navigation, and CMS defaults are installed with the migration.
  RUN_SEED=true
  echo "[deploy] Running Prisma migration and idempotent seed..."
  RUN_SEED="$RUN_SEED" docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" \
    run --rm --no-deps --pull never -e RUN_SEED="$RUN_SEED" migrate
fi

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" \
  up -d --no-deps --pull never --wait --wait-timeout 90 app

echo "[deploy] Runtime/migration step: $(elapsed "$runtime_started")"

if "$APP_DIR/deploy/health-check.sh" "http://127.0.0.1:${APP_BIND_PORT}/api/health"; then
  if ! "$APP_DIR/deploy/smoke-test.sh"; then
    echo "[deploy] Production smoke gate failed; restoring the previous release." >&2
    CONFIRM_ROLLBACK=AUTOMATIC_DEPLOY_FAILURE "$APP_DIR/deploy/rollback.sh"
    exit 1
  fi

  cat > "$CURRENT_STATE" <<STATE
HOLY_LIFE_IMAGE=$NEW_APP_IMAGE
HOLY_LIFE_MIGRATOR_IMAGE=$NEW_MIGRATOR_IMAGE
RELEASE_SHA=$RELEASE_SHA
DEPLOYED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)
STATE

  if ! "$APP_DIR/deploy/prune-release-images.sh"; then
    echo "[deploy] WARNING: Holy Life release-image retention cleanup failed; deployment remains healthy." >&2
  fi

  echo "Deployment completed: $RELEASE_SHA"
  echo "Total remote deployment time: $(elapsed "$DEPLOY_STARTED")"
  exit 0
fi

CONFIRM_ROLLBACK=AUTOMATIC_DEPLOY_FAILURE "$APP_DIR/deploy/rollback.sh"
exit 1
