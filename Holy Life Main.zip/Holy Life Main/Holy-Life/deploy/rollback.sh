#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
ENV_FILE="$APP_DIR/.env.production"
COMPOSE_FILE="$APP_DIR/compose.production.yml"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"
STATE_DIR="$APP_DIR/releases"
CURRENT_STATE="$STATE_DIR/current.env"
PREVIOUS_STATE="$STATE_DIR/previous.env"
CONFIRMATION="${CONFIRM_ROLLBACK:-}"

test -f "$ENV_FILE"
test -f "$COMPOSE_FILE"
test -f "$DOTENV_READER"
test -f "$PREVIOUS_STATE"

if [[ "$CONFIRMATION" != "AUTOMATIC_DEPLOY_FAILURE" && "$CONFIRMATION" != "YES_ROLLBACK_HOLY_LIFE" ]]; then
  echo "Rollback requires CONFIRM_ROLLBACK=YES_ROLLBACK_HOLY_LIFE." >&2
  exit 64
fi

HOLY_LIFE_IMAGE="$(python3 "$DOTENV_READER" "$PREVIOUS_STATE" HOLY_LIFE_IMAGE)"
HOLY_LIFE_MIGRATOR_IMAGE="$(python3 "$DOTENV_READER" "$PREVIOUS_STATE" HOLY_LIFE_MIGRATOR_IMAGE)"
RELEASE_SHA="$(python3 "$DOTENV_READER" "$PREVIOUS_STATE" RELEASE_SHA previous-release)"
APP_BIND_PORT="$(python3 "$DOTENV_READER" "$ENV_FILE" APP_BIND_PORT 3100)"

[[ -n "$HOLY_LIFE_IMAGE" && -n "$HOLY_LIFE_MIGRATOR_IMAGE" ]] || {
  echo "Previous release state is incomplete." >&2
  exit 1
}

old_current="$(mktemp)"
trap 'rm -f "$old_current"' EXIT
if [[ -s "$CURRENT_STATE" ]]; then
  cp "$CURRENT_STATE" "$old_current"
fi

python3 - "$ENV_FILE" "$HOLY_LIFE_IMAGE" "$HOLY_LIFE_MIGRATOR_IMAGE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
updates = {"HOLY_LIFE_IMAGE": sys.argv[2], "HOLY_LIFE_MIGRATOR_IMAGE": sys.argv[3]}
lines = path.read_text(encoding="utf-8").splitlines()
seen = set()
out = []
for line in lines:
    key = line.split("=", 1)[0].strip() if "=" in line else ""
    if key in updates:
        out.append(f"{key}={updates[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in updates.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n", encoding="utf-8")
PY

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" pull app
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --no-deps --wait --wait-timeout 90 app
"$APP_DIR/deploy/health-check.sh" "http://127.0.0.1:${APP_BIND_PORT}/api/health"
"$APP_DIR/deploy/smoke-test.sh"

cp "$PREVIOUS_STATE" "$CURRENT_STATE"
if [[ -s "$old_current" ]]; then
  cp "$old_current" "$PREVIOUS_STATE"
fi

echo "Rollback completed to ${RELEASE_SHA}."
echo "Database migrations are not reversed automatically; only forward-compatible releases should use application rollback."
