#!/usr/bin/env bash
set -Eeuo pipefail

DOMAIN="${1:?Domain is required}"
SSH_PUBLIC_KEY_B64="${2:?SSH public key is required}"
DEPLOY_USER="${DEPLOY_USER:-holydeploy}"
APP_DIR="${APP_DIR:-/opt/holy-life}"
APP_PORT="${APP_PORT:-3100}"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run bootstrap as root." >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl gnupg git openssl python3 certbot

if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  . /etc/os-release
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${UBUNTU_CODENAME:-$VERSION_CODENAME} stable" > /etc/apt/sources.list.d/docker.list
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

if ! id "$DEPLOY_USER" >/dev/null 2>&1; then
  useradd --create-home --shell /bin/bash "$DEPLOY_USER"
fi
usermod -aG docker "$DEPLOY_USER"
install -d -m 700 -o "$DEPLOY_USER" -g "$DEPLOY_USER" "/home/$DEPLOY_USER/.ssh"
printf '%s' "$SSH_PUBLIC_KEY_B64" | base64 -d > "/home/$DEPLOY_USER/.ssh/authorized_keys"
chown "$DEPLOY_USER:$DEPLOY_USER" "/home/$DEPLOY_USER/.ssh/authorized_keys"
chmod 600 "/home/$DEPLOY_USER/.ssh/authorized_keys"
install -d -m 750 -o "$DEPLOY_USER" -g "$DEPLOY_USER" "$APP_DIR" "$APP_DIR/deploy" "$APP_DIR/backups" "$APP_DIR/releases"
systemctl enable --now docker

configure_nginx() {
  apt-get install -y nginx python3-certbot-nginx
  cat > "/etc/nginx/sites-available/holy-life" <<NGINX
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    client_max_body_size 20m;

    location / {
        proxy_pass http://127.0.0.1:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 120s;
    }
}
NGINX
  ln -sfn /etc/nginx/sites-available/holy-life /etc/nginx/sites-enabled/holy-life
  nginx -t
  systemctl enable --now nginx
  systemctl reload nginx
  PROXY_KIND="nginx"
}

configure_apache() {
  apt-get install -y apache2 python3-certbot-apache
  a2enmod proxy proxy_http headers rewrite ssl
  cat > "/etc/apache2/sites-available/holy-life.conf" <<APACHE
<VirtualHost *:80>
    ServerName $DOMAIN
    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:$APP_PORT/
    ProxyPassReverse / http://127.0.0.1:$APP_PORT/
    RequestHeader set X-Forwarded-Proto "http"
    ErrorLog \${APACHE_LOG_DIR}/holy-life-error.log
    CustomLog \${APACHE_LOG_DIR}/holy-life-access.log combined
</VirtualHost>
APACHE
  a2ensite holy-life.conf
  apache2ctl configtest
  systemctl enable --now apache2
  systemctl reload apache2
  PROXY_KIND="apache"
}

PROXY_KIND=""
if command -v nginx >/dev/null 2>&1 || systemctl list-unit-files 2>/dev/null | grep -q '^nginx.service'; then
  configure_nginx
elif command -v apache2 >/dev/null 2>&1 || systemctl list-unit-files 2>/dev/null | grep -q '^apache2.service'; then
  configure_apache
elif ! ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq '(^|:)(80|443)$'; then
  configure_nginx
else
  echo "Port 80/443 is controlled by an unsupported web server. Docker and the deploy user are ready, but the script did not overwrite the existing control-panel proxy." >&2
  echo "Detected listeners:" >&2
  ss -lntp | grep -E ':(80|443)[[:space:]]' >&2 || true
  exit 42
fi

if command -v ufw >/dev/null 2>&1 && ufw status | grep -q '^Status: active'; then
  ufw allow OpenSSH
  if [[ "$PROXY_KIND" == "nginx" ]]; then ufw allow 'Nginx Full'; else ufw allow 80/tcp; ufw allow 443/tcp; fi
fi

PUBLIC_IP="$(curl -4fsS --max-time 10 https://api.ipify.org || true)"
DNS_IPS="$(getent ahostsv4 "$DOMAIN" | awk '{print $1}' | sort -u || true)"
if [[ -n "$PUBLIC_IP" ]] && grep -qx "$PUBLIC_IP" <<< "$DNS_IPS"; then
  if [[ "$PROXY_KIND" == "nginx" ]]; then
    certbot --nginx --non-interactive --agree-tos --redirect --register-unsafely-without-email -d "$DOMAIN" || true
  else
    certbot --apache --non-interactive --agree-tos --redirect --register-unsafely-without-email -d "$DOMAIN" || true
  fi
else
  echo "DNS does not yet resolve to this server; SSL can be retried by rerunning bootstrap."
fi

echo "VPS bootstrap complete for $DOMAIN using $PROXY_KIND."
