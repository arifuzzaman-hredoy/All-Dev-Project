#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/holy-life}"
ENV_FILE="${ENV_FILE:-$APP_DIR/.env.production}"
COMPOSE_FILE="${COMPOSE_FILE:-$APP_DIR/compose.production.yml}"
BACKUP_DIR="${BACKUP_DIR:-$APP_DIR/backups}"
DOTENV_READER="$APP_DIR/deploy/read-dotenv.py"

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
test -f "$ENV_FILE"
test -f "$COMPOSE_FILE"
test -f "$DOTENV_READER"

POSTGRES_USER="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_USER)"
POSTGRES_DB="$(python3 "$DOTENV_READER" "$ENV_FILE" POSTGRES_DB)"
RETENTION_DAYS="$(python3 "$DOTENV_READER" "$ENV_FILE" BACKUP_RETENTION_DAYS 14)"

DB_CONTAINER_ID="$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" ps -q db 2>/dev/null || true)"
if [[ -z "$DB_CONTAINER_ID" ]]; then
  echo "No existing database container; skipping pre-deploy backup."
  exit 0
fi

DB_RUNNING="$(docker inspect --format '{{.State.Running}}' "$DB_CONTAINER_ID" 2>/dev/null || true)"
if [[ "$DB_RUNNING" != "true" ]]; then
  echo "Database container is not running; skipping pre-deploy backup."
  exit 0
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT="$BACKUP_DIR/holy-life-$STAMP.sql.gz"

# gzip -1 is intentionally used for fast pre-deploy safety backups.
# Scheduled/off-server backups can use stronger compression separately.
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_dump --clean --if-exists --no-owner --no-privileges -U "$POSTGRES_USER" "$POSTGRES_DB" \
  | gzip -1 > "$OUTPUT"

test -s "$OUTPUT"
find "$BACKUP_DIR" -type f -name 'holy-life-*.sql.gz' -mtime "+$RETENTION_DAYS" -delete
printf '%s\n' "$OUTPUT"
