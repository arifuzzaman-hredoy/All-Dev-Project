#!/usr/bin/env python3
"""Read one value from a Docker Compose dotenv file without executing it."""

from __future__ import annotations

from pathlib import Path
import sys


def decode_value(raw_value: str) -> str:
    value = raw_value.strip()
    if len(value) >= 2 and value[0] == value[-1] == "'":
        return value[1:-1]

    if len(value) >= 2 and value[0] == value[-1] == '"':
        inner = value[1:-1]
        output: list[str] = []
        index = 0
        escapes = {
            "n": "\n",
            "r": "\r",
            "t": "\t",
            '"': '"',
            "\\": "\\",
            "$": "$",
        }
        while index < len(inner):
            character = inner[index]
            if character == "\\" and index + 1 < len(inner):
                next_character = inner[index + 1]
                output.append(escapes.get(next_character, next_character))
                index += 2
                continue
            output.append(character)
            index += 1
        return "".join(output)

    return value


def load_dotenv(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, raw_value = line.split("=", 1)
        key = key.strip()
        if key:
            values[key] = decode_value(raw_value)
    return values


def main() -> int:
    if len(sys.argv) not in {3, 4}:
        print("usage: read-dotenv.py ENV_FILE KEY [DEFAULT]", file=sys.stderr)
        return 64

    env_path = Path(sys.argv[1])
    key = sys.argv[2]
    has_default = len(sys.argv) == 4
    default = sys.argv[3] if has_default else None

    if not env_path.is_file():
        print(f"dotenv file not found: {env_path}", file=sys.stderr)
        return 66

    values = load_dotenv(env_path)
    if key not in values:
        if has_default:
            print(default, end="")
            return 0
        print(f"dotenv key not found: {key}", file=sys.stderr)
        return 67

    print(values[key], end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
