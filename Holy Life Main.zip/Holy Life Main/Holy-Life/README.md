# Holy Life Platform — Phase 0 + Phase 1 + Phase 2

This package combines the project foundation, the approved layout system, and the authentication/security foundation into one Docker-based project.

## Included

### Phase 0 — Architecture and data foundation

- Next.js App Router with strict TypeScript
- PostgreSQL 17 and Prisma ORM
- Docker Compose services for PostgreSQL, migration/seed, and the application
- Modular-monolith module map for Healthcare, E-commerce, Learning, Website, and System
- Super Admin, Master Admin, custom-role, permission, navigation, CMS-section, setting, and audit-log data models
- Initial and Phase 2 database migrations
- Idempotent seed data
- Database-aware `/api/health` endpoint
- Architecture decision to defer Kubernetes

### Phase 1 — UX, layouts, and navigation

- Public home, appointment, course, and shop pages
- Unified member dashboard
- Operational Admin panel shell
- Owner-only Super Admin panel shell
- Three-level navigation pattern: section → subsection → sub-subsection
- Accordion sidebar, active state, breadcrumb, horizontal tabs, grouped forms/tables, filters, cards, status badges, loading/empty patterns, and mobile drawer
- Separate but restrained visual accents for Healthcare, Learning, and E-commerce

### Phase 2 — Authentication, users, and security

- Registration with email and/or Bangladesh mobile number
- Email/phone normalization and duplicate prevention
- Scrypt password hashing with per-password random salt
- Password policy and confirmation validation
- Login with email or phone
- Database-backed login throttling
- Contact verification with a six-digit code or secure one-time link
- Resend cooldown and maximum verification attempts
- Forgot/reset password by code or secure one-time link
- Opaque, hashed, HttpOnly database sessions
- Session limit, history, self-revocation, and force logout
- Immediate session invalidation when an account is suspended or a password changes
- Member, Admin, Master Admin, and owner-only Super Admin access boundaries
- Owner account protection against self-suspension and unsafe owner changes
- Authentication/security audit log
- Security response headers and same-origin form protection
- Real protected `/dashboard`, `/admin`, and `/super-admin` layouts
- Local log delivery plus a provider-neutral production webhook adapter for email/SMS delivery
- Authentication primitive tests

## Scope boundary

Phase 2 makes identity, verification, session, account status, and panel access real. Appointment, patient, prescription, product/order, payment, and LMS CRUD workflows are still placeholders and belong to their business implementation phases.

Granular role assignment and the full permission-management UI are not falsely presented as complete. The Phase 0 data model supports them, while their management workflows belong to the next permission phase.

## Requirements

- Docker Engine with Docker Compose v2, or Docker Desktop
- At least 4 GB free RAM recommended for the first image build
- Internet access during the first Docker build so npm packages and container images can be downloaded
- Ports `3000` and `5433` available, or changed in `.env`

Kubernetes is not required for this release.

## Run once with Docker

### Ubuntu

```bash
cd ~/Downloads
unzip -o holy-life-phase-0-1-2.zip
cd holy-life-phase-0-1-2
chmod +x RUN_UBUNTU.sh STOP_UBUNTU.sh
./RUN_UBUNTU.sh
```

### Windows PowerShell

```powershell
Set-Location "$HOME\Downloads"
Expand-Archive -Path .\holy-life-phase-0-1-2.zip -DestinationPath . -Force
Set-Location .\holy-life-phase-0-1-2
Set-ExecutionPolicy -Scope Process Bypass
.\RUN_WINDOWS.ps1
```

The run script generates a private `.env`, starts PostgreSQL, applies migrations, seeds the development owner/member accounts, builds the Next.js application, waits for the health check, and prints the generated credentials.

## Open these routes

- Public website: `http://localhost:3000`
- Login: `http://localhost:3000/login`
- Register: `http://localhost:3000/register`
- Member dashboard: `http://localhost:3000/dashboard`
- Account security: `http://localhost:3000/dashboard/profile/security`
- Admin panel: `http://localhost:3000/admin`
- Super Admin panel: `http://localhost:3000/super-admin`
- Owner security control: `http://localhost:3000/super-admin/security`
- Audit log: `http://localhost:3000/super-admin/audit`
- Health check: `http://localhost:3000/api/health`

## Local verification and password-reset messages

The default local setting is:

```env
AUTH_DELIVERY_MODE=log
```

Verification codes and secure links are written to the application log:

```bash
docker compose logs -f app
```

`log` mode intentionally refuses to run when `APP_URL` is not localhost. Before production, configure a real delivery service through the webhook adapter:

```env
APP_URL=https://your-domain.example
AUTH_DELIVERY_MODE=webhook
AUTH_DELIVERY_WEBHOOK_URL=https://your-private-delivery-service.example/auth-message
AUTH_DELIVERY_WEBHOOK_SECRET=replace-with-a-private-secret
```

The webhook endpoint must deliver the supplied message through your approved email/SMS provider. Do not expose the webhook publicly without authentication, request validation, rate limiting, and monitoring.

## Stop without deleting data

Ubuntu:

```bash
./STOP_UBUNTU.sh
```

Windows:

```powershell
.\STOP_WINDOWS.ps1
```

Do not run `docker compose down -v` unless you intentionally want to delete the PostgreSQL volume.

## Development mode

Use Node.js 22 and Docker for PostgreSQL.

Ubuntu:

```bash
chmod +x scripts/bootstrap-ubuntu.sh
./scripts/bootstrap-ubuntu.sh
npm run dev
```

Windows PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\bootstrap-windows.ps1
npm run dev
```

## QA commands

```bash
npm run lint
npm run typecheck
npm run test
npm run build
npm run qa
```

## Production risks to resolve before launch

- Replace development owner/member credentials and protect `.env`.
- Configure HTTPS and set `APP_URL` to the final HTTPS origin.
- Enable `TRUST_PROXY=true` only behind a trusted reverse proxy that overwrites forwarded-IP headers.
- Connect an approved email/SMS delivery provider; local log mode is forbidden outside localhost.
- Add off-server encrypted backups and perform restore tests.
- Add observability, alerting, retention/cleanup jobs for expired sessions/challenges/throttles, and incident procedures.
- Complete the granular role/permission administration phase before delegating admin access.
- Never share patient or prescription data until module-level authorization and sensitive-data audit tests are complete.

## Data and credential safety

- `.env` is generated only when absent and is excluded from Git and Docker build context.
- PostgreSQL data is stored in the `holy_life_postgres_data` named volume.
- Seed reruns do not overwrite an existing account password.
- Preserve the original `.env` when preserving the Docker volume. Deleting `.env` while keeping the existing volume can make newly generated credentials inconsistent with the existing database.

## Documentation

- Phase 0: `docs/phase-0`
- Phase 1: `docs/phase-1`
- Phase 2: `docs/phase-2`
- Validation status: `VALIDATION.md`

---

## Phase 3: RBAC and production delivery

Phase 3 adds production-oriented admin lifecycle management, role presets and custom roles, multiple-role assignment, nested permission matrix, data scopes, permission-aware navigation, server-side authorization, session refresh/revocation, invitation acceptance, audit history, Prisma migration and seed data, RBAC tests, GHCR CI/CD, Docker Compose production deployment, database backup/rollback scripts, and a Terraform learning target for the GitHub deployment environment.

Apply and validation commands are included in the Phase 3 replaceable patch. After the patch is applied, terminal-only infrastructure setup starts with:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup\SETUP_EVERYTHING.ps1
```

See `docs/PHASE_3_RBAC_AND_DEPLOYMENT.md` before the first live deployment.

---

## Phase 4 + Production DevOps Hardening

Phase 4 adds a structured Public Website CMS with page lifecycle, sections, navigation, SEO, media URLs, branding, revisions, RBAC, and audit-aware publishing.

Production operations support optional encrypted off-site backup and remote alerts. The current Holy Life demo VPS intentionally runs in local-only operations mode:

- five-minute application, database, disk, memory, load, and TLS monitoring in systemd/journald;
- daily local diagnostics snapshots;
- journald retention and diagnostics snapshots;
- Fail2ban, SSH rate limiting, key-only administration, unattended security updates, and hardened containers;
- repository secret scanning, dependency audit, pinned Trivy image scan, and SBOM artifacts;
- manual, approval-ready client production deployment;
- optional HCP Terraform remote state migration;
- terminal-only client installation and new-VPS disaster recovery.

### Apply and run

Use the replaceable ZIP's `APPLY_PHASE4_HARDENING_WINDOWS.ps1`, then run:

```powershell
Set-Location "G:\Current Project\Development\Holy Life Project\Holy Life Main\holy-life-phase-0-1-2"
Set-ExecutionPolicy -Scope Process Bypass
.\setup\RUN_PHASE4_AND_HARDENING.ps1
```

External object storage, Telegram/SMTP alerts, HCP Terraform, and automatic SSH lock are optional and are disabled on the current demo VPS by owner decision. They are not required for Phase 5.

---

## Phase 5: Doctor and Appointment Operations

Phase 5 adds database-backed medical departments, doctor profiles, recurring schedules, date-specific availability overrides, live appointment slots, public/member booking, receptionist booking, patient identity records, status workflow, rescheduling, cancellation, queue management, user appointment history, audit logs, and concurrency-safe capacity protection.

Primary routes:

```text
/appointment
/doctors/[slug]
/dashboard/healthcare/appointments
/admin/healthcare/doctors
/admin/healthcare/schedules
/admin/healthcare/appointments
/admin/healthcare/patients
```

Run the replace patch's `APPLY_PHASE5_WINDOWS.ps1`. The patch validates the baseline, creates a rollback copy, commits directly to `main`, watches GitHub Actions, deploys the exact image, and verifies the live health endpoint.

See `docs/PHASE_5_DOCTOR_APPOINTMENT.md`.

## Phase 6 E-commerce

Phase 6 adds transactional catalog, cart, checkout, stock ledger, order, refund, review and commerce reporting workflows. See `docs/PHASE_6_ECOMMERCE.md`.

## Phase 7

Course and Learning Management is available at `/courses`, `/dashboard/learning/courses`, and `/admin/learning/courses`.

## Phase 8 — Unified Public User Dashboard

Phase 8 unifies member-facing appointment, shopping, course, payment, notification, saved-item, profile, and address workflows under `/dashboard`.

Key routes:

```text
/dashboard
/dashboard/activity
/dashboard/notifications
/dashboard/payments
/dashboard/saved
/dashboard/profile
/dashboard/profile/addresses
```

Implementation and security boundaries are documented in `docs/PHASE_8_UNIFIED_DASHBOARD.md`.

## Phase 9 — local/manual finance and reporting

Phase 9 adds an auditable local payment ledger across healthcare, commerce, and
learning; user-submitted manual payment references; admin verification/refunds;
in-app notification management; revenue/transaction reports; CSV export; and
print-friendly reporting.

This deployment is intentionally **local/manual only**. It does not enable an
online payment gateway, email, SMS, push notifications, or external webhooks.

## Phase 10 — Messaging automation

The current platform also includes a DB-backed external messaging outbox, reusable communication templates, service/marketing campaigns, user channel preferences, signed provider webhook delivery, retry/backoff, delivery callbacks, and a Communication Manager role. External messaging is provider-neutral and disabled by default. See `docs/PHASE_10_MESSAGING_AUTOMATION.md` before enabling any provider.

## Phase 11 — Online payment gateway & automation

Phase 11 adds SSLCOMMERZ hosted checkout, signed IPN validation, mandatory server-side provider validation before ledger credit, idempotent `PaymentGatewayAttempt` records, missed-callback reconciliation, finance-admin revalidation, and member payment-result/history surfaces. The Phase 9 finance ledger remains the financial source of truth. The gateway is disabled by default and no provider credential is committed. See `docs/PHASE_11_ONLINE_PAYMENT_GATEWAY.md` before activation.

## Phase 12 — Advanced Healthcare & Prescription

Phase 12 adds longitudinal clinical profiles, per-appointment encounter notes, append-only vitals, versioned prescriptions, authenticated sign-and-lock, immutable signed history, print/PDF-ready prescription views, patient-owned health-record surfaces, and sensitive-data audit events. It reuses the healthcare RBAC permissions reserved in Phase 3. See `docs/PHASE_12_ADVANCED_HEALTHCARE.md`.

Phase 11 SSLCOMMERZ sandbox acceptance remains pending and is not represented as `phase-11-complete`; Phase 12 is based on the successfully deployed Phase 11 commit.

## Phase 13 — Reports, Analytics, Audit & Backup Hardening

Phase 13 adds cross-module platform analytics, ledger-backed revenue summaries, filtered audit exploration/export, and read-only backup/restore assurance. It hardens the existing encrypted restic backup system instead of introducing a second backup stack: PostgreSQL dumps use custom format, archive structure is checked before upload, restored dumps are checksum-verified, restore tests validate critical tables, and a weekly restic repository integrity check samples stored data.

Operational jobs report bounded status evidence into `OperationalRun` through a dedicated bearer-protected endpoint; the VPS reporter uses the loopback application listener by default. Backup encryption keys, database contents, and provider credentials are never stored in operational telemetry. Destructive restore remains terminal-only and still requires `CONFIRM_RESTORE=YES_RESTORE_HOLY_LIFE`; there is intentionally no browser restore button.

Primary routes:

```text
/admin/analytics
/admin/audit
/admin/operations/backups
```

See `docs/PHASE_13_ANALYTICS_AUDIT_BACKUP.md`. Phase 11 SSLCOMMERZ sandbox acceptance and Phase 12 clinical browser acceptance remain pending by project decision.

## Phase 14 — Final Production Readiness & Launch

Phase 14 turns launch readiness into a fail-closed operational gate instead of treating a successful deployment as client-launch approval. It adds `/admin/launch-readiness`, automated configuration/content/backup evidence checks, Primary Super Admin acceptance gates, production metadata/error surfaces, a deployment smoke gate, destructive-migration scanning, rollback-state hardening, and Holy-Life-only release-image retention.

Production safety additions include CSP/HSTS/private no-store headers, `robots.txt`, `sitemap.xml`, `manifest.webmanifest`, custom 404/global error recovery, GitHub Actions Node 24-compatible cache/artifact actions, and a deployment smoke suite that must pass health, metadata, security-header, private-cache, 404, and anonymous-admin checks before a release is accepted.

The launch dashboard intentionally remains **LAUNCH BLOCKED** while required production evidence is absent. In the current project state this includes the pending Phase 11 SSLCOMMERZ acceptance, Phase 12 clinical browser acceptance, Phase 13 analytics/audit/backup browser acceptance, reviewed legal/public content, production auth/payment configuration, and encrypted off-site backup/restore/repository evidence. Phase 13 local-only backup mode is valid for the current demo environment but is not treated as client-production launch-ready.

Image retention is scoped only to Holy Life repositories and keeps the current and previous application/migrator releases. It does not run a global Docker prune, delete volumes, backups, logs, other-project images, or build cache. Manual rollback requires `CONFIRM_ROLLBACK=YES_ROLLBACK_HOLY_LIFE`; successful rollback swaps current/previous release state, while database migrations remain forward-only.

See `docs/PHASE_14_PRODUCTION_READINESS.md`. **Code deployment is not launch approval.** No Phase 11, 12, or 13 completion tag is implied by Phase 14.
