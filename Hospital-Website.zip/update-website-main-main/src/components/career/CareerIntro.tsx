// File: clinic-website/src/components/career/CareerIntro.tsx

import Image from "next/image";
import {
  BriefcaseBusiness,
  HeartHandshake,
  Quote,
  Sparkles,
  UsersRound,
} from "lucide-react";

export default function CareerIntro() {
  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 text-[#062d62] sm:py-14 lg:py-20">
      {/* Minimal Premium Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
        <div className="absolute left-1/2 top-[42%] h-[300px] w-[300px] -translate-x-1/2 rounded-full bg-[#8cc63f]/8 blur-[100px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062d62]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Intro Heading */}
        <div className="mx-auto max-w-5xl text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,45,98,0.08)] backdrop-blur-md">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062d62] text-white shadow-[0_10px_25px_rgba(6,45,98,0.18)]">
              <BriefcaseBusiness size={16} />
            </span>

            <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
              Career With Us
            </span>
          </div>

          <h1 className="text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
            Want to join{" "}
            <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062d62] bg-clip-text text-transparent">
              our team?
              <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
            </span>
          </h1>

          <p className="mt-5 text-base font-black text-[#061b3d] sm:mt-6 sm:text-lg">
            Join us in transforming healthcare in Bangladesh
          </p>

          <p className="mx-auto mt-6 max-w-4xl text-sm font-semibold leading-7 text-[#4d6380] sm:mt-8 sm:text-base sm:leading-8">
            At Update Diagnostic Center, your career is a journey that touches
            lives and transforms futures. We believe in the strength of
            diversity and the power of inclusion to drive exceptional care.
            Every team member, from every background, is valued for their unique
            contribution.
          </p>

          {/* Small Animated Feature Icons */}
          <div className="mx-auto mt-8 grid max-w-3xl gap-3 sm:mt-10 sm:grid-cols-3 sm:gap-4">
            <div className="group rounded-[20px] border border-[#dbeafe] bg-white/75 p-4 shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white sm:rounded-[22px] sm:p-5">
              <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#43c7f4]/12 text-[#43c7f4] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#43c7f4] group-hover:text-white">
                <UsersRound size={23} />
              </span>
              <p className="mt-4 text-sm font-black text-[#062d62]">
                Diverse Team
              </p>
            </div>

            <div className="group rounded-[20px] border border-[#dbeafe] bg-white/75 p-4 shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white sm:rounded-[22px] sm:p-5">
              <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8a6bb8]/12 text-[#8a6bb8] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#8a6bb8] group-hover:text-white">
                <HeartHandshake size={23} />
              </span>
              <p className="mt-4 text-sm font-black text-[#062d62]">
                Care Mission
              </p>
            </div>

            <div className="group rounded-[20px] border border-[#dbeafe] bg-white/75 p-4 shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white sm:rounded-[22px] sm:p-5">
              <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8cc63f]/14 text-[#76a92f] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#8cc63f] group-hover:text-white">
                <Sparkles size={23} />
              </span>
              <p className="mt-4 text-sm font-black text-[#062d62]">
                Growth Culture
              </p>
            </div>
          </div>
        </div>

        {/* HR Message */}
        <div className="mx-auto mt-12 grid max-w-5xl gap-8 sm:mt-16 lg:mt-20 lg:grid-cols-[260px_1fr] lg:gap-14">
          <aside className="flex justify-center lg:justify-start">
            <div className="">
              <div className="pointer-events-none absolute right-[-60px] top-[-60px] h-[150px] w-[150px] rounded-full bg-[#43c7f4]/14 blur-[45px]" />

              <div className="relative z-10">
                <div className="relative h-[130px] w-[130px] overflow-hidden rounded-[26px] border border-[#dbeafe] bg-slate-100 shadow-[0_16px_40px_rgba(6,45,98,0.10)]">
                  <Image
                    src="/doctor-articles/doctor-3.jpg"
                    alt="Senior Director HR"
                    fill
                    sizes="130px"
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>

                <div className="mt-5 flex gap-2">
                  <span className="h-2 flex-1 rounded-full bg-[#062d62]" />
                  <span className="h-2 flex-1 rounded-full bg-[#8b65ad]" />
                  <span className="h-2 flex-1 rounded-full bg-[#45b3dc]" />
                  <span className="h-2 flex-1 rounded-full bg-[#98c45d]" />
                </div>

                <h2 className="mt-6 text-2xl font-black leading-tight text-[#062d62]">
                  Kaiser Chowdhury
                </h2>

                <p className="mt-3 text-base font-bold leading-6 text-[#5b6b82]">
                  Senior Director, HR – Bangladesh
                </p>
              </div>
            </div>
          </aside>

          <article className="relative overflow-hidden rounded-[24px] border border-white/80 bg-white/80 p-5 shadow-[0_22px_60px_rgba(6,45,98,0.10)] backdrop-blur-xl sm:rounded-[30px] sm:p-8 lg:p-10">
            <div className="pointer-events-none absolute right-[-80px] top-[-80px] h-[190px] w-[190px] rounded-full bg-[#8a6bb8]/12 blur-[50px]" />

            <div className="relative z-10">
              <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#062d62] text-white shadow-[0_18px_45px_rgba(6,45,98,0.20)] transition-all duration-300 hover:-translate-y-1 hover:rotate-6 hover:scale-110">
                <Quote size={26} />
              </div>

              <h2 className="text-2xl font-black leading-tight text-[#062d62] sm:text-3xl lg:text-4xl">
                Message from Senior Director, HR
              </h2>

              <div className="mt-6 space-y-5 text-sm font-semibold leading-7 text-[#4d6380] sm:mt-8 sm:space-y-6 sm:text-base sm:leading-8">
                <p>I am pleased to welcome you to our career page.</p>

                <p>
                  We believe that our greatest asset is our people. Our
                  healthcare professionals are committed to providing
                  exceptional care to patients and their families, and we are
                  always looking for passionate individuals to join this
                  mission.
                </p>

                <p>
                  Here, you will find opportunities across clinical, nursing,
                  operations, hospitality, finance, HR, supply chain, allied
                  health, and support services. Each role plays a vital part in
                  helping us deliver the highest quality care to our community.
                </p>

                <p>
                  We value diversity, innovation, and collaboration, and we are
                  looking for individuals who share our passion for transforming
                  healthcare and making a difference in the lives of patients.
                </p>
              </div>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}
