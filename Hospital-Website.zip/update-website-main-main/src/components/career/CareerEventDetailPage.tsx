/* eslint-disable @next/next/no-img-element */
"use client";

import Link from "next/link";
import {
  ArrowLeft,
  CalendarDays,
  HeartHandshake,
  MapPin,
} from "lucide-react";
import { type ReactNode, useMemo, useSyncExternalStore } from "react";
import { useParams } from "next/navigation";
import {
  defaultCareerCmsData,
  getCareerCmsData,
  subscribeCareerCms,
} from "@/lib/careerCms";

function ImageBox({
  src,
  alt,
  className = "",
  children,
}: {
  src?: string;
  alt: string;
  className?: string;
  children?: ReactNode;
}) {
  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-br from-[#07346f] via-[#0c82aa] to-[#42c5e8] ${className}`}
    >
      {src ? (
        <img src={src} alt={alt} className="h-full w-full object-cover" />
      ) : (
        <div className="flex h-full min-h-[260px] items-center justify-center p-8 text-center text-2xl font-black text-white">
          {alt}
        </div>
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-[#031b3d]/75 via-[#031b3d]/20 to-transparent" />
      {children}
    </div>
  );
}

export default function CareerEventDetailPage() {
  const params = useParams<{ slug: string }>();
  const data = useSyncExternalStore(
    subscribeCareerCms,
    getCareerCmsData,
    () => defaultCareerCmsData,
  );

  const event = useMemo(
    () => data.events.find((item) => item.slug === params.slug),
    [data.events, params.slug],
  );

  if (!event) {
    return (
      <main className="min-h-screen bg-[#f6fbff] px-4 py-20">
        <div className="mx-auto max-w-4xl rounded-[32px] bg-white p-10 text-center shadow-sm">
          <h1 className="text-4xl font-black text-[#07346f]">
            Event not found
          </h1>
          <Link
            href="/career"
            className="mt-6 inline-flex items-center gap-3 rounded-2xl bg-[#07346f] px-6 py-4 font-black text-white"
          >
            <ArrowLeft size={20} /> Back to Career
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#f6fbff] px-4 py-10 text-slate-900">
      <div className="mx-auto max-w-6xl">
        <Link
          href="/career"
          className="mb-6 inline-flex items-center gap-3 rounded-full bg-white px-5 py-3 font-black text-[#07346f] shadow-sm"
        >
          <ArrowLeft size={18} /> Back to Career
        </Link>

        <article className="overflow-hidden rounded-[36px] border border-slate-200 bg-white shadow-sm">
          <ImageBox src={event.imageUrl} alt={event.title} className="h-[460px]">
            <div className="absolute bottom-10 left-8 right-8">
              <span className="inline-flex items-center gap-2 rounded-2xl bg-[#07346f]/80 px-5 py-3 text-xs font-black uppercase tracking-[0.2em] text-white backdrop-blur">
                <HeartHandshake size={18} /> {event.label}
              </span>
              <h1 className="mt-5 max-w-4xl text-4xl font-black leading-tight text-white md:text-6xl">
                {event.title}
              </h1>
            </div>
          </ImageBox>

          <div className="grid gap-8 p-6 md:grid-cols-[1fr_320px] md:p-10">
            <div className="grid gap-6">
              <p className="text-xl font-black leading-9 text-slate-700">
                {event.excerpt}
              </p>
              {event.contentParagraphs.map((paragraph) => (
                <p
                  key={paragraph}
                  className="font-semibold leading-8 text-slate-600"
                >
                  {paragraph}
                </p>
              ))}
            </div>

            <aside className="h-fit rounded-[30px] border border-slate-200 bg-slate-50 p-6">
              <span className="inline-flex size-14 items-center justify-center rounded-2xl bg-[#07346f] text-white">
                <HeartHandshake />
              </span>
              <h2 className="mt-5 text-2xl font-black text-[#07346f]">
                Event Details
              </h2>
              <div className="mt-5 grid gap-3">
                <div className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 font-bold text-slate-600">
                  <CalendarDays size={18} className="text-violet-500" />
                  {event.date}
                </div>
                <div className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 font-bold text-slate-600">
                  <MapPin size={18} className="text-cyan-500" />
                  {event.location}
                </div>
              </div>
            </aside>
          </div>
        </article>
      </div>
    </main>
  );
}
