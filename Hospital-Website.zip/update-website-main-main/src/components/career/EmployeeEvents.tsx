// File: clinic-website/src/components/career/EmployeeEvents.tsx

import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  CalendarDays,
  HeartHandshake,
  Sparkles,
} from "lucide-react";

const events = [
  {
    slug: "healthy-week-2025",
    title: "Healthy Week 2025 at Update Diagnostic Center",
    date: "14 July 2025",
    image: "/blogs/blog-1.jpg",
  },
  {
    slug: "campus-activation-afmc",
    title: "Campus Activation in Armed Forces Medical College (AFMC)",
    date: "14 July 2025",
    image: "/news/news-2.jpg",
  },
  {
    slug: "campus-activation-north-south-university",
    title: "Campus Activation in North South University",
    date: "01 March 2025",
    image: "/doctor-articles/doctor-2.jpg",
  },
];

export default function EmployeeEvents() {
  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 text-[#062d62] sm:py-14 lg:py-20">
      {/* Premium Minimal Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />

        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
        <div className="absolute left-1/2 top-[45%] h-[300px] w-[300px] -translate-x-1/2 rounded-full bg-[#8cc63f]/8 blur-[100px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062d62]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,45,98,0.08)] backdrop-blur-md">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062d62] text-white shadow-[0_10px_25px_rgba(6,45,98,0.18)]">
              <HeartHandshake size={16} />
            </span>

            <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
              Employee Life
            </span>
          </div>

          <h2 className="text-center text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
            Employee Engagement{" "}
            <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062d62] bg-clip-text text-transparent">
              & Events
              <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
            </span>
          </h2>

          <p className="mx-auto mt-4 max-w-2xl text-sm font-semibold leading-7 text-[#4d6380] sm:mt-6 sm:text-base sm:leading-8">
            Celebrating team culture, learning activities, and meaningful
            moments that inspire our people.
          </p>
        </div>

        {/* Event Cards */}
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:mt-14 xl:grid-cols-3">
          {events.map((event, index) => (
            <article
              key={event.title}
              className="group relative overflow-hidden rounded-[24px] border border-white/80 bg-white/80 p-1.5 shadow-[0_20px_55px_rgba(6,45,98,0.10)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:bg-white hover:shadow-[0_30px_80px_rgba(6,45,98,0.16)] sm:rounded-[30px] sm:p-2"
            >
              <div className="pointer-events-none absolute right-[-60px] top-[-60px] h-[160px] w-[160px] rounded-full bg-[#43c7f4]/12 blur-[45px] transition-all duration-500 group-hover:bg-[#8a6bb8]/14" />

              {/* Image */}
              <div className="relative h-48 overflow-hidden rounded-[20px] bg-slate-100 sm:h-56 sm:rounded-[24px]">
                <Image
                  src={event.image}
                  alt={event.title}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 400px"
                  className="object-cover transition-transform duration-[1000ms] ease-out group-hover:scale-110"
                />

                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#062d62]/70 via-[#062d62]/10 to-transparent opacity-85 transition-opacity duration-500 group-hover:opacity-95" />

                {/* Animated Top Icon */}
                <div className="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/25 bg-white/20 text-white shadow-[0_16px_40px_rgba(6,45,98,0.22)] backdrop-blur-md transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-white group-hover:text-[#062d62]">
                  <Sparkles
                    size={23}
                    className="transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110"
                  />
                </div>

                {/* Number Badge */}
                <div className="absolute bottom-5 left-5 rounded-full border border-white/25 bg-white/90 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-[#062d62] shadow-[0_14px_35px_rgba(6,45,98,0.18)] backdrop-blur-md">
                  Event {String(index + 1).padStart(2, "0")}
                </div>

                {/* Shine */}
                <div className="pointer-events-none absolute inset-y-0 left-0 w-20 -translate-x-28 rotate-12 bg-white/25 blur-md transition-transform duration-1000 group-hover:translate-x-[460px]" />
              </div>

              {/* Content */}
              <div className="relative z-10 p-5 sm:p-6">
                <p className="inline-flex items-center gap-2 rounded-full border border-[#dbeafe] bg-[#f8fbff] px-4 py-2 text-sm font-black text-[#9063b4]">
                  <CalendarDays
                    size={16}
                    className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6 group-hover:scale-110"
                  />
                  {event.date}
                </p>

                <h3 className="mt-5 text-xl font-black leading-tight text-[#062d62] transition-colors duration-300 group-hover:text-[#8a6bb8] sm:text-2xl">
                  {event.title}
                </h3>

                <Link
                  href={`/career/events/${event.slug}`}
                  className="group/button mt-6 inline-flex min-h-11 items-center gap-3 text-sm font-black text-[#46bfdf] transition-all duration-300 hover:-translate-y-0.5 hover:text-[#062d62] sm:mt-7 sm:text-base"
                >
                  <span className="relative inline-block after:absolute after:left-0 after:-bottom-[6px] after:h-[3px] after:w-0 after:rounded-full after:bg-gradient-to-r after:from-[#46bfdf] after:via-[#8a6bb8] after:to-[#062d62] after:transition-all after:duration-300 group-hover/button:after:w-full">
                    Read More
                  </span>

                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#46bfdf]/12 text-[#46bfdf] transition-all duration-300 group-hover/button:translate-x-1 group-hover/button:-translate-y-1 group-hover/button:rotate-6 group-hover/button:scale-110 group-hover/button:bg-[#062d62] group-hover/button:text-white">
                    <ArrowRight size={18} />
                  </span>
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
