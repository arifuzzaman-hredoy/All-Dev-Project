"use client";

import Image from "next/image";
import { useEffect, useState } from "react";

const slides = [
  {
    src: "/doctor-articles/doctor-2.jpg",
    alt: "Healthcare professionals at Update Diagnostic Center",
  },
  {
    src: "/slider1.jpeg",
    alt: "Care team assisting patients inside the hospital",
  },
  {
    src: "/news/news-1.jpg",
    alt: "Doctor ready to support a patient consultation",
  },
  {
    src: "/blogs/blog-2.jpg",
    alt: "Family receiving compassionate hospital care",
  },
];

const SLIDE_INTERVAL_MS = 4500;

export default function CareerHero() {
  const [activeSlide, setActiveSlide] = useState(0);

  function showPreviousSlide() {
    setActiveSlide((currentSlide) =>
      currentSlide === 0 ? slides.length - 1 : currentSlide - 1,
    );
  }

  function showNextSlide() {
    setActiveSlide((currentSlide) => (currentSlide + 1) % slides.length);
  }

  useEffect(() => {
    const intervalId = window.setInterval(showNextSlide, SLIDE_INTERVAL_MS);

    return () => {
      window.clearInterval(intervalId);
    };
  }, []);

  return (
    <section className="bg-white pt-0">
      <div className="relative h-[260px] w-full overflow-hidden bg-slate-100 sm:h-[430px] lg:h-[556px]">
        {slides.map((slide, index) => (
          <Image
            key={slide.src}
            src={slide.src}
            alt={slide.alt}
            fill
            priority={index === 0}
            sizes="100vw"
            className={`object-cover object-center transition-opacity duration-700 ${
              activeSlide === index ? "opacity-100" : "opacity-0"
            }`}
          />
        ))}

        <button
          type="button"
          aria-label="Previous career banner"
          onClick={showPreviousSlide}
          className="absolute left-3 top-1/2 grid size-9 -translate-y-1/2 place-items-center rounded-full bg-white/85 text-[#062d62] shadow-sm transition hover:bg-white sm:left-5"
        >
          ‹
        </button>

        <button
          type="button"
          aria-label="Next career banner"
          onClick={showNextSlide}
          className="absolute right-3 top-1/2 grid size-9 -translate-y-1/2 place-items-center rounded-full bg-white/85 text-[#062d62] shadow-sm transition hover:bg-white sm:right-5"
        >
          ›
        </button>

        <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 gap-2">
          {slides.map((slide, index) => (
            <button
              key={slide.src}
              type="button"
              aria-label={`Show career banner ${index + 1}`}
              onClick={() => setActiveSlide(index)}
              className={`h-2.5 rounded-full transition-all ${
                activeSlide === index
                  ? "w-8 bg-white"
                  : "w-2.5 bg-white/55 hover:bg-white"
              }`}
            />
          ))}
        </div>
      </div>

      <div className="grid h-3 grid-cols-[1fr_1fr_1fr_1fr]" aria-hidden="true">
        <span className="bg-[#062d62]" />
        <span className="bg-[#45b3dc]" />
        <span className="bg-[#8b65ad]" />
        <span className="bg-[#98c45d]" />
      </div>
    </section>
  );
}
