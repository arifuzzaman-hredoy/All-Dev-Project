// File: clinic-website/src/components/career/ResumeCallToAction.tsx

import { ArrowRight, FileUp } from "lucide-react";

export default function ResumeCallToAction() {
  return (
    <section className="relative overflow-hidden bg-[#062d62] py-10 text-white sm:py-14">
      {/* Premium Simple Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#041d43_0%,#062d62_48%,#083f82_100%)]" />

        <div className="absolute left-[-160px] top-[-130px] h-[340px] w-[340px] rounded-full bg-[#43c7f4]/18 blur-[95px]" />
        <div className="absolute right-[-170px] bottom-[-140px] h-[370px] w-[370px] rounded-full bg-[#8a6bb8]/18 blur-[105px]" />
        <div className="absolute left-1/2 top-[35%] h-[240px] w-[240px] -translate-x-1/2 rounded-full bg-[#8cc63f]/10 blur-[90px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.10)_1px,transparent_0)] [background-size:30px_30px] opacity-25" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/35 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-[24px] border border-white/12 bg-white/10 p-5 shadow-[0_24px_70px_rgba(0,0,0,0.22)] backdrop-blur-xl sm:rounded-[30px] sm:p-8 lg:p-10">
          <div className="pointer-events-none absolute right-[-80px] top-[-80px] h-[190px] w-[190px] rounded-full bg-[#43c7f4]/18 blur-[55px]" />
          <div className="pointer-events-none absolute bottom-[-90px] left-[35%] h-[190px] w-[190px] rounded-full bg-[#8a6bb8]/18 blur-[55px]" />

          <div className="relative z-10 flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <h2 className="text-2xl font-black leading-tight sm:text-4xl lg:text-5xl">
                Join{" "}
                <span className="bg-gradient-to-r from-[#43c7f4] via-white to-[#8cc63f] bg-clip-text text-transparent">
                  Us
                </span>
              </h2>

              <p className="mt-4 text-sm font-semibold leading-7 text-blue-50/90 sm:text-base lg:text-lg lg:leading-8">
                Submit your resume, we will contact you when a relevant
                opportunity becomes available.
              </p>
            </div>

            <button
              type="button"
              className="group relative inline-flex min-h-12 w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-white px-6 py-3 text-sm font-black uppercase tracking-[0.07em] text-[#062d62] shadow-[0_20px_55px_rgba(0,0,0,0.20)] transition-all duration-300 hover:-translate-y-1 hover:bg-[#43c7f4] hover:text-white hover:shadow-[0_24px_70px_rgba(67,199,244,0.26)] sm:min-h-14 sm:w-auto sm:px-8"
            >
              <span className="absolute inset-y-0 left-0 w-12 -translate-x-16 rotate-12 bg-white/45 blur-md transition-transform duration-700 group-hover:translate-x-[310px]" />

              <FileUp
                size={19}
                className="relative z-10 transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110"
              />

              <span className="relative z-10">Submit Your Resume</span>

              <ArrowRight
                size={18}
                className="relative z-10 transition-transform duration-300 group-hover:translate-x-1"
              />
            </button>
          </div>

        </div>
      </div>
    </section>
  );
}
