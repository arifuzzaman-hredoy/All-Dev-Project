/* eslint-disable @next/next/no-img-element */
"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Award,
  BriefcaseBusiness,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  FileUp,
  GraduationCap,
  HeartHandshake,
  MapPin,
  Sparkles,
  Stethoscope,
  UsersRound,
  X,
} from "lucide-react";
import {
  type ChangeEvent,
  type ReactNode,
  useMemo,
  useState,
  useSyncExternalStore,
} from "react";
import {
  addCareerApplication,
  type CareerIconKey,
  type CareerJob,
  defaultCareerCmsData,
  fileToDataUrl,
  getCareerCmsData,
  subscribeCareerCms,
} from "@/lib/careerCms";

type ApplyFormState = {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  education: string;
  experience: string;
  expectedSalary: string;
  coverNote: string;
  resumeFileName?: string;
  resumeDataUrl?: string;
};

const emptyForm: ApplyFormState = {
  fullName: "",
  phone: "",
  email: "",
  address: "",
  education: "",
  experience: "",
  expectedSalary: "",
  coverNote: "",
  resumeFileName: "",
  resumeDataUrl: "",
};

function useCareerCms() {
  return useSyncExternalStore(
    subscribeCareerCms,
    getCareerCmsData,
    () => defaultCareerCmsData,
  );
}

function CareerIcon({ icon }: { icon: CareerIconKey }) {
  const icons: Record<CareerIconKey, ReactNode> = {
    users: <UsersRound size={24} />,
    heart: <HeartHandshake size={24} />,
    growth: <Sparkles size={24} />,
    briefcase: <BriefcaseBusiness size={24} />,
    award: <Award size={24} />,
    stethoscope: <Stethoscope size={24} />,
    graduation: <GraduationCap size={24} />,
  };

  return (
    <span className="inline-flex size-12 items-center justify-center rounded-2xl bg-cyan-50 text-cyan-500 transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-cyan-400 group-hover:text-white">
      {icons[icon]}
    </span>
  );
}

function ImageBox({
  src,
  alt,
  className = "",
  children,
}: {
  src?: string;
  alt: string;
  className?: string;
  children?: ReactNode;
}) {
  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-br from-[#07346f] via-[#0c82aa] to-[#42c5e8] ${className}`}
    >
      {src ? (
        <img src={src} alt={alt} className="h-full w-full object-cover" />
      ) : (
        <div className="flex h-full min-h-[220px] items-center justify-center p-6 text-center text-lg font-black text-white">
          {alt}
        </div>
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-[#031b3d]/65 via-transparent to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 left-0 w-20 -translate-x-28 rotate-12 bg-white/25 blur-md transition-transform duration-1000 group-hover:translate-x-[520px]" />
      {children}
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-black text-[#07346f]">{label}</span>
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold outline-none focus:border-cyan-400"
      />
    </label>
  );
}

function ApplyModal({
  job,
  onClose,
}: {
  job?: CareerJob;
  onClose: () => void;
}) {
  const [form, setForm] = useState<ApplyFormState>(emptyForm);
  const [done, setDone] = useState(false);

  const patch = (key: keyof ApplyFormState, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  async function handleResume(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    const dataUrl = await fileToDataUrl(file);

    setForm((current) => ({
      ...current,
      resumeFileName: file.name,
      resumeDataUrl: dataUrl,
    }));
  }

  function submit() {
    if (!form.fullName.trim() || !form.phone.trim()) {
      alert("Name and phone number required.");
      return;
    }

    addCareerApplication({
      applyType: job ? "job" : "general",
      jobId: job?.id,
      jobTitle: job?.title,
      department: job?.categoryLabel,
      ...form,
    });

    setDone(true);
    setForm(emptyForm);
  }

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center bg-[#031b3d]/70 p-4 backdrop-blur-sm">
      <div className="max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-[32px] bg-white p-6 shadow-2xl">
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.25em] text-cyan-500">
              Career Application
            </p>
            <h2 className="mt-2 text-3xl font-black text-[#07346f]">
              {job ? `Apply for ${job.title}` : "Submit your resume"}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-full bg-slate-100 p-3 text-slate-500"
          >
            <X size={20} />
          </button>
        </div>

        {done ? (
          <div className="rounded-3xl bg-emerald-50 p-6 text-center">
            <h3 className="text-2xl font-black text-emerald-700">
              Submitted successfully
            </h3>
            <p className="mt-2 font-semibold text-emerald-700">
              Admin panel applications section-e ei submission dekha jabe.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="mt-5 rounded-2xl bg-[#07346f] px-6 py-3 font-black text-white"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            <Input
              label="Full Name"
              value={form.fullName}
              onChange={(value) => patch("fullName", value)}
            />
            <Input
              label="Phone"
              value={form.phone}
              onChange={(value) => patch("phone", value)}
            />
            <Input
              label="Email"
              value={form.email}
              onChange={(value) => patch("email", value)}
            />
            <Input
              label="Address"
              value={form.address}
              onChange={(value) => patch("address", value)}
            />
            <Input
              label="Education"
              value={form.education}
              onChange={(value) => patch("education", value)}
            />
            <Input
              label="Experience"
              value={form.experience}
              onChange={(value) => patch("experience", value)}
            />
            <Input
              label="Expected Salary"
              value={form.expectedSalary}
              onChange={(value) => patch("expectedSalary", value)}
            />

            <label className="grid gap-2">
              <span className="text-sm font-black text-[#07346f]">
                Resume / CV
              </span>
              <input
                type="file"
                accept=".pdf,.doc,.docx,.jpg,.png"
                onChange={handleResume}
                className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold outline-none"
              />
              {form.resumeFileName ? (
                <span className="text-xs font-bold text-cyan-600">
                  Selected: {form.resumeFileName}
                </span>
              ) : null}
            </label>

            <label className="grid gap-2 md:col-span-2">
              <span className="text-sm font-black text-[#07346f]">
                Cover Note
              </span>
              <textarea
                rows={5}
                value={form.coverNote}
                onChange={(event) => patch("coverNote", event.target.value)}
                className="resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold leading-7 outline-none focus:border-cyan-400"
              />
            </label>

            <button
              type="button"
              onClick={submit}
              className="inline-flex w-full items-center justify-center gap-3 rounded-2xl bg-[#07346f] px-6 py-4 font-black uppercase tracking-[0.15em] text-white md:col-span-2"
            >
              Submit Application <ArrowRight size={20} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function CareerPublicPage() {
  const router = useRouter();
  const data = useCareerCms();
  const [slideIndex, setSlideIndex] = useState(0);
  const [department, setDepartment] = useState("all");
  const [applyJob, setApplyJob] = useState<CareerJob | undefined>();
  const [generalApply, setGeneralApply] = useState(false);

  const activeSlide = data.heroSlides[slideIndex] || data.heroSlides[0];

  const jobs = useMemo(
    () =>
      data.jobs.filter(
        (job) =>
          job.status === "open" &&
          (department === "all" || job.departmentId === department),
      ),
    [data.jobs, department],
  );

  const nextSlide = () => {
    setSlideIndex((current) =>
      data.heroSlides.length ? (current + 1) % data.heroSlides.length : 0,
    );
  };

  const previousSlide = () => {
    setSlideIndex((current) =>
      data.heroSlides.length
        ? (current - 1 + data.heroSlides.length) % data.heroSlides.length
        : 0,
    );
  };

  return (
    <main className="min-h-screen bg-[#f7fbff] text-slate-900">
      <section>
        <ImageBox
          src={activeSlide?.imageUrl}
          alt={activeSlide?.title || "Career Banner"}
          className="h-[320px] md:h-[560px]"
        >
          <button
            type="button"
            onClick={previousSlide}
            className="absolute left-5 top-1/2 grid size-12 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-[#07346f]"
            aria-label="Previous career slide"
          >
            <ChevronLeft />
          </button>
          <button
            type="button"
            onClick={nextSlide}
            className="absolute right-5 top-1/2 grid size-12 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-[#07346f]"
            aria-label="Next career slide"
          >
            <ChevronRight />
          </button>
        </ImageBox>
        <div className="h-2 bg-gradient-to-r from-[#062d62] via-[#43c7f4] to-[#8cc63f]" />
      </section>

      <section className="relative overflow-hidden bg-[#f7fbff] px-4 py-10 text-center sm:py-14 lg:py-20">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
          <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
          <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
        </div>
        <div className="relative z-10 mx-auto max-w-6xl">
          <div className="inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8] shadow-[0_14px_40px_rgba(6,45,98,0.08)] backdrop-blur-md">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062d62] text-white">
              <BriefcaseBusiness size={16} />
            </span>
            {data.intro.badge}
          </div>
        <h1 className="mt-6 text-4xl font-black text-[#07346f] md:text-6xl">
          {data.intro.titleBefore}{" "}
          <span className="bg-gradient-to-r from-violet-500 to-cyan-500 bg-clip-text text-transparent">
            {data.intro.highlight}
          </span>
          {data.intro.titleAfter}
        </h1>
        <h2 className="mt-5 text-xl font-black text-slate-900">
          {data.intro.subtitle}
        </h2>
        <p className="mx-auto mt-6 max-w-3xl text-base font-semibold leading-8 text-slate-600">
          {data.intro.description}
        </p>
        <div className="mx-auto mt-10 grid max-w-4xl gap-5 md:grid-cols-3">
          {data.intro.values.map((item) => (
            <div
              key={item.id}
              className="group rounded-[24px] border border-white/80 bg-white/80 p-8 shadow-[0_20px_55px_rgba(6,45,98,0.10)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white"
            >
              <CareerIcon icon={item.icon} />
              <h3 className="mt-4 font-black text-[#07346f]">{item.title}</h3>
            </div>
          ))}
        </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-8 px-4 pb-20 md:grid-cols-[300px_1fr]">
        <div className="text-center">
          <ImageBox
            src={data.hrMessage.photoUrl}
            alt={data.hrMessage.name}
            className="mx-auto size-36 rounded-[32px]"
          />
          <h3 className="mt-5 text-2xl font-black text-[#07346f]">
            {data.hrMessage.name}
          </h3>
          <p className="mt-2 font-bold text-slate-500">
            {data.hrMessage.designation}
          </p>
        </div>
        <div className="rounded-[30px] border border-white/80 bg-white/85 p-8 shadow-[0_22px_60px_rgba(6,45,98,0.10)] backdrop-blur-xl md:p-12">
          <span className="inline-flex size-14 items-center justify-center rounded-2xl bg-[#07346f] text-white">
            <HeartHandshake />
          </span>
          <h2 className="mt-6 text-3xl font-black text-[#07346f] md:text-5xl">
            {data.hrMessage.title}
          </h2>
          <div className="mt-7 grid gap-5">
            {data.hrMessage.paragraphs.map((paragraph) => (
              <p key={paragraph} className="font-semibold leading-8 text-slate-600">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-[#f7fbff] px-4 py-10 text-[#062d62] sm:py-14 lg:py-20">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
          <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
          <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
        </div>
        <div className="relative z-10 mx-auto max-w-7xl">
        <div className="text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8] shadow-[0_14px_40px_rgba(6,45,98,0.08)] backdrop-blur-md">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062d62] text-white">
              <BriefcaseBusiness size={16} />
            </span>
            Career Opportunities
          </div>
          <h2 className="text-4xl font-black text-[#07346f] md:text-6xl">
            Apply for{" "}
            <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062d62] bg-clip-text text-transparent">
              a Job
              <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
            </span>
          </h2>
          <select
            value={department}
            onChange={(event) => setDepartment(event.target.value)}
            className="mt-8 rounded-full border border-[#dbeafe] bg-white/85 px-6 py-4 font-bold text-[#07346f] shadow-[0_16px_45px_rgba(6,45,98,0.08)] outline-none backdrop-blur-xl"
          >
            <option value="all">All Departments</option>
            {data.departments.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {jobs.map((job) => (
            <article
              key={job.id}
              className="group relative overflow-hidden rounded-[24px] border border-white/80 bg-white/80 p-1.5 shadow-[0_20px_55px_rgba(6,45,98,0.10)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:bg-white hover:shadow-[0_30px_80px_rgba(6,45,98,0.16)] sm:rounded-[30px] sm:p-2"
            >
              <ImageBox src={job.imageUrl} alt={job.title} className="h-48 rounded-[20px] sm:h-56 sm:rounded-[24px]">
                <span className="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/25 bg-white/20 text-white shadow-[0_16px_40px_rgba(6,45,98,0.22)] backdrop-blur-md transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-white group-hover:text-[#062d62]">
                  <BriefcaseBusiness size={23} />
                </span>
                <span className="absolute bottom-5 left-5 rounded-full border border-white/25 bg-white/90 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-[#07346f] shadow-[0_14px_35px_rgba(6,45,98,0.18)] backdrop-blur-md">
                  {job.categoryLabel}
                </span>
              </ImageBox>
              <div className="relative z-10 p-4 sm:p-5">
                <div className="mb-5 flex flex-wrap gap-3">
                  <span className="inline-flex items-center gap-2 rounded-full border border-[#dbeafe] bg-[#f8fbff] px-4 py-2 text-sm font-black text-[#07346f]">
                    <MapPin size={16} /> {job.location}
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full border border-[#dbeafe] bg-[#f8fbff] px-4 py-2 text-sm font-black text-[#07346f]">
                    <UsersRound size={16} /> {job.type}
                  </span>
                </div>
                <h3 className="text-2xl font-black leading-tight text-[#07346f] transition-colors duration-300 group-hover:text-[#8a6bb8]">
                  {job.title}
                </h3>
                <p className="mt-3 font-semibold leading-7 text-slate-600">
                  {job.summary}
                </p>
                <div className="mt-5 grid gap-3">
                  <div className="inline-flex items-center gap-3 rounded-2xl bg-[#f8fbff] p-4 font-bold text-slate-600 ring-1 ring-[#062d62]/8">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#43c7f4]/12 text-[#43c7f4]"><BriefcaseBusiness size={16} /></span>
                    <span>Vacancy: {job.vacancy}</span>
                  </div>
                  <div className="inline-flex items-center gap-3 rounded-2xl bg-[#f8fbff] p-4 font-bold text-slate-600 ring-1 ring-[#062d62]/8">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#8a6bb8]/12 text-[#8a6bb8]"><CalendarDays size={16} /></span>
                    <span>Deadline: {job.deadline}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setApplyJob(job);
                    router.push(`/career/apply?position=${encodeURIComponent(
                      job.title,
                    )}`);
                  }}
                  className="group/button relative mt-6 inline-flex min-h-12 w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-[#062d62] px-6 py-4 font-black uppercase tracking-[0.07em] text-white shadow-[0_18px_45px_rgba(6,45,98,0.22)] transition-all duration-300 hover:-translate-y-1 hover:bg-[#43c7f4]"
                >
                  Apply Now <ArrowRight size={20} />
                </button>
              </div>
            </article>
          ))}
        </div>
        </div>
      </section>

      <section className="bg-[#07346f] py-16 text-white">
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 md:grid-cols-[1fr_auto]">
          <div>
            <h2 className="text-4xl font-black md:text-6xl">
              {data.joinUs.titleBefore}{" "}
              <span className="text-cyan-300">{data.joinUs.highlight}</span>
            </h2>
            <p className="mt-5 max-w-2xl text-lg font-bold leading-8 text-white/80">
              {data.joinUs.description}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setGeneralApply(true);
              router.push("/career/apply");
            }}
            className="inline-flex items-center justify-center gap-3 rounded-full bg-white px-8 py-5 font-black uppercase tracking-[0.15em] text-[#07346f]"
          >
            <FileUp size={20} /> {data.joinUs.buttonLabel}
          </button>
        </div>
      </section>

      <section className="relative overflow-hidden bg-[#f7fbff] px-4 py-10 sm:py-14 lg:py-20">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
          <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
          <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
        </div>
        <div className="relative z-10 mx-auto max-w-7xl">
        <div className="text-center">
          <div className="inline-flex items-center gap-3 rounded-full bg-white px-5 py-3 text-xs font-black uppercase tracking-[0.25em] text-violet-500 shadow">
            <HeartHandshake size={18} className="text-[#07346f]" />
            Employee Life
          </div>
          <h2 className="mt-6 text-4xl font-black text-[#07346f] md:text-6xl">
            Employee Engagement{" "}
            <span className="bg-gradient-to-r from-violet-500 to-cyan-500 bg-clip-text text-transparent">
              & Events
            </span>
          </h2>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {data.events.map((event) => (
            <article
              key={event.id}
              className="group relative overflow-hidden rounded-[24px] border border-white/80 bg-white/80 p-1.5 shadow-[0_20px_55px_rgba(6,45,98,0.10)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:bg-white hover:shadow-[0_30px_80px_rgba(6,45,98,0.16)] sm:rounded-[30px] sm:p-2"
            >
              <ImageBox src={event.imageUrl} alt={event.title} className="h-56 rounded-[24px]">
                <span className="absolute bottom-5 left-5 rounded-full border border-white/25 bg-white/90 px-4 py-2 text-xs font-black uppercase tracking-[0.15em] text-[#07346f] shadow-[0_14px_35px_rgba(6,45,98,0.18)] backdrop-blur-md">
                  {event.label}
                </span>
              </ImageBox>
              <div className="p-5">
                <span className="inline-flex items-center gap-2 rounded-full bg-violet-50 px-4 py-2 text-sm font-black text-violet-500">
                  <CalendarDays size={16} /> {event.date}
                </span>
                <h3 className="mt-5 text-2xl font-black leading-tight text-[#07346f]">
                  {event.title}
                </h3>
                <p className="mt-3 font-semibold leading-7 text-slate-600">
                  {event.excerpt}
                </p>
                <Link
                  href={`/career/events/${event.slug}`}
                  className="mt-5 inline-flex items-center gap-3 font-black text-cyan-500"
                >
                  Read More{" "}
                  <span className="grid size-10 place-items-center rounded-full bg-cyan-50">
                    <ArrowRight size={18} />
                  </span>
                </Link>
              </div>
            </article>
          ))}
        </div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-[#f7fbff] px-4 py-10 sm:py-14 lg:py-20">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
          <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
          <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
        </div>
        <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-10 md:grid-cols-[420px_1fr]">
        <ImageBox
          src={data.feature.imageUrl}
          alt={data.feature.title}
          className="h-[430px] rounded-[30px] border border-white/80 p-1.5 shadow-[0_22px_60px_rgba(6,45,98,0.10)]"
        >
          <span className="absolute bottom-6 left-6 rounded-2xl bg-white px-5 py-3 text-xs font-black uppercase tracking-[0.2em] text-[#07346f]">
            {data.feature.imageLabel}
          </span>
        </ImageBox>
        <div>
          <div className="inline-flex items-center gap-3 rounded-full bg-white px-5 py-3 text-xs font-black uppercase tracking-[0.25em] text-violet-500 shadow">
            <GraduationCap size={18} className="text-[#07346f]" />
            {data.feature.badge}
          </div>
          <h2 className="mt-6 text-4xl font-black leading-tight text-[#07346f] md:text-6xl">
            {data.feature.title}
          </h2>
          <p className="mt-6 text-lg font-semibold leading-8 text-slate-600">
            {data.feature.description}
          </p>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            {data.feature.cards.map((card) => (
              <div
                key={card.id}
                className="group rounded-[22px] border border-[#dbeafe] bg-white/80 p-6 shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white"
              >
                <CareerIcon icon={card.icon} />
                <h3 className="mt-4 font-black text-[#07346f]">
                  {card.title}
                </h3>
              </div>
            ))}
          </div>
        </div>
        </div>
      </section>

      {applyJob ? (
        <ApplyModal job={applyJob} onClose={() => setApplyJob(undefined)} />
      ) : null}
      {generalApply ? (
        <ApplyModal onClose={() => setGeneralApply(false)} />
      ) : null}
    </main>
  );
}
