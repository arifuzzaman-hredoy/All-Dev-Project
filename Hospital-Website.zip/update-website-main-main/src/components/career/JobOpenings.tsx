"use client";

// File: clinic-website/src/components/career/JobOpenings.tsx

import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronDown,
  Filter,
  MapPin,
  Sparkles,
  UsersRound,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

const departments = ["All Departments", "Medical", "Non Medical", "Nursing"];

const jobs = [
  {
    title: "Resident Medical Officer",
    department: "Medical",
    image: "/news/news-1.jpg",
    location: "Dhaka",
    type: "Full Time",
    vacancy: "Multiple",
    deadline: "N/A",
  },
  {
    title: "Staff Nurse",
    department: "Nursing",
    image: "/blogs/blog-2.jpg",
    location: "Dhaka",
    type: "Full Time",
    vacancy: "Multiple",
    deadline: "N/A",
  },
  {
    title: "Customer Care Officer",
    department: "Non Medical",
    image: "/slider4.jpeg",
    location: "Dhaka",
    type: "Full Time",
    vacancy: "Multiple",
    deadline: "31 July 2026",
  },
  {
    title: "Patient Support Assistant",
    department: "Non Medical",
    image: "/pasent.jpeg",
    location: "Dhaka",
    type: "Full Time",
    vacancy: "Multiple",
    deadline: "N/A",
  },
  {
    title: "Infection Control Nurse",
    department: "Nursing",
    image: "/slider4.jpeg",
    location: "Dhaka",
    type: "Full Time",
    vacancy: "Multiple",
    deadline: "N/A",
  },
];

export default function JobOpenings() {
  const [selectedDepartment, setSelectedDepartment] = useState(departments[0]);
  const [menuOpen, setMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  const visibleJobs = useMemo(() => {
    if (selectedDepartment === "All Departments") return jobs;
    return jobs.filter((job) => job.department === selectedDepartment);
  }, [selectedDepartment]);

  useEffect(() => {
    function handleOutsideClick(event: MouseEvent) {
      if (!dropdownRef.current) return;

      if (!dropdownRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }

    function handleEscape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setMenuOpen(false);
      }
    }

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 text-[#062d62] sm:py-14 lg:py-20">
      {/* Premium Minimal Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
        <div className="absolute left-1/2 top-[45%] h-[300px] w-[300px] -translate-x-1/2 rounded-full bg-[#8cc63f]/8 blur-[100px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062d62]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,45,98,0.08)] backdrop-blur-md">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062d62] text-white shadow-[0_10px_25px_rgba(6,45,98,0.18)]">
              <BriefcaseBusiness size={16} />
            </span>

            <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
              Career Opportunities
            </span>
          </div>

          <h2 className="text-center text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
            Apply for{" "}
            <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062d62] bg-clip-text text-transparent">
              a Job
              <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
            </span>
          </h2>

          <p className="mx-auto mt-4 max-w-2xl text-sm font-semibold leading-7 text-[#4d6380] sm:mt-6 sm:text-base sm:leading-8">
            Explore available positions and choose the department that matches
            your skills, passion, and career goal.
          </p>
        </div>

        {/* Filter Dropdown */}
        <div
          ref={dropdownRef}
          className="relative z-20 mx-auto mt-6 w-full max-w-[260px] sm:mt-10"
        >
          <button
            type="button"
            onClick={() => setMenuOpen((value) => !value)}
            aria-expanded={menuOpen}
            className="group flex min-h-12 w-full items-center justify-between rounded-full border border-[#dbeafe] bg-white/85 px-5 py-3 text-left text-sm font-black text-[#061b3d] shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:border-[#43c7f4]/45 hover:bg-white hover:shadow-[0_22px_60px_rgba(6,45,98,0.12)] sm:min-h-14"
          >
            <span className="inline-flex items-center gap-2">
              <Filter
                size={17}
                className="text-[#8a6bb8] transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6 group-hover:scale-110"
              />
              {selectedDepartment}
            </span>

            <ChevronDown
              className={`h-4 w-4 transition-transform duration-300 ${
                menuOpen ? "rotate-180" : ""
              }`}
              aria-hidden="true"
            />
          </button>

          {menuOpen && (
            <div className="absolute left-0 top-[62px] w-full overflow-hidden rounded-[22px] border border-white/80 bg-white/95 p-2 shadow-[0_24px_70px_rgba(6,45,98,0.16)] ring-1 ring-[#062d62]/5 backdrop-blur-xl">
              {departments.map((department) => (
                <button
                  key={department}
                  type="button"
                  onClick={() => {
                    setSelectedDepartment(department);
                    setMenuOpen(false);
                  }}
                  className="group flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left text-sm font-black text-[#061b3d] transition-all duration-300 hover:translate-x-1 hover:bg-[#effaff] hover:text-[#062d62]"
                >
                  <span className="inline-flex items-center gap-2">
                    <Sparkles
                      size={15}
                      className="text-[#43c7f4] opacity-0 transition-all duration-300 group-hover:opacity-100 group-hover:rotate-12"
                    />
                    {department}
                  </span>

                  {selectedDepartment === department && (
                    <Check
                      className="h-4 w-4 text-[#43c7f4]"
                      aria-hidden="true"
                    />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Job Cards */}
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:mt-14 xl:grid-cols-3">
          {visibleJobs.map((job) => (
            <article
              key={job.title}
              className="group relative overflow-hidden rounded-[24px] border border-white/80 bg-white/80 p-1.5 shadow-[0_20px_55px_rgba(6,45,98,0.10)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:bg-white hover:shadow-[0_30px_80px_rgba(6,45,98,0.16)] sm:rounded-[30px] sm:p-2"
            >
              <div className="pointer-events-none absolute right-[-60px] top-[-60px] h-[160px] w-[160px] rounded-full bg-[#43c7f4]/12 blur-[45px] transition-all duration-500 group-hover:bg-[#8a6bb8]/14" />

              <div className="relative h-48 overflow-hidden rounded-[20px] bg-slate-100 sm:h-56 sm:rounded-[24px]">
                <Image
                  src={job.image}
                  alt={job.title}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 400px"
                  className="object-cover transition-transform duration-[1000ms] ease-out group-hover:scale-110"
                />

                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#062d62]/65 via-[#062d62]/10 to-transparent opacity-85 transition-opacity duration-500 group-hover:opacity-95" />

                <div className="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/25 bg-white/20 text-white shadow-[0_16px_40px_rgba(6,45,98,0.22)] backdrop-blur-md transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-white group-hover:text-[#062d62]">
                  <BriefcaseBusiness
                    size={23}
                    className="transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110"
                  />
                </div>

                <div className="absolute bottom-5 left-5 rounded-full border border-white/25 bg-white/90 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-[#062d62] shadow-[0_14px_35px_rgba(6,45,98,0.18)] backdrop-blur-md">
                  {job.department}
                </div>

                <div className="pointer-events-none absolute inset-y-0 left-0 w-20 -translate-x-28 rotate-12 bg-white/25 blur-md transition-transform duration-1000 group-hover:translate-x-[460px]" />
              </div>

              <div className="relative z-10 p-4 sm:p-5">
                <div className="flex flex-wrap items-center gap-3 text-sm font-bold text-[#061b3d]">
                  <span className="inline-flex items-center gap-2 rounded-full border border-[#dbeafe] bg-[#f8fbff] px-4 py-2 text-[#062d62]">
                    <MapPin
                      size={15}
                      className="text-[#43c7f4] transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:scale-110"
                    />
                    {job.location}
                  </span>

                  <span className="inline-flex items-center gap-2 rounded-full border border-[#dbeafe] bg-[#f8fbff] px-4 py-2 text-[#062d62]">
                    <UsersRound
                      size={15}
                      className="text-[#8a6bb8] transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:scale-110"
                    />
                    {job.type}
                  </span>
                </div>

                <h3 className="mt-5 text-xl font-black leading-tight text-[#062d62] transition-colors duration-300 group-hover:text-[#8a6bb8] sm:text-2xl">
                  {job.title}
                </h3>

                <div className="mt-5 grid gap-3 text-sm font-semibold text-[#4d6380]">
                  <span className="inline-flex items-center gap-3 rounded-2xl bg-[#f8fbff] px-4 py-3 ring-1 ring-[#062d62]/8">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#43c7f4]/12 text-[#43c7f4] transition-all duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6 group-hover:scale-110">
                      <BriefcaseBusiness
                        className="h-4 w-4"
                        aria-hidden="true"
                      />
                    </span>
                    Vacancy: {job.vacancy}
                  </span>

                  <span className="inline-flex items-center gap-3 rounded-2xl bg-[#f8fbff] px-4 py-3 ring-1 ring-[#062d62]/8">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#8a6bb8]/12 text-[#8a6bb8] transition-all duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6 group-hover:scale-110">
                      <CalendarDays className="h-4 w-4" aria-hidden="true" />
                    </span>
                    Deadline: {job.deadline}
                  </span>
                </div>

                <Link
                  href={{
                    pathname: "/career/apply",
                    query: { position: job.title },
                  }}
                  className="group/button relative mt-6 inline-flex min-h-12 w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-[#062d62] px-6 py-3 text-sm font-black uppercase tracking-[0.07em] text-white shadow-[0_18px_45px_rgba(6,45,98,0.22)] transition-all duration-300 hover:-translate-y-1 hover:bg-[#43c7f4] hover:shadow-[0_24px_65px_rgba(67,199,244,0.28)] sm:mt-8 sm:py-4"
                >
                  <span className="absolute inset-y-0 left-0 w-12 -translate-x-16 rotate-12 bg-white/25 blur-sm transition-transform duration-700 group-hover/button:translate-x-[420px]" />
                  <span className="relative z-10">Apply Now</span>
                  <ArrowRight
                    size={18}
                    className="relative z-10 transition-transform duration-300 group-hover/button:translate-x-1"
                  />
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
