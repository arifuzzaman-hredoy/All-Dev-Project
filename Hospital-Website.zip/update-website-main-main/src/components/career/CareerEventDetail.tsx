import Image from "next/image";
import Link from "next/link";
import {
  ArrowLeft,
  CalendarDays,
  HeartHandshake,
  MapPin,
  Sparkles,
} from "lucide-react";

export type CareerEventDetailData = {
  slug: string;
  title: string;
  date: string;
  image: string;
  location: string;
  badge: string;
  summary: string;
  body: string[];
};

export const careerEventDetails: CareerEventDetailData[] = [
  {
    slug: "healthy-week-2025",
    title: "Healthy Week 2025 at Update Diagnostic Center",
    date: "14 July 2025",
    image: "/blogs/blog-1.jpg",
    location: "Update Diagnostic Center",
    badge: "Event 01",
    summary:
      "A team-focused health awareness activity designed to celebrate wellness, preventive care, and staff participation.",
    body: [
      "Healthy Week 2025 brought employees, service teams, and healthcare professionals together around a shared message of preventive care and workplace wellness.",
      "The program highlighted practical health awareness, patient communication, and team culture. This page is fully separate so you can edit event text, images, and layout from one file.",
      "You can customize this detail page later by editing src/components/career/CareerEventDetail.tsx.",
    ],
  },
  {
    slug: "campus-activation-afmc",
    title: "Campus Activation in Armed Forces Medical College (AFMC)",
    date: "14 July 2025",
    image: "/news/news-2.jpg",
    location: "Armed Forces Medical College",
    badge: "Event 02",
    summary:
      "A campus engagement program connecting healthcare education, awareness, and Update Diagnostic Center's service mission.",
    body: [
      "The AFMC campus activation focused on outreach, professional connection, and awareness around diagnostic services and healthcare career development.",
      "Team members participated in meaningful discussions and engagement activities that strengthened the relationship between education and healthcare service.",
      "You can replace this copy with the final event story, gallery details, or organizer notes whenever needed.",
    ],
  },
  {
    slug: "campus-activation-north-south-university",
    title: "Campus Activation in North South University",
    date: "01 March 2025",
    image: "/doctor-articles/doctor-2.jpg",
    location: "North South University",
    badge: "Event 03",
    summary:
      "A university engagement event focused on awareness, team representation, and community connection.",
    body: [
      "The North South University activation created a space for community engagement and awareness through direct interaction with students and visitors.",
      "The event reflected Update Diagnostic Center's commitment to communication, education, and stronger public health awareness.",
      "Edit this file to add the complete event story, photos, quotes, or final campaign details.",
    ],
  },
];

type CareerEventDetailProps = {
  event: CareerEventDetailData;
};

export default function CareerEventDetail({ event }: CareerEventDetailProps) {
  return (
    <main className="relative overflow-hidden bg-[#f7fbff] px-4 py-12 text-[#062d62] sm:px-6 lg:px-8">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl">
        <Link
          href="/career"
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#dbeafe] bg-white/85 px-4 py-2 text-sm font-black text-[#062d62] shadow-sm transition hover:border-[#43c7f4] hover:text-[#0b77a5]"
        >
          <ArrowLeft size={17} />
          Back to Career
        </Link>

        <article className="overflow-hidden rounded-[30px] border border-white/80 bg-white/85 shadow-[0_24px_70px_rgba(6,45,98,0.12)] backdrop-blur-xl">
          <div className="relative h-[320px] bg-slate-100 sm:h-[430px]">
            <Image
              src={event.image}
              alt={event.title}
              fill
              sizes="100vw"
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#062d62]/85 via-[#062d62]/30 to-transparent" />

            <div className="absolute bottom-6 left-5 right-5 text-white sm:bottom-8 sm:left-8 sm:right-8">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/15 px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-cyan-100 backdrop-blur-md">
                <Sparkles size={15} />
                {event.badge}
              </div>

              <h1 className="max-w-4xl text-3xl font-black leading-tight sm:text-5xl">
                {event.title}
              </h1>
            </div>
          </div>

          <div className="grid gap-8 p-5 sm:p-8 lg:grid-cols-[1fr_320px] lg:p-10">
            <div>
              <p className="text-lg font-bold leading-8 text-[#4d6380]">
                {event.summary}
              </p>

              <div className="mt-8 space-y-5">
                {event.body.map((paragraph) => (
                  <p
                    key={paragraph}
                    className="text-base font-semibold leading-8 text-[#4d6380]"
                  >
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>

            <aside className="h-fit rounded-[28px] border border-[#dbeafe] bg-[#f8fbff] p-5">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[#062d62] text-white">
                <HeartHandshake size={22} />
              </div>

              <h2 className="mt-5 text-xl font-black text-[#062d62]">
                Event Details
              </h2>

              <div className="mt-5 space-y-3 text-sm font-bold text-[#4d6380]">
                <p className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 ring-1 ring-[#062d62]/8">
                  <CalendarDays size={17} className="text-[#8a6bb8]" />
                  {event.date}
                </p>
                <p className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 ring-1 ring-[#062d62]/8">
                  <MapPin size={17} className="text-[#43c7f4]" />
                  {event.location}
                </p>
              </div>
            </aside>
          </div>
        </article>
      </div>
    </main>
  );
}
