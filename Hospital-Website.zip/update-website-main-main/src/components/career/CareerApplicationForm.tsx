"use client";

import Link from "next/link";
import {
  ArrowLeft,
  BriefcaseBusiness,
  FileUp,
  Mail,
  MapPin,
  Phone,
  Send,
  UserRound,
} from "lucide-react";
import { type ChangeEvent, type FormEvent, useState } from "react";
import { addCareerApplication, fileToDataUrl } from "@/lib/careerCms";

type CareerApplicationFormProps = {
  position?: string;
};

const fieldClass =
  "w-full rounded-2xl border border-[#dbeafe] bg-white px-4 py-3 text-sm font-semibold text-[#062d62] outline-none transition focus:border-[#43c7f4] focus:ring-4 focus:ring-[#43c7f4]/15";

const labelClass = "mb-2 block text-sm font-black text-[#062d62]";

function clean(value: FormDataEntryValue | null) {
  return String(value || "").trim();
}

export default function CareerApplicationForm({
  position = "",
}: CareerApplicationFormProps) {
  const [resumeFileName, setResumeFileName] = useState("");
  const [resumeDataUrl, setResumeDataUrl] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  async function handleResume(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];

    const isAllowedExtension = /\.(pdf|doc|docx)$/i.test(file.name);

    if (!allowedTypes.includes(file.type) && !isAllowedExtension) {
      setErrorMessage("Only PDF, DOC, or DOCX resume files are allowed.");
      event.target.value = "";
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      setErrorMessage("Resume file must be smaller than 3MB.");
      event.target.value = "";
      return;
    }

    setErrorMessage("");
    setResumeFileName(file.name);
    setResumeDataUrl(await fileToDataUrl(file));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (isSubmitting) return;

    const form = event.currentTarget;
    const formData = new FormData(form);

    const fullName = clean(formData.get("fullName"));
    const phone = clean(formData.get("phone"));
    const email = clean(formData.get("email"));
    const jobTitle = clean(formData.get("position"));
    const location = clean(formData.get("location"));
    const education = clean(formData.get("education"));
    const experience = clean(formData.get("experience"));
    const expectedSalary = clean(formData.get("expectedSalary"));
    const coverNote = clean(formData.get("message"));

    if (!fullName || !phone) {
      setErrorMessage("Name and phone number required.");
      return;
    }

    setSubmitted(false);
    setErrorMessage("");
    setIsSubmitting(true);

    const finalMessage =
      coverNote ||
      `Career application submitted for ${jobTitle || "General Resume"}.`;

    try {
      const response = await fetch("/api/form-submissions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          formType: "CAREER",
          name: fullName,
          phone,
          email,
          subject: jobTitle
            ? `Career Application - ${jobTitle}`
            : "Career Application - General Resume",
          message: finalMessage,
          payload: {
            applyType: jobTitle ? "job" : "general",
            jobTitle: jobTitle || "",
            department: jobTitle || "General Resume",
            address: location,
            education,
            experience,
            expectedSalary,
            coverNote,
            resumeFileName,
            resumeDataUrl,
            source: "career-apply-page",
            submittedAt: new Date().toISOString(),
          },
        }),
      });

      const result = (await response.json().catch(() => null)) as {
        message?: string;
        submission?: { id?: string };
      } | null;

      if (!response.ok) {
        throw new Error(result?.message || "Application submission failed.");
      }

      addCareerApplication({
        applyType: jobTitle ? "job" : "general",
        jobTitle: jobTitle || undefined,
        department: jobTitle || "General Resume",
        fullName,
        phone,
        email,
        address: location,
        education,
        experience,
        expectedSalary,
        coverNote,
        resumeFileName,
        resumeDataUrl,
      });

      setSubmitted(true);
      form.reset();
      setResumeFileName("");
      setResumeDataUrl("");
    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Application submission failed. Please try again.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="relative overflow-hidden bg-[#f7fbff] px-4 py-12 text-[#062d62] sm:px-6 lg:px-8">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />
        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl">
        <Link
          href="/career"
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#dbeafe] bg-white/85 px-4 py-2 text-sm font-black text-[#062d62] shadow-sm transition hover:border-[#43c7f4] hover:text-[#0b77a5]"
        >
          <ArrowLeft size={17} />
          Back to Career
        </Link>

        <section className="overflow-hidden rounded-[30px] border border-white/80 bg-white/85 shadow-[0_24px_70px_rgba(6,45,98,0.12)] backdrop-blur-xl">
          <div className="bg-[#062d62] px-5 py-8 text-white sm:px-8 lg:px-10">
            <div className="inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-100">
              <BriefcaseBusiness size={16} />
              Job Application
            </div>

            <h1 className="mt-5 text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
              Apply for a Position
            </h1>

            <p className="mt-4 max-w-2xl text-sm font-semibold leading-7 text-blue-50/90 sm:text-base">
              Fill out the form below. Your application will be saved in the admin
              panel and SMS workflow will be logged automatically.
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            className="grid gap-6 p-5 sm:p-8 lg:grid-cols-[1fr_0.75fr] lg:p-10"
          >
            <div className="grid gap-5">
              {submitted ? (
                <div className="rounded-[24px] border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm font-black text-emerald-700">
                  Application submitted successfully. Admin panel-e submission
                  save hoye geche.
                </div>
              ) : null}

              {errorMessage ? (
                <div className="rounded-[24px] border border-red-200 bg-red-50 px-5 py-4 text-sm font-black text-red-700">
                  {errorMessage}
                </div>
              ) : null}

              <div>
                <label className={labelClass} htmlFor="position">
                  Applying Position
                </label>
                <div className="relative">
                  <BriefcaseBusiness
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#8a6bb8]"
                    size={18}
                  />
                  <input
                    id="position"
                    name="position"
                    defaultValue={position}
                    placeholder="Select or type position"
                    className={`${fieldClass} pl-11`}
                  />
                </div>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label className={labelClass} htmlFor="fullName">
                    Full Name
                  </label>
                  <div className="relative">
                    <UserRound
                      className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#43c7f4]"
                      size={18}
                    />
                    <input
                      id="fullName"
                      name="fullName"
                      placeholder="Your full name"
                      className={`${fieldClass} pl-11`}
                    />
                  </div>
                </div>

                <div>
                  <label className={labelClass} htmlFor="phone">
                    Phone Number
                  </label>
                  <div className="relative">
                    <Phone
                      className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#43c7f4]"
                      size={18}
                    />
                    <input
                      id="phone"
                      name="phone"
                      placeholder="+880"
                      className={`${fieldClass} pl-11`}
                    />
                  </div>
                </div>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label className={labelClass} htmlFor="email">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail
                      className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#8a6bb8]"
                      size={18}
                    />
                    <input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="name@example.com"
                      className={`${fieldClass} pl-11`}
                    />
                  </div>
                </div>

                <div>
                  <label className={labelClass} htmlFor="location">
                    Current Location
                  </label>
                  <div className="relative">
                    <MapPin
                      className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#8a6bb8]"
                      size={18}
                    />
                    <input
                      id="location"
                      name="location"
                      placeholder="City"
                      className={`${fieldClass} pl-11`}
                    />
                  </div>
                </div>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label className={labelClass} htmlFor="education">
                    Education
                  </label>
                  <input
                    id="education"
                    name="education"
                    placeholder="Latest education"
                    className={fieldClass}
                  />
                </div>

                <div>
                  <label className={labelClass} htmlFor="experience">
                    Experience
                  </label>
                  <input
                    id="experience"
                    name="experience"
                    placeholder="Years / current role"
                    className={fieldClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass} htmlFor="expectedSalary">
                  Expected Salary
                </label>
                <input
                  id="expectedSalary"
                  name="expectedSalary"
                  placeholder="Negotiable"
                  className={fieldClass}
                />
              </div>

              <div>
                <label className={labelClass} htmlFor="resume">
                  Upload CV / Resume
                </label>
                <label className="flex min-h-32 cursor-pointer flex-col items-center justify-center rounded-[24px] border border-dashed border-[#43c7f4]/70 bg-[#f3fbff] px-5 py-7 text-center transition hover:bg-white">
                  <FileUp size={28} className="text-[#43c7f4]" />
                  <span className="mt-3 text-sm font-black text-[#062d62]">
                    Choose resume file
                  </span>
                  <span className="mt-1 text-xs font-semibold text-[#4d6380]">
                    PDF, DOC, or DOCX. Max 3MB.
                  </span>
                  <input
                    id="resume"
                    name="resume"
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={handleResume}
                    className="hidden"
                  />
                </label>
                {resumeFileName ? (
                  <p className="mt-2 text-xs font-black text-[#0b77a5]">
                    Selected: {resumeFileName}
                  </p>
                ) : null}
              </div>

              <div>
                <label className={labelClass} htmlFor="message">
                  Short Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={6}
                  placeholder="Write your experience, availability, or note."
                  className={`${fieldClass} resize-y leading-7`}
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex min-h-12 items-center justify-center gap-3 rounded-full bg-[#062d62] px-7 py-3 text-sm font-black uppercase tracking-[0.07em] text-white shadow-[0_18px_45px_rgba(6,45,98,0.22)] transition hover:-translate-y-0.5 hover:bg-[#43c7f4] disabled:cursor-not-allowed disabled:opacity-60 sm:min-h-14"
              >
                {isSubmitting ? "Submitting..." : "Submit Application"}
                <Send size={18} />
              </button>
            </div>

            <aside className="h-fit rounded-[28px] border border-[#dbeafe] bg-[#f8fbff] p-5 sm:p-6">
              <h2 className="text-xl font-black text-[#062d62]">
                Application Note
              </h2>
              <p className="mt-3 text-sm font-semibold leading-7 text-[#4d6380]">
                Your application will be stored securely in the admin database.
                SMS workflow is already connected and will become active when
                the client SMS API is enabled.
              </p>
              <div className="mt-5 rounded-2xl bg-white p-4 text-sm font-bold leading-7 text-[#4d6380] ring-1 ring-[#062d62]/8">
                Current selected position:
                <br />
                <span className="text-[#062d62]">
                  {position || "Not selected"}
                </span>
              </div>
            </aside>
          </form>
        </section>
      </div>
    </main>
  );
}


