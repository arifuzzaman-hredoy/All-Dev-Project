/* eslint-disable @next/next/no-img-element */
"use client";

import {
  Award,
  BriefcaseBusiness,
  Download,
  FileDown,
  GraduationCap,
  HeartHandshake,
  ImageIcon,
  Plus,
  Printer,
  RefreshCcw,
  Save,
  Sparkles,
  Stethoscope,
  Trash2,
  UsersRound,
} from "lucide-react";
import {
  type ChangeEvent,
  type ReactNode,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  arrayToLines,
  type CareerApplication,
  type CareerCmsData,
  type CareerDepartment,
  type CareerEventItem,
  type CareerFeatureCard,
  type CareerIconKey,
  type CareerJob,
  type CareerValueCard,
  defaultCareerCmsData,
  deleteCareerApplication,
  fileToDataUrl,
  getCareerApplications,
  getCareerCmsData,
  linesToArray,
  resetCareerCmsData,
  saveCareerCmsData,
  slugify,
  subscribeCareerApplications,
  uid,
  updateCareerApplicationStatus,
} from "@/lib/careerCms";

type TabKey =
  | "hero"
  | "intro"
  | "hr"
  | "jobs"
  | "applications"
  | "events"
  | "feature";

const iconOptions: CareerIconKey[] = [
  "users",
  "heart",
  "growth",
  "briefcase",
  "award",
  "stethoscope",
  "graduation",
];

function IconPreview({ icon }: { icon: CareerIconKey }) {
  const icons: Record<CareerIconKey, ReactNode> = {
    users: <UsersRound size={20} />,
    heart: <HeartHandshake size={20} />,
    growth: <Sparkles size={20} />,
    briefcase: <BriefcaseBusiness size={20} />,
    award: <Award size={20} />,
    stethoscope: <Stethoscope size={20} />,
    graduation: <GraduationCap size={20} />,
  };

  return (
    <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-cyan-50 text-cyan-500">
      {icons[icon]}
    </span>
  );
}

function Card({
  title,
  children,
  action,
}: {
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <section className="rounded-[30px] border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-black text-[#07346f]">{title}</h2>
        {action}
      </div>
      {children}
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-black text-[#07346f]">{label}</span>
      <input
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold outline-none focus:border-cyan-400"
      />
    </label>
  );
}

function Textarea({
  label,
  value,
  onChange,
  rows = 4,
  hint,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  rows?: number;
  hint?: string;
}) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-black text-[#07346f]">{label}</span>
      <textarea
        rows={rows}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="resize-y rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold leading-7 outline-none focus:border-cyan-400"
      />
      {hint ? (
        <span className="text-xs font-bold text-slate-400">{hint}</span>
      ) : null}
    </label>
  );
}

function SelectField({
  label,
  value,
  onChange,
  children,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: ReactNode;
}) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-black text-[#07346f]">{label}</span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold outline-none focus:border-cyan-400"
      >
        {children}
      </select>
    </label>
  );
}

function ImageUpload({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  async function handleFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    const dataUrl = await fileToDataUrl(file);
    onChange(dataUrl);
  }

  return (
    <div className="grid gap-3">
      <span className="text-sm font-black text-[#07346f]">{label}</span>
      <div className="relative min-h-[180px] overflow-hidden rounded-[26px] border border-dashed border-cyan-300 bg-slate-50">
        {value ? (
          <img
            src={value}
            alt={label}
            className="h-full min-h-[180px] w-full object-cover"
          />
        ) : (
          <div className="flex min-h-[180px] flex-col items-center justify-center gap-3 p-5 text-center text-slate-400">
            <ImageIcon size={34} />
            <p className="font-black">Upload image</p>
          </div>
        )}
      </div>
      <input
        type="file"
        accept="image/*"
        onChange={handleFile}
        className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold"
      />
      {value ? (
        <button
          type="button"
          onClick={() => onChange("")}
          className="rounded-2xl border border-red-200 px-4 py-3 text-sm font-black text-red-500"
        >
          Remove Image
        </button>
      ) : null}
    </div>
  );
}

function exportCsv(applications: CareerApplication[]) {
  const headers = [
    "Submitted At",
    "Type",
    "Job Title",
    "Department",
    "Full Name",
    "Phone",
    "Email",
    "Address",
    "Education",
    "Experience",
    "Expected Salary",
    "Status",
    "Cover Note",
  ];

  const rows = applications.map((item) => [
    item.submittedAt,
    item.applyType,
    item.jobTitle || "",
    item.department || "",
    item.fullName,
    item.phone,
    item.email,
    item.address,
    item.education,
    item.experience,
    item.expectedSalary,
    item.status,
    item.coverNote,
  ]);

  const csv = [headers, ...rows]
    .map((row) =>
      row
        .map((cell) => `"${String(cell || "").replace(/"/g, '""')}"`)
        .join(","),
    )
    .join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = "career-applications.csv";
  link.click();
  URL.revokeObjectURL(url);
}

export default function CareerAdminPanel() {
  const initialData = getCareerCmsData();
  const [activeTab, setActiveTab] = useState<TabKey>("hero");
  const [data, setData] = useState<CareerCmsData>(initialData);
  const [applications, setApplications] = useState<CareerApplication[]>(() =>
    getCareerApplications(),
  );
  const [selectedJobId, setSelectedJobId] = useState(
    initialData.jobs[0]?.id || "",
  );
  const [selectedEventId, setSelectedEventId] = useState(
    initialData.events[0]?.id || "",
  );

  useEffect(
    () =>
      subscribeCareerApplications(() => {
        setApplications(getCareerApplications());
      }),
    [],
  );

  const selectedJob = useMemo(
    () => data.jobs.find((job) => job.id === selectedJobId),
    [data.jobs, selectedJobId],
  );

  const selectedEvent = useMemo(
    () => data.events.find((event) => event.id === selectedEventId),
    [data.events, selectedEventId],
  );

  function save() {
    saveCareerCmsData(data);
    alert("Career page saved successfully.");
  }

  function reset() {
    const yes = confirm("Reset Career CMS demo data?");
    if (!yes) return;

    resetCareerCmsData();
    setData(defaultCareerCmsData);
    setSelectedJobId(defaultCareerCmsData.jobs[0]?.id || "");
    setSelectedEventId(defaultCareerCmsData.events[0]?.id || "");
    alert("Career CMS reset complete.");
  }

  const patchJob = (id: string, patch: Partial<CareerJob>) => {
    setData((current) => ({
      ...current,
      jobs: current.jobs.map((job) =>
        job.id === id ? { ...job, ...patch } : job,
      ),
    }));
  };

  function addJob() {
    const department = data.departments[0];
    const nextJob: CareerJob = {
      id: uid("job"),
      slug: "new-job",
      title: "New Job Vacancy",
      departmentId: department?.id || "",
      categoryLabel: department?.name || "General",
      imageUrl: "",
      location: "Dhaka",
      type: "Full Time",
      vacancy: "1",
      deadline: "N/A",
      salary: "Negotiable",
      summary: "Write short job summary here.",
      details: "Write full job description here.",
      responsibilities: ["Responsibility one"],
      requirements: ["Requirement one"],
      status: "open",
    };

    setData((current) => ({ ...current, jobs: [nextJob, ...current.jobs] }));
    setSelectedJobId(nextJob.id);
    setActiveTab("jobs");
  }

  function removeJob(id: string) {
    const yes = confirm("Delete this job?");
    if (!yes) return;

    setData((current) => ({
      ...current,
      jobs: current.jobs.filter((job) => job.id !== id),
    }));
    setSelectedJobId("");
  }

  function addDepartment() {
    const nextDepartment: CareerDepartment = {
      id: uid("dept"),
      name: "New Department",
    };

    setData((current) => ({
      ...current,
      departments: [...current.departments, nextDepartment],
    }));
  }

  function patchDepartment(id: string, name: string) {
    setData((current) => ({
      ...current,
      departments: current.departments.map((department) =>
        department.id === id ? { ...department, name } : department,
      ),
      jobs: current.jobs.map((job) =>
        job.departmentId === id ? { ...job, categoryLabel: name } : job,
      ),
    }));
  }

  function removeDepartment(id: string) {
    const yes = confirm("Delete this department?");
    if (!yes) return;

    setData((current) => ({
      ...current,
      departments: current.departments.filter((item) => item.id !== id),
    }));
  }

  const patchEvent = (id: string, patch: Partial<CareerEventItem>) => {
    setData((current) => ({
      ...current,
      events: current.events.map((event) =>
        event.id === id ? { ...event, ...patch } : event,
      ),
    }));
  };

  function addEvent() {
    const nextEvent: CareerEventItem = {
      id: uid("event"),
      slug: "new-event",
      label: "Event",
      title: "New Employee Event",
      date: "N/A",
      location: "Update Diagnostic Center",
      imageUrl: "",
      excerpt: "Write event short description here.",
      contentParagraphs: ["Write event detail paragraph here."],
    };

    setData((current) => ({
      ...current,
      events: [nextEvent, ...current.events],
    }));
    setSelectedEventId(nextEvent.id);
    setActiveTab("events");
  }

  function removeEvent(id: string) {
    const yes = confirm("Delete this event?");
    if (!yes) return;

    setData((current) => ({
      ...current,
      events: current.events.filter((event) => event.id !== id),
    }));
    setSelectedEventId("");
  }

  const patchValueCard = (id: string, patch: Partial<CareerValueCard>) => {
    setData((current) => ({
      ...current,
      intro: {
        ...current.intro,
        values: current.intro.values.map((card) =>
          card.id === id ? { ...card, ...patch } : card,
        ),
      },
    }));
  };

  const patchFeatureCard = (id: string, patch: Partial<CareerFeatureCard>) => {
    setData((current) => ({
      ...current,
      feature: {
        ...current.feature,
        cards: current.feature.cards.map((card) =>
          card.id === id ? { ...card, ...patch } : card,
        ),
      },
    }));
  };

  const tabs: { key: TabKey; label: string }[] = [
    { key: "hero", label: "Slider" },
    { key: "intro", label: "Intro" },
    { key: "hr", label: "HR Message" },
    { key: "jobs", label: "Jobs" },
    { key: "applications", label: "Applications" },
    { key: "events", label: "Events" },
    { key: "feature", label: "Career Feature" },
  ];

  return (
    <main className="min-h-screen bg-[#f6fbff] p-4 text-slate-900 md:p-8">
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #career-print-area, #career-print-area * { visibility: visible !important; }
          #career-print-area {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            overflow: visible !important;
            background: white !important;
            border: 0 !important;
            border-radius: 0 !important;
            box-shadow: none !important;
          }
          #career-print-area table {
            width: 100% !important;
            min-width: 0 !important;
            table-layout: fixed !important;
            border-collapse: collapse !important;
            font-size: 9px !important;
            color: #111827 !important;
          }
          #career-print-area th,
          #career-print-area td {
            border: 1px solid #cbd5e1 !important;
            padding: 4px !important;
            color: #111827 !important;
            vertical-align: top !important;
            word-break: break-word !important;
          }
          #career-print-area thead tr {
            background: #e2e8f0 !important;
            color: #111827 !important;
          }
          #career-print-area tbody tr {
            background: white !important;
          }
          .career-print-title {
            display: block !important;
            margin-bottom: 8px !important;
            color: #111827 !important;
          }
          .career-print-title h1 {
            margin: 0 !important;
            font-size: 18px !important;
            font-weight: 800 !important;
          }
          .career-print-title p {
            margin: 2px 0 0 !important;
            font-size: 10px !important;
            font-weight: 700 !important;
          }
          @page { size: A4 landscape; margin: 10mm; }
        }
      `}</style>

      <div className="mx-auto max-w-7xl">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-[30px] bg-[#07346f] p-5 text-white shadow-sm">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.25em] text-cyan-300">
              Admin CMS
            </p>
            <h1 className="mt-2 text-3xl font-black">
              Career Page Control
            </h1>
            <p className="mt-1 font-semibold text-white/70">
              Slider, HR message, jobs, applications, events and feature section.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={reset}
              className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-5 py-3 font-black text-white"
            >
              <RefreshCcw size={18} /> Reset
            </button>
            <button
              type="button"
              onClick={save}
              className="inline-flex items-center gap-2 rounded-2xl bg-cyan-400 px-5 py-3 font-black text-[#07346f]"
            >
              <Save size={18} /> Save Changes
            </button>
          </div>
        </div>

        <div className="mb-6 flex gap-3 overflow-x-auto rounded-[24px] bg-white p-3 shadow-sm">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setActiveTab(tab.key)}
              className={`whitespace-nowrap rounded-2xl px-5 py-3 text-sm font-black ${
                activeTab === tab.key
                  ? "bg-[#07346f] text-white"
                  : "bg-slate-50 text-slate-500"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === "hero" ? (
          <Card title="Top Career Slider">
            <div className="grid gap-6 md:grid-cols-3">
              {data.heroSlides.map((slide, index) => (
                <div key={slide.id} className="grid gap-4 rounded-[26px] bg-slate-50 p-4">
                  <h3 className="font-black text-[#07346f]">Slide {index + 1}</h3>
                  <ImageUpload
                    label="Slider Image"
                    value={slide.imageUrl}
                    onChange={(imageUrl) =>
                      setData((current) => ({
                        ...current,
                        heroSlides: current.heroSlides.map((item) =>
                          item.id === slide.id ? { ...item, imageUrl } : item,
                        ),
                      }))
                    }
                  />
                  <Field
                    label="Slide Title"
                    value={slide.title}
                    onChange={(title) =>
                      setData((current) => ({
                        ...current,
                        heroSlides: current.heroSlides.map((item) =>
                          item.id === slide.id ? { ...item, title } : item,
                        ),
                      }))
                    }
                  />
                </div>
              ))}
            </div>
          </Card>
        ) : null}

        {activeTab === "intro" ? (
          <div className="grid gap-6">
            <Card title="Career Intro Text">
              <div className="grid gap-4 md:grid-cols-2">
                <Field
                  label="Badge"
                  value={data.intro.badge}
                  onChange={(badge) =>
                    setData((current) => ({
                      ...current,
                      intro: { ...current.intro, badge },
                    }))
                  }
                />
                <Field
                  label="Subtitle"
                  value={data.intro.subtitle}
                  onChange={(subtitle) =>
                    setData((current) => ({
                      ...current,
                      intro: { ...current.intro, subtitle },
                    }))
                  }
                />
                <Field
                  label="Title Before"
                  value={data.intro.titleBefore}
                  onChange={(titleBefore) =>
                    setData((current) => ({
                      ...current,
                      intro: { ...current.intro, titleBefore },
                    }))
                  }
                />
                <Field
                  label="Highlight"
                  value={data.intro.highlight}
                  onChange={(highlight) =>
                    setData((current) => ({
                      ...current,
                      intro: { ...current.intro, highlight },
                    }))
                  }
                />
                <Field
                  label="Title After"
                  value={data.intro.titleAfter}
                  onChange={(titleAfter) =>
                    setData((current) => ({
                      ...current,
                      intro: { ...current.intro, titleAfter },
                    }))
                  }
                />
                <div className="md:col-span-2">
                  <Textarea
                    label="Description"
                    rows={5}
                    value={data.intro.description}
                    onChange={(description) =>
                      setData((current) => ({
                        ...current,
                        intro: { ...current.intro, description },
                      }))
                    }
                  />
                </div>
              </div>
            </Card>

            <Card
              title="Intro Small Cards"
              action={
                <button
                  type="button"
                  onClick={() =>
                    setData((current) => ({
                      ...current,
                      intro: {
                        ...current.intro,
                        values: [
                          ...current.intro.values,
                          { id: uid("value"), title: "New Value", icon: "heart" },
                        ],
                      },
                    }))
                  }
                  className="inline-flex items-center gap-2 rounded-2xl bg-cyan-500 px-4 py-2 text-sm font-black text-white"
                >
                  <Plus size={18} /> Add Card
                </button>
              }
            >
              <div className="grid gap-4 md:grid-cols-3">
                {data.intro.values.map((card) => (
                  <div key={card.id} className="grid gap-4 rounded-[26px] bg-slate-50 p-4">
                    <div className="flex items-center gap-3">
                      <IconPreview icon={card.icon} />
                      <Field
                        label="Title"
                        value={card.title}
                        onChange={(title) => patchValueCard(card.id, { title })}
                      />
                    </div>
                    <SelectField
                      label="Icon"
                      value={card.icon}
                      onChange={(icon) =>
                        patchValueCard(card.id, { icon: icon as CareerIconKey })
                      }
                    >
                      {iconOptions.map((icon) => (
                        <option key={icon} value={icon}>
                          {icon}
                        </option>
                      ))}
                    </SelectField>
                    <button
                      type="button"
                      onClick={() =>
                        setData((current) => ({
                          ...current,
                          intro: {
                            ...current.intro,
                            values: current.intro.values.filter(
                              (item) => item.id !== card.id,
                            ),
                          },
                        }))
                      }
                      className="rounded-2xl border border-red-200 px-4 py-3 text-sm font-black text-red-500"
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        ) : null}

        {activeTab === "hr" ? (
          <Card title="HR Message Section">
            <div className="grid gap-6 md:grid-cols-[320px_1fr]">
              <ImageUpload
                label="HR Photo"
                value={data.hrMessage.photoUrl}
                onChange={(photoUrl) =>
                  setData((current) => ({
                    ...current,
                    hrMessage: { ...current.hrMessage, photoUrl },
                  }))
                }
              />
              <div className="grid gap-4 md:grid-cols-2">
                <Field
                  label="Name"
                  value={data.hrMessage.name}
                  onChange={(name) =>
                    setData((current) => ({
                      ...current,
                      hrMessage: { ...current.hrMessage, name },
                    }))
                  }
                />
                <Field
                  label="Designation"
                  value={data.hrMessage.designation}
                  onChange={(designation) =>
                    setData((current) => ({
                      ...current,
                      hrMessage: { ...current.hrMessage, designation },
                    }))
                  }
                />
                <div className="md:col-span-2">
                  <Field
                    label="Message Title"
                    value={data.hrMessage.title}
                    onChange={(title) =>
                      setData((current) => ({
                        ...current,
                        hrMessage: { ...current.hrMessage, title },
                      }))
                    }
                  />
                </div>
                <div className="md:col-span-2">
                  <Textarea
                    label="Message Paragraphs"
                    rows={10}
                    value={arrayToLines(data.hrMessage.paragraphs)}
                    onChange={(value) =>
                      setData((current) => ({
                        ...current,
                        hrMessage: {
                          ...current.hrMessage,
                          paragraphs: linesToArray(value),
                        },
                      }))
                    }
                    hint="One paragraph per line."
                  />
                </div>
              </div>
            </div>
          </Card>
        ) : null}

        {activeTab === "jobs" ? (
          <div className="grid gap-6">
            <Card
              title="Departments"
              action={
                <button
                  type="button"
                  onClick={addDepartment}
                  className="inline-flex items-center gap-2 rounded-2xl bg-cyan-500 px-4 py-2 text-sm font-black text-white"
                >
                  <Plus size={18} /> Add Department
                </button>
              }
            >
              <div className="grid gap-4 md:grid-cols-3">
                {data.departments.map((department) => (
                  <div
                    key={department.id}
                    className="flex items-end gap-3 rounded-[26px] bg-slate-50 p-4"
                  >
                    <div className="flex-1">
                      <Field
                        label="Department Name"
                        value={department.name}
                        onChange={(name) => patchDepartment(department.id, name)}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeDepartment(department.id)}
                      className="rounded-2xl border border-red-200 p-3 text-red-500"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                ))}
              </div>
            </Card>

            <Card
              title="Job Vacancy"
              action={
                <button
                  type="button"
                  onClick={addJob}
                  className="inline-flex items-center gap-2 rounded-2xl bg-cyan-500 px-4 py-2 text-sm font-black text-white"
                >
                  <Plus size={18} /> Add New Job Vacancy
                </button>
              }
            >
              <div className="grid gap-6 md:grid-cols-[320px_1fr]">
                <div className="grid h-fit gap-3 rounded-[26px] bg-slate-50 p-3">
                  {data.jobs.map((job) => (
                    <button
                      key={job.id}
                      type="button"
                      onClick={() => setSelectedJobId(job.id)}
                      className={`rounded-2xl p-4 text-left ${
                        selectedJobId === job.id
                          ? "bg-[#07346f] text-white"
                          : "bg-white text-slate-600"
                      }`}
                    >
                      <p className="font-black">{job.title}</p>
                      <p className="mt-1 text-xs font-bold opacity-70">
                        {job.categoryLabel} - {job.status}
                      </p>
                    </button>
                  ))}
                </div>

                {selectedJob ? (
                  <div className="grid gap-5 rounded-[26px] bg-slate-50 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <h3 className="text-xl font-black text-[#07346f]">
                        Edit Job
                      </h3>
                      <button
                        type="button"
                        onClick={() => removeJob(selectedJob.id)}
                        className="inline-flex items-center gap-2 rounded-2xl border border-red-200 bg-white px-4 py-2 text-sm font-black text-red-500"
                      >
                        <Trash2 size={18} /> Delete Job
                      </button>
                    </div>
                    <div className="grid gap-5 md:grid-cols-[280px_1fr]">
                      <ImageUpload
                        label="Job Card Image"
                        value={selectedJob.imageUrl}
                        onChange={(imageUrl) =>
                          patchJob(selectedJob.id, { imageUrl })
                        }
                      />
                      <div className="grid gap-4 md:grid-cols-2">
                        <Field
                          label="Job Title"
                          value={selectedJob.title}
                          onChange={(title) =>
                            patchJob(selectedJob.id, {
                              title,
                              slug: slugify(title) || selectedJob.slug,
                            })
                          }
                        />
                        <Field
                          label="Slug"
                          value={selectedJob.slug}
                          onChange={(slug) =>
                            patchJob(selectedJob.id, { slug: slugify(slug) })
                          }
                        />
                        <SelectField
                          label="Department"
                          value={selectedJob.departmentId}
                          onChange={(departmentId) => {
                            const department = data.departments.find(
                              (item) => item.id === departmentId,
                            );
                            patchJob(selectedJob.id, {
                              departmentId,
                              categoryLabel:
                                department?.name || selectedJob.categoryLabel,
                            });
                          }}
                        >
                          {data.departments.map((department) => (
                            <option key={department.id} value={department.id}>
                              {department.name}
                            </option>
                          ))}
                        </SelectField>
                        <Field
                          label="Category Label"
                          value={selectedJob.categoryLabel}
                          onChange={(categoryLabel) =>
                            patchJob(selectedJob.id, { categoryLabel })
                          }
                        />
                        <Field
                          label="Location"
                          value={selectedJob.location}
                          onChange={(location) =>
                            patchJob(selectedJob.id, { location })
                          }
                        />
                        <Field
                          label="Job Type"
                          value={selectedJob.type}
                          onChange={(type) => patchJob(selectedJob.id, { type })}
                        />
                        <Field
                          label="Vacancy"
                          value={selectedJob.vacancy}
                          onChange={(vacancy) =>
                            patchJob(selectedJob.id, { vacancy })
                          }
                        />
                        <Field
                          label="Deadline"
                          value={selectedJob.deadline}
                          onChange={(deadline) =>
                            patchJob(selectedJob.id, { deadline })
                          }
                        />
                        <Field
                          label="Salary"
                          value={selectedJob.salary}
                          onChange={(salary) =>
                            patchJob(selectedJob.id, { salary })
                          }
                        />
                        <SelectField
                          label="Status"
                          value={selectedJob.status}
                          onChange={(status) =>
                            patchJob(selectedJob.id, {
                              status: status as CareerJob["status"],
                            })
                          }
                        >
                          <option value="open">Open</option>
                          <option value="closed">Closed</option>
                        </SelectField>
                      </div>
                    </div>
                    <Textarea
                      label="Summary"
                      rows={3}
                      value={selectedJob.summary}
                      onChange={(summary) => patchJob(selectedJob.id, { summary })}
                    />
                    <Textarea
                      label="Full Details"
                      rows={5}
                      value={selectedJob.details}
                      onChange={(details) => patchJob(selectedJob.id, { details })}
                    />
                    <Textarea
                      label="Responsibilities"
                      rows={6}
                      value={arrayToLines(selectedJob.responsibilities)}
                      onChange={(value) =>
                        patchJob(selectedJob.id, {
                          responsibilities: linesToArray(value),
                        })
                      }
                      hint="One responsibility per line."
                    />
                    <Textarea
                      label="Requirements"
                      rows={6}
                      value={arrayToLines(selectedJob.requirements)}
                      onChange={(value) =>
                        patchJob(selectedJob.id, {
                          requirements: linesToArray(value),
                        })
                      }
                      hint="One requirement per line."
                    />
                  </div>
                ) : (
                  <div className="rounded-[26px] bg-slate-50 p-8 text-center font-black text-slate-400">
                    No job selected
                  </div>
                )}
              </div>
            </Card>
          </div>
        ) : null}

        {activeTab === "applications" ? (
          <Card
            title="Submitted Applications"
            action={
              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => exportCsv(applications)}
                  className="inline-flex items-center gap-2 rounded-2xl bg-emerald-500 px-4 py-2 text-sm font-black text-white"
                >
                  <FileDown size={18} /> Export CSV
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-2 rounded-2xl bg-[#07346f] px-4 py-2 text-sm font-black text-white"
                >
                  <Printer size={18} /> Print A4
                </button>
              </div>
            }
          >
            <div
              id="career-print-area"
              className="overflow-x-auto rounded-[24px] border border-slate-200 bg-white"
            >
              <div className="career-print-title hidden">
                <h1>Career Applications</h1>
                <p>Update Diagnostic Center Rangpur</p>
              </div>
              <table className="w-full min-w-[1200px] border-collapse text-left text-sm">
                <thead>
                  <tr className="bg-[#07346f] text-white">
                    <th className="border border-slate-200 p-3">Date</th>
                    <th className="border border-slate-200 p-3">Name</th>
                    <th className="border border-slate-200 p-3">Phone</th>
                    <th className="border border-slate-200 p-3">Email</th>
                    <th className="border border-slate-200 p-3">Job</th>
                    <th className="border border-slate-200 p-3">Department</th>
                    <th className="border border-slate-200 p-3">Education</th>
                    <th className="border border-slate-200 p-3">Experience</th>
                    <th className="border border-slate-200 p-3">Salary</th>
                    <th className="border border-slate-200 p-3">Status</th>
                    <th className="border border-slate-200 p-3 print:hidden">Resume</th>
                    <th className="border border-slate-200 p-3 print:hidden">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {applications.map((application) => (
                    <tr key={application.id} className="odd:bg-slate-50">
                      <td className="border border-slate-200 p-3 font-bold">
                        {new Date(application.submittedAt).toLocaleString()}
                      </td>
                      <td className="border border-slate-200 p-3 font-black text-[#07346f]">
                        {application.fullName}
                      </td>
                      <td className="border border-slate-200 p-3 font-bold">{application.phone}</td>
                      <td className="border border-slate-200 p-3 font-bold">{application.email}</td>
                      <td className="border border-slate-200 p-3 font-bold">
                        {application.jobTitle || "General Resume"}
                      </td>
                      <td className="border border-slate-200 p-3 font-bold">
                        {application.department || "-"}
                      </td>
                      <td className="border border-slate-200 p-3 font-bold">{application.education}</td>
                      <td className="border border-slate-200 p-3 font-bold">{application.experience}</td>
                      <td className="border border-slate-200 p-3 font-bold">{application.expectedSalary}</td>
                      <td className="border border-slate-200 p-3 print:hidden">
                        <select
                          value={application.status}
                          onChange={(event) => {
                            updateCareerApplicationStatus(
                              application.id,
                              event.target.value as CareerApplication["status"],
                            );
                            setApplications(getCareerApplications());
                          }}
                          className="rounded-xl border border-slate-200 bg-white px-3 py-2 font-bold"
                        >
                          <option value="new">New</option>
                          <option value="reviewed">Reviewed</option>
                          <option value="shortlisted">Shortlisted</option>
                          <option value="rejected">Rejected</option>
                        </select>
                      </td>
                      <td className="hidden border border-slate-200 p-3 font-bold print:table-cell">
                        {application.status}
                      </td>
                      <td className="border border-slate-200 p-3 print:hidden">
                        {application.resumeDataUrl ? (
                          <a
                            href={application.resumeDataUrl}
                            download={application.resumeFileName || "resume-file"}
                            className="inline-flex items-center gap-2 rounded-xl bg-cyan-50 px-3 py-2 font-black text-cyan-600"
                          >
                            <Download size={16} /> Download
                          </a>
                        ) : (
                          "-"
                        )}
                      </td>
                      <td className="border border-slate-200 p-3 print:hidden">
                        <button
                          type="button"
                          onClick={() => {
                            const yes = confirm("Delete application?");
                            if (!yes) return;
                            deleteCareerApplication(application.id);
                            setApplications(getCareerApplications());
                          }}
                          className="rounded-xl border border-red-200 px-3 py-2 font-black text-red-500"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                  {!applications.length ? (
                    <tr>
                      <td colSpan={12} className="p-8 text-center font-black text-slate-400">
                        No application submitted yet.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </Card>
        ) : null}

        {activeTab === "events" ? (
          <Card
            title="Employee Engagement & Events"
            action={
              <button
                type="button"
                onClick={addEvent}
                className="inline-flex items-center gap-2 rounded-2xl bg-cyan-500 px-4 py-2 text-sm font-black text-white"
              >
                <Plus size={18} /> Add Event
              </button>
            }
          >
            <div className="grid gap-6 md:grid-cols-[320px_1fr]">
              <div className="grid h-fit gap-3 rounded-[26px] bg-slate-50 p-3">
                {data.events.map((event) => (
                  <button
                    key={event.id}
                    type="button"
                    onClick={() => setSelectedEventId(event.id)}
                    className={`rounded-2xl p-4 text-left ${
                      selectedEventId === event.id
                        ? "bg-[#07346f] text-white"
                        : "bg-white text-slate-600"
                    }`}
                  >
                    <p className="font-black">{event.title}</p>
                    <p className="mt-1 text-xs font-bold opacity-70">{event.date}</p>
                  </button>
                ))}
              </div>

              {selectedEvent ? (
                <div className="grid gap-5 rounded-[26px] bg-slate-50 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h3 className="text-xl font-black text-[#07346f]">
                      Edit Event + Detail Page
                    </h3>
                    <button
                      type="button"
                      onClick={() => removeEvent(selectedEvent.id)}
                      className="inline-flex items-center gap-2 rounded-2xl border border-red-200 bg-white px-4 py-2 text-sm font-black text-red-500"
                    >
                      <Trash2 size={18} /> Delete Event
                    </button>
                  </div>
                  <div className="grid gap-5 md:grid-cols-[280px_1fr]">
                    <ImageUpload
                      label="Event Image"
                      value={selectedEvent.imageUrl}
                      onChange={(imageUrl) =>
                        patchEvent(selectedEvent.id, { imageUrl })
                      }
                    />
                    <div className="grid gap-4 md:grid-cols-2">
                      <Field
                        label="Event Label"
                        value={selectedEvent.label}
                        onChange={(label) => patchEvent(selectedEvent.id, { label })}
                      />
                      <Field
                        label="Event Title"
                        value={selectedEvent.title}
                        onChange={(title) =>
                          patchEvent(selectedEvent.id, {
                            title,
                            slug: slugify(title) || selectedEvent.slug,
                          })
                        }
                      />
                      <Field
                        label="Slug"
                        value={selectedEvent.slug}
                        onChange={(slug) =>
                          patchEvent(selectedEvent.id, { slug: slugify(slug) })
                        }
                      />
                      <Field
                        label="Date"
                        value={selectedEvent.date}
                        onChange={(date) => patchEvent(selectedEvent.id, { date })}
                      />
                      <Field
                        label="Location"
                        value={selectedEvent.location}
                        onChange={(location) =>
                          patchEvent(selectedEvent.id, { location })
                        }
                      />
                    </div>
                  </div>
                  <Textarea
                    label="Card Excerpt"
                    rows={4}
                    value={selectedEvent.excerpt}
                    onChange={(excerpt) => patchEvent(selectedEvent.id, { excerpt })}
                  />
                  <Textarea
                    label="Read More Detail Page Paragraphs"
                    rows={10}
                    value={arrayToLines(selectedEvent.contentParagraphs)}
                    onChange={(value) =>
                      patchEvent(selectedEvent.id, {
                        contentParagraphs: linesToArray(value),
                      })
                    }
                    hint="One paragraph per line. This appears on the Read More page."
                  />
                </div>
              ) : (
                <div className="rounded-[26px] bg-slate-50 p-8 text-center font-black text-slate-400">
                  No event selected
                </div>
              )}
            </div>
          </Card>
        ) : null}

        {activeTab === "feature" ? (
          <div className="grid gap-6">
            <Card title="Career Feature Main Card">
              <div className="grid gap-6 md:grid-cols-[320px_1fr]">
                <ImageUpload
                  label="Feature Image"
                  value={data.feature.imageUrl}
                  onChange={(imageUrl) =>
                    setData((current) => ({
                      ...current,
                      feature: { ...current.feature, imageUrl },
                    }))
                  }
                />
                <div className="grid gap-4 md:grid-cols-2">
                  <Field
                    label="Badge"
                    value={data.feature.badge}
                    onChange={(badge) =>
                      setData((current) => ({
                        ...current,
                        feature: { ...current.feature, badge },
                      }))
                    }
                  />
                  <Field
                    label="Image Label"
                    value={data.feature.imageLabel}
                    onChange={(imageLabel) =>
                      setData((current) => ({
                        ...current,
                        feature: { ...current.feature, imageLabel },
                      }))
                    }
                  />
                  <div className="md:col-span-2">
                    <Field
                      label="Title"
                      value={data.feature.title}
                      onChange={(title) =>
                        setData((current) => ({
                          ...current,
                          feature: { ...current.feature, title },
                        }))
                      }
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Field
                      label="Highlight Text"
                      value={data.feature.highlight}
                      onChange={(highlight) =>
                        setData((current) => ({
                          ...current,
                          feature: { ...current.feature, highlight },
                        }))
                      }
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Textarea
                      label="Description"
                      rows={6}
                      value={data.feature.description}
                      onChange={(description) =>
                        setData((current) => ({
                          ...current,
                          feature: { ...current.feature, description },
                        }))
                      }
                    />
                  </div>
                </div>
              </div>
            </Card>

            <Card
              title="Feature Small Cards"
              action={
                <button
                  type="button"
                  onClick={() =>
                    setData((current) => ({
                      ...current,
                      feature: {
                        ...current.feature,
                        cards: [
                          ...current.feature.cards,
                          { id: uid("feature"), title: "New Feature", icon: "award" },
                        ],
                      },
                    }))
                  }
                  className="inline-flex items-center gap-2 rounded-2xl bg-cyan-500 px-4 py-2 text-sm font-black text-white"
                >
                  <Plus size={18} /> Add Card
                </button>
              }
            >
              <div className="grid gap-4 md:grid-cols-3">
                {data.feature.cards.map((card) => (
                  <div key={card.id} className="grid gap-4 rounded-[26px] bg-slate-50 p-4">
                    <div className="flex items-center gap-3">
                      <IconPreview icon={card.icon} />
                      <Field
                        label="Title"
                        value={card.title}
                        onChange={(title) => patchFeatureCard(card.id, { title })}
                      />
                    </div>
                    <SelectField
                      label="Icon"
                      value={card.icon}
                      onChange={(icon) =>
                        patchFeatureCard(card.id, { icon: icon as CareerIconKey })
                      }
                    >
                      {iconOptions.map((icon) => (
                        <option key={icon} value={icon}>
                          {icon}
                        </option>
                      ))}
                    </SelectField>
                    <button
                      type="button"
                      onClick={() =>
                        setData((current) => ({
                          ...current,
                          feature: {
                            ...current.feature,
                            cards: current.feature.cards.filter(
                              (item) => item.id !== card.id,
                            ),
                          },
                        }))
                      }
                      className="rounded-2xl border border-red-200 px-4 py-3 text-sm font-black text-red-500"
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        ) : null}

        <div className="mt-6 rounded-[26px] border border-amber-200 bg-amber-50 p-5 text-sm font-bold leading-7 text-amber-800">
          Brutal truth: this is localStorage CMS. Same browser/domain e edit
          korle public page update hobe. Real visitor/applicant data admin panel
          e ante API + database + file upload storage lagbe.
        </div>
      </div>
    </main>
  );
}
