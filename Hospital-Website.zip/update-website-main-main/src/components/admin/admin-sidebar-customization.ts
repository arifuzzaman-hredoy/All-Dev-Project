import type { LucideIcon } from "lucide-react";
import {
  Activity,
  ArrowUpRight,
  BriefcaseMedical,
  ClipboardList,
  CalendarDays,
  ClipboardCheck,
  ContactRound,
  FileText,
  FolderKanban,
  History,
  ImageIcon,
  LayoutDashboard,
  LayoutGrid,
  MessageSquareText,
  Newspaper,
  PanelTop,
  SearchCheck,
  ServerCog,
  Settings2,
  Shield,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  Users,
  UserCog,
} from "lucide-react";

export type AdminNavItem = {
  label: string;
  href: string;
  description: string;
  icon: LucideIcon;
};

export type AdminNavGroup = {
  label: string;
  items: AdminNavItem[];
};

export const adminSidebarBrand = {
  eyebrow: "Admin Panel",
  title: "Update Diagnostic Center",
  mobileTitle: "Navigation",
  icon: Shield,
};

export const adminSidebarLabels = {
  workspace: "Admin workspace",
  fallbackTitle: "Admin",
  publicSite: "View public site",
  logout: "Logout",
};

export const adminSidebarWidths = {
  expanded: "320px",
  collapsed: "92px",
};

export const adminNavGroups: AdminNavGroup[] = [
  {
    label: "Overview",
    items: [
      {
        label: "Dashboard",
        href: "/admin",
        description: "Live shortcuts and editing status.",
        icon: LayoutDashboard,
      },
      {
        label: "Site settings",
        href: "/admin/site-settings",
        description: "Brand, contact, and utility values.",
        icon: Settings2,
      },
      {
        label: "Audit logs",
        href: "/admin/audit-logs",
        description: "Track admin login, changes, deletes, and uploads.",
        icon: History,
      },
      {
        label: "Admin users",
        href: "/admin/users",
        description: "Super admin user registration, roles, and access control.",
        icon: UserCog,
      },
      {
        label: "Backend support",
        href: "/admin/frontend-support",
        description: "Verify frontend features have real backend and DB support.",
        icon: ServerCog,
      },
      {
        label: "Media library",
        href: "/admin/media",
        description: "Upload, copy, update, and remove CMS images.",
        icon: ImageIcon,
      },
      {
        label: "Services",
        href: "/admin/services",
        description: "Create dynamic public service pages.",
        icon: FolderKanban,
      },
      {
        label: "Doctors",
        href: "/admin/doctors",
        description: "Manage doctor profiles and schedules.",
        icon: Stethoscope,
      },
      {
        label: "Appointments",
        href: "/admin/appointments",
        description: "View and manage appointment requests.",
        icon: CalendarDays,
      },
      {
        label: "Package requests",
        href: "/admin/package-requests",
        description: "Verify and print health package bookings.",
        icon: ClipboardCheck,
      },
      {
        label: "Form submissions",
        href: "/admin/form-submissions",
        description: "View every public form request in one place.",
        icon: FileText,
      },
      {
        label: "SMS templates",
        href: "/admin/sms-templates",
        description: "Edit SMS messages and dynamic variables.",
        icon: FileText,
      },
      {
        label: "SMS logs",
        href: "/admin/sms-logs",
        description: "Track sent, failed, disabled, and pending SMS messages.",
        icon: FileText,
      },
      {
        label: "Exports",
        href: "/admin/exports",
        description: "Download appointments, submissions, package bookings, and SMS logs.",
        icon: FileText,
      },
    ],
  },
  {
    label: "Homepage",
    items: [
      {
        label: "Hero",
        href: "/admin/sections/home-hero",
        description: "Main headline, CTA, and banner copy.",
        icon: Sparkles,
      },
      {
        label: "Quick actions",
        href: "/admin/sections/home-quick-actions",
        description: "Homepage action cards and links.",
        icon: ClipboardList,
      },
      {
        label: "Why choose us",
        href: "/admin/sections/home-why-choose",
        description: "Homepage trust and value points.",
        icon: ShieldCheck,
      },
      {
        label: "Specialities",
        href: "/admin/sections/home-specialities",
        description: "Featured specialities and card copy.",
        icon: LayoutGrid,
      },
      {
        label: "Homepage doctors",
        href: "/admin/sections/home-doctors",
        description: "Consultant highlights and availability.",
        icon: Stethoscope,
      },
      {
        label: "News",
        href: "/admin/sections/home-news",
        description: "Homepage news teaser items.",
        icon: Newspaper,
      },
      {
        label: "Blogs",
        href: "/admin/sections/home-blogs",
        description: "Homepage blog teaser items.",
        icon: FileText,
      },
      {
        label: "Corporate services",
        href: "/admin/sections/home-corporate-services",
        description: "Corporate service tiles and copy.",
        icon: BriefcaseMedical,
      },
    ],
  },
  {
    label: "Public pages",
    items: [
      {
        label: "About",
        href: "/admin/pages/about",
        description: "About page sections and story text.",
        icon: Users,
      },
      {
        label: "Appointment",
        href: "/admin/pages/appointment",
        description: "Appointment hero and urgent help copy.",
        icon: PanelTop,
      },
      {
        label: "Contact",
        href: "/admin/pages/contact",
        description: "Location list, map notes, and hotline.",
        icon: ContactRound,
      },
      {
        label: "Health check",
        href: "/admin/pages/health-check",
        description: "Package overview and screening copy.",
        icon: SearchCheck,
      },
      {
        label: "Online report",
        href: "/admin/pages/online-report",
        description: "Report access steps and support copy.",
        icon: ArrowUpRight,
      },
      {
        label: "Patient guide",
        href: "/admin/pages/patient-guide",
        description: "Admission, billing, and discharge notes.",
        icon: ClipboardList,
      },
      {
        label: "Patient stories",
        href: "/admin/pages/patient-stories",
        description: "Story cards and quote copy.",
        icon: Users,
      },
      {
        label: "News & media",
        href: "/admin/pages/news-media",
        description: "Media updates and announcement copy.",
        icon: Activity,
      },
      {
        label: "Doctor articles",
        href: "/admin/pages/doctor-articles",
        description: "Educational article teasers.",
        icon: FileText,
      },
      {
        label: "Blogs",
        href: "/admin/pages/blogs",
        description: "Blog index copy and teaser content.",
        icon: Newspaper,
      },
      {
        label: "Career",
        href: "/admin/career",
        description: "Jobs, events, applications, and career page content.",
        icon: BriefcaseMedical,
      },
      {
        label: "Support",
        href: "/admin/pages/support",
        description: "Support center and contact guidance.",
        icon: MessageSquareText,
      },
      {
        label: "Legal",
        href: "/admin/pages/legal",
        description: "Privacy policy and terms copy.",
        icon: ShieldCheck,
      },
    ],
  },
];

