"use client";

import { type ReactNode, useMemo, useState, useTransition } from "react";

import { deleteAppointmentAction } from "@/app/admin/appointments/actions";
import type {
  AppointmentRecord,
  ManualAppointmentDoctor,
} from "@/types/appointment";
import AppointmentFilters from "./AppointmentFilters";
import AppointmentPrintButton from "./AppointmentPrintButton";
import ManualAppointmentModal from "./ManualAppointmentModal";

type AppointmentsTableProps = {
  appointments: AppointmentRecord[];
  doctors: ManualAppointmentDoctor[];
  clinicName: string;
};

function formatDate(value: string) {
  if (!value) return "";

  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function formatSource(value?: string) {
  if (!value) return "Public";
  return value.replaceAll("_", " ").toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
}

function matchesAppointment(appointment: AppointmentRecord, search: string) {
  const query = search.trim().toLowerCase();
  if (!query) return true;

  return [
    appointment.patientName,
    appointment.phone,
    appointment.disease,
    appointment.doctorName,
    appointment.department,
    appointment.source || "",
    appointment.smsStatus || "",
  ].some((value) => value.toLowerCase().includes(query));
}

export default function AppointmentsTable({
  appointments,
  doctors,
  clinicName,
}: AppointmentsTableProps) {
  const [search, setSearch] = useState("");
  const [records, setRecords] = useState(appointments);
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const printDate = useMemo(() => formatDate(new Date().toISOString()), []);

  const filteredAppointments = useMemo(
    () => records.filter((appointment) => matchesAppointment(appointment, search)),
    [records, search],
  );

  function handleCreated(appointment: AppointmentRecord) {
    setRecords((current) => [appointment, ...current]);
  }

  function handleDelete(appointment: AppointmentRecord) {
    const confirmed = window.confirm(
      `Delete appointment ${appointment.token} for ${appointment.patientName}?`,
    );

    if (!confirmed) return;

    setPendingId(appointment.id);
    startTransition(async () => {
      await deleteAppointmentAction(appointment.id);
      setRecords((current) =>
        current.filter((record) => record.id !== appointment.id),
      );
      setPendingId(null);
    });
  }

  return (
    <section className="space-y-4">
      <div className="flex flex-col gap-3 print:hidden lg:flex-row lg:items-end lg:justify-between">
        <div className="w-full max-w-2xl">
          <AppointmentFilters search={search} onSearchChange={setSearch} />
        </div>

        <div className="flex flex-col gap-2 sm:flex-row">
          <ManualAppointmentModal doctors={doctors} onCreated={handleCreated} />
          <AppointmentPrintButton />
        </div>
      </div>

      <div
        id="appointments-print-sheet"
        className="overflow-hidden border border-slate-300 bg-white print:border-0"
      >
        <div className="hidden print:block">
          <h2 className="text-base font-bold text-black">{clinicName}</h2>
          <p className="mt-1 text-xs text-black">Appointment Requests</p>
          <p className="mt-1 text-xs text-black">Printed: {printDate}</p>
        </div>

        <div className="overflow-x-auto print:overflow-visible">
          <table className="min-w-[1840px] border-collapse text-left text-xs text-slate-900 print:w-full print:min-w-0 print:text-[8px]">
            <thead className="bg-slate-100 text-[11px] uppercase text-slate-700 print:bg-white print:text-black">
              <tr>
                <TableHeader>Serial No.</TableHeader>
                <TableHeader>Token / Receipt ID</TableHeader>
                <TableHeader>Source</TableHeader>
                <TableHeader>SMS</TableHeader>
                <TableHeader>Patient Name</TableHeader>
                <TableHeader>Phone</TableHeader>
                <TableHeader>Age</TableHeader>
                <TableHeader>Gender</TableHeader>
                <TableHeader>Disease / Problem</TableHeader>
                <TableHeader>Department</TableHeader>
                <TableHeader>Doctor Name</TableHeader>
                <TableHeader>Doctor Available Days</TableHeader>
                <TableHeader>Appointment Time</TableHeader>
                <TableHeader>Room</TableHeader>
                <TableHeader>Fee</TableHeader>
                <TableHeader>Submitted Date</TableHeader>
                <TableHeader className="print:hidden">Action</TableHeader>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.map((appointment, index) => (
                <tr
                  key={appointment.id}
                  className="odd:bg-white even:bg-slate-50 print:bg-white"
                >
                  <TableCell>{index + 1}</TableCell>
                  <TableCell className="font-semibold">{appointment.token}</TableCell>
                  <TableCell>{formatSource(appointment.source)}</TableCell>
                  <TableCell>{appointment.smsStatus || "PENDING"}</TableCell>
                  <TableCell>{appointment.patientName}</TableCell>
                  <TableCell>{appointment.phone}</TableCell>
                  <TableCell>{appointment.age}</TableCell>
                  <TableCell>{appointment.gender}</TableCell>
                  <TableCell>{appointment.disease}</TableCell>
                  <TableCell>{appointment.department}</TableCell>
                  <TableCell>{appointment.doctorName}</TableCell>
                  <TableCell>{appointment.doctorAvailableDays.join(", ")}</TableCell>
                  <TableCell>{appointment.appointmentTime}</TableCell>
                  <TableCell>{appointment.room}</TableCell>
                  <TableCell>৳{appointment.fee}</TableCell>
                  <TableCell>{formatDate(appointment.submittedAt)}</TableCell>
                  <TableCell className="print:hidden">
                    <button
                      type="button"
                      onClick={() => handleDelete(appointment)}
                      disabled={isPending && pendingId === appointment.id}
                      className="rounded border border-red-200 px-2 py-1 text-[11px] font-bold text-red-600 transition hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {isPending && pendingId === appointment.id
                        ? "Deleting"
                        : "Delete"}
                    </button>
                  </TableCell>
                </tr>
              ))}

              {filteredAppointments.length === 0 && (
                <tr>
                  <td
                    colSpan={17}
                    className="border border-slate-300 px-3 py-8 text-center text-sm text-slate-500"
                  >
                    No appointment records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <style jsx global>{`
        @media print {
          @page {
            size: A4 landscape;
            margin: 10mm;
          }

          body {
            background: #fff !important;
          }

          body * {
            visibility: hidden;
          }

          #appointments-print-sheet,
          #appointments-print-sheet * {
            visibility: visible;
          }

          #appointments-print-sheet {
            position: absolute;
            inset: 0 auto auto 0;
            width: 100%;
          }
        }
      `}</style>
    </section>
  );
}

function TableHeader({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <th
      className={`border border-slate-300 px-2 py-2 align-middle font-bold ${className}`}
    >
      {children}
    </th>
  );
}

function TableCell({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <td className={`border border-slate-300 px-2 py-1.5 align-top ${className}`}>
      {children}
    </td>
  );
}
