"use client";

import { Printer } from "lucide-react";

export default function AppointmentPrintButton() {
  return (
    <button
      type="button"
      onClick={() => window.print()}
      className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-4 text-sm font-bold text-slate-700 transition hover:border-[#062f66] hover:text-[#062f66] print:hidden"
    >
      <Printer size={16} />
      Print
    </button>
  );
}
