"use client";

import { type FormEvent, useMemo, useState } from "react";
import { Loader2, Plus, X } from "lucide-react";

import type {
  AppointmentRecord,
  ManualAppointmentDoctor,
  ManualAppointmentInput,
  ManualAppointmentSource,
} from "@/types/appointment";

type ManualAppointmentModalProps = {
  doctors: ManualAppointmentDoctor[];
  onCreated: (appointment: AppointmentRecord) => void;
};

const initialForm: ManualAppointmentInput = {
  patientName: "",
  phone: "",
  patientEmail: "",
  age: "",
  gender: "Male",
  disease: "",
  doctorId: "",
  department: "",
  doctorName: "",
  doctorDesignation: "",
  specialist: "",
  doctorAvailableDays: [],
  appointmentTime: "",
  room: "",
  fee: 0,
  source: "PHONE_CALL",
  message: "",
};

export default function ManualAppointmentModal({
  doctors,
  onCreated,
}: ManualAppointmentModalProps) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<ManualAppointmentInput>(initialForm);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const selectedDoctor = useMemo(
    () => doctors.find((doctor) => doctor.id === form.doctorId),
    [doctors, form.doctorId],
  );

  function updateField<K extends keyof ManualAppointmentInput>(
    key: K,
    value: ManualAppointmentInput[K],
  ) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function handleDoctorChange(doctorId: string) {
    const doctor = doctors.find((item) => item.id === doctorId);

    if (!doctor) {
      setForm((current) => ({
        ...current,
        doctorId: "",
        doctorName: "",
        doctorDesignation: "",
        specialist: "",
        doctorAvailableDays: [],
      }));
      return;
    }

    setForm((current) => ({
      ...current,
      doctorId: doctor.id,
      department: doctor.department,
      doctorName: doctor.name,
      doctorDesignation: doctor.designation,
      specialist: doctor.specialist,
      doctorAvailableDays: doctor.availableDays,
      appointmentTime: doctor.consultationTime || current.appointmentTime,
      room: doctor.room || current.room,
      fee: doctor.fee,
    }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const response = await fetch("/api/admin/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = (await response.json().catch(() => null)) as {
        appointment?: AppointmentRecord;
        message?: string;
      } | null;

      if (!response.ok || !data?.appointment) {
        throw new Error(data?.message || "Manual appointment save failed.");
      }

      onCreated(data.appointment);
      setForm(initialForm);
      setOpen(false);
    } catch (caught) {
      setError(
        caught instanceof Error
          ? caught.message
          : "Manual appointment save failed.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="print:hidden">
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex h-10 items-center justify-center gap-2 rounded-md bg-[#062f66] px-4 text-sm font-black text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-[#0b3f85]"
      >
        <Plus size={17} />
        Add Manual Appointment
      </button>

      {open ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 px-3 py-6 backdrop-blur-sm">
          <div className="max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-[28px] bg-white shadow-[0_30px_100px_rgba(15,23,42,0.35)]">
            <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-slate-100 bg-white/95 p-5 backdrop-blur">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.18em] text-[#43c7f4]">
                  Counter / Phone Entry
                </p>
                <h2 className="mt-1 text-2xl font-black text-[#062f66]">
                  Add Manual Appointment
                </h2>
                <p className="mt-1 text-sm font-semibold text-slate-500">
                  Save phone call or counter appointment directly into the admin system.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setOpen(false)}
                className="grid h-10 w-10 place-items-center rounded-full border border-slate-200 text-slate-600 transition hover:bg-slate-50"
                aria-label="Close manual appointment modal"
              >
                <X size={19} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-5 p-5">
              <div className="grid gap-4 md:grid-cols-3">
                <Field label="Source">
                  <select
                    value={form.source}
                    onChange={(event) =>
                      updateField(
                        "source",
                        event.target.value as ManualAppointmentSource,
                      )
                    }
                    className="form-input"
                  >
                    <option value="PHONE_CALL">Phone Call</option>
                    <option value="ADMIN_MANUAL">Counter / Manual</option>
                  </select>
                </Field>

                <Field label="Patient name *">
                  <input
                    required
                    value={form.patientName}
                    onChange={(event) =>
                      updateField("patientName", event.target.value)
                    }
                    placeholder="Patient full name"
                    className="form-input"
                  />
                </Field>

                <Field label="Phone *">
                  <input
                    required
                    value={form.phone}
                    onChange={(event) => updateField("phone", event.target.value)}
                    placeholder="Phone number"
                    className="form-input"
                  />
                </Field>
              </div>

              <div className="grid gap-4 md:grid-cols-4">
                <Field label="Email">
                  <input
                    type="email"
                    value={form.patientEmail}
                    onChange={(event) =>
                      updateField("patientEmail", event.target.value)
                    }
                    placeholder="Email address"
                    className="form-input"
                  />
                </Field>

                <Field label="Age">
                  <input
                    value={form.age}
                    onChange={(event) => updateField("age", event.target.value)}
                    placeholder="Age"
                    className="form-input"
                  />
                </Field>

                <Field label="Gender">
                  <select
                    value={form.gender}
                    onChange={(event) => updateField("gender", event.target.value)}
                    className="form-input"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </Field>

                <Field label="Disease / Problem *">
                  <input
                    required
                    value={form.disease}
                    onChange={(event) =>
                      updateField("disease", event.target.value)
                    }
                    placeholder="Disease/problem"
                    className="form-input"
                  />
                </Field>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Doctor">
                  <select
                    value={form.doctorId}
                    onChange={(event) => handleDoctorChange(event.target.value)}
                    className="form-input"
                  >
                    <option value="">No doctor selected</option>
                    {doctors.map((doctor) => (
                      <option key={doctor.id} value={doctor.id}>
                        {doctor.name} — {doctor.department}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Department *">
                  <input
                    required
                    value={form.department}
                    onChange={(event) =>
                      updateField("department", event.target.value)
                    }
                    placeholder="Department"
                    className="form-input"
                  />
                </Field>
              </div>

              {selectedDoctor ? (
                <div className="rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] p-4 text-sm font-semibold text-slate-600">
                  <span className="font-black text-[#062f66]">
                    Selected doctor:
                  </span>{" "}
                  {selectedDoctor.name} · {selectedDoctor.designation} ·{" "}
                  {selectedDoctor.availableDays.join(", ") || "No schedule"}
                </div>
              ) : null}

              <div className="grid gap-4 md:grid-cols-4">
                <Field label="Appointment time *">
                  <input
                    required
                    value={form.appointmentTime}
                    onChange={(event) =>
                      updateField("appointmentTime", event.target.value)
                    }
                    placeholder="10:00 AM - 12:00 PM"
                    className="form-input"
                  />
                </Field>

                <Field label="Room">
                  <input
                    value={form.room}
                    onChange={(event) => updateField("room", event.target.value)}
                    placeholder="Room"
                    className="form-input"
                  />
                </Field>

                <Field label="Fee">
                  <input
                    type="number"
                    min="0"
                    value={form.fee}
                    onChange={(event) =>
                      updateField("fee", Number(event.target.value))
                    }
                    placeholder="Fee"
                    className="form-input"
                  />
                </Field>

                <Field label="Available days">
                  <input
                    value={form.doctorAvailableDays.join(", ")}
                    onChange={(event) =>
                      updateField(
                        "doctorAvailableDays",
                        event.target.value
                          .split(",")
                          .map((item) => item.trim())
                          .filter(Boolean),
                      )
                    }
                    placeholder="Sat, Sun, Mon"
                    className="form-input"
                  />
                </Field>
              </div>

              <Field label="Internal note / message">
                <textarea
                  value={form.message}
                  onChange={(event) => updateField("message", event.target.value)}
                  placeholder="Write any additional note"
                  rows={4}
                  className="form-input min-h-28 py-3"
                />
              </Field>

              {error ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-black text-red-700">
                  {error}
                </div>
              ) : null}

              <div className="flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="h-11 rounded-full border border-slate-200 px-5 text-sm font-black text-slate-600 transition hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-[#43c7f4] px-5 text-sm font-black text-white shadow-[0_16px_35px_rgba(67,199,244,0.30)] transition hover:-translate-y-0.5 hover:bg-[#17a9de] disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {loading ? (
                    <Loader2 className="animate-spin" size={18} />
                  ) : (
                    <Plus size={18} />
                  )}
                  {loading ? "Saving..." : "Save appointment"}
                </button>
              </div>
            </form>

            <style jsx>{`
              .form-input {
                height: 44px;
                width: 100%;
                border-radius: 14px;
                border: 1px solid #dbe8ff;
                background: #f8fbff;
                padding: 0 14px;
                font-size: 13px;
                font-weight: 700;
                color: #062f66;
                outline: none;
                transition: all 0.2s ease;
              }

              .form-input:focus {
                border-color: #43c7f4;
                background: #ffffff;
                box-shadow: 0 0 0 4px rgba(67, 199, 244, 0.15);
              }
            `}</style>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="grid gap-2 text-sm font-black text-[#062f66]">
      {label}
      {children}
    </label>
  );
}
