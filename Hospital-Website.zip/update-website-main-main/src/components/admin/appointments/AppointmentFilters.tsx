"use client";

type AppointmentFiltersProps = {
  search: string;
  onSearchChange: (value: string) => void;
};

export default function AppointmentFilters({
  search,
  onSearchChange,
}: AppointmentFiltersProps) {
  return (
    <div className="print:hidden">
      <label
        htmlFor="appointment-search"
        className="mb-2 block text-xs font-bold uppercase tracking-[0.14em] text-slate-500"
      >
        Search appointments
      </label>
      <input
        id="appointment-search"
        type="search"
        value={search}
        onChange={(event) => onSearchChange(event.target.value)}
        placeholder="Search by patient, phone, disease, doctor, or department"
        className="h-10 w-full rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none transition focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
      />
    </div>
  );
}
