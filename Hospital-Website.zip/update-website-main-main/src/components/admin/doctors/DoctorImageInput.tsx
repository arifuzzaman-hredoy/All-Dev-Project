"use client";

import Image from "next/image";
import { UserRound } from "lucide-react";

type DoctorImageInputProps = {
  imageUrl: string;
  onImageUrlChange: (value: string) => void;
  onFileChange: (file: File | null) => void;
};

export default function DoctorImageInput({
  imageUrl,
  onImageUrlChange,
  onFileChange,
}: DoctorImageInputProps) {
  return (
    <div className="grid gap-3 sm:grid-cols-[96px_1fr]">
      <div className="flex size-24 items-center justify-center overflow-hidden rounded-md border border-slate-300 bg-slate-50">
        {imageUrl ? (
          <Image
            src={imageUrl}
            alt="Doctor preview"
            width={96}
            height={96}
            unoptimized
            className="h-full w-full object-cover"
          />
        ) : (
          <UserRound size={34} className="text-slate-400" />
        )}
      </div>

      <div className="space-y-3">
        <input
          value={imageUrl}
          onChange={(event) => onImageUrlChange(event.target.value)}
          placeholder="/uploads/cms/doctor.jpg"
          className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
        />
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={(event) => onFileChange(event.target.files?.[0] || null)}
          className="block w-full text-sm text-slate-600 file:mr-3 file:rounded-md file:border-0 file:bg-slate-900 file:px-3 file:py-2 file:text-sm file:font-bold file:text-white"
        />
      </div>
    </div>
  );
}
