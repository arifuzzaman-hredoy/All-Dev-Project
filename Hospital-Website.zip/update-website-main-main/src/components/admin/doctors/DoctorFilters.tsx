"use client";

type DoctorFiltersProps = {
  search: string;
  onSearchChange: (value: string) => void;
};

export default function DoctorFilters({
  search,
  onSearchChange,
}: DoctorFiltersProps) {
  return (
    <div>
      <label
        htmlFor="doctor-search"
        className="mb-2 block text-xs font-bold uppercase tracking-[0.14em] text-slate-500"
      >
        Search doctors
      </label>
      <input
        id="doctor-search"
        type="search"
        value={search}
        onChange={(event) => onSearchChange(event.target.value)}
        placeholder="Search by name, department, specialist, or available day"
        className="h-10 w-full rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none transition focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
      />
    </div>
  );
}
