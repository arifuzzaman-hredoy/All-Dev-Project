"use client";

import { FormEvent, useState } from "react";

import type { DoctorProfile, DoctorProfileInput } from "@/types/doctor";
import DoctorImageInput from "./DoctorImageInput";

const blankForm: DoctorProfileInput = {
  name: "",
  designation: "",
  department: "",
  specialist: "",
  experienceYears: 0,
  availableDays: [],
  consultationTime: "",
  room: "",
  fee: 0,
  imageUrl: "",
  isActive: true,
  sortOrder: 0,
};

type DoctorFormProps = {
  selectedDoctor: DoctorProfile | null;
  nextSortOrder: number;
  onCancel: () => void;
  onSaved: (doctor: DoctorProfile) => void;
};

function doctorToInput(doctor: DoctorProfile | null, nextSortOrder: number) {
  if (!doctor) return { ...blankForm, sortOrder: nextSortOrder };

  return {
    name: doctor.name,
    designation: doctor.designation,
    department: doctor.department,
    specialist: doctor.specialist,
    experienceYears: doctor.experienceYears,
    availableDays: doctor.availableDays,
    consultationTime: doctor.consultationTime,
    room: doctor.room,
    fee: doctor.fee,
    imageUrl: doctor.imageUrl,
    isActive: doctor.isActive,
    sortOrder: doctor.sortOrder,
  } satisfies DoctorProfileInput;
}

export default function DoctorForm({
  selectedDoctor,
  nextSortOrder,
  onCancel,
  onSaved,
}: DoctorFormProps) {
  const [form, setForm] = useState(() =>
    doctorToInput(selectedDoctor, nextSortOrder),
  );
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  function updateField<K extends keyof DoctorProfileInput>(
    key: K,
    value: DoctorProfileInput[K],
  ) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function uploadImage() {
    if (!imageFile) return form.imageUrl;

    const data = new FormData();
    data.append("file", imageFile);

    const response = await fetch("/api/admin/uploads", {
      method: "POST",
      body: data,
    });
    const result = (await response.json()) as {
      ok?: boolean;
      url?: string;
      message?: string;
    };

    if (!response.ok || !result.ok || !result.url) {
      throw new Error(result.message || "Doctor image upload failed.");
    }

    return result.url;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSaving(true);

    try {
      const imageUrl = await uploadImage();
      const payload = { ...form, imageUrl };
      const response = await fetch(
        selectedDoctor ? `/api/doctors/${selectedDoctor.id}` : "/api/doctors",
        {
          method: selectedDoctor ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        },
      );
      const result = (await response.json()) as {
        doctor?: DoctorProfile;
        message?: string;
      };

      if (!response.ok || !result.doctor) {
        throw new Error(result.message || "Doctor save failed.");
      }

      onSaved(result.doctor);
      setForm(doctorToInput(null, nextSortOrder + 1));
      setImageFile(null);
    } catch (caught) {
      alert(caught instanceof Error ? caught.message : "Doctor save failed.");
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-4 rounded-md border border-slate-300 bg-white p-4"
    >
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-black text-[#062f66]">
            {selectedDoctor ? "Edit doctor profile" : "Add doctor profile"}
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            Add picture, name, title, degree, experience, schedule, room, and fee.
          </p>
        </div>
        <button
          type="button"
          onClick={onCancel}
          className="rounded-md border border-slate-300 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50"
        >
          Close
        </button>
      </div>

      <DoctorImageInput
        imageUrl={form.imageUrl}
        onImageUrlChange={(value) => updateField("imageUrl", value)}
        onFileChange={setImageFile}
      />

      <div className="grid gap-3 sm:grid-cols-2">
        <TextInput
          label="Doctor name *"
          value={form.name}
          onChange={(value) => updateField("name", value)}
        />
        <TextInput
          label="Designation/title"
          value={form.designation}
          onChange={(value) => updateField("designation", value)}
        />
        <TextInput
          label="Department *"
          value={form.department}
          onChange={(value) => updateField("department", value)}
        />
        <TextInput
          label="Specialist/degree"
          value={form.specialist}
          onChange={(value) => updateField("specialist", value)}
        />
        <NumberInput
          label="Years of experience *"
          value={form.experienceYears}
          onChange={(value) => updateField("experienceYears", value)}
        />
        <NumberInput
          label="Consultation fee *"
          value={form.fee}
          onChange={(value) => updateField("fee", value)}
        />
        <TextInput
          label="Available days *"
          value={form.availableDays.join(", ")}
          onChange={(value) =>
            updateField(
              "availableDays",
              value
                .split(",")
                .map((day) => day.trim())
                .filter(Boolean),
            )
          }
          placeholder="Saturday, Monday, Wednesday"
        />
        <TextInput
          label="Consultation time"
          value={form.consultationTime}
          onChange={(value) => updateField("consultationTime", value)}
          placeholder="10:00 AM - 2:00 PM"
        />
        <TextInput
          label="Room number"
          value={form.room}
          onChange={(value) => updateField("room", value)}
        />
        <NumberInput
          label="Sort order"
          value={form.sortOrder}
          onChange={(value) => updateField("sortOrder", value)}
        />
      </div>

      <label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
        <input
          type="checkbox"
          checked={form.isActive}
          onChange={(event) => updateField("isActive", event.target.checked)}
          className="size-4 rounded border-slate-300"
        />
        Active doctor
      </label>

      <button
        type="submit"
        disabled={isSaving}
        className="rounded-md bg-slate-900 px-4 py-2 text-sm font-bold text-white transition hover:bg-[#062f66] disabled:cursor-not-allowed disabled:opacity-60"
      >
        {isSaving ? "Saving..." : selectedDoctor ? "Update Doctor" : "Add Doctor"}
      </button>
    </form>
  );
}

function TextInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-bold text-slate-600">
        {label}
      </span>
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
      />
    </label>
  );
}

function NumberInput({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-bold text-slate-600">
        {label}
      </span>
      <input
        type="number"
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
      />
    </label>
  );
}
