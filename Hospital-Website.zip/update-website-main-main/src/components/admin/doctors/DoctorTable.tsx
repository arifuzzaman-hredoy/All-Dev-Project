"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import { UserRound } from "lucide-react";

import type { DoctorProfile } from "@/types/doctor";
import DoctorFilters from "./DoctorFilters";
import DoctorForm from "./DoctorForm";

type DoctorTableProps = {
  doctors: DoctorProfile[];
};

function matchesDoctor(doctor: DoctorProfile, search: string) {
  const query = search.trim().toLowerCase();
  if (!query) return true;

  return [
    doctor.name,
    doctor.department,
    doctor.specialist,
    doctor.designation,
    doctor.availableDays.join(", "),
  ].some((value) => value.toLowerCase().includes(query));
}

function sortDoctors(doctors: DoctorProfile[]) {
  return [...doctors].sort((left, right) => {
    const order = left.sortOrder - right.sortOrder;
    if (order !== 0) return order;

    return left.name.localeCompare(right.name);
  });
}

export default function DoctorTable({ doctors }: DoctorTableProps) {
  const [records, setRecords] = useState(() => sortDoctors(doctors));
  const [search, setSearch] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState<DoctorProfile | null>(
    null,
  );
  const [formOpen, setFormOpen] = useState(false);
  const [isDeletingId, setIsDeletingId] = useState("");

  const filteredDoctors = useMemo(
    () => records.filter((doctor) => matchesDoctor(doctor, search)),
    [records, search],
  );

  const nextSortOrder =
    records.reduce((highest, doctor) => Math.max(highest, doctor.sortOrder), 0) +
    1;

  function handleSaved(doctor: DoctorProfile) {
    setRecords((current) => {
      const exists = current.some((item) => item.id === doctor.id);
      const next = exists
        ? current.map((item) => (item.id === doctor.id ? doctor : item))
        : [...current, doctor];

      return sortDoctors(next);
    });
    setSelectedDoctor(null);
    setFormOpen(false);
  }

  async function toggleStatus(doctor: DoctorProfile) {
    const response = await fetch(`/api/doctors/${doctor.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...doctor, isActive: !doctor.isActive }),
    });
    const result = (await response.json()) as {
      doctor?: DoctorProfile;
      message?: string;
    };

    if (!response.ok || !result.doctor) {
      alert(result.message || "Doctor status update failed.");
      return;
    }

    handleSaved(result.doctor);
  }

  async function deleteDoctor(doctor: DoctorProfile) {
    const confirmed = window.confirm(`Delete ${doctor.name}?`);
    if (!confirmed) return;

    setIsDeletingId(doctor.id);

    try {
      const response = await fetch(`/api/doctors/${doctor.id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const result = (await response.json()) as { message?: string };
        alert(result.message || "Doctor delete failed.");
        return;
      }

      setRecords((current) => current.filter((item) => item.id !== doctor.id));
      if (selectedDoctor?.id === doctor.id) setSelectedDoctor(null);
    } finally {
      setIsDeletingId("");
    }
  }

  return (
    <div className="space-y-5">
      {formOpen ? (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-950/45 px-4 py-6 backdrop-blur-sm sm:py-10">
          <div className="w-full max-w-4xl">
            <DoctorForm
              key={selectedDoctor?.id || `new-${nextSortOrder}`}
              selectedDoctor={selectedDoctor}
              nextSortOrder={nextSortOrder}
              onCancel={() => {
                setSelectedDoctor(null);
                setFormOpen(false);
              }}
              onSaved={handleSaved}
            />
          </div>
        </div>
      ) : null}

      <div className="space-y-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div className="w-full max-w-2xl">
            <DoctorFilters search={search} onSearchChange={setSearch} />
          </div>
          <button
            type="button"
            onClick={() => {
              setSelectedDoctor(null);
              setFormOpen(true);
            }}
            className="h-10 rounded-md bg-slate-900 px-4 text-sm font-bold text-white hover:bg-[#062f66]"
          >
            Add doctor
          </button>
        </div>

        <div className="overflow-hidden border border-slate-300 bg-white">
          <div className="overflow-x-auto">
            <table className="min-w-[1200px] border-collapse text-left text-xs text-slate-900">
              <thead className="bg-slate-100 text-[11px] uppercase text-slate-700">
                <tr>
                  <TableHeader>Image</TableHeader>
                  <TableHeader>Doctor Name</TableHeader>
                  <TableHeader>Department</TableHeader>
                  <TableHeader>Specialist</TableHeader>
                  <TableHeader>Experience</TableHeader>
                  <TableHeader>Available Days</TableHeader>
                  <TableHeader>Time</TableHeader>
                  <TableHeader>Room</TableHeader>
                  <TableHeader>Fee</TableHeader>
                  <TableHeader>Status</TableHeader>
                  <TableHeader>Action</TableHeader>
                </tr>
              </thead>
              <tbody>
                {filteredDoctors.map((doctor) => (
                  <tr key={doctor.id} className="odd:bg-white even:bg-slate-50">
                    <TableCell>
                      <div className="flex size-12 items-center justify-center overflow-hidden rounded border border-slate-200 bg-slate-50">
                        {doctor.imageUrl ? (
                          <Image
                            src={doctor.imageUrl}
                            alt={doctor.name}
                            width={48}
                            height={48}
                            unoptimized
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <UserRound size={22} className="text-slate-400" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-bold text-slate-900">
                        {doctor.name}
                      </div>
                      <div className="mt-1 text-slate-500">
                        {doctor.designation}
                      </div>
                    </TableCell>
                    <TableCell>{doctor.department}</TableCell>
                    <TableCell>{doctor.specialist}</TableCell>
                    <TableCell>{doctor.experienceYears} years</TableCell>
                    <TableCell>{doctor.availableDays.join(", ")}</TableCell>
                    <TableCell>{doctor.consultationTime}</TableCell>
                    <TableCell>{doctor.room}</TableCell>
                    <TableCell>৳{doctor.fee}</TableCell>
                    <TableCell>
                      <button
                        type="button"
                        onClick={() => void toggleStatus(doctor)}
                        className={`rounded border px-2 py-1 text-[11px] font-bold ${
                          doctor.isActive
                            ? "border-emerald-200 text-emerald-700"
                            : "border-slate-300 text-slate-500"
                        }`}
                      >
                        {doctor.isActive ? "Active" : "Inactive"}
                      </button>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedDoctor(doctor);
                            setFormOpen(true);
                          }}
                          className="rounded border border-slate-300 px-2 py-1 text-[11px] font-bold text-slate-700 hover:bg-slate-50"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => void deleteDoctor(doctor)}
                          disabled={isDeletingId === doctor.id}
                          className="rounded border border-red-200 px-2 py-1 text-[11px] font-bold text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          {isDeletingId === doctor.id ? "Deleting" : "Delete"}
                        </button>
                      </div>
                    </TableCell>
                  </tr>
                ))}

                {filteredDoctors.length === 0 && (
                  <tr>
                    <td
                      colSpan={11}
                      className="border border-slate-300 px-3 py-8 text-center text-sm text-slate-500"
                    >
                      No doctors found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

function TableHeader({ children }: { children: React.ReactNode }) {
  return (
    <th className="border border-slate-300 px-2 py-2 align-middle font-bold">
      {children}
    </th>
  );
}

function TableCell({ children }: { children: React.ReactNode }) {
  return (
    <td className="border border-slate-300 px-2 py-1.5 align-top">
      {children}
    </td>
  );
}
