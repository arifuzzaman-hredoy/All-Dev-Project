
"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Copy,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  Plus,
  RefreshCcw,
  Save,
  ShieldCheck,
  UserCog,
  UserPlus,
} from "lucide-react";

type AdminRole = "SUPER_ADMIN" | "ADMIN" | "EDITOR";

type AdminUserRow = {
  id: string;
  name: string | null;
  email: string;
  role: AdminRole;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type ApiListResponse = { ok: boolean; admins?: AdminUserRow[]; message?: string };
type ApiMutationResponse = { ok: boolean; message?: string; generatedPassword?: string | null };

const ROLE_OPTIONS: Array<{ value: AdminRole; label: string; help: string }> = [
  { value: "SUPER_ADMIN", label: "Super Admin", help: "Full access including admin users and security." },
  { value: "ADMIN", label: "Admin", help: "Can manage website content and requests." },
  { value: "EDITOR", label: "Editor", help: "Content/page editing role." },
];

const emptyForm = { name: "", email: "", role: "ADMIN" as AdminRole, password: "", isActive: true };

function formatDate(value: string | null) {
  if (!value) return "Never";
  return new Intl.DateTimeFormat("en-GB", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

export default function AdminUsersManager({ currentAdminEmail }: { currentAdminEmail: string }) {
  const [admins, setAdmins] = useState<AdminUserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [visiblePassword, setVisiblePassword] = useState(false);
  const [temporaryPassword, setTemporaryPassword] = useState<string | null>(null);

  const activeSuperAdminCount = useMemo(
    () => admins.filter((admin) => admin.role === "SUPER_ADMIN" && admin.isActive).length,
    [admins],
  );

  async function loadAdmins() {
    setLoading(true);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/users", { cache: "no-store" });
      const result = (await response.json()) as ApiListResponse;
      if (!response.ok || !result.ok) throw new Error(result.message || "Failed to load admin users.");
      setAdmins(result.admins || []);
    } catch (error) {
      setMessage({ type: "error", text: error instanceof Error ? error.message : "Failed to load admin users." });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadAdmins();
  }, []);

  async function handleCreate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setTemporaryPassword(null);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const result = (await response.json()) as ApiMutationResponse;
      if (!response.ok || !result.ok) throw new Error(result.message || "Failed to create admin user.");
      setMessage({ type: "success", text: result.message || "Admin user created." });
      if (result.generatedPassword) setTemporaryPassword(result.generatedPassword);
      setForm(emptyForm);
      await loadAdmins();
    } catch (error) {
      setMessage({ type: "error", text: error instanceof Error ? error.message : "Failed to create admin user." });
    } finally {
      setSaving(false);
    }
  }

  async function updateAdmin(admin: AdminUserRow, changes: Partial<Pick<AdminUserRow, "name" | "role" | "isActive">>) {
    setMessage(null);
    try {
      const response = await fetch(`/api/admin/users/${admin.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(changes),
      });
      const result = (await response.json()) as ApiMutationResponse;
      if (!response.ok || !result.ok) throw new Error(result.message || "Failed to update admin user.");
      setMessage({ type: "success", text: result.message || "Admin user updated." });
      await loadAdmins();
    } catch (error) {
      setMessage({ type: "error", text: error instanceof Error ? error.message : "Failed to update admin user." });
    }
  }

  async function deactivateAdmin(admin: AdminUserRow) {
    if (!window.confirm(`Deactivate ${admin.email}? This will end active sessions.`)) return;
    setMessage(null);
    try {
      const response = await fetch(`/api/admin/users/${admin.id}`, { method: "DELETE" });
      const result = (await response.json()) as ApiMutationResponse;
      if (!response.ok || !result.ok) throw new Error(result.message || "Failed to deactivate admin user.");
      setMessage({ type: "success", text: result.message || "Admin user deactivated." });
      await loadAdmins();
    } catch (error) {
      setMessage({ type: "error", text: error instanceof Error ? error.message : "Failed to deactivate admin user." });
    }
  }

  async function resetPassword(admin: AdminUserRow) {
    const customPassword = window.prompt(`New password for ${admin.email}. Leave blank to auto-generate a temporary password.`, "");
    if (customPassword === null) return;
    setMessage(null);
    setTemporaryPassword(null);
    try {
      const response = await fetch(`/api/admin/users/${admin.id}/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: customPassword.trim() }),
      });
      const result = (await response.json()) as ApiMutationResponse;
      if (!response.ok || !result.ok) throw new Error(result.message || "Failed to reset admin password.");
      setMessage({ type: "success", text: result.message || "Admin password updated." });
      if (result.generatedPassword) setTemporaryPassword(result.generatedPassword);
    } catch (error) {
      setMessage({ type: "error", text: error instanceof Error ? error.message : "Failed to reset admin password." });
    }
  }

  function copyTemporaryPassword() {
    if (!temporaryPassword) return;
    void navigator.clipboard.writeText(temporaryPassword);
    setMessage({ type: "success", text: "Temporary password copied." });
  }

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-[32px] bg-[#062f66] px-6 py-8 text-white shadow-[0_28px_65px_rgba(6,47,102,0.18)] sm:px-8 lg:px-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(91,192,222,0.22),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(140,198,63,0.16),transparent_34%)]" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <p className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-200">
              <ShieldCheck size={16} /> Super admin security
            </p>
            <h1 className="mt-3 text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">Admin users</h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base">
              Create, activate, deactivate, role-manage, and reset passwords for registered admin panel users. Forgot-password codes are sent to each registered admin email.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur"><p className="text-2xl font-black">{admins.length}</p><p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">admins</p></div>
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur"><p className="text-2xl font-black">{admins.filter((admin) => admin.isActive).length}</p><p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">active</p></div>
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur"><p className="text-2xl font-black">{activeSuperAdminCount}</p><p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">super admins</p></div>
          </div>
        </div>
      </section>

      {message ? (
        <div className={`flex items-start gap-3 rounded-3xl border px-5 py-4 text-sm font-semibold ${message.type === "success" ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-red-200 bg-red-50 text-red-700"}`}>
          {message.type === "success" ? <CheckCircle2 size={18} /> : <AlertTriangle size={18} />}
          <p>{message.text}</p>
        </div>
      ) : null}

      {temporaryPassword ? (
        <div className="rounded-[28px] border border-amber-200 bg-amber-50 p-5 text-amber-900 shadow-sm">
          <p className="flex items-center gap-2 text-sm font-black uppercase tracking-[0.16em]"><KeyRound size={16} /> Temporary password</p>
          <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center">
            <code className="flex-1 rounded-2xl bg-white px-4 py-3 font-mono text-sm font-bold text-slate-900 shadow-sm">{temporaryPassword}</code>
            <button type="button" onClick={copyTemporaryPassword} className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#062f66] px-4 py-3 text-sm font-black text-white transition hover:bg-[#0a4d8f]"><Copy size={16} /> Copy</button>
          </div>
          <p className="mt-3 text-xs font-semibold text-amber-800">Copy this now. It is not stored in plain text and will not be shown again.</p>
        </div>
      ) : null}

      <section className="grid gap-6 xl:grid-cols-[420px_1fr]">
        <form onSubmit={handleCreate} className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_18px_50px_rgba(15,23,42,0.06)]">
          <div className="mb-5 flex items-start justify-between gap-3"><div><p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-600"><UserPlus size={15} /> Create admin</p><h2 className="mt-1 text-xl font-black text-[#062f66]">Register admin user</h2></div><span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-blue-700">Super Admin only</span></div>
          <label className="mb-4 block"><span className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">Name</span><input value={form.name} onChange={(event) => setForm((value) => ({ ...value, name: event.target.value }))} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none transition focus:border-[#0a4d8f] focus:ring-4 focus:ring-blue-100" placeholder="Admin name" /></label>
          <label className="mb-4 block"><span className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">Email</span><input type="email" required value={form.email} onChange={(event) => setForm((value) => ({ ...value, email: event.target.value }))} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none transition focus:border-[#0a4d8f] focus:ring-4 focus:ring-blue-100" placeholder="admin@example.com" /></label>
          <label className="mb-4 block"><span className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">Role</span><select value={form.role} onChange={(event) => setForm((value) => ({ ...value, role: event.target.value as AdminRole }))} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm font-black outline-none transition focus:border-[#0a4d8f] focus:ring-4 focus:ring-blue-100">{ROLE_OPTIONS.map((role) => <option key={role.value} value={role.value}>{role.label}</option>)}</select><p className="mt-2 text-xs font-semibold leading-5 text-slate-500">{ROLE_OPTIONS.find((role) => role.value === form.role)?.help}</p></label>
          <label className="mb-4 block"><span className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">Password <span className="font-semibold normal-case text-slate-400">optional</span></span><div className="mt-2 flex overflow-hidden rounded-2xl border border-slate-200 bg-white focus-within:border-[#0a4d8f] focus-within:ring-4 focus-within:ring-blue-100"><input type={visiblePassword ? "text" : "password"} value={form.password} onChange={(event) => setForm((value) => ({ ...value, password: event.target.value }))} className="min-w-0 flex-1 px-4 py-3 text-sm font-semibold outline-none" placeholder="Leave blank to auto-generate" /><button type="button" onClick={() => setVisiblePassword((value) => !value)} className="px-4 text-slate-500 hover:text-[#062f66]" aria-label="Toggle password visibility">{visiblePassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div></label>
          <label className="mb-5 flex items-center gap-3 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-bold text-slate-700"><input type="checkbox" checked={form.isActive} onChange={(event) => setForm((value) => ({ ...value, isActive: event.target.checked }))} className="size-4" />Active user</label>
          <button type="submit" disabled={saving} className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-[#062f66] px-5 py-3 text-sm font-black text-white transition hover:bg-[#0a4d8f] disabled:cursor-not-allowed disabled:opacity-60">{saving ? <Loader2 size={17} className="animate-spin" /> : <Plus size={17} />}Create admin</button>
        </form>

        <section className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-[0_18px_50px_rgba(15,23,42,0.06)]">
          <div className="flex flex-col gap-3 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-600"><UserCog size={15} /> Registered admins</p><h2 className="mt-1 text-xl font-black text-[#062f66]">Admin panel access</h2></div><button type="button" onClick={loadAdmins} className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 px-4 py-2 text-xs font-black text-slate-700 transition hover:border-[#0a4d8f] hover:text-[#062f66]"><RefreshCcw size={14} /> Refresh</button></div>
          {loading ? <div className="flex items-center justify-center gap-3 px-5 py-12 text-sm font-bold text-slate-500"><Loader2 size={18} className="animate-spin" /> Loading admin users...</div> : (
            <div className="overflow-x-auto"><table className="min-w-[920px] w-full text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-[0.14em] text-slate-500"><tr><th className="px-5 py-4 font-black">Admin</th><th className="px-5 py-4 font-black">Role</th><th className="px-5 py-4 font-black">Status</th><th className="px-5 py-4 font-black">Last login</th><th className="px-5 py-4 font-black">Actions</th></tr></thead><tbody className="divide-y divide-slate-100">{admins.map((admin) => <tr key={admin.id} className="align-top hover:bg-slate-50/70"><td className="px-5 py-4"><p className="font-black text-[#062f66]">{admin.name || "Unnamed admin"}</p><p className="mt-1 text-xs font-semibold text-slate-500">{admin.email}</p>{admin.email === currentAdminEmail ? <span className="mt-2 inline-flex rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700">You</span> : null}</td><td className="px-5 py-4"><select value={admin.role} onChange={(event) => updateAdmin(admin, { role: event.target.value as AdminRole })} className="rounded-2xl border border-slate-200 px-3 py-2 text-xs font-black text-slate-700 outline-none focus:border-[#0a4d8f] focus:ring-4 focus:ring-blue-100">{ROLE_OPTIONS.map((role) => <option key={role.value} value={role.value}>{role.label}</option>)}</select></td><td className="px-5 py-4"><button type="button" onClick={() => updateAdmin(admin, { isActive: !admin.isActive })} className={`rounded-full px-3 py-1 text-xs font-black uppercase tracking-[0.08em] ${admin.isActive ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{admin.isActive ? "Active" : "Inactive"}</button></td><td className="whitespace-nowrap px-5 py-4 text-xs font-semibold text-slate-500">{formatDate(admin.lastLoginAt)}</td><td className="px-5 py-4"><div className="flex flex-wrap gap-2"><button type="button" onClick={() => resetPassword(admin)} className="inline-flex items-center gap-1.5 rounded-xl bg-blue-50 px-3 py-2 text-xs font-black text-blue-700 transition hover:bg-blue-100"><KeyRound size={14} /> Reset</button><button type="button" onClick={() => updateAdmin(admin, { name: window.prompt("Admin name", admin.name || "") || admin.name })} className="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 px-3 py-2 text-xs font-black text-slate-700 transition hover:bg-slate-200"><Save size={14} /> Name</button><button type="button" onClick={() => deactivateAdmin(admin)} disabled={!admin.isActive || admin.email === currentAdminEmail} className="inline-flex items-center gap-1.5 rounded-xl bg-red-50 px-3 py-2 text-xs font-black text-red-700 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-40">Deactivate</button></div>{admin.role === "SUPER_ADMIN" && admin.isActive && activeSuperAdminCount <= 1 ? <p className="mt-2 text-xs font-semibold text-amber-700">Last active Super Admin is protected.</p> : null}</td></tr>)}</tbody></table></div>
          )}
        </section>
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-5 text-sm text-slate-600 shadow-sm">
        <p className="font-black text-[#062f66]">Password reset email rule</p>
        <p className="mt-2 leading-7">Email is sent from the configured SMTP sender, for example techtemlead@gmail.com, but the recovery code is delivered to the registered admin user email stored in the AdminUser database table.</p>
      </section>
    </div>
  );
}
