"use client";

import Image from "next/image";
import { useMemo, useState } from "react";

import type {
  WhyChooseSection,
  WhyChooseSpeciality,
} from "@/types/home-why-choose";
import SpecialityCardEditor from "./SpecialityCardEditor";

type WhyChooseFormProps = {
  initialSection: WhyChooseSection;
};

function createId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }

  return `speciality-${Date.now()}`;
}

export default function WhyChooseForm({ initialSection }: WhyChooseFormProps) {
  const [section, setSection] = useState(initialSection);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [notice, setNotice] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const sortedSpecialities = useMemo(
    () =>
      [...section.specialities].sort(
        (left, right) => left.sortOrder - right.sortOrder,
      ),
    [section.specialities],
  );

  function updateSpeciality(nextSpeciality: WhyChooseSpeciality) {
    setNotice(null);
    setSection((current) => ({
      ...current,
      specialities: current.specialities.map((item) =>
        item.id === nextSpeciality.id ? nextSpeciality : item,
      ),
    }));
  }

  function addSpeciality() {
    const nextOrder =
      section.specialities.reduce(
        (highest, item) => Math.max(highest, item.sortOrder),
        0,
      ) + 1;

    setSection((current) => ({
      ...current,
      specialities: [
        ...current.specialities,
        {
          id: createId(),
          title: "New Speciality",
          iconName: "HeartPulse",
          isActive: true,
          sortOrder: nextOrder,
        },
      ],
    }));
  }

  function deleteSpeciality(id: string) {
    const confirmed = window.confirm("Delete this speciality card?");
    if (!confirmed) return;

    setSection((current) => ({
      ...current,
      specialities: current.specialities.filter((item) => item.id !== id),
    }));
  }

  async function uploadImage() {
    if (!imageFile) return section.imageUrl;

    const formData = new FormData();
    formData.append("file", imageFile);

    const response = await fetch("/api/admin/uploads", {
      method: "POST",
      body: formData,
    });
    const result = (await response.json()) as {
      ok?: boolean;
      url?: string;
      message?: string;
    };

    if (!response.ok || !result.ok || !result.url) {
      throw new Error(result.message || "Image upload failed.");
    }

    return result.url;
  }

  async function saveChanges() {
    setIsSaving(true);
    setNotice(null);

    try {
      const imageUrl = await uploadImage();
      const response = await fetch("/api/admin/home-why-choose", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...section, imageUrl }),
      });
      const result = (await response.json()) as {
        message?: string;
        section?: WhyChooseSection;
      };

      if (!response.ok || !result.section) {
        throw new Error(result.message || "Failed to update section.");
      }

      setSection(result.section);
      setImageFile(null);
      setNotice({
        type: "success",
        text: "Why Choose section updated successfully.",
      });
    } catch {
      setNotice({
        type: "error",
        text: "Failed to update section. Please try again.",
      });
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 border-b border-slate-200 pb-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-black text-[#062f66]">
            Why Choose Section
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Update homepage image, heading, description, and speciality cards.
          </p>
        </div>

        <button
          type="button"
          onClick={() => void saveChanges()}
          disabled={isSaving}
          className="h-10 rounded-md bg-slate-900 px-4 text-sm font-bold text-white transition hover:bg-[#062f66] disabled:cursor-not-allowed disabled:opacity-60"
        >
          {isSaving ? "Saving..." : "Save Changes"}
        </button>
      </div>

      {notice ? (
        <div
          className={`rounded-md border px-3 py-2 text-sm font-semibold ${
            notice.type === "success"
              ? "border-emerald-200 bg-emerald-50 text-emerald-700"
              : "border-red-200 bg-red-50 text-red-700"
          }`}
        >
          {notice.text}
        </div>
      ) : null}

      <section className="rounded-md border border-slate-300 bg-white p-4">
        <h2 className="text-base font-black text-[#062f66]">
          Section Content
        </h2>

        <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_280px]">
          <div className="space-y-3">
            <label className="block">
              <span className="mb-1 block text-xs font-bold text-slate-600">
                Section title
              </span>
              <input
                value={section.title}
                onChange={(event) =>
                  setSection((current) => ({
                    ...current,
                    title: event.target.value,
                  }))
                }
                className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-xs font-bold text-slate-600">
                Section description
              </span>
              <textarea
                value={section.description}
                onChange={(event) =>
                  setSection((current) => ({
                    ...current,
                    description: event.target.value,
                  }))
                }
                rows={6}
                className="w-full resize-none rounded-md border border-slate-300 px-3 py-2 text-sm leading-6 outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-xs font-bold text-slate-600">
                Main image URL
              </span>
              <input
                value={section.imageUrl}
                onChange={(event) =>
                  setSection((current) => ({
                    ...current,
                    imageUrl: event.target.value,
                  }))
                }
                className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
              />
            </label>

            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={(event) => setImageFile(event.target.files?.[0] || null)}
              className="block w-full text-sm text-slate-600 file:mr-3 file:rounded-md file:border-0 file:bg-slate-900 file:px-3 file:py-2 file:text-sm file:font-bold file:text-white"
            />
          </div>

          <div className="overflow-hidden rounded-md border border-slate-300 bg-slate-50">
            {section.imageUrl ? (
              <Image
                src={section.imageUrl}
                alt="Why choose preview"
                width={420}
                height={520}
                unoptimized
                className="h-full min-h-[240px] w-full object-cover"
              />
            ) : (
              <div className="flex min-h-[240px] items-center justify-center text-sm font-semibold text-slate-400">
                Image preview
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="rounded-md border border-slate-300 bg-white p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-base font-black text-[#062f66]">
              Speciality Cards
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Edit icons, titles, visibility, and order.
            </p>
          </div>

          <button
            type="button"
            onClick={addSpeciality}
            className="h-10 rounded-md border border-slate-300 px-4 text-sm font-bold text-slate-700 transition hover:bg-slate-50"
          >
            Add new card
          </button>
        </div>

        <div className="mt-4 space-y-3">
          {sortedSpecialities.map((speciality) => (
            <SpecialityCardEditor
              key={speciality.id}
              speciality={speciality}
              onChange={updateSpeciality}
              onDelete={() => deleteSpeciality(speciality.id)}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
