"use client";

import WhyChooseIcon from "@/components/home-why-choose/WhyChooseIcon";
import {
  WHY_CHOOSE_ICON_NAMES,
  type WhyChooseIconName,
} from "@/types/home-why-choose";

type IconPickerProps = {
  value: WhyChooseIconName;
  onChange: (value: WhyChooseIconName) => void;
};

export default function IconPicker({ value, onChange }: IconPickerProps) {
  return (
    <div className="grid gap-2 sm:grid-cols-[150px_1fr] sm:items-center">
      <div className="flex h-10 items-center gap-2 rounded-md border border-slate-300 bg-slate-50 px-3 text-sm font-semibold text-slate-700">
        <WhyChooseIcon name={value} size={18} />
        <span className="truncate">{value}</span>
      </div>

      <select
        value={value}
        onChange={(event) => onChange(event.target.value as WhyChooseIconName)}
        className="h-10 w-full rounded-md border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
      >
        {WHY_CHOOSE_ICON_NAMES.map((iconName) => (
          <option key={iconName} value={iconName}>
            {iconName}
          </option>
        ))}
      </select>
    </div>
  );
}
