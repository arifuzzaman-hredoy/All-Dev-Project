"use client";

import type {
  WhyChooseIconName,
  WhyChooseSpeciality,
} from "@/types/home-why-choose";
import IconPicker from "./IconPicker";

type SpecialityCardEditorProps = {
  speciality: WhyChooseSpeciality;
  onChange: (speciality: WhyChooseSpeciality) => void;
  onDelete: () => void;
};

export default function SpecialityCardEditor({
  speciality,
  onChange,
  onDelete,
}: SpecialityCardEditorProps) {
  return (
    <div className="rounded-md border border-slate-300 bg-white p-3">
      <div className="grid gap-3 lg:grid-cols-[1fr_220px_120px_120px_auto] lg:items-end">
        <label className="block">
          <span className="mb-1 block text-xs font-bold text-slate-600">
            Card title
          </span>
          <input
            value={speciality.title}
            onChange={(event) =>
              onChange({ ...speciality, title: event.target.value })
            }
            className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
          />
        </label>

        <label className="block">
          <span className="mb-1 block text-xs font-bold text-slate-600">
            Icon
          </span>
          <IconPicker
            value={speciality.iconName as WhyChooseIconName}
            onChange={(iconName) => onChange({ ...speciality, iconName })}
          />
        </label>

        <label className="block">
          <span className="mb-1 block text-xs font-bold text-slate-600">
            Sort order
          </span>
          <input
            type="number"
            value={speciality.sortOrder}
            onChange={(event) =>
              onChange({ ...speciality, sortOrder: Number(event.target.value) })
            }
            className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-[#062f66] focus:ring-2 focus:ring-[#062f66]/15"
          />
        </label>

        <label className="flex h-10 items-center gap-2 text-sm font-semibold text-slate-700">
          <input
            type="checkbox"
            checked={speciality.isActive}
            onChange={(event) =>
              onChange({ ...speciality, isActive: event.target.checked })
            }
            className="size-4 rounded border-slate-300"
          />
          Active
        </label>

        <button
          type="button"
          onClick={onDelete}
          className="h-10 rounded-md border border-red-200 px-3 text-sm font-bold text-red-600 transition hover:bg-red-50"
        >
          Delete
        </button>
      </div>
    </div>
  );
}
