"use client";

import * as React from "react";
import { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import AdminShell from "@/components/admin/AdminShell";

type AdminAuthGateProps = {
  children: React.ReactNode;
};

export default function AdminAuthGate({ children }: AdminAuthGateProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [authState, setAuthState] = React.useState<{
    status: "checking" | "authed" | "guest";
    pathname: string;
  }>({ status: "checking", pathname: "" });

  const isPublicAdminAuthPage =
    pathname === "/admin/login" || pathname.startsWith("/admin/forgot-password");

  useEffect(() => {
    let cancelled = false;

    async function checkSession() {
      if (isPublicAdminAuthPage) {
        setAuthState({ status: "guest", pathname });
        return;
      }

      setAuthState({ status: "checking", pathname });

      try {
        const response = await fetch("/api/admin/auth/me", {
          cache: "no-store",
        });
        const result = (await response.json()) as { authenticated?: boolean };

        if (!cancelled) {
          setAuthState({
            status: result.authenticated ? "authed" : "guest",
            pathname,
          });
        }
      } catch {
        if (!cancelled) setAuthState({ status: "guest", pathname });
      }
    }

    void checkSession();

    return () => {
      cancelled = true;
    };
  }, [isPublicAdminAuthPage, pathname]);

  useEffect(() => {
    const status =
      authState.pathname === pathname ? authState.status : "checking";

    if (status === "checking") return;

    if (status === "guest" && !isPublicAdminAuthPage) {
      router.replace("/admin/login");
      return;
    }

    if (status === "authed" && isPublicAdminAuthPage) {
      router.replace("/admin");
    }
  }, [authState, isPublicAdminAuthPage, pathname, router]);

  if (isPublicAdminAuthPage) {
    return <>{children}</>;
  }

  const status =
    authState.pathname === pathname ? authState.status : "checking";

  if (status !== "authed") {
    return null;
  }

  return <AdminShell>{children}</AdminShell>;
}
