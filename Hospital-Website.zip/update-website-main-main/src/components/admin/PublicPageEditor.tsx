import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";
import type { StaticPageKey } from "@/lib/static-pages";

type PublicPageEditorProps = {
  pageKey: "support" | "contact" | "legal" | "privacy-policy" | "terms";
};

function resolvePageKey(pageKey: PublicPageEditorProps["pageKey"]): StaticPageKey {
  if (pageKey === "legal") return "privacy-policy";
  return pageKey;
}

export default function PublicPageEditor({ pageKey }: PublicPageEditorProps) {
  return <StaticPageAdminPage pageKey={resolvePageKey(pageKey)} />;
}
