"use client";

import { Menu, X } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import {
  adminNavGroups,
  adminSidebarLabels,
} from "@/components/admin/admin-sidebar-customization";
import { useRouter } from "next/navigation";
import AdminSidebar from "@/components/admin/AdminSidebar";
import CraftedBySignature from "@/components/brand/CraftedBySignature";
import { clearAdminSession } from "@/lib/admin-session";

type AdminShellProps = {
  children: React.ReactNode;
};

function isRouteActive(pathname: string, href: string) {
  if (href === "/admin") return pathname === "/admin";
  return pathname === href || pathname.startsWith(`${href}/`);
}

export default function AdminShell({ children }: AdminShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [pendingHref, setPendingHref] = useState<string | null>(null);
  const routePending = pendingHref !== null && pendingHref !== pathname;

  useEffect(() => {
    if (!routePending) return;

    const timeout = window.setTimeout(() => {
      setPendingHref(null);
    }, 3500);

    return () => window.clearTimeout(timeout);
  }, [routePending]);

  useEffect(() => {
    document.body.style.overflow = mobileMenuOpen ? "hidden" : "";

    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen]);

  function handleLogout() {
    void clearAdminSession();
    router.replace("/admin/login");
  }

  function handleAdminNavigateStart(href: string) {
    if (href !== pathname) setPendingHref(href);
  }

  const currentTitle = useMemo(() => {
    if (pathname === "/admin") return "Dashboard";

    for (const group of adminNavGroups) {
      for (const item of group.items) {
        if (isRouteActive(pathname, item.href)) return item.label;
      }
    }

    return adminSidebarLabels.fallbackTitle;
  }, [pathname]);

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fbff_0%,#eef5ff_48%,#ffffff_100%)] text-slate-900 xl:[--admin-sidebar-width:292px]">
      <div className="mx-auto min-h-screen w-full max-w-[1900px] transition-[padding] duration-300 ease-out xl:pl-[var(--admin-sidebar-width)]">
        <div
          aria-hidden={!routePending}
          className="fixed inset-x-0 top-0 z-[70] h-0.5 overflow-hidden bg-transparent"
        >
          <div
            className={`h-full origin-left bg-[linear-gradient(90deg,#8cc63f,#0a4d8f,#062f66)] shadow-[0_0_18px_rgba(10,77,143,0.28)] transition-transform duration-500 ease-out ${
              routePending ? "scale-x-100" : "scale-x-0"
            }`}
          />
        </div>

        <AdminSidebar
          pathname={pathname}
          mobileMenuOpen={mobileMenuOpen}
          onCloseMobileMenu={() => setMobileMenuOpen(false)}
          onNavigateStart={handleAdminNavigateStart}
          onLogout={handleLogout}
        />

        <div className="flex min-h-screen flex-col">
          <header className="sticky top-0 z-20 border-b border-slate-200/80 bg-white/90 backdrop-blur">
            <div className="flex items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8 xl:px-10">
              <div className="flex min-w-0 items-center gap-3">
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(true)}
                  className="inline-flex size-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:border-[#c8dcff] hover:text-[#062f66] xl:hidden"
                  aria-label="Open admin navigation"
                >
                  <Menu size={20} />
                </button>

                <div className="min-w-0">
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">
                    {adminSidebarLabels.workspace}
                  </p>
                  <h1 className="truncate text-lg font-bold text-[#062f66] sm:text-xl">
                    {currentTitle}
                  </h1>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen((value) => !value)}
                  className="inline-flex size-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:border-[#c8dcff] hover:text-[#062f66] xl:hidden"
                  aria-label="Toggle admin navigation"
                >
                  {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
                </button>
              </div>
            </div>
          </header>

          <main
            className={`flex-1 px-4 py-5 transition-opacity duration-200 sm:px-6 sm:py-6 lg:px-8 lg:py-8 xl:px-10 ${
              routePending ? "opacity-80" : "opacity-100"
            }`}
          >
            {children}
          </main>
          <CraftedBySignature variant="admin" />
        </div>
      </div>
    </div>
  );
}
