import { notFound } from "next/navigation";

import SectionEditor from "@/components/admin/SectionEditor";
import { getAdminSectionPreset } from "@/data/admin-section-presets";
import HomeHeroEditor from "@/features/admin/home-hero/components/HomeHeroEditor";
import { getHomeHeroContent } from "@/lib/home-hero-db";

type AdminPresetPageProps = {
  presetKey: string;
};

export default async function AdminPresetPage({
  presetKey,
}: AdminPresetPageProps) {
  const preset = getAdminSectionPreset(presetKey);

  if (!preset) {
    notFound();
  }

  if (preset.editor === "homeHero") {
    const content = await getHomeHeroContent();
    return <HomeHeroEditor initialContent={content} />;
  }

  return <SectionEditor {...preset} />;
}
