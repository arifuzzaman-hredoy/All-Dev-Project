"use client";

import { useMemo, useState } from "react";
import clsx from "clsx";
import { Copy, RotateCcw } from "lucide-react";

export type EditorField = {
  key: string;
  label: string;
  type: "text" | "textarea" | "list";
  placeholder?: string;
  helperText?: string;
  rows?: number;
};

export type SectionEditorPreset = {
  title: string;
  description: string;
  routeLabel: string;
  editor?: "default" | "homeHero";
  fields: EditorField[];
  initialValues: Record<string, string | string[]>;
};

function normalizeValue(value: string | string[] | undefined) {
  if (Array.isArray(value)) return value.join("\n");
  if (typeof value === "string") return value;
  return "";
}

function parseValue(value: string, type: EditorField["type"]) {
  if (type === "list") {
    return value
      .split("\n")
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return value;
}

export default function SectionEditor({
  title,
  description,
  routeLabel,
  fields,
  initialValues,
}: SectionEditorPreset) {
  const [draft, setDraft] = useState<Record<string, string>>(() => {
    return fields.reduce<Record<string, string>>((accumulator, field) => {
      accumulator[field.key] = normalizeValue(initialValues[field.key]);
      return accumulator;
    }, {});
  });
  const [copied, setCopied] = useState(false);

  const snapshot = useMemo(() => {
    return fields.reduce<Record<string, string | string[]>>(
      (accumulator, field) => {
        accumulator[field.key] = parseValue(draft[field.key] ?? "", field.type);
        return accumulator;
      },
      {},
    );
  }, [draft, fields]);

  async function handleCopy() {
    await navigator.clipboard.writeText(JSON.stringify(snapshot, null, 2));
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  }

  function handleReset() {
    setDraft(
      fields.reduce<Record<string, string>>((accumulator, field) => {
        accumulator[field.key] = normalizeValue(initialValues[field.key]);
        return accumulator;
      }, {}),
    );
  }

  return (
    <section className="grid gap-6 xl:grid-cols-[minmax(0,1.25fr)_380px]">
      <div className="space-y-6">
        <div className="rounded-[28px] border border-[#dbe8ff] bg-white p-5 shadow-[0_18px_50px_rgba(6,47,102,0.06)] sm:p-7">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">
            {routeLabel}
          </p>
          <h2 className="mt-2 text-2xl font-bold text-[#062f66] sm:text-3xl">
            {title}
          </h2>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-600 sm:text-base">
            {description}
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <button
              type="button"
              onClick={handleCopy}
              className={clsx(
                "inline-flex w-full items-center justify-center gap-2 rounded-full px-4 py-3 text-sm font-semibold transition sm:w-auto sm:py-2",
                copied
                  ? "bg-emerald-600 text-white"
                  : "bg-[#062f66] text-white hover:bg-[#0c4b95]",
              )}
            >
              <Copy size={16} />
              {copied ? "Copied snapshot" : "Copy snapshot"}
            </button>
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:border-[#c8dcff] hover:text-[#062f66] sm:w-auto sm:py-2"
            >
              <RotateCcw size={16} />
              Reset draft
            </button>
          </div>
        </div>

        <div className="grid gap-4">
          {fields.map((field) => {
            const value = draft[field.key] ?? "";

            return (
              <label
                key={field.key}
                className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6"
              >
                <span className="block text-sm font-bold text-[#062f66]">
                  {field.label}
                </span>
                {field.helperText ? (
                  <span className="mt-2 block text-xs leading-5 text-slate-500">
                    {field.helperText}
                  </span>
                ) : null}
                {field.type === "textarea" || field.type === "list" ? (
                  <textarea
                    value={value}
                    onChange={(event) =>
                      setDraft((current) => ({
                        ...current,
                        [field.key]: event.target.value,
                      }))
                    }
                    rows={field.rows ?? (field.type === "list" ? 7 : 5)}
                    placeholder={field.placeholder}
                    className="mt-4 min-h-32 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-7 text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-[#8cc63f] focus:bg-white"
                  />
                ) : (
                  <input
                    value={value}
                    onChange={(event) =>
                      setDraft((current) => ({
                        ...current,
                        [field.key]: event.target.value,
                      }))
                    }
                    placeholder={field.placeholder}
                    className="mt-4 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-[#8cc63f] focus:bg-white"
                  />
                )}
              </label>
            );
          })}
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-[26px] border border-[#dbe8ff] bg-[#062f66] p-5 text-white shadow-[0_18px_45px_rgba(6,47,102,0.16)]">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-cyan-200">
            Draft preview
          </p>
          <pre className="mt-4 overflow-auto rounded-2xl bg-white/10 p-4 text-xs leading-6 text-cyan-50 sm:p-5">
            {JSON.stringify(snapshot, null, 2)}
          </pre>
        </div>

        <div className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)]">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">
            Editing note
          </p>
          <p className="mt-3 text-sm leading-7 text-slate-600">
            This editor is intentionally simple: change the copy, copy the JSON
            snapshot, then paste the values into the matching public section.
          </p>
        </div>
      </aside>
    </section>
  );
}
