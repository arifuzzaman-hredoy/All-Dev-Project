"use client";

import { useMemo, useState } from "react";
import { Eye, EyeOff, RotateCcw, Save } from "lucide-react";
import type {
  HomeSectionTeaserConfig,
  HomeSectionTeaserKey,
} from "@/lib/home-section-teaser-types";

type HomeSectionTeaserEditorProps = {
  sectionKey: HomeSectionTeaserKey;
  initialSection: HomeSectionTeaserConfig;
  routeLabel: string;
  editorTitle: string;
  editorDescription: string;
};

function toDraft(section: HomeSectionTeaserConfig) {
  return {
    eyebrow: section.eyebrow,
    title: section.title,
    description: section.description,
    buttonLabel: section.buttonLabel,
    buttonHref: section.buttonHref,
    limit: String(section.limit),
    isActive: section.isActive,
  };
}

export default function HomeSectionTeaserEditor({
  sectionKey,
  initialSection,
  routeLabel,
  editorTitle,
  editorDescription,
}: HomeSectionTeaserEditorProps) {
  const [draft, setDraft] = useState(() => toDraft(initialSection));
  const [status, setStatus] = useState<string>("");
  const [isSaving, setIsSaving] = useState(false);

  const preview = useMemo<HomeSectionTeaserConfig>(() => {
    const limitValue = Number(draft.limit);
    return {
      key: sectionKey,
      eyebrow: draft.eyebrow.trim(),
      title: draft.title.trim(),
      description: draft.description.trim(),
      buttonLabel: draft.buttonLabel.trim(),
      buttonHref: draft.buttonHref.trim() || "/",
      limit: Number.isFinite(limitValue)
        ? Math.min(12, Math.max(1, Math.round(limitValue)))
        : initialSection.limit,
      isActive: draft.isActive,
    };
  }, [draft, initialSection.limit, sectionKey]);

  async function saveSection(payload = preview) {
    setIsSaving(true);
    setStatus("Saving...");

    try {
      const response = await fetch(`/api/admin/home-section-teasers/${sectionKey}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = (await response.json().catch(() => null)) as {
        section?: HomeSectionTeaserConfig;
        message?: string;
      } | null;

      if (!response.ok || !data?.section) {
        throw new Error(data?.message || "Unable to save section.");
      }

      setDraft(toDraft(data.section));
      window.dispatchEvent(new CustomEvent("home-section-teasers-updated"));
      setStatus("Saved to database.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Unable to save section.");
    } finally {
      setIsSaving(false);
    }
  }

  async function resetSection() {
    if (!confirm("Reset this homepage section copy to default?")) return;

    setIsSaving(true);
    setStatus("Resetting...");

    try {
      const response = await fetch(`/api/admin/home-section-teasers/${sectionKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reset" }),
      });

      const data = (await response.json().catch(() => null)) as {
        section?: HomeSectionTeaserConfig;
        message?: string;
      } | null;

      if (!response.ok || !data?.section) {
        throw new Error(data?.message || "Unable to reset section.");
      }

      setDraft(toDraft(data.section));
      window.dispatchEvent(new CustomEvent("home-section-teasers-updated"));
      setStatus("Reset and saved to database.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Unable to reset section.");
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <section className="grid gap-6 xl:grid-cols-[minmax(0,1.1fr)_420px]">
      <div className="space-y-6">
        <div className="rounded-[28px] border border-[#dbe8ff] bg-white p-5 shadow-[0_18px_50px_rgba(6,47,102,0.06)] sm:p-7">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">
            {routeLabel}
          </p>
          <h2 className="mt-2 text-2xl font-bold text-[#062f66] sm:text-3xl">
            {editorTitle}
          </h2>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-600 sm:text-base">
            {editorDescription}
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <button
              type="button"
              onClick={() => void saveSection()}
              disabled={isSaving}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 py-3 text-sm font-black text-white transition hover:bg-[#0c4b95] disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
            >
              <Save size={17} />
              {isSaving ? "Saving..." : "Save to DB"}
            </button>
            <button
              type="button"
              onClick={resetSection}
              disabled={isSaving}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-700 transition hover:border-[#c8dcff] hover:text-[#062f66] disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
            >
              <RotateCcw size={17} />
              Reset default
            </button>
            <button
              type="button"
              onClick={() => setDraft((current) => ({ ...current, isActive: !current.isActive }))}
              disabled={isSaving}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-700 transition hover:border-[#8cc63f] hover:text-[#062f66] disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
            >
              {draft.isActive ? <Eye size={17} /> : <EyeOff size={17} />}
              {draft.isActive ? "Visible" : "Hidden"}
            </button>
          </div>

          {status ? (
            <p className="mt-4 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-600">
              {status}
            </p>
          ) : null}
        </div>

        <div className="grid gap-4">
          <label className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
            <span className="block text-sm font-bold text-[#062f66]">Eyebrow</span>
            <input
              value={draft.eyebrow}
              onChange={(event) => setDraft((current) => ({ ...current, eyebrow: event.target.value }))}
              className="mt-4 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-[#8cc63f] focus:bg-white"
            />
          </label>

          <label className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
            <span className="block text-sm font-bold text-[#062f66]">Title</span>
            <textarea
              value={draft.title}
              onChange={(event) => setDraft((current) => ({ ...current, title: event.target.value }))}
              rows={3}
              className="mt-4 min-h-24 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-7 text-slate-700 outline-none transition focus:border-[#8cc63f] focus:bg-white"
            />
          </label>

          <label className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
            <span className="block text-sm font-bold text-[#062f66]">Description</span>
            <textarea
              value={draft.description}
              onChange={(event) => setDraft((current) => ({ ...current, description: event.target.value }))}
              rows={4}
              className="mt-4 min-h-28 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-7 text-slate-700 outline-none transition focus:border-[#8cc63f] focus:bg-white"
            />
          </label>

          <div className="grid gap-4 lg:grid-cols-3">
            <label className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
              <span className="block text-sm font-bold text-[#062f66]">Button label</span>
              <input
                value={draft.buttonLabel}
                onChange={(event) => setDraft((current) => ({ ...current, buttonLabel: event.target.value }))}
                className="mt-4 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-[#8cc63f] focus:bg-white"
              />
            </label>

            <label className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
              <span className="block text-sm font-bold text-[#062f66]">Button link</span>
              <input
                value={draft.buttonHref}
                onChange={(event) => setDraft((current) => ({ ...current, buttonHref: event.target.value }))}
                className="mt-4 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-[#8cc63f] focus:bg-white"
              />
            </label>

            <label className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
              <span className="block text-sm font-bold text-[#062f66]">Card limit</span>
              <input
                type="number"
                min={1}
                max={12}
                value={draft.limit}
                onChange={(event) => setDraft((current) => ({ ...current, limit: event.target.value }))}
                className="mt-4 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-[#8cc63f] focus:bg-white"
              />
            </label>
          </div>
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-[26px] border border-[#dbe8ff] bg-[#062f66] p-5 text-white shadow-[0_18px_45px_rgba(6,47,102,0.16)]">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-cyan-200">
            Live DB preview
          </p>
          <pre className="mt-4 overflow-auto rounded-2xl bg-white/10 p-4 text-xs leading-6 text-cyan-50 sm:p-5">
            {JSON.stringify(preview, null, 2)}
          </pre>
        </div>

        <div className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)]">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">
            This is real CMS now
          </p>
          <p className="mt-3 text-sm leading-7 text-slate-600">
            Save করলে data SiteSetting table-এ যাবে। Homepage refresh করলে same
            browser না, অন্য browser থেকেও update দেখা যাবে।
          </p>
        </div>
      </aside>
    </section>
  );
}
