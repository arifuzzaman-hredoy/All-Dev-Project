"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  KeyRound,
  ShieldCheck,
  ShieldQuestion,
  Stethoscope,
} from "lucide-react";
import CraftedBySignature from "@/components/brand/CraftedBySignature";

const RESET_EMAIL_KEY = "admin_reset_email";
const RESET_CODE_KEY = "admin_reset_code";
const RESET_TOKEN_KEY = "admin_reset_token";

type VerifyResult = {
  ok?: boolean;
  message?: string;
  resetToken?: string;
};

const trustItems = [
  "Short-lived reset code",
  "Attempt limit protection",
  "Reset token after verify",
  "Audit trail recorded",
];

export default function VerifyPasswordResetPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const savedEmail = window.sessionStorage.getItem(RESET_EMAIL_KEY) || "";
    const savedCode = window.sessionStorage.getItem(RESET_CODE_KEY) || "";
    setEmail(savedEmail);
    setCode(savedCode);
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setNotice("");

    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = code.replace(/\D/g, "").slice(0, 6);

    if (!cleanEmail || !cleanCode) {
      setError("Admin email and recovery code are required.");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/admin/auth/password-reset/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: cleanEmail, code: cleanCode }),
      });
      const result = (await response.json().catch(() => null)) as VerifyResult | null;

      if (!response.ok || !result?.ok || !result.resetToken) {
        throw new Error(result?.message || "Code verification failed.");
      }

      window.sessionStorage.setItem(RESET_EMAIL_KEY, cleanEmail);
      window.sessionStorage.setItem(RESET_CODE_KEY, cleanCode);
      window.sessionStorage.setItem(RESET_TOKEN_KEY, result.resetToken);
      setNotice("Recovery code verified. Continue to set a new password.");
      router.push("/admin/forgot-password/reset");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Code verification failed.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="relative min-h-dvh overflow-hidden bg-[#eef6ff] px-4 py-6 text-slate-950 sm:px-6 lg:px-8">
      <div className="pointer-events-none absolute left-[-14rem] top-[-16rem] h-[36rem] w-[36rem] rounded-full bg-cyan-300/20 blur-3xl" />
      <div className="pointer-events-none absolute right-[-18rem] top-[6rem] h-[42rem] w-[42rem] rounded-full bg-blue-400/18 blur-3xl" />

      <div className="relative mx-auto grid min-h-[calc(100dvh-3rem)] w-full max-w-7xl items-center gap-6 lg:grid-cols-[1.08fr_0.92fr]">
        <section className="relative hidden overflow-hidden rounded-[32px] border border-white/70 bg-[#062f66] p-9 text-white shadow-[0_28px_76px_rgba(6,47,102,0.20)] lg:block">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_8%,rgba(103,232,249,0.22),transparent_30%),linear-gradient(135deg,rgba(255,255,255,0.10),transparent_45%)]" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.07] px-4 py-2 text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-100">
              <ShieldQuestion size={15} />
              Code verification
            </div>
            <div className="mt-8 max-w-3xl">
              <div className="mb-5 flex items-center gap-3 text-cyan-100">
                <Stethoscope size={26} />
                <span className="text-sm font-bold uppercase tracking-[0.22em]">
                  Update Diagnostic Center
                </span>
              </div>
              <h1 className="text-5xl font-black leading-[1.05] tracking-[-0.045em] xl:text-6xl">
                Verify the recovery code securely.
              </h1>
              <p className="mt-5 max-w-2xl text-base leading-8 text-blue-50/90 xl:text-lg">
                The code is checked against the database. After verification, a separate reset token
                is created for the password update step.
              </p>
            </div>
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {trustItems.map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-3 rounded-3xl border border-white/12 bg-white/[0.065] p-4 text-sm font-semibold text-blue-50"
                >
                  <BadgeCheck size={17} className="text-cyan-100" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[590px] rounded-[32px] border border-white/80 bg-white p-5 shadow-[0_28px_76px_rgba(15,23,42,0.09)] sm:p-7 lg:p-9">
          <div className="mb-7 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <ShieldCheck className="text-[#062f66]" size={30} />
              <div>
                <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-600">
                  Verification
                </p>
                <h2 className="mt-1 text-3xl font-black tracking-[-0.04em] text-[#062f66] sm:text-4xl">
                  Enter code
                </h2>
              </div>
            </div>
            <Link
              href="/admin/forgot-password"
              className="hidden items-center gap-1.5 rounded-full border border-slate-200 px-4 py-2 text-sm font-bold text-slate-600 transition hover:bg-blue-50 hover:text-[#0b5bd3] sm:inline-flex"
            >
              <ArrowLeft size={16} /> Back
            </Link>
          </div>

          <form onSubmit={handleSubmit} className="grid gap-4">
            <label className="grid gap-2">
              <span className="text-sm font-bold text-slate-700">Admin email</span>
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                type="email"
                autoComplete="email"
                placeholder="admin@example.com"
                className="h-[56px] rounded-2xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-900 outline-none transition focus:border-[#1a73e8] focus:ring-4 focus:ring-[#1a73e8]/10"
              />
            </label>

            <label className="grid gap-2">
              <span className="text-sm font-bold text-slate-700">Recovery code</span>
              <div className="flex h-[56px] items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 focus-within:border-[#1a73e8] focus-within:ring-4 focus-within:ring-[#1a73e8]/10">
                <KeyRound size={18} className="text-slate-400" />
                <input
                  value={code}
                  onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))}
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  placeholder="6 digit code"
                  className="w-full bg-transparent font-mono text-xl font-black tracking-[0.25em] text-slate-900 outline-none placeholder:text-sm placeholder:font-semibold placeholder:tracking-normal placeholder:text-slate-400"
                />
              </div>
            </label>

            {error ? (
              <p className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
                {error}
              </p>
            ) : null}
            {notice ? (
              <p className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
                {notice}
              </p>
            ) : null}

            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 text-sm font-black text-white transition hover:bg-[#0b428b] disabled:cursor-not-allowed disabled:opacity-70"
            >
              {isSubmitting ? "Verifying..." : "Verify code"}
              <ArrowRight size={16} />
            </button>
          </form>

          <CraftedBySignature variant="login" />
        </section>
      </div>
    </main>
  );
}
