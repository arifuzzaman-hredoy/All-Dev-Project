"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import clsx from "clsx";
import type { LucideIcon } from "lucide-react";
import {
  ChevronRight,
  ExternalLink,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  X,
} from "lucide-react";
import { adminNavGroups } from "@/data/admin-navigation";

let desktopSidebarScrollTop = 0;
let desktopSidebarCollapsed = false;

const SIDEBAR_EXPANDED_WIDTH = "292px";
const SIDEBAR_COLLAPSED_WIDTH = "82px";
const SIDEBAR_COLLAPSED_KEY = "update_admin_sidebar_collapsed";

type AdminSidebarProps = {
  pathname: string;
  mobileMenuOpen: boolean;
  onCloseMobileMenu: () => void;
  onNavigateStart: (href: string) => void;
  onLogout: () => void;
};

function isRouteActive(pathname: string, href: string) {
  if (href === "/admin") return pathname === "/admin";
  return pathname === href || pathname.startsWith(`${href}/`);
}

function applySidebarWidth(collapsed: boolean) {
  if (typeof document === "undefined") return;

  document.documentElement.style.setProperty(
    "--admin-sidebar-width",
    collapsed ? SIDEBAR_COLLAPSED_WIDTH : SIDEBAR_EXPANDED_WIDTH,
  );
}

function getSavedSidebarCollapsed() {
  if (typeof window === "undefined") return desktopSidebarCollapsed;

  const saved = window.localStorage.getItem(SIDEBAR_COLLAPSED_KEY);
  return saved === "true";
}

function saveSidebarCollapsed(collapsed: boolean) {
  desktopSidebarCollapsed = collapsed;
  applySidebarWidth(collapsed);

  if (typeof window !== "undefined") {
    window.localStorage.setItem(SIDEBAR_COLLAPSED_KEY, String(collapsed));
  }
}

function NavItem({
  href,
  label,
  description,
  icon: Icon,
  active,
  collapsed,
  onNavigate,
}: {
  href: string;
  label: string;
  description: string;
  icon: LucideIcon;
  active: boolean;
  collapsed: boolean;
  onNavigate: (href: string) => void;
}) {
  const [pressed, setPressed] = useState(false);

  function releasePress() {
    setPressed(false);
  }

  return (
    <Link
      href={href}
      title={collapsed ? label : undefined}
      aria-label={collapsed ? label : undefined}
      prefetch
      onClick={(event) => {
        if (
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey ||
          event.button !== 0
        ) {
          return;
        }

        onNavigate(href);
      }}
      onPointerDown={() => setPressed(true)}
      onPointerUp={releasePress}
      onPointerCancel={releasePress}
      onPointerLeave={releasePress}
      onBlur={releasePress}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          setPressed(true);
        }
      }}
      onKeyUp={releasePress}
      aria-current={active ? "page" : undefined}
      className={clsx(
        "group relative flex min-h-[42px] items-center overflow-hidden rounded-xl transition-all duration-200 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8cc63f]/60",
        collapsed ? "justify-center px-2 py-2" : "gap-2.5 px-3 py-2",
        collapsed
          ? active
            ? "text-[#062f66]"
            : "text-slate-400 hover:text-[#062f66]"
          : active
            ? "bg-white text-[#062f66] shadow-[0_14px_34px_rgba(6,47,102,0.12)] ring-1 ring-[#dbe8ff]"
            : "text-slate-500 hover:bg-white/75 hover:text-[#062f66] hover:shadow-[0_8px_22px_rgba(15,23,42,0.05)]",
        pressed &&
          (collapsed
            ? "scale-95 text-[#062f66]"
            : "translate-y-px scale-[0.985] bg-white shadow-[inset_0_2px_8px_rgba(15,23,42,0.10)]"),
      )}
    >
      <span
        className={clsx(
          "pointer-events-none absolute left-0 top-1/2 w-1 -translate-y-1/2 rounded-r-full transition-all duration-200",
          active
            ? "h-6 bg-[#8cc63f] opacity-100"
            : "h-4 bg-[#8cc63f]/0 opacity-0 group-hover:bg-[#8cc63f]/45 group-hover:opacity-100",
        )}
      />

      {!collapsed ? (
        <span
          className={clsx(
            "pointer-events-none absolute inset-0 rounded-xl transition-all duration-200",
            active
              ? "bg-[linear-gradient(90deg,rgba(140,198,63,0.10),rgba(255,255,255,0)_62%)]"
              : pressed
                ? "bg-slate-900/[0.025]"
                : "bg-transparent",
          )}
        />
      ) : null}

      <Icon
        size={collapsed ? 20 : 17}
        strokeWidth={active ? 2.6 : 2.15}
        className={clsx(
          "relative z-10 shrink-0 transition-all duration-200",
          active
            ? "scale-105 text-[#062f66]"
            : "text-slate-400 group-hover:text-[#062f66]",
        )}
      />

      {!collapsed ? (
        <>
          <span className="relative z-10 min-w-0 flex-1">
            <span
              className={clsx(
                "block truncate text-[12.5px] leading-5 transition-colors",
                active ? "font-black text-[#062f66]" : "font-extrabold",
              )}
            >
              {label}
            </span>

            <span
              className={clsx(
                "mt-0.5 block truncate text-[10.5px] font-medium leading-4 transition-colors",
                active ? "text-slate-500" : "text-slate-400",
              )}
            >
              {description}
            </span>
          </span>

          {active ? (
            <span className="relative z-10 size-1.5 shrink-0 rounded-full bg-[#8cc63f] shadow-[0_0_0_4px_rgba(140,198,63,0.13)]" />
          ) : (
            <ChevronRight
              size={14}
              className="relative z-10 shrink-0 text-slate-300 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-[#062f66]"
            />
          )}
        </>
      ) : null}
    </Link>
  );
}

function SidebarHeader({
  collapsed,
  onToggleCollapse,
}: {
  collapsed: boolean;
  onToggleCollapse: () => void;
}) {
  return (
    <div
      className={clsx(
        "flex items-center gap-3",
        collapsed ? "justify-center" : "justify-between",
      )}
    >
      <Link
        href="/admin"
        className={clsx(
          "flex min-w-0 items-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8cc63f]/70",
          collapsed ? "justify-center" : "justify-start",
        )}
        title="Update Diagnostic Center"
      >
        <Image
          src="/update.png"
          alt="Update Diagnostic Center"
          width={883}
          height={491}
          priority
          className={clsx(
            "h-auto object-contain transition-all duration-300",
            collapsed ? "max-h-10 w-11 max-w-11" : "max-h-14 w-auto max-w-[190px]",
          )}
        />
      </Link>

      {!collapsed ? (
        <button
          type="button"
          onClick={onToggleCollapse}
          title="Collapse sidebar"
          className="shrink-0 text-slate-400 transition hover:text-[#062f66] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8cc63f]/70"
          aria-label="Collapse sidebar"
        >
          <PanelLeftClose size={20} />
        </button>
      ) : null}
    </div>
  );
}

function CollapsedToggleButton({
  onToggleCollapse,
}: {
  onToggleCollapse: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggleCollapse}
      title="Expand sidebar"
      className="mx-auto mt-4 block text-slate-400 transition hover:scale-105 hover:text-[#062f66] active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8cc63f]/70"
      aria-label="Expand sidebar"
    >
      <PanelLeftOpen size={20} />
    </button>
  );
}

function MobileSidebarHeader({
  onCloseMobileMenu,
}: {
  onCloseMobileMenu: () => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <Link
        href="/admin"
        onClick={onCloseMobileMenu}
        className="flex min-w-0 items-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8cc63f]/70"
        title="Update Diagnostic Center"
      >
        <Image
          src="/update.png"
          alt="Update Diagnostic Center"
          width={883}
          height={491}
          priority
          className="h-auto max-h-14 w-auto max-w-[190px] object-contain"
        />
      </Link>

      <button
        type="button"
        onClick={onCloseMobileMenu}
        className="text-slate-500 transition hover:text-[#062f66] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8cc63f]/70"
        aria-label="Close admin navigation"
      >
        <X size={21} />
      </button>
    </div>
  );
}

function SidebarFooterAction({
  href,
  icon: Icon,
  label,
  collapsed,
  danger = false,
  onClick,
}: {
  href?: string;
  icon: LucideIcon;
  label: string;
  collapsed: boolean;
  danger?: boolean;
  onClick?: () => void;
}) {
  const className = clsx(
    "group flex min-h-[42px] items-center rounded-xl text-sm font-extrabold transition-all duration-200 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8cc63f]/60 active:scale-[0.985]",
    collapsed ? "justify-center px-2 py-2" : "gap-2.5 px-3 py-2",
    collapsed
      ? danger
        ? "text-slate-400 hover:text-red-600"
        : "text-slate-400 hover:text-[#062f66]"
      : danger
        ? "text-slate-500 hover:bg-red-50 hover:text-red-600"
        : "text-slate-500 hover:bg-white hover:text-[#062f66] hover:shadow-[0_8px_22px_rgba(15,23,42,0.05)]",
  );

  const content = (
    <>
      <Icon
        size={collapsed ? 20 : 17}
        strokeWidth={2.2}
        className="shrink-0 transition-transform duration-200 group-hover:scale-105"
      />
      {!collapsed ? <span className="truncate text-[12.5px]">{label}</span> : null}
    </>
  );

  if (href) {
    return (
      <Link
        href={href}
        title={collapsed ? label : undefined}
        prefetch
        className={className}
      >
        {content}
      </Link>
    );
  }

  return (
    <button
      type="button"
      title={collapsed ? label : undefined}
      onClick={onClick}
      className={clsx(className, "w-full")}
    >
      {content}
    </button>
  );
}

function DesktopSidebar({
  pathname,
  onCloseMobileMenu,
  onNavigateStart,
  onLogout,
}: Omit<AdminSidebarProps, "mobileMenuOpen">) {
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const [collapsed, setCollapsed] = useState(desktopSidebarCollapsed);

  useEffect(() => {
    const savedCollapsed = getSavedSidebarCollapsed();

    saveSidebarCollapsed(savedCollapsed);
    const frame = requestAnimationFrame(() => {
      setCollapsed(savedCollapsed);
    });

    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    saveSidebarCollapsed(collapsed);
  }, [collapsed]);

  useEffect(() => {
    const scrollArea = scrollAreaRef.current;
    if (!scrollArea || collapsed) return;

    const frame = requestAnimationFrame(() => {
      scrollArea.scrollTop = desktopSidebarScrollTop;

      const activeItem = scrollArea.querySelector<HTMLAnchorElement>(
        '[aria-current="page"]',
      );

      if (!activeItem) return;

      const scrollAreaRect = scrollArea.getBoundingClientRect();
      const activeItemRect = activeItem.getBoundingClientRect();

      if (
        activeItemRect.top < scrollAreaRect.top + 10 ||
        activeItemRect.bottom > scrollAreaRect.bottom - 10
      ) {
        activeItem.scrollIntoView({ block: "nearest" });
        desktopSidebarScrollTop = scrollArea.scrollTop;
      }
    });

    return () => cancelAnimationFrame(frame);
  }, [pathname, collapsed]);

  function handleNavigate(href: string) {
    if (scrollAreaRef.current) {
      desktopSidebarScrollTop = scrollAreaRef.current.scrollTop;
    }

    onNavigateStart(href);
    onCloseMobileMenu();
  }

  function handleToggleCollapse() {
    setCollapsed((value) => {
      const nextValue = !value;
      saveSidebarCollapsed(nextValue);
      return nextValue;
    });
  }

  return (
    <aside
      className={clsx(
        "fixed inset-y-0 left-0 z-30 hidden h-screen border-r border-slate-200/70 bg-[#f8fbff]/88 backdrop-blur-xl transition-[width,padding] duration-300 ease-out xl:flex xl:flex-col",
        collapsed ? "px-3 py-5" : "px-4 py-5",
      )}
      style={{
        width: collapsed ? SIDEBAR_COLLAPSED_WIDTH : SIDEBAR_EXPANDED_WIDTH,
      }}
    >
      <SidebarHeader collapsed={collapsed} onToggleCollapse={handleToggleCollapse} />

      {collapsed ? (
        <CollapsedToggleButton onToggleCollapse={handleToggleCollapse} />
      ) : null}

      <div
        ref={scrollAreaRef}
        onScroll={(event) => {
          desktopSidebarScrollTop = event.currentTarget.scrollTop;
        }}
        className={clsx(
          "mt-4 flex-1 overflow-y-auto overflow-x-hidden scroll-smooth",
          collapsed ? "pr-0" : "pr-1",
        )}
      >
        <nav className="space-y-4">
          {adminNavGroups.map((group) => (
            <div key={group.label}>
              {!collapsed ? (
                <p className="px-3 text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">
                  {group.label}
                </p>
              ) : null}

              <div className={clsx(collapsed ? "mt-1 space-y-1.5" : "mt-2 space-y-1.5")}>
                {group.items.map((item) => (
                  <NavItem
                    key={item.href}
                    href={item.href}
                    label={item.label}
                    description={item.description}
                    icon={item.icon}
                    active={isRouteActive(pathname, item.href)}
                    collapsed={collapsed}
                    onNavigate={handleNavigate}
                  />
                ))}
              </div>
            </div>
          ))}
        </nav>
      </div>

      <div className="mt-4 border-t border-slate-200/80 pt-3">
        <div className="space-y-1.5">
          <SidebarFooterAction
            href="/"
            icon={ExternalLink}
            label="View public site"
            collapsed={collapsed}
          />

          <SidebarFooterAction
            icon={LogOut}
            label="Logout"
            collapsed={collapsed}
            danger
            onClick={onLogout}
          />
        </div>
      </div>
    </aside>
  );
}

function MobileSidebar({
  pathname,
  mobileMenuOpen,
  onCloseMobileMenu,
  onNavigateStart,
  onLogout,
}: Pick<
  AdminSidebarProps,
  | "pathname"
  | "mobileMenuOpen"
  | "onCloseMobileMenu"
  | "onNavigateStart"
  | "onLogout"
>) {
  if (!mobileMenuOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/40 backdrop-blur-sm xl:hidden">
      <button
        type="button"
        className="absolute inset-0 h-full w-full cursor-default"
        aria-label="Close navigation overlay"
        onClick={onCloseMobileMenu}
      />

      <div className="absolute inset-y-0 left-0 flex w-[90vw] max-w-[350px] flex-col overflow-y-auto border-r border-slate-200 bg-[#f8fbff] px-4 py-5 shadow-[0_28px_90px_rgba(15,23,42,0.28)]">
        <MobileSidebarHeader onCloseMobileMenu={onCloseMobileMenu} />

        <nav className="mt-5 space-y-4 pb-6">
          {adminNavGroups.map((group) => (
            <div key={group.label}>
              <p className="px-2 text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">
                {group.label}
              </p>

              <div className="mt-2 space-y-1.5">
                {group.items.map((item) => (
                  <NavItem
                    key={item.href}
                    href={item.href}
                    label={item.label}
                    description={item.description}
                    icon={item.icon}
                    active={isRouteActive(pathname, item.href)}
                    collapsed={false}
                    onNavigate={(href) => {
                      onNavigateStart(href);
                      onCloseMobileMenu();
                    }}
                  />
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div className="mt-auto border-t border-slate-200/80 pt-3">
          <div className="space-y-1.5">
            <Link
              href="/"
              onClick={onCloseMobileMenu}
              className="flex min-h-11 items-center gap-2.5 rounded-xl px-3 py-2 text-[13px] font-extrabold text-slate-500 transition hover:bg-white hover:text-[#062f66]"
            >
              <ExternalLink size={17} />
              View public site
            </Link>

            <button
              type="button"
              onClick={onLogout}
              className="flex min-h-11 w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-[13px] font-extrabold text-slate-500 transition hover:bg-red-50 hover:text-red-600"
            >
              <LogOut size={17} />
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminSidebar({
  pathname,
  mobileMenuOpen,
  onCloseMobileMenu,
  onNavigateStart,
  onLogout,
}: AdminSidebarProps) {
  return (
    <>
      <DesktopSidebar
        pathname={pathname}
        onCloseMobileMenu={onCloseMobileMenu}
        onNavigateStart={onNavigateStart}
        onLogout={onLogout}
      />

      <MobileSidebar
        pathname={pathname}
        mobileMenuOpen={mobileMenuOpen}
        onCloseMobileMenu={onCloseMobileMenu}
        onNavigateStart={onNavigateStart}
        onLogout={onLogout}
      />
    </>
  );
}
