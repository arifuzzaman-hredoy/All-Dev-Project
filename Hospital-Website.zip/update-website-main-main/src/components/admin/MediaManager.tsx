"use client";

import { type ChangeEvent, useEffect, useMemo, useState } from "react";
import {
  Check,
  Copy,
  Database,
  ImageIcon,
  Loader2,
  Pencil,
  RefreshCcw,
  Search,
  Trash2,
  UploadCloud,
} from "lucide-react";
import type { AdminMediaAssetView } from "@/lib/media-assets";

type MediaCounts = {
  total: number;
  cms: number;
  hero: number;
};

type MediaManagerProps = {
  initialAssets: AdminMediaAssetView[];
  initialCounts: MediaCounts;
};

function formatBytes(size: number) {
  if (!Number.isFinite(size) || size <= 0) return "0 KB";
  if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

export default function MediaManager({ initialAssets, initialCounts }: MediaManagerProps) {
  const [assets, setAssets] = useState(initialAssets);
  const [counts, setCounts] = useState(initialCounts);
  const [folder, setFolder] = useState("all");
  const [search, setSearch] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [toast, setToast] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftAltText, setDraftAltText] = useState("");
  const [copiedUrl, setCopiedUrl] = useState("");

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  async function loadAssets(nextFolder = folder, nextSearch = search) {
    const params = new URLSearchParams();
    params.set("folder", nextFolder);
    if (nextSearch.trim()) params.set("q", nextSearch.trim());
    params.set("take", "200");

    try {
      setIsLoading(true);
      const response = await fetch(`/api/admin/media-assets?${params.toString()}`, {
        cache: "no-store",
      });
      const data = (await response.json().catch(() => null)) as {
        assets?: AdminMediaAssetView[];
        counts?: MediaCounts;
        message?: string;
      } | null;

      if (!response.ok) {
        throw new Error(data?.message || "Failed to load media assets.");
      }

      setAssets(Array.isArray(data?.assets) ? data.assets : []);
      if (data?.counts) setCounts(data.counts);
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Failed to load media assets.");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadAssets(folder, search);
    }, 250);

    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [folder, search]);

  async function handleUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      showToast("Only image files are allowed.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      setIsUploading(true);
      const response = await fetch("/api/admin/uploads", {
        method: "POST",
        body: formData,
      });
      const data = (await response.json().catch(() => null)) as {
        ok?: boolean;
        asset?: AdminMediaAssetView;
        message?: string;
      } | null;

      if (!response.ok || !data?.ok) {
        throw new Error(data?.message || "Upload failed.");
      }

      if (data.asset) {
        setAssets((current) => [data.asset as AdminMediaAssetView, ...current]);
        setCounts((current) => ({
          ...current,
          total: current.total + 1,
          cms: current.cms + 1,
        }));
      } else {
        await loadAssets();
      }

      showToast("Image uploaded and saved to media library.");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setIsUploading(false);
    }
  }

  async function copyUrl(url: string) {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      window.setTimeout(() => setCopiedUrl(""), 1600);
      showToast("Image URL copied.");
    } catch {
      showToast("Could not copy URL. Select and copy it manually.");
    }
  }

  function startEdit(asset: AdminMediaAssetView) {
    setEditingId(asset.id);
    setDraftAltText(asset.altText);
  }

  async function saveAltText(asset: AdminMediaAssetView) {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/admin/media-assets/${asset.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ altText: draftAltText }),
      });
      const data = (await response.json().catch(() => null)) as {
        asset?: AdminMediaAssetView;
        message?: string;
      } | null;

      if (!response.ok || !data?.asset) {
        throw new Error(data?.message || "Failed to update media asset.");
      }

      setAssets((current) =>
        current.map((item) => (item.id === asset.id ? data.asset as AdminMediaAssetView : item)),
      );
      setEditingId(null);
      setDraftAltText("");
      showToast("Alt text updated.");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Failed to update media asset.");
    } finally {
      setIsLoading(false);
    }
  }

  async function deleteAsset(asset: AdminMediaAssetView) {
    if (!window.confirm(`Delete media file "${asset.fileName}"?`)) return;

    try {
      setIsLoading(true);
      const response = await fetch(`/api/admin/media-assets/${asset.id}`, {
        method: "DELETE",
      });
      const data = (await response.json().catch(() => null)) as {
        ok?: boolean;
        message?: string;
      } | null;

      if (!response.ok || !data?.ok) {
        throw new Error(data?.message || "Failed to delete media asset.");
      }

      setAssets((current) => current.filter((item) => item.id !== asset.id));
      setCounts((current) => ({
        ...current,
        total: Math.max(0, current.total - 1),
        cms: asset.folder === "cms" ? Math.max(0, current.cms - 1) : current.cms,
        hero: asset.folder === "hero" ? Math.max(0, current.hero - 1) : current.hero,
      }));
      showToast("Media asset deleted.");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Failed to delete media asset.");
    } finally {
      setIsLoading(false);
    }
  }

  const visibleAssets = useMemo(() => assets, [assets]);

  return (
    <div className="space-y-6">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 rounded-2xl bg-[#062f66] px-5 py-3 text-sm font-black text-white shadow-2xl">
          {toast}
        </div>
      ) : null}

      <section className="relative overflow-hidden rounded-[32px] bg-[#062f66] px-6 py-8 text-white shadow-[0_28px_65px_rgba(6,47,102,0.18)] sm:px-8 lg:px-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(91,192,222,0.22),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(140,198,63,0.16),transparent_34%)]" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <p className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-200">
              <ImageIcon size={16} /> Media library
            </p>
            <h1 className="mt-3 text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
              Admin media manager
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base">
              Upload images, copy public URLs, update alt text, and remove unused CMS files from one DB-backed media library.
            </p>
          </div>

          <label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-black text-[#062f66] shadow-[0_18px_42px_rgba(255,255,255,0.16)] transition hover:-translate-y-0.5 disabled:opacity-60">
            {isUploading ? <Loader2 size={17} className="animate-spin" /> : <UploadCloud size={17} />}
            {isUploading ? "Uploading..." : "Upload image"}
            <input type="file" accept="image/*" onChange={handleUpload} disabled={isUploading} className="hidden" />
          </label>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {[
          ["Total media", counts.total],
          ["CMS images", counts.cms],
          ["Hero images", counts.hero],
        ].map(([label, value]) => (
          <div key={label} className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_18px_50px_rgba(15,23,42,0.06)]">
            <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-cyan-600">
              <Database size={14} /> {label}
            </p>
            <p className="mt-3 text-4xl font-black text-[#062f66]">{value}</p>
          </div>
        ))}
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-[0_18px_50px_rgba(15,23,42,0.06)]">
        <div className="grid gap-3 lg:grid-cols-[1fr_220px_auto]">
          <label className="relative block">
            <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search filename, alt text, folder, URL..."
              className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 pl-11 pr-4 text-sm font-semibold text-slate-700 outline-none transition focus:border-cyan-400 focus:bg-white focus:ring-4 focus:ring-cyan-100"
            />
          </label>

          <select
            value={folder}
            onChange={(event) => setFolder(event.target.value)}
            className="h-12 rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm font-black text-slate-700 outline-none transition focus:border-cyan-400 focus:bg-white focus:ring-4 focus:ring-cyan-100"
          >
            <option value="all">All folders</option>
            <option value="cms">CMS</option>
            <option value="hero">Hero</option>
          </select>

          <button
            type="button"
            onClick={() => void loadAssets()}
            disabled={isLoading}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-[#062f66] px-5 text-sm font-black text-white transition hover:-translate-y-0.5 disabled:opacity-60"
          >
            {isLoading ? <Loader2 size={16} className="animate-spin" /> : <RefreshCcw size={16} />}
            Refresh
          </button>
        </div>
      </section>

      <section className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {visibleAssets.length === 0 ? (
          <div className="col-span-full rounded-[28px] border border-dashed border-slate-300 bg-white p-10 text-center text-sm font-bold text-slate-500">
            No media assets found.
          </div>
        ) : (
          visibleAssets.map((asset) => (
            <article key={asset.id} className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-[0_18px_50px_rgba(15,23,42,0.06)]">
              <div className="relative aspect-[16/10] bg-slate-100">
                <img src={asset.url} alt={asset.altText || asset.fileName} className="h-full w-full object-cover" />
                <span className="absolute left-3 top-3 rounded-full bg-slate-950/75 px-3 py-1 text-xs font-black uppercase tracking-[0.1em] text-white backdrop-blur">
                  {asset.folder}
                </span>
              </div>

              <div className="space-y-4 p-5">
                <div>
                  <h2 className="line-clamp-1 text-base font-black text-[#062f66]">{asset.fileName}</h2>
                  <p className="mt-1 text-xs font-semibold text-slate-500">
                    {formatBytes(asset.size)} · {asset.mimeType} · {formatDate(asset.createdAt)}
                  </p>
                </div>

                {editingId === asset.id ? (
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">Alt text</label>
                    <input
                      value={draftAltText}
                      onChange={(event) => setDraftAltText(event.target.value)}
                      className="h-11 w-full rounded-2xl border border-slate-200 px-3 text-sm font-semibold outline-none focus:border-cyan-400 focus:ring-4 focus:ring-cyan-100"
                      placeholder="Describe this image for accessibility"
                    />
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => void saveAltText(asset)}
                        className="rounded-xl bg-[#062f66] px-3 py-2 text-xs font-black text-white"
                      >
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-black text-slate-600"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="line-clamp-2 min-h-10 text-sm font-semibold leading-5 text-slate-600">
                    {asset.altText || "No alt text yet."}
                  </p>
                )}

                <div className="rounded-2xl bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-500">
                  <p className="truncate">{asset.url}</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => void copyUrl(asset.url)}
                    className="inline-flex items-center gap-2 rounded-2xl border border-blue-100 bg-blue-50 px-3 py-2 text-xs font-black text-blue-700"
                  >
                    {copiedUrl === asset.url ? <Check size={14} /> : <Copy size={14} />}
                    Copy URL
                  </button>
                  <button
                    type="button"
                    onClick={() => startEdit(asset)}
                    className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700"
                  >
                    <Pencil size={14} /> Alt text
                  </button>
                  <button
                    type="button"
                    onClick={() => void deleteAsset(asset)}
                    className="inline-flex items-center gap-2 rounded-2xl border border-red-100 bg-red-50 px-3 py-2 text-xs font-black text-red-700"
                  >
                    <Trash2 size={14} /> Delete
                  </button>
                </div>
              </div>
            </article>
          ))
        )}
      </section>
    </div>
  );
}
