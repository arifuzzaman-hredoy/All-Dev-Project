"use client";

import { ChangeEvent, createElement, useEffect, useState } from "react";
import {
  AboutFeatureCard,
  AboutImageCard,
  AboutPageData,
  DEFAULT_ABOUT_PAGE,
  fileToDataUrl,
  makeAboutId,
} from "@/lib/aboutPage";
import { aboutIconOptions, getAboutIcon } from "@/lib/aboutIcons";

type CardGroupKey = "whoCards" | "values" | "learningCards";

function AboutIcon({ icon, className }: { icon: string; className?: string }) {
  const Icon = getAboutIcon(icon);

  return createElement(Icon, { className, strokeWidth: 2.4 });
}

export default function AboutPageAdmin() {
  const [draft, setDraft] = useState<AboutPageData>(DEFAULT_ABOUT_PAGE);
  const [toast, setToast] = useState("");

  useEffect(() => {
    let mounted = true;

    async function loadDraft() {
      try {
        const response = await fetch("/api/admin/about-page", { cache: "no-store" });
        const payload = (await response.json().catch(() => null)) as
          | { data?: AboutPageData }
          | null;

        if (mounted && response.ok && payload?.data) {
          setDraft(payload.data);
          return;
        }
      } catch {
        // Keep editor usable with default content if API is unavailable.
      }

      if (mounted) setDraft(DEFAULT_ABOUT_PAGE);
    }

    void loadDraft();

    return () => {
      mounted = false;
    };
  }, []);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2500);
  }

  function updateField<K extends keyof AboutPageData>(
    key: K,
    value: AboutPageData[K],
  ) {
    setDraft((prev) => ({ ...prev, [key]: value }));
  }

  async function saveAll() {
    try {
      const response = await fetch("/api/admin/about-page", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data: draft }),
      });
      const payload = (await response.json().catch(() => null)) as
        | { data?: AboutPageData; message?: string }
        | null;

      if (!response.ok || !payload?.data) {
        throw new Error(payload?.message || "About page save failed.");
      }

      setDraft(payload.data);
      window.dispatchEvent(new Event("about-page-updated"));
      showToast("About page updated successfully.");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "About page save failed.");
    }
  }

  async function resetDefault() {
    if (!window.confirm("Reset About page to default data?")) return;

    try {
      const response = await fetch("/api/admin/about-page", { method: "DELETE" });
      const payload = (await response.json().catch(() => null)) as
        | { data?: AboutPageData; message?: string }
        | null;

      if (!response.ok || !payload?.data) {
        throw new Error(payload?.message || "Reset failed.");
      }

      setDraft(payload.data);
      window.dispatchEvent(new Event("about-page-updated"));
      showToast("Default About page restored.");
    } catch {
      setDraft(DEFAULT_ABOUT_PAGE);
      showToast("Default About page restored.");
    }
  }

  async function uploadMainImage(
    event: ChangeEvent<HTMLInputElement>,
    key: "heroImage" | "whoImage" | "learningImage",
  ) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) return showToast("Only image allowed.");
    if (file.size > 3 * 1024 * 1024) {
      return showToast("Image 3MB er niche rakho.");
    }

    const dataUrl = await fileToDataUrl(file);
    updateField(key, dataUrl);
    showToast("Image uploaded. Save korte vulbe na.");
  }

  function updateCard(
    group: CardGroupKey,
    id: string,
    key: keyof AboutFeatureCard,
    value: string | number | boolean,
  ) {
    setDraft((prev) => ({
      ...prev,
      [group]: prev[group].map((item) =>
        item.id === id ? { ...item, [key]: value } : item,
      ),
    }));
  }

  function addCard(group: CardGroupKey) {
    const nextCard: AboutFeatureCard = {
      id: makeAboutId(group),
      icon: "stethoscope",
      title: "New Card",
      text: "Editable card text.",
      active: true,
      sortOrder: draft[group].length + 1,
    };

    setDraft((prev) => ({ ...prev, [group]: [...prev[group], nextCard] }));
  }

  function deleteCard(group: CardGroupKey, id: string) {
    if (!window.confirm("Delete this card?")) return;
    setDraft((prev) => ({
      ...prev,
      [group]: prev[group].filter((item) => item.id !== id),
    }));
  }

  function updateGallery(
    id: string,
    key: keyof AboutImageCard,
    value: string | number | boolean,
  ) {
    setDraft((prev) => ({
      ...prev,
      transformImages: prev.transformImages.map((item) =>
        item.id === id ? { ...item, [key]: value } : item,
      ),
    }));
  }

  function addGalleryImage() {
    const nextImage: AboutImageCard = {
      id: makeAboutId("gallery"),
      icon: "stethoscope",
      image: "",
      label: String(draft.transformImages.length + 1).padStart(2, "0"),
      active: true,
      sortOrder: draft.transformImages.length + 1,
    };

    setDraft((prev) => ({
      ...prev,
      transformImages: [...prev.transformImages, nextImage],
    }));
  }

  function deleteGalleryImage(id: string) {
    if (!window.confirm("Delete this gallery image?")) return;
    setDraft((prev) => ({
      ...prev,
      transformImages: prev.transformImages.filter((item) => item.id !== id),
    }));
  }

  async function uploadGalleryImage(
    event: ChangeEvent<HTMLInputElement>,
    id: string,
  ) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) return showToast("Only image allowed.");
    if (file.size > 3 * 1024 * 1024) {
      return showToast("Image 3MB er niche rakho.");
    }

    const dataUrl = await fileToDataUrl(file);
    updateGallery(id, "image", dataUrl);
    showToast("Gallery image uploaded. Save korte vulbe na.");
  }

  return (
    <main className="min-h-screen bg-[#f4f8fc] p-5 text-[#002f70] sm:p-7">
      {toast ? (
        <div className="fixed right-6 top-6 z-[100] rounded-lg bg-[#002f70] px-5 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section className="rounded-2xl border border-[#d7e3f1] bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-[#8061bd]">
              CMS Control
            </p>
            <h1 className="mt-2 text-3xl font-black">About Page</h1>
            <p className="mt-2 max-w-3xl font-semibold leading-7 text-[#49668b]">
              Edit About page images, text, value cards, gallery images, and
              medical learning section.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={resetDefault}
              className="rounded-lg border border-[#c7d7ea] bg-white px-5 py-3 text-sm font-black"
            >
              Reset Default
            </button>
            <button
              type="button"
              onClick={saveAll}
              className="rounded-lg bg-[#002f70] px-5 py-3 text-sm font-black text-white"
            >
              Save About Page
            </button>
          </div>
        </div>
      </section>

      <AdminBlock title="Hero Banner">
        <ImageUploadRow
          image={draft.heroImage}
          label="Hero image"
          onUrl={(value) => updateField("heroImage", value)}
          onUpload={(event) => uploadMainImage(event, "heroImage")}
        />
        <FormInput
          label="Hero alt text"
          value={draft.heroAlt}
          onChange={(value) => updateField("heroAlt", value)}
        />
      </AdminBlock>

      <AdminBlock title="Who We Are Section">
        <div className="grid gap-4 md:grid-cols-2">
          <FormInput label="Badge" value={draft.whoBadge} onChange={(value) => updateField("whoBadge", value)} />
          <FormInput label="Image label" value={draft.whoImageLabel} onChange={(value) => updateField("whoImageLabel", value)} />
          <FormInput label="Title main" value={draft.whoTitleMain} onChange={(value) => updateField("whoTitleMain", value)} />
          <FormInput label="Title accent" value={draft.whoTitleAccent} onChange={(value) => updateField("whoTitleAccent", value)} />
        </div>
        <FormTextarea label="Description" rows={5} value={draft.whoDescription} onChange={(value) => updateField("whoDescription", value)} />
        <ImageUploadRow
          image={draft.whoImage}
          label="Who section image"
          onUrl={(value) => updateField("whoImage", value)}
          onUpload={(event) => uploadMainImage(event, "whoImage")}
        />
        <CardsEditor
          title="Who Cards"
          cards={draft.whoCards}
          onAdd={() => addCard("whoCards")}
          onUpdate={(id, key, value) => updateCard("whoCards", id, key, value)}
          onDelete={(id) => deleteCard("whoCards", id)}
        />
      </AdminBlock>

      <AdminBlock title="Transforming Healthcare Gallery">
        <div className="grid gap-4 md:grid-cols-2">
          <FormInput label="Title main" value={draft.transformTitleMain} onChange={(value) => updateField("transformTitleMain", value)} />
          <FormInput label="Title accent" value={draft.transformTitleAccent} onChange={(value) => updateField("transformTitleAccent", value)} />
        </div>

        <div className="mt-5 flex justify-end">
          <button
            type="button"
            onClick={addGalleryImage}
            className="rounded-lg bg-[#002f70] px-5 py-3 text-sm font-black text-white"
          >
            + Add Gallery Image
          </button>
        </div>

        <div className="mt-5 grid gap-4 lg:grid-cols-2">
          {draft.transformImages
            .slice()
            .sort((a, b) => a.sortOrder - b.sortOrder)
            .map((item) => (
              <article
                key={item.id}
                className={`rounded-xl border border-[#d5e2f0] bg-[#f8fbff] p-4 ${
                  !item.active ? "opacity-60" : ""
                }`}
              >
                <div className="grid gap-4 md:grid-cols-[150px_1fr]">
                  <div className="h-[130px] overflow-hidden rounded-xl border bg-white">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.label}
                        className="h-full w-full object-cover"
                      />
                    ) : null}
                  </div>

                  <div className="grid gap-3">
                    <div className="flex items-center gap-2 text-sm font-black">
                      <AboutIcon icon={item.icon} className="h-5 w-5 text-[#00a6a6]" />
                      Gallery Image
                    </div>
                    <FormInput label="Label" value={item.label} onChange={(value) => updateGallery(item.id, "label", value)} />
                    <IconSelect value={item.icon} onChange={(value) => updateGallery(item.id, "icon", value)} />
                    <FormInput label="Image URL" value={item.image} onChange={(value) => updateGallery(item.id, "image", value)} />
                    <FormInput label="Sort" type="number" value={String(item.sortOrder)} onChange={(value) => updateGallery(item.id, "sortOrder", Number(value))} />

                    <div className="flex flex-wrap gap-2">
                      <label className="cursor-pointer rounded-md bg-[#071126] px-4 py-2 text-sm font-black text-white">
                        Upload
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(event) => uploadGalleryImage(event, item.id)}
                          className="hidden"
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => updateGallery(item.id, "active", !item.active)}
                        className="rounded-md border bg-white px-4 py-2 text-sm font-black"
                      >
                        {item.active ? "Hide" : "Show"}
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteGalleryImage(item.id)}
                        className="rounded-md border border-[#ffd1d1] bg-[#fff1f1] px-4 py-2 text-sm font-black text-[#b42318]"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            ))}
        </div>
      </AdminBlock>

      <AdminBlock title="Vision & Mission">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <FormInput label="Vision title" value={draft.visionTitle} onChange={(value) => updateField("visionTitle", value)} />
            <FormTextarea label="Vision text" rows={5} value={draft.visionText} onChange={(value) => updateField("visionText", value)} />
          </div>
          <div>
            <FormInput label="Mission title" value={draft.missionTitle} onChange={(value) => updateField("missionTitle", value)} />
            <FormTextarea label="Mission text" rows={5} value={draft.missionText} onChange={(value) => updateField("missionText", value)} />
          </div>
        </div>
      </AdminBlock>

      <AdminBlock title="Values Section">
        <FormInput label="Values title" value={draft.valuesTitle} onChange={(value) => updateField("valuesTitle", value)} />
        <FormTextarea label="Values intro" rows={4} value={draft.valuesIntro} onChange={(value) => updateField("valuesIntro", value)} />
        <CardsEditor
          title="Values Cards"
          cards={draft.values}
          onAdd={() => addCard("values")}
          onUpdate={(id, key, value) => updateCard("values", id, key, value)}
          onDelete={(id) => deleteCard("values", id)}
        />
      </AdminBlock>

      <AdminBlock title="Medical Learning Section">
        <div className="grid gap-4 md:grid-cols-2">
          <FormInput label="Badge" value={draft.learningBadge} onChange={(value) => updateField("learningBadge", value)} />
          <FormInput label="Image label" value={draft.learningImageLabel} onChange={(value) => updateField("learningImageLabel", value)} />
          <FormInput label="Title" value={draft.learningTitle} onChange={(value) => updateField("learningTitle", value)} />
          <FormInput label="Accent word" value={draft.learningAccent} onChange={(value) => updateField("learningAccent", value)} />
        </div>
        <FormTextarea label="Description" rows={5} value={draft.learningDescription} onChange={(value) => updateField("learningDescription", value)} />
        <ImageUploadRow
          image={draft.learningImage}
          label="Learning image"
          onUrl={(value) => updateField("learningImage", value)}
          onUpload={(event) => uploadMainImage(event, "learningImage")}
        />
        <CardsEditor
          title="Learning Cards"
          cards={draft.learningCards}
          onAdd={() => addCard("learningCards")}
          onUpdate={(id, key, value) => updateCard("learningCards", id, key, value)}
          onDelete={(id) => deleteCard("learningCards", id)}
        />
      </AdminBlock>

      <div className="sticky bottom-5 z-40 mt-8 flex justify-end">
        <button
          type="button"
          onClick={saveAll}
          className="rounded-xl bg-[#002f70] px-7 py-4 text-sm font-black text-white shadow-2xl"
        >
          Save About Page
        </button>
      </div>
    </main>
  );
}

function AdminBlock({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-5 rounded-2xl border border-[#d7e3f1] bg-white p-5 shadow-sm">
      <h2 className="text-xl font-black">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function FormInput({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 rounded-md border border-[#c6d6e8] px-3 text-base font-semibold text-[#002f70] outline-none focus:border-[#24a7dc] focus:ring-4 focus:ring-[#24a7dc]/10"
      />
    </label>
  );
}

function FormTextarea({
  label,
  value,
  onChange,
  rows,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  rows: number;
}) {
  return (
    <label className="mt-4 grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <textarea
        rows={rows}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="resize-y rounded-md border border-[#c6d6e8] px-3 py-3 text-base font-semibold leading-6 text-[#002f70] outline-none focus:border-[#24a7dc] focus:ring-4 focus:ring-[#24a7dc]/10"
      />
    </label>
  );
}

function ImageUploadRow({
  image,
  label,
  onUrl,
  onUpload,
}: {
  image: string;
  label: string;
  onUrl: (value: string) => void;
  onUpload: (event: ChangeEvent<HTMLInputElement>) => void;
}) {
  return (
    <div className="mt-4 grid gap-4 md:grid-cols-[180px_1fr]">
      <div className="h-[125px] overflow-hidden rounded-xl border border-[#d5e2f0] bg-[#f8fbff]">
        {image ? (
          <img src={image} alt={label} className="h-full w-full object-cover" />
        ) : null}
      </div>
      <div className="grid gap-3">
        <FormInput label={label} value={image} onChange={onUrl} />
        <label className="inline-flex w-fit cursor-pointer rounded-md bg-[#071126] px-4 py-3 text-sm font-black text-white">
          Upload Image
          <input type="file" accept="image/*" onChange={onUpload} className="hidden" />
        </label>
      </div>
    </div>
  );
}

function IconSelect({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      Icon
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 rounded-md border border-[#c6d6e8] px-3 text-base font-semibold text-[#002f70] outline-none"
      >
        {aboutIconOptions.map((option) => (
          <option key={option.key} value={option.key}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function CardsEditor({
  title,
  cards,
  onAdd,
  onUpdate,
  onDelete,
}: {
  title: string;
  cards: AboutFeatureCard[];
  onAdd: () => void;
  onUpdate: (
    id: string,
    key: keyof AboutFeatureCard,
    value: string | number | boolean,
  ) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="mt-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-lg font-black">{title}</h3>
        <button
          type="button"
          onClick={onAdd}
          className="rounded-lg bg-[#002f70] px-5 py-3 text-sm font-black text-white"
        >
          + Add Card
        </button>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        {cards
          .slice()
          .sort((a, b) => a.sortOrder - b.sortOrder)
          .map((item) => (
            <article
              key={item.id}
              className={`rounded-xl border border-[#d5e2f0] bg-[#f8fbff] p-4 ${
                !item.active ? "opacity-60" : ""
              }`}
            >
              <div className="mb-3 flex items-center gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-[#e4f7ff] text-[#35bbea]">
                  <AboutIcon icon={item.icon} className="h-6 w-6" />
                </div>
                <strong>{item.title}</strong>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <IconSelect
                  value={item.icon}
                  onChange={(value) => onUpdate(item.id, "icon", value)}
                />
                <FormInput
                  label="Sort"
                  type="number"
                  value={String(item.sortOrder)}
                  onChange={(value) =>
                    onUpdate(item.id, "sortOrder", Number(value))
                  }
                />
                <FormInput
                  label="Title"
                  value={item.title}
                  onChange={(value) => onUpdate(item.id, "title", value)}
                />
                <FormInput
                  label="Text"
                  value={item.text}
                  onChange={(value) => onUpdate(item.id, "text", value)}
                />
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => onUpdate(item.id, "active", !item.active)}
                  className="rounded-md border border-[#cfe1f5] bg-white px-4 py-2 text-sm font-black"
                >
                  {item.active ? "Hide" : "Show"}
                </button>
                <button
                  type="button"
                  onClick={() => onDelete(item.id)}
                  className="rounded-md border border-[#ffd1d1] bg-[#fff1f1] px-4 py-2 text-sm font-black text-[#b42318]"
                >
                  Delete
                </button>
              </div>
            </article>
          ))}
      </div>
    </div>
  );
}
