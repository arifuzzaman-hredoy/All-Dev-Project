"use client";

import Link from "next/link";
import { FormEvent, ReactNode, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Eye,
  EyeOff,
  Loader2,
  LockKeyhole,
  Mail,
  ShieldCheck,
} from "lucide-react";

type LoginResponse = {
  ok?: boolean;
  message?: string;
  error?: string;
};

type FieldIcon = React.ComponentType<{
  size?: number;
  strokeWidth?: number;
  className?: string;
}>;

const FORGOT_PASSWORD_HREF = "/admin/forgot-password";

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function GoogleInput({
  id,
  label,
  type,
  value,
  icon: Icon,
  disabled,
  autoComplete,
  error,
  rightSlot,
  onChange,
}: {
  id: string;
  label: string;
  type: string;
  value: string;
  icon: FieldIcon;
  disabled?: boolean;
  autoComplete?: string;
  error?: boolean;
  rightSlot?: ReactNode;
  onChange: (value: string) => void;
}) {
  const [focused, setFocused] = useState(false);
  const isFloating = focused || value.trim().length > 0;

  return (
    <div className="relative w-full">
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        disabled={disabled}
        autoComplete={autoComplete}
        placeholder=" "
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onChange={(event) => onChange(event.target.value)}
        className={cn(
          "h-[56px] w-full appearance-none rounded-2xl border bg-white pl-12 text-[15px] font-semibold text-slate-900 outline-none transition-[border-color,box-shadow] duration-200",
          "placeholder:text-transparent",
          "disabled:cursor-not-allowed disabled:bg-white disabled:text-slate-400",
          "hover:border-slate-300",
          "focus:bg-white focus:ring-4",
          rightSlot ? "pr-14" : "pr-4",
          error
            ? "border-red-400 focus:border-red-500 focus:ring-red-500/10"
            : "border-slate-200 focus:border-[#1a73e8] focus:ring-[#1a73e8]/10",
        )}
        style={{
          backgroundColor: "white",
          WebkitBoxShadow: "0 0 0 1000px white inset",
          WebkitTextFillColor: "#0f172a",
          caretColor: "#0f172a",
        }}
      />

      <Icon
        size={18}
        strokeWidth={1.65}
        className={cn(
          "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 transition-colors duration-200",
          error
            ? "text-red-500"
            : focused
              ? "text-[#1a73e8]"
              : "text-slate-400",
        )}
      />

      <label
        htmlFor={id}
        className={cn(
          "pointer-events-none absolute font-semibold transition-all duration-200",
          isFloating
            ? "left-4 top-0 -translate-y-1/2 bg-white px-1.5 text-[12px]"
            : "left-12 top-1/2 -translate-y-1/2 bg-transparent px-0 text-[14px]",
          error
            ? "text-red-500"
            : focused
              ? "text-[#1a73e8]"
              : isFloating
                ? "text-slate-500"
                : "text-slate-400",
        )}
      >
        {label}
      </label>

      {rightSlot ? (
        <div className="absolute right-3 top-1/2 -translate-y-1/2">
          {rightSlot}
        </div>
      ) : null}
    </div>
  );
}

export default function AdminLoginForm() {
  const router = useRouter();

  const [emailOrPhone, setEmailOrPhone] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [touched, setTouched] = useState(false);
  const [serverError, setServerError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const emailError = touched && emailOrPhone.trim().length < 3;
  const passwordError = touched && password.trim().length < 4;

  const canSubmit = useMemo(() => {
    return emailOrPhone.trim().length >= 3 && password.trim().length >= 4;
  }, [emailOrPhone, password]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setTouched(true);
    setServerError("");

    if (!canSubmit) return;

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          email: emailOrPhone.trim(),
          emailOrPhone: emailOrPhone.trim(),
          password,
          rememberMe,
        }),
      });

      const data = (await response.json().catch(() => ({}))) as LoginResponse;

      if (!response.ok || data.ok === false) {
        setServerError(data.message || data.error || "Invalid admin login.");
        return;
      }

      router.refresh();
      router.push("/admin");
    } catch {
      setServerError("Login request failed. Please check your connection.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="w-full space-y-5">
      <GoogleInput
        id="emailOrPhone"
        label="Email"
        type="text"
        value={emailOrPhone}
        icon={Mail}
        disabled={isSubmitting}
        autoComplete="username"
        error={emailError}
        onChange={(value) => {
          setEmailOrPhone(value);
          setServerError("");
        }}
      />

      <div className="space-y-2">
        <div className="flex justify-end">
          <Link
            href={FORGOT_PASSWORD_HREF}
            className="text-sm font-extrabold text-slate-800 transition hover:text-[#1a73e8]"
          >
            Forgot password?
          </Link>
        </div>

        <GoogleInput
          id="password"
          label="Password"
          type={showPassword ? "text" : "password"}
          value={password}
          icon={LockKeyhole}
          disabled={isSubmitting}
          autoComplete="current-password"
          error={passwordError}
          onChange={(value) => {
            setPassword(value);
            setServerError("");
          }}
          rightSlot={
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => setShowPassword((current) => !current)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 transition hover:text-[#1a73e8] disabled:cursor-not-allowed disabled:opacity-50"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                <EyeOff size={18} strokeWidth={1.65} />
              ) : (
                <Eye size={18} strokeWidth={1.65} />
              )}
            </button>
          }
        />
      </div>

      {(emailError || passwordError || serverError) && (
        <div className="rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
          {serverError || "Email and password are required."}
        </div>
      )}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <label className="flex cursor-pointer items-center gap-3 text-sm font-bold text-slate-600">
          <input
            type="checkbox"
            checked={rememberMe}
            disabled={isSubmitting}
            onChange={(event) => setRememberMe(event.target.checked)}
            className="h-4 w-4 rounded accent-[#1a73e8]"
          />
          Remember me
        </label>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
          <ShieldCheck size={15} strokeWidth={1.65} />
          Password is never saved
        </div>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="inline-flex h-[58px] w-full items-center justify-center gap-2 rounded-2xl bg-[#062f66] px-5 text-sm font-black uppercase tracking-[0.22em] text-white shadow-[0_20px_42px_rgba(6,47,102,0.24)] transition hover:-translate-y-0.5 hover:bg-[#0b5bd3] active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-70"
      >
        {isSubmitting ? (
          <>
            <Loader2 size={18} className="animate-spin" />
            Signing in
          </>
        ) : (
          "Sign in securely"
        )}
      </button>
    </form>
  );
}