"use client";

import {
  CheckCircle2,
  Download,
  Eye,
  RefreshCcw,
  Search,
  Trash2,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";

type FormSubmissionStatus =
  | "NEW"
  | "READ"
  | "IN_PROGRESS"
  | "RESOLVED"
  | "ARCHIVED"
  | "SPAM";

type AdminFormSubmission = {
  id: string;
  formType: string;
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
  payload: unknown;
  status: FormSubmissionStatus;
  source: string;
  ipAddress: string;
  userAgent: string;
  createdAt: string;
  updatedAt: string;
};

const statusOptions: FormSubmissionStatus[] = [
  "NEW",
  "READ",
  "IN_PROGRESS",
  "RESOLVED",
  "ARCHIVED",
  "SPAM",
];

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function getPayloadRecord(payload: unknown): Record<string, unknown> {
  if (payload && typeof payload === "object" && !Array.isArray(payload)) {
    return payload as Record<string, unknown>;
  }

  return {};
}

function payloadText(payload: unknown, key: string) {
  const record = getPayloadRecord(payload);
  const value = record[key];

  if (typeof value === "string") return value;
  if (typeof value === "number") return String(value);
  return "";
}

function csvEscape(value: unknown) {
  const text = String(value ?? "");
  return `"${text.replaceAll('"', '""')}"`;
}

function exportCareerApplications(applications: AdminFormSubmission[]) {
  const rows = [
    [
      "Date",
      "Name",
      "Phone",
      "Email",
      "Position",
      "Education",
      "Experience",
      "Expected Salary",
      "Subject",
      "Message",
      "Status",
      "Source",
      "Resume File",
    ],
    ...applications.map((item) => [
      formatDateTime(item.createdAt),
      item.name,
      item.phone,
      item.email,
      payloadText(item.payload, "jobTitle") ||
        payloadText(item.payload, "department"),
      payloadText(item.payload, "education"),
      payloadText(item.payload, "experience"),
      payloadText(item.payload, "expectedSalary"),
      item.subject,
      item.message,
      item.status,
      item.source,
      payloadText(item.payload, "resumeFileName"),
    ]),
  ];

  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "career-db-applications.csv";
  link.click();
  URL.revokeObjectURL(url);
}

export default function CareerDbApplications() {
  const [submissions, setSubmissions] = useState<AdminFormSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("ALL");
  const [selected, setSelected] = useState<AdminFormSubmission | null>(null);
  const [toast, setToast] = useState("");

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }, []);

  const loadSubmissions = useCallback(async () => {
    setLoading(true);

    try {
      const response = await fetch("/api/admin/form-submissions", {
        cache: "no-store",
      });

      if (!response.ok) {
        throw new Error("Failed to load career applications.");
      }

      const data = (await response.json()) as {
        submissions: AdminFormSubmission[];
      };

      setSubmissions(
        data.submissions.filter((item) => item.formType === "CAREER"),
      );
    } catch {
      showToast("Failed to load career applications from database.");
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    void loadSubmissions();
  }, [loadSubmissions]);

  const filteredApplications = useMemo(() => {
    const keyword = search.toLowerCase().trim();

    return submissions.filter((item) => {
      if (status !== "ALL" && item.status !== status) return false;
      if (!keyword) return true;

      return [
        item.name,
        item.phone,
        item.email,
        item.subject,
        item.message,
        item.status,
        payloadText(item.payload, "jobTitle"),
        payloadText(item.payload, "department"),
        payloadText(item.payload, "education"),
        payloadText(item.payload, "experience"),
      ]
        .join(" ")
        .toLowerCase()
        .includes(keyword);
    });
  }, [search, status, submissions]);

  async function updateStatus(id: string, nextStatus: FormSubmissionStatus) {
    const response = await fetch(`/api/admin/form-submissions/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });

    if (!response.ok) {
      showToast("Status update failed.");
      return;
    }

    await loadSubmissions();
    showToast(`Career application marked as ${nextStatus}.`);
  }

  async function archiveApplication(id: string) {
    if (!window.confirm("Archive this career application?")) return;

    const response = await fetch(`/api/admin/form-submissions/${id}`, {
      method: "DELETE",
    });

    if (!response.ok) {
      showToast("Archive failed.");
      return;
    }

    setSelected(null);
    await loadSubmissions();
    showToast("Career application archived.");
  }

  return (
    <section className="mb-6 space-y-5 rounded-[30px] border border-emerald-200 bg-emerald-50/70 p-5 shadow-sm">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 rounded-xl bg-[#062f66] px-4 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-emerald-700">
            Real Database Applications
          </p>
          <h2 className="mt-2 text-2xl font-black text-[#062f66]">
            Career Applications from DB
          </h2>
          <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-slate-600">
            Public career apply form submissions are stored here from the real
            database. This section is not localStorage based.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void loadSubmissions()}
            className="inline-flex items-center gap-2 rounded-full border border-emerald-300 bg-white px-4 py-2 text-sm font-black text-emerald-700"
          >
            <RefreshCcw size={16} />
            Refresh
          </button>
          <button
            type="button"
            onClick={() => exportCareerApplications(filteredApplications)}
            className="inline-flex items-center gap-2 rounded-full bg-[#062f66] px-4 py-2 text-sm font-black text-white"
          >
            <Download size={16} />
            Export CSV
          </button>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-4">
        <div className="rounded-2xl bg-white p-4 ring-1 ring-emerald-100">
          <p className="text-xs font-black uppercase tracking-[0.15em] text-slate-500">
            Total
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {submissions.length}
          </p>
        </div>
        <div className="rounded-2xl bg-white p-4 ring-1 ring-emerald-100">
          <p className="text-xs font-black uppercase tracking-[0.15em] text-slate-500">
            New
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {submissions.filter((item) => item.status === "NEW").length}
          </p>
        </div>
        <div className="rounded-2xl bg-white p-4 ring-1 ring-emerald-100">
          <p className="text-xs font-black uppercase tracking-[0.15em] text-slate-500">
            In Progress
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {
              submissions.filter((item) => item.status === "IN_PROGRESS")
                .length
            }
          </p>
        </div>
        <div className="rounded-2xl bg-white p-4 ring-1 ring-emerald-100">
          <p className="text-xs font-black uppercase tracking-[0.15em] text-slate-500">
            Showing
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {filteredApplications.length}
          </p>
        </div>
      </div>

      <div className="grid gap-3 rounded-2xl bg-white p-4 ring-1 ring-emerald-100 md:grid-cols-[1fr_220px]">
        <label className="relative block">
          <Search
            size={17}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search career applications..."
            className="h-11 w-full rounded-xl border border-slate-200 pl-10 pr-3 text-sm font-semibold outline-none focus:border-emerald-400"
          />
        </label>

        <select
          value={status}
          onChange={(event) => setStatus(event.target.value)}
          className="h-11 rounded-xl border border-slate-200 px-3 text-sm font-bold outline-none focus:border-emerald-400"
        >
          <option value="ALL">All statuses</option>
          {statusOptions.map((item) => (
            <option key={item} value={item}>
              {item.replaceAll("_", " ")}
            </option>
          ))}
        </select>
      </div>

      <div className="overflow-hidden rounded-2xl border border-emerald-100 bg-white">
        <div className="overflow-x-auto">
          <table className="min-w-[1050px] w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs font-black uppercase tracking-[0.14em] text-slate-500">
              <tr>
                <th className="px-4 py-3">Applicant</th>
                <th className="px-4 py-3">Position</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center font-bold text-slate-500">
                    Loading career applications from database...
                  </td>
                </tr>
              ) : null}

              {!loading && !filteredApplications.length ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center font-bold text-slate-500">
                    No career applications found.
                  </td>
                </tr>
              ) : null}

              {filteredApplications.map((item) => (
                <tr key={item.id} className="align-top">
                  <td className="px-4 py-4">
                    <p className="font-black text-[#062f66]">
                      {item.name || "Unknown"}
                    </p>
                    <p className="mt-1 text-xs font-semibold text-slate-500">
                      {item.subject || "Career Application"}
                    </p>
                  </td>
                  <td className="px-4 py-4">
                    <p className="font-bold text-slate-700">
                      {payloadText(item.payload, "jobTitle") ||
                        payloadText(item.payload, "department") ||
                        "General Resume"}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      {payloadText(item.payload, "experience") || "No experience info"}
                    </p>
                  </td>
                  <td className="px-4 py-4">
                    <p className="font-bold text-slate-700">{item.phone || "-"}</p>
                    <p className="mt-1 text-xs text-slate-500">{item.email || "-"}</p>
                  </td>
                  <td className="px-4 py-4">
                    <select
                      value={item.status}
                      onChange={(event) =>
                        void updateStatus(
                          item.id,
                          event.target.value as FormSubmissionStatus,
                        )
                      }
                      className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-black"
                    >
                      {statusOptions.map((option) => (
                        <option key={option} value={option}>
                          {option.replaceAll("_", " ")}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-4 text-xs font-semibold text-slate-500">
                    {formatDateTime(item.createdAt)}
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setSelected(item)}
                        className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-2 text-xs font-black text-[#062f66]"
                      >
                        <Eye size={14} />
                        View
                      </button>
                      <button
                        type="button"
                        onClick={() => void archiveApplication(item.id)}
                        className="inline-flex items-center gap-2 rounded-full border border-red-200 px-3 py-2 text-xs font-black text-red-600"
                      >
                        <Trash2 size={14} />
                        Archive
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selected ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/50 p-4">
          <div className="max-h-[90vh] w-full max-w-3xl overflow-auto rounded-[28px] bg-white p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.16em] text-emerald-600">
                  Application Details
                </p>
                <h3 className="mt-2 text-2xl font-black text-[#062f66]">
                  {selected.name || "Unknown Applicant"}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="rounded-full border border-slate-200 px-4 py-2 text-sm font-black"
              >
                Close
              </button>
            </div>

            <div className="mt-5 grid gap-3 text-sm md:grid-cols-2">
              {[
                ["Phone", selected.phone],
                ["Email", selected.email],
                ["Position", payloadText(selected.payload, "jobTitle") || payloadText(selected.payload, "department")],
                ["Education", payloadText(selected.payload, "education")],
                ["Experience", payloadText(selected.payload, "experience")],
                ["Expected Salary", payloadText(selected.payload, "expectedSalary")],
                ["Resume File", payloadText(selected.payload, "resumeFileName")],
                ["Status", selected.status],
                ["Submitted", formatDateTime(selected.createdAt)],
              ].map(([label, value]) => (
                <div key={label} className="rounded-2xl bg-slate-50 p-4">
                  <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">
                    {label}
                  </p>
                  <p className="mt-2 font-bold text-[#062f66]">{value || "-"}</p>
                </div>
              ))}
            </div>

            <div className="mt-4 rounded-2xl bg-slate-50 p-4">
              <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">
                Message
              </p>
              <p className="mt-2 whitespace-pre-wrap text-sm font-semibold leading-7 text-slate-700">
                {selected.message || "-"}
              </p>
            </div>

            <div className="mt-4 rounded-2xl bg-slate-900 p-4">
              <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-300">
                Raw Payload
              </p>
              <pre className="mt-2 max-h-72 overflow-auto text-xs leading-6 text-slate-100">
                {JSON.stringify(selected.payload, null, 2)}
              </pre>
            </div>

            <div className="mt-5 flex flex-wrap justify-end gap-2">
              <button
                type="button"
                onClick={() => void updateStatus(selected.id, "IN_PROGRESS")}
                className="inline-flex items-center gap-2 rounded-full bg-[#062f66] px-4 py-2 text-sm font-black text-white"
              >
                <CheckCircle2 size={16} />
                Mark In Progress
              </button>
              <button
                type="button"
                onClick={() => void archiveApplication(selected.id)}
                className="inline-flex items-center gap-2 rounded-full border border-red-200 px-4 py-2 text-sm font-black text-red-600"
              >
                <Trash2 size={16} />
                Archive
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}

