"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";

export type LocalContentItem = {
  id: string;
  slug: string;
  title: string;
  date: string;
  category: string;
  image: string;
  excerpt: string;
  leadText: string;
  body: string[];
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
  author?: string;
};

type FormState = {
  id: string;
  slug: string;
  title: string;
  author: string;
  date: string;
  category: string;
  image: string;
  excerpt: string;
  leadText: string;
  bodyText: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
};

type LocalContentAdminProps<T extends LocalContentItem> = {
  title: string;
  eyebrow: string;
  description: string;
  defaultItems: T[];
  getItems?: () => T[];
  saveItems?: (items: T[]) => void;
  slugify: (value: string) => string;
  fileToDataUrl: (file: File) => Promise<string>;
  linesToParagraphs: (value: string) => string[];
  formatDate: (value: string) => string;
  defaultCategory: string;
  defaultImage: string;
  authorLabel?: string;
  apiBasePath?: string;
  remoteEventName?: string;
};

function makeId(prefix: string) {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function itemToForm<T extends LocalContentItem>(
  item: T | undefined,
  defaultCategory: string,
  defaultImage: string,
  idPrefix: string,
): FormState {
  return {
    id: item?.id || makeId(idPrefix),
    slug: item?.slug || "",
    title: item?.title || "",
    author: item?.author || "",
    date: item?.date || new Date().toISOString().slice(0, 10),
    category: item?.category || defaultCategory,
    image: item?.image || defaultImage,
    excerpt: item?.excerpt || "",
    leadText: item?.leadText || "",
    bodyText: item?.body.join("\n") || "",
    active: item?.active ?? true,
    sortOrder: item?.sortOrder || 10,
    createdAt: item?.createdAt || new Date().toISOString(),
  };
}

function makeUniqueSlug<T extends LocalContentItem>(
  items: T[],
  baseSlug: string,
  currentId: string,
  fallback: string,
) {
  const rootSlug = baseSlug || fallback;
  let slug = rootSlug;
  let counter = 2;

  while (items.some((item) => item.slug === slug && item.id !== currentId)) {
    slug = `${rootSlug}-${counter}`;
    counter += 1;
  }

  return slug;
}

export default function LocalContentAdmin<T extends LocalContentItem>({
  title,
  eyebrow,
  description,
  defaultItems,
  getItems,
  saveItems,
  slugify,
  fileToDataUrl,
  linesToParagraphs,
  formatDate,
  defaultCategory,
  defaultImage,
  authorLabel,
  apiBasePath,
  remoteEventName,
}: LocalContentAdminProps<T>) {
  const idPrefix = slugify(title) || "content";
  const [items, setItems] = useState<T[]>(() =>
    getItems ? getItems() : defaultItems,
  );
  const [form, setForm] = useState<FormState>(() =>
    itemToForm(undefined, defaultCategory, defaultImage, idPrefix),
  );
  const [openForm, setOpenForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");
  const [isSyncing, setIsSyncing] = useState(false);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  useEffect(() => {
    if (!apiBasePath) return;
    const apiUrl = apiBasePath;
    let mounted = true;

    async function loadRemoteItems() {
      try {
        setIsSyncing(true);
        const response = await fetch(apiUrl, { cache: "no-store" });
        const data = (await response.json().catch(() => null)) as {
          items?: T[];
          message?: string;
        } | null;

        if (!response.ok) {
          throw new Error(data?.message || "Failed to load content.");
        }

        if (mounted && Array.isArray(data?.items)) {
          setItems([...data.items].sort((a, b) => a.sortOrder - b.sortOrder));
        }
      } catch (error) {
        if (mounted) {
          showToast(
            error instanceof Error ? error.message : "Failed to load content.",
          );
        }
      } finally {
        if (mounted) setIsSyncing(false);
      }
    }

    void loadRemoteItems();

    return () => {
      mounted = false;
    };
  }, [apiBasePath]);

  const filteredItems = useMemo(() => {
    const keyword = search.toLowerCase().trim();

    return [...items]
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .filter((item) => {
        if (!keyword) return true;
        return [
          item.title,
          item.author || "",
          item.category,
          item.date,
          item.excerpt,
          item.leadText,
          item.slug,
          item.body.join(" "),
        ]
          .join(" ")
          .toLowerCase()
          .includes(keyword);
      });
  }, [items, search]);

  function persist(nextItems: T[], message: string) {
    const sorted = [...nextItems].sort((a, b) => a.sortOrder - b.sortOrder);
    setItems(sorted);
    saveItems?.(sorted);
    showToast(message);
  }

  function emitRemoteChange() {
    if (remoteEventName) window.dispatchEvent(new Event(remoteEventName));
  }

  async function requestRemoteItem(url: string, init: RequestInit) {
    const response = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init.headers || {}),
      },
    });
    const data = (await response.json().catch(() => null)) as {
      item?: T;
      items?: T[];
      message?: string;
    } | null;

    if (!response.ok) {
      throw new Error(data?.message || "Content sync failed.");
    }

    return data;
  }

  function updateField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleImageUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      showToast("Only image file allowed.");
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      showToast("Keep image size under 3MB.");
      return;
    }

    try {
      if (apiBasePath) {
        const formData = new FormData();
        formData.append("file", file);

        const response = await fetch("/api/admin/uploads", {
          method: "POST",
          body: formData,
        });
        const data = (await response.json().catch(() => null)) as {
          ok?: boolean;
          url?: string;
          message?: string;
        } | null;

        if (!response.ok || !data?.ok || !data.url) {
          throw new Error(data?.message || "Image upload failed.");
        }

        updateField("image", data.url);
        showToast("Image uploaded to media library.");
        return;
      }

      updateField("image", await fileToDataUrl(file));
      showToast("Image uploaded.");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Image upload failed.");
    }
  }

  function openAddForm() {
    setEditingId(null);
    setForm(itemToForm(undefined, defaultCategory, defaultImage, idPrefix));
    setOpenForm(true);
  }

  function openEditForm(item: T) {
    setEditingId(item.id);
    setForm(itemToForm(item, defaultCategory, defaultImage, idPrefix));
    setOpenForm(true);
  }

  function closeForm() {
    setEditingId(null);
    setOpenForm(false);
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const itemTitle = form.title.trim();
    const body = linesToParagraphs(form.bodyText);

    if (!itemTitle) return showToast("Title required.");
    if (authorLabel && !form.author.trim())
      return showToast(`${authorLabel} required.`);
    if (!form.date) return showToast("Date required.");
    if (!form.excerpt.trim()) return showToast("Excerpt required.");
    if (!form.leadText.trim()) return showToast("Lead text required.");
    if (!body.length) return showToast("Minimum 1 paragraph required.");

    const now = new Date().toISOString();
    const payload = {
      id: form.id,
      slug: makeUniqueSlug(
        items,
        slugify(form.slug || itemTitle),
        form.id,
        idPrefix,
      ),
      title: itemTitle,
      author: form.author.trim(),
      date: form.date,
      category: form.category.trim() || defaultCategory,
      image: form.image.trim() || defaultImage,
      excerpt: form.excerpt.trim(),
      leadText: form.leadText.trim(),
      body,
      active: form.active,
      sortOrder: Number(form.sortOrder) || 10,
      createdAt: form.createdAt,
      updatedAt: now,
    } as T;

    if (apiBasePath) {
      try {
        setIsSyncing(true);
        const data = await requestRemoteItem(
          editingId ? `${apiBasePath}/${editingId}` : apiBasePath,
          {
            method: editingId ? "PUT" : "POST",
            body: JSON.stringify(payload),
          },
        );
        const saved = data?.item || payload;
        const nextItems = editingId
          ? items.map((item) => (item.id === editingId ? saved : item))
          : [...items, saved];
        setItems([...nextItems].sort((a, b) => a.sortOrder - b.sortOrder));
        emitRemoteChange();
        showToast(
          editingId
            ? `${title} updated successfully.`
            : `${title} added successfully.`,
        );
        closeForm();
      } catch (error) {
        showToast(error instanceof Error ? error.message : "Save failed.");
      } finally {
        setIsSyncing(false);
      }
      return;
    }

    persist(
      editingId
        ? items.map((item) => (item.id === editingId ? payload : item))
        : [...items, payload],
      editingId
        ? `${title} updated successfully.`
        : `${title} added successfully.`,
    );
    closeForm();
  }

  async function toggleActive(id: string) {
    const current = items.find((item) => item.id === id);
    if (!current) return;
    const updated = {
      ...current,
      active: !current.active,
      updatedAt: new Date().toISOString(),
    };

    if (apiBasePath) {
      try {
        setIsSyncing(true);
        const data = await requestRemoteItem(`${apiBasePath}/${id}`, {
          method: "PUT",
          body: JSON.stringify(updated),
        });
        const saved = data?.item || updated;
        setItems(items.map((item) => (item.id === id ? saved : item)));
        emitRemoteChange();
        showToast("Visibility updated.");
      } catch (error) {
        showToast(
          error instanceof Error ? error.message : "Visibility update failed.",
        );
      } finally {
        setIsSyncing(false);
      }
      return;
    }

    persist(
      items.map((item) => (item.id === id ? updated : item)),
      "Visibility updated.",
    );
  }

  async function deleteItem(id: string) {
    const item = items.find((entry) => entry.id === id);
    if (!item || !window.confirm(`Delete "${item.title}"?`)) return;

    if (apiBasePath) {
      try {
        setIsSyncing(true);
        await requestRemoteItem(`${apiBasePath}/${id}`, { method: "DELETE" });
        setItems(items.filter((entry) => entry.id !== id));
        emitRemoteChange();
        showToast("Deleted successfully.");
      } catch (error) {
        showToast(error instanceof Error ? error.message : "Delete failed.");
      } finally {
        setIsSyncing(false);
      }
      return;
    }

    persist(
      items.filter((entry) => entry.id !== id),
      "Deleted successfully.",
    );
  }

  async function duplicateItem(item: T) {
    const id = makeId(idPrefix);
    const payload = {
      ...item,
      id,
      slug: makeUniqueSlug(items, `${item.slug}-copy`, id, idPrefix),
      title: `${item.title} Copy`,
      sortOrder: item.sortOrder + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as T;

    if (apiBasePath) {
      try {
        setIsSyncing(true);
        const data = await requestRemoteItem(apiBasePath, {
          method: "POST",
          body: JSON.stringify(payload),
        });
        const saved = data?.item || payload;
        setItems([...items, saved].sort((a, b) => a.sortOrder - b.sortOrder));
        emitRemoteChange();
        showToast("Duplicated.");
      } catch (error) {
        showToast(error instanceof Error ? error.message : "Duplicate failed.");
      } finally {
        setIsSyncing(false);
      }
      return;
    }

    persist([...items, payload], "Duplicated.");
  }

  async function resetDefault() {
    if (!window.confirm(`Reset ${title} to default data?`)) return;

    if (apiBasePath) {
      try {
        setIsSyncing(true);
        const data = await requestRemoteItem(`${apiBasePath}/reset`, { method: "POST" });
        const nextItems = Array.isArray(data?.items) ? data.items : defaultItems;
        setItems([...nextItems].sort((a, b) => a.sortOrder - b.sortOrder));
        emitRemoteChange();
        showToast("Default data restored.");
      } catch (error) {
        showToast(error instanceof Error ? error.message : "Reset failed.");
      } finally {
        setIsSyncing(false);
      }
      return;
    }

    persist(defaultItems, "Default data restored.");
  }

  return (
    <main className="min-h-screen bg-[#f4f8fc] p-4 text-[#002f70] sm:p-7">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 rounded-lg bg-[#002f70] px-4 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section className="border border-[#d7e3f1] bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#8061bd]">
              {eyebrow}
            </p>
            <h1 className="mt-2 text-3xl font-black">{title}</h1>
            <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-[#49668b]">
              {description}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => void resetDefault()}
              disabled={isSyncing}
              className="border border-[#c7d7ea] bg-white px-4 py-3 text-sm font-black disabled:opacity-50"
            >
              Reset Default
            </button>
            <button
              type="button"
              onClick={openAddForm}
              disabled={isSyncing}
              className="bg-[#002f70] px-4 py-3 text-sm font-black text-white disabled:opacity-50"
            >
              Add Item
            </button>
          </div>
        </div>
      </section>

      <section className="mt-4 grid gap-3 border border-[#d7e3f1] bg-white p-4 md:grid-cols-[2fr_1fr_1fr]">
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Search
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search title, date, content..."
            className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
          />
        </label>
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Total
          <input
            value={`${items.length} items`}
            readOnly
            className="h-11 border border-[#c6d6e8] bg-[#f8fbff] px-3 text-sm font-semibold"
          />
        </label>
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Public active
          <input
            value={`${items.filter((item) => item.active).length} active`}
            readOnly
            className="h-11 border border-[#c6d6e8] bg-[#f8fbff] px-3 text-sm font-semibold"
          />
        </label>
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-2">
        {filteredItems.map((item) => (
          <article
            key={item.id}
            className={`overflow-hidden border border-[#d5e2f0] bg-white shadow-sm ${item.active ? "" : "opacity-60"}`}
          >
            <div className="grid sm:grid-cols-[210px_1fr]">
              <div className="relative min-h-56 bg-[#dfeaf6]">
                <img
                  src={item.image}
                  alt={item.title}
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <span
                  className={`absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-black text-white ${item.active ? "bg-[#079455]" : "bg-[#b42318]"}`}
                >
                  {item.active ? "Active" : "Hidden"}
                </span>
              </div>
              <div className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-black tracking-[0.18em] text-[#8061bd]">
                      {formatDate(item.date)}{" "}
                      {item.category ? `| ${item.category}` : ""}
                    </p>
                    <h2 className="mt-2 text-xl font-black leading-7">
                      {item.title}
                    </h2>
                    {authorLabel && item.author ? (
                      <p className="mt-1 text-sm font-black text-[#49668b]">
                        {item.author}
                      </p>
                    ) : null}
                  </div>
                  <strong className="rounded-full bg-[#eef6ff] px-3 py-1 text-xs">
                    Sort: {item.sortOrder}
                  </strong>
                </div>
                <p className="mt-3 line-clamp-2 text-sm font-semibold leading-6 text-[#49668b]">
                  {item.excerpt}
                </p>
                <div className="mt-3 flex flex-wrap gap-2 text-xs font-black text-[#27527d]">
                  <span className="rounded-full bg-[#eef6ff] px-3 py-1">
                    /{item.slug}
                  </span>
                  <span className="rounded-full bg-[#eef6ff] px-3 py-1">
                    {item.body.length} paragraphs
                  </span>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => openEditForm(item)}
                    className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => void toggleActive(item.id)}
                    disabled={isSyncing}
                    className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black disabled:opacity-50"
                  >
                    {item.active ? "Hide" : "Show"}
                  </button>
                  <button
                    type="button"
                    onClick={() => void duplicateItem(item)}
                    disabled={isSyncing}
                    className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black disabled:opacity-50"
                  >
                    Duplicate
                  </button>
                  <button
                    type="button"
                    onClick={() => void deleteItem(item.id)}
                    disabled={isSyncing}
                    className="border border-[#ffd1d1] bg-[#fff1f1] px-3 py-2 text-sm font-black text-[#b42318] disabled:opacity-50"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </article>
        ))}
      </section>

      {openForm ? (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-auto bg-slate-900/50 p-4 backdrop-blur-sm">
          <form
            onSubmit={handleSubmit}
            className="max-h-[92vh] w-full max-w-5xl overflow-auto bg-white p-4 shadow-2xl"
          >
            <div className="mb-4 flex flex-wrap items-start justify-between gap-4">
              <div>
                <h2 className="text-xl font-black">
                  {editingId ? `Edit ${title}` : `Add ${title}`}
                </h2>
                <p className="mt-1 text-sm font-semibold text-[#49668b]">
                  Add image, title, date, category, content, sorting and
                  visibility.
                </p>
              </div>
              <button
                type="button"
                onClick={closeForm}
                className="border border-[#c6d6e8] bg-white px-4 py-3 text-sm font-bold"
              >
                Close
              </button>
            </div>

            <div className="mb-4 grid gap-3 md:grid-cols-[110px_1fr]">
              <div className="h-[110px] overflow-hidden border border-[#c6d6e8] bg-[#f8fbff]">
                {form.image ? (
                  <img
                    src={form.image}
                    alt="Preview"
                    className="h-full w-full object-cover"
                  />
                ) : null}
              </div>
              <div className="grid gap-3">
                <input
                  value={form.image}
                  onChange={(event) => updateField("image", event.target.value)}
                  placeholder={defaultImage}
                  className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none"
                />
                <label className="inline-flex w-fit cursor-pointer bg-[#071126] px-4 py-3 text-sm font-black text-white">
                  Choose File
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <FormInput
                label="Title *"
                value={form.title}
                onChange={(value) => updateField("title", value)}
              />
              {authorLabel ? (
                <FormInput
                  label={`${authorLabel} *`}
                  value={form.author}
                  onChange={(value) => updateField("author", value)}
                />
              ) : null}
              <FormInput
                label="Date *"
                type="date"
                value={form.date}
                onChange={(value) => updateField("date", value)}
              />
              <FormInput
                label="Category"
                value={form.category}
                onChange={(value) => updateField("category", value)}
              />
              <FormInput
                label="Slug"
                value={form.slug}
                onChange={(value) => updateField("slug", value)}
              />
              <FormInput
                label="Sort order"
                type="number"
                value={String(form.sortOrder)}
                onChange={(value) => updateField("sortOrder", Number(value))}
              />
            </div>

            <FormTextarea
              label="Card short text / excerpt *"
              rows={3}
              value={form.excerpt}
              onChange={(value) => updateField("excerpt", value)}
            />
            <FormTextarea
              label="Detail lead text *"
              rows={3}
              value={form.leadText}
              onChange={(value) => updateField("leadText", value)}
            />
            <FormTextarea
              label="Detail paragraphs *"
              rows={9}
              value={form.bodyText}
              onChange={(value) => updateField("bodyText", value)}
              help="One line = one paragraph."
            />

            <label className="mt-4 flex items-center gap-2 text-sm font-black">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(event) =>
                  updateField("active", event.target.checked)
                }
              />
              Active
            </label>

            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={closeForm}
                className="border border-[#c7d7ea] bg-white px-5 py-3 text-sm font-black"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSyncing}
                className="bg-[#002f70] px-5 py-3 text-sm font-black text-white disabled:opacity-50"
              >
                {editingId ? "Update" : "Add"}
              </button>
            </div>
          </form>
        </div>
      ) : null}
    </main>
  );
}

function FormInput({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none"
      />
    </label>
  );
}

function FormTextarea({
  label,
  value,
  onChange,
  rows,
  help,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  rows: number;
  help?: string;
}) {
  return (
    <label className="mt-4 grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <textarea
        rows={rows}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="resize-y border border-[#c6d6e8] px-3 py-3 text-sm font-semibold leading-6 outline-none"
      />
      {help ? (
        <small className="text-xs font-bold normal-case text-[#687f9e]">
          {help}
        </small>
      ) : null}
    </label>
  );
}
