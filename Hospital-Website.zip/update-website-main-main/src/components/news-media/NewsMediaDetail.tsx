// File: clinic-website/src/components/news-media/NewsMediaDetail.tsx

"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Home } from "lucide-react";
import Container from "@/components/common/Container";
import {
  NewsMediaItem,
  formatNewsDate,
  getActiveNewsMedia,
} from "@/lib/newsMedia";
import type { NewsMedia } from "@/data/site";

type NewsMediaDetailProps = {
  news?: NewsMedia | NewsMediaItem;
  slug?: string;
};

function toLocalNews(item?: NewsMedia | NewsMediaItem) {
  if (!item) return null;
  if ("id" in item) return item;

  return {
    id: item.slug,
    slug: item.slug,
    title: item.title,
    date: item.date,
    category: "Media Update",
    image: item.image,
    excerpt: item.excerpt,
    leadText: item.excerpt,
    body: item.content,
    active: true,
    sortOrder: 1,
    createdAt: "2026-06-12T00:00:00.000Z",
    updatedAt: "2026-06-12T00:00:00.000Z",
  };
}

export default function NewsMediaDetail({ news, slug }: NewsMediaDetailProps) {
  const params = useParams();
  const initialNews = useMemo(() => toLocalNews(news), [news]);
  const currentSlug = slug || initialNews?.slug || String(params?.slug || "");
  const [storedNews, setStoredNews] = useState<NewsMediaItem | null>(initialNews);

  useEffect(() => {
    function loadNews() {
      setStoredNews(
        getActiveNewsMedia().find((item) => item.slug === currentSlug) ||
          initialNews
      );
    }

    queueMicrotask(loadNews);
    window.addEventListener("storage", loadNews);
    window.addEventListener("news-media-updated", loadNews);
    return () => {
      window.removeEventListener("storage", loadNews);
      window.removeEventListener("news-media-updated", loadNews);
    };
  }, [currentSlug, initialNews]);

  if (!storedNews) {
    return (
      <main className="grid min-h-[70vh] place-items-center bg-white p-8 text-center text-[#002f70]">
        <div>
          <h1 className="text-2xl font-black">News not found</h1>
          <Link href="/news-media" className="mt-6 inline-flex bg-[#002f70] px-6 py-4 font-black text-white">
            Back to News & Media
          </Link>
        </div>
      </main>
    );
  }

  return (
    <section className="bg-white py-10 sm:py-14 lg:py-16">
      <Container>
        <nav className="flex flex-wrap items-center gap-3 text-base font-bold text-[#062f66]">
          <Link href="/" className="inline-flex items-center gap-1 text-blue-600">
            <Home size={17} />
            Home
          </Link>
          <span className="text-slate-300">›</span>
          <Link href="/news-media" className="text-blue-600">
            News & Media
          </Link>
          <span className="text-slate-300">›</span>
          <span>{storedNews.title}</span>
        </nav>

        <article className="mx-auto mt-14 max-w-5xl">
          <time className="inline-flex border border-[#e2dff6] px-4 py-1 text-[13px] font-semibold uppercase tracking-[0.32em] text-[#8a6bb8]">
            {formatNewsDate(storedNews.date)}
          </time>

          <h1 className="mt-6 text-4xl font-black leading-tight text-[#062f66] sm:text-5xl">
            {storedNews.title}
          </h1>

          <div className="relative mt-10 h-[280px] overflow-hidden rounded-[4px] bg-slate-100 sm:h-[430px]">
            <img
              src={storedNews.image}
              alt={storedNews.title}
              className="h-full w-full object-cover"
            />
          </div>

          <p className="mt-10 text-xl font-semibold leading-9 text-[#062f66]">
            {storedNews.leadText}
          </p>

          <div className="mt-8 space-y-6 text-lg leading-8 text-slate-700">
            {storedNews.body.map((paragraph, index) => (
              <p key={`${storedNews.id}-${index}`}>{paragraph}</p>
            ))}
          </div>

          <Link
            href="/news-media"
            className="mt-10 inline-flex bg-[#062f66] px-8 py-4 text-sm font-black text-white transition hover:bg-[#5bc0de]"
          >
            Back to News & Media
          </Link>
        </article>
      </Container>
    </section>
  );
}
