// File: clinic-website/src/components/news-media/NewsMediaCard.tsx

import Link from "next/link";
import { formatNewsDate, type NewsMediaItem } from "@/lib/newsMedia";

type NewsMediaCardProps = {
  news: NewsMediaItem;
};

export default function NewsMediaCard({ news }: NewsMediaCardProps) {
  return (
    <article className="group relative overflow-hidden rounded-[20px] border border-[#e8eef7] bg-white shadow-[0_16px_42px_rgba(6,47,102,0.08)] transition-all duration-500 hover:-translate-y-1 hover:border-[#8a6bb8]/25 hover:shadow-[0_26px_70px_rgba(6,47,102,0.14)] sm:rounded-[24px]">
      {/* Top Glow */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 h-px bg-gradient-to-r from-transparent via-[#8a6bb8]/45 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

      {/* Image */}
      <div className="relative h-[200px] overflow-hidden bg-[#eef5ff] sm:h-[220px]">
        <img
          src={news.image}
          alt={news.title}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />

        {/* Image Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#062f66]/70 via-[#062f66]/10 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-95" />

        {/* Floating Date Badge */}
        <time className="absolute bottom-4 left-4 inline-flex rounded-full border border-white/25 bg-white/90 px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] text-[#062f66] shadow-[0_12px_30px_rgba(6,47,102,0.18)] backdrop-blur-md">
          {formatNewsDate(news.date)}
        </time>

        {/* Corner Icon */}
        <div className="absolute right-4 top-4 flex h-11 w-11 items-center justify-center rounded-full border border-white/25 bg-white/20 text-white shadow-[0_12px_30px_rgba(6,47,102,0.18)] backdrop-blur-md transition-all duration-500 group-hover:rotate-45 group-hover:bg-white group-hover:text-[#062f66]">
          <span className="text-xl leading-none">↗</span>
        </div>
      </div>

      {/* Content */}
      <div className="relative p-5 sm:min-h-[205px] sm:p-6">
        <div className="pointer-events-none absolute right-[-55px] top-[-55px] h-[140px] w-[140px] rounded-full bg-[#8a6bb8]/10 blur-[45px] transition-all duration-500 group-hover:bg-[#43c7f4]/15" />

        <div className="relative z-10">
          <span className="mb-4 inline-flex items-center gap-2 rounded-full bg-[#f3f7ff] px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] text-[#8a6bb8] ring-1 ring-[#062f66]/8">
            <span className="h-1.5 w-1.5 rounded-full bg-[#43c7f4] shadow-[0_0_0_4px_rgba(67,199,244,0.12)]" />
            {news.category}
          </span>

          <h2 className="text-lg font-black leading-7 text-[#062f66] transition-colors duration-300 group-hover:text-[#8a6bb8] sm:min-h-[86px] sm:text-xl">
            {news.title}
          </h2>

          <Link
            href={`/news-media/${news.slug}`}
            className="group/link mt-5 inline-flex min-h-11 items-center gap-3 text-sm font-black uppercase tracking-[0.08em] text-[#43c7f4] transition-colors duration-300 hover:text-[#8cc63f] sm:mt-6"
          >
            <span className="relative inline-block after:absolute after:left-0 after:-bottom-[7px] after:h-[3px] after:w-0 after:rounded-full after:bg-gradient-to-r after:from-[#43c7f4] after:via-[#8cc63f] after:to-[#43c7f4] after:shadow-[0_0_12px_rgba(67,199,244,0.55)] after:transition-all after:duration-300 group-hover/link:after:w-full">
              Read More
            </span>

            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#43c7f4]/10 text-lg leading-none text-[#43c7f4] transition-all duration-300 group-hover/link:translate-x-1 group-hover/link:bg-[#8cc63f]/15 group-hover/link:text-[#8cc63f]">
              →
            </span>
          </Link>
        </div>
      </div>
    </article>
  );
}
