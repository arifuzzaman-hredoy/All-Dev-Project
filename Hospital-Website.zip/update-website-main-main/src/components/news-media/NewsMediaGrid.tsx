// File: clinic-website/src/components/news-media/NewsMediaGrid.tsx

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Container from "@/components/common/Container";
import NewsMediaCard from "@/components/news-media/NewsMediaCard";
import {
  DEFAULT_NEWS_MEDIA,
  NewsMediaItem,
  getActiveNewsMedia,
} from "@/lib/newsMedia";

export default function NewsMediaGrid() {
  const [items, setItems] = useState<NewsMediaItem[]>(() =>
    DEFAULT_NEWS_MEDIA.filter((item) => item.active).sort(
      (a, b) => a.sortOrder - b.sortOrder,
    ),
  );

  useEffect(() => {
    function loadItems() {
      setItems(getActiveNewsMedia());
    }

    loadItems();
    window.addEventListener("storage", loadItems);
    window.addEventListener("news-media-updated", loadItems);
    return () => {
      window.removeEventListener("storage", loadItems);
      window.removeEventListener("news-media-updated", loadItems);
    };
  }, []);

  return (
    <section className="relative overflow-hidden bg-[linear-gradient(180deg,#f8fbff_0%,#ffffff_48%,#f3f7ff_100%)] py-10 sm:py-14 lg:py-20">
      {/* Premium Background Effects */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-[-160px] top-[-120px] h-[360px] w-[360px] rounded-full bg-[#062f66]/10 blur-[90px]" />
        <div className="absolute right-[-150px] top-32 h-[420px] w-[420px] rounded-full bg-[#8a6bb8]/16 blur-[100px]" />
        <div className="absolute bottom-[-180px] left-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-[#2f80ed]/10 blur-[100px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,47,102,0.08)_1px,transparent_0)] [background-size:26px_26px]" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062f66]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#8a6bb8]/20 to-transparent" />
      </div>

      <Container>
        <div className="relative z-10 mx-auto max-w-[1245px]">
          {/* Section Header */}
          <div className="mx-auto max-w-[760px] text-center">
            <div className="mx-auto mb-5 inline-flex items-center rounded-full border border-[#062f66]/10 bg-white/75 px-4 py-2 shadow-[0_12px_35px_rgba(6,47,102,0.08)] backdrop-blur-md">
              <span className="mr-2 h-2 w-2 rounded-full bg-[#8a6bb8] shadow-[0_0_0_5px_rgba(138,107,184,0.12)]" />
              <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
                News & Media
              </span>
            </div>

            <h1 className="text-3xl font-black leading-tight text-[#062f66] sm:text-4xl lg:text-5xl">
              Latest News &{" "}
              <span className="relative inline-block">
                Media Updates
                <span className="absolute -bottom-2 left-0 h-[6px] w-full rounded-full bg-gradient-to-r from-[#8a6bb8]/70 via-[#2f80ed]/45 to-transparent" />
              </span>
            </h1>

            <p className="mx-auto mt-4 max-w-[620px] text-sm font-medium leading-7 text-[#4d6380] sm:mt-6 sm:text-base lg:text-lg lg:leading-8">
              Stay connected with our latest healthcare updates, announcements,
              media coverage, and important clinic news.
            </p>
          </div>

          {/* News Cards */}
          <div className="mt-8 grid gap-5 sm:mt-12 sm:gap-6 md:grid-cols-3">
            {items.map((news) => (
              <div
                key={news.slug}
                className="group rounded-[22px] bg-white/70 p-1.5 shadow-[0_16px_45px_rgba(6,47,102,0.08)] ring-1 ring-[#062f66]/8 backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white hover:shadow-[0_24px_60px_rgba(6,47,102,0.14)] sm:rounded-[28px] sm:p-2"
              >
                <NewsMediaCard news={news} />
              </div>
            ))}
          </div>

          {/* Button */}
          <div className="mt-8 flex justify-center sm:mt-12">
            <Link
              href="/news-media"
              className="group relative inline-flex min-h-12 w-full items-center justify-center overflow-hidden rounded-full bg-[#062f66] px-6 py-3 text-sm font-black uppercase tracking-[0.06em] text-white shadow-[0_18px_45px_rgba(6,47,102,0.24)] transition-all duration-300 hover:-translate-y-[2px] hover:bg-[#43c7f4] hover:shadow-[0_22px_55px_rgba(67,199,244,0.28)] sm:w-auto sm:min-w-[245px] sm:px-8 sm:py-4"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <span className="absolute inset-y-0 left-0 w-12 -translate-x-16 rotate-12 bg-white/25 blur-sm transition-transform duration-700 group-hover:translate-x-[290px]" />
              <span className="relative z-10">View All News & Media</span>
            </Link>
          </div>
        </div>
      </Container>
    </section>
  );
}
