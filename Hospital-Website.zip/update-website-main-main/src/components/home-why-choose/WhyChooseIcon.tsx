import {
  Activity,
  Ambulance,
  Apple,
  Baby,
  Bone,
  Brain,
  ClipboardPlus,
  Cross,
  Ear,
  Eye,
  FlaskConical,
  Headphones,
  Heart,
  HeartPulse,
  Hospital,
  Microscope,
  Pill,
  Ribbon,
  ShieldCheck,
  Smile,
  Stethoscope,
  Syringe,
  UserRoundCheck,
  Users,
  type LucideIcon,
} from "lucide-react";

import type { WhyChooseIconName } from "@/types/home-why-choose";

export const whyChooseIconMap = {
  Activity,
  Ambulance,
  Apple,
  Baby,
  Bone,
  Brain,
  ClipboardPlus,
  Cross,
  Ear,
  Eye,
  FlaskConical,
  Headphones,
  Heart,
  HeartPulse,
  Hospital,
  Microscope,
  Pill,
  Ribbon,
  ShieldCheck,
  Smile,
  Stethoscope,
  Syringe,
  UserRoundCheck,
  Users,
} satisfies Record<WhyChooseIconName, LucideIcon>;

type WhyChooseIconProps = {
  name?: string;
  size?: number;
  className?: string;
};

export default function WhyChooseIcon({
  name = "HeartPulse",
  size = 24,
  className,
}: WhyChooseIconProps) {
  const Icon =
    whyChooseIconMap[name as WhyChooseIconName] || whyChooseIconMap.HeartPulse;

  return <Icon size={size} strokeWidth={1.8} className={className} />;
}
