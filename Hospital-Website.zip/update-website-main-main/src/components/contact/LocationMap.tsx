// File: clinic-website/src/components/contact/LocationMap.tsx

import Link from "next/link";
import { ExternalLink, MapPin, Navigation, Phone, Star } from "lucide-react";

export default function LocationMap() {
  const clinicName = "Update Diagnostic Center";
  const address = "Rangpur, Bangladesh";
  const phone = "10666";

  const mapQuery = encodeURIComponent(`${clinicName}, ${address}`);

  const mapEmbedUrl = `https://www.google.com/maps?q=${mapQuery}&output=embed`;
  const googleMapUrl = `https://www.google.com/maps/search/?api=1&query=${mapQuery}`;
  const directionUrl = `https://www.google.com/maps/dir/?api=1&destination=${mapQuery}`;

  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-8 sm:py-12 lg:py-16">
      {/* Soft Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(180deg,#ffffff_0%,#f4f9ff_55%,#ffffff_100%)]" />
        <div className="absolute left-[-160px] top-[-120px] h-[320px] w-[320px] rounded-full bg-[#43c7f4]/12 blur-[90px]" />
        <div className="absolute right-[-170px] bottom-[-130px] h-[360px] w-[360px] rounded-full bg-[#8a6bb8]/12 blur-[95px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,47,102,0.055)_1px,transparent_0)] [background-size:28px_28px]" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-[1320px] px-4 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-[20px] border border-white/80 bg-white/75 p-1.5 shadow-[0_18px_55px_rgba(6,47,102,0.10)] backdrop-blur-xl sm:rounded-[30px] sm:p-2 sm:shadow-[0_26px_80px_rgba(6,47,102,0.12)]">
          <div className="relative h-[320px] w-full overflow-hidden rounded-[16px] bg-[#eef5ff] sm:h-[500px] sm:rounded-[24px] lg:h-[560px]">
            <iframe
              src={mapEmbedUrl}
              title={`${clinicName} location map`}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="absolute inset-0 h-full w-full border-0"
              allowFullScreen
            />

            {/* Map Overlay */}
            <div className="pointer-events-none absolute inset-0 hidden bg-[linear-gradient(90deg,rgba(6,47,102,0.18)_0%,rgba(6,47,102,0.04)_36%,transparent_70%)] sm:block" />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-white/5 via-transparent to-white/10 sm:from-white/10 sm:to-white/15" />

            {/* Location Card - hidden on phone, visible from tablet/desktop */}
            <div className="absolute left-6 top-6 z-10 hidden w-[360px] overflow-hidden rounded-[24px] border border-white/80 bg-white/95 shadow-[0_22px_65px_rgba(6,47,102,0.20)] backdrop-blur-xl sm:block">
              <div className="h-1.5 bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8] to-[#062f66]" />

              <div className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <span className="mb-3 inline-flex rounded-full bg-[#eef7ff] px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] text-[#8a6bb8]">
                      Our Location
                    </span>

                    <h2 className="text-xl font-black leading-7 tracking-[-0.02em] text-[#062f66]">
                      {clinicName}
                    </h2>

                    <p className="mt-1 text-sm font-semibold text-[#5b6b82]">
                      {address}
                    </p>
                  </div>

                  <Link
                    href={googleMapUrl}
                    target="_blank"
                    className="grid size-10 shrink-0 place-items-center rounded-full bg-[#062f66] text-white shadow-[0_12px_28px_rgba(6,47,102,0.22)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#43c7f4] hover:shadow-[0_16px_35px_rgba(67,199,244,0.28)]"
                    aria-label="Open location in Google Maps"
                  >
                    <ExternalLink size={18} />
                  </Link>
                </div>

                <div className="mt-4 flex items-center gap-2 rounded-2xl bg-[#f8fbff] px-4 py-3 text-sm ring-1 ring-[#062f66]/8">
                  <span className="font-black text-[#062f66]">4.8</span>

                  <span className="flex text-[#f5b301]">
                    <Star size={15} fill="currentColor" />
                    <Star size={15} fill="currentColor" />
                    <Star size={15} fill="currentColor" />
                    <Star size={15} fill="currentColor" />
                    <Star size={15} fill="currentColor" />
                  </span>

                  <span className="font-semibold text-slate-500">
                    (120 Reviews)
                  </span>
                </div>

                <div className="mt-4 grid gap-3 text-sm font-bold text-[#4d6380]">
                  <p className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-[0_10px_28px_rgba(6,47,102,0.06)] ring-1 ring-[#062f66]/8">
                    <span className="grid size-9 shrink-0 place-items-center rounded-full bg-[#43c7f4]/12 text-[#43c7f4]">
                      <MapPin size={17} />
                    </span>
                    Visit our diagnostic center
                  </p>

                  <p className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-[0_10px_28px_rgba(6,47,102,0.06)] ring-1 ring-[#062f66]/8">
                    <span className="grid size-9 shrink-0 place-items-center rounded-full bg-[#8a6bb8]/12 text-[#8a6bb8]">
                      <Phone size={17} />
                    </span>
                    Hotline: {phone}
                  </p>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-3">
                  <Link
                    href={directionUrl}
                    target="_blank"
                    className="group inline-flex items-center justify-center gap-2 overflow-hidden rounded-full bg-[#062f66] px-4 py-3 text-sm font-black text-white shadow-[0_14px_30px_rgba(6,47,102,0.22)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#8a6bb8]"
                  >
                    <Navigation
                      size={16}
                      className="transition-transform duration-300 group-hover:translate-x-0.5"
                    />
                    Direction
                  </Link>

                  <Link
                    href={googleMapUrl}
                    target="_blank"
                    className="inline-flex items-center justify-center rounded-full bg-[#eef7ff] px-4 py-3 text-sm font-black text-[#062f66] ring-1 ring-[#062f66]/8 transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#43c7f4] hover:text-white"
                  >
                    View Larger
                  </Link>
                </div>
              </div>
            </div>

            {/* Desktop Bottom Label */}
            <div className="absolute bottom-5 right-5 z-10 hidden rounded-full border border-white/80 bg-white/90 px-5 py-3 text-xs font-black uppercase tracking-[0.12em] text-[#062f66] shadow-[0_16px_40px_rgba(6,47,102,0.16)] backdrop-blur-md sm:block">
              Google Map Location
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
