"use client";

// File: clinic-website/src/components/health/HealthPackageSelector.tsx

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  HealthPackage,
  getActiveHealthPackages,
} from "@/lib/healthPackages";

type HealthPackageSelectorProps = {
  currentSlug: string;
};

export default function HealthPackageSelector({
  currentSlug,
}: HealthPackageSelectorProps) {
  const router = useRouter();
  const [packages, setPackages] = useState<HealthPackage[]>(() =>
    getActiveHealthPackages()
  );

  useEffect(() => {
    function loadPackages() {
      setPackages(getActiveHealthPackages());
    }

    window.addEventListener("storage", loadPackages);
    window.addEventListener("health-packages-updated", loadPackages);

    return () => {
      window.removeEventListener("storage", loadPackages);
      window.removeEventListener("health-packages-updated", loadPackages);
    };
  }, []);

  return (
    <select
      value={currentSlug}
      onChange={(event) => router.push(`/health-check/${event.target.value}`)}
      className="min-h-12 w-full border border-slate-200 bg-white px-4 text-sm font-bold uppercase text-[#062f66] outline-none transition focus:border-[#43c7f4] focus:ring-4 focus:ring-[#43c7f4]/15 lg:w-[425px]"
      aria-label="Select health package"
    >
      {packages.map((item) => (
        <option key={item.slug} value={item.slug}>
          {item.title}
          {item.target ? ` (${item.target})` : ""}
        </option>
      ))}
    </select>
  );
}
