"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  HealthPackage,
  getActiveHealthPackages,
} from "@/lib/healthPackages";
import {
  PackageBooking,
  PaymentMethod,
  addPackageBooking,
  formatDateTime,
  makeBookingId,
  makeReceiptNo,
  makeToken,
} from "@/lib/packageBookings";

type BookingFormState = {
  packageSlug: string;
  patientName: string;
  phone: string;
  age: string;
  gender: string;
  diseaseProblem: string;
  address: string;
  email: string;
  paymentMethod: PaymentMethod;
  paymentNumber: string;
  transactionId: string;
  amountPaid: string;
  requestNote: string;
};

const initialForm: BookingFormState = {
  packageSlug: "",
  patientName: "",
  phone: "",
  age: "",
  gender: "Male",
  diseaseProblem: "",
  address: "",
  email: "",
  paymentMethod: "bKash",
  paymentNumber: "",
  transactionId: "",
  amountPaid: "",
  requestNote: "",
};

export default function HealthPackageBookingForm() {
  const searchParams = useSearchParams();
  const packageSlugFromUrl = searchParams.get("package") || "";
  const [packages, setPackages] = useState<HealthPackage[]>(() =>
    getActiveHealthPackages()
  );
  const [form, setForm] = useState<BookingFormState>(initialForm);
  const [toast, setToast] = useState("");
  const [receipt, setReceipt] = useState<PackageBooking | null>(null);

  useEffect(() => {
    queueMicrotask(() => {
      const activePackages = getActiveHealthPackages();
      setPackages(activePackages);

      const selected =
        activePackages.find((item) => item.slug === packageSlugFromUrl) ||
        activePackages[0];

      if (selected) {
        setForm((prev) => ({
          ...prev,
          packageSlug: selected.slug,
          amountPaid: selected.price,
        }));
      }
    });
  }, [packageSlugFromUrl]);

  const selectedPackage = useMemo(
    () => packages.find((item) => item.slug === form.packageSlug) || null,
    [packages, form.packageSlug]
  );

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  function updateField<K extends keyof BookingFormState>(
    key: K,
    value: BookingFormState[K]
  ) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function handlePackageChange(slug: string) {
    const item = packages.find((pkg) => pkg.slug === slug);
    setForm((prev) => ({
      ...prev,
      packageSlug: slug,
      amountPaid: item?.price || prev.amountPaid,
    }));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!selectedPackage) return showToast("Please select a package.");
    if (!form.patientName.trim()) return showToast("Patient name required.");
    if (!form.phone.trim()) return showToast("Phone number required.");
    if (!form.age.trim()) return showToast("Age required.");
    if (!form.diseaseProblem.trim()) {
      return showToast("Disease/problem required.");
    }

    if (form.paymentMethod !== "Cash Request") {
      if (!form.paymentNumber.trim()) {
        return showToast("Mobile banking number required.");
      }
      if (!form.transactionId.trim()) {
        return showToast("Transaction ID required.");
      }
    }

    const now = new Date().toISOString();
    const booking: PackageBooking = {
      id: makeBookingId(),
      token: makeToken(),
      receiptNo: makeReceiptNo(),
      packageSlug: selectedPackage.slug,
      packageName: selectedPackage.title,
      packageTarget: selectedPackage.target,
      packageFee: selectedPackage.price,
      patientName: form.patientName.trim(),
      phone: form.phone.trim(),
      age: form.age.trim(),
      gender: form.gender,
      diseaseProblem: form.diseaseProblem.trim(),
      address: form.address.trim(),
      email: form.email.trim(),
      paymentMethod: form.paymentMethod,
      paymentNumber:
        form.paymentMethod === "Cash Request" ? "" : form.paymentNumber.trim(),
      transactionId:
        form.paymentMethod === "Cash Request" ? "" : form.transactionId.trim(),
      amountPaid: selectedPackage.price,
      paymentStatus:
        form.paymentMethod === "Cash Request"
          ? "Cash Request"
          : "Payment Submitted",
      requestNote: form.requestNote.trim(),
      submittedAt: now,
      updatedAt: now,
    };

    addPackageBooking(booking);
    setReceipt(booking);
    showToast("Package request submitted. Cash receipt generated.");
  }

  if (!packages.length) {
    return (
      <main className="grid min-h-[70vh] place-items-center bg-white p-8 text-center text-[#002f70]">
        <div>
          <h1 className="text-2xl font-black">No active package found</h1>
          <p className="mt-2 font-semibold">
            Admin panel থেকে minimum 1টা package active করতে হবে।
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#f3f8ff] p-5 text-[#002f70] sm:p-9">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 rounded-lg bg-[#002f70] px-4 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section className="noPrint mx-auto mb-5 max-w-5xl">
        <p className="text-xs font-black uppercase tracking-[0.22em] text-[#8061bd]">
          Health Package Booking
        </p>
        <h1 className="mt-2 text-3xl font-black">Book Health Check Package</h1>
        <p className="mt-2 font-semibold text-[#486385]">
          Fill patient information, submit payment details, then collect your
          cash receipt.
        </p>
      </section>

      <section className="mx-auto max-w-5xl">
        {!receipt ? (
          <form
            onSubmit={handleSubmit}
            className="border border-[#d5e2f0] bg-white p-5 shadow-sm sm:p-6"
          >
            <h2 className="text-xl font-black">Patient & Payment Form</h2>
            <p className="mt-1 text-sm font-semibold text-[#486385]">
              Package booking request submit korar jonno form fill korun.
            </p>

            <Field label="Select Package *" className="mt-5">
              <select
                value={form.packageSlug}
                onChange={(event) => handlePackageChange(event.target.value)}
                className="field"
              >
                {packages.map((item) => (
                  <option key={item.id} value={item.slug}>
                    {item.title}
                    {item.target ? ` (${item.target})` : ""} - {item.price}
                  </option>
                ))}
              </select>
            </Field>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border border-[#d4e8fb] bg-[#eef7ff] p-4">
              <strong className="text-lg">{selectedPackage?.title}</strong>
              <span className="font-black text-[#486385]">
                {selectedPackage?.target || "Health Package"}
              </span>
              <b className="text-xl text-[#35bbea]">{selectedPackage?.price}</b>
            </div>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <TextInput
                label="Patient Name *"
                value={form.patientName}
                onChange={(value) => updateField("patientName", value)}
                placeholder="Enter patient name"
              />
              <TextInput
                label="Phone *"
                value={form.phone}
                onChange={(value) => updateField("phone", value)}
                placeholder="013XXXXXXXX"
              />
              <TextInput
                label="Age *"
                value={form.age}
                onChange={(value) => updateField("age", value)}
                placeholder="28"
              />
              <Field label="Gender *">
                <select
                  value={form.gender}
                  onChange={(event) => updateField("gender", event.target.value)}
                  className="field"
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </Field>
              <TextInput
                label="Email"
                value={form.email}
                onChange={(value) => updateField("email", value)}
                placeholder="patient@email.com"
              />
              <TextInput
                label="Address"
                value={form.address}
                onChange={(value) => updateField("address", value)}
                placeholder="Rangpur / Dhaka / Bogura"
              />
            </div>

            <Field label="Disease / Problem *" className="mt-4">
              <textarea
                rows={3}
                value={form.diseaseProblem}
                onChange={(event) =>
                  updateField("diseaseProblem", event.target.value)
                }
                placeholder="Fever / Cold / Cough / health check purpose"
                className="field min-h-24 py-3"
              />
            </Field>

            <div className="mt-5 border border-[#d8e6f5] bg-[#f8fbff] p-4">
              <h3 className="text-lg font-black">
                Mobile Banking Payment / Request
              </h3>
              <p className="mt-2 border-l-4 border-[#35bbea] bg-white p-3 text-sm font-semibold leading-6 text-[#36577e]">
                Demo payment instruction: bKash/Nagad/Rocket transaction ID
                দিলে receipt generate হবে। Real gateway ছাড়া এটা automatic
                verified payment না।
              </p>
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <Field label="Payment Method *">
                  <select
                    value={form.paymentMethod}
                    onChange={(event) =>
                      updateField(
                        "paymentMethod",
                        event.target.value as PaymentMethod
                      )
                    }
                    className="field"
                  >
                    <option value="bKash">bKash</option>
                    <option value="Nagad">Nagad</option>
                    <option value="Rocket">Rocket</option>
                    <option value="Upay">Upay</option>
                    <option value="Cash Request">Cash Request</option>
                  </select>
                </Field>
                <Field label="Amount *">
                  <input
                    value={selectedPackage?.price || form.amountPaid}
                    readOnly
                    aria-readonly="true"
                    className="field cursor-not-allowed bg-[#f1f6fc] font-black text-[#002f70]"
                    title="Amount is fixed from selected package"
                  />
                </Field>
                {form.paymentMethod !== "Cash Request" ? (
                  <>
                    <TextInput
                      label="Payment Number *"
                      value={form.paymentNumber}
                      onChange={(value) => updateField("paymentNumber", value)}
                      placeholder="01XXXXXXXXX"
                    />
                    <TextInput
                      label="Transaction ID *"
                      value={form.transactionId}
                      onChange={(value) => updateField("transactionId", value)}
                      placeholder="TXN123456789"
                    />
                  </>
                ) : null}
              </div>
              <Field label="Request Note" className="mt-4">
                <textarea
                  rows={3}
                  value={form.requestNote}
                  onChange={(event) =>
                    updateField("requestNote", event.target.value)
                  }
                  className="field min-h-24 py-3"
                />
              </Field>
            </div>

            <button
              type="submit"
              className="mt-5 bg-[#002f70] px-6 py-4 text-sm font-black text-white"
            >
              Submit Request & Generate Receipt
            </button>
          </form>
        ) : (
          <Receipt receipt={receipt} />
        )}
      </section>
      <style jsx global>{`
        .field {
          min-height: 44px;
          width: 100%;
          border: 1px solid #c8d8eb;
          background: #fff;
          padding: 0 13px;
          color: #002f70;
          font-size: 15px;
          font-weight: 600;
          outline: none;
        }

        textarea.field {
          padding-top: 12px;
          padding-bottom: 12px;
          line-height: 1.5;
          resize: vertical;
        }

        .field:focus {
          border-color: #24a7dc;
          box-shadow: 0 0 0 3px rgba(36, 167, 220, 0.13);
        }

        .field[readonly] {
          cursor: not-allowed;
          background: #f1f6fc;
          color: #002f70;
          font-weight: 900;
        }

        .field[readonly]:focus {
          border-color: #c8d8eb;
          box-shadow: none;
        }

        .receiptAction {
          display: inline-flex;
          min-height: 48px;
          min-width: 168px;
          align-items: center;
          justify-content: center;
          background: #002f70;
          padding: 12px 18px;
          color: #ffffff !important;
          font-size: 14px;
          font-weight: 900;
          line-height: 1.2;
          text-align: center;
          text-decoration: none;
        }

        .receiptPrintArea {
          color: #002f70;
        }

        @media print {
          @page {
            size: A4 portrait;
            margin: 12mm;
          }

          html,
          body {
            width: 210mm;
            min-height: 297mm;
            overflow: visible !important;
            background: #fff !important;
          }

          body * {
            visibility: hidden !important;
          }

          .receiptPrintArea,
          .receiptPrintArea * {
            visibility: visible !important;
          }

          .receiptPrintArea {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            max-width: none;
            border: 0 !important;
            box-shadow: none !important;
            padding: 0 !important;
            background: #fff !important;
          }

          .noPrint {
            display: none !important;
          }

          .receiptPrintArea table {
            page-break-inside: avoid;
          }

          .receiptPrintArea th,
          .receiptPrintArea td,
          .receiptPrintArea span {
            color: #002f70 !important;
          }
        }
      `}</style>
    </main>
  );
}

function Receipt({ receipt }: { receipt: PackageBooking }) {
  return (
    <section className="receiptPrintArea border border-[#d5e2f0] bg-white p-6 shadow-sm">
      <div className="flex flex-wrap justify-between gap-4 border-b-2 border-[#d8e6f5] pb-4">
        <div>
          <h2 className="text-2xl font-black">Update Diagnostic Center</h2>
          <p className="mt-1 font-semibold text-[#486385]">
            Health Package Cash Receipt
          </p>
        </div>
        <button
          type="button"
          onClick={() => window.print()}
          className="noPrint h-11 border border-[#c5d6ea] px-4 text-sm font-black"
        >
          Print Receipt
        </button>
      </div>
      <div className="my-4 grid gap-2 md:grid-cols-4">
        <Info label="Receipt No" value={receipt.receiptNo} />
        <Info label="Token" value={receipt.token} />
        <Info label="Date" value={formatDateTime(receipt.submittedAt)} />
        <Info label="Status" value={receipt.paymentStatus} />
      </div>
      <table className="w-full border-collapse text-sm">
        <tbody>
          {[
            ["Patient Name", receipt.patientName],
            ["Phone", receipt.phone],
            ["Age / Gender", `${receipt.age} / ${receipt.gender}`],
            [
              "Package",
              `${receipt.packageName}${
                receipt.packageTarget ? ` (${receipt.packageTarget})` : ""
              }`,
            ],
            ["Disease / Problem", receipt.diseaseProblem],
            ["Fee", receipt.packageFee],
            ["Payment Method", receipt.paymentMethod],
            ["Payment Number", receipt.paymentNumber || "-"],
            ["Transaction ID", receipt.transactionId || "-"],
            ["Amount Paid", receipt.amountPaid],
          ].map(([label, value]) => (
            <tr key={label}>
              <th className="w-56 border border-[#bfd0e5] bg-[#f1f6fc] p-3 text-left">
                {label}
              </th>
              <td className="border border-[#bfd0e5] p-3">{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-20 flex justify-between gap-8 font-black">
        <span className="w-56 border-t border-[#002f70] pt-2 text-center">
          Patient Signature
        </span>
        <span className="w-56 border-t border-[#002f70] pt-2 text-center">
          Authorized Signature
        </span>
      </div>
      <div className="noPrint mt-6 flex flex-wrap gap-2">
        <Link href="/health-check" className="receiptAction">
          Back to Packages
        </Link>
      </div>
    </section>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <span className="border border-[#d8e6f5] bg-[#f8fbff] p-3 text-sm">
      {label}: <strong>{value}</strong>
    </span>
  );
}

function TextInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <Field label={label}>
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="field"
      />
    </Field>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label className={`grid gap-2 text-xs font-black uppercase text-[#24476e] ${className}`}>
      {label}
      {children}
    </label>
  );
}
