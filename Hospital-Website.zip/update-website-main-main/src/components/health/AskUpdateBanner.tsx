// File: clinic-website/src/components/health/AskUpdateBanner.tsx

import Link from "next/link";
import { ArrowRight, MessageCircle } from "lucide-react";

export default function AskUpdateBanner() {
  return (
    <section className="relative overflow-hidden bg-[#062f66] py-14 text-white sm:py-16">
      <div className="pointer-events-none absolute left-[-120px] top-[-120px] h-[280px] w-[280px] rounded-full bg-[#5bc0de]/18 blur-[90px]" />
      <div className="pointer-events-none absolute bottom-[-140px] right-[-120px] h-[300px] w-[300px] rounded-full bg-[#8cc63f]/12 blur-[95px]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-white/20" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-white/10" />

      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-col gap-8 px-4 sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:px-8">
        <div className="max-w-2xl">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-white/90 shadow-[0_10px_24px_rgba(0,0,0,0.08)] backdrop-blur-sm">
            <MessageCircle size={15} className="text-[#5bc0de]" />
            Update Support
          </div>

          <h2 className="text-3xl font-black tracking-wide sm:text-4xl">
            Ask Update
          </h2>

          <p className="mt-3 text-base font-semibold leading-7 tracking-wide text-white/90 sm:text-lg">
            Looking for world-class care, we are here to support you.
          </p>
        </div>

        <Link
          href="/appointment"
          className="group relative isolate inline-flex h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-lg border border-white/70 bg-white px-10 text-sm font-black tracking-wide shadow-[0_14px_30px_rgba(0,0,0,0.16)] transition-all duration-300 hover:-translate-y-0.5 hover:border-[#5bc0de] hover:bg-[#5bc0de] hover:shadow-[0_18px_40px_rgba(91,192,222,0.28)] sm:w-[185px]"
        >
          <span className="relative z-20 text-[#062f66] transition-colors duration-300 group-hover:text-white">
            Send Query
          </span>

          <ArrowRight
            size={18}
            strokeWidth={2.5}
            className="relative z-20 text-[#062f66] transition-all duration-300 group-hover:translate-x-1 group-hover:text-white"
          />

          <span className="pointer-events-none absolute inset-0 z-0 -translate-x-full bg-gradient-to-r from-transparent via-[#062f66]/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
        </Link>
      </div>
    </section>
  );
}
