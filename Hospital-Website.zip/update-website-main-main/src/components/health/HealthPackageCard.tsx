// File: clinic-website/src/components/health/HealthPackageCard.tsx

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { HealthPackage } from "@/lib/healthPackages";

type HealthPackageCardProps = {
  healthPackage: HealthPackage;
};

export default function HealthPackageCard({
  healthPackage,
}: HealthPackageCardProps) {
  return (
    <article className="group relative h-[270px] overflow-hidden rounded-xl bg-[#062f66] shadow-[0_14px_32px_rgba(6,47,102,0.12)] ring-1 ring-slate-200/70 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_22px_48px_rgba(6,47,102,0.20)] sm:h-[320px]">
      <img
        src={healthPackage.image}
        alt={healthPackage.title}
        className="h-full w-full object-cover transition-all duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:-translate-y-1 group-hover:scale-[1.07]"
      />

      <div className="absolute inset-0 bg-gradient-to-b from-[#0b2f5b]/5 via-[#0b2f5b]/28 to-[#061b3d]/95 transition-opacity duration-500 group-hover:opacity-95" />

      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_80%_10%,rgba(67,199,244,0.18),transparent_35%)] opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

      <div className="pointer-events-none absolute inset-x-5 top-5 h-px bg-white/45 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

      <div className="absolute inset-x-0 bottom-0 p-4 text-white sm:p-5">
        <h2 className="text-lg font-black uppercase leading-6 tracking-wide drop-shadow-[0_2px_10px_rgba(0,0,0,0.22)] sm:text-xl">
          {healthPackage.title}
        </h2>

        {healthPackage.target ? (
          <p className="mt-1 text-sm font-black uppercase tracking-wide text-white/90">
            ({healthPackage.target})
          </p>
        ) : null}

        <Link
          href={`/health-check/${healthPackage.slug}`}
          className="group/link mt-4 inline-flex min-h-11 w-fit items-center gap-2 text-base font-black text-[#43c7f4] transition-all duration-300 hover:text-[#8cc63f] sm:mt-5 sm:text-lg"
        >
          <span className="relative inline-block after:absolute after:left-0 after:-bottom-[6px] after:h-[3px] after:w-0 after:rounded-full after:bg-gradient-to-r after:from-[#43c7f4] after:via-[#8cc63f] after:to-[#43c7f4] after:shadow-[0_0_10px_rgba(140,198,63,0.65)] after:transition-all after:duration-300 group-hover/link:after:w-full">
            See Package
          </span>

          <ArrowRight
            size={20}
            strokeWidth={2.4}
            className="transition-transform duration-300 group-hover/link:translate-x-1"
          />
        </Link>
      </div>
    </article>
  );
}
