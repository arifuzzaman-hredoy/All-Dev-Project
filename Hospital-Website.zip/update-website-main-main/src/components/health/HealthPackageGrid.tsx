// File: clinic-website/src/components/health/HealthPackageGrid.tsx

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Container from "@/components/common/Container";
import AskUpdateBanner from "@/components/health/AskUpdateBanner";
import HealthPackageCard from "@/components/health/HealthPackageCard";
import {
  DEFAULT_HEALTH_PACKAGES,
  HealthPackage,
  getActiveHealthPackages,
} from "@/lib/healthPackages";

export default function HealthPackageGrid() {
  const [packages, setPackages] = useState<HealthPackage[]>(() =>
    DEFAULT_HEALTH_PACKAGES.filter((item) => item.active).sort(
      (a, b) => a.sortOrder - b.sortOrder,
    ),
  );

  useEffect(() => {
    function loadPackages() {
      setPackages(getActiveHealthPackages());
    }

    loadPackages();
    window.addEventListener("storage", loadPackages);
    window.addEventListener("health-packages-updated", loadPackages);

    return () => {
      window.removeEventListener("storage", loadPackages);
      window.removeEventListener("health-packages-updated", loadPackages);
    };
  }, []);

  return (
    <>
      <section className="relative overflow-hidden bg-[#f7fbff] py-10 sm:py-14 lg:py-20">
        {/* Different Premium Background */}
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#eef8ff_42%,#f7f2ff_100%)]" />

          {/* Large Soft Glow */}
          <div className="absolute left-[-180px] top-[-130px] h-[420px] w-[420px] rounded-full bg-[#43c7f4]/16 blur-[105px]" />
          <div className="absolute right-[-190px] bottom-[-150px] h-[460px] w-[460px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
          <div className="absolute left-[38%] top-[42%] h-[360px] w-[360px] rounded-full bg-[#8cc63f]/8 blur-[105px]" />

          {/* Clean Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(6,47,102,0.045)_1px,transparent_1px),linear-gradient(180deg,rgba(6,47,102,0.045)_1px,transparent_1px)] [background-size:44px_44px]" />

          {/* Medical Wave Line */}
          <svg
            aria-hidden="true"
            className="absolute left-1/2 top-[115px] h-[140px] w-[980px] -translate-x-1/2 text-[#43c7f4]/22"
            viewBox="0 0 980 140"
            fill="none"
          >
            <path
              d="M0 82C70 82 70 50 140 50C210 50 210 104 280 104C350 104 350 42 420 42C490 42 490 92 560 92C630 92 630 62 700 62C770 62 770 100 840 100C910 100 910 68 980 68"
              stroke="currentColor"
              strokeWidth="4"
              strokeLinecap="round"
            />
          </svg>

          {/* Floating Glass Shapes */}
          <div className="absolute left-8 top-28 hidden h-24 w-24 rotate-12 rounded-[28px] border border-white/70 bg-white/45 shadow-[0_22px_60px_rgba(6,47,102,0.08)] backdrop-blur-md lg:block" />
          <div className="absolute right-12 top-40 hidden h-16 w-16 rounded-full border border-white/70 bg-white/45 shadow-[0_18px_50px_rgba(138,107,184,0.10)] backdrop-blur-md lg:block" />
          <div className="absolute bottom-28 left-16 hidden h-20 w-20 -rotate-12 rounded-[26px] border border-white/70 bg-white/40 shadow-[0_18px_50px_rgba(67,199,244,0.10)] backdrop-blur-md lg:block" />

          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062f66]/15 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
        </div>

        <Container>
          <div className="relative z-10">
            <div className="mx-auto max-w-3xl text-center">
              <span className="mb-4 inline-flex rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-[#8a6bb8] shadow-[0_12px_32px_rgba(6,47,102,0.07)] backdrop-blur-md">
                Health Packages
              </span>

              <h1 className="text-center text-3xl font-black leading-tight text-[#062f66] sm:text-4xl lg:text-5xl">
                Health Check{" "}
                <span className="relative inline-block text-[#8a6bb8]">
                  Packages
                  <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
                </span>
              </h1>

              <p className="mx-auto mt-4 max-w-2xl text-sm font-semibold leading-7 text-[#4d6380] sm:mt-6 sm:text-base">
                Choose a suitable health check package for preventive care,
                routine screening, and better health planning.
              </p>
            </div>

            <div className="mx-auto mt-8 grid max-w-[1245px] gap-4 sm:mt-12 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
              {packages.map((healthPackage, index) => (
                <div
                  key={healthPackage.slug}
                  className="group rounded-[20px] bg-white/70 p-1.5 shadow-[0_14px_40px_rgba(6,47,102,0.08)] ring-1 ring-[#062f66]/8 backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white hover:shadow-[0_24px_60px_rgba(6,47,102,0.14)] sm:rounded-[26px] sm:p-2"
                  style={{
                    animation:
                      "healthPackageReveal 650ms cubic-bezier(0.22, 1, 0.36, 1) both",
                    animationDelay: `${index * 80}ms`,
                  }}
                >
                  <HealthPackageCard healthPackage={healthPackage} />
                </div>
              ))}
            </div>

            <div className="mt-8 flex justify-center sm:mt-12">
              <Link
                href="/appointment"
                className="group relative inline-flex min-h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-full bg-[#062f66] px-6 py-3 text-sm font-black uppercase tracking-[0.06em] text-white shadow-[0_18px_45px_rgba(6,47,102,0.22)] transition-all duration-300 hover:-translate-y-[2px] hover:bg-[#43c7f4] hover:shadow-[0_24px_60px_rgba(67,199,244,0.28)] sm:w-auto sm:min-w-[235px] sm:px-8 sm:py-4"
              >
                <span className="absolute inset-y-0 left-0 w-12 -translate-x-16 rotate-12 bg-white/25 blur-sm transition-transform duration-700 group-hover:translate-x-[290px]" />

                <span className="relative z-10">View All Packages</span>

                <ArrowRight
                  size={18}
                  className="relative z-10 transition-transform duration-300 group-hover:translate-x-1"
                />
              </Link>
            </div>
          </div>
        </Container>
      </section>

      <AskUpdateBanner />
    </>
  );
}
