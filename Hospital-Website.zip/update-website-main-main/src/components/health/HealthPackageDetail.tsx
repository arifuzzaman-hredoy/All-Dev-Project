// File: clinic-website/src/components/health/HealthPackageDetail.tsx

"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Home } from "lucide-react";
import Container from "@/components/common/Container";
import HealthPackageSelector from "@/components/health/HealthPackageSelector";
import {
  HealthPackage,
  getActiveHealthPackages,
} from "@/lib/healthPackages";
import type { HealthPackage as SiteHealthPackage } from "@/data/site";

type HealthPackageDetailProps = {
  healthPackage?: HealthPackage | SiteHealthPackage;
  slug?: string;
};

function toLocalPackage(item?: HealthPackage | SiteHealthPackage) {
  if (!item) return null;
  if ("id" in item) return item;

  return {
    id: item.slug,
    slug: item.slug,
    title: item.title,
    name: item.title,
    badge: "HEALTH PACKAGES",
    price: item.price,
    target: item.subtitle || "",
    subtitle:
      "Choose a suitable health check package for preventive care, routine screening, and better health planning.",
    image: item.image,
    tests: item.tests,
    active: true,
    sortOrder: 1,
    createdAt: "2026-06-12T00:00:00.000Z",
    updatedAt: "2026-06-12T00:00:00.000Z",
  };
}

export default function HealthPackageDetail({
  healthPackage,
  slug,
}: HealthPackageDetailProps) {
  const initialPackage = useMemo(
    () => toLocalPackage(healthPackage),
    [healthPackage]
  );
  const [storedPackage, setStoredPackage] = useState<HealthPackage | null>(
    initialPackage
  );
  const currentSlug = slug || initialPackage?.slug || "";

  useEffect(() => {
    function loadPackage() {
      const packages = getActiveHealthPackages();
      const nextPackage = packages.find((item) => item.slug === currentSlug);
      setStoredPackage(nextPackage || initialPackage);
    }

    queueMicrotask(loadPackage);
    window.addEventListener("storage", loadPackage);
    window.addEventListener("health-packages-updated", loadPackage);

    return () => {
      window.removeEventListener("storage", loadPackage);
      window.removeEventListener("health-packages-updated", loadPackage);
    };
  }, [currentSlug, initialPackage]);

  const displayTitle = useMemo(() => {
    if (!storedPackage) return "Health Package";

    return storedPackage.target
      ? `${storedPackage.title} (${storedPackage.target})`
      : storedPackage.title;
  }, [storedPackage]);

  if (!storedPackage) {
    return (
      <section className="bg-white py-16">
        <Container>
          <h1 className="text-2xl font-black text-[#062f66]">
            Package not found
          </h1>
          <Link
            href="/health-check"
            className="mt-5 inline-flex bg-[#062f66] px-6 py-3 text-sm font-bold text-white"
          >
            Back to Packages
          </Link>
        </Container>
      </section>
    );
  }

  return (
    <section className="bg-white py-10 sm:py-14 lg:py-16">
      <Container>
        <nav className="flex flex-wrap items-center gap-3 text-base font-bold text-[#062f66]">
          <Link href="/" className="inline-flex items-center gap-1 text-blue-600">
            <Home size={17} />
            Home
          </Link>
          <span className="text-slate-300">›</span>
          <Link href="/health-check" className="text-blue-600">
            Health Check
          </Link>
          <span className="text-slate-300">›</span>
          <span className="uppercase">{displayTitle}</span>
        </nav>

        <div className="mt-20 grid gap-10 lg:grid-cols-[1fr_425px] lg:items-start">
          <div>
            <h1 className="text-2xl font-black uppercase tracking-wide text-[#062f66] sm:text-3xl">
              {displayTitle}
            </h1>
            <p className="mt-8 text-3xl font-black text-[#43c7f4]">
              {storedPackage.price}
            </p>
          </div>

          <aside>
            <h2 className="mb-6 text-xl font-black text-[#062f66]">
              Select Packages
            </h2>
            <HealthPackageSelector currentSlug={storedPackage.slug} />
          </aside>
        </div>

        <div className="mt-14 grid gap-x-24 gap-y-7 lg:grid-cols-2">
          {storedPackage.tests.map((test) => (
            <div key={test} className="flex gap-5">
              <span className="mt-2 size-1.5 shrink-0 rounded-full bg-[#159bd7]" />
              <p className="text-lg font-black uppercase leading-7 text-[#062f66]">
                {test}
              </p>
            </div>
          ))}
        </div>

        <Link
          href={`/health-check/book?package=${encodeURIComponent(
            storedPackage.slug
          )}`}
          className="mt-8 inline-flex min-w-40 justify-center bg-[#062f66] px-8 py-4 text-sm font-bold text-white transition hover:bg-[#8a6bb8]"
        >
          Book Now
        </Link>
      </Container>
    </section>
  );
}
