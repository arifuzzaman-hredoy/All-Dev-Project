import { ExternalLink } from "lucide-react";
import clsx from "clsx";

type CraftedBySignatureProps = {
  variant?: "public" | "admin" | "login";
};

const signatureLink =
  "group/link relative inline-flex items-center gap-1.5 font-semibold transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-transparent";

export default function CraftedBySignature({
  variant = "public",
}: CraftedBySignatureProps) {
  if (variant === "admin") {
    return (
      <div className="px-4 pb-5 sm:px-6 lg:px-8 xl:px-10">
        <div className="mx-auto flex w-full max-w-fit items-center justify-center rounded-2xl border border-slate-200/80 bg-white/80 px-4 py-2.5 text-center text-xs text-slate-500 shadow-sm backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-300/70 hover:bg-white hover:shadow-[0_14px_32px_rgba(8,145,178,0.12)] sm:text-sm">
          <span>Website crafted by&nbsp;</span>
          <a
            href="https://techteamlead.com/"
            target="_blank"
            rel="noreferrer"
            aria-label="Visit Tech Team Lead website"
            className={clsx(
              signatureLink,
              "text-[#062f66] hover:text-cyan-700 after:absolute after:-bottom-0.5 after:left-0 after:h-px after:w-0 after:bg-cyan-500 after:transition-all after:duration-300 hover:after:w-full",
            )}
          >
            Tech Team Lead
            <ExternalLink className="h-3.5 w-3.5 opacity-60 transition group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 group-hover/link:opacity-100" />
          </a>
        </div>
      </div>
    );
  }

  if (variant === "login") {
    return (
      <div className="mt-7 flex justify-center">
        <div className="rounded-full border border-white/70 bg-white/70 px-4 py-2 text-center text-xs text-slate-500 shadow-[0_14px_34px_rgba(15,23,42,0.08)] backdrop-blur-xl transition-all duration-300 hover:border-cyan-200 hover:bg-white/85 sm:text-sm">
          <span>Website crafted by&nbsp;</span>
          <a
            href="https://techteamlead.com/"
            target="_blank"
            rel="noreferrer"
            aria-label="Visit Tech Team Lead website"
            className={clsx(
              signatureLink,
              "text-[#062f66] hover:text-cyan-600 after:absolute after:-bottom-0.5 after:left-0 after:h-px after:w-full after:origin-left after:scale-x-0 after:bg-cyan-500 after:transition-transform after:duration-300 hover:drop-shadow-[0_0_10px_rgba(8,145,178,0.28)] hover:after:scale-x-100",
            )}
          >
            Tech Team Lead
            <ExternalLink className="h-3.5 w-3.5 opacity-60 transition group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 group-hover/link:opacity-100" />
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="border-t border-white/10 bg-black/95 px-4 py-4 text-center">
      <p className="text-xs tracking-wide text-white/50 sm:text-sm">
        Website crafted by{" "}
        <a
          href="https://techteamlead.com/"
          target="_blank"
          rel="noreferrer"
          aria-label="Visit Tech Team Lead website"
          className={clsx(
            signatureLink,
            "text-white/80 hover:bg-gradient-to-r hover:from-cyan-200 hover:to-teal-200 hover:bg-clip-text hover:text-transparent hover:drop-shadow-[0_0_12px_rgba(103,232,249,0.26)] after:absolute after:-bottom-1 after:left-0 after:h-px after:w-full after:origin-left after:scale-x-0 after:bg-gradient-to-r after:from-cyan-300 after:to-teal-300 after:transition-transform after:duration-300 hover:after:scale-x-100",
          )}
        >
          Tech Team Lead
          <ExternalLink className="h-3.5 w-3.5 text-cyan-200/70 transition group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 group-hover/link:text-cyan-200" />
        </a>
      </p>
    </div>
  );
}
