// File: clinic-website/src/components/layout/Footer.tsx

import Image from "next/image";
import Link from "next/link";
import {
  Activity,
  Ambulance,
  ArrowRight,
  Clock3,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";
import Container from "@/components/common/Container";
import { navigation, siteInfo } from "@/data/site-base";
import CraftedBySignature from "@/components/brand/CraftedBySignature";

const footerServices = [
  {
    label: "Emergency Support",
    icon: Ambulance,
  },
  {
    label: "Expert Doctors",
    icon: Stethoscope,
  },
  {
    label: "Modern Diagnosis",
    icon: Activity,
  },
  {
    label: "Trusted Care",
    icon: ShieldCheck,
  },
];

function FooterLogo() {
  return (
    <Link
      href="/"
      aria-label="Go to home"
      className="group relative block h-[72px] w-[190px] overflow-hidden rounded-2xl bg-white p-3 shadow-[0_18px_45px_rgba(0,0,0,0.22)] ring-1 ring-white/20 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_28px_75px_rgba(91,192,222,0.28)] sm:h-[82px] sm:w-[220px]"
    >
      <span className="absolute -left-8 -top-8 size-24 rounded-full bg-[#5bc0de]/20 blur-2xl transition-all duration-500 group-hover:bg-[#5bc0de]/35" />
      <span className="absolute -bottom-8 -right-8 size-24 rounded-full bg-[#8cc63f]/20 blur-2xl transition-all duration-500 group-hover:bg-[#8cc63f]/35" />

      <Image
        src="/update.png"
        alt="Update Diagnostic"
        fill
        priority
        sizes="220px"
        className="object-contain p-3 transition-transform duration-500 group-hover:scale-105"
      />
    </Link>
  );
}

function AnimatedHospitalChart() {
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.06] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_20px_55px_rgba(0,0,0,0.18)] backdrop-blur transition-all duration-500 hover:-translate-y-1 hover:border-[#5bc0de]/40 hover:bg-white/[0.08] hover:shadow-[0_30px_85px_rgba(91,192,222,0.16)] sm:rounded-3xl sm:p-5">
      <span className="absolute -left-14 top-10 size-32 rounded-full bg-[#5bc0de]/15 blur-3xl transition-all duration-500 group-hover:bg-[#5bc0de]/25" />
      <span className="absolute -bottom-14 right-8 size-32 rounded-full bg-[#8cc63f]/15 blur-3xl transition-all duration-500 group-hover:bg-[#8cc63f]/25" />

      <div className="relative mb-5 flex items-center justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-200">
            Live Care Chart
          </p>

          <h3 className="mt-2 text-xl font-black text-white">Patient Flow</h3>
        </div>

        <span className="grid size-10 place-items-center rounded-full bg-[#5bc0de] text-white shadow-[0_12px_28px_rgba(91,192,222,0.38)] transition-all duration-500 group-hover:rotate-[14deg] group-hover:scale-110 group-hover:bg-[#8cc63f] group-hover:shadow-[0_18px_42px_rgba(140,198,63,0.35)] sm:size-12">
          <Activity size={23} />
        </span>
      </div>

      <svg
        viewBox="0 0 420 190"
        className="relative h-[150px] w-full sm:h-[190px]"
        role="img"
        aria-label="Animated hospital chart"
      >
        <defs>
          <linearGradient id="footerChartLine" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor="#5bc0de" />
            <stop offset="45%" stopColor="#8cc63f" />
            <stop offset="100%" stopColor="#f8c846" />
          </linearGradient>

          <linearGradient id="footerChartFill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#5bc0de" stopOpacity="0.38" />
            <stop offset="100%" stopColor="#5bc0de" stopOpacity="0" />
          </linearGradient>

          <filter id="footerGlow">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {[35, 70, 105, 140].map((y) => (
          <line
            key={y}
            x1="0"
            y1={y}
            x2="420"
            y2={y}
            stroke="rgba(255,255,255,0.09)"
            strokeWidth="1"
          />
        ))}

        {[60, 120, 180, 240, 300, 360].map((x) => (
          <line
            key={x}
            x1={x}
            y1="20"
            x2={x}
            y2="160"
            stroke="rgba(255,255,255,0.06)"
            strokeWidth="1"
          />
        ))}

        <path
          d="M 20 150 L 70 125 L 120 135 L 165 78 L 205 92 L 250 45 L 300 75 L 350 40 L 400 58 L 400 170 L 20 170 Z"
          fill="url(#footerChartFill)"
        />

        <path
          d="M 20 150 L 70 125 L 120 135 L 165 78 L 205 92 L 250 45 L 300 75 L 350 40 L 400 58"
          fill="none"
          stroke="url(#footerChartLine)"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter="url(#footerGlow)"
          strokeDasharray="900"
          strokeDashoffset="900"
        >
          <animate
            attributeName="stroke-dashoffset"
            from="900"
            to="0"
            dur="3.1s"
            repeatCount="indefinite"
          />
        </path>

        <circle r="7" fill="#ffffff">
          <animateMotion
            dur="3.1s"
            repeatCount="indefinite"
            path="M 20 150 L 70 125 L 120 135 L 165 78 L 205 92 L 250 45 L 300 75 L 350 40 L 400 58"
          />
        </circle>

        <circle r="16" fill="#5bc0de" opacity="0.2">
          <animateMotion
            dur="3.1s"
            repeatCount="indefinite"
            path="M 20 150 L 70 125 L 120 135 L 165 78 L 205 92 L 250 45 L 300 75 L 350 40 L 400 58"
          />
        </circle>
      </svg>

      <div className="relative mt-4 grid grid-cols-3 gap-2 sm:gap-3">
        {[
          { value: "24/7", label: "Support" },
          { value: "98%", label: "Care Rate" },
          { value: "Fast", label: "Response" },
        ].map((item) => (
          <div
            key={item.label}
            className="rounded-xl bg-white/[0.07] p-2 text-center ring-1 ring-white/10 transition-all duration-300 hover:-translate-y-1 hover:bg-white/[0.11] hover:shadow-[0_14px_35px_rgba(91,192,222,0.14)] sm:rounded-2xl sm:p-3"
          >
            <p className="text-base font-black text-white sm:text-lg">
              {item.value}
            </p>
            <p className="mt-1 text-xs font-semibold text-blue-100">
              {item.label}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Footer() {
  return (
    <>
      <footer className="relative overflow-hidden bg-[#061b3d] text-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(91,192,222,0.24),transparent_32%),radial-gradient(circle_at_bottom_right,rgba(140,198,63,0.18),transparent_34%)]" />
        <div className="absolute left-0 top-0 h-1 w-full bg-gradient-to-r from-[#062f66] via-[#5bc0de] to-[#8cc63f]" />
        <div className="absolute -left-24 top-20 size-72 rounded-full bg-[#5bc0de]/10 blur-3xl" />
        <div className="absolute -right-24 bottom-20 size-72 rounded-full bg-[#8cc63f]/10 blur-3xl" />

        <Container className="relative py-10 sm:py-14 lg:py-20">
          <div className="grid gap-8 sm:gap-10 lg:grid-cols-[1.1fr_0.8fr_0.9fr_1.15fr] lg:gap-12">
            {/* Logo + About */}
            <div>
              <FooterLogo />

              <p className="mt-5 max-w-md text-sm font-medium leading-7 text-blue-100 sm:mt-7 sm:text-[15px] sm:leading-8">
                {siteInfo.description}
              </p>

              <div className="mt-5 grid gap-3 sm:mt-7">
                {footerServices.map((service) => {
                  const Icon = service.icon;

                  return (
                    <div
                      key={service.label}
                      className="group relative overflow-hidden rounded-2xl bg-white/[0.06] px-4 py-3 text-blue-100 ring-1 ring-white/10 transition-all duration-500 hover:-translate-y-1 hover:bg-white/[0.1] hover:text-white hover:shadow-[0_18px_45px_rgba(91,192,222,0.18)]"
                    >
                      <span className="absolute -left-8 top-1/2 size-20 -translate-y-1/2 rounded-full bg-[#5bc0de]/0 blur-2xl transition-all duration-500 group-hover:bg-[#5bc0de]/25" />
                      <span className="absolute -right-8 top-1/2 size-20 -translate-y-1/2 rounded-full bg-[#8cc63f]/0 blur-2xl transition-all duration-500 group-hover:bg-[#8cc63f]/20" />

                      <div className="relative flex items-center gap-3">
                        <span className="grid size-10 place-items-center rounded-full bg-white/10 text-[#5bc0de] shadow-[0_8px_24px_rgba(91,192,222,0.12)] transition-all duration-500 group-hover:rotate-[14deg] group-hover:scale-110 group-hover:bg-[#5bc0de] group-hover:text-white group-hover:shadow-[0_14px_34px_rgba(91,192,222,0.36)]">
                          <Icon size={19} />
                        </span>

                        <span className="text-sm font-bold">{service.label}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          {/* Quick Links */}
          <div>
            <h2 className="text-sm font-black uppercase tracking-[0.18em] text-cyan-200">
              Quick Links
            </h2>

            <nav className="mt-5 grid gap-3 sm:mt-6">
              {navigation.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="group flex w-fit items-center gap-2 text-sm font-semibold text-blue-100 transition hover:text-[#5bc0de]"
                >
                  <span className="grid size-7 place-items-center rounded-full bg-white/5 text-[#5bc0de] shadow-[0_8px_22px_rgba(91,192,222,0.08)] transition-all duration-500 group-hover:rotate-[14deg] group-hover:scale-110 group-hover:bg-[#5bc0de] group-hover:text-white group-hover:shadow-[0_14px_32px_rgba(91,192,222,0.3)]">
                    <ArrowRight size={13} />
                  </span>

                  <span className="relative after:absolute after:left-0 after:-bottom-1 after:h-[2px] after:w-0 after:rounded-full after:bg-[#5bc0de] after:transition-all after:duration-300 group-hover:after:w-full">
                    {item.label}
                  </span>
                </Link>
              ))}
            </nav>
          </div>

          {/* Contact */}
          <div>
            <h2 className="text-sm font-black uppercase tracking-[0.18em] text-cyan-200">
              Contact
            </h2>

            <div className="mt-5 grid gap-3 text-blue-100 sm:mt-6 sm:gap-4">
              <Link
                href={`tel:${siteInfo.phone}`}
                className="group relative flex items-start gap-3 overflow-hidden rounded-2xl bg-white/[0.05] p-4 ring-1 ring-white/10 transition-all duration-500 hover:-translate-y-1 hover:bg-white/[0.09] hover:shadow-[0_18px_45px_rgba(91,192,222,0.18)]"
              >
                <span className="absolute -left-10 top-1/2 size-24 -translate-y-1/2 rounded-full bg-[#5bc0de]/0 blur-2xl transition-all duration-500 group-hover:bg-[#5bc0de]/25" />

                <span className="relative grid size-10 shrink-0 place-items-center rounded-full bg-[#5bc0de] text-white shadow-[0_10px_28px_rgba(91,192,222,0.25)] transition-all duration-500 group-hover:rotate-[14deg] group-hover:scale-110 group-hover:shadow-[0_16px_40px_rgba(91,192,222,0.38)]">
                  <Phone size={18} />
                </span>

                <span className="relative">
                  <span className="block text-xs font-black uppercase tracking-[0.12em] text-cyan-200">
                    Hotline
                  </span>
                  <span className="mt-1 block text-sm font-semibold text-white">
                    {siteInfo.phone}
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-blue-100">
                    Emergency {siteInfo.emergency}
                  </span>
                </span>
              </Link>

              <Link
                href={`mailto:${siteInfo.email}`}
                className="group relative flex items-start gap-3 overflow-hidden rounded-2xl bg-white/[0.05] p-4 ring-1 ring-white/10 transition-all duration-500 hover:-translate-y-1 hover:bg-white/[0.09] hover:shadow-[0_18px_45px_rgba(140,198,63,0.18)]"
              >
                <span className="absolute -left-10 top-1/2 size-24 -translate-y-1/2 rounded-full bg-[#8cc63f]/0 blur-2xl transition-all duration-500 group-hover:bg-[#8cc63f]/25" />

                <span className="relative grid size-10 shrink-0 place-items-center rounded-full bg-[#8cc63f] text-white shadow-[0_10px_28px_rgba(140,198,63,0.22)] transition-all duration-500 group-hover:-rotate-[14deg] group-hover:scale-110 group-hover:shadow-[0_16px_40px_rgba(140,198,63,0.34)]">
                  <Mail size={18} />
                </span>

                <span className="relative">
                  <span className="block text-xs font-black uppercase tracking-[0.12em] text-cyan-200">
                    Email
                  </span>
                  <span className="mt-1 block break-all text-sm font-semibold text-white">
                    {siteInfo.email}
                  </span>
                </span>
              </Link>

              <div className="group relative flex items-start gap-3 overflow-hidden rounded-2xl bg-white/[0.05] p-4 ring-1 ring-white/10 transition-all duration-500 hover:-translate-y-1 hover:bg-white/[0.09] hover:shadow-[0_18px_45px_rgba(138,107,184,0.18)]">
                <span className="absolute -left-10 top-1/2 size-24 -translate-y-1/2 rounded-full bg-[#8a6bb8]/0 blur-2xl transition-all duration-500 group-hover:bg-[#8a6bb8]/25" />

                <span className="relative grid size-10 shrink-0 place-items-center rounded-full bg-[#8a6bb8] text-white shadow-[0_10px_28px_rgba(138,107,184,0.22)] transition-all duration-500 group-hover:rotate-[14deg] group-hover:scale-110 group-hover:shadow-[0_16px_40px_rgba(138,107,184,0.34)]">
                  <MapPin size={18} />
                </span>

                <span className="relative">
                  <span className="block text-xs font-black uppercase tracking-[0.12em] text-cyan-200">
                    Address
                  </span>
                  <span className="mt-1 block text-sm font-semibold leading-6 text-white">
                    {siteInfo.address}
                  </span>
                </span>
              </div>

              <div className="group relative flex items-center gap-3 overflow-hidden rounded-2xl bg-white/[0.05] p-4 text-blue-100 ring-1 ring-white/10 transition-all duration-500 hover:-translate-y-1 hover:bg-white/[0.09] hover:shadow-[0_18px_45px_rgba(91,192,222,0.16)]">
                <span className="absolute -left-10 top-1/2 size-24 -translate-y-1/2 rounded-full bg-[#5bc0de]/0 blur-2xl transition-all duration-500 group-hover:bg-[#5bc0de]/25" />

                <Clock3
                  size={19}
                  className="relative text-[#5bc0de] transition-all duration-500 group-hover:rotate-[14deg] group-hover:scale-110"
                />

                <span className="relative text-sm font-semibold">
                  Open 24/7 for emergency support
                </span>
              </div>
            </div>
          </div>

          {/* Animated Chart */}
          <AnimatedHospitalChart />
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-white/10 pt-6 text-sm font-semibold text-blue-100 sm:mt-14 sm:flex-row sm:items-center sm:justify-between sm:pt-7">
          <p>© 2026 {siteInfo.name}. All rights reserved.</p>

          <div className="flex flex-wrap gap-4">
            <Link
              href="/privacy-policy"
              className="transition hover:text-[#5bc0de]"
            >
              Privacy Policy
            </Link>
            <Link href="/terms" className="transition hover:text-[#5bc0de]">
              Terms
            </Link>
            <Link href="/support" className="transition hover:text-[#5bc0de]">
              Support
            </Link>
          </div>
        </div>
      </Container>
      </footer>

      <CraftedBySignature variant="public" />
    </>
  );
}
