"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import clsx from "clsx";
import {
  Check,
  ChevronDown,
  Home,
  MapPin,
  Menu,
  Phone,
  Search,
  X,
} from "lucide-react";
import { navigation, siteInfo } from "@/data/site-base";
import { getActiveSpecialties, slugify } from "@/lib/specialties";

type SpecialityMenuItem = {
  title: string;
  slug: string;
};

const locations = [
  {
    id: "bashundhara",
    name: "Update Diagnostic Center",
    address: "Bashundhara R/A, Dhaka, Bangladesh",
    href: "/contact",
  },
  {
    id: "rangpur-medical-road",
    name: "Update Diagnostic Center Rangpur",
    address: "Medical Road, Rangpur, Bangladesh",
    href: "/contact",
  },
  {
    id: "rangpur-station-road",
    name: "Update Diagnostic Center",
    address: "Station Road, Rangpur, Bangladesh",
    href: "/contact",
  },
];

const languages = ["English", "বাংলা"];

const searchSuggestions = [
  { label: "Find a Doctor", href: "/doctors" },
  { label: "Cardiology", href: "/specialities" },
  { label: "Health Check", href: "/health-check" },
  { label: "Appointment", href: "/appointment" },
  { label: "Online Report", href: "/online-report" },
  { label: "Patient Stories", href: "/patient-stories" },
  { label: "News & Media", href: "/news-media" },
  { label: "Blogs", href: "/blogs" },
  { label: "Career", href: "/career" },
];

const specialityColumns = [
  [
    "Accident & Emergency",
    "Anesthesia And Pain Medicine",
    "Cancer Care Centre",
    "Cardiology Care Centre",
    "Cardiothoracic & Vascular Surgery",
    "Cardiothoracic Anaesthesia",
    "Child Development Centre",
    "Counselling Centre",
    "Critical Care Units",
    "Dental & Maxillofacial Surgery",
    "Dermatology & Venereology",
  ],
  [
    "Diabetology & Endocrinology",
    "Diagnostic & Interventional Radiology",
    "Dietetics & Nutrition",
    "ENT & Head Neck Surgery",
    "Fertility Centre",
    "Gastroenterology & Hepatology",
    "General & Laparoscopic Surgery",
    "Hematology & Stem Cell Transplant",
    "Hepatobiliary, Pancreatic And Liver Transplant",
    "Internal Medicine",
    "Joint Care & Wellness Centre",
  ],
  [
    "Kidney Transplant Program",
    "Lab Medicine",
    "Lithotripsy",
    "Neonatology",
    "Nephrology",
    "Neurology",
    "Neurosurgery",
    "Nuclear Medicine",
    "Obstetrics And Gynaecology",
    "Ophthalmology",
    "Orthopaedics",
  ],
  [
    "Paediatric Cardiology",
    "Paediatric Surgery & Paediatric Urology",
    "Paediatrics",
    "Physical Medicine & Rehabilitation",
    "Plastic, Reconstructive & Cosmetic Surgery",
    "Psychiatry",
    "Respiratory Medicine",
    "Rheumatology",
    "Thoracic Surgery",
    "Transfusion Medicine",
    "Urology",
  ],
];

const fallbackSpecialityMenuItems = specialityColumns
  .flat()
  .map((title) => ({ title, slug: slugify(title) }));

function chunkMenuItems(items: SpecialityMenuItem[]) {
  const columns = 4;
  const size = Math.ceil(items.length / columns);

  return Array.from({ length: columns }, (_, index) =>
    items.slice(index * size, index * size + size),
  );
}

const HEADER_HIDE_START = 90;
const SCROLL_DELTA_THRESHOLD = 2;

function LogoImage({ wrapperClassName = "" }: { wrapperClassName?: string }) {
  return (
    <span
      className={clsx(
        "relative block shrink-0 overflow-hidden drop-shadow-[0_16px_30px_rgba(8,47,73,0.14)]",
        wrapperClassName,
      )}
    >
      <Image
        src="/update.png"
        alt="Update Diagnostic Center"
        fill
        priority
        sizes="(max-width: 640px) 145px, (max-width: 1024px) 170px, 200px"
        className="object-contain transition duration-500 ease-out group-hover:scale-[1.025]"
      />
    </span>
  );
}

export default function Header() {
  const router = useRouter();
  const pathname = usePathname();

  const [isOpen, setIsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [locationOpen, setLocationOpen] = useState(false);
  const [languageOpen, setLanguageOpen] = useState(false);
  const [specialitiesOpen, setSpecialitiesOpen] = useState(false);
  const [headerVisible, setHeaderVisible] = useState(true);

  const [mobileLocationOpen, setMobileLocationOpen] = useState(false);
  const [mobileLanguageOpen, setMobileLanguageOpen] = useState(false);

  const [searchValue, setSearchValue] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("English");
  const [specialityMenuItems, setSpecialityMenuItems] = useState<
    SpecialityMenuItem[]
  >(fallbackSpecialityMenuItems);

  const lastScrollY = useRef(0);
  const ticking = useRef(false);

  const searchRef = useRef<HTMLDivElement | null>(null);
  const locationRef = useRef<HTMLDivElement | null>(null);
  const languageRef = useRef<HTMLDivElement | null>(null);
  const specialitiesRef = useRef<HTMLDivElement | null>(null);
  const dynamicSpecialityColumns = chunkMenuItems(specialityMenuItems);

  function isActiveRoute(href: string) {
    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  }

  function closeSpecialitiesMenu() {
    setSpecialitiesOpen(false);
  }

  function closeMobileMenu() {
    setIsOpen(false);
    setMobileLocationOpen(false);
    setMobileLanguageOpen(false);
  }

  useEffect(() => {
    function updateHeaderVisibility() {
      const currentScrollY = Math.max(window.scrollY, 0);
      const scrollDifference = currentScrollY - lastScrollY.current;
      const isScrollingDown = scrollDifference > SCROLL_DELTA_THRESHOLD;
      const isScrollingUp = scrollDifference < -SCROLL_DELTA_THRESHOLD;

      const anyMenuOpen =
        isOpen ||
        searchOpen ||
        locationOpen ||
        languageOpen ||
        specialitiesOpen;

      if (anyMenuOpen) {
        setHeaderVisible(true);
        lastScrollY.current = currentScrollY;
        ticking.current = false;
        return;
      }

      if (currentScrollY <= HEADER_HIDE_START) {
        setHeaderVisible(true);
        lastScrollY.current = currentScrollY;
        ticking.current = false;
        return;
      }

      if (isScrollingDown) {
        setHeaderVisible(false);
      }

      if (isScrollingUp) {
        setHeaderVisible(true);
      }

      lastScrollY.current = currentScrollY;
      ticking.current = false;
    }

    function handleScroll() {
      if (!ticking.current) {
        ticking.current = true;
        window.requestAnimationFrame(updateHeaderVisibility);
      }
    }

    lastScrollY.current = Math.max(window.scrollY, 0);

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [isOpen, searchOpen, locationOpen, languageOpen, specialitiesOpen]);

  useEffect(() => {
    lastScrollY.current = Math.max(window.scrollY, 0);

    const frameId = window.requestAnimationFrame(() => {
      setHeaderVisible(true);
    });

    return () => {
      window.cancelAnimationFrame(frameId);
    };
  }, [pathname]);

  useEffect(() => {
    function handleOutsideClick(event: MouseEvent | TouchEvent) {
      if (!searchOpen || !searchRef.current) return;

      if (!searchRef.current.contains(event.target as Node)) {
        setSearchOpen(false);
      }
    }

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("touchstart", handleOutsideClick);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("touchstart", handleOutsideClick);
    };
  }, [searchOpen]);

  useEffect(() => {
    function handleEscape(event: KeyboardEvent) {
      if (event.key !== "Escape") return;

      setSearchOpen(false);
      setLocationOpen(false);
      setLanguageOpen(false);
      setSpecialitiesOpen(false);
      closeMobileMenu();
    }

    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";

    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  useEffect(() => {
    function loadSpecialityMenu() {
      const menuItems = getActiveSpecialties()
        .filter((item) => item.showInMenu)
        .map((item) => ({ title: item.title, slug: item.slug }));

      setSpecialityMenuItems(menuItems.length ? menuItems : fallbackSpecialityMenuItems);
    }

    loadSpecialityMenu();
    window.addEventListener("specialties-updated", loadSpecialityMenu);
    window.addEventListener("storage", loadSpecialityMenu);

    return () => {
      window.removeEventListener("specialties-updated", loadSpecialityMenu);
      window.removeEventListener("storage", loadSpecialityMenu);
    };
  }, []);

  function handleSearchSubmit() {
    const query = searchValue.trim();

    if (!query) return;

    setSearchOpen(false);
    closeMobileMenu();

    const lowerQuery = query.toLowerCase();

    if (lowerQuery.includes("doctor")) {
      router.push(`/doctors?search=${encodeURIComponent(query)}`);
      return;
    }

    if (lowerQuery.includes("appointment")) {
      router.push("/appointment");
      return;
    }

    if (lowerQuery.includes("report")) {
      router.push("/online-report");
      return;
    }

    if (lowerQuery.includes("health")) {
      router.push("/health-check");
      return;
    }

    router.push(`/specialities?search=${encodeURIComponent(query)}`);
  }

  return (
    <>
      <style>{`
        @keyframes clinicDropdownIn {
          from {
            opacity: 0;
            transform: translateY(10px) scale(0.975);
            filter: blur(6px);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
            filter: blur(0);
          }
        }

        @keyframes clinicMegaIn {
          from {
            opacity: 0;
            transform: translateY(14px) scale(0.985);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        @keyframes clinicAccordionIn {
          from {
            opacity: 0;
            transform: translateY(-8px);
            max-height: 0;
          }
          to {
            opacity: 1;
            transform: translateY(0);
            max-height: 520px;
          }
        }

        @keyframes clinicSoftFloat {
          0%, 100% {
            transform: translate3d(0, 0, 0);
          }
          50% {
            transform: translate3d(0, -4px, 0);
          }
        }

        .clinic-dropdown-motion {
          animation: clinicDropdownIn 190ms cubic-bezier(0.16, 1, 0.3, 1) both;
          transform-origin: top right;
        }

        .clinic-mega-motion {
          animation: clinicMegaIn 220ms cubic-bezier(0.16, 1, 0.3, 1) both;
          transform-origin: top center;
        }

        .clinic-accordion-motion {
          animation: clinicAccordionIn 220ms cubic-bezier(0.16, 1, 0.3, 1) both;
          overflow: hidden;
        }

        .clinic-soft-float {
          animation: clinicSoftFloat 4.5s ease-in-out infinite;
        }

        @media (prefers-reduced-motion: reduce) {
          .clinic-dropdown-motion,
          .clinic-mega-motion,
          .clinic-accordion-motion,
          .clinic-soft-float {
            animation: none !important;
          }
        }
      `}</style>

      <div aria-hidden="true" className="h-[112px] xl:h-[124px]" />

      <header
        className={clsx(
          "fixed inset-x-0 top-0 z-50 border-b border-white/60 bg-white/90 shadow-[0_20px_70px_rgba(8,47,73,0.12)] backdrop-blur-2xl transition-transform duration-300 ease-out will-change-transform",
          headerVisible ? "translate-y-0" : "-translate-y-full",
        )}
      >
        {/* Top Premium Bar */}
        <div className="relative z-[90] w-full overflow-hidden bg-[linear-gradient(135deg,#020b1f_0%,#052f63_42%,#087ea4_73%,#10b8c9_100%)] text-white shadow-[inset_0_-1px_0_rgba(255,255,255,0.20)] before:pointer-events-none before:absolute before:inset-0 before:bg-[radial-gradient(circle_at_9%_15%,rgba(186,230,253,0.34),transparent_32%)] before:content-[''] after:pointer-events-none after:absolute after:right-[-120px] after:top-[-100px] after:h-[210px] after:w-[330px] after:rounded-full after:bg-cyan-200/25 after:blur-3xl after:content-['']">
          <div className="pointer-events-none absolute left-[36%] top-[-90px] h-[180px] w-[260px] rounded-full bg-white/10 blur-3xl clinic-soft-float" />
          <div className="pointer-events-none absolute bottom-0 left-0 h-px w-full bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.35),transparent)]" />

          <div className="relative z-10 mx-auto flex h-[44px] max-w-[1600px] items-center justify-between px-4 lg:px-8">
            <div className="flex min-w-0 items-center gap-4">
              <Link
                href="/"
                onMouseEnter={closeSpecialitiesMenu}
                className="group hidden h-[30px] w-[42px] shrink-0 items-center justify-center rounded-full bg-white/14 text-white shadow-[0_12px_28px_rgba(14,165,233,0.20)] ring-1 ring-white/25 backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:bg-cyan-200 hover:text-[#04264d] hover:shadow-[0_16px_38px_rgba(103,232,249,0.38)] sm:flex"
                aria-label="Go to home"
              >
                <Home size={15} className="transition duration-300 group-hover:scale-110" />
              </Link>

              <p className="hidden truncate text-[15px] font-semibold tracking-wide text-white/95 md:block">
                Welcome to {siteInfo.name} Rangpur.
              </p>

              <Link
                href={`tel:${siteInfo.emergency || "10678"}`}
                className="group flex items-center gap-2 text-sm font-semibold text-white xl:hidden"
              >
                <span className="relative grid size-7 place-items-center rounded-full bg-white/14 text-white ring-1 ring-white/20 transition-all duration-300 group-hover:bg-cyan-200 group-hover:text-[#04264d] group-hover:shadow-[0_0_24px_rgba(103,232,249,0.40)]">
                  <span className="absolute inset-0 rounded-full bg-cyan-200/20 opacity-0 transition group-hover:animate-ping group-hover:opacity-100" />
                  <Phone size={14} className="relative z-10" />
                </span>
                {siteInfo.emergency || "10678"}
              </Link>
            </div>

            <div className="flex items-center gap-4 xl:hidden">
              <button
                type="button"
                onClick={() => {
                  setIsOpen(true);
                  setMobileLanguageOpen(true);
                  setMobileLocationOpen(false);
                }}
                className="flex items-center gap-1 rounded-full bg-white/12 px-3 py-1.5 text-sm font-semibold text-white/95 ring-1 ring-white/20 backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/18 active:scale-95"
              >
                {selectedLanguage}
                <ChevronDown size={14} />
              </button>
            </div>

            <div
              onMouseEnter={closeSpecialitiesMenu}
              className="hidden items-center gap-4 xl:flex 2xl:gap-6"
            >
              <div ref={searchRef} className="relative">
                <div
                  onClick={() => {
                    setSearchOpen(true);
                    setLocationOpen(false);
                    setLanguageOpen(false);
                  }}
                  className="flex h-[32px] w-[168px] cursor-text items-center justify-between rounded-full border border-white/30 bg-white/13 px-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.18),0_10px_26px_rgba(0,0,0,0.08)] backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-100/75 hover:bg-white/20 hover:shadow-[inset_0_1px_0_rgba(255,255,255,0.24),0_14px_32px_rgba(0,0,0,0.10)] 2xl:w-[188px]"
                >
                  <input
                    type="text"
                    placeholder="Search"
                    value={searchValue}
                    onFocus={() => {
                      setSearchOpen(true);
                      setLocationOpen(false);
                      setLanguageOpen(false);
                    }}
                    onChange={(event) => {
                      setSearchValue(event.target.value);
                      setSearchOpen(true);
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        handleSearchSubmit();
                      }
                    }}
                    className="w-full bg-transparent text-sm text-white placeholder:text-white/85 outline-none"
                  />

                  <button
                    type="button"
                    onClick={handleSearchSubmit}
                    aria-label="Search"
                    className="grid size-6 place-items-center rounded-full transition-all duration-300 hover:bg-white/15 hover:scale-110 active:scale-95"
                  >
                    <Search size={16} className="text-white" />
                  </button>
                </div>

                {searchOpen && (
                  <div className="clinic-dropdown-motion absolute right-0 top-[42px] z-[999] w-[360px] overflow-hidden rounded-[26px] border border-white/70 bg-white/95 p-3 text-slate-800 shadow-[0_30px_90px_rgba(8,47,73,0.24)] ring-1 ring-cyan-900/5 backdrop-blur-2xl">
                    <div className="pointer-events-none absolute right-[-70px] top-[-70px] h-[150px] w-[150px] rounded-full bg-cyan-100/80 blur-3xl" />

                    <div className="relative z-10">
                      <p className="mb-2 text-xs font-black uppercase tracking-[0.22em] text-slate-500">
                        Search Hospital
                      </p>

                      <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50/90 px-3 py-2.5 shadow-inner transition-all duration-300 focus-within:border-cyan-400 focus-within:bg-white focus-within:ring-4 focus-within:ring-cyan-400/15">
                        <Search size={16} className="text-slate-400" />

                        <input
                          autoFocus
                          type="text"
                          placeholder="Doctor, department, service..."
                          value={searchValue}
                          onChange={(event) => setSearchValue(event.target.value)}
                          onKeyDown={(event) => {
                            if (event.key === "Enter") {
                              handleSearchSubmit();
                            }
                          }}
                          className="w-full bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400"
                        />
                      </div>

                      <div className="mt-3 space-y-1.5">
                        {searchSuggestions.map((item) => (
                          <button
                            key={item.label}
                            type="button"
                            onClick={() => {
                              setSearchValue(item.label);
                              setSearchOpen(false);
                              router.push(item.href);
                            }}
                            className="group flex w-full items-center justify-between rounded-2xl px-3 py-2.5 text-left text-sm font-semibold text-slate-700 transition-all duration-300 hover:translate-x-1 hover:bg-cyan-50 hover:text-[#063b73] active:scale-[0.99]"
                          >
                            <span>{item.label}</span>
                            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 opacity-0 transition duration-300 group-hover:opacity-100" />
                          </button>
                        ))}
                      </div>

                      <button
                        type="button"
                        onClick={handleSearchSubmit}
                        className="group relative mt-3 w-full overflow-hidden rounded-2xl bg-[linear-gradient(135deg,#04264d_0%,#087ea4_55%,#10b8c9_100%)] px-4 py-2.5 text-sm font-black text-white shadow-[0_18px_38px_rgba(8,47,73,0.26)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_50px_rgba(8,145,178,0.32)] active:scale-[0.99]"
                      >
                        <span className="absolute inset-0 translate-x-[-120%] bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.28),transparent)] transition-transform duration-700 group-hover:translate-x-[120%]" />
                        <span className="relative z-10">Search Now</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <Link
                href="/publications"
                className="relative rounded-full px-2 py-1 text-sm font-semibold text-white/95 transition-all duration-300 after:absolute after:left-2 after:right-2 after:-bottom-1 after:h-[2px] after:scale-x-0 after:rounded-full after:bg-cyan-200 after:transition-transform after:duration-300 hover:-translate-y-0.5 hover:bg-white/10 hover:text-cyan-100 hover:after:scale-x-100 active:scale-95"
              >
                Publications
              </Link>

              <div ref={locationRef} className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setLocationOpen((value) => !value);
                    setSearchOpen(false);
                    setLanguageOpen(false);
                  }}
                  className="flex items-center gap-1 rounded-full px-2.5 py-1 text-sm font-semibold text-white/95 transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/10 hover:text-cyan-100 active:scale-95"
                >
                  View All Locations
                  <ChevronDown
                    size={14}
                    className={clsx(
                      "transition duration-300",
                      locationOpen && "rotate-180",
                    )}
                  />
                </button>

                {locationOpen && (
                  <div className="clinic-dropdown-motion absolute right-0 top-[38px] z-[999] w-[400px] overflow-hidden rounded-[26px] border border-white/70 bg-white/95 p-3 text-slate-800 shadow-[0_30px_90px_rgba(8,47,73,0.24)] ring-1 ring-cyan-900/5 backdrop-blur-2xl">
                    <div className="pointer-events-none absolute right-[-80px] top-[-80px] h-[170px] w-[170px] rounded-full bg-cyan-100/80 blur-3xl" />

                    <div className="relative z-10">
                      <p className="mb-2 text-xs font-black uppercase tracking-[0.22em] text-slate-500">
                        Our Locations
                      </p>

                      <div className="space-y-2">
                        {locations.map((location) => (
                          <Link
                            key={location.id}
                            href={location.href}
                            onClick={() => setLocationOpen(false)}
                            className="group flex gap-3 rounded-[22px] border border-transparent p-3 transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-100 hover:bg-cyan-50 hover:shadow-[0_18px_38px_rgba(8,47,73,0.10)] active:scale-[0.99]"
                          >
                            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[linear-gradient(135deg,#ecfeff,#dff7ff)] text-[#063b73] ring-1 ring-cyan-200 transition-all duration-300 group-hover:scale-105 group-hover:bg-[linear-gradient(135deg,#04264d,#087ea4)] group-hover:text-white group-hover:shadow-[0_14px_30px_rgba(8,145,178,0.25)]">
                              <MapPin size={18} />
                            </span>

                            <span className="min-w-0">
                              <span className="block text-sm font-black text-[#063b73]">
                                {location.name}
                              </span>
                              <span className="mt-1 block text-xs leading-5 text-slate-500">
                                {location.address}
                              </span>
                            </span>
                          </Link>
                        ))}
                      </div>

                      <Link
                        href="/contact"
                        onClick={() => setLocationOpen(false)}
                        className="group relative mt-3 block overflow-hidden rounded-2xl bg-[linear-gradient(135deg,#04264d_0%,#087ea4_55%,#10b8c9_100%)] px-4 py-2.5 text-center text-sm font-black text-white shadow-[0_18px_38px_rgba(8,47,73,0.26)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_50px_rgba(8,145,178,0.32)] active:scale-[0.99]"
                      >
                        <span className="absolute inset-0 translate-x-[-120%] bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.28),transparent)] transition-transform duration-700 group-hover:translate-x-[120%]" />
                        <span className="relative z-10">View Location Details</span>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              <Link
                href={`tel:${siteInfo.emergency || "10678"}`}
                className="group flex items-center gap-3 rounded-full px-1.5 py-1 text-sm font-semibold text-white transition-all duration-300 hover:bg-white/10 active:scale-95"
              >
                <span className="relative grid h-[30px] w-[30px] place-items-center rounded-full bg-white text-[#063b73] shadow-[0_10px_24px_rgba(255,255,255,0.20)] transition-all duration-300 group-hover:scale-110 group-hover:bg-cyan-200 group-hover:text-[#04264d] group-hover:shadow-[0_0_28px_rgba(103,232,249,0.48)]">
                  <span className="absolute inset-0 rounded-full bg-cyan-200/25 opacity-0 transition group-hover:animate-ping group-hover:opacity-100" />
                  <Phone size={14} className="relative z-10" />
                </span>
                {siteInfo.emergency || "10678"}
              </Link>

              <div ref={languageRef} className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setLanguageOpen((value) => !value);
                    setSearchOpen(false);
                    setLocationOpen(false);
                  }}
                  className="flex items-center gap-1 rounded-full px-2.5 py-1 text-sm font-semibold text-white/95 transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/10 hover:text-cyan-100 active:scale-95"
                >
                  {selectedLanguage}
                  <ChevronDown
                    size={14}
                    className={clsx(
                      "transition duration-300",
                      languageOpen && "rotate-180",
                    )}
                  />
                </button>

                {languageOpen && (
                  <div className="clinic-dropdown-motion absolute right-0 top-[38px] z-[999] w-[190px] overflow-hidden rounded-[22px] border border-white/70 bg-white/95 p-2 text-slate-800 shadow-[0_30px_90px_rgba(8,47,73,0.24)] ring-1 ring-cyan-900/5 backdrop-blur-2xl">
                    {languages.map((language) => (
                      <button
                        key={language}
                        type="button"
                        onClick={() => {
                          setSelectedLanguage(language);
                          setLanguageOpen(false);
                        }}
                        className="flex w-full items-center justify-between rounded-2xl px-3 py-2.5 text-sm font-semibold transition-all duration-300 hover:translate-x-0.5 hover:bg-cyan-50 hover:text-[#063b73] active:scale-[0.99]"
                      >
                        <span>{language}</span>

                        {selectedLanguage === language && (
                          <Check size={15} className="text-[#063b73]" />
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Main Premium Navbar */}
        <div
          ref={specialitiesRef}
          onMouseLeave={() => setSpecialitiesOpen(false)}
          className="relative z-[70] border-b border-slate-100/80 bg-[linear-gradient(180deg,rgba(255,255,255,0.98)_0%,rgba(248,253,255,0.96)_100%)] backdrop-blur-2xl"
        >
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-[linear-gradient(90deg,transparent,rgba(8,145,178,0.22),transparent)]" />

          <div className="mx-auto w-full max-w-[1600px] px-4 sm:px-6 lg:px-8">
            <div className="flex h-[68px] items-center justify-between gap-4 xl:h-20">
              <Link
                href="/"
                onMouseEnter={closeSpecialitiesMenu}
                onClick={closeMobileMenu}
                className="group flex h-full w-[132px] shrink-0 items-center sm:w-[160px] xl:w-[176px] 2xl:w-[200px]"
                aria-label="Go to home"
              >
                <LogoImage wrapperClassName="h-[50px] w-[130px] transition duration-300 sm:h-[58px] sm:w-[156px] xl:h-[62px] xl:w-[174px] 2xl:h-[70px] 2xl:w-[196px]" />
              </Link>

              <div className="hidden min-w-0 flex-1 items-center justify-end gap-3 xl:flex 2xl:gap-5">
                <nav className="flex min-w-0 flex-1 items-center justify-end gap-1 overflow-hidden rounded-[30px] bg-white/55 p-1 shadow-[inset_0_1px_0_rgba(255,255,255,0.9)] ring-1 ring-slate-200/70 backdrop-blur-xl 2xl:gap-1.5">
                  {navigation.map((item) => {
                    const isSpecialities =
                      item.label.toLowerCase() === "specialities" ||
                      item.label.toLowerCase() === "specialties";

                    const active = isSpecialities
                      ? pathname.startsWith("/specialities")
                      : isActiveRoute(item.href);

                    const navClass = clsx(
                      "group relative flex h-10 min-w-0 items-center justify-center overflow-hidden rounded-full px-2.5 text-center text-[12.5px] font-black leading-none tracking-[0.01em] transition-all duration-300 2xl:h-11 2xl:px-3.5 2xl:text-[14px]",
                      active
                        ? "bg-[linear-gradient(135deg,#04264d_0%,#087ea4_60%,#18c7d9_100%)] text-white shadow-[0_14px_30px_rgba(8,145,178,0.28)]"
                        : "text-[#061b3d] hover:-translate-y-0.5 hover:bg-[linear-gradient(135deg,#087ea4,#18c7d9)] hover:text-white hover:shadow-[0_12px_28px_rgba(8,145,178,0.20)]",
                    );

                    if (isSpecialities) {
                      return (
                        <button
                          key={item.href}
                          type="button"
                          onMouseEnter={() => setSpecialitiesOpen(true)}
                          onClick={() => setSpecialitiesOpen((value) => !value)}
                          className={clsx(navClass, "gap-1.5")}
                        >
                          <span className="pointer-events-none absolute inset-0 translate-x-[-130%] bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.25),transparent)] transition-transform duration-700 group-hover:translate-x-[130%]" />

                          <span className="relative z-10 whitespace-nowrap">
                            {item.label}
                          </span>

                          <ChevronDown
                            size={13}
                            className={clsx(
                              "relative z-10 mt-[1px] shrink-0 transition duration-300",
                              specialitiesOpen && "rotate-180",
                            )}
                          />

                          <span
                            className={clsx(
                              "pointer-events-none absolute -bottom-[11px] left-1/2 h-0 w-0 -translate-x-1/2 border-x-[10px] border-t-[10px] border-x-transparent border-t-[#087ea4] transition-all duration-300",
                              active || specialitiesOpen
                                ? "opacity-100"
                                : "opacity-0 group-hover:opacity-100",
                            )}
                          />
                        </button>
                      );
                    }

                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        onMouseEnter={closeSpecialitiesMenu}
                        className={navClass}
                      >
                        <span className="pointer-events-none absolute inset-0 translate-x-[-130%] bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.25),transparent)] transition-transform duration-700 group-hover:translate-x-[130%]" />

                        <span className="relative z-10 whitespace-nowrap">
                          {item.label}
                        </span>

                        <span
                          className={clsx(
                            "pointer-events-none absolute -bottom-[11px] left-1/2 h-0 w-0 -translate-x-1/2 border-x-[10px] border-t-[10px] border-x-transparent border-t-[#087ea4] transition-all duration-300",
                            active
                              ? "opacity-100"
                              : "opacity-0 group-hover:opacity-100",
                          )}
                        />
                      </Link>
                    );
                  })}
                </nav>

                <Link
                  href="/appointment"
                  onMouseEnter={closeSpecialitiesMenu}
                  className="group relative inline-flex h-11 min-w-[132px] shrink-0 items-center justify-center overflow-hidden rounded-full bg-[linear-gradient(135deg,#04264d_0%,#087ea4_55%,#18c7d9_100%)] px-4 text-center text-sm font-black text-white shadow-[0_18px_38px_rgba(8,47,73,0.22)] ring-1 ring-cyan-900/10 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_50px_rgba(8,145,178,0.33)] active:scale-[0.98] 2xl:h-12 2xl:min-w-[154px] 2xl:px-5"
                >
                  <span className="absolute inset-0 translate-x-[-120%] bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.28),transparent)] transition-transform duration-700 group-hover:translate-x-[120%]" />
                  <span className="relative z-10">Send Query</span>
                </Link>
              </div>

              <button
                type="button"
                className="group ml-auto inline-flex size-11 shrink-0 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#04264d_0%,#087ea4_60%,#18c7d9_100%)] text-white shadow-[0_16px_34px_rgba(8,47,73,0.28)] ring-1 ring-cyan-900/10 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_22px_44px_rgba(8,145,178,0.36)] active:scale-95 xl:hidden"
                aria-label="Toggle navigation menu"
                onClick={() => setIsOpen(true)}
              >
                <Menu size={25} className="transition duration-300 group-hover:scale-110" />
              </button>
            </div>
          </div>

          {/* Specialities Mega Menu */}
          {specialitiesOpen && (
            <div
              onMouseEnter={() => setSpecialitiesOpen(true)}
              className="absolute left-0 top-full z-[900] hidden w-full lg:block"
            >
              <div className="clinic-mega-motion relative mx-auto max-w-[1600px] overflow-hidden rounded-b-[36px] bg-[linear-gradient(135deg,#020b1f_0%,#052f63_42%,#087ea4_75%,#10b8c9_100%)] px-7 py-8 text-white shadow-[0_38px_100px_rgba(8,47,73,0.38)] ring-1 ring-white/10">
                <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_16%_10%,rgba(186,230,253,0.22),transparent_30%)]" />
                <div className="pointer-events-none absolute right-[-120px] top-[-120px] h-[260px] w-[360px] rounded-full bg-cyan-200/20 blur-3xl clinic-soft-float" />
                <div className="pointer-events-none absolute bottom-0 left-0 h-px w-full bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.35),transparent)]" />

                <div className="relative z-10 grid grid-cols-4 gap-x-12 gap-y-4 2xl:gap-x-16">
                  {dynamicSpecialityColumns.map((column, columnIndex) => (
                    <div
                      key={columnIndex}
                      className="rounded-[24px] border border-white/10 bg-white/[0.04] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:bg-white/[0.06] hover:shadow-[0_20px_45px_rgba(0,0,0,0.14),inset_0_1px_0_rgba(255,255,255,0.10)]"
                    >
                      <div className="space-y-3.5">
                        {column.map((speciality) => (
                          <Link
                            key={speciality.slug}
                            href={`/specialities/${speciality.slug}`}
                            onClick={() => setSpecialitiesOpen(false)}
                            className="group block w-full rounded-xl px-2 py-1.5 text-[14px] font-semibold leading-5 tracking-wide transition-all duration-300 hover:translate-x-1 hover:bg-white/[0.08] active:scale-[0.99]"
                          >
                            <span className="relative inline-block text-white/95 transition-all duration-300 after:absolute after:left-0 after:-bottom-[5px] after:h-[2px] after:w-0 after:rounded-full after:bg-cyan-200 after:shadow-[0_0_16px_rgba(103,232,249,0.9)] after:transition-all after:duration-300 group-hover:font-black group-hover:text-cyan-100 group-hover:after:w-full">
                              {speciality.title}
                            </span>
                          </Link>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="relative z-10 mt-8 flex justify-end">
                  <Link
                    href="/specialities"
                    onClick={() => setSpecialitiesOpen(false)}
                    className="group relative inline-flex min-w-[205px] items-center justify-center overflow-hidden rounded-full bg-white px-6 py-3 text-center text-sm font-black shadow-[0_18px_42px_rgba(0,0,0,0.20)] ring-1 ring-white/40 transition-all duration-300 hover:-translate-y-0.5 hover:bg-cyan-200 hover:shadow-[0_24px_54px_rgba(103,232,249,0.28)] active:scale-[0.98]"
                  >
                    <span className="absolute inset-0 translate-x-[-120%] bg-[linear-gradient(90deg,transparent,rgba(8,145,178,0.16),transparent)] transition-transform duration-700 group-hover:translate-x-[120%]" />
                    <span className="relative z-10 whitespace-nowrap text-[#063b73] transition-colors duration-300 group-hover:text-[#04264d]">
                      View All Specialities
                    </span>
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Mobile Overlay */}
      <div
        onClick={closeMobileMenu}
        className={clsx(
          "fixed inset-0 z-[90] bg-[#020817]/75 backdrop-blur-sm transition-opacity duration-300 xl:hidden",
          isOpen
            ? "pointer-events-auto opacity-100"
            : "pointer-events-none opacity-0",
        )}
      />

      {/* Mobile Side Drawer */}
      <aside
        className={clsx(
          "fixed left-0 top-0 z-[100] flex h-dvh w-[88%] max-w-[400px] flex-col overflow-hidden rounded-r-[34px] bg-white text-[#061b3d] shadow-[28px_0_90px_rgba(2,8,23,0.28)] transition-transform duration-300 ease-out will-change-transform xl:hidden",
          isOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="relative overflow-hidden border-b border-slate-100 bg-[linear-gradient(180deg,#ffffff_0%,#f0fbff_100%)] px-6 pb-5 pt-6 before:pointer-events-none before:absolute before:right-[-90px] before:top-[-90px] before:h-[190px] before:w-[190px] before:rounded-full before:bg-cyan-100/90 before:blur-3xl before:content-[''] after:pointer-events-none after:absolute after:left-[-80px] after:bottom-[-90px] after:h-[170px] after:w-[170px] after:rounded-full after:bg-blue-100/70 after:blur-3xl after:content-['']">
          <Link
            href="/"
            onClick={closeMobileMenu}
            className="relative z-10 inline-flex rounded-2xl bg-white/60 p-1 shadow-sm ring-1 ring-white/70"
            aria-label="Go to home"
          >
            <LogoImage wrapperClassName="h-[62px] w-[170px]" />
          </Link>

          <button
            type="button"
            onClick={closeMobileMenu}
            aria-label="Close mobile menu"
            className="absolute right-5 top-5 z-10 grid size-10 place-items-center rounded-2xl border border-slate-200 bg-white text-[#061b3d] shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-300 hover:bg-cyan-400 hover:text-white hover:shadow-[0_14px_28px_rgba(8,145,178,0.22)] active:scale-95"
          >
            <X size={20} />
          </button>
        </div>

        <div className="border-b border-slate-100 px-6 py-4">
          <div className="flex h-[46px] items-center rounded-full border border-slate-200 bg-slate-50/90 px-4 shadow-inner transition-all duration-300 focus-within:border-cyan-400 focus-within:bg-white focus-within:ring-4 focus-within:ring-cyan-400/15">
            <input
              type="text"
              placeholder="Search"
              value={searchValue}
              onChange={(event) => setSearchValue(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  handleSearchSubmit();
                }
              }}
              className="w-full bg-transparent text-sm font-semibold text-[#061b3d] outline-none placeholder:font-medium placeholder:text-slate-400"
            />

            <button
              type="button"
              onClick={handleSearchSubmit}
              aria-label="Search"
              className="grid size-8 place-items-center rounded-full bg-cyan-50 text-[#063b73] transition-all duration-300 hover:bg-cyan-400 hover:text-white active:scale-95"
            >
              <Search size={17} />
            </button>
          </div>
        </div>

        <nav className="flex-1 space-y-1.5 overflow-y-auto px-6 pt-5">
          {navigation.map((item) => {
            const isSpecialities =
              item.label.toLowerCase() === "specialities" ||
              item.label.toLowerCase() === "specialties";

            const active = isSpecialities
              ? pathname.startsWith("/specialities")
              : isActiveRoute(item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={closeMobileMenu}
                className={clsx(
                  "group relative flex w-full items-center overflow-hidden rounded-2xl px-4 py-3 text-[15px] font-black tracking-wide transition-all duration-300 active:scale-[0.99]",
                  active
                    ? "bg-[linear-gradient(135deg,#04264d_0%,#087ea4_60%,#18c7d9_100%)] text-white shadow-[0_16px_34px_rgba(8,145,178,0.25)]"
                    : "text-[#061b3d] hover:translate-x-1 hover:bg-cyan-50 hover:text-[#063b73]",
                )}
              >
                <span className="absolute inset-y-2 left-0 w-1 rounded-r-full bg-cyan-400 opacity-0 transition duration-300 group-hover:opacity-100" />
                <span className="absolute inset-0 translate-x-[-120%] bg-[linear-gradient(90deg,transparent,rgba(8,145,178,0.08),transparent)] transition-transform duration-700 group-hover:translate-x-[120%]" />
                <span className="relative z-10">{item.label}</span>
              </Link>
            );
          })}

          <Link
            href="/appointment"
            onClick={closeMobileMenu}
            className="group relative mt-5 inline-flex h-[50px] w-[170px] items-center justify-center overflow-hidden rounded-full bg-[linear-gradient(135deg,#04264d_0%,#087ea4_60%,#18c7d9_100%)] text-sm font-black text-white shadow-[0_20px_42px_rgba(8,47,73,0.25)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_50px_rgba(8,145,178,0.34)] active:scale-[0.98]"
          >
            <span className="absolute inset-0 translate-x-[-120%] bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.28),transparent)] transition-transform duration-700 group-hover:translate-x-[120%]" />
            <span className="relative z-10">Send Query</span>
          </Link>
        </nav>

        <div className="border-t border-slate-100 bg-[linear-gradient(180deg,#ffffff_0%,#f0fbff_100%)] px-6 py-5">
          <button
            type="button"
            onClick={() => {
              setMobileLocationOpen((value) => !value);
              setMobileLanguageOpen(false);
            }}
            className="flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left text-[15px] font-black text-[#061b3d] transition-all duration-300 hover:bg-cyan-50 hover:text-[#063b73] active:scale-[0.99]"
          >
            <span>View All Locations</span>
            <ChevronDown
              size={16}
              className={clsx(
                "transition duration-300",
                mobileLocationOpen && "rotate-180",
              )}
            />
          </button>

          {mobileLocationOpen && (
            <div className="clinic-accordion-motion mt-2 grid gap-2 rounded-[22px] bg-slate-50/90 p-3 ring-1 ring-slate-100">
              {locations.map((location) => (
                <Link
                  key={location.id}
                  href={location.href}
                  onClick={closeMobileMenu}
                  className="rounded-2xl bg-white p-3 text-sm shadow-sm ring-1 ring-slate-100 transition-all duration-300 hover:-translate-y-0.5 hover:bg-cyan-400 hover:text-white hover:shadow-[0_14px_28px_rgba(8,145,178,0.24)] active:scale-[0.99]"
                >
                  <span className="block font-black">{location.name}</span>
                  <span className="mt-1 block text-xs leading-5 opacity-75">
                    {location.address}
                  </span>
                </Link>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setMobileLanguageOpen((value) => !value);
              setMobileLocationOpen(false);
            }}
            className="mt-2 flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left text-[15px] font-black text-[#061b3d] transition-all duration-300 hover:bg-cyan-50 hover:text-[#063b73] active:scale-[0.99]"
          >
            <span>{selectedLanguage}</span>
            <ChevronDown
              size={16}
              className={clsx(
                "transition duration-300",
                mobileLanguageOpen && "rotate-180",
              )}
            />
          </button>

          {mobileLanguageOpen && (
            <div className="clinic-accordion-motion mt-2 grid gap-2 rounded-[22px] bg-slate-50/90 p-3 ring-1 ring-slate-100">
              {languages.map((language) => (
                <button
                  key={language}
                  type="button"
                  onClick={() => {
                    setSelectedLanguage(language);
                    setMobileLanguageOpen(false);
                  }}
                  className="flex items-center justify-between rounded-2xl bg-white px-3 py-3 text-left text-sm font-black text-[#061b3d] shadow-sm ring-1 ring-slate-100 transition-all duration-300 hover:-translate-y-0.5 hover:bg-cyan-400 hover:text-white active:scale-[0.99]"
                >
                  <span>{language}</span>
                  {selectedLanguage === language && <Check size={16} />}
                </button>
              ))}
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
