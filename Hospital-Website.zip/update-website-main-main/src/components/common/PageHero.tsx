// File: clinic-website/src/components/common/PageHero.tsx

import Container from "@/components/common/Container";

type PageHeroProps = {
  title: string;
  description: string;
};

export default function PageHero({ title, description }: PageHeroProps) {
  return (
    <section className="bg-[#062f66] py-10 text-white sm:py-14 lg:py-20">
      <Container>
        <div className="max-w-3xl">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-cyan-200 sm:text-sm">
            Update Diagnostic Center
          </p>
          <h1 className="text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
            {title}
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base lg:text-lg lg:leading-8">
            {description}
          </p>
        </div>
      </Container>
    </section>
  );
}
