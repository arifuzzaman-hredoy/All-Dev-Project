// File: clinic-website/src/components/common/StaticPage.tsx

import Container from "@/components/common/Container";
import PageHero from "@/components/common/PageHero";

type StaticPageProps = {
  title: string;
  description: string;
  children: React.ReactNode;
};

export default function StaticPage({ title, description, children }: StaticPageProps) {
  return (
    <>
      <PageHero title={title} description={description} />
      <section className="bg-white py-10 sm:py-14 lg:py-20">
        <Container>{children}</Container>
      </section>
    </>
  );
}
