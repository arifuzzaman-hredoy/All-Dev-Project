import Image from "next/image";
import Link from "next/link";
import { ChevronRight, Home } from "lucide-react";

export default function AboutHero() {
  return (
    <section className="bg-white pb-8 pt-4 sm:pb-12 sm:pt-6 lg:pt-10">
      <div className="mx-auto w-full max-w-[1712px] px-4 sm:px-6 lg:px-8">
        <div className="relative h-[230px] overflow-hidden bg-slate-100 sm:h-[380px] lg:h-[625px]">
          <Image
            src="/slider2.jpeg"
            alt="Update Diagnostic Center hospital building"
            fill
            priority
            sizes="(max-width: 768px) 100vw, 1712px"
            className="object-cover"
          />
        </div>

        <div className="grid h-3 grid-cols-[1.1fr_0.6fr_0.35fr_0.55fr]" aria-hidden="true">
          <span className="bg-[#062d62]" />
          <span className="bg-[#45b3dc]" />
          <span className="bg-[#8b65ad]" />
          <span className="bg-[#98c45d]" />
        </div>

        <nav
          aria-label="Breadcrumb"
          className="flex items-center gap-2 py-6 text-sm font-semibold sm:py-10 lg:py-12"
        >
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-[#2c6fff] transition hover:text-[#062d62]"
          >
            <Home className="h-4 w-4" aria-hidden="true" />
            Home
          </Link>
          <ChevronRight className="h-4 w-4 text-slate-300" aria-hidden="true" />
          <span className="text-[#102033]">About Us</span>
        </nav>
      </div>
    </section>
  );
}
