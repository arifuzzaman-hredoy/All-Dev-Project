import {
  BadgeCheck,
  HeartPulse,
  Lightbulb,
  Scale,
  Sparkles,
} from "lucide-react";
import type { ReactNode } from "react";

const valueCards = [
  {
    title: "Quality",
    description:
      "We are committed to providing quality healthcare for every patient.",
    icon: BadgeCheck,
    color: "text-[#9acd4f]",
    bg: "bg-[#9acd4f]/12",
  },
  {
    title: "Integrity",
    description:
      "We do the right thing, every time, even when no one is looking.",
    icon: Scale,
    color: "text-[#9063b4]",
    bg: "bg-[#9063b4]/12",
  },
  {
    title: "Passionate",
    description:
      "We are passionate about healthcare and this shows in the care we provide.",
    icon: HeartPulse,
    color: "text-[#f5222d]",
    bg: "bg-[#f5222d]/10",
  },
  {
    title: "Respect",
    description:
      "We are respectful of everyone regardless of our differences and diversity.",
    icon: Sparkles,
    color: "text-[#17aee6]",
    bg: "bg-[#17aee6]/12",
  },
  {
    title: "Innovative",
    description:
      "We believe innovation helps improve patients' experience and caregiver engagement.",
    icon: Lightbulb,
    color: "text-[#062d62]",
    bg: "bg-[#062d62]/10",
  },
];

function FramedTitle({ children }: { children: ReactNode }) {
  return (
    <h3 className="relative inline-flex overflow-hidden rounded-2xl border border-[#dbeafe] bg-white/90 px-6 py-3 text-2xl font-black uppercase tracking-[0.16em] text-[#062d62] shadow-[0_16px_40px_rgba(6,45,98,0.10)] backdrop-blur-md">
      <span className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-[#43c7f4] via-[#9063b4] to-[#9acd4f]" />
      <span className="relative z-10">{children}</span>
    </h3>
  );
}

export default function VisionMissionValues() {
  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 text-[#062d62] sm:py-14 lg:py-20">
      {/* Premium Simple Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />

        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#9063b4]/14 blur-[115px]" />
        <div className="absolute left-1/2 top-[44%] h-[300px] w-[300px] -translate-x-1/2 rounded-full bg-[#9acd4f]/8 blur-[100px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062d62]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Vision & Mission */}
        <div className="grid gap-8 text-center lg:grid-cols-2 lg:gap-10">
          <div className="rounded-[24px] border border-white/80 bg-white/75 p-5 shadow-[0_20px_60px_rgba(6,45,98,0.09)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_28px_75px_rgba(6,45,98,0.13)] sm:rounded-[30px] sm:p-9">
            <FramedTitle>Our Vision</FramedTitle>

            <p className="mx-auto mt-6 max-w-[620px] text-sm font-semibold leading-7 text-[#4d6380] sm:mt-8 sm:text-base sm:leading-8">
              To become a leading tertiary and quaternary care hospital chain,
              providing best-in-class private healthcare of international
              standards, accessible to Bangladeshi citizens.
            </p>
          </div>

          <div className="rounded-[24px] border border-white/80 bg-white/75 p-5 shadow-[0_20px_60px_rgba(6,45,98,0.09)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_28px_75px_rgba(6,45,98,0.13)] sm:rounded-[30px] sm:p-9">
            <FramedTitle>Our Mission</FramedTitle>

            <p className="mx-auto mt-6 max-w-[620px] text-sm font-semibold leading-7 text-[#4d6380] sm:mt-8 sm:text-base sm:leading-8">
              Set up quaternary care capabilities in all specialties so that
              Bangladeshi citizens do not need to travel out of country for
              medical treatments.
            </p>
          </div>
        </div>

        {/* Values Heading */}
        <div className="mt-12 text-center lg:mt-20">
          <FramedTitle>Our Values</FramedTitle>

          <p className="mx-auto mt-6 max-w-[680px] text-sm font-semibold leading-7 text-[#4d6380] sm:mt-8 sm:text-base sm:leading-8">
            We are committed to providing best-in-class, accessible healthcare
            for all and encourage our employees and caregivers to share our
            values:
          </p>
        </div>

        {/* Value Cards */}
        <div className="mx-auto mt-8 grid max-w-[900px] gap-4 sm:mt-12 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
          {valueCards.slice(0, 3).map((value) => {
            const Icon = value.icon;

            return (
              <article
                key={value.title}
                className="group relative flex min-h-[210px] flex-col items-center justify-center overflow-hidden rounded-[22px] border border-[#dbeafe] bg-white/80 px-5 py-6 text-center shadow-[0_18px_50px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:border-[#43c7f4]/45 hover:bg-white hover:shadow-[0_28px_75px_rgba(6,45,98,0.14)] sm:min-h-[240px] sm:rounded-[26px] sm:px-7 sm:py-8"
              >
                <div className="pointer-events-none absolute right-[-55px] top-[-55px] h-[140px] w-[140px] rounded-full bg-[#43c7f4]/10 blur-[40px] transition-all duration-300 group-hover:bg-[#9063b4]/12" />

                <span
                  className={`relative z-10 flex h-20 w-20 items-center justify-center rounded-[24px] ${value.bg} shadow-[0_14px_35px_rgba(6,45,98,0.08)] transition-all duration-300 group-hover:-translate-y-2 group-hover:rotate-6 group-hover:scale-110`}
                >
                  <Icon
                    className={`h-12 w-12 ${value.color} transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110`}
                    strokeWidth={2.4}
                  />
                </span>

                <h4 className="relative z-10 mt-6 text-xl font-black text-[#062d62] transition-colors duration-300 group-hover:text-[#9063b4]">
                  {value.title}
                </h4>

                <p className="relative z-10 mt-3 text-sm font-semibold leading-6 text-[#4d6380]">
                  {value.description}
                </p>

                <div className="pointer-events-none absolute inset-x-8 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/60 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              </article>
            );
          })}
        </div>

        <div className="mx-auto mt-4 grid max-w-[590px] gap-4 sm:mt-6 sm:grid-cols-2 sm:gap-6">
          {valueCards.slice(3).map((value) => {
            const Icon = value.icon;

            return (
              <article
                key={value.title}
                className="group relative flex min-h-[210px] flex-col items-center justify-center overflow-hidden rounded-[22px] border border-[#dbeafe] bg-white/80 px-5 py-6 text-center shadow-[0_18px_50px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:border-[#43c7f4]/45 hover:bg-white hover:shadow-[0_28px_75px_rgba(6,45,98,0.14)] sm:min-h-[240px] sm:rounded-[26px] sm:px-7 sm:py-8"
              >
                <div className="pointer-events-none absolute right-[-55px] top-[-55px] h-[140px] w-[140px] rounded-full bg-[#43c7f4]/10 blur-[40px] transition-all duration-300 group-hover:bg-[#9063b4]/12" />

                <span
                  className={`relative z-10 flex h-20 w-20 items-center justify-center rounded-[24px] ${value.bg} shadow-[0_14px_35px_rgba(6,45,98,0.08)] transition-all duration-300 group-hover:-translate-y-2 group-hover:rotate-6 group-hover:scale-110`}
                >
                  <Icon
                    className={`h-12 w-12 ${value.color} transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110`}
                    strokeWidth={2.4}
                  />
                </span>

                <h4 className="relative z-10 mt-6 text-xl font-black text-[#062d62] transition-colors duration-300 group-hover:text-[#9063b4]">
                  {value.title}
                </h4>

                <p className="relative z-10 mt-3 text-sm font-semibold leading-6 text-[#4d6380]">
                  {value.description}
                </p>

                <div className="pointer-events-none absolute inset-x-8 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/60 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
