"use client";

import { createElement, useEffect, useState } from "react";
import {
  AboutPageData,
  DEFAULT_ABOUT_IMAGE,
  DEFAULT_ABOUT_PAGE,
  getAboutPageFromStorage,
} from "@/lib/aboutPage";
import { getAboutIcon } from "@/lib/aboutIcons";

function AboutIcon({
  icon,
  className,
  strokeWidth,
}: {
  icon: string;
  className?: string;
  strokeWidth?: number;
}) {
  const Icon = getAboutIcon(icon);

  return createElement(Icon, { className, strokeWidth });
}

export default function AboutPagePublic() {
  const [data, setData] = useState<AboutPageData>(DEFAULT_ABOUT_PAGE);

  useEffect(() => {
    function loadData() {
      setData(getAboutPageFromStorage());
    }

    loadData();
    window.addEventListener("storage", loadData);
    window.addEventListener("about-page-updated", loadData);

    return () => {
      window.removeEventListener("storage", loadData);
      window.removeEventListener("about-page-updated", loadData);
    };
  }, []);

  const whoCards = [...data.whoCards]
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
  const transformImages = [...data.transformImages]
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
  const values = [...data.values]
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
  const learningCards = [...data.learningCards]
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <main className="bg-white text-[#002f70]">
      <section className="px-5 py-10">
        <div className="mx-auto max-w-[1630px] overflow-hidden">
          <img
            src={data.heroImage || DEFAULT_ABOUT_IMAGE}
            alt={data.heroAlt}
            onError={(event) => {
              event.currentTarget.src = DEFAULT_ABOUT_IMAGE;
            }}
            className="h-auto max-h-[650px] w-full object-cover"
          />
          <div className="grid h-3 grid-cols-4">
            <span className="bg-[#002f70]" />
            <span className="bg-[#35bbea]" />
            <span className="bg-[#8061bd]" />
            <span className="bg-[#8cc63f]" />
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-r from-[#08233e] via-[#0c3153] to-[#103f7a] px-5 py-20 text-white">
        <div className="mx-auto grid max-w-[1215px] items-center gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="relative overflow-hidden rounded-[30px] border border-white/20 bg-white/10 p-2">
            <img
              src={data.whoImage || DEFAULT_ABOUT_IMAGE}
              alt={data.whoTitleAccent}
              onError={(event) => {
                event.currentTarget.src = DEFAULT_ABOUT_IMAGE;
              }}
              className="h-[420px] w-full rounded-[22px] object-cover"
            />
            <div className="absolute bottom-10 left-10 rounded-full bg-white px-8 py-5 text-sm font-black text-[#002f70] shadow-xl">
              {data.whoImageLabel}
            </div>
          </div>

          <div>
            <span className="inline-flex rounded-full border border-white/20 bg-white/10 px-5 py-2 text-xs font-black uppercase tracking-[0.28em] text-[#d8f3ff]">
              {data.whoBadge}
            </span>
            <h1 className="mt-7 text-5xl font-black leading-tight">
              {data.whoTitleMain}{" "}
              <span className="bg-gradient-to-r from-[#6ed2ff] to-[#c8f28a] bg-clip-text text-transparent">
                {data.whoTitleAccent}
              </span>
            </h1>
            <p className="mt-7 max-w-[670px] text-lg font-bold leading-8 text-white/90">
              {data.whoDescription}
            </p>

            <div className="mt-10 grid gap-4 md:grid-cols-3">
              {whoCards.map((item, index) => (
                <article
                  key={item.id}
                  className="rounded-2xl border border-white/15 bg-white/10 p-5"
                >
                  <div
                    className={`grid h-12 w-12 place-items-center rounded-xl ${
                      index % 3 === 0
                        ? "bg-[#35bbea]/20 text-[#6ed2ff]"
                        : index % 3 === 1
                          ? "bg-[#8cc63f]/20 text-[#b8ee77]"
                          : "bg-[#8061bd]/25 text-[#d9c7ff]"
                    }`}
                  >
                    <AboutIcon
                      icon={item.icon}
                      className="h-6 w-6"
                      strokeWidth={2.4}
                    />
                  </div>
                  <h3 className="mt-6 font-black">{item.title}</h3>
                  <p className="mt-2 text-sm font-semibold leading-6 text-white/75">
                    {item.text}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-[#f8fbff] px-5 py-20">
        <GridBg />
        <div className="relative mx-auto max-w-[1215px]">
          <div className="text-center">
            <h2 className="text-4xl font-black leading-tight md:text-5xl">
              {data.transformTitleMain}
              <span className="block bg-gradient-to-r from-[#8061bd] to-[#35bbea] bg-clip-text text-transparent">
                {data.transformTitleAccent}
              </span>
            </h2>
            <div className="mx-auto mt-3 h-1.5 w-[320px] max-w-full rounded-full bg-gradient-to-r from-[#35bbea] via-[#8061bd] to-transparent" />
          </div>

          <div className="mt-16 grid items-end gap-7 md:grid-cols-4">
            {transformImages.map((item, index) => (
              <article
                key={item.id}
                className={`relative overflow-hidden rounded-[30px] border-[9px] border-white bg-[#dfeaf6] shadow-xl ${
                  index % 2 === 1 ? "md:translate-y-8" : ""
                }`}
              >
                <img
                  src={item.image || DEFAULT_ABOUT_IMAGE}
                  alt={item.label}
                  onError={(event) => {
                    event.currentTarget.src = DEFAULT_ABOUT_IMAGE;
                  }}
                  className="h-[480px] w-full object-cover"
                />
                <div className="absolute left-5 top-5 grid h-12 w-12 place-items-center rounded-xl bg-white/40 text-white backdrop-blur">
                  <AboutIcon
                    icon={item.icon}
                    className="h-6 w-6"
                    strokeWidth={2.4}
                  />
                </div>
                <span className="absolute bottom-6 left-6 rounded-full bg-white px-5 py-3 text-sm font-black">
                  {item.label}
                </span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="relative bg-[#f8fbff] px-5 py-16">
        <GridBg />
        <div className="relative mx-auto grid max-w-[920px] gap-10 md:grid-cols-2">
          <InfoCard title={data.visionTitle} text={data.visionText} />
          <InfoCard title={data.missionTitle} text={data.missionText} />
        </div>

        <div className="relative mx-auto mt-20 max-w-[920px] text-center">
          <SectionPill>{data.valuesTitle}</SectionPill>
          <p className="mx-auto mt-8 max-w-[720px] font-bold leading-8 text-[#4d627d]">
            {data.valuesIntro}
          </p>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {values.map((item, index) => (
              <article
                key={item.id}
                className="rounded-3xl border border-[#dce8f7] bg-white p-7 shadow-sm"
              >
                <div
                  className={`mx-auto grid h-20 w-20 place-items-center rounded-2xl ${
                    index % 5 === 0
                      ? "bg-[#eefbdc] text-[#8cc63f]"
                      : index % 5 === 1
                        ? "bg-[#f0e7ff] text-[#8061bd]"
                        : index % 5 === 2
                          ? "bg-[#ffe4e8] text-[#ef233c]"
                          : index % 5 === 3
                            ? "bg-[#e2f7ff] text-[#1aaad9]"
                            : "bg-[#edf1f7] text-[#002f70]"
                  }`}
                >
                  <AboutIcon
                    icon={item.icon}
                    className="h-10 w-10"
                    strokeWidth={2.6}
                  />
                </div>
                <h3 className="mt-7 text-xl font-black">{item.title}</h3>
                <p className="mt-4 font-semibold leading-7 text-[#4d627d]">
                  {item.text}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="relative bg-[#f8fbff] px-5 py-20">
        <GridBg />
        <div className="relative mx-auto grid max-w-[1215px] items-center gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="relative overflow-hidden rounded-[30px] border-[9px] border-white bg-[#dfeaf6] shadow-xl">
            <img
              src={data.learningImage || DEFAULT_ABOUT_IMAGE}
              alt={data.learningTitle}
              onError={(event) => {
                event.currentTarget.src = DEFAULT_ABOUT_IMAGE;
              }}
              className="h-[440px] w-full object-cover"
            />
            <span className="absolute bottom-6 left-6 rounded-full bg-white px-7 py-4 text-xs font-black uppercase tracking-[0.18em]">
              {data.learningImageLabel}
            </span>
          </div>

          <div>
            <span className="inline-flex rounded-full border border-[#d5e4f7] bg-white px-5 py-2 text-xs font-black uppercase tracking-[0.28em] text-[#8061bd]">
              {data.learningBadge}
            </span>
            <h2 className="mt-7 text-4xl font-black leading-tight md:text-5xl">
              {data.learningTitle}{" "}
              <span className="bg-gradient-to-r from-[#8061bd] to-[#35bbea] bg-clip-text text-transparent">
                {data.learningAccent}
              </span>
            </h2>
            <p className="mt-8 text-lg font-bold leading-8 text-[#4d627d]">
              {data.learningDescription}
            </p>

            <div className="mt-10 grid gap-5 md:grid-cols-3">
              {learningCards.map((item) => (
                <article
                  key={item.id}
                  className="rounded-2xl border border-[#dce8f7] bg-white p-5"
                >
                  <div className="grid h-12 w-12 place-items-center rounded-xl bg-[#e4f7ff] text-[#35bbea]">
                    <AboutIcon
                      icon={item.icon}
                      className="h-6 w-6"
                      strokeWidth={2.4}
                    />
                  </div>
                  <h3 className="mt-6 font-black">{item.title}</h3>
                  <p className="mt-2 text-sm font-semibold leading-6 text-[#4d627d]">
                    {item.text}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function GridBg() {
  return (
    <>
      <div className="absolute inset-0 opacity-70 [background-image:radial-gradient(#d8e6f7_1px,transparent_1px)] [background-size:22px_22px]" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#eaf8ff]/70 via-white/70 to-[#fff3ff]/70" />
    </>
  );
}

function SectionPill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex rounded-2xl border border-[#d5e4f7] bg-white px-8 py-4 text-2xl font-black uppercase tracking-[0.22em] text-[#002f70] shadow-sm">
      {children}
    </span>
  );
}

function InfoCard({ title, text }: { title: string; text: string }) {
  return (
    <article className="rounded-3xl border border-[#dce8f7] bg-white/80 p-9 text-center shadow-sm">
      <SectionPill>{title}</SectionPill>
      <p className="mt-8 font-bold leading-8 text-[#4d627d]">{text}</p>
    </article>
  );
}
