// File: clinic-website/src/components/about/MedicalEducationFeature.tsx

import Image from "next/image";
import { Award, BookOpenCheck, GraduationCap, Stethoscope } from "lucide-react";

export default function MedicalEducationFeature() {
  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 sm:py-14 lg:py-20">
      {/* Premium Simple Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />

        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
        <div className="absolute left-[45%] top-[40%] h-[300px] w-[300px] rounded-full bg-[#8cc63f]/8 blur-[100px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,45,98,0.055)_1px,transparent_0)] [background-size:30px_30px]" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062d62]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto grid w-full max-w-7xl items-center gap-8 px-4 sm:px-6 lg:grid-cols-[0.82fr_1.18fr] lg:gap-10 lg:px-8">
        {/* Image */}
        <div className="group relative min-h-[245px] overflow-hidden rounded-[24px] border border-white/80 bg-white/75 p-1.5 shadow-[0_22px_60px_rgba(6,45,98,0.10)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_80px_rgba(6,45,98,0.16)] sm:min-h-[390px] sm:rounded-[30px] sm:p-2 lg:min-h-[460px]">
          <div className="relative h-full min-h-[230px] overflow-hidden rounded-[20px] bg-slate-100 sm:min-h-[370px] sm:rounded-[24px] lg:min-h-[440px]">
            <Image
              src="/news/news-2.jpg"
              alt="Medical education event at Update Diagnostic Center"
              fill
              sizes="(max-width: 1024px) 100vw, 520px"
              className="object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
            />

            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#062d62]/55 via-[#062d62]/10 to-transparent opacity-85 transition-opacity duration-500 group-hover:opacity-95" />

            {/* Floating Icon Badge */}
            <div className="absolute left-5 top-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-white/25 bg-white/20 text-white shadow-[0_18px_45px_rgba(6,45,98,0.24)] backdrop-blur-md transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-white group-hover:text-[#062d62]">
              <GraduationCap
                size={27}
                className="transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110"
              />
            </div>

            {/* Bottom Badge */}
            <div className="absolute bottom-5 left-5 rounded-full border border-white/25 bg-white/90 px-4 py-3 text-xs font-black uppercase tracking-[0.16em] text-[#062d62] shadow-[0_16px_40px_rgba(6,45,98,0.18)] backdrop-blur-md">
              Medical Education
            </div>

            <div className="pointer-events-none absolute inset-y-0 left-0 w-20 -translate-x-28 rotate-12 bg-white/25 blur-md transition-transform duration-1000 group-hover:translate-x-[520px]" />
          </div>
        </div>

        {/* Content */}
        <article className="text-[#062d62]">
          <div className="mb-5 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,45,98,0.08)] backdrop-blur-md">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062d62] text-white shadow-[0_10px_25px_rgba(6,45,98,0.18)] transition-all duration-300 hover:-translate-y-0.5 hover:rotate-6 hover:scale-110">
              <BookOpenCheck size={16} />
            </span>

            <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
              Medical Learning
            </span>
          </div>

          <h2 className="max-w-[760px] text-3xl font-black leading-tight text-[#062d62] sm:text-4xl lg:text-5xl">
            The first MRCP{" "}
            <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062d62] bg-clip-text text-transparent">
              (UK) PACES
              <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
            </span>{" "}
            examination center in Bangladesh
          </h2>

          <p className="mt-6 max-w-[760px] text-sm font-semibold leading-7 text-[#4d6380] sm:mt-8 sm:text-base lg:text-lg lg:leading-8">
            Update Diagnostic Center is committed to strengthening healthcare
            standards through skilled clinicians, modern diagnostic services,
            and continuous medical learning. This development supports aspiring
            physicians, improves local training access, and helps patients
            receive more confident specialist care close to home.
          </p>

          {/* Simple Animated Icon Cards */}
          <div className="mt-6 grid gap-3 sm:mt-8 sm:grid-cols-3 sm:gap-4">
            <div className="group rounded-[22px] border border-[#dbeafe] bg-white/80 p-5 shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white hover:shadow-[0_22px_60px_rgba(6,45,98,0.12)]">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#43c7f4]/12 text-[#43c7f4] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#43c7f4] group-hover:text-white">
                <GraduationCap size={23} />
              </span>
              <p className="mt-4 text-sm font-black leading-5 text-[#062d62]">
                Medical Training
              </p>
            </div>

            <div className="group rounded-[22px] border border-[#dbeafe] bg-white/80 p-5 shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white hover:shadow-[0_22px_60px_rgba(6,45,98,0.12)]">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8a6bb8]/12 text-[#8a6bb8] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#8a6bb8] group-hover:text-white">
                <Award size={23} />
              </span>
              <p className="mt-4 text-sm font-black leading-5 text-[#062d62]">
                Global Standard
              </p>
            </div>

            <div className="group rounded-[22px] border border-[#dbeafe] bg-white/80 p-5 shadow-[0_16px_45px_rgba(6,45,98,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white hover:shadow-[0_22px_60px_rgba(6,45,98,0.12)]">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8cc63f]/14 text-[#76a92f] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#8cc63f] group-hover:text-white">
                <Stethoscope size={23} />
              </span>
              <p className="mt-4 text-sm font-black leading-5 text-[#062d62]">
                Specialist Care
              </p>
            </div>
          </div>
        </article>
      </div>
    </section>
  );
}
