// File: clinic-website/src/components/about/WhoWeAre.tsx

import Image from "next/image";
import { HeartPulse, ShieldCheck, Stethoscope } from "lucide-react";

export default function WhoWeAre() {
  return (
    <section className="relative overflow-hidden bg-[#062d62] py-10 text-white sm:py-14 lg:py-20">
      {/* Premium Simple Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#041d43_0%,#062d62_48%,#083f82_100%)]" />
        <div className="absolute left-[-180px] top-[-140px] h-[380px] w-[380px] rounded-full bg-[#43c7f4]/18 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-160px] h-[420px] w-[420px] rounded-full bg-[#8a6bb8]/18 blur-[115px]" />
        <div className="absolute left-1/2 top-[45%] h-[280px] w-[280px] -translate-x-1/2 rounded-full bg-[#8cc63f]/10 blur-[95px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.10)_1px,transparent_0)] [background-size:30px_30px] opacity-30" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/35 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto grid w-full max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-[0.86fr_1fr] lg:gap-12 lg:px-8">
        {/* Image */}
        <div className="group relative min-h-[240px] overflow-hidden rounded-[24px] border border-white/15 bg-white/10 p-1.5 shadow-[0_24px_70px_rgba(0,0,0,0.22)] backdrop-blur-xl sm:min-h-[360px] sm:rounded-[28px] sm:p-2 lg:min-h-[430px]">
          <div className="relative h-full min-h-[225px] overflow-hidden rounded-[20px] bg-white sm:min-h-[340px] sm:rounded-[22px] lg:min-h-[410px]">
            <Image
              src="/pasent.jpeg"
              alt="Caregiver holding a patient's hand"
              fill
              sizes="(max-width: 1024px) 100vw, 500px"
              className="object-cover object-center transition-transform duration-[1200ms] ease-out group-hover:scale-105"
            />

            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#062d62]/35 via-transparent to-transparent" />

            <div className="absolute bottom-5 left-5 flex items-center gap-3 rounded-full border border-white/25 bg-white/90 px-4 py-3 text-[#062d62] shadow-[0_18px_45px_rgba(6,45,98,0.22)] backdrop-blur-md">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#43c7f4]/12 text-[#43c7f4] transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-12 group-hover:scale-110">
                <HeartPulse size={21} />
              </span>

              <span className="text-sm font-black">Patient First Care</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-[720px]">
          <div className="mb-5 inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/10 px-4 py-2 shadow-[0_18px_45px_rgba(0,0,0,0.16)] backdrop-blur-xl">
            <span className="h-2.5 w-2.5 rounded-full bg-[#43c7f4] shadow-[0_0_0_6px_rgba(67,199,244,0.15)]" />
            <span className="text-xs font-black uppercase tracking-[0.2em] text-[#bdeeff]">
              About Us
            </span>
          </div>

          <h2 className="text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
            Who{" "}
            <span className="bg-gradient-to-r from-[#43c7f4] via-white to-[#8cc63f] bg-clip-text text-transparent">
              We Are
            </span>
          </h2>

          <p className="mt-4 text-sm font-semibold leading-7 text-blue-50/90 sm:mt-6 sm:text-base lg:text-lg lg:leading-8">
            <strong className="text-white">Update Diagnostic Center</strong> is
            a trusted healthcare destination committed to providing coordinated
            medical, diagnostic, and wellness services. We focus on accessible
            care, patient safety, and clear communication so every visitor feels
            supported from consultation to recovery.
          </p>

          {/* Simple Icon Features */}
          <div className="mt-6 grid gap-3 sm:mt-8 sm:grid-cols-3 sm:gap-4">
            <div className="group rounded-[20px] border border-white/12 bg-white/10 p-4 shadow-[0_18px_45px_rgba(0,0,0,0.16)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white/15 sm:rounded-[22px] sm:p-5">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#43c7f4]/15 text-[#7ee3ff] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#43c7f4] group-hover:text-white">
                <Stethoscope size={23} />
              </span>
              <p className="mt-4 text-sm font-black leading-5 text-white">
                Expert Medical Care
              </p>
            </div>

            <div className="group rounded-[20px] border border-white/12 bg-white/10 p-4 shadow-[0_18px_45px_rgba(0,0,0,0.16)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white/15 sm:rounded-[22px] sm:p-5">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8cc63f]/15 text-[#b9f06c] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#8cc63f] group-hover:text-white">
                <ShieldCheck size={23} />
              </span>
              <p className="mt-4 text-sm font-black leading-5 text-white">
                Patient Safety
              </p>
            </div>

            <div className="group rounded-[20px] border border-white/12 bg-white/10 p-4 shadow-[0_18px_45px_rgba(0,0,0,0.16)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white/15 sm:rounded-[22px] sm:p-5">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8a6bb8]/18 text-[#d8c7ff] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#8a6bb8] group-hover:text-white">
                <HeartPulse size={23} />
              </span>
              <p className="mt-4 text-sm font-black leading-5 text-white">
                Trusted Support
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
