// File: clinic-website/src/components/about/HealthcareGallery.tsx

import Image from "next/image";
import { HeartPulse, ShieldCheck, Sparkles, Stethoscope } from "lucide-react";

const galleryImages = [
  {
    src: "/slider1.jpeg",
    alt: "Specialist care team supporting a hospital patient",
    className: "lg:translate-y-0",
    icon: Stethoscope,
  },
  {
    src: "/blogs/blog-2.jpg",
    alt: "Family receiving maternity care support",
    className: "lg:translate-y-8",
    icon: HeartPulse,
  },
  {
    src: "/doctor-articles/doctor-1.jpg",
    alt: "Doctor reviewing patient information",
    className: "lg:translate-y-0",
    icon: ShieldCheck,
  },
  {
    src: "/news/news-3.jpg",
    alt: "Nurse helping an elderly patient",
    className: "lg:translate-y-8",
    icon: Sparkles,
  },
];

export default function HealthcareGallery() {
  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 sm:py-14 lg:py-20">
      {/* Premium Simple Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_45%,#f8f3ff_100%)]" />

        <div className="absolute left-[-180px] top-[-140px] h-[390px] w-[390px] rounded-full bg-[#43c7f4]/14 blur-[105px]" />
        <div className="absolute right-[-190px] bottom-[-150px] h-[430px] w-[430px] rounded-full bg-[#8a6bb8]/14 blur-[115px]" />
        <div className="absolute left-1/2 top-[45%] h-[300px] w-[300px] -translate-x-1/2 rounded-full bg-[#8cc63f]/8 blur-[100px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,47,102,0.055)_1px,transparent_0)] [background-size:30px_30px]" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062d62]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,47,102,0.08)] backdrop-blur-md">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062d62] text-white shadow-[0_10px_25px_rgba(6,45,98,0.18)]">
              <HeartPulse size={16} />
            </span>

            <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
              Healthcare Gallery
            </span>
          </div>

          <h2 className="text-center text-3xl font-black leading-tight text-[#062d62] sm:text-4xl lg:text-5xl">
            Transforming Healthcare{" "}
            <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062d62] bg-clip-text text-transparent">
              in Bangladesh
              <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
            </span>
          </h2>
        </div>

        {/* Gallery */}
        <div className="mt-8 grid gap-4 sm:mt-12 sm:grid-cols-2 lg:mt-16 lg:grid-cols-4 lg:gap-5">
          {galleryImages.map((image, index) => {
            const Icon = image.icon;

            return (
              <div
                key={image.src}
                className={`group relative h-[260px] overflow-hidden rounded-[22px] border border-white/80 bg-white/70 p-1.5 shadow-[0_18px_45px_rgba(6,47,102,0.10)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_26px_70px_rgba(6,47,102,0.16)] sm:h-[420px] sm:rounded-[28px] sm:p-2 lg:h-[496px] ${image.className}`}
              >
                <div className="relative h-full overflow-hidden rounded-[22px] bg-slate-100">
                  <Image
                    src={image.src}
                    alt={image.alt}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 290px"
                    className="object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-110"
                  />

                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#062d62]/55 via-[#062d62]/8 to-transparent opacity-85 transition-opacity duration-500 group-hover:opacity-95" />

                  {/* Animated Icon */}
                  <div className="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/25 bg-white/20 text-white shadow-[0_16px_40px_rgba(6,47,102,0.22)] backdrop-blur-md transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-white group-hover:text-[#062d62]">
                    <Icon
                      size={23}
                      className="transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110"
                    />
                  </div>

                  {/* Number Badge */}
                  <div className="absolute bottom-5 left-5 rounded-full border border-white/25 bg-white/90 px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-[#062d62] shadow-[0_14px_35px_rgba(6,47,102,0.18)] backdrop-blur-md">
                    {String(index + 1).padStart(2, "0")}
                  </div>

                  {/* Soft Shine */}
                  <div className="pointer-events-none absolute inset-y-0 left-0 w-20 -translate-x-28 rotate-12 bg-white/25 blur-md transition-transform duration-1000 group-hover:translate-x-[420px]" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
