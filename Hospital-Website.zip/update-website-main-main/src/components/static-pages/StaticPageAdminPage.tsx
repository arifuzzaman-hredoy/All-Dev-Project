import { requireAdminSession } from "@/lib/admin-session";
import {
  getStaticPage,
  STATIC_PAGE_ROUTE_LABELS,
  type StaticPageKey,
} from "@/lib/static-pages";
import StaticPageAdminEditor from "@/components/static-pages/StaticPageAdminEditor";

type StaticPageAdminPageProps = {
  pageKey: StaticPageKey;
};

export default async function StaticPageAdminPage({
  pageKey,
}: StaticPageAdminPageProps) {
  await requireAdminSession();
  const page = await getStaticPage(pageKey);

  return (
    <StaticPageAdminEditor
      initialPage={page}
      routeLabel={`Public pages / ${STATIC_PAGE_ROUTE_LABELS[pageKey]}`}
    />
  );
}
