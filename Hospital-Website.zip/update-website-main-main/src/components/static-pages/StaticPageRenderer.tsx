import Image from "next/image";
import Link from "next/link";
import { ArrowRight, CheckCircle2, FileText, Sparkles } from "lucide-react";

import type { StaticPageContent } from "@/lib/static-pages";

type StaticPageRendererProps = {
  page: StaticPageContent;
};

function isExternalHref(href: string) {
  return href.startsWith("http") || href.startsWith("mailto:") || href.startsWith("tel:");
}

function ActionLink({ href, label, primary = false }: { href: string; label: string; primary?: boolean }) {
  if (!href || !label) return null;

  const className = primary
    ? "inline-flex items-center justify-center gap-2 rounded-full bg-[#43c7f4] px-6 py-3 text-sm font-black text-white shadow-[0_16px_35px_rgba(67,199,244,0.30)] transition hover:-translate-y-0.5 hover:bg-[#17a9de]"
    : "inline-flex items-center justify-center gap-2 rounded-full border border-[#dbe8ff] bg-white px-6 py-3 text-sm font-black text-[#062f66] shadow-sm transition hover:-translate-y-0.5 hover:border-[#43c7f4]";

  if (isExternalHref(href)) {
    return (
      <a href={href} className={className}>
        {label}
        <ArrowRight size={16} />
      </a>
    );
  }

  return (
    <Link href={href} className={className}>
      {label}
      <ArrowRight size={16} />
    </Link>
  );
}

export default function StaticPageRenderer({ page }: StaticPageRendererProps) {
  return (
    <main className="overflow-hidden bg-[#f7fbff]">
      <section className="relative px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
        <div className="pointer-events-none absolute -left-32 top-16 h-80 w-80 rounded-full bg-[#43c7f4]/15 blur-[90px]" />
        <div className="pointer-events-none absolute -right-32 bottom-8 h-96 w-96 rounded-full bg-[#062f66]/10 blur-[100px]" />

        <div className="relative mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1.08fr_0.92fr] lg:items-center">
          <div className="rounded-[34px] border border-white/80 bg-white/85 p-6 shadow-[0_28px_90px_rgba(6,47,102,0.10)] backdrop-blur-xl sm:p-9 lg:p-11">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#cfefff] bg-[#f0fbff] px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] text-[#1597c7]">
              <Sparkles size={14} />
              {page.eyebrow}
            </div>

            <h1 className="max-w-4xl text-4xl font-black tracking-[-0.05em] text-[#062f66] sm:text-5xl lg:text-6xl">
              {page.title}
            </h1>

            <p className="mt-5 max-w-3xl text-base font-semibold leading-8 text-[#5d6f86] sm:text-lg">
              {page.description}
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <ActionLink href={page.primaryButtonHref} label={page.primaryButtonLabel} primary />
              <ActionLink href={page.secondaryButtonHref} label={page.secondaryButtonLabel} />
            </div>
          </div>

          <div className="relative overflow-hidden rounded-[34px] border border-white/70 bg-white shadow-[0_28px_90px_rgba(6,47,102,0.12)]">
            {page.heroImage ? (
              <Image
                src={page.heroImage}
                alt={page.title}
                width={900}
                height={680}
                className="h-[360px] w-full object-cover sm:h-[460px] lg:h-[520px]"
                priority
              />
            ) : (
              <div className="grid h-[360px] place-items-center bg-gradient-to-br from-[#062f66] to-[#43c7f4] p-8 text-center text-white sm:h-[460px] lg:h-[520px]">
                <div>
                  <FileText className="mx-auto mb-5" size={52} />
                  <p className="text-3xl font-black">{page.title}</p>
                </div>
              </div>
            )}
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#062f66]/80 to-transparent p-6 text-white">
              <p className="text-sm font-black uppercase tracking-[0.18em] text-cyan-100">Update Diagnostic Center</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 pb-16 sm:px-6 lg:px-8 lg:pb-24">
        <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          <aside className="space-y-4">
            <div className="rounded-[30px] border border-[#dbe8ff] bg-white p-6 shadow-[0_20px_60px_rgba(6,47,102,0.08)]">
              <p className="text-xs font-black uppercase tracking-[0.18em] text-[#43c7f4]">Quick highlights</p>
              <div className="mt-5 grid gap-3">
                {page.highlights.map((item) => (
                  <div key={item} className="flex items-start gap-3 rounded-2xl border border-slate-100 bg-[#f8fbff] p-4 text-sm font-bold leading-6 text-[#4d6380]">
                    <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-[#43c7f4]" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </aside>

          <div className="space-y-6">
            <article className="rounded-[30px] border border-[#dbe8ff] bg-white p-6 shadow-[0_20px_60px_rgba(6,47,102,0.08)] sm:p-8">
              <p className="text-xs font-black uppercase tracking-[0.18em] text-[#43c7f4]">Details</p>
              <div className="mt-5 space-y-5">
                {page.body.map((paragraph) => (
                  <p key={paragraph} className="text-base font-semibold leading-8 text-[#5d6f86]">
                    {paragraph}
                  </p>
                ))}
              </div>
            </article>

            <div className="grid gap-4 sm:grid-cols-2">
              {page.cards.map((card) => (
                <article key={card.title} className="group rounded-[26px] border border-[#dbe8ff] bg-white p-5 shadow-[0_18px_50px_rgba(6,47,102,0.07)] transition hover:-translate-y-1 hover:border-[#43c7f4]/50 hover:shadow-[0_24px_65px_rgba(6,47,102,0.12)]">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eaf7ff] text-[#062f66] transition group-hover:bg-[#43c7f4] group-hover:text-white">
                    <FileText size={22} />
                  </div>
                  <h2 className="text-xl font-black text-[#062f66]">{card.title}</h2>
                  <p className="mt-3 text-sm font-semibold leading-7 text-[#5d6f86]">{card.description}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
