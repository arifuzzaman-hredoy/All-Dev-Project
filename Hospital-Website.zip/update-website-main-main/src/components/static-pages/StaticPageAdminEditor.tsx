"use client";

import { useMemo, useState } from "react";
import clsx from "clsx";
import {
  CheckCircle2,
  Eye,
  FileText,
  ImageIcon,
  Loader2,
  RefreshCcw,
  Save,
  ShieldCheck,
} from "lucide-react";

import type { StaticPageContent } from "@/lib/static-pages";

type StaticPageAdminEditorProps = {
  initialPage: StaticPageContent;
  routeLabel: string;
};

type Draft = Omit<StaticPageContent, "body" | "highlights" | "cards"> & {
  bodyText: string;
  highlightsText: string;
  cardsText: string;
};

function cardsToText(cards: StaticPageContent["cards"]) {
  return cards.map((card) => `${card.title} | ${card.description}`).join("\n");
}

function textToCards(value: string) {
  return value
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [title, ...description] = line.split("|").map((part) => part.trim());
      return {
        title: title || "Untitled card",
        description: description.join(" | ") || "Add card description here.",
      };
    });
}

function textToList(value: string) {
  return value
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
}

function toDraft(page: StaticPageContent): Draft {
  return {
    ...page,
    bodyText: page.body.join("\n\n"),
    highlightsText: page.highlights.join("\n"),
    cardsText: cardsToText(page.cards),
  };
}

function toPayload(draft: Draft): StaticPageContent {
  return {
    ...draft,
    body: textToList(draft.bodyText),
    highlights: textToList(draft.highlightsText),
    cards: textToCards(draft.cardsText),
  };
}

export default function StaticPageAdminEditor({
  initialPage,
  routeLabel,
}: StaticPageAdminEditorProps) {
  const [draft, setDraft] = useState<Draft>(() => toDraft(initialPage));
  const [savedPage, setSavedPage] = useState(initialPage);
  const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">(
    "idle",
  );
  const [message, setMessage] = useState("");

  const preview = useMemo(() => toPayload(draft), [draft]);

  function updateField<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
    setStatus("idle");
    setMessage("");
  }

  async function handleSave() {
    setStatus("saving");
    setMessage("");

    try {
      const response = await fetch(`/api/admin/static-pages/${draft.key}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ page: preview }),
      });

      const data = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(data?.message || "Static page save failed.");
      }

      setSavedPage(data.page);
      setDraft(toDraft(data.page));
      setStatus("saved");
      setMessage("Saved to database. Public page will show this content after refresh.");
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Save failed.");
    }
  }

  async function handleReset() {
    const confirmed = window.confirm(
      "Reset this page to default demo content? Current saved content will be replaced.",
    );

    if (!confirmed) return;

    setStatus("saving");
    setMessage("");

    try {
      const response = await fetch(`/api/admin/static-pages/${draft.key}/reset`, {
        method: "POST",
      });
      const data = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(data?.message || "Reset failed.");
      }

      setSavedPage(data.page);
      setDraft(toDraft(data.page));
      setStatus("saved");
      setMessage("Default content restored and saved to database.");
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Reset failed.");
    }
  }

  return (
    <section className="grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_400px]">
      <div className="space-y-6">
        <div className="overflow-hidden rounded-[30px] border border-[#dbe8ff] bg-white shadow-[0_22px_70px_rgba(6,47,102,0.08)]">
          <div className="bg-gradient-to-br from-[#062f66] via-[#0b4d8d] to-[#43c7f4] p-6 text-white sm:p-8">
            <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100">
              {routeLabel}
            </p>
            <h1 className="mt-3 text-2xl font-black tracking-[-0.03em] sm:text-4xl">
              Static Page DB Editor
            </h1>
            <p className="mt-3 max-w-3xl text-sm font-semibold leading-7 text-blue-50 sm:text-base">
              Edit this public page from the admin panel. Save goes directly to PostgreSQL, so another browser/device will see the same content.
            </p>
          </div>

          <div className="grid gap-4 p-5 sm:p-7">
            {message ? (
              <div
                className={clsx(
                  "rounded-2xl border px-4 py-3 text-sm font-bold",
                  status === "error"
                    ? "border-rose-200 bg-rose-50 text-rose-700"
                    : "border-emerald-200 bg-emerald-50 text-emerald-700",
                )}
              >
                {message}
              </div>
            ) : null}

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <span className="text-sm font-black text-[#062f66]">Eyebrow</span>
                <input
                  value={draft.eyebrow}
                  onChange={(event) => updateField("eyebrow", event.target.value)}
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4]"
                />
              </label>

              <label className="block rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <span className="text-sm font-black text-[#062f66]">Hero image URL</span>
                <div className="mt-3 flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 focus-within:border-[#43c7f4]">
                  <ImageIcon size={18} className="text-slate-400" />
                  <input
                    value={draft.heroImage}
                    onChange={(event) => updateField("heroImage", event.target.value)}
                    placeholder="/slider1.jpeg"
                    className="w-full bg-transparent text-sm font-semibold text-slate-700 outline-none"
                  />
                </div>
              </label>
            </div>

            <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
              <span className="text-sm font-black text-[#062f66]">Page title</span>
              <input
                value={draft.title}
                onChange={(event) => updateField("title", event.target.value)}
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
              />
            </label>

            <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
              <span className="text-sm font-black text-[#062f66]">Short description</span>
              <textarea
                value={draft.description}
                onChange={(event) => updateField("description", event.target.value)}
                rows={3}
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold leading-7 text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
              />
            </label>

            <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
              <span className="text-sm font-black text-[#062f66]">Body paragraphs</span>
              <span className="mt-1 block text-xs font-semibold text-slate-500">
                One paragraph per line or blank-space separated paragraph block.
              </span>
              <textarea
                value={draft.bodyText}
                onChange={(event) => updateField("bodyText", event.target.value)}
                rows={8}
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold leading-7 text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
              />
            </label>

            <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
              <span className="text-sm font-black text-[#062f66]">Highlights</span>
              <span className="mt-1 block text-xs font-semibold text-slate-500">
                One highlight per line.
              </span>
              <textarea
                value={draft.highlightsText}
                onChange={(event) => updateField("highlightsText", event.target.value)}
                rows={5}
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold leading-7 text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
              />
            </label>

            <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
              <span className="text-sm font-black text-[#062f66]">Cards</span>
              <span className="mt-1 block text-xs font-semibold text-slate-500">
                Format: Title | Description. One card per line.
              </span>
              <textarea
                value={draft.cardsText}
                onChange={(event) => updateField("cardsText", event.target.value)}
                rows={6}
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold leading-7 text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
              />
            </label>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <span className="text-sm font-black text-[#062f66]">Primary button label</span>
                <input
                  value={draft.primaryButtonLabel}
                  onChange={(event) => updateField("primaryButtonLabel", event.target.value)}
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4]"
                />
              </label>

              <label className="block rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <span className="text-sm font-black text-[#062f66]">Primary button URL</span>
                <input
                  value={draft.primaryButtonHref}
                  onChange={(event) => updateField("primaryButtonHref", event.target.value)}
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4]"
                />
              </label>

              <label className="block rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <span className="text-sm font-black text-[#062f66]">Secondary button label</span>
                <input
                  value={draft.secondaryButtonLabel}
                  onChange={(event) => updateField("secondaryButtonLabel", event.target.value)}
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4]"
                />
              </label>

              <label className="block rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <span className="text-sm font-black text-[#062f66]">Secondary button URL</span>
                <input
                  value={draft.secondaryButtonHref}
                  onChange={(event) => updateField("secondaryButtonHref", event.target.value)}
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4]"
                />
              </label>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
                <span className="text-sm font-black text-[#062f66]">SEO title</span>
                <input
                  value={draft.seoTitle}
                  onChange={(event) => updateField("seoTitle", event.target.value)}
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
                />
              </label>

              <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
                <span className="text-sm font-black text-[#062f66]">Publish status</span>
                <select
                  value={draft.status}
                  onChange={(event) =>
                    updateField("status", event.target.value as Draft["status"])
                  }
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
                >
                  <option value="PUBLISHED">Published</option>
                  <option value="DRAFT">Draft</option>
                  <option value="ARCHIVED">Archived</option>
                </select>
              </label>
            </div>

            <label className="block rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
              <span className="text-sm font-black text-[#062f66]">SEO description</span>
              <textarea
                value={draft.seoDescription}
                onChange={(event) => updateField("seoDescription", event.target.value)}
                rows={3}
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold leading-7 text-slate-700 outline-none focus:border-[#43c7f4] focus:bg-white"
              />
            </label>

            <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <button
                type="button"
                onClick={handleSave}
                disabled={status === "saving"}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-[#062f66] px-6 py-3 text-sm font-black text-white shadow-[0_16px_35px_rgba(6,47,102,0.20)] transition hover:-translate-y-0.5 hover:bg-[#0b4d8d] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {status === "saving" ? <Loader2 size={17} className="animate-spin" /> : <Save size={17} />}
                Save to database
              </button>

              <button
                type="button"
                onClick={handleReset}
                disabled={status === "saving"}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-6 py-3 text-sm font-black text-slate-700 transition hover:-translate-y-0.5 hover:border-[#43c7f4] hover:text-[#062f66] disabled:cursor-not-allowed disabled:opacity-60"
              >
                <RefreshCcw size={17} />
                Reset default
              </button>
            </div>
          </div>
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-[30px] border border-[#dbe8ff] bg-white p-5 shadow-[0_18px_55px_rgba(6,47,102,0.08)]">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#eaf7ff] text-[#062f66]">
              <Eye size={22} />
            </span>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">Public URL</p>
              <p className="text-sm font-black text-[#062f66]">/{draft.slug}</p>
            </div>
          </div>
        </div>

        <div className="rounded-[30px] border border-[#dbe8ff] bg-[#062f66] p-5 text-white shadow-[0_18px_55px_rgba(6,47,102,0.18)]">
          <div className="mb-4 flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/15 text-white">
              <FileText size={20} />
            </span>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-100">Live preview</p>
              <p className="text-sm font-bold text-white">{preview.title}</p>
            </div>
          </div>

          <div className="rounded-3xl bg-white/10 p-4">
            <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-100">{preview.eyebrow}</p>
            <h2 className="mt-3 text-xl font-black leading-tight text-white">{preview.title}</h2>
            <p className="mt-3 text-sm font-semibold leading-6 text-blue-50">{preview.description}</p>
          </div>

          <div className="mt-4 grid gap-2">
            {preview.highlights.slice(0, 5).map((item) => (
              <div key={item} className="flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 text-xs font-bold text-blue-50">
                <CheckCircle2 size={14} className="text-[#43c7f4]" />
                {item}
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-[30px] border border-emerald-200 bg-emerald-50 p-5 text-emerald-900">
          <div className="flex items-start gap-3">
            <ShieldCheck size={22} className="mt-1 shrink-0" />
            <p className="text-sm font-bold leading-7">
              Last saved page: {savedPage.title}. This editor writes to DB API only.
            </p>
          </div>
        </div>
      </aside>
    </section>
  );
}
