import type { Metadata } from "next";

import StaticPageRenderer from "@/components/static-pages/StaticPageRenderer";
import {
  getPublicStaticPageBySlug,
  getStaticPage,
  type StaticPageKey,
} from "@/lib/static-pages";

export async function getStaticDbPageMetadata(
  pageKey: StaticPageKey,
): Promise<Metadata> {
  const page = await getStaticPage(pageKey);

  return {
    title: page.seoTitle || page.title,
    description: page.seoDescription || page.description,
    openGraph: {
      title: page.seoTitle || page.title,
      description: page.seoDescription || page.description,
      images: page.heroImage ? [{ url: page.heroImage }] : undefined,
    },
  };
}

type StaticDbPageProps = {
  pageKey: StaticPageKey;
};

export default async function StaticDbPage({ pageKey }: StaticDbPageProps) {
  const page = await getPublicStaticPageBySlug(pageKey);
  return <StaticPageRenderer page={page} />;
}
