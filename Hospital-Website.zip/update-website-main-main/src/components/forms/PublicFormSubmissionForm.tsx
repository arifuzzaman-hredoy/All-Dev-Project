"use client";

import { type FormEvent, useMemo, useState } from "react";
import { CheckCircle2, Loader2, Send } from "lucide-react";

type PublicFormType = "CONTACT" | "CAREER" | "SUPPORT" | "ONLINE_REPORT";

type PublicFormSubmissionFormProps = {
  formType: PublicFormType;
  title: string;
  description: string;
  subjectLabel?: string;
  subjectPlaceholder?: string;
  messageLabel?: string;
  messagePlaceholder?: string;
  defaultSubject?: string;
};

type FormState = {
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
};

const initialState: FormState = {
  name: "",
  phone: "",
  email: "",
  subject: "",
  message: "",
};

const formBadges: Record<PublicFormType, string> = {
  CONTACT: "Contact Request",
  CAREER: "Career Request",
  SUPPORT: "Support Request",
  ONLINE_REPORT: "Report Help Request",
};

export default function PublicFormSubmissionForm({
  formType,
  title,
  description,
  subjectLabel = "Subject",
  subjectPlaceholder = "Write request subject",
  messageLabel = "Message",
  messagePlaceholder = "Write your request details",
  defaultSubject,
}: PublicFormSubmissionFormProps) {
  const [form, setForm] = useState<FormState>(initialState);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const subjectValue = useMemo(() => {
    return form.subject.trim() || defaultSubject || formBadges[formType];
  }, [defaultSubject, form.subject, formType]);

  function updateField(key: keyof FormState, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice("");
    setError("");
    setLoading(true);

    try {
      const response = await fetch("/api/form-submissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          formType,
          name: form.name,
          phone: form.phone,
          email: form.email,
          subject: subjectValue,
          message: form.message,
          payload: {
            pagePath: window.location.pathname,
            pageTitle: document.title,
            badge: formBadges[formType],
          },
        }),
      });

      if (!response.ok) {
        const data = (await response.json().catch(() => null)) as {
          message?: string;
        } | null;

        throw new Error(data?.message || "Submission failed.");
      }

      setForm(initialState);
      setNotice("Your request has been submitted successfully.");
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Submission failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="mx-auto mt-10 max-w-6xl px-4 pb-10 sm:px-6 lg:px-8">
      <div className="overflow-hidden rounded-[30px] border border-[#dbe8ff] bg-white shadow-[0_22px_70px_rgba(6,47,102,0.09)]">
        <div className="grid gap-0 lg:grid-cols-[0.82fr_1.18fr]">
          <div className="bg-[#062f66] p-6 text-white sm:p-8 lg:p-10">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em]">
              <CheckCircle2 size={15} />
              {formBadges[formType]}
            </div>

            <h2 className="mt-5 text-3xl font-black leading-tight tracking-[-0.04em] sm:text-4xl">
              {title}
            </h2>

            <p className="mt-4 text-sm font-semibold leading-7 text-blue-50">
              {description}
            </p>

            <div className="mt-7 rounded-2xl border border-white/15 bg-white/10 p-4 text-sm font-bold leading-7 text-white/90">
              Submitted requests will be stored in the admin panel for follow-up
              and future SMS automation.
            </div>
          </div>

          <form onSubmit={handleSubmit} className="grid gap-4 p-5 sm:p-7 lg:p-9">
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="grid gap-2 text-sm font-black text-[#062f66]">
                Full name *
                <input
                  required
                  value={form.name}
                  onChange={(event) => updateField("name", event.target.value)}
                  placeholder="Enter full name"
                  className="h-12 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-4 text-sm font-semibold outline-none transition focus:border-[#43c7f4] focus:bg-white focus:ring-4 focus:ring-[#43c7f4]/15"
                />
              </label>

              <label className="grid gap-2 text-sm font-black text-[#062f66]">
                Phone number *
                <input
                  required
                  value={form.phone}
                  onChange={(event) => updateField("phone", event.target.value)}
                  placeholder="Enter phone number"
                  className="h-12 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-4 text-sm font-semibold outline-none transition focus:border-[#43c7f4] focus:bg-white focus:ring-4 focus:ring-[#43c7f4]/15"
                />
              </label>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="grid gap-2 text-sm font-black text-[#062f66]">
                Email
                <input
                  type="email"
                  value={form.email}
                  onChange={(event) => updateField("email", event.target.value)}
                  placeholder="Enter email address"
                  className="h-12 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-4 text-sm font-semibold outline-none transition focus:border-[#43c7f4] focus:bg-white focus:ring-4 focus:ring-[#43c7f4]/15"
                />
              </label>

              <label className="grid gap-2 text-sm font-black text-[#062f66]">
                {subjectLabel}
                <input
                  value={form.subject}
                  onChange={(event) =>
                    updateField("subject", event.target.value)
                  }
                  placeholder={subjectPlaceholder}
                  className="h-12 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-4 text-sm font-semibold outline-none transition focus:border-[#43c7f4] focus:bg-white focus:ring-4 focus:ring-[#43c7f4]/15"
                />
              </label>
            </div>

            <label className="grid gap-2 text-sm font-black text-[#062f66]">
              {messageLabel} *
              <textarea
                required
                value={form.message}
                onChange={(event) => updateField("message", event.target.value)}
                placeholder={messagePlaceholder}
                rows={5}
                className="resize-none rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-4 py-3 text-sm font-semibold outline-none transition focus:border-[#43c7f4] focus:bg-white focus:ring-4 focus:ring-[#43c7f4]/15"
              />
            </label>

            {notice ? (
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-black text-emerald-700">
                {notice}
              </div>
            ) : null}

            {error ? (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-black text-red-700">
                {error}
              </div>
            ) : null}

            <button
              type="submit"
              disabled={loading}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[#43c7f4] px-6 text-sm font-black text-white shadow-[0_16px_35px_rgba(67,199,244,0.30)] transition hover:-translate-y-0.5 hover:bg-[#17a9de] disabled:cursor-not-allowed disabled:opacity-70"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : <Send size={18} />}
              {loading ? "Submitting..." : "Submit request"}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
