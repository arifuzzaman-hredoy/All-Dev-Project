"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";

import {
  diseaseOptions,
  type DiseaseOption,
} from "@/data/doctor-schedule";
import type { AppointmentRecord } from "@/types/appointment";
import type { DoctorProfile } from "@/types/doctor";

type BookingMode = "disease" | "doctor";

type Receipt = {
  token: string;
  patientName: string;
  phone: string;
  age: string;
  gender: string;
  problem: string;
  department: string;
  doctorName: string;
  doctorSpecialist: string;
  doctorAvailableDays: string[];
  appointmentTime: string;
  room: string;
  fee: number;
  createdAt: string;
};

export default function AppointmentForm() {
  const [bookingMode, setBookingMode] = useState<BookingMode>("disease");
  const [diseaseId, setDiseaseId] = useState("");
  const [doctorId, setDoctorId] = useState("");

  const [patientName, setPatientName] = useState("");
  const [phone, setPhone] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [reason, setReason] = useState("");

  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const [doctors, setDoctors] = useState<DoctorProfile[]>([]);
  const [isLoadingDoctors, setIsLoadingDoctors] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedDisease = diseaseOptions.find((item) => item.id === diseaseId);

  useEffect(() => {
    let active = true;

    async function loadDoctors() {
      try {
        const response = await fetch("/api/doctors?active=1", {
          cache: "no-store",
        });
        const result = (await response.json()) as { doctors?: DoctorProfile[] };

        if (active) setDoctors(result.doctors || []);
      } catch {
        if (active) setDoctors([]);
      } finally {
        if (active) setIsLoadingDoctors(false);
      }
    }

    void loadDoctors();

    return () => {
      active = false;
    };
  }, []);

  const availableDoctors = useMemo(() => {
    if (bookingMode === "doctor") return doctors;
    if (!selectedDisease) return [];

    return doctors.filter(
      (doctor) => doctor.department === selectedDisease.department
    );
  }, [bookingMode, doctors, selectedDisease]);

  const selectedDoctor = doctors.find((doctor) => doctor.id === doctorId);

  function resetDoctorSelection() {
    setDoctorId("");
    setReceipt(null);
  }

  function resetFormAfterSuccess() {
    setDiseaseId("");
    setDoctorId("");
    setPatientName("");
    setPhone("");
    setAge("");
    setGender("");
    setReason("");
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!patientName || !phone || !age || !gender || !selectedDoctor) {
      alert("Please fill all required fields.");
      return;
    }

    if (bookingMode === "disease" && !selectedDisease) {
      alert("Please select patient problem / disease.");
      return;
    }

    const problem =
      selectedDisease?.label || reason.trim() || "Direct doctor consultation";

    setIsSubmitting(true);
    setReceipt(null);

    try {
      const response = await fetch("/api/appointments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          patientName,
          phone,
          age,
          gender,
          disease: problem,
          doctorId: selectedDoctor.id,
          department: selectedDoctor.department,
          doctorName: selectedDoctor.name,
          doctorDesignation: selectedDoctor.designation,
          specialist: selectedDoctor.specialist,
          doctorAvailableDays: selectedDoctor.availableDays,
          appointmentTime: selectedDoctor.consultationTime,
          room: selectedDoctor.room,
          fee: selectedDoctor.fee,
        }),
      });

      const result = (await response.json()) as {
        appointment?: AppointmentRecord;
        message?: string;
      };

      if (!response.ok || !result.appointment) {
        alert(result.message || "Appointment submission failed.");
        return;
      }

      const newReceipt: Receipt = {
        token: result.appointment.token,
        patientName,
        phone,
        age,
        gender,
        problem,
        department: selectedDoctor.department,
        doctorName: selectedDoctor.name,
        doctorSpecialist:
          selectedDoctor.specialist || selectedDoctor.designation,
        doctorAvailableDays: selectedDoctor.availableDays,
        appointmentTime: selectedDoctor.consultationTime,
        room: selectedDoctor.room,
        fee: selectedDoctor.fee,
        createdAt: new Date(result.appointment.submittedAt).toLocaleString(),
      };

      setReceipt(newReceipt);
      resetFormAfterSuccess();
    } catch {
      alert("Appointment submission failed. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function copyReceipt() {
    if (!receipt) return;

    await navigator.clipboard.writeText(generateSlipText(receipt));
    alert("Appointment slip copied successfully.");
  }

  function printReceipt() {
    if (!receipt) return;

    const printWindow = window.open("", "_blank", "width=900,height=700");

    if (!printWindow) {
      alert("Popup blocked. Please allow popup and try again.");
      return;
    }

    printWindow.document.open();
    printWindow.document.write(generateSlipHtml(receipt));
    printWindow.document.close();

    printWindow.focus();

    setTimeout(() => {
      printWindow.print();
    }, 300);
  }

  function downloadReceipt() {
    if (!receipt) return;

    const file = new Blob([generateSlipHtml(receipt)], {
      type: "text/html;charset=utf-8",
    });

    const url = URL.createObjectURL(file);
    const link = document.createElement("a");

    link.href = url;
    link.download = `appointment-slip-${receipt.token}.html`;
    document.body.appendChild(link);
    link.click();
    link.remove();

    URL.revokeObjectURL(url);
  }

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
      <div className="border-b border-slate-200 pb-5">
        <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-600">
          Appointment
        </p>

        <h2 className="mt-2 text-2xl font-black tracking-tight text-slate-900">
          Patient Appointment Form
        </h2>

        <p className="mt-2 text-sm leading-6 text-slate-500">
          রোগ অথবা doctor select করে patient appointment slip generate করুন।
        </p>
      </div>

      {receipt && (
        <div className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
          <p className="text-sm font-black text-emerald-800">
            Appointment submitted successfully.
          </p>
          <p className="mt-1 text-sm text-emerald-700">
            Token: <span className="font-black">{receipt.token}</span>
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-6 space-y-5">
        <div className="grid gap-3 sm:grid-cols-2">
          <ModeButton
            active={bookingMode === "disease"}
            title="রোগ অনুযায়ী"
            text="Problem select করলে doctor show হবে"
            onClick={() => {
              setBookingMode("disease");
              setDiseaseId("");
              resetDoctorSelection();
            }}
          />

          <ModeButton
            active={bookingMode === "doctor"}
            title="Direct Doctor"
            text="Doctor select করে appointment করুন"
            onClick={() => {
              setBookingMode("doctor");
              setDiseaseId("");
              resetDoctorSelection();
            }}
          />
        </div>

        {bookingMode === "disease" && (
          <Field label="Patient Problem / Disease *">
            <select
              value={diseaseId}
              onChange={(event) => {
                setDiseaseId(event.target.value);
                resetDoctorSelection();
              }}
              required
              className="input-minimal"
            >
              <option value="">Select problem</option>
              {diseaseOptions.map((item: DiseaseOption) => (
                <option key={item.id} value={item.id}>
                  {item.label} - {item.department}
                </option>
              ))}
            </select>
          </Field>
        )}

        <Field label="Select Doctor *">
          <select
            value={doctorId}
            onChange={(event) => {
              setDoctorId(event.target.value);
              setReceipt(null);
            }}
            disabled={
              isLoadingDoctors || (bookingMode === "disease" && !selectedDisease)
            }
            required
            className="input-minimal disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-400"
          >
            <option value="">
              {isLoadingDoctors
                ? "Loading doctors..."
                : bookingMode === "disease" && !selectedDisease
                ? "Select problem first"
                : "Select doctor"}
            </option>

            {availableDoctors.map((doctor: DoctorProfile) => (
              <option key={doctor.id} value={doctor.id}>
                {doctor.name} - {doctor.designation || doctor.specialist} -{" "}
                {doctor.department}
              </option>
            ))}
          </select>
        </Field>

        {selectedDoctor && (
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-lg font-black text-slate-900">
                  {selectedDoctor.name}
                </p>
                <p className="mt-1 text-sm font-semibold text-slate-600">
                  {selectedDoctor.designation}
                </p>
                <p className="mt-1 text-sm text-slate-500">
                  {selectedDoctor.specialist} - {selectedDoctor.department}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white px-4 py-2">
                <p className="text-xs font-bold text-slate-500">Fee</p>
                <p className="text-xl font-black text-slate-900">
                  ৳{selectedDoctor.fee}
                </p>
              </div>
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <InfoBox
                label="Days"
                value={selectedDoctor.availableDays.join(", ")}
              />
              <InfoBox label="Time" value={selectedDoctor.consultationTime} />
              <InfoBox label="Room" value={selectedDoctor.room} />
            </div>
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Patient Name *">
            <input
              value={patientName}
              onChange={(event) => setPatientName(event.target.value)}
              placeholder="Enter patient name"
              required
              className="input-minimal"
            />
          </Field>

          <Field label="Phone Number *">
            <input
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
              placeholder="Enter phone number"
              required
              className="input-minimal"
            />
          </Field>

          <Field label="Age *">
            <input
              value={age}
              onChange={(event) => setAge(event.target.value)}
              placeholder="Enter age"
              required
              className="input-minimal"
            />
          </Field>

          <Field label="Gender *">
            <select
              value={gender}
              onChange={(event) => setGender(event.target.value)}
              required
              className="input-minimal"
            >
              <option value="">Select gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </Field>
        </div>

        <Field label="Patient Note / Reason">
          <textarea
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            placeholder="Write patient problem details"
            rows={3}
            className="input-minimal resize-none"
          />
        </Field>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full rounded-2xl bg-slate-900 px-5 py-4 text-sm font-black uppercase tracking-[0.16em] text-white transition hover:bg-cyan-600 disabled:cursor-not-allowed disabled:opacity-70"
        >
          {isSubmitting ? "Submitting..." : "Submit Appointment"}
        </button>
      </form>

      {receipt && (
        <div className="mt-7 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 border-b border-dashed border-slate-300 pb-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-slate-500">
                Appointment Slip
              </p>
              <h3 className="mt-2 text-3xl font-black text-slate-900">
                {receipt.token}
              </h3>
            </div>

            <div className="rounded-2xl bg-slate-900 px-5 py-3 text-white">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-white/60">
                Fee
              </p>
              <p className="text-2xl font-black">৳{receipt.fee}</p>
            </div>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <SlipItem label="Patient" value={receipt.patientName} />
            <SlipItem label="Phone" value={receipt.phone} />
            <SlipItem label="Age" value={receipt.age} />
            <SlipItem label="Gender" value={receipt.gender} />
            <SlipItem label="Problem" value={receipt.problem} />
            <SlipItem label="Department" value={receipt.department} />
            <SlipItem label="Doctor" value={receipt.doctorName} />
            <SlipItem label="Specialist" value={receipt.doctorSpecialist} />
            <SlipItem
              label="Available Days"
              value={receipt.doctorAvailableDays.join(", ")}
            />
            <SlipItem label="Time" value={receipt.appointmentTime} />
            <SlipItem label="Room" value={receipt.room} />
            <SlipItem label="Created At" value={receipt.createdAt} />
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <button
              type="button"
              onClick={copyReceipt}
              className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-800 transition hover:bg-slate-50"
            >
              Copy Slip
            </button>

            <button
              type="button"
              onClick={printReceipt}
              className="rounded-2xl bg-cyan-500 px-5 py-3 text-sm font-black text-white transition hover:bg-cyan-600"
            >
              Print Slip
            </button>

            <button
              type="button"
              onClick={downloadReceipt}
              className="rounded-2xl bg-slate-900 px-5 py-3 text-sm font-black text-white transition hover:bg-slate-800"
            >
              Download Slip
            </button>
          </div>
        </div>
      )}

      <style jsx global>{`
        .input-minimal {
          min-height: 48px;
          width: 100%;
          border-radius: 14px;
          border: 1px solid rgb(226 232 240);
          background: white;
          padding: 10px 14px;
          font-size: 14px;
          font-weight: 600;
          color: rgb(30 41 59);
          outline: none;
          transition: 0.2s ease;
        }

        .input-minimal:focus {
          border-color: rgb(34 211 238);
          box-shadow: 0 0 0 4px rgba(103, 232, 249, 0.35);
        }
      `}</style>
    </div>
  );
}

function ModeButton({
  active,
  title,
  text,
  onClick,
}: {
  active: boolean;
  title: string;
  text: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-2xl border p-4 text-left transition ${
        active
          ? "border-cyan-300 bg-cyan-50"
          : "border-slate-200 bg-white hover:bg-slate-50"
      }`}
    >
      <p className="text-sm font-black text-slate-900">{title}</p>
      <p className="mt-1 text-xs leading-5 text-slate-500">{text}</p>
    </button>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-bold text-slate-700">
        {label}
      </label>
      {children}
    </div>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3">
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-slate-400">
        {label}
      </p>
      <p className="mt-1 text-sm font-black text-slate-800">{value}</p>
    </div>
  );
}

function SlipItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
      <p className="text-[11px] font-black uppercase tracking-[0.16em] text-slate-400">
        {label}
      </p>
      <p className="mt-1 break-words text-sm font-black text-slate-900">
        {value}
      </p>
    </div>
  );
}

function generateSlipText(receipt: Receipt) {
  return `
Appointment Slip
Token: ${receipt.token}

Patient: ${receipt.patientName}
Phone: ${receipt.phone}
Age: ${receipt.age}
Gender: ${receipt.gender}
Problem: ${receipt.problem}

Doctor: ${receipt.doctorName}
Specialist: ${receipt.doctorSpecialist}
Department: ${receipt.department}
Available Days: ${receipt.doctorAvailableDays.join(", ")}
Time: ${receipt.appointmentTime}
Room: ${receipt.room}
Fee: ${receipt.fee} BDT

Created At: ${receipt.createdAt}
`.trim();
}

function generateSlipHtml(receipt: Receipt) {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Appointment Slip - ${escapeHtml(receipt.token)}</title>
  <style>
    @page {
      size: A4;
      margin: 18mm;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      background: #f8fafc;
      color: #0f172a;
      font-family: Arial, sans-serif;
    }

    .sheet {
      max-width: 760px;
      margin: 24px auto;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      padding: 28px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      border-bottom: 1px dashed #94a3b8;
      padding-bottom: 18px;
      margin-bottom: 18px;
    }

    .label {
      font-size: 10px;
      font-weight: 800;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 1.6px;
    }

    h1 {
      margin: 8px 0 0;
      font-size: 30px;
      line-height: 1;
    }

    .fee {
      min-width: 120px;
      background: #0f172a;
      color: #ffffff;
      padding: 14px;
      text-align: center;
    }

    .fee strong {
      display: block;
      margin-top: 5px;
      font-size: 24px;
    }

    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }

    .item {
      border: 1px solid #e2e8f0;
      padding: 10px;
      min-height: 58px;
    }

    .item p {
      margin: 6px 0 0;
      font-size: 13px;
      font-weight: 800;
    }

    .note {
      margin-top: 18px;
      border-top: 1px dashed #94a3b8;
      padding-top: 14px;
      font-size: 11px;
      color: #64748b;
      line-height: 1.6;
    }

    @media print {
      body {
        background: #ffffff;
      }

      .sheet {
        margin: 0;
        max-width: none;
        border: none;
        padding: 0;
      }
    }
  </style>
</head>
<body>
  <main class="sheet">
    <section class="header">
      <div>
        <div class="label">Appointment Slip</div>
        <h1>${escapeHtml(receipt.token)}</h1>
      </div>

      <div class="fee">
        <div class="label" style="color:#cbd5e1;">Fee</div>
        <strong>BDT ${escapeHtml(String(receipt.fee))}</strong>
      </div>
    </section>

    <section class="grid">
      ${htmlItem("Patient", receipt.patientName)}
      ${htmlItem("Phone", receipt.phone)}
      ${htmlItem("Age", receipt.age)}
      ${htmlItem("Gender", receipt.gender)}
      ${htmlItem("Problem", receipt.problem)}
      ${htmlItem("Department", receipt.department)}
      ${htmlItem("Doctor", receipt.doctorName)}
      ${htmlItem("Specialist", receipt.doctorSpecialist)}
      ${htmlItem("Available Days", receipt.doctorAvailableDays.join(", "))}
      ${htmlItem("Time", receipt.appointmentTime)}
      ${htmlItem("Room", receipt.room)}
      ${htmlItem("Created At", receipt.createdAt)}
    </section>

    <p class="note">
      Please bring this appointment slip during your visit. Doctor schedule may change due to emergency or clinic authority decision.
    </p>
  </main>
</body>
</html>
`;
}

function htmlItem(label: string, value: string) {
  return `
    <div class="item">
      <div class="label">${escapeHtml(label)}</div>
      <p>${escapeHtml(value)}</p>
    </div>
  `;
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
