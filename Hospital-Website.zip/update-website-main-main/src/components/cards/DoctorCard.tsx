// File: clinic-website/src/components/cards/DoctorCard.tsx

import Link from "next/link";
import { CalendarCheck, UserRound } from "lucide-react";

type DoctorCardProps = {
  name: string;
  speciality: string;
  experience: string;
  availability: string;
};

export default function DoctorCard({
  name,
  speciality,
  experience,
  availability,
}: DoctorCardProps) {
  return (
    <article className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-[0_12px_32px_rgba(15,23,42,0.08)]">
      <div className="flex aspect-[4/3] items-center justify-center bg-gradient-to-br from-blue-50 via-cyan-50 to-amber-50">
        <div className="flex size-20 items-center justify-center rounded-full bg-white text-[#062f66] shadow-sm sm:size-24">
          <UserRound size={42} strokeWidth={1.8} />
        </div>
      </div>
      <div className="p-5 sm:p-6">
        <h3 className="text-lg font-bold leading-tight text-[#062f66] sm:text-xl">
          {name}
        </h3>
        <p className="mt-2 font-semibold text-teal-600">{speciality}</p>
        <p className="mt-3 text-sm text-slate-600">{experience}</p>
        <p className="mt-1 text-sm text-slate-600">Available: {availability}</p>
        <Link
          href="/appointment"
          className="mt-5 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#43c7f4] sm:w-auto"
        >
          <CalendarCheck size={18} />
          Book Appointment
        </Link>
      </div>
    </article>
  );
}
