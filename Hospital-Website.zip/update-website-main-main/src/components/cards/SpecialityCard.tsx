// File: clinic-website/src/components/cards/SpecialityCard.tsx

import {
  Baby,
  Bone,
  Brain,
  HeartPulse,
  Microscope,
  Siren,
  type LucideIcon,
} from "lucide-react";

const icons: Record<string, LucideIcon> = {
  Baby,
  Bone,
  Brain,
  HeartPulse,
  Microscope,
  Siren,
};

type SpecialityCardProps = {
  title: string;
  description: string;
  icon: string;
};

export default function SpecialityCard({ title, description, icon }: SpecialityCardProps) {
  const Icon = icons[icon] ?? HeartPulse;

  return (
    <article className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_12px_32px_rgba(15,23,42,0.08)] transition hover:-translate-y-1 hover:shadow-[0_20px_50px_rgba(15,23,42,0.12)] sm:p-6">
      <div className="mb-4 flex size-11 items-center justify-center rounded-xl bg-cyan-50 text-teal-600 sm:mb-5 sm:size-12">
        <Icon size={26} strokeWidth={2.2} />
      </div>
      <h3 className="text-lg font-bold leading-tight text-[#062f66] sm:text-xl">
        {title}
      </h3>
      <p className="mt-3 text-sm leading-7 text-slate-600 sm:text-base">
        {description}
      </p>
    </article>
  );
}
