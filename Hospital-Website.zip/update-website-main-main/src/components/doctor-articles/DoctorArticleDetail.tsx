"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Home } from "lucide-react";
import Container from "@/components/common/Container";
import {
  DoctorArticle,
  formatArticleDate,
  getActiveDoctorArticles,
} from "@/lib/doctorArticles";
import type { DoctorArticle as SiteDoctorArticle } from "@/data/site";

type DoctorArticleDetailProps = {
  article?: DoctorArticle | SiteDoctorArticle;
  slug?: string;
};

function toLocalArticle(item?: DoctorArticle | SiteDoctorArticle) {
  if (!item) return null;
  if ("id" in item) return item;

  return {
    id: item.slug,
    slug: item.slug,
    title: item.title,
    author: item.doctor,
    date: item.date,
    category: "Doctor Article",
    image: item.image,
    excerpt: item.excerpt,
    leadText: item.excerpt,
    body: item.content,
    active: true,
    sortOrder: 1,
    createdAt: "2026-06-12T00:00:00.000Z",
    updatedAt: "2026-06-12T00:00:00.000Z",
  };
}

export default function DoctorArticleDetail({
  article,
  slug,
}: DoctorArticleDetailProps) {
  const params = useParams();
  const initialArticle = useMemo(() => toLocalArticle(article), [article]);
  const currentSlug =
    slug || initialArticle?.slug || String(params?.slug || "");
  const [storedArticle, setStoredArticle] = useState<DoctorArticle | null>(
    initialArticle
  );

  useEffect(() => {
    function loadArticle() {
      setStoredArticle(
        getActiveDoctorArticles().find((item) => item.slug === currentSlug) ||
          initialArticle
      );
    }

    queueMicrotask(loadArticle);
    window.addEventListener("storage", loadArticle);
    window.addEventListener("doctor-articles-updated", loadArticle);
    return () => {
      window.removeEventListener("storage", loadArticle);
      window.removeEventListener("doctor-articles-updated", loadArticle);
    };
  }, [currentSlug, initialArticle]);

  if (!storedArticle) {
    return (
      <main className="grid min-h-[70vh] place-items-center bg-white p-8 text-center text-[#002f70]">
        <div>
          <h1 className="text-2xl font-black">Article not found</h1>
          <Link href="/doctor-articles" className="mt-6 inline-flex bg-[#002f70] px-6 py-4 font-black text-white">
            Back to Doctor Articles
          </Link>
        </div>
      </main>
    );
  }

  return (
    <section className="bg-white py-10 sm:py-14 lg:py-16">
      <Container>
        <nav className="flex flex-wrap items-center gap-3 text-base font-bold text-[#062f66]">
          <Link
            href="/"
            className="inline-flex items-center gap-1 text-blue-600"
          >
            <Home size={17} />
            Home
          </Link>
          <span className="text-slate-300">›</span>
          <Link href="/doctor-articles" className="text-blue-600">
            Doctor Articles
          </Link>
          <span className="text-slate-300">›</span>
          <span>{storedArticle.title}</span>
        </nav>

        <article className="mx-auto mt-14 max-w-5xl">
          <time className="inline-flex border border-[#e2dff6] px-4 py-1 text-[13px] font-semibold uppercase tracking-[0.32em] text-[#8a6bb8]">
            {formatArticleDate(storedArticle.date)}
          </time>

          <h1 className="mt-6 text-4xl font-black leading-tight text-[#062f66] sm:text-5xl">
            {storedArticle.title}
          </h1>

          <p className="mt-4 text-lg font-semibold uppercase tracking-[0.14em] text-[#8a6bb8]">
            {storedArticle.author}
          </p>

          <div className="relative mt-10 h-[280px] overflow-hidden rounded-[4px] bg-slate-100 sm:h-[430px]">
            <img
              src={storedArticle.image}
              alt={storedArticle.title}
              className="h-full w-full object-cover"
            />
          </div>

          <p className="mt-10 text-xl font-semibold leading-9 text-[#062f66]">
            {storedArticle.leadText}
          </p>

          <div className="mt-8 space-y-6 text-lg leading-8 text-slate-700">
            {storedArticle.body.map((paragraph, index) => (
              <p key={`${storedArticle.id}-${index}`}>{paragraph}</p>
            ))}
          </div>

          <Link
            href="/doctor-articles"
            className="mt-10 inline-flex bg-[#062f66] px-8 py-4 text-sm font-black text-white transition hover:bg-[#5bc0de]"
          >
            Back to Doctor Articles
          </Link>
        </article>
      </Container>
    </section>
  );
}
