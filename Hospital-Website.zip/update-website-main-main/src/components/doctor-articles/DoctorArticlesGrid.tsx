// File: clinic-website/src/components/doctor-articles/DoctorArticlesGrid.tsx

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Container from "@/components/common/Container";
import DoctorArticleCard from "@/components/doctor-articles/DoctorArticleCard";
import {
  DEFAULT_DOCTOR_ARTICLES,
  DoctorArticle,
  getActiveDoctorArticles,
} from "@/lib/doctorArticles";

export default function DoctorArticlesGrid() {
  const [articles, setArticles] = useState<DoctorArticle[]>(() =>
    DEFAULT_DOCTOR_ARTICLES.filter((item) => item.active).sort(
      (a, b) => a.sortOrder - b.sortOrder,
    ),
  );

  useEffect(() => {
    function loadArticles() {
      setArticles(getActiveDoctorArticles());
    }

    loadArticles();
    window.addEventListener("storage", loadArticles);
    window.addEventListener("doctor-articles-updated", loadArticles);
    return () => {
      window.removeEventListener("storage", loadArticles);
      window.removeEventListener("doctor-articles-updated", loadArticles);
    };
  }, []);

  return (
    <section className="relative overflow-hidden bg-[#061a35] py-10 sm:py-14 lg:py-20">
      {/* Premium Dark Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#061a35_0%,#08284f_45%,#07172d_100%)]" />

        <div className="absolute left-[-180px] top-[-160px] h-[420px] w-[420px] rounded-full bg-[#43c7f4]/20 blur-[110px]" />
        <div className="absolute right-[-190px] top-20 h-[460px] w-[460px] rounded-full bg-[#8a6bb8]/25 blur-[120px]" />
        <div className="absolute bottom-[-210px] left-[35%] h-[430px] w-[430px] rounded-full bg-[#8cc63f]/12 blur-[120px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.10)_1px,transparent_0)] [background-size:30px_30px] opacity-35" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/35 to-transparent" />
      </div>

      <Container>
        <div className="relative z-10 mx-auto max-w-[1245px]">
          {/* Header */}
          <div className="mb-8 grid items-end gap-6 sm:mb-12 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <div className="mb-5 inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/10 px-4 py-2 shadow-[0_18px_45px_rgba(0,0,0,0.18)] backdrop-blur-xl">
                <span className="h-2.5 w-2.5 rounded-full bg-[#43c7f4] shadow-[0_0_0_6px_rgba(67,199,244,0.15)]" />
                <span className="text-xs font-black uppercase tracking-[0.2em] text-[#bdeeff]">
                  Medical Journal
                </span>
              </div>

              <h1 className="max-w-[620px] text-3xl font-black leading-tight text-white sm:text-4xl lg:text-5xl">
                Doctor Written{" "}
                <span className="bg-gradient-to-r from-[#43c7f4] via-white to-[#8cc63f] bg-clip-text text-transparent">
                  Health Articles
                </span>
              </h1>
            </div>
          </div>

          {/* Cards */}
          <div className="grid gap-5 sm:gap-6 md:grid-cols-3">
            {articles.map((article) => (
              <div
                key={article.slug}
                className="group relative rounded-[22px] border border-white/12 bg-white/10 p-1.5 shadow-[0_20px_55px_rgba(0,0,0,0.20)] backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:border-[#43c7f4]/35 hover:bg-white/15 hover:shadow-[0_30px_80px_rgba(0,0,0,0.26)] sm:rounded-[30px] sm:p-2"
              >
                <div className="pointer-events-none absolute inset-x-8 -top-px h-px bg-gradient-to-r from-transparent via-[#43c7f4]/70 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <DoctorArticleCard article={article} />
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="mt-8 flex justify-center sm:mt-12">
            <Link
              href="/doctors"
              className="group relative inline-flex min-h-12 w-full items-center justify-center overflow-hidden rounded-full border border-white/15 bg-white px-6 py-3 text-sm font-black uppercase tracking-[0.08em] text-[#062f66] shadow-[0_22px_55px_rgba(0,0,0,0.25)] transition-all duration-300 hover:-translate-y-[2px] hover:bg-[#43c7f4] hover:text-white hover:shadow-[0_26px_70px_rgba(67,199,244,0.25)] sm:w-auto sm:min-w-[250px] sm:px-8 sm:py-4"
            >
              <span className="absolute inset-y-0 left-0 w-14 -translate-x-20 rotate-12 bg-white/45 blur-md transition-transform duration-700 group-hover:translate-x-[310px]" />
              <span className="relative z-10">View All Doctors</span>
              <span className="relative z-10 ml-3 transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </Link>
          </div>
        </div>
      </Container>
    </section>
  );
}
