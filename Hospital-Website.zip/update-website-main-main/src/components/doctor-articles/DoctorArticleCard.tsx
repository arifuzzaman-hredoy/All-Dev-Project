// File: clinic-website/src/components/doctor-articles/DoctorArticleCard.tsx

import Link from "next/link";
import { ArrowUpRight, BookOpen, CalendarDays } from "lucide-react";
import {
  formatArticleDate,
  type DoctorArticle,
} from "@/lib/doctorArticles";

type DoctorArticleCardProps = {
  article: DoctorArticle;
};

export default function DoctorArticleCard({ article }: DoctorArticleCardProps) {
  return (
    <article className="group relative overflow-hidden rounded-[22px] border border-white/70 bg-white shadow-[0_16px_42px_rgba(6,47,102,0.10)] transition-all duration-500 hover:-translate-y-1 hover:border-[#43c7f4]/35 hover:shadow-[0_26px_70px_rgba(6,47,102,0.16)] sm:rounded-[26px]">
      {/* Premium Top Glow */}
      <div className="pointer-events-none absolute inset-x-8 top-0 z-20 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/70 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

      {/* Image Area */}
      <div className="relative h-[200px] overflow-hidden bg-[#eef5ff] sm:h-[220px]">
        <img
          src={article.image}
          alt={article.title}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />

        {/* Image Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#062f66]/75 via-[#062f66]/15 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-95" />

        {/* Floating Book Icon */}
        <div className="absolute left-4 top-4 flex h-12 w-12 items-center justify-center rounded-full border border-white/25 bg-white/20 text-white shadow-[0_14px_35px_rgba(6,47,102,0.25)] backdrop-blur-md transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-12 group-hover:scale-110 group-hover:bg-white group-hover:text-[#062f66]">
          <BookOpen className="h-5 w-5 transition-transform duration-500 group-hover:-rotate-12" />
        </div>

        {/* Floating Arrow Icon */}
        <Link
          href={`/doctor-articles/${article.slug}`}
          aria-label={`Read ${article.title}`}
          className="absolute right-4 top-4 flex h-12 w-12 items-center justify-center rounded-full border border-white/25 bg-white/20 text-white shadow-[0_14px_35px_rgba(6,47,102,0.25)] backdrop-blur-md transition-all duration-500 hover:-translate-y-1 hover:rotate-45 hover:scale-110 hover:bg-[#43c7f4] hover:text-white hover:shadow-[0_18px_45px_rgba(67,199,244,0.35)]"
        >
          <ArrowUpRight className="h-5 w-5 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </Link>

        {/* Date Badge */}
        <time className="absolute bottom-4 left-4 inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/90 px-4 py-2 text-[11px] font-black uppercase tracking-[0.14em] text-[#062f66] shadow-[0_12px_30px_rgba(6,47,102,0.20)] backdrop-blur-md">
          <CalendarDays className="h-4 w-4 text-[#8a6bb8] transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110" />
          {formatArticleDate(article.date)}
        </time>
      </div>

      {/* Content */}
      <div className="relative p-5 sm:min-h-[215px] sm:p-6">
        {/* Soft Background Glow */}
        <div className="pointer-events-none absolute right-[-60px] top-[-55px] h-[145px] w-[145px] rounded-full bg-[#43c7f4]/10 blur-[45px] transition-all duration-500 group-hover:bg-[#8a6bb8]/15" />

        <div className="relative z-10">
          <span className="mb-4 inline-flex items-center gap-2 rounded-full bg-[#f3f7ff] px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] text-[#8a6bb8] ring-1 ring-[#062f66]/8">
            <span className="h-1.5 w-1.5 rounded-full bg-[#43c7f4] shadow-[0_0_0_4px_rgba(67,199,244,0.12)]" />
            {article.category}
          </span>

          <h2 className="text-lg font-black leading-7 text-[#062f66] transition-colors duration-300 group-hover:text-[#8a6bb8] sm:min-h-[86px] sm:text-xl">
            {article.title}
          </h2>

          <Link
            href={`/doctor-articles/${article.slug}`}
            className="group/link mt-5 inline-flex min-h-11 items-center gap-3 text-sm font-black uppercase tracking-[0.08em] text-[#43c7f4] transition-colors duration-300 hover:text-[#8cc63f] sm:mt-6"
          >
            <span className="relative inline-block after:absolute after:left-0 after:-bottom-[7px] after:h-[3px] after:w-0 after:rounded-full after:bg-gradient-to-r after:from-[#43c7f4] after:via-[#8cc63f] after:to-[#43c7f4] after:shadow-[0_0_12px_rgba(67,199,244,0.55)] after:transition-all after:duration-300 group-hover/link:after:w-full">
              Read More Doctors
            </span>

            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#43c7f4]/10 text-[#43c7f4] shadow-[0_10px_25px_rgba(67,199,244,0.10)] transition-all duration-300 group-hover/link:translate-x-1 group-hover/link:-translate-y-1 group-hover/link:rotate-45 group-hover/link:scale-110 group-hover/link:bg-[#8cc63f]/15 group-hover/link:text-[#8cc63f]">
              <ArrowUpRight className="h-5 w-5" />
            </span>
          </Link>
        </div>
      </div>
    </article>
  );
}
