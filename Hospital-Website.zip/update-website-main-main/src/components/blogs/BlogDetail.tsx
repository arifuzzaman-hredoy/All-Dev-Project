// File: clinic-website/src/components/blogs/BlogDetail.tsx

"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Home } from "lucide-react";
import Container from "@/components/common/Container";
import {
  HealthBlogItem,
  formatBlogDate,
  getActiveHealthBlogs,
} from "@/lib/healthBlogs";
import type { BlogPost } from "@/data/site";

type BlogDetailProps = {
  blog?: BlogPost | HealthBlogItem;
  slug?: string;
};

function toLocalBlog(item?: BlogPost | HealthBlogItem) {
  if (!item) return null;
  if ("id" in item) return item;

  return {
    id: item.slug,
    slug: item.slug,
    title: item.title,
    date: item.date,
    category: "Health Blog",
    image: item.image,
    excerpt: item.excerpt,
    leadText: item.excerpt,
    body: item.content,
    active: true,
    sortOrder: 1,
    createdAt: "2026-06-12T00:00:00.000Z",
    updatedAt: "2026-06-12T00:00:00.000Z",
  };
}

export default function BlogDetail({ blog, slug }: BlogDetailProps) {
  const params = useParams();
  const initialBlog = useMemo(() => toLocalBlog(blog), [blog]);
  const currentSlug = slug || initialBlog?.slug || String(params?.slug || "");
  const [storedBlog, setStoredBlog] = useState<HealthBlogItem | null>(
    initialBlog
  );

  useEffect(() => {
    function loadBlog() {
      setStoredBlog(
        getActiveHealthBlogs().find((item) => item.slug === currentSlug) ||
          initialBlog
      );
    }

    queueMicrotask(loadBlog);
    window.addEventListener("storage", loadBlog);
    window.addEventListener("health-blogs-updated", loadBlog);
    return () => {
      window.removeEventListener("storage", loadBlog);
      window.removeEventListener("health-blogs-updated", loadBlog);
    };
  }, [currentSlug, initialBlog]);

  if (!storedBlog) {
    return (
      <main className="grid min-h-[70vh] place-items-center bg-white p-8 text-center text-[#002f70]">
        <div>
          <h1 className="text-2xl font-black">Blog not found</h1>
          <Link href="/blogs" className="mt-6 inline-flex bg-[#002f70] px-6 py-4 font-black text-white">
            Back to Blogs
          </Link>
        </div>
      </main>
    );
  }

  return (
    <section className="bg-white py-10 sm:py-14 lg:py-16">
      <Container>
        <nav className="flex flex-wrap items-center gap-3 text-base font-bold text-[#062f66]">
          <Link href="/" className="inline-flex items-center gap-1 text-blue-600">
            <Home size={17} />
            Home
          </Link>
          <span className="text-slate-300">›</span>
          <Link href="/blogs" className="text-blue-600">
            Blogs
          </Link>
          <span className="text-slate-300">›</span>
          <span>{storedBlog.title}</span>
        </nav>

        <article className="mx-auto mt-14 max-w-5xl">
          <time className="inline-flex border border-[#e2dff6] px-4 py-1 text-[13px] font-semibold uppercase tracking-[0.32em] text-[#8a6bb8]">
            {formatBlogDate(storedBlog.date)}
          </time>

          <h1 className="mt-6 text-4xl font-black leading-tight text-[#062f66] sm:text-5xl">
            {storedBlog.title}
          </h1>

          <div className="relative mt-10 h-[280px] overflow-hidden rounded-[4px] bg-slate-100 sm:h-[430px]">
            <img
              src={storedBlog.image}
              alt={storedBlog.title}
              className="h-full w-full object-cover"
            />
          </div>

          <p className="mt-10 text-xl font-semibold leading-9 text-[#062f66]">
            {storedBlog.leadText}
          </p>

          <div className="mt-8 space-y-6 text-lg leading-8 text-slate-700">
            {storedBlog.body.map((paragraph, index) => (
              <p key={`${storedBlog.id}-${index}`}>{paragraph}</p>
            ))}
          </div>

          <Link
            href="/blogs"
            className="mt-10 inline-flex bg-[#062f66] px-8 py-4 text-sm font-black text-white transition hover:bg-[#5bc0de]"
          >
            Back to Blogs
          </Link>
        </article>
      </Container>
    </section>
  );
}
