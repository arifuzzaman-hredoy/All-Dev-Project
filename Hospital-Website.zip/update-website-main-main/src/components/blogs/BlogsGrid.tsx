// File: clinic-website/src/components/blogs/BlogsGrid.tsx

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Container from "@/components/common/Container";
import BlogCard from "@/components/blogs/BlogCard";
import {
  DEFAULT_HEALTH_BLOGS,
  HealthBlogItem,
  getActiveHealthBlogs,
} from "@/lib/healthBlogs";

export default function BlogsGrid() {
  const [blogs, setBlogs] = useState<HealthBlogItem[]>(() =>
    DEFAULT_HEALTH_BLOGS.filter((item) => item.active).sort(
      (a, b) => a.sortOrder - b.sortOrder,
    ),
  );

  useEffect(() => {
    function loadBlogs() {
      setBlogs(getActiveHealthBlogs());
    }

    loadBlogs();
    window.addEventListener("storage", loadBlogs);
    window.addEventListener("health-blogs-updated", loadBlogs);
    return () => {
      window.removeEventListener("storage", loadBlogs);
      window.removeEventListener("health-blogs-updated", loadBlogs);
    };
  }, []);

  return (
    <section className="relative overflow-hidden bg-[#eef7ff] py-10 sm:py-14 lg:py-20">
      {/* Background Design */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#eef7ff_0%,#ffffff_45%,#f6f1ff_100%)]" />

        <div className="absolute left-[-180px] top-[-160px] h-[420px] w-[420px] rounded-full bg-[#43c7f4]/16 blur-[105px]" />
        <div className="absolute right-[-190px] top-20 h-[450px] w-[450px] rounded-full bg-[#8a6bb8]/16 blur-[115px]" />
        <div className="absolute bottom-[-180px] left-[35%] h-[380px] w-[380px] rounded-full bg-[#8cc63f]/10 blur-[100px]" />

        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(6,47,102,0.04)_1px,transparent_1px),linear-gradient(180deg,rgba(6,47,102,0.04)_1px,transparent_1px)] [background-size:42px_42px]" />

        <div className="absolute left-10 top-24 hidden h-28 w-28 rounded-[34px] border border-[#062f66]/10 bg-white/45 shadow-[0_20px_60px_rgba(6,47,102,0.08)] backdrop-blur-md lg:block" />
        <div className="absolute bottom-24 right-14 hidden h-36 w-36 rotate-12 rounded-full border border-[#8a6bb8]/15 bg-white/40 shadow-[0_20px_60px_rgba(138,107,184,0.10)] backdrop-blur-md lg:block" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062f66]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#8a6bb8]/20 to-transparent" />
      </div>

      <Container>
        <div className="relative z-10 mx-auto max-w-[1245px]">
          {/* Header */}
          <div className="mb-8 grid items-end gap-6 sm:mb-12 lg:grid-cols-[0.85fr_1.15fr]">
            <div>
              <div className="mb-4 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,47,102,0.08)] backdrop-blur-md sm:mb-5">
                <span className="h-2.5 w-2.5 rounded-full bg-[#43c7f4] shadow-[0_0_0_6px_rgba(67,199,244,0.13)]" />
                <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
                  Health Blog
                </span>
              </div>

              <h1 className="max-w-[560px] text-3xl font-black leading-tight text-[#062f66] sm:text-5xl lg:text-6xl">
                Latest
                <span className="mt-2 block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062f66] bg-clip-text text-transparent">
                  Blogs
                </span>
              </h1>
            </div>
          </div>

          {/* Blog Cards */}
          <div className="grid gap-5 sm:gap-6 md:grid-cols-3">
            {blogs.map((blog, index) => (
              <div
                key={blog.slug}
                className="group relative rounded-[22px] bg-white/75 p-1.5 shadow-[0_16px_45px_rgba(6,47,102,0.09)] ring-1 ring-[#062f66]/8 backdrop-blur-xl transition-all duration-500 hover:-translate-y-1 hover:bg-white hover:shadow-[0_26px_70px_rgba(6,47,102,0.14)] sm:rounded-[32px] sm:p-2"
              >
                <div className="pointer-events-none absolute -top-4 left-6 z-20 flex h-10 w-10 items-center justify-center rounded-full bg-[#062f66] text-xs font-black text-white shadow-[0_12px_30px_rgba(6,47,102,0.22)] transition-all duration-500 group-hover:-translate-y-1 group-hover:rotate-12 group-hover:bg-[#8a6bb8]">
                  {String(index + 1).padStart(2, "0")}
                </div>

                <div className="pointer-events-none absolute inset-x-8 top-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/70 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <BlogCard blog={blog} />
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="mt-8 flex justify-center sm:mt-12">
            <Link
              href="/blogs"
              className="group relative inline-flex min-h-12 w-full items-center justify-center overflow-hidden rounded-full bg-[#062f66] px-6 py-3 text-sm font-black uppercase tracking-[0.07em] text-white shadow-[0_18px_45px_rgba(6,47,102,0.24)] transition-all duration-300 hover:-translate-y-[2px] hover:bg-[#43c7f4] hover:shadow-[0_24px_65px_rgba(67,199,244,0.28)] sm:w-auto sm:min-w-[235px] sm:px-8 sm:py-4"
            >
              <span className="absolute inset-y-0 left-0 w-12 -translate-x-16 rotate-12 bg-white/25 blur-sm transition-transform duration-700 group-hover:translate-x-[290px]" />
              <span className="relative z-10">View More Blogs</span>
              <span className="relative z-10 ml-3 transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </Link>
          </div>
        </div>
      </Container>
    </section>
  );
}
