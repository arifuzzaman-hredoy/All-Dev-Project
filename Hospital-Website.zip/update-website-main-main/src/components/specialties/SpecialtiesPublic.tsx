"use client";

import { createElement, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, CalendarCheck, Clock, MapPin } from "lucide-react";
import Container from "@/components/common/Container";
import { getActiveSpecialties, SpecialtyItem } from "@/lib/specialties";
import { getSpecialtyIcon } from "@/lib/specialtyIcons";

type SpecialtiesPublicProps = {
  mode?: "list" | "detail";
  slug?: string;
};

function SpecialtyIconGlyph({
  icon,
  className,
  size,
  strokeWidth,
}: {
  icon: string;
  className?: string;
  size?: number;
  strokeWidth?: number;
}) {
  const Icon = getSpecialtyIcon(icon);

  return createElement(Icon, { className, size, strokeWidth });
}

export default function SpecialtiesPublic({
  mode = "list",
  slug,
}: SpecialtiesPublicProps) {
  const [items, setItems] = useState<SpecialtyItem[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    function loadItems() {
      setItems(getActiveSpecialties());
    }

    loadItems();
    window.addEventListener("specialties-updated", loadItems);
    window.addEventListener("storage", loadItems);

    return () => {
      window.removeEventListener("specialties-updated", loadItems);
      window.removeEventListener("storage", loadItems);
    };
  }, []);

  const filteredItems = useMemo(() => {
    const keyword = search.trim().toLowerCase();
    if (!keyword) return items;

    return items.filter((item) =>
      [item.title, item.shortDescription, item.services.join(" ")]
        .join(" ")
        .toLowerCase()
        .includes(keyword),
    );
  }, [items, search]);

  if (mode === "detail") {
    const item = items.find((specialty) => specialty.slug === slug);

    if (!item) {
      return (
        <section className="bg-white py-16">
          <Container>
            <div className="border border-dashed border-slate-300 bg-slate-50 p-8 text-center">
              <h1 className="text-2xl font-black text-[#062f66]">
                Specialty not found
              </h1>
              <Link
                href="/specialities"
                className="mt-5 inline-flex bg-[#062f66] px-5 py-3 text-sm font-black text-white"
              >
                Back to all specialities
              </Link>
            </div>
          </Container>
        </section>
      );
    }

    return <SpecialtyDetail item={item} />;
  }

  return (
    <section className="bg-slate-50 py-16 sm:py-20">
      <Container>
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-black text-[#062f66]">
              All Specialities
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-600">
              Choose a department to view services, doctors, schedule, and care
              details.
            </p>
          </div>
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search department..."
            className="h-12 w-full border border-slate-200 bg-white px-4 text-sm font-semibold text-[#062f66] outline-none focus:border-cyan-300 sm:w-[320px]"
          />
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredItems.map((item) => {
            return (
              <Link
                key={item.id}
                href={`/specialities/${item.slug}`}
                className="group border border-slate-100 bg-white p-5 shadow-[0_12px_32px_rgba(15,23,42,0.08)] transition hover:-translate-y-1 hover:shadow-[0_20px_50px_rgba(15,23,42,0.12)] sm:p-6"
              >
                <div className="mb-4 flex size-12 items-center justify-center bg-cyan-50 text-teal-600 transition group-hover:bg-[#062f66] group-hover:text-white">
                  <SpecialtyIconGlyph
                    icon={item.icon}
                    size={26}
                    strokeWidth={2.2}
                  />
                </div>
                <h3 className="text-lg font-bold leading-tight text-[#062f66] sm:text-xl">
                  {item.title}
                </h3>
                <p className="mt-3 text-sm leading-7 text-slate-600 sm:text-base">
                  {item.shortDescription}
                </p>
                <span className="mt-5 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.14em] text-cyan-700">
                  View details <ArrowRight size={15} />
                </span>
              </Link>
            );
          })}
        </div>
      </Container>
    </section>
  );
}

function SpecialtyDetail({ item }: { item: SpecialtyItem }) {
  const doctors = item.doctors
    .filter((doctor) => doctor.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <>
      <section className="bg-[#062f66] py-10 text-white sm:py-14 lg:py-20">
        <Container>
          <Link
            href="/specialities"
            className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:bg-white/15"
          >
            <ArrowLeft size={16} />
            All specialities
          </Link>

          <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_420px] lg:items-center">
            <div>
              <span className="inline-flex items-center gap-2 border border-white/20 bg-white/10 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-100">
                <SpecialtyIconGlyph
                  icon={item.icon}
                  className="h-4 w-4"
                  strokeWidth={2.4}
                />
                Department
              </span>
              <h1 className="mt-4 text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
                {item.detailTitle || item.title}
              </h1>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base lg:text-lg lg:leading-8">
                {item.detailDescription || item.shortDescription}
              </p>
            </div>

            <div className="aspect-[4/3] overflow-hidden border border-white/15 bg-white/10">
              <img
                src={item.image}
                alt={item.title}
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-white py-14 sm:py-18">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_340px]">
            <article className="border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-8">
              <h2 className="text-2xl font-black text-[#062f66]">
                Available services
              </h2>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {item.services.map((service) => (
                  <div
                    key={service}
                    className="border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold leading-6 text-slate-700"
                  >
                    {service}
                  </div>
                ))}
              </div>
            </article>

            <aside className="border border-slate-200 bg-slate-50 p-6">
              <h2 className="text-lg font-black text-[#062f66]">
                Need this department?
              </h2>
              <p className="mt-3 text-sm leading-7 text-slate-600">
                Contact the appointment desk for schedule, consultant
                availability, and preparation instructions.
              </p>
              <Link
                href="/appointment"
                className="mt-5 inline-flex w-full items-center justify-center gap-2 bg-[#062f66] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#0b428b]"
              >
                <CalendarCheck size={16} />
                Request appointment
              </Link>
            </aside>
          </div>

          <div className="mt-10">
            <h2 className="text-2xl font-black text-[#062f66]">
              Department doctors
            </h2>
            <div className="mt-5 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {doctors.map((doctor) => (
                <article
                  key={doctor.id}
                  className="border border-slate-200 bg-white p-5 shadow-[0_12px_32px_rgba(15,23,42,0.06)]"
                >
                  <div className="flex gap-4">
                    <div className="h-20 w-20 shrink-0 overflow-hidden bg-cyan-50">
                      {doctor.image ? (
                        <img
                          src={doctor.image}
                          alt={doctor.name}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="grid h-full place-items-center text-[#062f66]">
                          <SpecialtyIconGlyph icon={item.icon} size={28} />
                        </div>
                      )}
                    </div>
                    <div>
                      <h3 className="font-black text-[#062f66]">{doctor.name}</h3>
                      <p className="mt-1 text-sm font-semibold text-cyan-700">
                        {doctor.title}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 space-y-2 text-sm font-semibold text-slate-600">
                    <p className="flex gap-2">
                      <Clock size={16} className="mt-0.5 text-cyan-700" />
                      <span>
                        {doctor.schedule}
                        <br />
                        {doctor.time}
                      </span>
                    </p>
                    <p className="flex gap-2">
                      <MapPin size={16} className="mt-0.5 text-cyan-700" />
                      <span>{doctor.room}</span>
                    </p>
                    <p className="font-black text-[#062f66]">Fee: {doctor.fee}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
