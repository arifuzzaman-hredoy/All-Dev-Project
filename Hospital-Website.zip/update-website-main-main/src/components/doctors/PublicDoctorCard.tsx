import Image from "next/image";
import Link from "next/link";
import { CalendarCheck, UserRound } from "lucide-react";

import type { DoctorProfile } from "@/types/doctor";

type PublicDoctorCardProps = {
  doctor: DoctorProfile;
};

export default function PublicDoctorCard({ doctor }: PublicDoctorCardProps) {
  return (
    <article className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-[0_12px_32px_rgba(15,23,42,0.08)]">
      <div className="flex aspect-[4/3] items-center justify-center overflow-hidden bg-gradient-to-br from-blue-50 via-cyan-50 to-amber-50">
        {doctor.imageUrl ? (
          <Image
            src={doctor.imageUrl}
            alt={doctor.name}
            width={640}
            height={480}
            unoptimized
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex size-20 items-center justify-center rounded-full bg-white text-[#062f66] shadow-sm sm:size-24">
            <UserRound size={42} strokeWidth={1.8} />
          </div>
        )}
      </div>
      <div className="p-5 sm:p-6">
        <h3 className="text-lg font-bold leading-tight text-[#062f66] sm:text-xl">
          {doctor.name}
        </h3>
        <p className="mt-2 font-semibold text-teal-600">
          {doctor.designation || doctor.department}
        </p>
        <p className="mt-2 text-sm font-semibold text-slate-700">
          {doctor.specialist}
        </p>
        <p className="mt-3 text-sm text-slate-600">
          {doctor.experienceYears} years experience
        </p>
        <p className="mt-1 text-sm text-slate-600">
          Available: {doctor.availableDays.join(", ")}
        </p>
        <Link
          href="/appointment"
          className="mt-5 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#43c7f4] sm:w-auto"
        >
          <CalendarCheck size={18} />
          Book Appointment
        </Link>
      </div>
    </article>
  );
}
