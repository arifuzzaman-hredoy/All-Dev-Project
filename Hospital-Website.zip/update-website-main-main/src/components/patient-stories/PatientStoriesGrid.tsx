// File: clinic-website/src/components/patient-stories/PatientStoriesGrid.tsx

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, HeartPulse, Quote } from "lucide-react";
import Container from "@/components/common/Container";
import PatientStoryCard from "@/components/patient-stories/PatientStoryCard";
import {
  DEFAULT_PATIENT_STORIES,
  PatientStory,
  getActivePatientStories,
} from "@/lib/patientStories";

export default function PatientStoriesGrid() {
  const [stories, setStories] = useState<PatientStory[]>(() =>
    DEFAULT_PATIENT_STORIES.filter((item) => item.active).sort(
      (a, b) => a.sortOrder - b.sortOrder,
    ),
  );

  useEffect(() => {
    function loadStories() {
      setStories(getActivePatientStories());
    }

    loadStories();
    window.addEventListener("storage", loadStories);
    window.addEventListener("patient-stories-updated", loadStories);

    return () => {
      window.removeEventListener("storage", loadStories);
      window.removeEventListener("patient-stories-updated", loadStories);
    };
  }, []);

  if (!stories.length) {
    return (
      <section className="px-6 py-20 text-center text-[#002f70]">
        <h1 className="text-2xl font-black">No active patient story found</h1>
        <p className="mt-2 font-semibold">Admin panel থেকে story active করো।</p>
      </section>
    );
  }

  return (
    <section className="relative overflow-hidden bg-[linear-gradient(180deg,#ffffff_0%,#f6faff_50%,#ffffff_100%)] py-10 sm:py-14 lg:py-20">
      <div className="pointer-events-none absolute left-[-150px] top-20 h-[320px] w-[320px] rounded-full bg-[#062f66]/5 blur-[90px]" />
      <div className="pointer-events-none absolute bottom-16 right-[-140px] h-[340px] w-[340px] rounded-full bg-[#5bc0de]/10 blur-[95px]" />
      <div className="pointer-events-none absolute left-1/2 top-[52%] h-[220px] w-[72%] -translate-x-1/2 rounded-full bg-[#8cc63f]/[0.06] blur-[90px]" />

      <div className="pointer-events-none absolute left-8 top-12 hidden text-[#062f66]/5 lg:block">
        <HeartPulse size={120} strokeWidth={1.3} />
      </div>

      <div className="pointer-events-none absolute bottom-16 right-10 hidden text-[#062f66]/5 lg:block">
        <Quote size={120} strokeWidth={1.3} />
      </div>

      <Container>
        <div className="relative z-10 mx-auto max-w-[1245px]">
          <div className="max-w-[690px]">
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-[#dfe8f3] bg-white/85 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-[#062f66] shadow-[0_10px_24px_rgba(6,47,102,0.055)]">
              <HeartPulse size={15} className="text-[#5bc0de]" />
              Patient Stories
            </span>

            <h1 className="text-3xl font-black leading-tight text-[#062f66] sm:text-4xl lg:text-5xl">
              Our Incredible Patients Share Their Stories
            </h1>

            <p className="mt-5 max-w-2xl text-sm font-medium leading-7 text-slate-600 sm:text-base">
              Real experiences from patients who trusted Update for care,
              support, and better health.
            </p>
          </div>

          <div className="mt-8 grid gap-5 sm:mt-12 sm:gap-6 md:grid-cols-3">
            {stories.map((story) => (
              <div
                key={story.slug}
                className="rounded-xl transition-all duration-500 ease-out hover:-translate-y-1 hover:shadow-[0_22px_45px_rgba(6,47,102,0.12)]"
              >
                <PatientStoryCard story={story} />
              </div>
            ))}
          </div>

          <div className="mt-8 flex justify-center sm:mt-12">
            <Link
              href="/patient-stories"
              className="group relative inline-flex min-h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-lg bg-[#062f66] px-6 py-3 text-sm font-black uppercase tracking-[0.04em] text-white shadow-[0_14px_30px_rgba(6,47,102,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#43c7f4] hover:shadow-[0_18px_40px_rgba(67,199,244,0.24)] sm:w-auto sm:min-w-[220px] sm:px-8 sm:py-4"
            >
              <span className="relative z-10">View All Stories</span>

              <ArrowRight
                size={18}
                strokeWidth={2.5}
                className="relative z-10 transition-transform duration-300 group-hover:translate-x-1"
              />

              <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </Link>
          </div>
        </div>
      </Container>
    </section>
  );
}
