// File: clinic-website/src/components/patient-stories/PatientStoryDetail.tsx

"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Home } from "lucide-react";
import Container from "@/components/common/Container";
import {
  PatientStory,
  formatStoryDate,
  getActivePatientStories,
} from "@/lib/patientStories";
import type { PatientStory as SitePatientStory } from "@/data/site";

type PatientStoryDetailProps = {
  story?: PatientStory | SitePatientStory;
  slug?: string;
};

function toLocalStory(item?: PatientStory | SitePatientStory) {
  if (!item) return null;
  if ("id" in item) return item;

  return {
    id: item.slug,
    slug: item.slug,
    title: item.title,
    date: item.date,
    image: item.image,
    excerpt: item.excerpt,
    leadText: item.excerpt,
    body: item.content,
    active: true,
    sortOrder: 1,
    createdAt: "2026-06-12T00:00:00.000Z",
    updatedAt: "2026-06-12T00:00:00.000Z",
  };
}

export default function PatientStoryDetail({
  story,
  slug,
}: PatientStoryDetailProps) {
  const params = useParams();
  const initialStory = useMemo(() => toLocalStory(story), [story]);
  const currentSlug = slug || initialStory?.slug || String(params?.slug || "");
  const [storedStory, setStoredStory] = useState<PatientStory | null>(
    initialStory
  );

  useEffect(() => {
    function loadStory() {
      const nextStory =
        getActivePatientStories().find((item) => item.slug === currentSlug) ||
        initialStory;
      setStoredStory(nextStory);
    }

    queueMicrotask(loadStory);
    window.addEventListener("storage", loadStory);
    window.addEventListener("patient-stories-updated", loadStory);

    return () => {
      window.removeEventListener("storage", loadStory);
      window.removeEventListener("patient-stories-updated", loadStory);
    };
  }, [currentSlug, initialStory]);

  if (!storedStory) {
    return (
      <main className="grid min-h-[70vh] place-items-center bg-white p-8 text-center text-[#002f70]">
        <div>
          <h1 className="text-2xl font-black">Story not found</h1>
          <p className="mt-2 font-semibold">
            Story hidden, deleted, or slug changed from admin panel.
          </p>
          <Link
            href="/patient-stories"
            className="mt-6 inline-flex bg-[#002f70] px-6 py-4 font-black text-white"
          >
            Back to Stories
          </Link>
        </div>
      </main>
    );
  }

  return (
    <section className="bg-white py-10 sm:py-14 lg:py-16">
      <Container>
        <nav className="flex flex-wrap items-center gap-3 text-base font-bold text-[#062f66]">
          <Link href="/" className="inline-flex items-center gap-1 text-blue-600">
            <Home size={17} />
            Home
          </Link>
          <span className="text-slate-300">›</span>
          <Link href="/patient-stories" className="text-blue-600">
            Patient Stories
          </Link>
          <span className="text-slate-300">›</span>
          <span>{storedStory.title}</span>
        </nav>

        <article className="mx-auto mt-14 max-w-5xl">
          <time className="inline-flex border border-[#e2dff6] px-4 py-1 text-[13px] font-semibold uppercase tracking-[0.32em] text-[#8a6bb8]">
            {formatStoryDate(storedStory.date)}
          </time>

          <h1 className="mt-6 text-4xl font-black leading-tight text-[#062f66] sm:text-5xl">
            {storedStory.title}
          </h1>

          <div className="relative mt-10 h-[280px] overflow-hidden rounded-[4px] bg-slate-100 sm:h-[430px]">
            <img
              src={storedStory.image}
              alt={storedStory.title}
              className="h-full w-full object-cover"
            />
          </div>

          <p className="mt-10 text-xl font-semibold leading-9 text-[#062f66]">
            {storedStory.leadText}
          </p>

          <div className="mt-8 space-y-6 text-lg leading-8 text-slate-700">
            {storedStory.body.map((paragraph, index) => (
              <p key={`${storedStory.id}-${index}`}>{paragraph}</p>
            ))}
          </div>

          <Link
            href="/patient-stories"
            className="mt-10 inline-flex bg-[#062f66] px-8 py-4 text-sm font-black text-white transition hover:bg-[#5bc0de]"
          >
            Back to Stories
          </Link>
        </article>
      </Container>
    </section>
  );
}
