// File: clinic-website/src/components/patient-stories/PatientStoryCard.tsx

import Link from "next/link";
import { ArrowRight, CalendarDays } from "lucide-react";
import { formatStoryDate, type PatientStory } from "@/lib/patientStories";

type PatientStoryCardProps = {
  story: PatientStory;
};

export default function PatientStoryCard({ story }: PatientStoryCardProps) {
  return (
    <article className="group relative overflow-hidden rounded-xl border border-slate-200/80 bg-white shadow-[0_12px_30px_rgba(6,47,102,0.08)] transition-all duration-500 hover:-translate-y-1.5 hover:border-[#cfe0f4] hover:shadow-[0_24px_55px_rgba(6,47,102,0.16)]">
      <div className="relative h-[190px] overflow-hidden bg-slate-100 sm:h-[210px]">
        <img
          src={story.image}
          alt={story.title}
          className="h-full w-full object-cover transition-all duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.075]"
        />

        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#062f66]/45 via-[#062f66]/10 to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-90" />

        <div className="pointer-events-none absolute inset-x-5 top-5 h-px bg-white/50 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
      </div>

      <div className="relative bg-white p-5 sm:min-h-[200px]">
        <div className="pointer-events-none absolute right-0 top-0 h-24 w-24 rounded-bl-full bg-[#f4f8fc]" />

        <time className="relative z-10 inline-flex items-center gap-2 rounded-full border border-[#e2dff6] bg-[#f8f6ff] px-4 py-2 text-[12px] font-black uppercase tracking-[0.22em] text-[#8a6bb8] transition-all duration-300 group-hover:border-[#8a6bb8]/40 group-hover:bg-white group-hover:shadow-[0_10px_22px_rgba(138,107,184,0.10)]">
          <CalendarDays size={14} strokeWidth={2.2} />
          {formatStoryDate(story.date)}
        </time>

        <h2 className="relative z-10 mt-4 text-lg font-black leading-7 text-[#062f66] transition-colors duration-300 group-hover:text-[#041d43] sm:mt-5 sm:text-xl">
          {story.title}
        </h2>

        <p className="relative z-10 mt-3 line-clamp-2 text-sm font-semibold leading-6 text-slate-600">
          {story.excerpt}
        </p>

        <Link
          href={`/patient-stories/${story.slug}`}
          className="group/link relative z-10 mt-5 inline-flex min-h-11 w-fit items-center gap-2 text-sm font-black text-[#43c7f4] transition-all duration-300 hover:text-[#8cc63f] sm:mt-6 sm:text-base"
        >
          <span className="relative inline-block after:absolute after:left-0 after:-bottom-[6px] after:h-[3px] after:w-0 after:rounded-full after:bg-gradient-to-r after:from-[#43c7f4] after:via-[#8cc63f] after:to-[#43c7f4] after:shadow-[0_0_10px_rgba(67,199,244,0.55)] after:transition-all after:duration-300 group-hover/link:after:w-full">
            Read More Story
          </span>

          <ArrowRight
            size={18}
            strokeWidth={2.5}
            className="transition-transform duration-300 group-hover/link:translate-x-1"
          />
        </Link>
      </div>
    </article>
  );
}
