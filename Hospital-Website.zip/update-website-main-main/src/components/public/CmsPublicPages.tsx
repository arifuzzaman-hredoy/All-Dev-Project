export {
  ContactPublicPage,
  LegalPublicPage,
  SupportPublicPage,
} from "@/components/public/PublicSitePage";
