/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import type { ReactNode } from "react";
import {
  ArrowRight,
  CalendarCheck,
  CheckCircle2,
  FileText,
  Headphones,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Stethoscope,
  type LucideIcon,
} from "lucide-react";

import LocationMap from "@/components/contact/LocationMap";
import PublicFormSubmissionForm from "@/components/forms/PublicFormSubmissionForm";
import {
  getPublicStaticPageBySlug,
  type StaticPageContent,
  type StaticPageKey,
} from "@/lib/static-pages";
import { siteInfo } from "@/data/site-base";

type PublicSitePageProps = {
  pageKey: StaticPageKey;
};

type LegalPublicPageProps = {
  type: "privacy" | "terms";
};

type SmartLinkProps = {
  href: string;
  className: string;
  children: ReactNode;
};

function isExternalHref(href: string) {
  return (
    href.startsWith("http") ||
    href.startsWith("mailto:") ||
    href.startsWith("tel:")
  );
}

function SmartLink({ href, className, children }: SmartLinkProps) {
  if (!href) return null;

  if (isExternalHref(href)) {
    return (
      <a href={href} className={className}>
        {children}
      </a>
    );
  }

  return (
    <Link href={href} className={className}>
      {children}
    </Link>
  );
}

function PageHero({ page }: { page: StaticPageContent }) {
  const backgroundStyle = page.heroImage
    ? {
        backgroundImage: `linear-gradient(90deg, rgba(6, 48, 94, 0.96), rgba(6, 48, 94, 0.88)), url(${page.heroImage})`,
      }
    : undefined;

  return (
    <section
      className="relative overflow-hidden bg-[#07366f] bg-cover bg-center px-4 py-20 text-white md:px-8 md:py-24"
      style={backgroundStyle}
    >
      <div className="pointer-events-none absolute -left-28 top-0 h-72 w-72 rounded-full bg-[#43c7f4]/20 blur-[95px]" />
      <div className="pointer-events-none absolute -right-28 bottom-0 h-80 w-80 rounded-full bg-white/10 blur-[105px]" />
      <div className="relative mx-auto max-w-6xl">
        <p className="text-xs font-black uppercase tracking-[0.28em] text-cyan-300">
          {page.eyebrow}
        </p>
        <h1 className="mt-5 max-w-4xl text-4xl font-black tracking-[-0.04em] text-white md:text-5xl lg:text-6xl">
          {page.title}
        </h1>
        <p className="mt-6 max-w-2xl text-base font-semibold leading-8 text-sky-50 md:text-lg md:leading-9">
          {page.description}
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <SmartLink
            href={page.primaryButtonHref}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-cyan-400 px-6 py-3 text-sm font-black text-[#07366f] shadow-[0_18px_45px_rgba(34,211,238,0.25)] transition hover:-translate-y-0.5 hover:bg-white"
          >
            {page.primaryButtonLabel}
            <ArrowRight size={17} />
          </SmartLink>
          <SmartLink
            href={page.secondaryButtonHref}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 py-3 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-white hover:text-[#07366f]"
          >
            {page.secondaryButtonLabel}
            <ArrowRight size={17} />
          </SmartLink>
        </div>
      </div>
    </section>
  );
}

function InfoCard({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon: LucideIcon;
  children: ReactNode;
}) {
  return (
    <div className="rounded-[24px] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-[#43c7f4]/50 hover:shadow-[0_18px_45px_rgba(6,47,102,0.10)]">
      <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-50 text-[#07366f]">
        <Icon size={22} />
      </div>
      <h2 className="text-xl font-black text-[#07366f]">{title}</h2>
      <div className="mt-3 space-y-1 text-sm font-semibold leading-7 text-slate-600">
        {children}
      </div>
    </div>
  );
}

function safeUpdatedDate(page: StaticPageContent) {
  if (!page.updatedAt) return "2026";

  try {
    return new Intl.DateTimeFormat("en", {
      year: "numeric",
      month: "short",
      day: "2-digit",
    }).format(new Date(page.updatedAt));
  } catch {
    return "2026";
  }
}

function legalSections(page: StaticPageContent) {
  const bodySections = page.body.map((paragraph, index) => ({
    id: `body-${index + 1}`,
    title: index === 0 ? page.title : `Information ${index + 1}`,
    content: paragraph,
  }));

  const cardSections = page.cards.map((card, index) => ({
    id: `card-${index + 1}`,
    title: card.title,
    content: card.description,
  }));

  return [...bodySections, ...cardSections];
}

function LegalArticle({ page, badgeLabel }: { page: StaticPageContent; badgeLabel: string }) {
  const sections = legalSections(page);

  return (
    <section className="bg-white px-4 py-16 md:px-8 md:py-20">
      <article className="mx-auto max-w-[820px] rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_55px_rgba(6,47,102,0.08)] md:p-10">
        <div className="flex flex-col gap-5 border-b border-slate-200 pb-7 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h2 className="text-3xl font-black tracking-tight text-slate-950">
              {page.title}
            </h2>
            <p className="mt-3 text-sm font-bold text-slate-500">
              Last Updated: <span className="text-[#07366f]">{safeUpdatedDate(page)}</span>
            </p>
          </div>

          <span className="inline-flex w-fit items-center gap-2 rounded-2xl bg-[#07366f] px-5 py-3 text-sm font-black text-white shadow-sm">
            <ShieldCheck className="h-4 w-4" />
            {badgeLabel}
          </span>
        </div>

        <p className="mt-9 whitespace-pre-line text-[15px] font-semibold leading-8 text-slate-800">
          {page.description}
        </p>

        <div className="mt-8 space-y-9">
          {sections.map((section, index) => (
            <section key={section.id}>
              <h3 className="text-xl font-black text-slate-950">
                {index + 1}. {section.title}
              </h3>
              <p className="mt-5 whitespace-pre-line text-[15px] font-semibold leading-8 text-slate-700">
                {section.content}
              </p>
            </section>
          ))}
        </div>
      </article>
    </section>
  );
}

function SupportTopicCard({
  title,
  description,
  icon: Icon,
}: {
  title: string;
  description: string;
  icon: LucideIcon;
}) {
  return (
    <div className="group rounded-[24px] border border-slate-200 bg-sky-50/40 p-5 transition hover:-translate-y-1 hover:border-[#43c7f4]/50 hover:bg-white hover:shadow-[0_18px_45px_rgba(6,47,102,0.10)]">
      <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-[#07366f] shadow-sm transition group-hover:bg-[#43c7f4] group-hover:text-white">
        <Icon size={21} />
      </div>
      <h3 className="text-base font-black text-[#07366f]">{title}</h3>
      <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
        {description}
      </p>
    </div>
  );
}

const supportIcons = [
  CalendarCheck,
  ShieldCheck,
  CheckCircle2,
  Headphones,
  Stethoscope,
];

export async function ContactPublicPage() {
  const page = await getPublicStaticPageBySlug("contact");

  return (
    <main className="bg-white text-slate-950">
      <PageHero page={page} />

      <section className="px-4 py-16 md:px-8 md:py-20">
        <div className="mx-auto max-w-6xl">
          <div className="grid gap-5 md:grid-cols-3">
            <InfoCard title="Phone" icon={Phone}>
              <p>{siteInfo.phone}</p>
              <p>Emergency: {siteInfo.emergency}</p>
            </InfoCard>
            <InfoCard title="Email" icon={Mail}>
              <p className="break-all">{siteInfo.email}</p>
            </InfoCard>
            <InfoCard title="Address" icon={MapPin}>
              <p>{siteInfo.address}</p>
              <p>{siteInfo.hours}</p>
            </InfoCard>
          </div>

          <div className="mt-10 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="rounded-[30px] border border-slate-200 bg-white p-7 shadow-sm">
              <p className="text-xs font-black uppercase tracking-[0.24em] text-sky-600">
                Location
              </p>
              <h2 className="mt-3 text-3xl font-black tracking-tight text-[#07366f]">
                Visit Update Diagnostic Center
              </h2>
              <div className="mt-4 space-y-4 text-sm font-semibold leading-7 text-slate-600">
                {page.body.slice(0, 2).map((paragraph) => (
                  <p key={paragraph}>{paragraph}</p>
                ))}
              </div>
              <div className="mt-6 grid gap-3">
                {page.highlights.slice(0, 4).map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-sky-50/50 px-4 py-3 text-xs font-black text-slate-600"
                  >
                    <CheckCircle2 size={16} className="shrink-0 text-sky-500" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <SmartLink
                href={`tel:${siteInfo.phone}`}
                className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#07366f] px-6 py-3 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-[#43c7f4]"
              >
                Call Now
                <Phone size={17} />
              </SmartLink>
            </div>

            <div className="overflow-hidden rounded-[30px] border border-slate-200 bg-slate-100 shadow-sm">
              <LocationMap />
            </div>
          </div>
        </div>
      </section>

      <PublicFormSubmissionForm
        formType="CONTACT"
        title="Send us a message"
        description="Submit your contact request and our desk team will follow up from the admin panel."
        defaultSubject="Contact request"
        subjectPlaceholder="Appointment, service, billing, or general inquiry"
        messagePlaceholder="Write your contact request details"
      />
    </main>
  );
}

export async function SupportPublicPage() {
  const page = await getPublicStaticPageBySlug("support");
  const topics = page.cards.length
    ? page.cards
    : page.highlights.map((item) => ({ title: item, description: "Support guidance and information." }));

  return (
    <main className="bg-white text-slate-950">
      <PageHero page={page} />

      <section className="px-4 py-16 md:px-8 md:py-20">
        <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[1.2fr_0.9fr]">
          <div className="rounded-[30px] border border-slate-200 bg-white p-6 shadow-sm md:p-8">
            <div className="mb-6 flex flex-wrap items-center gap-3">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-50 text-sky-700">
                <Headphones size={24} />
              </span>
              <span className="rounded-full border border-sky-200 bg-sky-50 px-4 py-1.5 text-xs font-black uppercase tracking-[0.22em] text-sky-700">
                Support Center
              </span>
            </div>

            <h2 className="text-3xl font-black tracking-tight text-[#07366f]">
              How can we help?
            </h2>
            <p className="mt-3 max-w-2xl text-sm font-semibold leading-7 text-slate-600">
              {page.body[0] || page.description}
            </p>

            <div className="mt-7 grid gap-4 md:grid-cols-2">
              {topics.map((topic, index) => {
                const Icon = supportIcons[index % supportIcons.length];
                return (
                  <SupportTopicCard
                    key={`${topic.title}-${index}`}
                    title={topic.title}
                    description={topic.description}
                    icon={Icon}
                  />
                );
              })}
            </div>

            {page.highlights.length ? (
              <div className="mt-6 grid gap-3 md:grid-cols-3">
                {page.highlights.slice(0, 6).map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-xs font-black text-slate-600"
                  >
                    <CheckCircle2 size={16} className="shrink-0 text-sky-500" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            ) : null}
          </div>

          <div className="rounded-[30px] bg-[#07366f] p-7 text-white shadow-xl md:p-8">
            <span className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 text-white">
              <Phone size={25} />
            </span>
            <p className="w-fit rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-black uppercase tracking-[0.2em] text-sky-100">
              Patient Help Desk
            </p>
            <h2 className="mt-6 text-3xl font-black">Contact Support</h2>
            <p className="mt-4 text-sm font-semibold leading-7 text-sky-50">
              Call {siteInfo.phone} or emergency hotline {siteInfo.emergency} for urgent service guidance.
            </p>
            <div className="mt-8 rounded-[24px] border border-white/15 bg-white/10 p-5 text-sm font-bold leading-7">
              Phone: {siteInfo.phone}
              <br />
              Emergency: {siteInfo.emergency}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <SmartLink
                href={`tel:${siteInfo.phone}`}
                className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-6 py-3 text-sm font-black text-[#07366f] transition hover:-translate-y-0.5 hover:bg-white"
              >
                Call Support
                <Phone size={17} />
              </SmartLink>
              <SmartLink
                href="/contact"
                className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-black text-[#07366f] transition hover:-translate-y-0.5 hover:bg-cyan-50"
              >
                Go to Contact
                <ArrowRight size={17} />
              </SmartLink>
            </div>
          </div>
        </div>
      </section>

      <PublicFormSubmissionForm
        formType="SUPPORT"
        title="Submit a support request"
        description="Send your appointment, report, package, or patient support request to our team."
        defaultSubject="Support request"
        subjectPlaceholder="Appointment support, report help, package guidance..."
        messagePlaceholder="Write your support request details"
      />
    </main>
  );
}

export async function LegalPublicPage({ type }: LegalPublicPageProps) {
  const pageKey = type === "privacy" ? "privacy-policy" : "terms";
  const page = await getPublicStaticPageBySlug(pageKey);

  return (
    <main className="bg-white text-slate-950">
      <PageHero page={page} />
      <LegalArticle page={page} badgeLabel={type === "privacy" ? "Privacy" : "Legal"} />
    </main>
  );
}

export default async function PublicSitePage({ pageKey }: PublicSitePageProps) {
  if (pageKey === "contact") return <ContactPublicPage />;
  if (pageKey === "support") return <SupportPublicPage />;
  if (pageKey === "privacy-policy") return <LegalPublicPage type="privacy" />;
  if (pageKey === "terms") return <LegalPublicPage type="terms" />;

  const page = await getPublicStaticPageBySlug(pageKey);

  return (
    <main className="bg-white text-slate-950">
      <PageHero page={page} />
      <section className="px-4 py-16 md:px-8 md:py-20">
        <div className="mx-auto max-w-6xl">
          <div className="grid gap-4 md:grid-cols-2">
            {page.cards.map((card) => (
              <InfoCard key={card.title} title={card.title} icon={FileText}>
                <p>{card.description}</p>
              </InfoCard>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
