// File: clinic-website/src/components/home/NewsPreview.tsx

import Container from "@/components/common/Container";
import SectionTitle from "@/components/common/SectionTitle";
import { news } from "@/data/site";

export default function NewsPreview() {
  return (
    <section className="bg-white py-10 sm:py-14 lg:py-20">
      <Container>
        <SectionTitle
          eyebrow="News & Media"
          title="Latest hospital updates."
          description="Simple content cards are ready for real press releases, announcements, and health articles."
          align="center"
        />
        <div className="mt-8 grid gap-4 md:grid-cols-3 md:gap-6">
          {news.map((item) => (
            <article
              key={item.title}
              className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_12px_32px_rgba(15,23,42,0.08)] sm:p-6"
            >
              <p className="text-sm font-bold text-teal-600">{item.date}</p>
              <h3 className="mt-3 text-lg font-black leading-7 text-[#062f66] sm:text-xl">
                {item.title}
              </h3>
              <p className="mt-3 text-sm leading-7 text-slate-600 sm:text-base">
                {item.summary}
              </p>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
