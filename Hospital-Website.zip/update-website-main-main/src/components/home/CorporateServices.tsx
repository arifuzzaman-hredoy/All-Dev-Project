// File: clinic-website/src/components/home/CorporateServices.tsx

"use client";

import {
  Building2,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Headphones,
  ShieldCheck,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  CorporateFeatureItem,
  getCorporateServicesFromStorage,
} from "@/lib/corporateServices";

function FeatureIcon({ item }: { item: CorporateFeatureItem }) {
  if (item.icon === "Clock3") return <Clock3 size={20} />;
  if (item.icon === "Headphones") return <Headphones size={20} />;
  return <ShieldCheck size={20} />;
}

export default function CorporateServices() {
  const sliderRef = useRef<HTMLDivElement | null>(null);
  const [data, setData] = useState(() => getCorporateServicesFromStorage());

  const activeFeatures = useMemo(
    () =>
      data.features
        .filter((item) => item.active)
        .sort((a, b) => a.sortOrder - b.sortOrder),
    [data.features]
  );

  const activeLogos = useMemo(
    () =>
      data.logos
        .filter((item) => item.active)
        .sort((a, b) => a.sortOrder - b.sortOrder),
    [data.logos]
  );

  const scrollNext = () => {
    const slider = sliderRef.current;
    if (!slider) return;

    const cardWidth = slider.clientWidth / 5;

    if (slider.scrollLeft + slider.clientWidth >= slider.scrollWidth - 20) {
      slider.scrollTo({
        left: 0,
        behavior: "smooth",
      });
      return;
    }

    slider.scrollBy({
      left: cardWidth,
      behavior: "smooth",
    });
  };

  const scrollPrevious = () => {
    const slider = sliderRef.current;
    if (!slider) return;

    const cardWidth = slider.clientWidth / 5;

    if (slider.scrollLeft <= 10) {
      slider.scrollTo({
        left: slider.scrollWidth,
        behavior: "smooth",
      });
      return;
    }

    slider.scrollBy({
      left: -cardWidth,
      behavior: "smooth",
    });
  };

  useEffect(() => {
    const timer = window.setInterval(() => {
      scrollNext();
    }, 2600);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    function loadCorporateServices() {
      setData(getCorporateServicesFromStorage());
    }

    window.addEventListener("storage", loadCorporateServices);
    window.addEventListener("corporate-services-updated", loadCorporateServices);
    return () => {
      window.removeEventListener("storage", loadCorporateServices);
      window.removeEventListener("corporate-services-updated", loadCorporateServices);
    };
  }, []);

  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 sm:py-14 lg:py-20">
      {/* Premium Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#eef8ff_42%,#f7f1ff_100%)]" />

        <div className="absolute left-[-190px] top-[-150px] h-[440px] w-[440px] rounded-full bg-[#43c7f4]/16 blur-[110px]" />
        <div className="absolute right-[-210px] top-20 h-[480px] w-[480px] rounded-full bg-[#8a6bb8]/16 blur-[120px]" />
        <div className="absolute bottom-[-210px] left-[35%] h-[430px] w-[430px] rounded-full bg-[#8cc63f]/10 blur-[115px]" />

        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(6,47,102,0.045)_1px,transparent_1px),linear-gradient(180deg,rgba(6,47,102,0.045)_1px,transparent_1px)] [background-size:44px_44px]" />

        <svg
          aria-hidden="true"
          className="absolute left-1/2 top-[110px] h-[150px] w-[1050px] -translate-x-1/2 text-[#43c7f4]/20"
          viewBox="0 0 1050 150"
          fill="none"
        >
          <path
            d="M0 88C90 88 90 48 180 48C270 48 270 112 360 112C450 112 450 38 540 38C630 38 630 96 720 96C810 96 810 62 900 62C975 62 990 80 1050 80"
            stroke="currentColor"
            strokeWidth="4"
            strokeLinecap="round"
          />
        </svg>

        <div className="absolute left-10 top-24 hidden h-28 w-28 rotate-12 rounded-[34px] border border-white/70 bg-white/45 shadow-[0_24px_65px_rgba(6,47,102,0.08)] backdrop-blur-md lg:block" />
        <div className="absolute bottom-28 right-14 hidden h-36 w-36 rounded-full border border-white/70 bg-white/40 shadow-[0_24px_65px_rgba(138,107,184,0.10)] backdrop-blur-md lg:block" />
        <div className="absolute bottom-16 left-20 hidden h-20 w-20 -rotate-12 rounded-[28px] border border-white/70 bg-white/40 shadow-[0_20px_55px_rgba(67,199,244,0.10)] backdrop-blur-md lg:block" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062f66]/15 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/25 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-[1320px] px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto max-w-[1050px] text-center">
          <div className="mx-auto mb-4 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,47,102,0.08)] backdrop-blur-md sm:mb-5">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062f66] text-white shadow-[0_10px_25px_rgba(6,47,102,0.18)]">
              <Building2 size={16} />
            </span>

            <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
              {data.badgeText}
            </span>
          </div>

          <h2 className="text-3xl font-black leading-tight text-[#062f66] sm:text-4xl lg:text-5xl">
            {data.headingMain}{" "}
            <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062f66] bg-clip-text text-transparent">
              {data.headingAccent}
              <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
            </span>
          </h2>

          <div className="relative mx-auto mt-6 overflow-hidden rounded-[24px] border border-white/80 bg-white/75 p-5 text-left shadow-[0_20px_60px_rgba(6,47,102,0.10)] backdrop-blur-xl sm:mt-8 sm:rounded-[34px] sm:p-8">
            <div className="pointer-events-none absolute right-[-70px] top-[-70px] h-[180px] w-[180px] rounded-full bg-[#43c7f4]/15 blur-[45px]" />
            <div className="pointer-events-none absolute bottom-[-85px] left-[35%] h-[190px] w-[190px] rounded-full bg-[#8a6bb8]/14 blur-[50px]" />

            <div className="relative z-10 grid gap-6 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
              <p className="text-sm font-semibold leading-7 text-[#4d6380] sm:text-base sm:leading-8">
                <span className="font-black text-[#062f66]">
                  {data.mainLabel}
                </span>{" "}
                {data.mainText}
              </p>

              <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-1">
                {activeFeatures.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 rounded-2xl border border-[#dbeafe] bg-[#f8fbff]/90 p-4 shadow-[0_14px_35px_rgba(6,47,102,0.06)]">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#43c7f4]/12 text-[#43c7f4]">
                      <FeatureIcon item={item} />
                    </span>
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.12em] text-[#8a6bb8]">
                        {item.label}
                      </p>
                      <p className="mt-1 text-sm font-black text-[#062f66]">
                        {item.value}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Corporate Logo Slider */}
        <div className="relative mx-auto mt-10 max-w-[1180px] overflow-hidden rounded-[24px] border border-white/80 bg-white/70 px-12 py-5 shadow-[0_20px_60px_rgba(6,47,102,0.12)] backdrop-blur-xl sm:mt-16 sm:rounded-[34px] sm:px-20 sm:py-8">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(67,199,244,0.14),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(138,107,184,0.14),transparent_35%)]" />

          <button
            type="button"
            onClick={scrollPrevious}
            aria-label="Previous corporate logo"
            className="absolute left-3 top-1/2 z-20 grid size-10 -translate-y-1/2 place-items-center rounded-full bg-[#062f66] text-white shadow-[0_14px_35px_rgba(6,47,102,0.26)] transition-all duration-300 hover:-translate-y-[55%] hover:bg-[#43c7f4] hover:shadow-[0_18px_45px_rgba(67,199,244,0.30)] sm:left-5 sm:size-12"
          >
            <ChevronLeft size={22} />
          </button>

          <div
            ref={sliderRef}
            className="relative z-10 flex snap-x gap-4 overflow-x-auto scroll-smooth py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:gap-8"
          >
            {activeLogos.map((logo) => (
              <div
                key={logo.id}
                className="group flex h-[118px] min-w-[150px] snap-start items-center justify-center rounded-[20px] border border-[#e7eef8] bg-white px-4 shadow-[0_16px_40px_rgba(15,23,42,0.06)] transition-all duration-500 hover:-translate-y-1 hover:border-[#43c7f4]/35 hover:shadow-[0_26px_65px_rgba(6,47,102,0.14)] sm:h-[150px] sm:min-w-[195px] sm:rounded-[26px] sm:px-6"
              >
                <div className="relative h-[82px] w-full transition-transform duration-500 group-hover:scale-105 sm:h-[105px]">
                  <img
                    src={logo.image}
                    alt={logo.name}
                    className="h-full w-full object-contain"
                  />
                </div>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={scrollNext}
            aria-label="Next corporate logo"
            className="absolute right-3 top-1/2 z-20 grid size-10 -translate-y-1/2 place-items-center rounded-full bg-[#062f66] text-white shadow-[0_14px_35px_rgba(6,47,102,0.26)] transition-all duration-300 hover:-translate-y-[55%] hover:bg-[#43c7f4] hover:shadow-[0_18px_45px_rgba(67,199,244,0.30)] sm:right-5 sm:size-12"
          >
            <ChevronRight size={22} />
          </button>
        </div>
      </div>
    </section>
  );
}
