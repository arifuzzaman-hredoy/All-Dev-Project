"use client";

// File: clinic-website/src/components/home/HeroSlider.tsx

import Image from "next/image";
import Link from "next/link";
import type { CSSProperties } from "react";
import { useEffect, useState } from "react";
import {
  Activity,
  CalendarCheck,
  ChevronLeft,
  ChevronRight,
  FileText,
  Headset,
  Stethoscope,
  Users,
  type LucideIcon,
} from "lucide-react";
import {
  defaultHomeHeroContent,
  normalizeHomeHeroContent,
} from "@/features/home-hero/defaults";
import type {
  HomeHeroContent,
  HomeHeroIconKey,
} from "@/features/home-hero/types";

const iconMap: Record<HomeHeroIconKey, LucideIcon> = {
  Stethoscope,
  CalendarCheck,
  FileText,
  Headphones: Headset,
  Users,
  Activity,
};

type HeroSliderProps = {
  content?: HomeHeroContent;
};

export default function HeroSlider({ content }: HeroSliderProps) {
  const homeHero = normalizeHomeHeroContent(content ?? defaultHomeHeroContent);

  const sliderImages = homeHero.slides
    .filter((slide) => slide.isActive)
    .sort((a, b) => a.sortOrder - b.sortOrder);

  const sliderActions = homeHero.quickActions
    .filter((action) => action.isActive)
    .sort((a, b) => a.sortOrder - b.sortOrder);

  const [activeIndex, setActiveIndex] = useState(0);

  function goToPrevious() {
    setActiveIndex((current) =>
      current === 0 ? sliderImages.length - 1 : current - 1,
    );
  }

  function goToNext() {
    setActiveIndex((current) =>
      current === sliderImages.length - 1 ? 0 : current + 1,
    );
  }

  useEffect(() => {
    if (activeIndex <= sliderImages.length - 1) return;
    setActiveIndex(0);
  }, [activeIndex, sliderImages.length]);

  useEffect(() => {
    if (!homeHero.carousel.autoplay || sliderImages.length <= 1) return;

    const timer = window.setInterval(() => {
      setActiveIndex((current) =>
        current === sliderImages.length - 1 ? 0 : current + 1,
      );
    }, homeHero.carousel.intervalMs);

    return () => window.clearInterval(timer);
  }, [
    homeHero.carousel.autoplay,
    homeHero.carousel.intervalMs,
    sliderImages.length,
  ]);

  return (
    <section
      className="relative isolate overflow-hidden bg-[linear-gradient(180deg,#ffffff_0%,#f7fcff_58%,#ffffff_100%)]"
      style={
        {
          "--hero-desktop-height": `${homeHero.carousel.desktopHeight}px`,
          "--hero-mobile-height": `${homeHero.carousel.mobileHeight}px`,
        } as CSSProperties
      }
    >
      <style>{`
        @keyframes heroSoftFloat {
          0%, 100% {
            transform: translate3d(0, 0, 0);
          }
          50% {
            transform: translate3d(0, -10px, 0);
          }
        }

        @keyframes heroCardIn {
          from {
            opacity: 0;
            transform: translateY(18px) scale(0.985);
            filter: blur(6px);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
            filter: blur(0);
          }
        }

        @keyframes heroDotPulse {
          0%, 100% {
            box-shadow: 0 0 0 0 rgba(255,255,255,0.55);
          }
          50% {
            box-shadow: 0 0 0 7px rgba(255,255,255,0);
          }
        }

        .hero-soft-float {
          animation: heroSoftFloat 6s ease-in-out infinite;
        }

        .hero-card-in {
          animation: heroCardIn 520ms cubic-bezier(0.16, 1, 0.3, 1) both;
        }

        .hero-active-dot {
          animation: heroDotPulse 1.8s ease-in-out infinite;
        }
        @keyframes heroColorRail {
          0% {
            background-position: 0% 50%;
          }
          100% {
            background-position: 220% 50%;
          }
        }

        @keyframes heroShineSweep {
          0% {
            transform: translateX(-140%) skewX(-18deg);
            opacity: 0;
          }
          18% {
            opacity: 1;
          }
          52% {
            opacity: 0.9;
          }
          100% {
            transform: translateX(360%) skewX(-18deg);
            opacity: 0;
          }
        }

        @keyframes heroGlowPulse {
          0%, 100% {
            opacity: 0.55;
            filter: blur(10px);
          }
          50% {
            opacity: 1;
            filter: blur(14px);
          }
        }

        .hero-color-rail {
          background-size: 220% 100%;
          animation: heroColorRail 5.5s linear infinite;
        }

        .hero-shine-sweep {
          animation: heroShineSweep 3.2s cubic-bezier(0.16, 1, 0.3, 1) infinite;
        }

        .hero-glow-pulse {
          animation: heroGlowPulse 2.8s ease-in-out infinite;
        }
        
        @media (prefers-reduced-motion: reduce) {
          .hero-soft-float,
          .hero-card-in,
                    .hero-color-rail,
          .hero-shine-sweep,
          .hero-glow-pulse,
          .hero-active-dot {
            animation: none !important;
          }
        }
      `}</style>

      <div className="pointer-events-none absolute left-1/2 top-[230px] -z-10 h-[220px] w-[92%] -translate-x-1/2 rounded-full bg-cyan-300/16 blur-[90px] sm:top-[315px] sm:h-[260px] sm:w-[78%]" />
      <div className="pointer-events-none absolute -left-24 top-24 -z-10 h-72 w-72 rounded-full bg-[#062f66]/10 blur-3xl hero-soft-float" />
      <div className="pointer-events-none absolute -right-24 top-44 -z-10 h-80 w-80 rounded-full bg-cyan-300/20 blur-3xl hero-soft-float" />

      {/* Slider Image Area */}
      <div className="relative h-[var(--hero-mobile-height)] overflow-hidden bg-[#062f66] shadow-[0_28px_80px_rgba(6,47,102,0.18)] lg:h-[var(--hero-desktop-height)]">
        <div className="pointer-events-none absolute inset-x-0 top-0 z-20 h-px bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.65),transparent)]" />

        <div
          className="flex h-full transition-transform duration-[1500ms] ease-[cubic-bezier(0.16,1,0.3,1)] will-change-transform"
          style={{
            transform: `translateX(-${activeIndex * 100}%)`,
          }}
        >
          {sliderImages.map((image, index) => (
            <div
              key={image.id}
              className="relative h-full w-full shrink-0 overflow-hidden"
            >
              <Image
                src={image.imageUrl}
                alt={image.imageAlt}
                fill
                priority={index === 0}
                sizes="100vw"
                className={[
                  "object-cover transition-transform duration-[5200ms] ease-out will-change-transform",
                  index === activeIndex ? "scale-100" : "scale-[1.065]",
                ].join(" ")}
              />

              {image.mobileImageUrl ? (
                <Image
                  src={image.mobileImageUrl}
                  alt={image.imageAlt}
                  fill
                  priority={index === 0}
                  sizes="100vw"
                  className={[
                    "object-cover transition-transform duration-[5200ms] ease-out will-change-transform sm:hidden",
                    index === activeIndex ? "scale-100" : "scale-[1.065]",
                  ].join(" ")}
                />
              ) : null}

              <div
                className="pointer-events-none absolute inset-0 bg-[#062f66]"
                style={{ opacity: homeHero.carousel.overlayOpacity / 100 }}
              />

              <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(90deg,rgba(2,11,31,0.44)_0%,rgba(6,47,102,0.18)_34%,rgba(6,47,102,0.03)_58%,rgba(2,11,31,0.22)_100%)]" />
              <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_28%,rgba(125,211,252,0.16),transparent_34%)]" />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-52 bg-gradient-to-t from-[#02142f]/58 via-[#062f66]/18 to-transparent" />
              <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/18 to-transparent" />
            </div>
          ))}
        </div>

        {/* Left Arrow */}
        {homeHero.carousel.showArrows && sliderImages.length > 1 ? (
          <button
            type="button"
            onClick={goToPrevious}
            aria-label="Previous slide"
            className="group absolute left-3 top-1/2 z-30 grid size-10 -translate-y-1/2 place-items-center rounded-full border border-white/65 bg-white/90 text-[#062f66] shadow-[0_18px_42px_rgba(2,11,31,0.24)] backdrop-blur-xl transition-all duration-300 hover:-translate-x-1 hover:scale-105 hover:border-white hover:bg-[#062f66] hover:text-white hover:shadow-[0_24px_55px_rgba(6,47,102,0.36)] active:scale-95 sm:left-6 sm:size-12"
          >
            <ChevronLeft
              size={24}
              className="transition-transform duration-300 group-hover:-translate-x-0.5"
            />
          </button>
        ) : null}

        {/* Right Arrow */}
        {homeHero.carousel.showArrows && sliderImages.length > 1 ? (
          <button
            type="button"
            onClick={goToNext}
            aria-label="Next slide"
            className="group absolute right-3 top-1/2 z-30 grid size-10 -translate-y-1/2 place-items-center rounded-full border border-white/65 bg-white/90 text-[#062f66] shadow-[0_18px_42px_rgba(2,11,31,0.24)] backdrop-blur-xl transition-all duration-300 hover:translate-x-1 hover:scale-105 hover:border-white hover:bg-[#062f66] hover:text-white hover:shadow-[0_24px_55px_rgba(6,47,102,0.36)] active:scale-95 sm:right-6 sm:size-12"
          >
            <ChevronRight
              size={24}
              className="transition-transform duration-300 group-hover:translate-x-0.5"
            />
          </button>
        ) : null}

        {/* Slider Dots */}
        {homeHero.carousel.showDots && sliderImages.length > 1 ? (
          <div className="absolute bottom-4 left-1/2 z-30 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/25 bg-[#020b1f]/18 px-3 py-2 shadow-[0_14px_34px_rgba(0,0,0,0.18)] backdrop-blur-xl sm:bottom-6">
            {sliderImages.map((image, index) => (
              <button
                key={image.id}
                type="button"
                aria-label={`Go to slide ${index + 1}`}
                onClick={() => setActiveIndex(index)}
                className={[
                  "h-2.5 rounded-full transition-all duration-500 active:scale-90",
                  index === activeIndex
                    ? "hero-active-dot w-9 bg-white shadow-[0_0_18px_rgba(255,255,255,0.75)]"
                    : "w-2.5 bg-white/55 hover:w-5 hover:bg-white/90",
                ].join(" ")}
              />
            ))}
          </div>
        ) : null}
      </div>

      {/* Action Cards */}
      <div className="relative z-40 mx-auto -mt-8 grid w-[calc(100%-24px)] max-w-[1500px] gap-3 sm:-mt-14 sm:w-[calc(100%-32px)] sm:grid-cols-2 lg:-mt-20 lg:grid-cols-3 xl:grid-cols-5">
        <div className="pointer-events-none absolute -inset-x-4 -bottom-8 top-8 -z-10 rounded-[36px] bg-[#062f66]/10 blur-3xl" />

        {sliderActions.map((action, index) => {
          const Icon = iconMap[action.icon];

          return (
            <Link
              key={action.id}
              href={action.href}
              className="hero-card-in group relative flex min-h-[82px] items-center justify-between gap-3 overflow-hidden rounded-[24px] border border-white/80 bg-white/92 px-4 py-4 text-[#062f66] shadow-[0_18px_42px_rgba(15,23,42,0.12)] ring-1 ring-slate-200/70 backdrop-blur-xl transition-all duration-500 before:absolute before:inset-0 before:bg-[radial-gradient(circle_at_85%_15%,rgba(34,211,238,0.22),transparent_38%)] before:opacity-0 before:transition-opacity before:duration-500 after:absolute after:inset-0 after:translate-x-[-120%] after:bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.64),transparent)] after:transition-transform after:duration-700 hover:-translate-y-1.5 hover:border-cyan-200 hover:bg-white hover:text-[#062f66] hover:shadow-[0_28px_65px_rgba(6,47,102,0.20)] hover:before:opacity-100 hover:after:translate-x-[120%] active:scale-[0.99] sm:min-h-[106px] sm:gap-5 sm:px-5 sm:py-6 xl:min-h-[108px]"
              style={{ animationDelay: `${index * 70}ms` }}
            >
              <span className="absolute bottom-0 left-0 h-1 w-full origin-left scale-x-0 bg-[linear-gradient(90deg,#062f66,#22c1dc,#8cc63f)] transition-transform duration-500 group-hover:scale-x-100" />

              <span className="relative z-10 min-w-0 max-w-[170px] text-sm font-black uppercase leading-5 tracking-[0.01em] text-[#062f66] transition-colors duration-300 sm:max-w-[220px] sm:text-[16px] xl:max-w-[180px] xl:text-[17px]">
                {action.label}
              </span>

              <span className="relative z-10 grid size-11 shrink-0 place-items-center rounded-2xl bg-[linear-gradient(135deg,#04264d_0%,#087ea4_60%,#18c7d9_100%)] text-white shadow-[0_16px_32px_rgba(6,47,102,0.25)] ring-1 ring-white/40 transition-all duration-500 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:rotate-3 group-hover:scale-110 group-hover:shadow-[0_22px_44px_rgba(8,145,178,0.34)] sm:size-14">
                <Icon
                  size={23}
                  strokeWidth={2}
                  className="transition-transform duration-500 group-hover:scale-110 sm:size-[27px]"
                />
              </span>
            </Link>
          );
        })}
      </div>

          {/* Bottom Premium Moving Line */}
      <div className="relative z-10 mt-4 h-3 overflow-hidden bg-[#04264d] shadow-[0_-14px_36px_rgba(6,47,102,0.10)]">
        <style>{`
          @keyframes heroPremiumRailMove {
            0% {
              background-position: 0% 50%;
            }
            100% {
              background-position: 240% 50%;
            }
          }

          @keyframes heroPremiumRailGlow {
            0%, 100% {
              opacity: 0.55;
            }
            50% {
              opacity: 0.9;
            }
          }

          .hero-premium-rail {
            background-size: 240% 100%;
            animation: heroPremiumRailMove 7s linear infinite;
          }

          .hero-premium-rail-glow {
            background-size: 240% 100%;
            animation:
              heroPremiumRailMove 7s linear infinite,
              heroPremiumRailGlow 3s ease-in-out infinite;
          }

          @media (prefers-reduced-motion: reduce) {
            .hero-premium-rail,
            .hero-premium-rail-glow {
              animation: none !important;
            }
          }
        `}</style>

        <div className="hero-premium-rail absolute inset-0 bg-[linear-gradient(90deg,#04264d_0%,#063b73_14%,#087ea4_28%,#22c1dc_42%,#8a6bb8_58%,#8cc63f_74%,#22c55e_88%,#04264d_100%)]" />

        <div className="hero-premium-rail-glow pointer-events-none absolute inset-x-0 top-1/2 h-7 -translate-y-1/2 bg-[linear-gradient(90deg,transparent_0%,rgba(34,193,220,0.36)_28%,rgba(138,107,184,0.30)_56%,rgba(34,197,94,0.34)_78%,transparent_100%)] blur-md" />

        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-white/45" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-black/10" />
      </div>
    </section>
  );
}