// File: clinic-website/src/components/home/QuickActions.tsx

import Link from "next/link";
import {
  CalendarCheck,
  ClipboardList,
  FileText,
  Stethoscope,
  Video,
  type LucideIcon,
} from "lucide-react";
import Container from "@/components/common/Container";
import { quickActions } from "@/data/site";

const icons: Record<string, LucideIcon> = {
  CalendarCheck,
  ClipboardList,
  FileText,
  Stethoscope,
  Video,
};

export default function QuickActions() {
  return (
    <section className="-mt-6 bg-white pb-10 sm:-mt-8 sm:pb-14 lg:pb-16">
      <Container>
        <div className="grid gap-3 rounded-2xl border border-slate-100 bg-white p-3 shadow-[0_18px_60px_rgba(15,23,42,0.10)] sm:grid-cols-2 sm:gap-4 sm:rounded-3xl sm:p-4 lg:grid-cols-5">
          {quickActions.map((action) => {
            const Icon = icons[action.icon] ?? Stethoscope;

            return (
              <Link
                key={action.title}
                href={action.href}
                className="rounded-2xl p-4 transition hover:bg-slate-50 sm:p-5"
              >
                <div className="mb-4 flex size-11 items-center justify-center rounded-xl bg-cyan-50 text-teal-600">
                  <Icon size={23} />
                </div>
                <h2 className="font-black text-[#0b2f5b]">{action.title}</h2>
                <p className="mt-2 text-sm leading-6 text-slate-600">
                  {action.description}
                </p>
              </Link>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
