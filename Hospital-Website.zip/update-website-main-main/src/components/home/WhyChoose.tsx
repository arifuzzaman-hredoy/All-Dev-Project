// File: clinic-website/src/components/home/WhyChoose.tsx

import { CheckCircle2 } from "lucide-react";
import Container from "@/components/common/Container";
import SectionTitle from "@/components/common/SectionTitle";
import { whyChoose } from "@/data/site";

export default function WhyChoose() {
  return (
    <section className="relative overflow-hidden bg-[#f7fbff] py-10 sm:py-14 lg:py-20">
      {/* Soft Color Grading Background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f3f9ff_42%,#f8f3ff_100%)]" />

        <div className="absolute left-[-170px] top-[-130px] h-[360px] w-[360px] rounded-full bg-[#43c7f4]/14 blur-[95px]" />
        <div className="absolute right-[-180px] bottom-[-140px] h-[390px] w-[390px] rounded-full bg-[#8a6bb8]/14 blur-[100px]" />
        <div className="absolute left-[38%] top-[45%] h-[260px] w-[260px] rounded-full bg-[#8cc63f]/8 blur-[90px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,47,102,0.05)_1px,transparent_0)] [background-size:28px_28px]" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062f66]/12 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/20 to-transparent" />
      </div>

      <Container>
        <div className="relative z-10 grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <div className="rounded-[24px] border border-white/70 bg-white/60 p-5 shadow-[0_18px_55px_rgba(6,47,102,0.08)] backdrop-blur-xl sm:rounded-[30px] sm:p-8">
            <SectionTitle
              eyebrow="Why Choose Us"
              title="Premium healthcare, organized for comfort and confidence."
              description="Patients and families get clear guidance, thoughtful facilities, and coordinated clinical services in one place."
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {whyChoose.map((item, index) => (
              <div
                key={item}
                className="group relative overflow-hidden rounded-[20px] border border-[#e3edf8] bg-white p-5 shadow-[0_14px_40px_rgba(6,47,102,0.07)] transition-all duration-300 hover:-translate-y-1 hover:border-[#43c7f4]/40 hover:shadow-[0_24px_60px_rgba(6,47,102,0.12)] sm:rounded-[24px] sm:p-6"
              >
                <div className="pointer-events-none absolute right-[-55px] top-[-55px] h-[130px] w-[130px] rounded-full bg-[#43c7f4]/8 blur-[35px] transition-all duration-300 group-hover:bg-[#8a6bb8]/12" />

                <div className="relative z-10 flex items-start gap-4">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#eef8ff] text-[#43c7f4] shadow-[0_10px_25px_rgba(67,199,244,0.12)] transition-all duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#062f66] group-hover:text-white group-hover:shadow-[0_16px_35px_rgba(6,47,102,0.22)]">
                    <CheckCircle2
                      size={24}
                      className="transition-transform duration-300 group-hover:-rotate-6"
                    />
                  </span>

                  <div>
                    <span className="mb-2 block text-xs font-black uppercase tracking-[0.16em] text-[#8a6bb8]">
                      {String(index + 1).padStart(2, "0")}
                    </span>

                    <p className="font-semibold leading-7 text-[#4d6380] transition-colors duration-300 group-hover:text-[#062f66]">
                      {item}
                    </p>
                  </div>
                </div>

                <div className="pointer-events-none absolute inset-x-6 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/45 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
