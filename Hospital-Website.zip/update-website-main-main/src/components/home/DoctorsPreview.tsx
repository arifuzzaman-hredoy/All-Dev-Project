// File: clinic-website/src/components/home/DoctorsPreview.tsx

import { connection } from "next/server";
import Link from "next/link";
import Container from "@/components/common/Container";
import SectionTitle from "@/components/common/SectionTitle";
import PublicDoctorCard from "@/components/doctors/PublicDoctorCard";
import { getActiveDoctors } from "@/lib/doctors";

export default async function DoctorsPreview() {
  await connection();

  const doctors = (await getActiveDoctors()).slice(0, 4);

  return (
    <section className="bg-white py-10 sm:py-14 lg:py-20">
      <Container>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionTitle
            eyebrow="Doctors"
            title="Experienced consultants across key departments."
            description="Book with active specialists and view current schedules from the doctor directory."
          />

          <Link
            href="/doctors"
            className="inline-flex min-h-11 w-full items-center justify-center rounded-full border border-[#062f66]/15 bg-white px-6 py-3 text-sm font-black text-[#062f66] shadow-[0_12px_28px_rgba(6,47,102,0.08)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#062f66] hover:text-white sm:w-auto sm:text-base"
          >
            Meet all doctors
          </Link>
        </div>

        <div className="mt-6 grid gap-4 sm:mt-10 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4 lg:gap-6">
          {doctors.map((doctor) => (
            <PublicDoctorCard key={doctor.id} doctor={doctor} />
          ))}
        </div>
      </Container>
    </section>
  );
}
