// File: clinic-website/src/components/home/Hero.tsx

"use client";

import Image from "next/image";
import Link from "next/link";
import { useMemo, useState } from "react";
import {
  Activity,
  Ambulance,
  Apple,
  ArrowLeft,
  ArrowRight,
  Baby,
  Bone,
  Brain,
  ClipboardPlus,
  Cross,
  Ear,
  Eye,
  FlaskConical,
  HandHeart,
  Headphones,
  Heart,
  HeartPulse,
  Hospital,
  Microscope,
  Pill,
  Ribbon,
  Scissors,
  ShieldPlus,
  ShieldCheck,
  Smile,
  Stethoscope,
  Syringe,
  UserRoundCheck,
  Users,
  UsersRound,
  type LucideIcon,
} from "lucide-react";
import Container from "@/components/common/Container";
import type {
  WhyChooseIconName,
  WhyChooseSection,
  WhyChooseSpeciality,
} from "@/types/home-why-choose";

type SpecialityItem = {
  title: string;
  href: string;
  icon: LucideIcon;
};

type HeroProps = {
  whyChooseSection: WhyChooseSection;
};

const iconMap = {
  Activity,
  Ambulance,
  Apple,
  Baby,
  Bone,
  Brain,
  ClipboardPlus,
  Cross,
  Ear,
  Eye,
  FlaskConical,
  Headphones,
  Heart,
  HeartPulse,
  Hospital,
  Microscope,
  Pill,
  Ribbon,
  ShieldCheck,
  Smile,
  Stethoscope,
  Syringe,
  UserRoundCheck,
  Users,
} satisfies Record<WhyChooseIconName, LucideIcon>;

const specialities: SpecialityItem[] = [
  {
    title: "Accident & Emergency",
    href: "/specialities?name=Accident%20%26%20Emergency",
    icon: Ambulance,
  },
  {
    title: "Anesthesia and Pain Medicine",
    href: "/specialities?name=Anesthesia%20and%20Pain%20Medicine",
    icon: Syringe,
  },
  {
    title: "Cancer Care Centre",
    href: "/specialities?name=Cancer%20Care%20Centre",
    icon: Ribbon,
  },
  {
    title: "Cardiology Care Centre",
    href: "/specialities?name=Cardiology%20Care%20Centre",
    icon: HeartPulse,
  },
  {
    title: "Cardiothoracic & Vascular Surgery",
    href: "/specialities?name=Cardiothoracic%20%26%20Vascular%20Surgery",
    icon: HeartPulse,
  },
  {
    title: "Cardiothoracic Anaesthesia",
    href: "/specialities?name=Cardiothoracic%20Anaesthesia",
    icon: Stethoscope,
  },
  {
    title: "Child Development Centre",
    href: "/specialities?name=Child%20Development%20Centre",
    icon: Baby,
  },
  {
    title: "Counselling Centre",
    href: "/specialities?name=Counselling%20Centre",
    icon: UsersRound,
  },
  {
    title: "Critical Care Units",
    href: "/specialities?name=Critical%20Care%20Units",
    icon: Hospital,
  },
  {
    title: "Dental & Maxillofacial Surgery",
    href: "/specialities?name=Dental%20%26%20Maxillofacial%20Surgery",
    icon: Smile,
  },
  {
    title: "Dermatology & Venereology",
    href: "/specialities?name=Dermatology%20%26%20Venereology",
    icon: UserRoundCheck,
  },
  {
    title: "Diabetology & Endocrinology",
    href: "/specialities?name=Diabetology%20%26%20Endocrinology",
    icon: FlaskConical,
  },
  {
    title: "Diagnostic & Interventional Radiology",
    href: "/specialities?name=Diagnostic%20%26%20Interventional%20Radiology",
    icon: Microscope,
  },
  {
    title: "Dietetics & Nutrition",
    href: "/specialities?name=Dietetics%20%26%20Nutrition",
    icon: Apple,
  },
  {
    title: "ENT & Head Neck Surgery",
    href: "/specialities?name=ENT%20%26%20Head%20Neck%20Surgery",
    icon: Headphones,
  },
  {
    title: "Fertility Centre",
    href: "/specialities?name=Fertility%20Centre",
    icon: HandHeart,
  },
  {
    title: "Gastroenterology & Hepatology",
    href: "/specialities?name=Gastroenterology%20%26%20Hepatology",
    icon: Activity,
  },
  {
    title: "General & Laparoscopic Surgery",
    href: "/specialities?name=General%20%26%20Laparoscopic%20Surgery",
    icon: Scissors,
  },
  {
    title: "Hematology & Stem Cell Transplant",
    href: "/specialities?name=Hematology%20%26%20Stem%20Cell%20Transplant",
    icon: FlaskConical,
  },
  {
    title: "Hepatobiliary, Pancreatic and Liver Transplant",
    href: "/specialities?name=Hepatobiliary%2C%20Pancreatic%20and%20Liver%20Transplant",
    icon: Activity,
  },
  {
    title: "Internal Medicine",
    href: "/specialities?name=Internal%20Medicine",
    icon: Pill,
  },
  {
    title: "Joint Care & Wellness Centre",
    href: "/specialities?name=Joint%20Care%20%26%20Wellness%20Centre",
    icon: Bone,
  },
  {
    title: "Kidney Transplant Program",
    href: "/specialities?name=Kidney%20Transplant%20Program",
    icon: ShieldPlus,
  },
  {
    title: "Lab Medicine",
    href: "/specialities?name=Lab%20Medicine",
    icon: Microscope,
  },
  {
    title: "Lithotripsy",
    href: "/specialities?name=Lithotripsy",
    icon: ShieldPlus,
  },
  {
    title: "Neonatology",
    href: "/specialities?name=Neonatology",
    icon: Baby,
  },
  {
    title: "Nephrology",
    href: "/specialities?name=Nephrology",
    icon: ShieldPlus,
  },
  {
    title: "Neurology",
    href: "/specialities?name=Neurology",
    icon: Brain,
  },
  {
    title: "Neurosurgery",
    href: "/specialities?name=Neurosurgery",
    icon: Brain,
  },
  {
    title: "Nuclear Medicine",
    href: "/specialities?name=Nuclear%20Medicine",
    icon: Activity,
  },
  {
    title: "Obstetrics and Gynaecology",
    href: "/specialities?name=Obstetrics%20and%20Gynaecology",
    icon: Stethoscope,
  },
  {
    title: "Ophthalmology",
    href: "/specialities?name=Ophthalmology",
    icon: Eye,
  },
  {
    title: "Orthopaedics",
    href: "/specialities?name=Orthopaedics",
    icon: Bone,
  },
  {
    title: "Paediatric Cardiology",
    href: "/specialities?name=Paediatric%20Cardiology",
    icon: HeartPulse,
  },
  {
    title: "Paediatric Surgery & Paediatric Urology",
    href: "/specialities?name=Paediatric%20Surgery%20%26%20Paediatric%20Urology",
    icon: Baby,
  },
  {
    title: "Paediatrics",
    href: "/specialities?name=Paediatrics",
    icon: Baby,
  },
  {
    title: "Physical Medicine & Rehabilitation",
    href: "/specialities?name=Physical%20Medicine%20%26%20Rehabilitation",
    icon: Activity,
  },
  {
    title: "Plastic, Reconstructive & Cosmetic Surgery",
    href: "/specialities?name=Plastic%2C%20Reconstructive%20%26%20Cosmetic%20Surgery",
    icon: UserRoundCheck,
  },
  {
    title: "Psychiatry",
    href: "/specialities?name=Psychiatry",
    icon: Brain,
  },
  {
    title: "Respiratory Medicine",
    href: "/specialities?name=Respiratory%20Medicine",
    icon: Activity,
  },
  {
    title: "Rheumatology",
    href: "/specialities?name=Rheumatology",
    icon: Bone,
  },
  {
    title: "Thoracic Surgery",
    href: "/specialities?name=Thoracic%20Surgery",
    icon: Stethoscope,
  },
  {
    title: "Transfusion Medicine",
    href: "/specialities?name=Transfusion%20Medicine",
    icon: FlaskConical,
  },
  {
    title: "Urology",
    href: "/specialities?name=Urology",
    icon: ShieldPlus,
  },
];

const ITEMS_PER_PAGE = 15;

function sectionSpecialitiesToItems(
  specialities: WhyChooseSpeciality[],
): SpecialityItem[] {
  return specialities
    .filter((item) => item.isActive)
    .sort((left, right) => left.sortOrder - right.sortOrder)
    .map((item) => ({
      title: item.title,
      href: `/specialities?name=${encodeURIComponent(item.title)}`,
      icon: iconMap[item.iconName] || HeartPulse,
    }));
}

function SpecialityCard({ item }: { item: SpecialityItem }) {
  const Icon = item.icon;

  return (
    <Link
      href={item.href}
      className="group relative flex h-[126px] min-w-[170px] snap-start flex-col items-center justify-center overflow-hidden rounded-xl border border-[#dfe8f3] bg-white/90 px-4 text-center text-[#062f66] shadow-[0_10px_24px_rgba(6,47,102,0.055)] transition-all duration-300 hover:-translate-y-1 hover:border-[#062f66] hover:bg-[#062f66] hover:text-white hover:shadow-[0_18px_38px_rgba(6,47,102,0.18)] md:min-w-0"
    >
      <span className="pointer-events-none absolute inset-x-6 top-0 h-px bg-white opacity-0 transition-opacity duration-300 group-hover:opacity-50" />

      <Icon
        size={34}
        strokeWidth={1.8}
        className="mb-4 text-[#062f66] transition-all duration-300 ease-out group-hover:-translate-y-1 group-hover:scale-110 group-hover:rotate-3 group-hover:text-white"
      />

      <span className="text-[13px] font-semibold leading-[18px] tracking-[0.01em] text-[#061b3d] transition-colors duration-300 group-hover:text-white">
        {item.title}
      </span>
    </Link>
  );
}

export default function Hero({ whyChooseSection }: HeroProps) {
  const [pageIndex, setPageIndex] = useState(0);
  const [slideDirection, setSlideDirection] = useState<"next" | "previous">(
    "next",
  );
  const sectionSpecialities = useMemo(
    () => sectionSpecialitiesToItems(whyChooseSection.specialities),
    [whyChooseSection.specialities],
  );
  const displaySpecialities =
    sectionSpecialities.length > 0 ? sectionSpecialities : specialities;

  const totalPages = Math.max(
    1,
    Math.ceil(displaySpecialities.length / ITEMS_PER_PAGE),
  );

  const visibleSpecialities = useMemo(() => {
    const start = pageIndex * ITEMS_PER_PAGE;
    return displaySpecialities.slice(start, start + ITEMS_PER_PAGE);
  }, [displaySpecialities, pageIndex]);

  function handlePrevious() {
    setSlideDirection("previous");

    setPageIndex((current) => {
      if (current === 0) return totalPages - 1;
      return current - 1;
    });
  }

  function handleNext() {
    setSlideDirection("next");

    setPageIndex((current) => {
      if (current === totalPages - 1) return 0;
      return current + 1;
    });
  }

  return (
    <section className="relative overflow-hidden bg-[#f8fbff] py-12 sm:py-16 lg:py-24">
      <style jsx global>{`
        @keyframes specialitiesSlideNext {
          0% {
            opacity: 0;
            transform: translateX(34px) scale(0.985);
          }

          100% {
            opacity: 1;
            transform: translateX(0) scale(1);
          }
        }

        @keyframes specialitiesSlidePrevious {
          0% {
            opacity: 0;
            transform: translateX(-34px) scale(0.985);
          }

          100% {
            opacity: 1;
            transform: translateX(0) scale(1);
          }
        }

        @keyframes softImageReveal {
          0% {
            opacity: 0;
            transform: translateY(14px) scale(1.02);
          }

          100% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
      `}</style>

      {/* Premium Soft Background Only */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_42%,#f8f3ff_100%)]" />

        <div className="absolute left-[-180px] top-[-140px] h-[380px] w-[380px] rounded-full bg-[#43c7f4]/14 blur-[100px]" />
        <div className="absolute right-[-190px] top-[30%] h-[410px] w-[410px] rounded-full bg-[#8a6bb8]/12 blur-[110px]" />
        <div className="absolute bottom-[-170px] left-1/2 h-[360px] w-[360px] -translate-x-1/2 rounded-full bg-[#8cc63f]/8 blur-[105px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,47,102,0.055)_1px,transparent_0)] [background-size:30px_30px]" />

        <div className="absolute left-[-10%] top-[18%] h-[180px] w-[120%] rotate-[-4deg] bg-gradient-to-r from-transparent via-white/60 to-transparent blur-2xl" />
        <div className="absolute bottom-[12%] right-[-8%] h-[160px] w-[80%] rotate-[5deg] bg-gradient-to-r from-transparent via-[#43c7f4]/10 to-transparent blur-2xl" />

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#062f66]/12 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#43c7f4]/20 to-transparent" />
      </div>

      <Container className="px-4 sm:px-6 lg:px-8">
        {/* Top Heading */}
        <div className="relative z-10 mx-auto max-w-5xl text-center">
          <h1 className="text-2xl font-black tracking-[0.05em] text-[#062f66] sm:text-4xl sm:tracking-[0.08em] lg:text-[38px]">
            {whyChooseSection.title}
          </h1>

          <p className="mx-auto mt-6 max-w-5xl text-sm font-medium leading-7 tracking-[0.02em] text-[#062f66] sm:mt-8 sm:text-base sm:leading-[30px] sm:tracking-[0.03em]">
            {whyChooseSection.description}
          </p>
        </div>

        {/* Main Content */}
        <div className="relative z-10 mt-10 grid items-start gap-6 sm:mt-12 lg:mt-14 lg:grid-cols-[0.95fr_1.85fr] lg:gap-7">
          {/* Left Image */}
          <div className="group relative h-[310px] overflow-hidden rounded-xl bg-slate-100 shadow-[0_20px_50px_rgba(6,47,102,0.12)] ring-1 ring-slate-200/70 sm:h-[390px] lg:h-[520px]">
            <Image
              src={whyChooseSection.imageUrl || "/pasent.jpeg"}
              alt="Doctor consulting patient"
              fill
              priority
              loading="eager"
              sizes="(max-width: 1024px) 100vw, 38vw"
              className="object-cover transition-transform duration-[1400ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.035]"
              style={{
                animation:
                  "softImageReveal 750ms cubic-bezier(0.22, 1, 0.36, 1)",
              }}
            />

            <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(6,47,102,0.02),rgba(6,47,102,0.14))]" />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#062f66]/15 to-transparent" />
          </div>

          {/* Right Specialities */}
          <div className="min-w-0">
            <h2 className="mb-5 text-2xl font-black tracking-[0.05em] text-[#062f66] sm:mb-7 sm:text-4xl sm:tracking-[0.07em]">
              Our Specialities
            </h2>

            {/* Desktop / Tablet Grid */}
            <div
              key={`desktop-${pageIndex}`}
              className={[
                "hidden min-h-[410px] grid-cols-2 gap-4 md:grid lg:min-h-[694px] lg:grid-cols-3 xl:min-h-[410px] xl:grid-cols-5",
                slideDirection === "next"
                  ? "animate-[specialitiesSlideNext_650ms_cubic-bezier(0.22,1,0.36,1)]"
                  : "animate-[specialitiesSlidePrevious_650ms_cubic-bezier(0.22,1,0.36,1)]",
              ].join(" ")}
            >
              {visibleSpecialities.map((item) => (
                <SpecialityCard key={item.title} item={item} />
              ))}
            </div>

            {/* Mobile Horizontal Scroll */}
            <div
              key={`mobile-${pageIndex}`}
              className={[
                "-mx-4 flex snap-x gap-4 overflow-x-auto scroll-smooth px-4 pb-5 md:hidden [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
                slideDirection === "next"
                  ? "animate-[specialitiesSlideNext_650ms_cubic-bezier(0.22,1,0.36,1)]"
                  : "animate-[specialitiesSlidePrevious_650ms_cubic-bezier(0.22,1,0.36,1)]",
              ].join(" ")}
            >
              {visibleSpecialities.map((item) => (
                <SpecialityCard key={item.title} item={item} />
              ))}
            </div>

            {/* Bottom Controls */}
            <div className="mt-6 flex flex-col gap-4 sm:mt-8 sm:flex-row sm:items-center sm:justify-between sm:gap-5">
              <div className="flex items-center justify-center gap-4 sm:justify-start">
                <button
                  type="button"
                  onClick={handlePrevious}
                  aria-label="Previous specialities"
                  className="group grid size-10 place-items-center rounded-full border border-[#8cc63f] bg-white text-[#8cc63f] shadow-[0_10px_22px_rgba(140,198,63,0.14)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#8cc63f] hover:text-white hover:shadow-[0_16px_30px_rgba(140,198,63,0.24)]"
                >
                  <ArrowLeft
                    size={20}
                    className="transition-transform duration-300 group-hover:-translate-x-1"
                  />
                </button>

                <button
                  type="button"
                  onClick={handleNext}
                  aria-label="Next specialities"
                  className="group grid size-10 place-items-center rounded-full border border-[#8cc63f] bg-white text-[#8cc63f] shadow-[0_10px_22px_rgba(140,198,63,0.14)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#8cc63f] hover:text-white hover:shadow-[0_16px_30px_rgba(140,198,63,0.24)]"
                >
                  <ArrowRight
                    size={20}
                    className="transition-transform duration-300 group-hover:translate-x-1"
                  />
                </button>
              </div>

              <Link
                href="/specialities"
                className="group inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#8a6bb8] px-8 py-4 text-sm font-black text-white shadow-[0_14px_28px_rgba(138,107,184,0.18)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#062f66] hover:shadow-[0_18px_35px_rgba(6,47,102,0.22)] sm:w-auto"
              >
                <span>View All Specialities</span>

                <ArrowRight
                  size={18}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </Link>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
