"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Container from "@/components/common/Container";
import SectionTitle from "@/components/common/SectionTitle";
import { getFeaturedSpecialties, SpecialtyItem } from "@/lib/specialties";
import { getSpecialtyIcon } from "@/lib/specialtyIcons";

export default function SpecialitiesPreview() {
  const [items, setItems] = useState<SpecialtyItem[]>([]);

  useEffect(() => {
    function loadItems() {
      const featured = getFeaturedSpecialties();
      setItems(featured.length ? featured.slice(0, 6) : []);
    }

    loadItems();
    window.addEventListener("specialties-updated", loadItems);
    window.addEventListener("storage", loadItems);

    return () => {
      window.removeEventListener("specialties-updated", loadItems);
      window.removeEventListener("storage", loadItems);
    };
  }, []);

  if (!items.length) return null;

  return (
    <section className="relative isolate overflow-hidden bg-[linear-gradient(180deg,#f8fcff_0%,#eef9ff_42%,#ffffff_100%)] py-12 sm:py-16 lg:py-24">
      <style>{`
        @keyframes specialitiesFloatIcon {
          0%, 100% { transform: translate3d(0, 0, 0) rotate(0deg); }
          50% { transform: translate3d(0, -5px, 0) rotate(2deg); }
        }

        @keyframes specialitiesGridMove {
          0% { background-position: 0 0, 0 0; }
          100% { background-position: 56px 56px, 56px 56px; }
        }

        .specialities-grid-bg {
          background-image:
            linear-gradient(rgba(6,47,102,0.055) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6,47,102,0.055) 1px, transparent 1px);
          background-size: 56px 56px;
          animation: specialitiesGridMove 18s linear infinite;
        }

        .specialities-icon-float {
          animation: specialitiesFloatIcon 4.2s ease-in-out infinite;
        }

        @media (prefers-reduced-motion: reduce) {
          .specialities-grid-bg,
          .specialities-icon-float {
            animation: none !important;
          }
        }
      `}</style>

      <div className="specialities-grid-bg pointer-events-none absolute inset-0 -z-10 opacity-80" />
      <div className="pointer-events-none absolute left-0 top-0 -z-10 h-32 w-full bg-gradient-to-b from-white/80 to-transparent" />
      <div className="pointer-events-none absolute bottom-0 left-0 -z-10 h-32 w-full bg-gradient-to-t from-white to-transparent" />

      <Container>
        <div className="relative overflow-hidden border border-slate-200/80 bg-white/82 px-4 py-7 shadow-[0_26px_70px_rgba(6,47,102,0.10)] ring-1 ring-white/80 backdrop-blur-xl sm:px-6 sm:py-9 lg:px-8 lg:py-11">
          <div className="relative z-10 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-3xl">
              <SectionTitle
                eyebrow="Departments"
                title="Specialities for everyday and advanced care."
                description="Explore major clinical services designed for fast access and reliable treatment planning."
              />
            </div>

            <Link
              href="/specialities"
              className="inline-flex min-h-12 w-full items-center justify-center border border-[#062f66]/10 bg-[#062f66] px-6 py-3 text-sm font-black text-white shadow-[0_16px_36px_rgba(6,47,102,0.20)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#0891b2] active:scale-[0.98] sm:w-auto sm:text-base"
            >
              View all specialities
            </Link>
          </div>

          <div className="relative z-10 mt-8 grid gap-4 sm:mt-11 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3 lg:gap-6">
            {items.map((item) => {
              const Icon = getSpecialtyIcon(item.icon);

              return (
                <Link
                  key={item.id}
                  href={`/specialities/${item.slug}`}
                  className="group relative min-h-[210px] overflow-hidden border border-slate-200/80 bg-white px-6 py-7 shadow-[0_16px_38px_rgba(15,23,42,0.07)] transition-all duration-300 hover:-translate-y-1 hover:border-cyan-200 hover:shadow-[0_26px_60px_rgba(8,145,178,0.16)] active:scale-[0.99]"
                >
                  <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-[linear-gradient(90deg,#062f66,#0891b2,#22c55e)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

                  <div className="relative z-10 flex h-full flex-col">
                    <Icon
                      size={34}
                      strokeWidth={1.9}
                      className="specialities-icon-float mb-7 text-[#009f9a] transition-all duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:scale-110 group-hover:text-[#062f66]"
                    />

                    <h3 className="text-xl font-black leading-snug text-[#062f66]">
                      {item.title}
                    </h3>
                    <p className="mt-3 line-clamp-3 text-[15px] leading-7 text-slate-600">
                      {item.shortDescription}
                    </p>

                    <div className="mt-auto flex items-center justify-between pt-6">
                      <span className="text-xs font-black uppercase tracking-[0.18em] text-[#008c9e]">
                        Learn more
                      </span>
                      <span className="grid size-9 place-items-center rounded-full bg-slate-50 text-[#062f66] shadow-sm ring-1 ring-slate-200 transition-all duration-300 group-hover:translate-x-1 group-hover:bg-[#062f66] group-hover:text-white">
                        <ArrowRight size={17} />
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </Container>
    </section>
  );
}
