import DoctorArticleDetail from "@/components/doctor-articles/DoctorArticleDetail";

type DoctorArticleDynamicPageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export default async function DoctorArticleDynamicPage({
  params,
}: DoctorArticleDynamicPageProps) {
  const { slug } = await params;
  return <DoctorArticleDetail slug={slug} />;
}
