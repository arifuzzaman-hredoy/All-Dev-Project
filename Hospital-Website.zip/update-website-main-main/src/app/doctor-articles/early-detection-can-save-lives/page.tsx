// File: clinic-website/src/app/doctor-articles/early-detection-can-save-lives/page.tsx

import { notFound } from "next/navigation";
import DoctorArticleDetail from "@/components/doctor-articles/DoctorArticleDetail";
import { getDoctorArticleBySlug } from "@/data/site";

export default function EarlyDetectionCanSaveLivesPage() {
  const article = getDoctorArticleBySlug("early-detection-can-save-lives");

  if (!article) {
    notFound();
  }

  return <DoctorArticleDetail article={article} />;
}
