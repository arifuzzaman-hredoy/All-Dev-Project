// File: clinic-website/src/app/doctor-articles/diabetic-patients-ramadan-fasting/page.tsx

import { notFound } from "next/navigation";
import DoctorArticleDetail from "@/components/doctor-articles/DoctorArticleDetail";
import { getDoctorArticleBySlug } from "@/data/site";

export default function DiabeticPatientsRamadanFastingPage() {
  const article = getDoctorArticleBySlug("diabetic-patients-ramadan-fasting");

  if (!article) {
    notFound();
  }

  return <DoctorArticleDetail article={article} />;
}
