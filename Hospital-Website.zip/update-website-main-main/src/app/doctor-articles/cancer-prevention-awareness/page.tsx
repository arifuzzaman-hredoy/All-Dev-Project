// File: clinic-website/src/app/doctor-articles/cancer-prevention-awareness/page.tsx

import { notFound } from "next/navigation";
import DoctorArticleDetail from "@/components/doctor-articles/DoctorArticleDetail";
import { getDoctorArticleBySlug } from "@/data/site";

export default function CancerPreventionAwarenessPage() {
  const article = getDoctorArticleBySlug("cancer-prevention-awareness");

  if (!article) {
    notFound();
  }

  return <DoctorArticleDetail article={article} />;
}
