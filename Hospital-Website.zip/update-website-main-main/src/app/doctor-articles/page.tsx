// File: clinic-website/src/app/doctor-articles/page.tsx

import DoctorArticlesGrid from "@/components/doctor-articles/DoctorArticlesGrid";

export default function DoctorArticlesPage() {
  return <DoctorArticlesGrid />;
}
