import type { Metadata } from "next";
import { notFound } from "next/navigation";
import PublicServiceDetail from "@/features/public/services/components/PublicServiceDetail";
import {
  getPublicServiceBySlug,
  getPublicServices,
} from "@/features/public/services/queries";

type ServiceDetailPageProps = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({
  params,
}: ServiceDetailPageProps): Promise<Metadata> {
  const { slug } = await params;
  const service = await getPublicServiceBySlug(slug);

  if (!service) {
    return {
      title: "Service not found | Update Diagnostic Center",
    };
  }

  return {
    title: service.seoTitle || service.title,
    description: service.seoDescription || service.shortDescription,
    openGraph: service.featuredImage
      ? {
          title: service.seoTitle || service.title,
          description: service.seoDescription || service.shortDescription,
          images: [service.featuredImage],
        }
      : undefined,
  };
}

export async function generateStaticParams() {
  const services = await getPublicServices();
  return services.map((service) => ({ slug: service.slug }));
}

export default async function ServiceDetailPage({
  params,
}: ServiceDetailPageProps) {
  const { slug } = await params;
  const service = await getPublicServiceBySlug(slug);

  if (!service) {
    notFound();
  }

  return <PublicServiceDetail service={service} />;
}
