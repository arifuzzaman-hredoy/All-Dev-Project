import type { Metadata } from "next";
import PageHero from "@/components/common/PageHero";
import PublicServicesGrid from "@/features/public/services/components/PublicServicesGrid";
import { getPublicServices } from "@/features/public/services/queries";

export const metadata: Metadata = {
  title: "Services | Update Diagnostic Center",
  description:
    "Explore active services managed by Update Diagnostic Center's admin panel.",
};

export default async function ServicesPage() {
  const services = await getPublicServices();

  return (
    <>
      <PageHero
        title="Services"
        description="Explore active diagnostic and specialty services available for patients and families."
      />
      <PublicServicesGrid services={services} />
    </>
  );
}
