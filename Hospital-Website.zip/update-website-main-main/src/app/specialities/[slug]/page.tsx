import PageHero from "@/components/common/PageHero";
import SpecialtiesPublic from "@/components/specialties/SpecialtiesPublic";

export default async function SpecialtyDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  return (
    <>
      <PageHero
        title="Speciality Details"
        description="View department services, doctors, schedule, and appointment support."
      />
      <SpecialtiesPublic mode="detail" slug={slug} />
    </>
  );
}
