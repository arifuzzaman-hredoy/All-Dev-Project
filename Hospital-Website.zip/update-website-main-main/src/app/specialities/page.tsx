// File: clinic-website/src/app/specialities/page.tsx

import PageHero from "@/components/common/PageHero";
import SpecialtiesPublic from "@/components/specialties/SpecialtiesPublic";

export default function SpecialitiesPage() {
  return (
    <>
      <PageHero
        title="Specialities"
        description="Explore clinical departments and services available for patients and families."
      />
      <SpecialtiesPublic />
    </>
  );
}
