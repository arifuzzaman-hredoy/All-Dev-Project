// File: clinic-website/src/app/blogs/childhood-nephrotic-syndrome/page.tsx

import { notFound } from "next/navigation";
import BlogDetail from "@/components/blogs/BlogDetail";
import { getBlogPostBySlug } from "@/data/site";

export default function ChildhoodNephroticSyndromePage() {
  const blog = getBlogPostBySlug("childhood-nephrotic-syndrome");

  if (!blog) {
    notFound();
  }

  return <BlogDetail blog={blog} />;
}
