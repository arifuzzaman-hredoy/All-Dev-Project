import BlogDetail from "@/components/blogs/BlogDetail";

type BlogDynamicPageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export default async function BlogDynamicPage({ params }: BlogDynamicPageProps) {
  const { slug } = await params;
  return <BlogDetail slug={slug} />;
}
