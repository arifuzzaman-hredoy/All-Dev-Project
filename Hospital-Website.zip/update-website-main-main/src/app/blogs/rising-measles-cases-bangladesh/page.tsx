// File: clinic-website/src/app/blogs/rising-measles-cases-bangladesh/page.tsx

import { notFound } from "next/navigation";
import BlogDetail from "@/components/blogs/BlogDetail";
import { getBlogPostBySlug } from "@/data/site";

export default function RisingMeaslesCasesBangladeshPage() {
  const blog = getBlogPostBySlug("rising-measles-cases-bangladesh");

  if (!blog) {
    notFound();
  }

  return <BlogDetail blog={blog} />;
}
