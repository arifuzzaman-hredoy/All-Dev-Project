// File: clinic-website/src/app/blogs/page.tsx

import BlogsGrid from "@/components/blogs/BlogsGrid";

export default function BlogsPage() {
  return <BlogsGrid />;
}
