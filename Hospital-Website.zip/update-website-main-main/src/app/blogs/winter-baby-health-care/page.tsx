// File: clinic-website/src/app/blogs/winter-baby-health-care/page.tsx

import { notFound } from "next/navigation";
import BlogDetail from "@/components/blogs/BlogDetail";
import { getBlogPostBySlug } from "@/data/site";

export default function WinterBabyHealthCarePage() {
  const blog = getBlogPostBySlug("winter-baby-health-care");

  if (!blog) {
    notFound();
  }

  return <BlogDetail blog={blog} />;
}
