// File: clinic-website/src/app/doctors/page.tsx

import { connection } from "next/server";
import {
  Award,
  HeartPulse,
  ShieldCheck,
  Sparkles,
  Stethoscope,
} from "lucide-react";
import Container from "@/components/common/Container";
import PageHero from "@/components/common/PageHero";
import SectionTitle from "@/components/common/SectionTitle";
import PublicDoctorCard from "@/components/doctors/PublicDoctorCard";
import { getActiveDoctors } from "@/lib/doctors";

export default async function DoctorsPage() {
  await connection();

  const doctors = await getActiveDoctors();

  return (
    <>
      <PageHero
        title="Doctors"
        description="Find demo consultants by speciality and request an appointment from the doctor profile card."
      />

      <section className="relative overflow-hidden bg-[linear-gradient(180deg,#ffffff_0%,#f5faff_42%,#ffffff_100%)] py-16 sm:py-20">
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(6,47,102,0.035)_1px,transparent_1px),linear-gradient(90deg,rgba(6,47,102,0.035)_1px,transparent_1px)] bg-[size:42px_42px]" />

        <div className="pointer-events-none absolute left-[-150px] top-20 h-[340px] w-[340px] rounded-full bg-[#062f66]/6 blur-[95px]" />
        <div className="pointer-events-none absolute right-[-150px] top-[38%] h-[360px] w-[360px] rounded-full bg-[#5bc0de]/12 blur-[100px]" />
        <div className="pointer-events-none absolute bottom-12 left-1/2 h-[240px] w-[75%] -translate-x-1/2 rounded-full bg-[#8cc63f]/[0.07] blur-[95px]" />

        <div className="pointer-events-none absolute left-8 top-14 hidden text-[#062f66]/5 lg:block">
          <Stethoscope size={128} strokeWidth={1.25} />
        </div>

        <div className="pointer-events-none absolute bottom-16 right-10 hidden text-[#062f66]/5 lg:block">
          <HeartPulse size={128} strokeWidth={1.25} />
        </div>

        <div className="pointer-events-none absolute right-[18%] top-28 hidden text-[#5bc0de]/10 xl:block">
          <Sparkles size={80} strokeWidth={1.4} />
        </div>

        <Container>
          <div className="relative z-10">
            <div className="mx-auto mb-6 flex w-fit items-center gap-2 rounded-full border border-[#dfe8f3] bg-white/90 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-[#062f66] shadow-[0_10px_24px_rgba(6,47,102,0.06)] backdrop-blur-sm">
              <ShieldCheck size={15} className="text-[#5bc0de]" />
              Trusted Consultants
            </div>

            <SectionTitle
              title="Meet Our Best Doctors"
              description="Our experienced team of doctors is ready to provide you with the best healthcare"
              align="center"
            />

            <div className="mx-auto mt-8 grid max-w-4xl gap-4 rounded-3xl border border-slate-200/70 bg-white/75 p-4 shadow-[0_20px_55px_rgba(6,47,102,0.09)] backdrop-blur-sm sm:grid-cols-3">
              <div className="group flex items-center justify-center gap-3 rounded-2xl border border-slate-100 bg-[#f8fbff] px-4 py-4 text-center transition-all duration-300 hover:-translate-y-0.5 hover:bg-white hover:shadow-[0_14px_30px_rgba(6,47,102,0.08)]">
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-[#062f66] text-white shadow-[0_10px_22px_rgba(6,47,102,0.18)] transition-all duration-300 group-hover:scale-110 group-hover:bg-[#5bc0de]">
                  <Stethoscope
                    size={19}
                    className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6"
                  />
                </span>
                <span className="text-sm font-black text-[#062f66]">
                  Expert Care
                </span>
              </div>

              <div className="group flex items-center justify-center gap-3 rounded-2xl border border-slate-100 bg-[#f8fbff] px-4 py-4 text-center transition-all duration-300 hover:-translate-y-0.5 hover:bg-white hover:shadow-[0_14px_30px_rgba(6,47,102,0.08)]">
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-[#062f66] text-white shadow-[0_10px_22px_rgba(6,47,102,0.18)] transition-all duration-300 group-hover:scale-110 group-hover:bg-[#5bc0de]">
                  <Award
                    size={19}
                    className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6"
                  />
                </span>
                <span className="text-sm font-black text-[#062f66]">
                  Qualified Team
                </span>
              </div>

              <div className="group flex items-center justify-center gap-3 rounded-2xl border border-slate-100 bg-[#f8fbff] px-4 py-4 text-center transition-all duration-300 hover:-translate-y-0.5 hover:bg-white hover:shadow-[0_14px_30px_rgba(6,47,102,0.08)]">
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-[#062f66] text-white shadow-[0_10px_22px_rgba(6,47,102,0.18)] transition-all duration-300 group-hover:scale-110 group-hover:bg-[#5bc0de]">
                  <HeartPulse
                    size={19}
                    className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6"
                  />
                </span>
                <span className="text-sm font-black text-[#062f66]">
                  Patient First
                </span>
              </div>
            </div>

            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {doctors.map((doctor) => (
                <div
                  key={doctor.id}
                  className="rounded-2xl transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_26px_60px_rgba(6,47,102,0.16)]"
                >
                  <PublicDoctorCard doctor={doctor} />
                </div>
              ))}
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
