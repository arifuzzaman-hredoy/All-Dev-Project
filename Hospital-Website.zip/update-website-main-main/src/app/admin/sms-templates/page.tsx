"use client";

import { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  Copy,
  Loader2,
  MessageSquareText,
  RefreshCcw,
  Save,
  Search,
} from "lucide-react";

type AdminSmsTemplate = {
  id: string;
  templateKey: string;
  title: string;
  message: string;
  variables: string[];
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

type Draft = {
  title: string;
  message: string;
  variablesText: string;
  isActive: boolean;
  sortOrder: number;
};

function toDraft(template: AdminSmsTemplate): Draft {
  return {
    title: template.title,
    message: template.message,
    variablesText: template.variables.join(", "),
    isActive: template.isActive,
    sortOrder: template.sortOrder,
  };
}

function variablesFromText(value: string) {
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function variableToken(value: string) {
  return `{{${value}}}`;
}

export default function SmsTemplatesAdminPage() {
  const [templates, setTemplates] = useState<AdminSmsTemplate[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const selectedTemplate = useMemo(
    () => templates.find((template) => template.id === selectedId) || null,
    [selectedId, templates],
  );

  const filteredTemplates = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return templates;

    return templates.filter((template) =>
      [
        template.templateKey,
        template.title,
        template.message,
        template.variables.join(" "),
        template.isActive ? "active" : "inactive",
      ].some((value) => value.toLowerCase().includes(query)),
    );
  }, [search, templates]);

  async function loadTemplates() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/admin/sms-templates", {
        cache: "no-store",
      });

      if (!response.ok) {
        throw new Error("SMS templates could not be loaded.");
      }

      const data = (await response.json()) as {
        templates: AdminSmsTemplate[];
      };

      const nextTemplates = data.templates || [];
      setTemplates(nextTemplates);

      if (!selectedId && nextTemplates[0]) {
        setSelectedId(nextTemplates[0].id);
        setDraft(toDraft(nextTemplates[0]));
      }
    } catch (caught) {
      setError(
        caught instanceof Error
          ? caught.message
          : "SMS templates could not be loaded.",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadTemplates();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function selectTemplate(template: AdminSmsTemplate) {
    setSelectedId(template.id);
    setDraft(toDraft(template));
    setNotice("");
    setError("");
  }

  function updateDraft<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((current) => (current ? { ...current, [key]: value } : current));
  }

  async function saveTemplate() {
    if (!selectedTemplate || !draft) return;

    setSaving(true);
    setNotice("");
    setError("");

    try {
      const response = await fetch(
        `/api/admin/sms-templates/${selectedTemplate.id}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: draft.title,
            message: draft.message,
            variables: variablesFromText(draft.variablesText),
            isActive: draft.isActive,
            sortOrder: draft.sortOrder,
          }),
        },
      );

      const data = (await response.json().catch(() => null)) as {
        template?: AdminSmsTemplate;
        message?: string;
      } | null;

      if (!response.ok || !data?.template) {
        throw new Error(data?.message || "SMS template save failed.");
      }

      setTemplates((current) =>
        current
          .map((template) =>
            template.id === data.template?.id ? data.template : template,
          )
          .sort((left, right) => {
            const order = left.sortOrder - right.sortOrder;
            if (order !== 0) return order;
            return left.templateKey.localeCompare(right.templateKey);
          }),
      );
      setSelectedId(data.template.id);
      setDraft(toDraft(data.template));
      setNotice("SMS template saved successfully.");
    } catch (caught) {
      setError(
        caught instanceof Error ? caught.message : "SMS template save failed.",
      );
    } finally {
      setSaving(false);
    }
  }

  async function copyToken(token: string) {
    await navigator.clipboard.writeText(token);
    setNotice(`Copied ${token}`);
  }

  return (
    <div className="space-y-5">
      <section>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full bg-[#eaf7ff] px-3 py-1 text-xs font-black uppercase tracking-[0.16em] text-[#1597c7]">
              <MessageSquareText size={15} />
              SMS Automation
            </p>

            <h1 className="mt-3 text-2xl font-black text-[#062f66]">
              SMS Templates
            </h1>

            <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-slate-600">
              Edit SMS messages for appointment, package booking, contact,
              support, and career workflows. Dynamic variables use double curly
              braces like {"{{patientName}}"}.
            </p>
          </div>

          <button
            type="button"
            onClick={() => void loadTemplates()}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-slate-200 bg-white px-4 text-sm font-black text-[#062f66] shadow-sm transition hover:-translate-y-0.5 hover:border-[#43c7f4]"
          >
            <RefreshCcw size={17} />
            Refresh
          </button>
        </div>
      </section>

      {notice ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-black text-emerald-700">
          {notice}
        </div>
      ) : null}

      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-black text-red-700">
          {error}
        </div>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
        <aside className="rounded-[26px] border border-[#dbe8ff] bg-white p-4 shadow-[0_18px_55px_rgba(6,47,102,0.07)]">
          <label className="mb-4 flex h-11 items-center gap-2 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-3">
            <Search size={17} className="text-slate-400" />
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search templates..."
              className="w-full bg-transparent text-sm font-semibold text-[#062f66] outline-none placeholder:text-slate-400"
            />
          </label>

          {loading ? (
            <div className="flex items-center justify-center gap-2 rounded-2xl bg-slate-50 py-10 text-sm font-black text-slate-500">
              <Loader2 className="animate-spin" size={18} />
              Loading templates...
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTemplates.map((template) => (
                <button
                  key={template.id}
                  type="button"
                  onClick={() => selectTemplate(template)}
                  className={`w-full rounded-2xl border p-4 text-left transition hover:-translate-y-0.5 ${
                    selectedId === template.id
                      ? "border-[#43c7f4] bg-[#f0fbff] shadow-[0_14px_35px_rgba(67,199,244,0.15)]"
                      : "border-slate-100 bg-white hover:border-[#dbe8ff] hover:bg-[#f8fbff]"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.14em] text-[#43c7f4]">
                        {template.templateKey}
                      </p>
                      <h2 className="mt-1 text-sm font-black text-[#062f66]">
                        {template.title}
                      </h2>
                    </div>

                    <span
                      className={`rounded-full px-2.5 py-1 text-[10px] font-black uppercase ${
                        template.isActive
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-slate-100 text-slate-500"
                      }`}
                    >
                      {template.isActive ? "Active" : "Inactive"}
                    </span>
                  </div>

                  <p className="mt-3 line-clamp-2 text-xs font-semibold leading-5 text-slate-500">
                    {template.message}
                  </p>
                </button>
              ))}
            </div>
          )}
        </aside>

        <section className="rounded-[26px] border border-[#dbe8ff] bg-white p-5 shadow-[0_18px_55px_rgba(6,47,102,0.07)]">
          {!selectedTemplate || !draft ? (
            <div className="grid min-h-[420px] place-items-center rounded-2xl bg-slate-50 text-center">
              <p className="text-sm font-black text-slate-500">
                Select an SMS template to edit.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] p-4">
                <p className="text-xs font-black uppercase tracking-[0.16em] text-[#43c7f4]">
                  Template Key
                </p>
                <p className="mt-1 font-mono text-sm font-black text-[#062f66]">
                  {selectedTemplate.templateKey}
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-[1fr_150px]">
                <label className="grid gap-2 text-sm font-black text-[#062f66]">
                  Template title
                  <input
                    value={draft.title}
                    onChange={(event) => updateDraft("title", event.target.value)}
                    className="form-input"
                  />
                </label>

                <label className="grid gap-2 text-sm font-black text-[#062f66]">
                  Sort order
                  <input
                    type="number"
                    min="0"
                    value={draft.sortOrder}
                    onChange={(event) =>
                      updateDraft("sortOrder", Number(event.target.value))
                    }
                    className="form-input"
                  />
                </label>
              </div>

              <label className="flex items-center gap-3 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] p-4 text-sm font-black text-[#062f66]">
                <input
                  type="checkbox"
                  checked={draft.isActive}
                  onChange={(event) =>
                    updateDraft("isActive", event.target.checked)
                  }
                  className="h-5 w-5 rounded border-slate-300"
                />
                Active template
              </label>

              <label className="grid gap-2 text-sm font-black text-[#062f66]">
                Message
                <textarea
                  value={draft.message}
                  onChange={(event) =>
                    updateDraft("message", event.target.value)
                  }
                  rows={7}
                  className="form-input min-h-[180px] py-3 leading-7"
                />
              </label>

              <label className="grid gap-2 text-sm font-black text-[#062f66]">
                Variables
                <input
                  value={draft.variablesText}
                  onChange={(event) =>
                    updateDraft("variablesText", event.target.value)
                  }
                  placeholder="patientName, phone, token, clinicName"
                  className="form-input"
                />
              </label>

              <div className="rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] p-4">
                <p className="mb-3 text-xs font-black uppercase tracking-[0.16em] text-[#43c7f4]">
                  Click to copy variable
                </p>

                <div className="flex flex-wrap gap-2">
                  {variablesFromText(draft.variablesText).map((variable) => (
                    <button
                      key={variable}
                      type="button"
                      onClick={() => void copyToken(variableToken(variable))}
                      className="inline-flex items-center gap-2 rounded-full border border-[#dbe8ff] bg-white px-3 py-2 font-mono text-xs font-black text-[#062f66] transition hover:-translate-y-0.5 hover:border-[#43c7f4]"
                    >
                      <Copy size={13} />
                      {variableToken(variable)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-slate-100 bg-white p-4">
                <p className="mb-2 flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-slate-500">
                  <CheckCircle2 size={15} />
                  Preview
                </p>
                <p className="whitespace-pre-wrap rounded-2xl bg-slate-50 p-4 text-sm font-semibold leading-7 text-slate-700">
                  {draft.message}
                </p>
              </div>

              <div className="flex justify-end border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={() => void saveTemplate()}
                  disabled={saving}
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-[#43c7f4] px-6 text-sm font-black text-white shadow-[0_16px_35px_rgba(67,199,244,0.30)] transition hover:-translate-y-0.5 hover:bg-[#17a9de] disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {saving ? (
                    <Loader2 className="animate-spin" size={18} />
                  ) : (
                    <Save size={18} />
                  )}
                  {saving ? "Saving..." : "Save template"}
                </button>
              </div>

              <style jsx>{`
                .form-input {
                  width: 100%;
                  border-radius: 16px;
                  border: 1px solid #dbe8ff;
                  background: #f8fbff;
                  padding: 0 14px;
                  min-height: 44px;
                  font-size: 13px;
                  font-weight: 700;
                  color: #062f66;
                  outline: none;
                  transition: all 0.2s ease;
                }

                .form-input:focus {
                  border-color: #43c7f4;
                  background: #ffffff;
                  box-shadow: 0 0 0 4px rgba(67, 199, 244, 0.15);
                }
              `}</style>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
