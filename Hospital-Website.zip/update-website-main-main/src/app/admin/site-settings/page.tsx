"use client";

import Link from "next/link";
import clsx from "clsx";
import {
  type ChangeEvent,
  type ReactNode,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  BadgeCheck,
  Building2,
  Clock,
  Code2,
  Copy,
  Cpu,
  Download,
  ExternalLink,
  Globe2,
  ImageIcon,
  Layers3,
  Mail,
  MapPin,
  MonitorCog,
  Phone,
  RefreshCcw,
  Rocket,
  Save,
  Search,
  ShieldCheck,
  Sparkles,
  Upload,
  type LucideIcon,
} from "lucide-react";

type SiteSettings = {
  siteName: string;
  tagline: string;
  description: string;
  logoUrl: string;
  faviconUrl: string;
  phone: string;
  emergency: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  country: string;
  hours: string;
  googleMapUrl: string;
  googleMapEmbedUrl: string;
  facebookUrl: string;
  youtubeUrl: string;
  linkedinUrl: string;
  websiteUrl: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  primaryButtonText: string;
  primaryButtonUrl: string;
  secondaryButtonText: string;
  secondaryButtonUrl: string;
  footerText: string;
  copyrightText: string;
};

const TECHTEAM_LEAD_URL = "https://techteamlead.com/";

const DEFAULT_SETTINGS: SiteSettings = {
  siteName: "Update Diagnostic Center",
  tagline: "Advanced care with a human touch",
  description:
    "A modern multi-speciality healthcare destination focused on safe treatment, clear communication, and comfortable patient experiences.",

  logoUrl: "",
  faviconUrl: "",

  phone: "01763-555555",
  emergency: "01971-555555",
  whatsapp: "01763-555555",
  email: "update.diagnostic@gmail.com",

  address: "Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh",
  city: "Rangpur",
  country: "Bangladesh",
  hours: "Open 24/7",
  googleMapUrl: "https://maps.google.com",
  googleMapEmbedUrl: "",

  facebookUrl: "https://facebook.com",
  youtubeUrl: "https://youtube.com",
  linkedinUrl: "https://linkedin.com",
  websiteUrl: "https://example.com",

  seoTitle: "Update Diagnostic Center - Advanced Healthcare",
  seoDescription:
    "Update Diagnostic Center provides modern diagnostic and healthcare services with reliable care, clear communication, and patient-first support.",
  seoKeywords:
    "diagnostic center, hospital, healthcare, Rangpur, doctor, emergency, medical service",

  primaryButtonText: "Book Appointment",
  primaryButtonUrl: "/appointment",
  secondaryButtonText: "Call Emergency",
  secondaryButtonUrl: "tel:01971555555",

  footerText: "Advanced care with a human touch.",
  copyrightText: "© 2026 Update Diagnostic Center. All rights reserved.",
};

const inputClass =
  "w-full rounded-2xl border border-slate-200/90 bg-white/90 px-4 py-3 text-sm font-semibold text-slate-800 shadow-[0_10px_26px_rgba(15,23,42,0.035)] outline-none transition-all duration-300 placeholder:text-slate-400 hover:border-cyan-200 hover:bg-white focus:border-[#087ea4] focus:bg-white focus:ring-4 focus:ring-cyan-400/15";

const labelClass = "mb-2 block text-sm font-black text-slate-700";

function applyBrowserPreview(settings: SiteSettings) {
  if (typeof document === "undefined") return;

  document.title = settings.seoTitle || settings.siteName;

  if (settings.faviconUrl) {
    let favicon = document.querySelector<HTMLLinkElement>("link[rel='icon']");

    if (!favicon) {
      favicon = document.createElement("link");
      favicon.rel = "icon";
      document.head.appendChild(favicon);
    }

    favicon.href = settings.faviconUrl;
  }
}

function readImageAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Only image files are allowed."));
      return;
    }

    if (file.size > 1.5 * 1024 * 1024) {
      reject(new Error("Image size must be under 1.5MB."));
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      if (typeof reader.result === "string") resolve(reader.result);
      else reject(new Error("Could not read image."));
    };

    reader.onerror = () => reject(new Error("Could not read image."));
    reader.readAsDataURL(file);
  });
}

function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label className={labelClass}>{label}</label>
      {children}
      {hint ? (
        <p className="mt-2 text-xs font-semibold leading-5 text-slate-500">
          {hint}
        </p>
      ) : null}
    </div>
  );
}

function SectionCard({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <section className="group relative overflow-hidden rounded-[2rem] border border-white/75 bg-white/[0.88] p-5 shadow-[0_22px_60px_rgba(8,47,73,0.08)] ring-1 ring-slate-200/70 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-100 hover:shadow-[0_30px_80px_rgba(8,145,178,0.12)]">
      <div className="pointer-events-none absolute right-[-90px] top-[-100px] h-48 w-48 rounded-full bg-cyan-200/20 blur-3xl transition-opacity duration-300 group-hover:opacity-100" />
      <div className="pointer-events-none absolute left-[-120px] bottom-[-120px] h-56 w-56 rounded-full bg-[#062f66]/6 blur-3xl" />

      <div className="relative z-10 mb-5 flex items-start gap-3">
        <div className="settings-icon-spin grid size-11 shrink-0 place-items-center rounded-2xl bg-[linear-gradient(135deg,#04264d_0%,#087ea4_65%,#18c7d9_100%)] text-white shadow-[0_16px_34px_rgba(8,47,73,0.20)] ring-1 ring-white/40 transition-all duration-300 group-hover:scale-105 group-hover:shadow-[0_20px_44px_rgba(8,145,178,0.26)]">
          <Icon size={20} />
        </div>

        <div>
          <h2 className="text-base font-black text-slate-950">{title}</h2>
          <p className="mt-1 text-sm leading-6 text-slate-500">
            {description}
          </p>
        </div>
      </div>

      <div className="relative z-10">{children}</div>
    </section>
  );
}

function QuickLink({
  href,
  icon: Icon,
  label,
  external,
  tone = "blue",
}: {
  href: string;
  icon: LucideIcon;
  label: string;
  external?: boolean;
  tone?: "blue" | "red" | "green";
}) {
  const toneClass =
    tone === "red"
      ? "hover:border-red-200 hover:text-red-600 hover:shadow-[0_16px_34px_rgba(239,68,68,0.10)]"
      : tone === "green"
        ? "hover:border-emerald-200 hover:text-emerald-700 hover:shadow-[0_16px_34px_rgba(16,185,129,0.10)]"
        : "hover:border-cyan-200 hover:text-[#062f66] hover:shadow-[0_16px_34px_rgba(8,145,178,0.10)]";

  const commonClass = clsx(
    "group flex items-center gap-3 rounded-2xl border border-slate-200/85 bg-white/[0.78] px-4 py-3 text-sm font-black text-slate-700 shadow-[0_10px_24px_rgba(15,23,42,0.035)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98]",
    toneClass,
  );

  if (external) {
    return (
      <a href={href} target="_blank" rel="noreferrer" className={commonClass}>
        <Icon
          size={17}
          className="transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110"
        />
        {label}
      </a>
    );
  }

  return (
    <a href={href} className={commonClass}>
      <Icon
        size={17}
        className="transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110"
      />
      {label}
    </a>
  );
}

function DeveloperCreditCard() {
  return (
    <section className="relative overflow-hidden rounded-[2rem] border border-white/75 bg-[linear-gradient(135deg,#020b1f_0%,#052f63_48%,#087ea4_100%)] p-5 text-white shadow-[0_26px_80px_rgba(8,47,73,0.22)] ring-1 ring-white/10">
      <div className="pointer-events-none absolute -right-16 -top-16 h-52 w-52 rounded-full bg-cyan-200/24 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-20 left-6 h-48 w-48 rounded-full bg-[#8cc63f]/18 blur-3xl" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.48),transparent)]" />

      <div className="relative z-10 flex items-center gap-3">
        <div className="settings-icon-spin grid size-12 place-items-center rounded-2xl bg-white/12 text-cyan-100 shadow-[0_16px_34px_rgba(0,0,0,0.12)] ring-1 ring-white/15 backdrop-blur-md">
          <Code2 size={22} />
        </div>

        <div>
          <p className="inline-flex items-center gap-1 text-xs font-black uppercase tracking-[0.22em] text-cyan-100">
            <Sparkles size={13} />
            Developed by
          </p>
          <h2 className="mt-1 text-2xl font-black tracking-tight">
            TechTeam Lead
          </h2>
        </div>
      </div>

      <p className="relative z-10 mt-4 text-sm leading-6 text-cyan-50/90">
        This complete hospital website and admin control system was crafted by
        TechTeam Lead with modern UI, responsive layout, SEO controls, and
        scalable Next.js architecture.
      </p>

      <div className="relative z-10 mt-5 grid gap-2">
        <div className="group flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 text-sm font-bold text-white/90 ring-1 ring-white/10 backdrop-blur-md transition-all duration-300 hover:bg-white/15">
          <BadgeCheck
            size={16}
            className="text-[#8cc63f] transition-transform duration-300 group-hover:scale-110"
          />
          Complete hospital website solution
        </div>

        <div className="group flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 text-sm font-bold text-white/90 ring-1 ring-white/10 backdrop-blur-md transition-all duration-300 hover:bg-white/15">
          <Layers3
            size={16}
            className="text-cyan-200 transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110"
          />
          Admin editable content system
        </div>

        <div className="group flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 text-sm font-bold text-white/90 ring-1 ring-white/10 backdrop-blur-md transition-all duration-300 hover:bg-white/15">
          <Cpu
            size={16}
            className="text-cyan-200 transition-transform duration-300 group-hover:scale-110"
          />
          Modern Next.js frontend architecture
        </div>
      </div>

      <a
        href={TECHTEAM_LEAD_URL}
        target="_blank"
        rel="noreferrer"
        className="group relative z-10 mt-5 inline-flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl bg-white px-4 py-3 text-sm font-black text-[#062f66] shadow-[0_16px_34px_rgba(255,255,255,0.14)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-cyan-100 hover:shadow-[0_20px_44px_rgba(255,255,255,0.18)] active:scale-[0.98]"
      >
        <span className="absolute inset-0 translate-x-[-120%] bg-[linear-gradient(90deg,transparent,rgba(8,145,178,0.16),transparent)] transition-transform duration-700 group-hover:translate-x-[120%]" />
        <ExternalLink
          size={16}
          className="relative z-10 transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110"
        />
        <span className="relative z-10">Visit TechTeam Lead</span>
      </a>

      <a
        href={TECHTEAM_LEAD_URL}
        target="_blank"
        rel="noreferrer"
        className="relative z-10 mt-3 block truncate rounded-2xl border border-white/12 bg-white/8 px-3 py-2 text-center text-xs font-bold text-cyan-50/90 transition-all duration-300 hover:bg-white/12"
      >
        {TECHTEAM_LEAD_URL}
      </a>
    </section>
  );
}

export default function SiteSettingsPage() {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [savedAt, setSavedAt] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    let mounted = true;

    async function loadSettings() {
      try {
        const response = await fetch("/api/admin/site-settings", {
          cache: "no-store",
        });
        const payload = (await response.json().catch(() => null)) as
          | { settings?: Partial<SiteSettings> }
          | null;

        if (mounted && response.ok && payload?.settings) {
          const merged = { ...DEFAULT_SETTINGS, ...payload.settings };
          setSettings(merged);
          applyBrowserPreview(merged);
          return;
        }
      } catch {
        // Keep admin usable with local fallback during development.
      }

      if (mounted) {
        setSettings(DEFAULT_SETTINGS);
        setMessage("Could not load database settings. Showing defaults.");
      }
      applyBrowserPreview(DEFAULT_SETTINGS);
    }

    void loadSettings();

    return () => {
      mounted = false;
    };
  }, []);

  const contactLinks = useMemo(() => {
    const phone = settings.phone.replace(/\s+/g, "");
    const emergency = settings.emergency.replace(/\s+/g, "");
    const whatsapp = settings.whatsapp.replace(/[^\d+]/g, "").replace("+", "");

    return {
      phone: `tel:${phone}`,
      emergency: `tel:${emergency}`,
      whatsapp: `https://wa.me/${whatsapp}`,
      email: `mailto:${settings.email}`,
      map: settings.googleMapUrl || "https://maps.google.com",
    };
  }, [settings]);

  function updateField<K extends keyof SiteSettings>(
    key: K,
    value: SiteSettings[K],
  ) {
    setSettings((current) => ({ ...current, [key]: value }));
  }

  async function handleImageUpload(
    event: ChangeEvent<HTMLInputElement>,
    key: "logoUrl" | "faviconUrl",
  ) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const dataUrl = await readImageAsDataUrl(file);
      const nextSettings = { ...settings, [key]: dataUrl };

      setSettings(nextSettings);
      applyBrowserPreview(nextSettings);
      setMessage(key === "logoUrl" ? "Logo updated." : "Favicon updated.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Image upload failed.");
    }
  }

  async function handleSave() {
    try {
      const response = await fetch("/api/admin/site-settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings }),
      });
      const payload = (await response.json().catch(() => null)) as
        | { settings?: Partial<SiteSettings>; message?: string }
        | null;

      if (!response.ok || !payload?.settings) {
        throw new Error(payload?.message || "Settings save failed.");
      }

      const merged = { ...DEFAULT_SETTINGS, ...payload.settings };
      setSettings(merged);
      applyBrowserPreview(merged);
      setSavedAt(new Date().toLocaleString());
      setMessage("Settings saved successfully to database.");
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Settings save failed. Please try again.",
      );
    }
  }

  async function handleReset() {
    try {
      const response = await fetch("/api/admin/site-settings", {
        method: "DELETE",
      });
      const payload = (await response.json().catch(() => null)) as
        | { settings?: Partial<SiteSettings> }
        | null;
      const merged = { ...DEFAULT_SETTINGS, ...(payload?.settings || {}) };

      if (!response.ok) throw new Error("Reset failed.");

      setSettings(merged);
      applyBrowserPreview(merged);
      setSavedAt("");
      setMessage("Settings reset to default in database.");
    } catch {
      setSettings(DEFAULT_SETTINGS);
      applyBrowserPreview(DEFAULT_SETTINGS);
      setSavedAt("");
      setMessage("Settings reset to default preview. Database reset failed.");
    }
  }

  async function handleCopyJson() {
    await navigator.clipboard.writeText(JSON.stringify(settings, null, 2));
    setMessage("Settings JSON copied.");
  }

  function handleExportJson() {
    const blob = new Blob([JSON.stringify(settings, null, 2)], {
      type: "application/json",
    });

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");

    anchor.href = url;
    anchor.download = "site-settings.json";
    anchor.click();

    URL.revokeObjectURL(url);
    setMessage("Settings exported as JSON.");
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-[linear-gradient(180deg,#f8fcff_0%,#eef8ff_44%,#ffffff_100%)] px-4 py-6 sm:px-6 lg:px-8">
      <style>{`
        @keyframes settingsGridMove {
          0% {
            background-position: 0 0, 0 0;
          }
          100% {
            background-position: 64px 64px, 64px 64px;
          }
        }

        @keyframes settingsIconFloat {
          0%, 100% {
            transform: translate3d(0, 0, 0) rotate(0deg);
          }
          50% {
            transform: translate3d(0, -3px, 0) rotate(2deg);
          }
        }

        @keyframes settingsSoftPulse {
          0%, 100% {
            opacity: 0.55;
            transform: scale(1);
          }
          50% {
            opacity: 0.9;
            transform: scale(1.04);
          }
        }

        .settings-grid-bg {
          background-image:
            linear-gradient(rgba(6,47,102,0.055) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6,47,102,0.055) 1px, transparent 1px);
          background-size: 64px 64px;
          animation: settingsGridMove 22s linear infinite;
        }

        .settings-icon-spin svg {
          animation: settingsIconFloat 4.2s ease-in-out infinite;
        }

        .settings-soft-pulse {
          animation: settingsSoftPulse 5s ease-in-out infinite;
        }

        @media (prefers-reduced-motion: reduce) {
          .settings-grid-bg,
          .settings-icon-spin svg,
          .settings-soft-pulse {
            animation: none !important;
          }
        }
      `}</style>

      <div className="settings-grid-bg pointer-events-none absolute inset-0 opacity-70" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_10%_12%,rgba(34,211,238,0.16),transparent_30%),radial-gradient(circle_at_92%_10%,rgba(6,47,102,0.10),transparent_28%),radial-gradient(circle_at_50%_96%,rgba(34,197,94,0.10),transparent_34%)]" />
      <div className="settings-soft-pulse pointer-events-none absolute -left-32 top-20 h-96 w-96 rounded-full bg-cyan-300/16 blur-3xl" />
      <div className="settings-soft-pulse pointer-events-none absolute -right-32 top-60 h-96 w-96 rounded-full bg-[#062f66]/10 blur-3xl" />

      <div className="relative z-10 mx-auto max-w-7xl space-y-6">
        <div className="overflow-hidden rounded-[2rem] border border-white/70 bg-white/[0.84] shadow-[0_26px_80px_rgba(8,47,73,0.12)] ring-1 ring-slate-200/70 backdrop-blur-2xl">
          <div className="relative overflow-hidden bg-[linear-gradient(135deg,#020b1f_0%,#052f63_42%,#087ea4_74%,#10b8c9_100%)] px-5 py-7 text-white sm:px-7">
            <div className="pointer-events-none absolute -right-12 -top-16 size-48 rounded-full bg-cyan-200/22 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-16 left-12 size-40 rounded-full bg-[#8cc63f]/16 blur-3xl" />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.42),transparent)]" />

            <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="inline-flex rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-black uppercase tracking-[0.24em] text-cyan-100 backdrop-blur-md">
                  Overview / Site settings
                </p>

                <h1 className="mt-4 text-2xl font-black tracking-tight sm:text-3xl lg:text-4xl">
                  Shared site identity and contact details
                </h1>

                <p className="mt-3 max-w-3xl text-sm leading-6 text-cyan-50/90">
                  Change favicon, logo, contact number, emergency number,
                  location, SEO, social links, public buttons, and footer
                  content from one place.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={handleSave}
                  className="group inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm font-black text-[#062f66] shadow-[0_16px_34px_rgba(255,255,255,0.16)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-cyan-100 active:scale-[0.98]"
                >
                  <Save
                    size={16}
                    className="transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110"
                  />
                  Save Changes
                </button>

                <button
                  type="button"
                  onClick={handleReset}
                  className="group inline-flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-black text-white ring-1 ring-white/15 backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/18 active:scale-[0.98]"
                >
                  <RefreshCcw
                    size={16}
                    className="transition-transform duration-500 group-hover:rotate-180"
                  />
                  Reset
                </button>
              </div>
            </div>
          </div>

          <div className="grid gap-3 border-b border-slate-200/80 bg-white/80 px-5 py-4 backdrop-blur-xl sm:grid-cols-2 lg:grid-cols-5 lg:px-7">
            <QuickLink href={contactLinks.phone} icon={Phone} label="Call" />
            <QuickLink
              href={contactLinks.emergency}
              icon={Phone}
              label="Emergency"
              tone="red"
            />
            <QuickLink href={contactLinks.email} icon={Mail} label="Email" />
            <QuickLink
              href={contactLinks.map}
              icon={MapPin}
              label="Map"
              external
              tone="green"
            />
            <Link
              href="/"
              className="group flex items-center gap-3 rounded-2xl border border-slate-200/85 bg-white/[0.78] px-4 py-3 text-sm font-black text-slate-700 shadow-[0_10px_24px_rgba(15,23,42,0.035)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-200 hover:text-[#062f66] hover:shadow-[0_16px_34px_rgba(8,145,178,0.10)] active:scale-[0.98]"
            >
              <ExternalLink
                size={17}
                className="transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110"
              />
              Public Site
            </Link>
          </div>

          {message ? (
            <div className="border-b border-emerald-100 bg-[linear-gradient(90deg,#ecfdf5,#f7fee7)] px-5 py-3 text-sm font-black text-emerald-800 lg:px-7">
              {message}
              {savedAt ? (
                <span className="ml-2 font-bold text-emerald-700/70">
                  Last saved: {savedAt}
                </span>
              ) : null}
            </div>
          ) : null}
        </div>

        <div className="grid gap-6 xl:grid-cols-[1fr_390px]">
          <div className="space-y-6">
            <SectionCard
              icon={Building2}
              title="Brand Identity"
              description="Main website name, tagline, description, logo, and favicon."
            >
              <div className="grid gap-5 lg:grid-cols-2">
                <Field label="Site name">
                  <input
                    className={inputClass}
                    value={settings.siteName}
                    onChange={(event) =>
                      updateField("siteName", event.target.value)
                    }
                  />
                </Field>

                <Field label="Tagline">
                  <input
                    className={inputClass}
                    value={settings.tagline}
                    onChange={(event) =>
                      updateField("tagline", event.target.value)
                    }
                  />
                </Field>

                <div className="lg:col-span-2">
                  <Field label="Description">
                    <textarea
                      className={clsx(inputClass, "min-h-32 resize-y")}
                      value={settings.description}
                      onChange={(event) =>
                        updateField("description", event.target.value)
                      }
                    />
                  </Field>
                </div>

                <Field
                  label="Logo upload"
                  hint="Recommended: transparent PNG under 1.5MB."
                >
                  <label className="group flex cursor-pointer items-center justify-between gap-3 rounded-2xl border border-dashed border-slate-300 bg-white/70 px-4 py-4 shadow-[0_10px_24px_rgba(15,23,42,0.035)] transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-300 hover:bg-cyan-50/70">
                    <span className="flex items-center gap-3 text-sm font-black text-slate-600 group-hover:text-[#062f66]">
                      <Upload
                        size={17}
                        className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:scale-110"
                      />
                      Upload logo
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(event) => handleImageUpload(event, "logoUrl")}
                    />
                  </label>
                </Field>

                <Field
                  label="Favicon upload"
                  hint="Recommended: square PNG/ICO, 512×512 or 256×256."
                >
                  <label className="group flex cursor-pointer items-center justify-between gap-3 rounded-2xl border border-dashed border-slate-300 bg-white/70 px-4 py-4 shadow-[0_10px_24px_rgba(15,23,42,0.035)] transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-300 hover:bg-cyan-50/70">
                    <span className="flex items-center gap-3 text-sm font-black text-slate-600 group-hover:text-[#062f66]">
                      <Upload
                        size={17}
                        className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:scale-110"
                      />
                      Upload favicon
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(event) =>
                        handleImageUpload(event, "faviconUrl")
                      }
                    />
                  </label>
                </Field>
              </div>
            </SectionCard>

            <SectionCard
              icon={Phone}
              title="Contact Details"
              description="Phone, emergency, WhatsApp, email, and opening hours."
            >
              <div className="grid gap-5 lg:grid-cols-2">
                <Field label="Phone number">
                  <input
                    className={inputClass}
                    value={settings.phone}
                    onChange={(event) => updateField("phone", event.target.value)}
                  />
                </Field>

                <Field label="Emergency number">
                  <input
                    className={inputClass}
                    value={settings.emergency}
                    onChange={(event) =>
                      updateField("emergency", event.target.value)
                    }
                  />
                </Field>

                <Field label="WhatsApp number">
                  <input
                    className={inputClass}
                    value={settings.whatsapp}
                    onChange={(event) =>
                      updateField("whatsapp", event.target.value)
                    }
                  />
                </Field>

                <Field label="Email address">
                  <input
                    className={inputClass}
                    value={settings.email}
                    onChange={(event) => updateField("email", event.target.value)}
                  />
                </Field>

                <div className="lg:col-span-2">
                  <Field label="Opening hours">
                    <input
                      className={inputClass}
                      value={settings.hours}
                      onChange={(event) =>
                        updateField("hours", event.target.value)
                      }
                    />
                  </Field>
                </div>
              </div>
            </SectionCard>

            <SectionCard
              icon={MapPin}
              title="Location & Map"
              description="Address, city, country, Google Map link, and embedded map URL."
            >
              <div className="grid gap-5 lg:grid-cols-2">
                <div className="lg:col-span-2">
                  <Field label="Full address">
                    <input
                      className={inputClass}
                      value={settings.address}
                      onChange={(event) =>
                        updateField("address", event.target.value)
                      }
                    />
                  </Field>
                </div>

                <Field label="City">
                  <input
                    className={inputClass}
                    value={settings.city}
                    onChange={(event) => updateField("city", event.target.value)}
                  />
                </Field>

                <Field label="Country">
                  <input
                    className={inputClass}
                    value={settings.country}
                    onChange={(event) =>
                      updateField("country", event.target.value)
                    }
                  />
                </Field>

                <div className="lg:col-span-2">
                  <Field label="Google Map URL">
                    <input
                      className={inputClass}
                      value={settings.googleMapUrl}
                      onChange={(event) =>
                        updateField("googleMapUrl", event.target.value)
                      }
                    />
                  </Field>
                </div>

                <div className="lg:col-span-2">
                  <Field
                    label="Google Map Embed URL"
                    hint="Paste only iframe src URL, not full iframe code."
                  >
                    <input
                      className={inputClass}
                      value={settings.googleMapEmbedUrl}
                      onChange={(event) =>
                        updateField("googleMapEmbedUrl", event.target.value)
                      }
                    />
                  </Field>
                </div>
              </div>
            </SectionCard>

            <SectionCard
              icon={Globe2}
              title="Social & Website Links"
              description="Public social links and official website URL."
            >
              <div className="grid gap-5 lg:grid-cols-2">
                <Field label="Facebook URL">
                  <input
                    className={inputClass}
                    value={settings.facebookUrl}
                    onChange={(event) =>
                      updateField("facebookUrl", event.target.value)
                    }
                  />
                </Field>

                <Field label="YouTube URL">
                  <input
                    className={inputClass}
                    value={settings.youtubeUrl}
                    onChange={(event) =>
                      updateField("youtubeUrl", event.target.value)
                    }
                  />
                </Field>

                <Field label="LinkedIn URL">
                  <input
                    className={inputClass}
                    value={settings.linkedinUrl}
                    onChange={(event) =>
                      updateField("linkedinUrl", event.target.value)
                    }
                  />
                </Field>

                <Field label="Website URL">
                  <input
                    className={inputClass}
                    value={settings.websiteUrl}
                    onChange={(event) =>
                      updateField("websiteUrl", event.target.value)
                    }
                  />
                </Field>
              </div>
            </SectionCard>

            <SectionCard
              icon={Search}
              title="SEO Settings"
              description="Search engine title, description, and keywords."
            >
              <div className="grid gap-5">
                <Field label="SEO title">
                  <input
                    className={inputClass}
                    value={settings.seoTitle}
                    onChange={(event) =>
                      updateField("seoTitle", event.target.value)
                    }
                  />
                </Field>

                <Field label="SEO description">
                  <textarea
                    className={clsx(inputClass, "min-h-28 resize-y")}
                    value={settings.seoDescription}
                    onChange={(event) =>
                      updateField("seoDescription", event.target.value)
                    }
                  />
                </Field>

                <Field label="SEO keywords">
                  <input
                    className={inputClass}
                    value={settings.seoKeywords}
                    onChange={(event) =>
                      updateField("seoKeywords", event.target.value)
                    }
                  />
                </Field>
              </div>
            </SectionCard>

            <SectionCard
              icon={ShieldCheck}
              title="Buttons & Footer"
              description="Global CTA buttons and footer text."
            >
              <div className="grid gap-5 lg:grid-cols-2">
                <Field label="Primary button text">
                  <input
                    className={inputClass}
                    value={settings.primaryButtonText}
                    onChange={(event) =>
                      updateField("primaryButtonText", event.target.value)
                    }
                  />
                </Field>

                <Field label="Primary button URL">
                  <input
                    className={inputClass}
                    value={settings.primaryButtonUrl}
                    onChange={(event) =>
                      updateField("primaryButtonUrl", event.target.value)
                    }
                  />
                </Field>

                <Field label="Secondary button text">
                  <input
                    className={inputClass}
                    value={settings.secondaryButtonText}
                    onChange={(event) =>
                      updateField("secondaryButtonText", event.target.value)
                    }
                  />
                </Field>

                <Field label="Secondary button URL">
                  <input
                    className={inputClass}
                    value={settings.secondaryButtonUrl}
                    onChange={(event) =>
                      updateField("secondaryButtonUrl", event.target.value)
                    }
                  />
                </Field>

                <div className="lg:col-span-2">
                  <Field label="Footer text">
                    <input
                      className={inputClass}
                      value={settings.footerText}
                      onChange={(event) =>
                        updateField("footerText", event.target.value)
                      }
                    />
                  </Field>
                </div>

                <div className="lg:col-span-2">
                  <Field label="Copyright text">
                    <input
                      className={inputClass}
                      value={settings.copyrightText}
                      onChange={(event) =>
                        updateField("copyrightText", event.target.value)
                      }
                    />
                  </Field>
                </div>
              </div>
            </SectionCard>
          </div>

          <aside className="space-y-6">
            <div className="sticky top-6 space-y-6">
              <section className="relative overflow-hidden rounded-[2rem] border border-white/75 bg-white/[0.88] p-5 shadow-[0_22px_60px_rgba(8,47,73,0.08)] ring-1 ring-slate-200/70 backdrop-blur-xl">
                <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-cyan-200/25 blur-3xl" />

                <div className="relative z-10 flex items-center gap-3">
                  <div className="settings-icon-spin grid size-11 place-items-center rounded-2xl bg-[linear-gradient(135deg,#04264d,#087ea4)] text-white shadow-[0_16px_34px_rgba(8,47,73,0.18)]">
                    <ImageIcon size={20} />
                  </div>

                  <div>
                    <h2 className="text-base font-black text-slate-950">
                      Live Preview
                    </h2>
                    <p className="text-sm text-slate-500">
                      Logo, favicon, and core identity preview.
                    </p>
                  </div>
                </div>

                <div className="relative z-10 mt-5 rounded-[1.5rem] border border-slate-200/80 bg-white/[0.78] p-4 shadow-inner">
                  <div className="flex items-center gap-4">
                    <div className="grid size-16 place-items-center overflow-hidden rounded-2xl bg-white shadow-[0_14px_30px_rgba(15,23,42,0.08)] ring-1 ring-slate-200/70">
                      {settings.logoUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={settings.logoUrl}
                          alt="Site logo"
                          className="h-full w-full object-contain p-2"
                        />
                      ) : (
                        <Building2 className="text-[#062f66]" size={28} />
                      )}
                    </div>

                    <div className="min-w-0">
                      <h3 className="truncate text-lg font-black text-slate-950">
                        {settings.siteName}
                      </h3>
                      <p className="mt-1 text-sm leading-5 text-slate-500">
                        {settings.tagline}
                      </p>
                    </div>
                  </div>

                  <p className="mt-4 text-sm leading-6 text-slate-600">
                    {settings.description}
                  </p>

                  <div className="mt-4 grid gap-2 text-sm font-bold text-slate-700">
                    <div className="flex items-center gap-2">
                      <Phone size={15} className="text-[#087ea4]" />
                      {settings.phone}
                    </div>

                    <div className="flex items-center gap-2">
                      <Mail size={15} className="text-[#087ea4]" />
                      {settings.email}
                    </div>

                    <div className="flex items-center gap-2">
                      <MapPin size={15} className="text-[#087ea4]" />
                      {settings.address}
                    </div>

                    <div className="flex items-center gap-2">
                      <Clock size={15} className="text-[#087ea4]" />
                      {settings.hours}
                    </div>
                  </div>

                  <div className="mt-5 flex gap-2">
                    <a
                      href={settings.primaryButtonUrl || "#"}
                      className="flex-1 rounded-2xl bg-[linear-gradient(135deg,#04264d,#087ea4)] px-4 py-3 text-center text-sm font-black text-white shadow-[0_14px_30px_rgba(8,47,73,0.16)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_18px_38px_rgba(8,145,178,0.24)]"
                    >
                      {settings.primaryButtonText}
                    </a>

                    <a
                      href={settings.secondaryButtonUrl || "#"}
                      className="flex-1 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-center text-sm font-black text-slate-700 transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-200 hover:text-[#062f66]"
                    >
                      {settings.secondaryButtonText}
                    </a>
                  </div>
                </div>
              </section>

              <DeveloperCreditCard />

              <section className="relative overflow-hidden rounded-[2rem] border border-white/75 bg-white/[0.88] p-5 shadow-[0_22px_60px_rgba(8,47,73,0.08)] ring-1 ring-slate-200/70 backdrop-blur-xl">
                <div className="flex items-center gap-3">
                  <div className="settings-icon-spin grid size-11 place-items-center rounded-2xl bg-[linear-gradient(135deg,#04264d,#087ea4)] text-white">
                    <MonitorCog size={20} />
                  </div>

                  <div>
                    <h2 className="text-base font-black text-slate-950">
                      Functional Actions
                    </h2>
                    <p className="text-sm leading-6 text-slate-500">
                      Save, reset, copy, export, and quick test buttons.
                    </p>
                  </div>
                </div>

                <div className="mt-5 grid gap-3">
                  <button
                    type="button"
                    onClick={handleSave}
                    className="group flex items-center justify-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#04264d,#087ea4)] px-4 py-3 text-sm font-black text-white shadow-[0_16px_34px_rgba(8,47,73,0.16)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_20px_44px_rgba(8,145,178,0.24)] active:scale-[0.98]"
                  >
                    <Save
                      size={16}
                      className="transition-transform duration-300 group-hover:rotate-6"
                    />
                    Save Settings
                  </button>

                  <button
                    type="button"
                    onClick={handleCopyJson}
                    className="group flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-200 hover:text-[#062f66] active:scale-[0.98]"
                  >
                    <Copy
                      size={16}
                      className="transition-transform duration-300 group-hover:scale-110"
                    />
                    Copy JSON
                  </button>

                  <button
                    type="button"
                    onClick={handleExportJson}
                    className="group flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 transition-all duration-300 hover:-translate-y-0.5 hover:border-cyan-200 hover:text-[#062f66] active:scale-[0.98]"
                  >
                    <Download
                      size={16}
                      className="transition-transform duration-300 group-hover:translate-y-0.5"
                    />
                    Export JSON
                  </button>

                  <a
                    href={contactLinks.whatsapp}
                    target="_blank"
                    rel="noreferrer"
                    className="group flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 transition-all duration-300 hover:-translate-y-0.5 hover:border-emerald-200 hover:text-emerald-700 active:scale-[0.98]"
                  >
                    <Phone
                      size={16}
                      className="transition-transform duration-300 group-hover:rotate-6"
                    />
                    Test WhatsApp
                  </a>

                  <button
                    type="button"
                    onClick={handleReset}
                    className="group flex items-center justify-center gap-2 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-black text-red-600 transition-all duration-300 hover:-translate-y-0.5 hover:bg-red-100 active:scale-[0.98]"
                  >
                    <RefreshCcw
                      size={16}
                      className="transition-transform duration-500 group-hover:rotate-180"
                    />
                    Reset Default
                  </button>
                </div>
              </section>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}