import ServiceManager from "@/features/admin/services/components/ServiceManager";
import {
  getAdminService,
  getAdminServices,
} from "@/features/admin/services/service";

type AdminServicesPageProps = {
  searchParams: Promise<{ edit?: string }>;
};

export default async function AdminServicesPage({
  searchParams,
}: AdminServicesPageProps) {
  const { edit } = await searchParams;
  const services = await getAdminServices();
  const selectedService = edit ? await getAdminService(edit) : null;

  return (
    <ServiceManager services={services} selectedService={selectedService} />
  );
}
