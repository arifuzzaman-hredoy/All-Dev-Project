"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Mail,
  ShieldCheck,
  ShieldQuestion,
  Stethoscope,
} from "lucide-react";
import CraftedBySignature from "@/components/brand/CraftedBySignature";

const RESET_EMAIL_KEY = "admin_reset_email";
const RESET_CODE_KEY = "admin_reset_code";
const RESET_TOKEN_KEY = "admin_reset_token";

type RequestResult = {
  ok?: boolean;
  message?: string;
  devCode?: string;
  deliveryMode?: string;
  expiresInMinutes?: number;
};

const trustItems = [
  "Real database reset code",
  "Verified code before reset",
  "Old admin sessions are cleared",
  "Webhook/email-ready delivery",
];

export default function ForgotPasswordPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [devCode, setDevCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setNotice("");
    setDevCode("");

    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail || !cleanEmail.includes("@")) {
      setError("Enter a valid admin email address.");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/admin/auth/password-reset/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: cleanEmail }),
      });
      const result = (await response.json().catch(() => null)) as RequestResult | null;

      if (!response.ok || !result?.ok) {
        throw new Error(result?.message || "Recovery request failed.");
      }

      window.sessionStorage.setItem(RESET_EMAIL_KEY, cleanEmail);
      window.sessionStorage.removeItem(RESET_CODE_KEY);
      window.sessionStorage.removeItem(RESET_TOKEN_KEY);

      if (result.devCode) {
        setDevCode(result.devCode);
        setNotice("Temporary screen delivery is enabled. Use this recovery code to continue.");
      } else {
        setNotice(result.message || "Recovery code generated. Check the configured delivery channel.");
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Recovery request failed.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="relative min-h-dvh overflow-hidden bg-[#eef6ff] px-4 py-6 text-slate-950 sm:px-6 lg:px-8">
      <div className="pointer-events-none absolute left-[-14rem] top-[-16rem] h-[36rem] w-[36rem] rounded-full bg-cyan-300/20 blur-3xl" />
      <div className="pointer-events-none absolute right-[-18rem] top-[6rem] h-[42rem] w-[42rem] rounded-full bg-blue-400/18 blur-3xl" />

      <div className="relative mx-auto grid min-h-[calc(100dvh-3rem)] w-full max-w-7xl items-center gap-6 lg:grid-cols-[1.08fr_0.92fr]">
        <section className="relative hidden overflow-hidden rounded-[32px] border border-white/70 bg-[#062f66] p-9 text-white shadow-[0_28px_76px_rgba(6,47,102,0.20)] lg:block">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_8%,rgba(103,232,249,0.22),transparent_30%),linear-gradient(135deg,rgba(255,255,255,0.10),transparent_45%)]" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.07] px-4 py-2 text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-100">
              <ShieldQuestion size={15} />
              Admin recovery
            </div>
            <div className="mt-8 max-w-3xl">
              <div className="mb-5 flex items-center gap-3 text-cyan-100">
                <Stethoscope size={26} />
                <span className="text-sm font-bold uppercase tracking-[0.22em]">
                  Update Diagnostic Center
                </span>
              </div>
              <h1 className="text-5xl font-black leading-[1.05] tracking-[-0.045em] xl:text-6xl">
                Recover access to your admin workspace.
              </h1>
              <p className="mt-5 max-w-2xl text-base leading-8 text-blue-50/90 xl:text-lg">
                This is a real backend password recovery flow with database reset tokens,
                verification, audit logs, and session cleanup.
              </p>
            </div>
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {trustItems.map((item) => (
                <div key={item} className="flex items-center gap-3 rounded-3xl border border-white/12 bg-white/[0.065] p-4 text-sm font-semibold text-blue-50">
                  <BadgeCheck size={17} className="text-cyan-100" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[590px] rounded-[32px] border border-white/80 bg-white p-5 shadow-[0_28px_76px_rgba(15,23,42,0.09)] sm:p-7 lg:p-9">
          <div className="mb-7 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <ShieldCheck className="text-[#062f66]" size={30} />
              <div>
                <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-600">
                  Password recovery
                </p>
                <h2 className="mt-1 text-3xl font-black tracking-[-0.04em] text-[#062f66] sm:text-4xl">
                  Forgot password?
                </h2>
              </div>
            </div>
            <Link href="/admin/login" className="hidden items-center gap-1.5 rounded-full border border-slate-200 px-4 py-2 text-sm font-bold text-slate-600 transition hover:bg-blue-50 hover:text-[#0b5bd3] sm:inline-flex">
              <ArrowLeft size={16} /> Login
            </Link>
          </div>

          <p className="mb-6 text-sm leading-7 text-slate-600">
            Enter the configured admin email. A short-lived recovery code will be generated
            and delivered through the configured recovery channel.
          </p>

          <form onSubmit={handleSubmit} className="grid gap-4">
            <label className="grid gap-2">
              <span className="text-sm font-bold text-slate-700">Admin email</span>
              <div className="flex h-[56px] items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 focus-within:border-[#1a73e8] focus-within:ring-4 focus-within:ring-[#1a73e8]/10">
                <Mail size={18} className="text-slate-400" />
                <input
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  type="email"
                  autoComplete="email"
                  placeholder="admin@example.com"
                  className="w-full bg-transparent text-sm font-semibold text-slate-900 outline-none placeholder:text-slate-400"
                />
              </div>
            </label>

            {error ? <p className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</p> : null}
            {notice ? <p className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">{notice}</p> : null}
            {devCode ? (
              <div className="rounded-2xl border border-cyan-200 bg-cyan-50 px-4 py-3">
                <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700">Recovery code</p>
                <p className="mt-1 font-mono text-3xl font-black tracking-[0.3em] text-[#062f66]">{devCode}</p>
              </div>
            ) : null}

            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 text-sm font-black text-white transition hover:bg-[#0b428b] disabled:cursor-not-allowed disabled:opacity-70"
            >
              {isSubmitting ? "Generating..." : "Generate recovery code"}
              <ArrowRight size={16} />
            </button>

            <button
              type="button"
              onClick={() => router.push("/admin/forgot-password/verify")}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-5 text-sm font-black text-[#062f66] transition hover:bg-slate-50"
            >
              I have a code
              <ArrowRight size={16} />
            </button>
          </form>

          <CraftedBySignature variant="login" />
        </section>
      </div>
    </main>
  );
}
