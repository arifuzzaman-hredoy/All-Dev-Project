"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowLeft,
  BadgeCheck,
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  LockKeyhole,
  ShieldCheck,
  ShieldQuestion,
  Stethoscope,
} from "lucide-react";
import CraftedBySignature from "@/components/brand/CraftedBySignature";

const RESET_EMAIL_KEY = "admin_reset_email";
const RESET_CODE_KEY = "admin_reset_code";
const RESET_TOKEN_KEY = "admin_reset_token";

type PasswordStrength = "empty" | "weak" | "medium" | "strong";

type ResetResult = {
  ok?: boolean;
  message?: string;
};

function getPasswordStrength(password: string): PasswordStrength {
  if (!password) return "empty";
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[a-z]/.test(password)) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  if (score <= 2) return "weak";
  if (score <= 4) return "medium";
  return "strong";
}

const strengthConfig: Record<PasswordStrength, { label: string; width: string; line: string; text: string }> = {
  empty: { label: "Password strength", width: "w-0", line: "bg-slate-200", text: "text-slate-400" },
  weak: { label: "Weak password", width: "w-1/3", line: "bg-red-500", text: "text-red-600" },
  medium: { label: "Medium password", width: "w-2/3", line: "bg-yellow-500", text: "text-yellow-600" },
  strong: { label: "Strong password", width: "w-full", line: "bg-green-500", text: "text-green-600" },
};

const trustItems = [
  "Password hash updates in DB",
  "Existing admin sessions cleared",
  "Reset token is single-use",
  "Audit log is recorded",
];

export default function ResetPasswordPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const savedEmail = window.sessionStorage.getItem(RESET_EMAIL_KEY) || "";
    const savedToken = window.sessionStorage.getItem(RESET_TOKEN_KEY) || "";
    setEmail(savedEmail);
    setResetToken(savedToken);
    if (!savedEmail || !savedToken) router.replace("/admin/forgot-password");
  }, [router]);

  const strength = useMemo(() => getPasswordStrength(password), [password]);
  const strengthStyle = strengthConfig[strength];
  const passwordMismatch = confirmPassword.length > 0 && password !== confirmPassword;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setSuccess("");

    if (strength === "weak" || strength === "empty") {
      setError("Use a stronger password before continuing.");
      return;
    }

    if (password.length < 12) {
      setError("Password must be at least 12 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Password and confirm password do not match.");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/admin/auth/password-reset/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, resetToken, password }),
      });
      const result = (await response.json().catch(() => null)) as ResetResult | null;

      if (!response.ok || !result?.ok) {
        throw new Error(result?.message || "Password reset failed.");
      }

      window.sessionStorage.removeItem(RESET_EMAIL_KEY);
      window.sessionStorage.removeItem(RESET_CODE_KEY);
      window.sessionStorage.removeItem(RESET_TOKEN_KEY);
      setSuccess(result.message || "Admin password updated. Please login again.");
      setPassword("");
      setConfirmPassword("");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Password reset failed.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="relative min-h-dvh overflow-hidden bg-[#eef6ff] px-4 py-6 text-slate-950 sm:px-6 lg:px-8">
      <div className="pointer-events-none absolute left-[-14rem] top-[-16rem] h-[36rem] w-[36rem] rounded-full bg-cyan-300/20 blur-3xl" />
      <div className="pointer-events-none absolute right-[-18rem] top-[6rem] h-[42rem] w-[42rem] rounded-full bg-blue-400/18 blur-3xl" />

      <div className="relative mx-auto grid min-h-[calc(100dvh-3rem)] w-full max-w-7xl items-center gap-6 lg:grid-cols-[1.08fr_0.92fr]">
        <section className="relative hidden overflow-hidden rounded-[32px] border border-white/70 bg-[#062f66] p-9 text-white shadow-[0_28px_76px_rgba(6,47,102,0.20)] lg:block">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_8%,rgba(103,232,249,0.22),transparent_30%),linear-gradient(135deg,rgba(255,255,255,0.10),transparent_45%)]" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.07] px-4 py-2 text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-100">
              <ShieldQuestion size={15} />
              Password reset
            </div>
            <div className="mt-8 max-w-3xl">
              <div className="mb-5 flex items-center gap-3 text-cyan-100">
                <Stethoscope size={26} />
                <span className="text-sm font-bold uppercase tracking-[0.22em]">
                  Update Diagnostic Center
                </span>
              </div>
              <h1 className="text-5xl font-black leading-[1.05] tracking-[-0.045em] xl:text-6xl">
                Create a stronger admin password.
              </h1>
              <p className="mt-5 max-w-2xl text-base leading-8 text-blue-50/90 xl:text-lg">
                This page updates the real admin password hash in the database and clears old sessions.
              </p>
            </div>
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {trustItems.map((item) => (
                <div key={item} className="flex items-center gap-3 rounded-3xl border border-white/12 bg-white/[0.065] p-4 text-sm font-semibold text-blue-50">
                  <BadgeCheck size={17} className="text-cyan-100" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[590px] rounded-[32px] border border-white/80 bg-white p-5 shadow-[0_28px_76px_rgba(15,23,42,0.09)] sm:p-7 lg:p-9">
          <div className="mb-7 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <LockKeyhole className="text-[#062f66]" size={30} />
              <div>
                <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-600">
                  New password
                </p>
                <h2 className="mt-1 text-3xl font-black tracking-[-0.04em] text-[#062f66] sm:text-4xl">
                  Reset password
                </h2>
              </div>
            </div>
            <Link href="/admin/forgot-password/verify" className="hidden items-center gap-1.5 rounded-full border border-slate-200 px-4 py-2 text-sm font-bold text-slate-600 transition hover:bg-blue-50 hover:text-[#0b5bd3] sm:inline-flex">
              <ArrowLeft size={16} /> Back
            </Link>
          </div>

          <form onSubmit={handleSubmit} className="grid gap-4">
            <label className="grid gap-2">
              <span className="text-sm font-bold text-slate-700">New password</span>
              <div className="flex h-[56px] items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 focus-within:border-[#1a73e8] focus-within:ring-4 focus-within:ring-[#1a73e8]/10">
                <KeyRound size={18} className="text-slate-400" />
                <input
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="Minimum 12 characters"
                  className="w-full bg-transparent text-sm font-semibold text-slate-900 outline-none placeholder:text-slate-400"
                />
                <button type="button" onClick={() => setShowPassword((value) => !value)} className="text-slate-400 hover:text-slate-700" aria-label="Toggle password visibility">
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </label>

            <div>
              <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                <div className={`h-full rounded-full ${strengthStyle.width} ${strengthStyle.line} transition-all`} />
              </div>
              <p className={`mt-2 text-xs font-black uppercase tracking-[0.16em] ${strengthStyle.text}`}>
                {strengthStyle.label}
              </p>
            </div>

            <label className="grid gap-2">
              <span className="text-sm font-bold text-slate-700">Confirm password</span>
              <div className={`flex h-[56px] items-center gap-3 rounded-2xl border bg-white px-4 focus-within:ring-4 ${passwordMismatch ? "border-red-300 focus-within:border-red-500 focus-within:ring-red-500/10" : "border-slate-200 focus-within:border-[#1a73e8] focus-within:ring-[#1a73e8]/10"}`}>
                <CheckCircle2 size={18} className={passwordMismatch ? "text-red-400" : "text-slate-400"} />
                <input
                  value={confirmPassword}
                  onChange={(event) => setConfirmPassword(event.target.value)}
                  type={showConfirmPassword ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="Retype password"
                  className="w-full bg-transparent text-sm font-semibold text-slate-900 outline-none placeholder:text-slate-400"
                />
                <button type="button" onClick={() => setShowConfirmPassword((value) => !value)} className="text-slate-400 hover:text-slate-700" aria-label="Toggle confirm password visibility">
                  {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </label>

            {error ? <p className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</p> : null}
            {success ? <p className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">{success}</p> : null}

            {success ? (
              <Link href="/admin/login" className="inline-flex h-12 items-center justify-center rounded-full bg-[#062f66] px-5 text-sm font-black text-white transition hover:bg-[#0b428b]">
                Return to login
              </Link>
            ) : (
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 text-sm font-black text-white transition hover:bg-[#0b428b] disabled:cursor-not-allowed disabled:opacity-70"
              >
                {isSubmitting ? "Updating..." : "Update password"}
                <ShieldCheck size={16} />
              </button>
            )}
          </form>

          <CraftedBySignature variant="login" />
        </section>
      </div>
    </main>
  );
}
