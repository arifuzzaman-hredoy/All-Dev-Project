import type { Metadata } from "next";
import AdminAuthGate from "@/components/admin/AdminAuthGate";

export const metadata: Metadata = {
  title: "Admin Panel | Update Diagnostic Center",
  description: "Minimal admin workspace for updating public site sections.",
};

export default function AdminLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return <AdminAuthGate>{children}</AdminAuthGate>;
}
