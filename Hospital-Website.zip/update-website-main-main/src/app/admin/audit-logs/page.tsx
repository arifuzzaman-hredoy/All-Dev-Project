import { redirect } from "next/navigation";
import { Activity, Database, ShieldCheck } from "lucide-react";
import { hasAdminSession } from "@/lib/admin-session";
import { getAuditLogs } from "@/lib/audit-log";

type AuditLogRow = Awaited<ReturnType<typeof getAuditLogs>>[number];

export const dynamic = "force-dynamic";

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function formatMetadata(metadata: unknown) {
  if (!metadata) return "—";

  try {
    return JSON.stringify(metadata, null, 2);
  } catch {
    return String(metadata);
  }
}

export default async function AdminAuditLogsPage() {
  if (!(await hasAdminSession())) {
    redirect("/admin/login");
  }

  const logs: AuditLogRow[] = await getAuditLogs({ take: 120 });

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-[32px] bg-[#062f66] px-6 py-8 text-white shadow-[0_28px_65px_rgba(6,47,102,0.18)] sm:px-8 lg:px-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(91,192,222,0.22),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(140,198,63,0.16),transparent_34%)]" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <p className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-200">
              <ShieldCheck size={16} /> Security audit
            </p>
            <h1 className="mt-3 text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
              Admin audit log
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base">
              Track login events, content changes, delete actions, status updates,
              uploads, and key admin activity from one protected view.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
              <p className="text-2xl font-black">{logs.length}</p>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">
                latest logs
              </p>
            </div>
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
              <p className="text-2xl font-black">
                {new Set(logs.map((log: AuditLogRow) => log.entity)).size}
              </p>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">
                entities
              </p>
            </div>
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
              <p className="text-2xl font-black">
                {new Set(logs.map((log: AuditLogRow) => log.adminId || "system")).size}
              </p>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">
                actors
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-[0_18px_50px_rgba(15,23,42,0.06)]">
        <div className="flex flex-col gap-3 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
              <Activity size={15} /> Latest activity
            </p>
            <h2 className="mt-1 text-xl font-black text-[#062f66]">
              Recent admin actions
            </h2>
          </div>
          <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-4 py-2 text-xs font-bold text-slate-600">
            <Database size={14} /> DB-backed
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1050px] w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase tracking-[0.14em] text-slate-500">
              <tr>
                <th className="px-5 py-4 font-black">Time</th>
                <th className="px-5 py-4 font-black">Admin</th>
                <th className="px-5 py-4 font-black">Action</th>
                <th className="px-5 py-4 font-black">Entity</th>
                <th className="px-5 py-4 font-black">IP</th>
                <th className="px-5 py-4 font-black">Metadata</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-slate-500">
                    No audit records yet.
                  </td>
                </tr>
              ) : (
                logs.map((log: AuditLogRow) => (
                  <tr key={log.id} className="align-top hover:bg-slate-50/70">
                    <td className="whitespace-nowrap px-5 py-4 font-semibold text-slate-700">
                      {formatDate(log.createdAt)}
                    </td>
                    <td className="px-5 py-4">
                      <p className="font-bold text-[#062f66]">
                        {log.admin?.name || log.admin?.email || "System/Unknown"}
                      </p>
                      <p className="mt-1 text-xs text-slate-500">
                        {log.admin?.email || "—"}
                      </p>
                    </td>
                    <td className="px-5 py-4">
                      <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-black uppercase tracking-[0.08em] text-blue-700">
                        {log.action}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <p className="font-bold text-slate-800">{log.entity}</p>
                      <p className="mt-1 max-w-[180px] truncate text-xs text-slate-500">
                        {log.entityId || "—"}
                      </p>
                    </td>
                    <td className="whitespace-nowrap px-5 py-4 text-slate-600">
                      {log.ipAddress || "—"}
                    </td>
                    <td className="px-5 py-4">
                      <pre className="max-h-28 max-w-[340px] overflow-auto whitespace-pre-wrap rounded-2xl bg-slate-950 px-3 py-2 text-xs leading-5 text-slate-100">
                        {formatMetadata(log.metadata)}
                      </pre>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
