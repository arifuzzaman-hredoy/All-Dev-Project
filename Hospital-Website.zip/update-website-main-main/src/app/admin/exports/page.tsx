"use client";

import {
  Database,
  Download,
  FileSpreadsheet,
  FileText,
  Printer,
  ShieldCheck,
} from "lucide-react";

type ExportEntity = {
  key: "appointments" | "form-submissions" | "package-bookings" | "sms-logs";
  title: string;
  description: string;
  rowsHint: string;
};

const exportEntities: ExportEntity[] = [
  {
    key: "appointments",
    title: "Appointments",
    description:
      "Export all public and manual appointment requests with patient, doctor, room, source, and SMS status.",
    rowsHint: "Appointment table",
  },
  {
    key: "form-submissions",
    title: "Form Submissions",
    description:
      "Export contact, career, support, online report, package, and appointment mirror submissions.",
    rowsHint: "Central form inbox",
  },
  {
    key: "package-bookings",
    title: "Package Bookings",
    description:
      "Export health package booking requests with patient, payment, package, and SMS status.",
    rowsHint: "Package request table",
  },
  {
    key: "sms-logs",
    title: "SMS Logs",
    description:
      "Export SMS delivery history including phone, template, provider, status, retry count, and errors.",
    rowsHint: "SMS audit table",
  },
];

const formats = [
  {
    key: "csv",
    label: "CSV",
    icon: FileText,
    text: "Best for simple spreadsheet import.",
  },
  {
    key: "excel",
    label: "Excel",
    icon: FileSpreadsheet,
    text: "Excel-compatible .xls download.",
  },
  {
    key: "print",
    label: "Print / PDF",
    icon: Printer,
    text: "Open printable HTML and save as PDF.",
  },
];

function exportUrl(entity: ExportEntity["key"], format: string) {
  return `/api/admin/exports/${entity}?format=${format}`;
}

export default function AdminExportsPage() {
  return (
    <div className="space-y-6">
      <section className="rounded-[30px] border border-[#dbe8ff] bg-gradient-to-br from-white via-[#f8fcff] to-[#eaf7ff] p-6 shadow-[0_18px_55px_rgba(6,47,102,0.08)]">
        <p className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs font-black uppercase tracking-[0.16em] text-[#1597c7] shadow-sm">
          <Database size={15} />
          Export Center
        </p>

        <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_280px] lg:items-end">
          <div>
            <h1 className="text-3xl font-black tracking-tight text-[#062f66]">
              Admin Data Export
            </h1>

            <p className="mt-3 max-w-3xl text-sm font-semibold leading-7 text-slate-600">
              Download important admin data as CSV, Excel-compatible file, or
              printable PDF-ready HTML. Every export is saved in ExportAudit for
              future tracking.
            </p>
          </div>

          <div className="rounded-2xl border border-[#cfeaff] bg-white p-4">
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-2xl bg-[#eaf7ff] text-[#1597c7]">
                <ShieldCheck size={20} />
              </span>
              <div>
                <p className="text-sm font-black text-[#062f66]">
                  Admin only access
                </p>
                <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                  Export APIs require active admin session and are not public.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-4">
        {exportEntities.map((entity) => (
          <article
            key={entity.key}
            className="rounded-[26px] border border-[#dbe8ff] bg-white p-5 shadow-[0_14px_45px_rgba(6,47,102,0.06)]"
          >
            <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.14em] text-[#43c7f4]">
                  {entity.rowsHint}
                </p>

                <h2 className="mt-2 text-xl font-black text-[#062f66]">
                  {entity.title}
                </h2>

                <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-slate-600">
                  {entity.description}
                </p>
              </div>

              <div className="grid gap-2 sm:grid-cols-3 lg:min-w-[520px]">
                {formats.map((format) => {
                  const Icon = format.icon;

                  return (
                    <a
                      key={format.key}
                      href={exportUrl(entity.key, format.key)}
                      target={format.key === "print" ? "_blank" : undefined}
                      rel={format.key === "print" ? "noopener noreferrer" : undefined}
                      className="group rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] p-3 transition hover:-translate-y-0.5 hover:border-[#43c7f4] hover:bg-white hover:shadow-lg"
                    >
                      <div className="flex items-center gap-2">
                        <span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[#1597c7] shadow-sm group-hover:bg-[#43c7f4] group-hover:text-white">
                          <Icon size={18} />
                        </span>

                        <span className="text-sm font-black text-[#062f66]">
                          {format.label}
                        </span>
                      </div>

                      <p className="mt-2 text-xs font-semibold leading-5 text-slate-500">
                        {format.text}
                      </p>
                    </a>
                  );
                })}
              </div>
            </div>
          </article>
        ))}
      </section>

      <section className="rounded-[24px] border border-amber-200 bg-amber-50 p-4 text-sm font-bold leading-6 text-amber-800">
        <div className="flex items-start gap-2">
          <Download className="mt-0.5 shrink-0" size={18} />
          <p>
            Excel button downloads an Excel-compatible .xls file. Print / PDF
            opens a printable page; use browser Print and choose Save as PDF.
          </p>
        </div>
      </section>
    </div>
  );
}
