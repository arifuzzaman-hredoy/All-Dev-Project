import CareerAdminPanel from "@/components/admin/CareerAdminPanel";
import CareerDbApplications from "@/components/admin/CareerDbApplications";

export default function AdminCareerPage() {
  return (
    <>
      <CareerDbApplications />
      <CareerAdminPanel />
    </>
  );
}
