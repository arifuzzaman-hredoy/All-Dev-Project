"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  Loader2,
  MessageSquareText,
  RefreshCcw,
  Repeat2,
  Search,
  XCircle,
} from "lucide-react";

type SmsStatus = "PENDING" | "SENT" | "FAILED" | "DISABLED" | "SKIPPED";

type AdminSmsLog = {
  id: string;
  phone: string;
  message: string;
  provider: string;
  status: SmsStatus;
  templateKey: string;
  relatedFormType: string;
  relatedRecordId: string;
  retryCount: number;
  providerMessageId: string;
  providerResponse: unknown;
  errorMessage: string;
  sentAt: string;
  createdAt: string;
  updatedAt: string;
};

function formatDate(value: string) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function statusClass(status: SmsStatus) {
  switch (status) {
    case "SENT":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "FAILED":
      return "border-red-200 bg-red-50 text-red-700";
    case "DISABLED":
      return "border-amber-200 bg-amber-50 text-amber-700";
    case "SKIPPED":
      return "border-slate-200 bg-slate-100 text-slate-600";
    default:
      return "border-sky-200 bg-sky-50 text-sky-700";
  }
}

function statusIcon(status: SmsStatus) {
  if (status === "SENT") return <CheckCircle2 size={15} />;
  if (status === "FAILED") return <XCircle size={15} />;
  if (status === "DISABLED") return <AlertTriangle size={15} />;
  return <Clock3 size={15} />;
}

export default function SmsLogsAdminPage() {
  const [logs, setLogs] = useState<AdminSmsLog[]>([]);
  const [selectedLog, setSelectedLog] = useState<AdminSmsLog | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [loading, setLoading] = useState(true);
  const [resendingId, setResendingId] = useState("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const stats = useMemo(() => {
    return {
      total: logs.length,
      sent: logs.filter((log) => log.status === "SENT").length,
      failed: logs.filter((log) => log.status === "FAILED").length,
      disabled: logs.filter((log) => log.status === "DISABLED").length,
      pending: logs.filter((log) => log.status === "PENDING").length,
    };
  }, [logs]);

  const filteredLogs = useMemo(() => {
    const query = search.trim().toLowerCase();

    return logs.filter((log) => {
      const statusMatch =
        statusFilter === "ALL" ? true : log.status === statusFilter;

      const searchMatch = query
        ? [
            log.phone,
            log.message,
            log.provider,
            log.status,
            log.templateKey,
            log.relatedFormType,
            log.relatedRecordId,
            log.errorMessage,
          ].some((value) => value.toLowerCase().includes(query))
        : true;

      return statusMatch && searchMatch;
    });
  }, [logs, search, statusFilter]);

  async function loadLogs() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/admin/sms-logs", {
        cache: "no-store",
      });

      if (!response.ok) throw new Error("SMS logs could not be loaded.");

      const data = (await response.json()) as { logs: AdminSmsLog[] };
      setLogs(data.logs || []);
    } catch (caught) {
      setError(
        caught instanceof Error ? caught.message : "SMS logs could not be loaded.",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadLogs();
  }, []);

  async function resendLog(log: AdminSmsLog) {
    setResendingId(log.id);
    setNotice("");
    setError("");

    try {
      const response = await fetch(`/api/admin/sms-logs/${log.id}/resend`, {
        method: "POST",
      });

      const data = (await response.json().catch(() => null)) as {
        log?: AdminSmsLog;
        message?: string;
      } | null;

      if (!response.ok || !data?.log) {
        throw new Error(data?.message || "SMS resend failed.");
      }

      setLogs((current) =>
        current.map((item) => (item.id === data.log?.id ? data.log : item)),
      );
      setSelectedLog(data.log);
      setNotice(`SMS resend completed with status: ${data.log.status}`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "SMS resend failed.");
    } finally {
      setResendingId("");
    }
  }

  return (
    <div className="space-y-5">
      <section>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full bg-[#eaf7ff] px-3 py-1 text-xs font-black uppercase tracking-[0.16em] text-[#1597c7]">
              <MessageSquareText size={15} />
              SMS Delivery
            </p>

            <h1 className="mt-3 text-2xl font-black text-[#062f66]">
              SMS Logs
            </h1>

            <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-slate-600">
              Track every SMS created by appointment, package booking, contact,
              support, and career forms. Failed or disabled logs can be resent
              when SMS service is enabled.
            </p>
          </div>

          <button
            type="button"
            onClick={() => void loadLogs()}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-slate-200 bg-white px-4 text-sm font-black text-[#062f66] shadow-sm transition hover:-translate-y-0.5 hover:border-[#43c7f4]"
          >
            <RefreshCcw size={17} />
            Refresh
          </button>
        </div>
      </section>

      <section className="grid gap-3 md:grid-cols-5">
        {[
          ["Total", stats.total],
          ["Sent", stats.sent],
          ["Failed", stats.failed],
          ["Disabled", stats.disabled],
          ["Pending", stats.pending],
        ].map(([label, value]) => (
          <div
            key={label}
            className="rounded-2xl border border-[#dbe8ff] bg-white p-4 shadow-sm"
          >
            <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
              {label}
            </p>
            <p className="mt-2 text-2xl font-black text-[#062f66]">{value}</p>
          </div>
        ))}
      </section>

      {notice ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-black text-emerald-700">
          {notice}
        </div>
      ) : null}

      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-black text-red-700">
          {error}
        </div>
      ) : null}

      <section className="rounded-[26px] border border-[#dbe8ff] bg-white p-4 shadow-[0_18px_55px_rgba(6,47,102,0.07)]">
        <div className="mb-4 grid gap-3 lg:grid-cols-[1fr_180px]">
          <label className="flex h-11 items-center gap-2 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-3">
            <Search size={17} className="text-slate-400" />
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search phone, template, status, message..."
              className="w-full bg-transparent text-sm font-semibold text-[#062f66] outline-none placeholder:text-slate-400"
            />
          </label>

          <select
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value)}
            className="h-11 rounded-2xl border border-[#dbe8ff] bg-[#f8fbff] px-3 text-sm font-black text-[#062f66] outline-none"
          >
            <option value="ALL">All status</option>
            <option value="SENT">Sent</option>
            <option value="FAILED">Failed</option>
            <option value="DISABLED">Disabled</option>
            <option value="PENDING">Pending</option>
            <option value="SKIPPED">Skipped</option>
          </select>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 rounded-2xl bg-slate-50 py-12 text-sm font-black text-slate-500">
            <Loader2 className="animate-spin" size={18} />
            Loading SMS logs...
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-[1180px] w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-xs font-black uppercase tracking-[0.12em] text-slate-400">
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3">Phone</th>
                  <th className="px-3 py-3">Template</th>
                  <th className="px-3 py-3">Message</th>
                  <th className="px-3 py-3">Provider</th>
                  <th className="px-3 py-3">Retry</th>
                  <th className="px-3 py-3">Created</th>
                  <th className="px-3 py-3 text-right">Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredLogs.map((log) => (
                  <tr
                    key={log.id}
                    className="border-b border-slate-100 align-top text-slate-600"
                  >
                    <td className="px-3 py-4">
                      <span
                        className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-black ${statusClass(
                          log.status,
                        )}`}
                      >
                        {statusIcon(log.status)}
                        {log.status}
                      </span>
                    </td>
                    <td className="px-3 py-4 font-black text-[#062f66]">
                      {log.phone}
                    </td>
                    <td className="px-3 py-4">
                      <span className="rounded-full bg-[#f0fbff] px-2 py-1 font-mono text-xs font-black text-[#1597c7]">
                        {log.templateKey || "-"}
                      </span>
                    </td>
                    <td className="px-3 py-4">
                      <p className="line-clamp-2 max-w-[320px] font-semibold leading-6">
                        {log.message}
                      </p>
                      {log.errorMessage ? (
                        <p className="mt-1 line-clamp-1 text-xs font-bold text-red-600">
                          {log.errorMessage}
                        </p>
                      ) : null}
                    </td>
                    <td className="px-3 py-4 font-semibold">{log.provider}</td>
                    <td className="px-3 py-4 font-black">{log.retryCount}</td>
                    <td className="px-3 py-4 font-semibold">
                      {formatDate(log.createdAt)}
                    </td>
                    <td className="px-3 py-4">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedLog(log)}
                          className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-black text-[#062f66] transition hover:border-[#43c7f4]"
                        >
                          View
                        </button>

                        <button
                          type="button"
                          onClick={() => void resendLog(log)}
                          disabled={resendingId === log.id}
                          className="inline-flex items-center gap-1 rounded-full bg-[#43c7f4] px-3 py-1.5 text-xs font-black text-white transition hover:bg-[#17a9de] disabled:opacity-60"
                        >
                          {resendingId === log.id ? (
                            <Loader2 className="animate-spin" size={13} />
                          ) : (
                            <Repeat2 size={13} />
                          )}
                          Resend
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {filteredLogs.length === 0 ? (
                  <tr>
                    <td
                      colSpan={8}
                      className="px-3 py-12 text-center text-sm font-black text-slate-400"
                    >
                      No SMS logs found.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {selectedLog ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/40 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-[28px] bg-white p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.16em] text-[#43c7f4]">
                  SMS Log Details
                </p>
                <h2 className="mt-1 text-xl font-black text-[#062f66]">
                  {selectedLog.phone}
                </h2>
              </div>

              <button
                type="button"
                onClick={() => setSelectedLog(null)}
                className="rounded-full border border-slate-200 px-3 py-1.5 text-xs font-black text-slate-500"
              >
                Close
              </button>
            </div>

            <div className="mt-4 grid gap-4">
              <div className="grid gap-3 md:grid-cols-3">
                <div className="rounded-2xl bg-slate-50 p-3">
                  <p className="text-xs font-black text-slate-400">Status</p>
                  <p className="mt-1 font-black text-[#062f66]">
                    {selectedLog.status}
                  </p>
                </div>
                <div className="rounded-2xl bg-slate-50 p-3">
                  <p className="text-xs font-black text-slate-400">Provider</p>
                  <p className="mt-1 font-black text-[#062f66]">
                    {selectedLog.provider}
                  </p>
                </div>
                <div className="rounded-2xl bg-slate-50 p-3">
                  <p className="text-xs font-black text-slate-400">Retry</p>
                  <p className="mt-1 font-black text-[#062f66]">
                    {selectedLog.retryCount}
                  </p>
                </div>
              </div>

              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-[0.12em] text-slate-400">
                  Message
                </p>
                <p className="mt-2 whitespace-pre-wrap text-sm font-semibold leading-7 text-slate-700">
                  {selectedLog.message}
                </p>
              </div>

              {selectedLog.errorMessage ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 p-4">
                  <p className="text-xs font-black uppercase tracking-[0.12em] text-red-500">
                    Error
                  </p>
                  <p className="mt-2 text-sm font-bold leading-6 text-red-700">
                    {selectedLog.errorMessage}
                  </p>
                </div>
              ) : null}

              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-[0.12em] text-slate-400">
                  Provider response
                </p>
                <pre className="mt-2 max-h-64 overflow-auto whitespace-pre-wrap rounded-xl bg-white p-3 text-xs font-semibold text-slate-600">
                  {JSON.stringify(selectedLog.providerResponse || {}, null, 2)}
                </pre>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
