import { redirect } from "next/navigation";
import {
  BadgeCheck,
  Database,
  FileCheck2,
  Layers3,
  PlugZap,
  ShieldCheck,
} from "lucide-react";

import { hasAdminSession } from "@/lib/admin-session";
import { getFrontendBackendSupportReport } from "@/lib/frontend-backend-support";

export const dynamic = "force-dynamic";

type Status = "ready" | "configured" | "pending-config" | "needs-attention";

const statusCopy: Record<Status, { label: string; className: string }> = {
  ready: {
    label: "Ready",
    className: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  },
  configured: {
    label: "Configured",
    className: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  },
  "pending-config": {
    label: "Pending config",
    className: "bg-amber-50 text-amber-700 ring-amber-200",
  },
  "needs-attention": {
    label: "Needs attention",
    className: "bg-red-50 text-red-700 ring-red-200",
  },
};

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

export default async function AdminFrontendSupportPage() {
  if (!(await hasAdminSession())) {
    redirect("/admin/login");
  }

  const report = await getFrontendBackendSupportReport();

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-[32px] bg-[#062f66] px-6 py-8 text-white shadow-[0_28px_65px_rgba(6,47,102,0.18)] sm:px-8 lg:px-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(91,192,222,0.22),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(140,198,63,0.16),transparent_34%)]" />
        <div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <p className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-200">
              <PlugZap size={16} /> Phase 8.5 backend support
            </p>
            <h1 className="mt-3 text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
              Frontend feature backend support
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base">
              This protected view confirms that frontend developer features have
              real backend, database, logging, and production support instead of
              fake localStorage-only workflows.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
              <p className="text-2xl font-black">{report.summary.readyChecks}</p>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">
                ready
              </p>
            </div>
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
              <p className="text-2xl font-black">{report.summary.pendingConfigChecks}</p>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">
                pending
              </p>
            </div>
            <div className="rounded-3xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
              <p className="text-2xl font-black">{report.summary.needsAttentionChecks}</p>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">
                issues
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Static pages", value: report.counts.staticPages, Icon: Database },
          { label: "Submissions", value: report.counts.allSubmissions, Icon: FileCheck2 },
          { label: "SMS logs", value: report.counts.smsLogs, Icon: PlugZap },
          { label: "Audit logs", value: report.counts.auditLogs, Icon: ShieldCheck },
        ].map(({ label, value, Icon }) => (
          <div
            key={label}
            className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_50px_rgba(15,23,42,0.06)]"
          >
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">
                {label}
              </p>
              <span className="inline-flex size-10 items-center justify-center rounded-2xl bg-[#f0f7ff] text-[#062f66]">
                <Icon size={18} />
              </span>
            </div>
            <p className="mt-4 text-3xl font-black text-[#062f66]">
              {value.toLocaleString("en-GB")}
            </p>
          </div>
        ))}
      </section>

      <section className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-[0_18px_50px_rgba(15,23,42,0.06)]">
        <div className="flex flex-col gap-3 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
              <Layers3 size={15} /> Feature support matrix
            </p>
            <h2 className="mt-1 text-xl font-black text-[#062f66]">
              Frontend-to-backend readiness
            </h2>
          </div>
          <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-4 py-2 text-xs font-bold text-slate-600">
            <BadgeCheck size={14} /> Generated {formatDate(report.generatedAt)}
          </span>
        </div>

        <div className="grid gap-4 p-5 lg:grid-cols-2">
          {report.checks.map((check) => {
            const status = statusCopy[check.status];
            return (
              <article
                key={check.key}
                className="rounded-[24px] border border-slate-200 bg-slate-50/70 p-5 transition hover:border-[#c8dcff] hover:bg-white hover:shadow-[0_16px_36px_rgba(15,23,42,0.06)]"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <h3 className="text-lg font-black text-[#062f66]">
                      {check.title}
                    </h3>
                    <p className="mt-1 text-sm font-semibold leading-6 text-slate-500">
                      {check.frontendFeature}
                    </p>
                  </div>
                  <span
                    className={`inline-flex shrink-0 items-center justify-center rounded-full px-3 py-1 text-xs font-black uppercase tracking-[0.08em] ring-1 ${status.className}`}
                  >
                    {status.label}
                  </span>
                </div>

                <div className="mt-4 grid gap-3 text-sm">
                  <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
                    <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
                      Backend
                    </p>
                    <p className="mt-1 font-bold leading-6 text-slate-700">
                      {check.backendSupport}
                    </p>
                  </div>
                  <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
                    <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
                      Database
                    </p>
                    <p className="mt-1 font-bold leading-6 text-slate-700">
                      {check.databaseSupport}
                    </p>
                  </div>
                </div>

                <ul className="mt-4 space-y-2">
                  {check.evidence.map((item) => (
                    <li
                      key={item}
                      className="flex gap-2 text-sm font-semibold leading-6 text-slate-600"
                    >
                      <span className="mt-2 size-1.5 shrink-0 rounded-full bg-[#8cc63f]" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
}
