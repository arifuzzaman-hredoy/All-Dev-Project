"use client";

import { useEffect, useMemo, useState } from "react";

type FormSubmissionStatus =
  | "NEW"
  | "READ"
  | "IN_PROGRESS"
  | "RESOLVED"
  | "ARCHIVED"
  | "SPAM";

type AdminFormSubmission = {
  id: string;
  formType: string;
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
  payload: unknown;
  status: FormSubmissionStatus;
  source: string;
  ipAddress: string;
  userAgent: string;
  createdAt: string;
  updatedAt: string;
};

const statusOptions: FormSubmissionStatus[] = [
  "NEW",
  "READ",
  "IN_PROGRESS",
  "RESOLVED",
  "ARCHIVED",
  "SPAM",
];

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

export default function AdminFormSubmissionsPage() {
  const [submissions, setSubmissions] = useState<AdminFormSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [formType, setFormType] = useState("ALL");
  const [status, setStatus] = useState("ALL");
  const [selected, setSelected] = useState<AdminFormSubmission | null>(null);
  const [toast, setToast] = useState("");

  async function loadSubmissions() {
    const response = await fetch("/api/admin/form-submissions", {
      cache: "no-store",
    });

    if (!response.ok) {
      throw new Error("Failed to load form submissions.");
    }

    const data = (await response.json()) as {
      submissions: AdminFormSubmission[];
    };

    setSubmissions(data.submissions);
  }

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  useEffect(() => {
    let active = true;

    loadSubmissions()
      .catch(() => showToast("Failed to load form submissions."))
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const formTypes = useMemo(() => {
    return Array.from(new Set(submissions.map((item) => item.formType))).sort();
  }, [submissions]);

  const filteredSubmissions = useMemo(() => {
    const keyword = search.toLowerCase().trim();

    return submissions.filter((item) => {
      if (formType !== "ALL" && item.formType !== formType) return false;
      if (status !== "ALL" && item.status !== status) return false;

      if (!keyword) return true;

      return [
        item.formType,
        item.name,
        item.phone,
        item.email,
        item.subject,
        item.message,
        item.status,
        item.source,
      ]
        .join(" ")
        .toLowerCase()
        .includes(keyword);
    });
  }, [formType, search, status, submissions]);

  async function updateStatus(id: string, nextStatus: FormSubmissionStatus) {
    const response = await fetch(`/api/admin/form-submissions/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });

    if (!response.ok) {
      showToast("Status update failed.");
      return;
    }

    await loadSubmissions();
    showToast(`Status updated: ${nextStatus}`);
  }

  async function archiveSubmission(id: string) {
    if (!window.confirm("Archive this form submission?")) return;

    const response = await fetch(`/api/admin/form-submissions/${id}`, {
      method: "DELETE",
    });

    if (!response.ok) {
      showToast("Archive failed.");
      return;
    }

    await loadSubmissions();
    showToast("Submission archived.");
  }

  if (loading) {
    return (
      <main className="grid min-h-[60vh] place-items-center text-center">
        <div>
          <h1 className="text-2xl font-black text-[#062f66]">
            Loading form submissions...
          </h1>
          <p className="mt-2 text-sm font-semibold text-slate-600">
            Database theke form submission load hocche.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="space-y-5">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 rounded-xl bg-[#062f66] px-4 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section>
        <h1 className="text-2xl font-black text-[#062f66]">
          Form Submissions
        </h1>
        <p className="mt-2 max-w-3xl text-sm text-slate-600">
          Appointment, package booking, contact, career, support, and online
          report requests will be stored here.
        </p>
      </section>

      <section className="grid gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-4">
        <div className="rounded-xl bg-slate-50 p-4">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
            Total
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {submissions.length}
          </p>
        </div>
        <div className="rounded-xl bg-slate-50 p-4">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
            Showing
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {filteredSubmissions.length}
          </p>
        </div>
        <div className="rounded-xl bg-slate-50 p-4">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
            New
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {submissions.filter((item) => item.status === "NEW").length}
          </p>
        </div>
        <div className="rounded-xl bg-slate-50 p-4">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
            Archived
          </p>
          <p className="mt-2 text-2xl font-black text-[#062f66]">
            {submissions.filter((item) => item.status === "ARCHIVED").length}
          </p>
        </div>
      </section>

      <section className="grid gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-[1fr_220px_220px]">
        <input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search by name, phone, email, subject, status..."
          className="h-11 rounded-xl border border-slate-200 px-3 text-sm font-semibold outline-none focus:border-[#25a6dc]"
        />

        <select
          value={formType}
          onChange={(event) => setFormType(event.target.value)}
          className="h-11 rounded-xl border border-slate-200 px-3 text-sm font-bold outline-none focus:border-[#25a6dc]"
        >
          <option value="ALL">All form types</option>
          {formTypes.map((item) => (
            <option key={item} value={item}>
              {item.replaceAll("_", " ")}
            </option>
          ))}
        </select>

        <select
          value={status}
          onChange={(event) => setStatus(event.target.value)}
          className="h-11 rounded-xl border border-slate-200 px-3 text-sm font-bold outline-none focus:border-[#25a6dc]"
        >
          <option value="ALL">All status</option>
          {statusOptions.map((item) => (
            <option key={item} value={item}>
              {item.replaceAll("_", " ")}
            </option>
          ))}
        </select>
      </section>

      <section className="overflow-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="min-w-full border-collapse text-left text-sm">
          <thead className="bg-slate-50 text-xs font-black uppercase tracking-[0.12em] text-slate-500">
            <tr>
              <th className="p-3">Date</th>
              <th className="p-3">Type</th>
              <th className="p-3">Name</th>
              <th className="p-3">Phone</th>
              <th className="p-3">Email</th>
              <th className="p-3">Subject</th>
              <th className="p-3">Status</th>
              <th className="p-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredSubmissions.map((item) => (
              <tr key={item.id} className="border-t border-slate-100 align-top">
                <td className="p-3 font-semibold text-slate-600">
                  {formatDateTime(item.createdAt)}
                </td>
                <td className="p-3 font-black text-[#062f66]">
                  {item.formType.replaceAll("_", " ")}
                </td>
                <td className="p-3 font-semibold">{item.name || "-"}</td>
                <td className="p-3 font-semibold">{item.phone || "-"}</td>
                <td className="p-3 font-semibold">{item.email || "-"}</td>
                <td className="max-w-[260px] p-3 font-semibold">
                  {item.subject || item.message || "-"}
                </td>
                <td className="p-3">
                  <select
                    value={item.status}
                    onChange={(event) =>
                      updateStatus(
                        item.id,
                        event.target.value as FormSubmissionStatus
                      )
                    }
                    className="h-9 rounded-lg border border-slate-200 px-2 text-xs font-black"
                  >
                    {statusOptions.map((option) => (
                      <option key={option} value={option}>
                        {option.replaceAll("_", " ")}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="space-y-2 p-3">
                  <button
                    type="button"
                    onClick={() => setSelected(item)}
                    className="block rounded-lg bg-[#062f66] px-3 py-2 text-xs font-black text-white"
                  >
                    View
                  </button>
                  <button
                    type="button"
                    onClick={() => archiveSubmission(item.id)}
                    className="block rounded-lg border border-slate-200 px-3 py-2 text-xs font-black text-slate-700"
                  >
                    Archive
                  </button>
                </td>
              </tr>
            ))}

            {filteredSubmissions.length === 0 ? (
              <tr>
                <td className="p-6 text-center font-bold text-slate-500" colSpan={8}>
                  No form submissions found.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </section>

      {selected ? (
        <section className="fixed inset-0 z-50 grid place-items-center bg-slate-950/40 p-4">
          <div className="max-h-[88vh] w-full max-w-4xl overflow-auto rounded-2xl bg-white p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-xl font-black text-[#062f66]">
                  Submission Details
                </h2>
                <p className="mt-1 text-sm font-semibold text-slate-500">
                  {selected.formType.replaceAll("_", " ")} •{" "}
                  {formatDateTime(selected.createdAt)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-black"
              >
                Close
              </button>
            </div>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {[
                ["Name", selected.name || "-"],
                ["Phone", selected.phone || "-"],
                ["Email", selected.email || "-"],
                ["Subject", selected.subject || "-"],
                ["Message", selected.message || "-"],
                ["Source", selected.source || "-"],
                ["IP", selected.ipAddress || "-"],
                ["User Agent", selected.userAgent || "-"],
              ].map(([label, value]) => (
                <div key={label} className="rounded-xl bg-slate-50 p-3">
                  <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">
                    {label}
                  </p>
                  <p className="mt-1 break-words text-sm font-semibold text-slate-800">
                    {value}
                  </p>
                </div>
              ))}
            </div>

            <pre className="mt-4 max-h-[320px] overflow-auto rounded-xl bg-slate-950 p-4 text-xs text-white">
              {JSON.stringify(selected.payload, null, 2)}
            </pre>
          </div>
        </section>
      ) : null}
    </main>
  );
}
