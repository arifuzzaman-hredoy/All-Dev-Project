import Link from "next/link";
import { ArrowRight } from "lucide-react";

const homeSections = [
  {
    label: "Hero Banner",
    href: "/admin/sections/home-hero",
    helper: "Headline, summary, and CTA text",
  },
  {
    label: "Quick Actions",
    href: "/admin/sections/home-quick-actions",
    helper: "Five shortcut cards on the landing page",
  },
  {
    label: "Why Choose",
    href: "/admin/sections/home-why-choose",
    helper: "Intro text and value bullets",
  },
  {
    label: "Specialities",
    href: "/admin/sections/home-specialities",
    helper: "Featured speciality titles and copy",
  },
  {
    label: "Doctors",
    href: "/admin/sections/home-doctors",
    helper: "Doctor preview cards and availability",
  },
  {
    label: "News",
    href: "/admin/sections/home-news",
    helper: "Announcement copy for the homepage",
  },
  {
    label: "Blogs",
    href: "/admin/sections/home-blogs",
    helper: "Blog teaser titles and summaries",
  },
  {
    label: "Corporate services",
    href: "/admin/sections/home-corporate-services",
    helper: "Corporate cards and intro copy",
  },
];

export default function HomeAdminPage() {
  return (
    <div className="space-y-6">
      <section className="rounded-[30px] border border-slate-200 bg-white p-6 shadow-[0_16px_40px_rgba(15,23,42,0.05)] sm:p-8">
        <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
          Homepage
        </p>
        <h1 className="mt-2 text-3xl font-black text-[#062f66]">
          Home page sections
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-600 sm:text-base">
          Use one file per section so you can keep the homepage content
          organized. The public page stays readable and each block is easy to
          copy back into the source.
        </p>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        {homeSections.map((section) => (
          <Link
            key={section.href}
            href={section.href}
            className="group rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_16px_40px_rgba(15,23,42,0.05)] transition hover:-translate-y-1 hover:border-[#5bc0de]/30 hover:shadow-[0_20px_50px_rgba(15,23,42,0.09)]"
          >
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-black text-[#062f66]">
                  {section.label}
                </h2>
                <p className="mt-2 text-sm leading-6 text-slate-600">
                  {section.helper}
                </p>
              </div>
              <ArrowRight
                size={18}
                className="shrink-0 text-slate-400 transition group-hover:text-[#062f66]"
              />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
