import { redirect } from "next/navigation";
import MediaManager from "@/components/admin/MediaManager";
import { hasAdminSession } from "@/lib/admin-session";
import { getAdminMediaAssets, getMediaAssetCounts } from "@/lib/media-assets";

export const dynamic = "force-dynamic";

export default async function AdminMediaPage() {
  if (!(await hasAdminSession())) {
    redirect("/admin/login");
  }

  const [assets, counts] = await Promise.all([
    getAdminMediaAssets({ take: 120 }),
    getMediaAssetCounts(),
  ]);

  return <MediaManager initialAssets={assets} initialCounts={counts} />;
}
