import AdminPresetPage from "@/components/admin/AdminPresetPage";

export default function AdminHomeHeroPage() {
  return <AdminPresetPage presetKey="home-hero" />;
}
