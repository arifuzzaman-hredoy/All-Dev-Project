"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  DEFAULT_SPECIALTIES,
  SpecialtyItem,
  doctorsToLines,
  fileToDataUrl,
  linesToArray,
  linesToDoctors,
  makeSpecialtyId,
  slugify,
} from "@/lib/specialties";
import { getSpecialtyIcon, specialtyIconOptions } from "@/lib/specialtyIcons";

type FormState = {
  id: string;
  slug: string;
  title: string;
  icon: string;
  shortDescription: string;
  image: string;
  detailTitle: string;
  detailDescription: string;
  servicesText: string;
  doctorsText: string;
  active: boolean;
  featured: boolean;
  showInMenu: boolean;
  sortOrder: number;
  createdAt: string;
};

function itemToForm(item?: SpecialtyItem): FormState {
  const now = new Date().toISOString();

  return {
    id: item?.id || makeSpecialtyId(),
    slug: item?.slug || "",
    title: item?.title || "",
    icon: item?.icon || "stethoscope",
    shortDescription: item?.shortDescription || "",
    image: item?.image || "",
    detailTitle: item?.detailTitle || "",
    detailDescription: item?.detailDescription || "",
    servicesText: item?.services?.join("\n") || "",
    doctorsText: item?.doctors ? doctorsToLines(item.doctors) : "",
    active: item?.active ?? true,
    featured: item?.featured ?? false,
    showInMenu: item?.showInMenu ?? true,
    sortOrder: item?.sortOrder || 10,
    createdAt: item?.createdAt || now,
  };
}

function makeUniqueSlug(items: SpecialtyItem[], baseSlug: string, currentId: string) {
  const cleanBase = baseSlug || "specialty";
  let slug = cleanBase;
  let counter = 2;

  while (items.some((item) => item.slug === slug && item.id !== currentId)) {
    slug = `${cleanBase}-${counter}`;
    counter += 1;
  }

  return slug;
}

export default function AdminHomeSpecialitiesPage() {
  const [items, setItems] = useState<SpecialtyItem[]>(DEFAULT_SPECIALTIES);
  const [form, setForm] = useState<FormState>(() => itemToForm());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [openForm, setOpenForm] = useState(false);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");

  useEffect(() => {
    let mounted = true;

    async function loadSpecialities() {
      try {
        const response = await fetch("/api/admin/specialities", { cache: "no-store" });
        const payload = (await response.json()) as { specialities?: SpecialtyItem[] };
        if (mounted && Array.isArray(payload.specialities)) {
          setItems(payload.specialities);
        }
      } catch {
        // Keep fallback state if DB load fails.
      }
    }

    void loadSpecialities();
    return () => {
      mounted = false;
    };
  }, []);

  const filteredItems = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    return [...items]
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .filter((item) => {
        if (!keyword) return true;

        return [
          item.title,
          item.shortDescription,
          item.slug,
          item.services.join(" "),
          item.doctors.map((doctor) => doctor.name).join(" "),
        ]
          .join(" ")
          .toLowerCase()
          .includes(keyword);
      });
  }, [items, search]);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  function persist(nextItems: SpecialtyItem[], message: string) {
    const sorted = [...nextItems].sort((a, b) => a.sortOrder - b.sortOrder);
    setItems(sorted);
    showToast(message);

    void fetch("/api/admin/specialities", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sorted),
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("Save failed");
        const payload = (await response.json()) as { specialities?: SpecialtyItem[] };
        if (Array.isArray(payload.specialities)) setItems(payload.specialities);
      })
      .catch(() => showToast("DB save failed. Please try again."));
  }

  function updateField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function openAddForm() {
    setEditingId(null);
    setForm(itemToForm());
    setOpenForm(true);
  }

  function openEditForm(item: SpecialtyItem) {
    setEditingId(item.id);
    setForm(itemToForm(item));
    setOpenForm(true);
  }

  async function handleImageUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      showToast("Only image file allowed.");
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      showToast("Image 3MB er niche rakho.");
      return;
    }

    const dataUrl = await fileToDataUrl(file);
    updateField("image", dataUrl);
    showToast("Image uploaded.");
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const title = form.title.trim();
    if (!title) return showToast("Specialty title required.");

    const services = linesToArray(form.servicesText);
    if (!services.length) return showToast("Minimum 1 service required.");

    const finalSlug = makeUniqueSlug(items, slugify(form.slug || title), form.id);
    const payload: SpecialtyItem = {
      id: form.id,
      slug: finalSlug,
      title,
      icon: form.icon || "stethoscope",
      shortDescription: form.shortDescription.trim(),
      image: form.image.trim(),
      detailTitle: form.detailTitle.trim() || `${title} Department`,
      detailDescription:
        form.detailDescription.trim() ||
        `${title} department provides consultation and care support.`,
      services,
      doctors: linesToDoctors(form.doctorsText),
      active: form.active,
      featured: form.featured,
      showInMenu: form.showInMenu,
      sortOrder: Number(form.sortOrder) || 10,
      createdAt: form.createdAt,
      updatedAt: new Date().toISOString(),
    };

    persist(
      editingId
        ? items.map((item) => (item.id === editingId ? payload : item))
        : [...items, payload],
      editingId ? "Specialty updated." : "Specialty added.",
    );
    setOpenForm(false);
    setEditingId(null);
  }

  function toggleFlag(id: string, key: "active" | "featured" | "showInMenu") {
    persist(
      items.map((item) =>
        item.id === id
          ? { ...item, [key]: !item[key], updatedAt: new Date().toISOString() }
          : item,
      ),
      "Specialty status updated.",
    );
  }

  function deleteItem(item: SpecialtyItem) {
    if (!window.confirm(`Delete "${item.title}" specialty?`)) return;
    persist(
      items.filter((specialty) => specialty.id !== item.id),
      "Specialty deleted.",
    );
  }

  function resetDefault() {
    if (!window.confirm("Reset all specialties to default data?")) return;
    persist(DEFAULT_SPECIALTIES, "Default specialties restored.");
  }

  return (
    <main className="min-h-screen bg-[#f4f8fc] p-5 text-[#002f70] sm:p-7">
      {toast ? (
        <div className="fixed right-6 top-6 z-[100] rounded-lg bg-[#002f70] px-5 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section className="border border-[#d7e3f1] bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-[#8061bd]">
              CMS Control
            </p>
            <h1 className="mt-2 text-3xl font-black">
              Specialities & Departments
            </h1>
            <p className="mt-2 max-w-3xl font-semibold leading-7 text-[#49668b]">
              Control public cards, mega menu items, department detail pages,
              service lists, and doctors from one place.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <Link
              href="/specialities"
              className="border border-[#c7d7ea] bg-white px-5 py-3 text-sm font-black"
            >
              View Public Page
            </Link>
            <button
              type="button"
              onClick={resetDefault}
              className="border border-[#c7d7ea] bg-white px-5 py-3 text-sm font-black"
            >
              Reset Default
            </button>
            <button
              type="button"
              onClick={openAddForm}
              className="bg-[#002f70] px-5 py-3 text-sm font-black text-white"
            >
              + Add Specialty
            </button>
          </div>
        </div>
      </section>

      <section className="mt-5 grid gap-4 border border-[#d7e3f1] bg-white p-5 md:grid-cols-[2fr_1fr_1fr_1fr]">
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Search
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search specialty, service, doctor..."
            className="h-11 border border-[#c6d6e8] px-3 text-base font-semibold text-[#002f70] outline-none"
          />
        </label>
        <InfoBox label="Total" value={`${items.length} specialties`} />
        <InfoBox
          label="Featured cards"
          value={`${items.filter((item) => item.featured).length} cards`}
        />
        <InfoBox
          label="Menu items"
          value={`${items.filter((item) => item.showInMenu).length} menu`}
        />
      </section>

      <section className="mt-5 grid gap-5 lg:grid-cols-2">
        {filteredItems.map((item) => {
          const Icon = getSpecialtyIcon(item.icon);

          return (
            <article
              key={item.id}
              className={`overflow-hidden border border-[#d5e2f0] bg-white shadow-sm ${
                !item.active ? "opacity-60" : ""
              }`}
            >
              <div className="grid md:grid-cols-[170px_1fr]">
                <div className="grid min-h-[210px] place-items-center bg-[#eef7ff]">
                  <Icon className="h-14 w-14 text-[#00a6a6]" strokeWidth={2.2} />
                </div>

                <div className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h2 className="text-xl font-black">{item.title}</h2>
                      <p className="mt-2 font-semibold leading-6 text-[#49668b]">
                        {item.shortDescription}
                      </p>
                    </div>
                    <strong className="bg-[#eef6ff] px-3 py-1 text-xs">
                      Sort: {item.sortOrder}
                    </strong>
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2 text-xs font-black">
                    <span className="bg-[#eef6ff] px-3 py-1">/{item.slug}</span>
                    <span className="bg-[#eef6ff] px-3 py-1">
                      {item.services.length} services
                    </span>
                    <span className="bg-[#eef6ff] px-3 py-1">
                      {item.doctors.length} doctors
                    </span>
                    <span className="bg-[#eef6ff] px-3 py-1">
                      {item.featured ? "Featured" : "Not featured"}
                    </span>
                    <span className="bg-[#eef6ff] px-3 py-1">
                      {item.showInMenu ? "In menu" : "Not in menu"}
                    </span>
                  </div>

                  <div className="mt-5 flex flex-wrap gap-2">
                    <button onClick={() => openEditForm(item)} className="adminBtn">
                      Edit
                    </button>
                    <button onClick={() => toggleFlag(item.id, "active")} className="adminBtn">
                      {item.active ? "Hide" : "Show"}
                    </button>
                    <button onClick={() => toggleFlag(item.id, "featured")} className="adminBtn">
                      {item.featured ? "Unfeatured" : "Featured"}
                    </button>
                    <button onClick={() => toggleFlag(item.id, "showInMenu")} className="adminBtn">
                      {item.showInMenu ? "Remove Menu" : "Add Menu"}
                    </button>
                    <Link href={`/specialities/${item.slug}`} className="adminBtn">
                      View
                    </Link>
                    <button
                      onClick={() => deleteItem(item)}
                      className="border border-[#ffd1d1] bg-[#fff1f1] px-3 py-2 text-sm font-black text-[#b42318]"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </section>

      {openForm ? (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-auto bg-slate-900/50 p-4 backdrop-blur-sm">
          <form
            onSubmit={handleSubmit}
            className="max-h-[92vh] w-full max-w-5xl overflow-auto bg-white p-4 shadow-2xl"
          >
            <div className="mb-4 flex flex-wrap items-start justify-between gap-4">
              <div>
                <h2 className="text-xl font-black">
                  {editingId ? "Edit specialty" : "Add specialty"}
                </h2>
                <p className="mt-1 text-sm font-semibold text-[#49668b]">
                  Doctors format: Name | Title | Days | Time | Room | Fee |
                  Image URL | active
                </p>
              </div>
              <button
                type="button"
                onClick={() => setOpenForm(false)}
                className="border border-[#c6d6e8] bg-white px-4 py-3 text-base"
              >
                Close
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <FormInput label="Specialty title *" value={form.title} onChange={(value) => updateField("title", value)} />
              <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
                Icon
                <select
                  value={form.icon}
                  onChange={(event) => updateField("icon", event.target.value)}
                  className="h-11 border border-[#c6d6e8] px-3 text-base font-semibold text-[#002f70] outline-none"
                >
                  {specialtyIconOptions.map((option) => (
                    <option key={option.key} value={option.key}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>
              <FormInput label="Slug" value={form.slug} onChange={(value) => updateField("slug", value)} placeholder="auto-from-title" />
              <FormInput label="Sort order" type="number" value={String(form.sortOrder)} onChange={(value) => updateField("sortOrder", Number(value))} />
            </div>

            <FormTextarea label="Short description" rows={3} value={form.shortDescription} onChange={(value) => updateField("shortDescription", value)} />

            <div className="mt-4 grid gap-3 md:grid-cols-[130px_1fr]">
              <div className="h-[100px] overflow-hidden border border-[#c6d6e8] bg-[#f8fbff]">
                {form.image ? (
                  <img src={form.image} alt="Preview" className="h-full w-full object-cover" />
                ) : null}
              </div>
              <div className="grid gap-3">
                <FormInput label="Detail image URL / uploaded image" value={form.image} onChange={(value) => updateField("image", value)} />
                <label className="inline-flex w-fit cursor-pointer bg-[#071126] px-4 py-3 text-sm font-black text-white">
                  Upload Image
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              </div>
            </div>

            <FormInput label="Detail title" value={form.detailTitle} onChange={(value) => updateField("detailTitle", value)} />
            <FormTextarea label="Detail description" rows={4} value={form.detailDescription} onChange={(value) => updateField("detailDescription", value)} />
            <FormTextarea label="Services *" rows={7} value={form.servicesText} onChange={(value) => updateField("servicesText", value)} help="One line = one service" />
            <FormTextarea label="Doctors" rows={8} value={form.doctorsText} onChange={(value) => updateField("doctorsText", value)} help="One line = one doctor. Last value hidden dile doctor hide hobe." />

            <div className="mt-4 flex flex-wrap gap-5">
              <CheckBox label="Active specialty" checked={form.active} onChange={(value) => updateField("active", value)} />
              <CheckBox label="Show in homepage cards" checked={form.featured} onChange={(value) => updateField("featured", value)} />
              <CheckBox label="Show in big menu" checked={form.showInMenu} onChange={(value) => updateField("showInMenu", value)} />
            </div>

            <div className="mt-5 flex justify-end gap-2">
              <button type="button" onClick={() => setOpenForm(false)} className="border border-[#c7d7ea] bg-white px-5 py-3 text-sm font-black">
                Cancel
              </button>
              <button type="submit" className="bg-[#002f70] px-5 py-3 text-sm font-black text-white">
                {editingId ? "Update Specialty" : "Add Specialty"}
              </button>
            </div>
          </form>
        </div>
      ) : null}

      <style jsx global>{`
        .adminBtn {
          border: 1px solid #cfe1f5;
          background: #eef6ff;
          padding: 8px 12px;
          color: #002f70;
          font-size: 14px;
          font-weight: 900;
          text-decoration: none;
        }
      `}</style>
    </main>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <input
        value={value}
        readOnly
        className="h-11 border border-[#c6d6e8] bg-[#f8fbff] px-3 text-base font-semibold text-[#002f70]"
      />
    </label>
  );
}

function FormInput({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="h-11 border border-[#c6d6e8] px-3 text-base font-semibold text-[#002f70] outline-none"
      />
    </label>
  );
}

function FormTextarea({
  label,
  value,
  onChange,
  rows,
  help,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  rows: number;
  help?: string;
}) {
  return (
    <label className="mt-4 grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <textarea
        rows={rows}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="border border-[#c6d6e8] p-3 text-base font-semibold leading-6 text-[#002f70] outline-none"
      />
      {help ? <span className="text-[11px] normal-case text-[#49668b]">{help}</span> : null}
    </label>
  );
}

function CheckBox({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="inline-flex items-center gap-2 text-sm font-black text-[#24476e]">
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="h-5 w-5 accent-[#002f70]"
      />
      {label}
    </label>
  );
}
