import type { Metadata } from "next";

import AdminPresetPage from "@/components/admin/AdminPresetPage";

export const metadata: Metadata = {
  title: "Home Quick Actions | Admin Panel",
  description: "Manage homepage quick action cards from the admin panel.",
};

export default function AdminHomeQuickActionsPage() {
  return (
    <main className="space-y-6">
      <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-600">
              Homepage Section
            </p>

            <h1 className="mt-2 text-2xl font-black tracking-tight text-slate-900">
              Quick Actions
            </h1>

            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">
              Homepage-এর quick action cards এখানে সহজভাবে edit করুন। Title,
              description, button text, link — সব update করলে public website-এ
              section update হবে।
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">
              Status
            </p>
            <p className="mt-1 text-sm font-black text-emerald-600">
              Editable Section
            </p>
          </div>
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
        <div className="mb-5 border-b border-slate-200 pb-4">
          <h2 className="text-lg font-black text-slate-900">
            Edit Quick Action Content
          </h2>

          <p className="mt-1 text-sm leading-6 text-slate-500">
            প্রয়োজনীয় field গুলো update করে save করুন। Unnecessary design বা
            layout change করার দরকার নেই।
          </p>
        </div>

        <AdminPresetPage presetKey="home-quick-actions" />
      </section>
    </main>
  );
}