import HomeSectionTeaserEditor from "@/components/admin/HomeSectionTeaserEditor";
import { getCurrentAdminUser } from "@/lib/admin-session";
import { getHomeSectionTeaser } from "@/lib/home-section-teasers";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function AdminHomeBlogsPage() {
  const admin = await getCurrentAdminUser();

  if (!admin) {
    redirect("/admin/login");
  }

  const section = await getHomeSectionTeaser("home-blogs");

  return (
    <HomeSectionTeaserEditor
      sectionKey="home-blogs"
      initialSection={section}
      routeLabel="Homepage / Blogs"
      editorTitle="Homepage blogs teaser"
      editorDescription="Control only the homepage blog section copy, CTA, visibility, and card limit without changing frontend layout."
    />
  );
}
