import { connection } from "next/server";

import WhyChooseForm from "@/components/admin/home-why-choose/WhyChooseForm";
import { getWhyChooseSection } from "@/lib/home-why-choose";

export default async function AdminHomeWhyChoosePage() {
  await connection();

  const section = await getWhyChooseSection();

  return <WhyChooseForm initialSection={section} />;
}
