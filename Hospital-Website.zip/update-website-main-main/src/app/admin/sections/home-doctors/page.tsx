import HomeSectionTeaserEditor from "@/components/admin/HomeSectionTeaserEditor";
import { getCurrentAdminUser } from "@/lib/admin-session";
import { getHomeSectionTeaser } from "@/lib/home-section-teasers";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function AdminHomeDoctorsPage() {
  const admin = await getCurrentAdminUser();

  if (!admin) {
    redirect("/admin/login");
  }

  const section = await getHomeSectionTeaser("home-doctors");

  return (
    <HomeSectionTeaserEditor
      sectionKey="home-doctors"
      initialSection={section}
      routeLabel="Homepage / Doctors"
      editorTitle="Homepage doctors teaser"
      editorDescription="Control only the homepage doctors section copy, CTA, visibility, and card limit without changing frontend layout."
    />
  );
}
