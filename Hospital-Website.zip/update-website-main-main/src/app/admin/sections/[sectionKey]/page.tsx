import { notFound } from "next/navigation";
import SectionEditor from "@/components/admin/SectionEditor";
import { getAdminSectionPreset } from "@/data/admin-section-presets";
import HomeHeroEditor from "@/features/admin/home-hero/components/HomeHeroEditor";
import { readPublicContent } from "@/lib/public-content/storage";

type SectionPageProps = {
  params: Promise<{ sectionKey: string }>;
};

export default async function SectionPage({ params }: SectionPageProps) {
  const { sectionKey } = await params;
  const preset = getAdminSectionPreset(sectionKey);

  if (!preset) {
    notFound();
  }

  if (preset.editor === "homeHero") {
    const content = await readPublicContent();
    return <HomeHeroEditor initialContent={content.homeHero} />;
  }

  return <SectionEditor {...preset} />;
}
