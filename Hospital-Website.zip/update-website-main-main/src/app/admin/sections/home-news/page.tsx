import HomeSectionTeaserEditor from "@/components/admin/HomeSectionTeaserEditor";
import { getCurrentAdminUser } from "@/lib/admin-session";
import { getHomeSectionTeaser } from "@/lib/home-section-teasers";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function AdminHomeNewsPage() {
  const admin = await getCurrentAdminUser();

  if (!admin) {
    redirect("/admin/login");
  }

  const section = await getHomeSectionTeaser("home-news");

  return (
    <HomeSectionTeaserEditor
      sectionKey="home-news"
      initialSection={section}
      routeLabel="Homepage / News"
      editorTitle="Homepage news teaser"
      editorDescription="Control only the homepage news section copy, CTA, visibility, and card limit without changing frontend layout."
    />
  );
}
