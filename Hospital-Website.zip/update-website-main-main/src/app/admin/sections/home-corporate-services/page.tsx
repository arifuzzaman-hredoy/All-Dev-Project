"use client";

import { ChangeEvent, useEffect, useMemo, useState } from "react";
import {
  CorporateServicesData,
  DEFAULT_CORPORATE_LOGO,
  DEFAULT_CORPORATE_SERVICES,
  fileToDataUrl,
  makeCorporateId,
} from "@/lib/corporateServices";

export default function AdminHomeCorporateServicesPage() {
  const [data, setData] = useState<CorporateServicesData>(DEFAULT_CORPORATE_SERVICES);
  const [toast, setToast] = useState("");

  useEffect(() => {
    let mounted = true;

    async function loadCorporateServices() {
      try {
        const response = await fetch("/api/admin/corporate-services", { cache: "no-store" });
        const payload = (await response.json()) as { data?: CorporateServicesData };
        if (mounted && payload.data) setData(payload.data);
      } catch {
        // Keep fallback state if DB load fails.
      }
    }

    void loadCorporateServices();
    return () => {
      mounted = false;
    };
  }, []);

  const activeLogoCount = useMemo(
    () => data.logos.filter((item) => item.active).length,
    [data.logos]
  );
  const activeFeatureCount = useMemo(
    () => data.features.filter((item) => item.active).length,
    [data.features]
  );

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  function persist(nextData: CorporateServicesData, message?: string) {
    const finalData = { ...nextData, updatedAt: new Date().toISOString() };
    setData(finalData);
    if (message) showToast(message);

    void fetch("/api/admin/corporate-services", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(finalData),
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("Save failed");
        const payload = (await response.json()) as { data?: CorporateServicesData };
        if (payload.data) setData(payload.data);
      })
      .catch(() => showToast("DB save failed. Please try again."));
  }

  function updateMainField<K extends keyof CorporateServicesData>(
    key: K,
    value: CorporateServicesData[K]
  ) {
    persist({ ...data, [key]: value });
  }

  async function handleLogoUpload(id: string, event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return showToast("Only image file allowed.");
    if (file.size > 3 * 1024 * 1024) return showToast("Keep image under 3MB.");
    const image = await fileToDataUrl(file);
    persist({
      ...data,
      logos: data.logos.map((item) => (item.id === id ? { ...item, image } : item)),
    }, "Logo uploaded.");
  }

  return (
    <main className="min-h-screen bg-[#f4f8fc] p-4 text-[#002f70] sm:p-7">
      {toast ? <div className="fixed right-5 top-5 z-50 rounded-lg bg-[#002f70] px-4 py-3 text-sm font-black text-white shadow-xl">{toast}</div> : null}

      <section className="border border-[#d7e3f1] bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#8061bd]">CMS Control</p>
            <h1 className="mt-2 text-3xl font-black">Corporate Services</h1>
            <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-[#49668b]">Edit homepage corporate services text, support cards, and partner logos.</p>
          </div>
          <button type="button" onClick={() => persist(DEFAULT_CORPORATE_SERVICES, "Default corporate services restored.")} className="border border-[#c7d7ea] bg-white px-4 py-3 text-sm font-black">Reset Default</button>
        </div>
      </section>

      <section className="mt-4 grid gap-3 border border-[#d7e3f1] bg-white p-4 md:grid-cols-3">
        <ReadOnlyStat label="Active features" value={activeFeatureCount} />
        <ReadOnlyStat label="Active logos" value={activeLogoCount} />
        <ReadOnlyStat label="Total logos" value={data.logos.length} />
      </section>

      <section className="mt-4 grid gap-4 border border-[#d7e3f1] bg-white p-4 lg:grid-cols-2">
        <TextField label="Badge text" value={data.badgeText} onChange={(value) => updateMainField("badgeText", value)} />
        <TextField label="Heading main" value={data.headingMain} onChange={(value) => updateMainField("headingMain", value)} />
        <TextField label="Heading accent" value={data.headingAccent} onChange={(value) => updateMainField("headingAccent", value)} />
        <TextField label="Subtitle" value={data.subtitle} onChange={(value) => updateMainField("subtitle", value)} />
        <TextField label="Main label" value={data.mainLabel} onChange={(value) => updateMainField("mainLabel", value)} />
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e] lg:col-span-2">
          Main text
          <textarea value={data.mainText} onChange={(event) => updateMainField("mainText", event.target.value)} rows={4} className="border border-[#c6d6e8] px-3 py-3 text-sm font-semibold outline-none" />
        </label>
      </section>

      <section className="mt-4 border border-[#d7e3f1] bg-white p-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-xl font-black">Feature Cards</h2>
          <button type="button" onClick={() => persist({ ...data, features: [...data.features, { id: makeCorporateId("feature"), icon: "ShieldCheck", label: "New", value: "Feature", active: true, sortOrder: data.features.length + 1 }] }, "Feature added.")} className="bg-[#002f70] px-4 py-2 text-sm font-black text-white">Add Feature</button>
        </div>
        <div className="mt-4 grid gap-3 lg:grid-cols-3">
          {data.features.map((feature) => (
            <div key={feature.id} className="grid gap-2 border border-[#d8e6f5] p-3">
              <TextField label="Icon name" value={feature.icon} onChange={(value) => persist({ ...data, features: data.features.map((item) => item.id === feature.id ? { ...item, icon: value } : item) })} />
              <TextField label="Label" value={feature.label} onChange={(value) => persist({ ...data, features: data.features.map((item) => item.id === feature.id ? { ...item, label: value } : item) })} />
              <TextField label="Value" value={feature.value} onChange={(value) => persist({ ...data, features: data.features.map((item) => item.id === feature.id ? { ...item, value } : item) })} />
              <TextField label="Sort" type="number" value={String(feature.sortOrder)} onChange={(value) => persist({ ...data, features: data.features.map((item) => item.id === feature.id ? { ...item, sortOrder: Number(value) || 10 } : item) })} />
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => persist({ ...data, features: data.features.map((item) => item.id === feature.id ? { ...item, active: !item.active } : item) }, "Feature visibility updated.")} className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-xs font-black">{feature.active ? "Hide" : "Show"}</button>
                <button type="button" onClick={() => persist({ ...data, features: data.features.filter((item) => item.id !== feature.id) }, "Feature deleted.")} className="border border-[#ffd1d1] bg-[#fff1f1] px-3 py-2 text-xs font-black text-[#b42318]">Delete</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-4 border border-[#d7e3f1] bg-white p-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-xl font-black">Corporate Logos</h2>
          <button type="button" onClick={() => persist({ ...data, logos: [...data.logos, { id: makeCorporateId("logo"), name: "New Partner", image: DEFAULT_CORPORATE_LOGO, active: true, sortOrder: data.logos.length + 1 }] }, "Logo added.")} className="bg-[#002f70] px-4 py-2 text-sm font-black text-white">Add Logo</button>
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {data.logos.map((logo) => (
            <div key={logo.id} className="grid gap-3 border border-[#d8e6f5] p-3">
              <div className="grid h-32 place-items-center bg-[#f8fbff]">
                <img src={logo.image} alt={logo.name} className="max-h-24 max-w-full object-contain" />
              </div>
              <TextField label="Name" value={logo.name} onChange={(value) => persist({ ...data, logos: data.logos.map((item) => item.id === logo.id ? { ...item, name: value } : item) })} />
              <TextField label="Image path" value={logo.image} onChange={(value) => persist({ ...data, logos: data.logos.map((item) => item.id === logo.id ? { ...item, image: value } : item) })} />
              <TextField label="Sort" type="number" value={String(logo.sortOrder)} onChange={(value) => persist({ ...data, logos: data.logos.map((item) => item.id === logo.id ? { ...item, sortOrder: Number(value) || 10 } : item) })} />
              <input type="file" accept="image/*" onChange={(event) => void handleLogoUpload(logo.id, event)} className="text-sm font-semibold" />
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => persist({ ...data, logos: data.logos.map((item) => item.id === logo.id ? { ...item, active: !item.active } : item) }, "Logo visibility updated.")} className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-xs font-black">{logo.active ? "Hide" : "Show"}</button>
                <button type="button" onClick={() => persist({ ...data, logos: data.logos.filter((item) => item.id !== logo.id) }, "Logo deleted.")} className="border border-[#ffd1d1] bg-[#fff1f1] px-3 py-2 text-xs font-black text-[#b42318]">Delete</button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

function TextField({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (value: string) => void; type?: string }) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <input type={type} value={value} onChange={(event) => onChange(event.target.value)} className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none" />
    </label>
  );
}

function ReadOnlyStat({ label, value }: { label: string; value: number }) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <input value={value} readOnly className="h-11 border border-[#c6d6e8] bg-[#f8fbff] px-3 text-sm font-semibold" />
    </label>
  );
}
