import { connection } from "next/server";

import DoctorTable from "@/components/admin/doctors/DoctorTable";
import { getDoctors } from "@/lib/doctors";

export default async function AdminDoctorsPage() {
  await connection();

  const doctors = await getDoctors();

  return (
    <div className="space-y-5">
      <section>
        <h1 className="text-2xl font-black text-[#062f66]">Doctors</h1>
        <p className="mt-2 text-sm text-slate-600">
          Manage doctor profiles, schedules, images, and appointment
          availability.
        </p>
      </section>

      <DoctorTable doctors={doctors} />
    </div>
  );
}
