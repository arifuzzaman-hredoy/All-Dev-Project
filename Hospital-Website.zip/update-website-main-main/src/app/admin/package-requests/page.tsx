"use client";

import { useEffect, useMemo, useState } from "react";
import {
  PackageBooking,
  PaymentStatus,
  deletePackageBooking,
  formatDateTime,
  fetchPackageBookings,
  updatePackageBookingStatus,
} from "@/lib/packageBookings";

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export default function PackageRequestsAdminPage() {
  const [bookings, setBookings] = useState<PackageBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");

  async function loadBookings() {
    const nextBookings = await fetchPackageBookings();
    setBookings(
      nextBookings.sort(
        (a, b) =>
          new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
      )
    );
  }

  useEffect(() => {
    let active = true;

    fetchPackageBookings()
      .then((nextBookings) => {
        if (!active) return;
        setBookings(
          nextBookings.sort(
            (a, b) =>
              new Date(b.submittedAt).getTime() -
              new Date(a.submittedAt).getTime()
          )
        );
      })
      .catch(() => showToast("Failed to load package requests."))
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const filteredBookings = useMemo(() => {
    const keyword = search.toLowerCase().trim();
    if (!keyword) return bookings;

    return bookings.filter((item) =>
      [
        item.token,
        item.receiptNo,
        item.patientName,
        item.phone,
        item.packageName,
        item.packageTarget,
        item.diseaseProblem,
        item.paymentMethod,
        item.transactionId,
        item.paymentStatus,
      ]
        .join(" ")
        .toLowerCase()
        .includes(keyword)
    );
  }, [bookings, search]);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  async function handleDelete(id: string) {
    if (!window.confirm("Delete this package request?")) return;
    try {
      await deletePackageBooking(id);
      await loadBookings();
      showToast("Package request deleted.");
    } catch {
      showToast("Package request delete failed.");
    }
  }

  async function handleStatus(id: string, status: PaymentStatus) {
    try {
      await updatePackageBookingStatus(id, status);
      await loadBookings();
      showToast(`Status updated: ${status}`);
    } catch {
      showToast("Status update failed.");
    }
  }

  function printSingleReceipt(item: PackageBooking) {
    const win = window.open("", "_blank", "width=900,height=700");
    if (!win) return;

    const packageTitle = `${item.packageName}${
      item.packageTarget ? ` (${item.packageTarget})` : ""
    }`;
    const rows = [
      ["Token", item.token],
      ["Patient Name", item.patientName],
      ["Phone", item.phone],
      ["Age / Gender", `${item.age} / ${item.gender}`],
      ["Package", packageTitle],
      ["Disease / Problem", item.diseaseProblem],
      ["Fee", item.packageFee],
      ["Payment Method", item.paymentMethod],
      ["Payment Number", item.paymentNumber || "-"],
      ["Transaction ID", item.transactionId || "-"],
      ["Amount Paid", item.amountPaid],
      ["Status", item.paymentStatus],
      ["Request Note", item.requestNote || "-"],
    ];

    win.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${escapeHtml(item.receiptNo)}</title>
          <style>
            body { font-family: Arial, sans-serif; color: #002f70; padding: 28px; }
            .top { display: flex; justify-content: space-between; border-bottom: 2px solid #c9d8ea; padding-bottom: 14px; margin-bottom: 18px; }
            h1, p { margin: 0; }
            h1 { font-size: 24px; }
            p { margin-top: 6px; color: #33577e; }
            table { width: 100%; border-collapse: collapse; margin-top: 18px; }
            th, td { border: 1px solid #bdd0e5; padding: 11px; text-align: left; font-size: 14px; }
            th { width: 220px; background: #f1f6fc; }
            .signature { display: flex; justify-content: space-between; margin-top: 70px; font-weight: 700; }
            .signature span { width: 230px; border-top: 1px solid #002f70; padding-top: 8px; text-align: center; }
            @media print { button { display: none; } }
          </style>
        </head>
        <body>
          <button onclick="window.print()">Print</button>
          <div class="top">
            <div>
              <h1>Update Diagnostic Center</h1>
              <p>Health Package Cash Receipt</p>
            </div>
            <div>
              <strong>${escapeHtml(item.receiptNo)}</strong><br/>
              <span>${escapeHtml(formatDateTime(item.submittedAt))}</span>
            </div>
          </div>
          <table><tbody>
            ${rows
              .map(
                ([label, value]) =>
                  `<tr><th>${escapeHtml(label)}</th><td>${escapeHtml(
                    value
                  )}</td></tr>`
              )
              .join("")}
          </tbody></table>
          <div class="signature">
            <span>Patient Signature</span>
            <span>Authorized Signature</span>
          </div>
        </body>
      </html>
    `);
    win.document.close();
  }

  if (loading) {
    return (
      <main className="grid min-h-screen place-items-center bg-[#f2f7fd] p-8 text-center text-[#002f70]">
        <div>
          <h1 className="text-2xl font-black">Loading package requests...</h1>
          <p className="mt-2 text-sm font-semibold text-[#2d496c]">
            Database theke booking request load hocche.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="packageRequestsPage min-h-screen bg-[#f2f7fd] p-4 text-[#002f70] sm:p-8">
      {toast ? (
        <div className="noPrint fixed right-5 top-5 z-50 rounded-lg bg-[#002f70] px-4 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section className="noPrint">
        <h1 className="text-3xl font-black">Package Booking Requests</h1>
        <p className="mt-2 max-w-3xl text-sm font-semibold text-[#2d496c]">
          View, search, print, verify, reject, and remove submitted health
          package bookings.
        </p>
      </section>

      <div className="packageRequestsPrintArea">
        <section className="onlyPrint hidden">
          <div className="text-center text-[10px]">
            Admin Panel | Update Diagnostic Center
          </div>
          <h1 className="text-lg font-black">Update Diagnostic Center</h1>
          <p className="text-xs">Health Package Booking Requests</p>
          <span className="text-xs">
            Printed: {formatDateTime(new Date().toISOString())}
          </span>
        </section>

        <section className="noPrint mt-5 flex flex-wrap items-end justify-between gap-4">
          <label className="grid w-full max-w-2xl gap-2 text-xs font-black uppercase tracking-[0.18em] text-[#5b6f8e]">
            Search package requests
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search by patient, phone, package, payment, receipt, or transaction"
              className="h-11 border border-[#c4d4e7] bg-white px-3 text-base font-semibold tracking-normal outline-none focus:border-[#25a6dc]"
            />
          </label>
          <button
            type="button"
            onClick={() => window.print()}
            className="h-11 border border-[#c4d4e7] bg-white px-4 text-sm font-black"
          >
            Print
          </button>
        </section>

        <section className="requestsTableWrap mt-4 overflow-auto border border-[#bdcfe5] bg-white">
          <table className="requestsPrintTable w-max min-w-full border-collapse bg-white">
            <thead>
              <tr>
                {[
                  "Serial No.",
                  "Token / Receipt ID",
                  "Patient Name",
                  "Phone",
                  "Age",
                  "Gender",
                  "Package",
                  "Disease / Problem",
                  "Payment Method",
                  "Payment Number",
                  "Transaction ID",
                  "Fee",
                  "Paid",
                  "Status",
                  "Submitted Date",
                  "Action",
                ].map((heading) => (
                  <th
                    key={heading}
                    className={`border border-[#bdcfe5] bg-[#f0f5fb] p-2 text-left text-xs font-black uppercase text-[#123866] ${
                      heading === "Action" ? "noPrint" : ""
                    }`}
                  >
                    {heading}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredBookings.map((item, index) => (
                <tr key={item.id}>
                  <Cell>{index + 1}</Cell>
                  <Cell>
                    <strong>{item.token}</strong>
                    <br />
                    <span>{item.receiptNo}</span>
                  </Cell>
                  <Cell>{item.patientName}</Cell>
                  <Cell>{item.phone}</Cell>
                  <Cell>{item.age}</Cell>
                  <Cell>{item.gender}</Cell>
                  <Cell>
                    {item.packageName}
                    {item.packageTarget ? (
                      <>
                        <br />
                        <span>{item.packageTarget}</span>
                      </>
                    ) : null}
                  </Cell>
                  <Cell>{item.diseaseProblem}</Cell>
                  <Cell>{item.paymentMethod}</Cell>
                  <Cell>{item.paymentNumber || "-"}</Cell>
                  <Cell>{item.transactionId || "-"}</Cell>
                  <Cell>{item.packageFee}</Cell>
                  <Cell>{item.amountPaid}</Cell>
                  <Cell>
                    <span
                      className={`inline-flex rounded-full px-2 py-1 text-[11px] font-black text-white ${statusClass(
                        item.paymentStatus
                      )}`}
                    >
                      {item.paymentStatus}
                    </span>
                  </Cell>
                  <Cell>{formatDateTime(item.submittedAt)}</Cell>
                  <td className="noPrint border border-[#bdcfe5] p-2 align-top">
                    <div className="flex flex-wrap gap-1">
                      <ActionButton onClick={() => printSingleReceipt(item)}>
                        Receipt
                      </ActionButton>
                      <ActionButton
                        onClick={() => handleStatus(item.id, "Verified")}
                      >
                        Verify
                      </ActionButton>
                      <ActionButton
                        onClick={() => handleStatus(item.id, "Rejected")}
                      >
                        Reject
                      </ActionButton>
                      <button
                        type="button"
                        onClick={() => handleDelete(item.id)}
                        className="border border-[#ffd1d1] bg-[#fff1f1] px-2 py-1 text-xs font-black text-[#b42318]"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {!filteredBookings.length ? (
                <tr>
                  <td
                    colSpan={16}
                    className="border border-[#bdcfe5] p-8 text-center text-sm font-black text-[#5b6f8e]"
                  >
                    No package booking request found.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </section>
      </div>

      <style jsx global>{`
        @media print {
          @page {
            size: A4 landscape;
            margin: 6mm;
          }

          html,
          body {
            width: 297mm;
            min-height: 210mm;
            overflow: visible !important;
            background: #fff !important;
          }

          body * {
            visibility: hidden !important;
          }

          .packageRequestsPrintArea,
          .packageRequestsPrintArea * {
            visibility: visible !important;
          }

          .packageRequestsPrintArea {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            color: #000 !important;
            background: #fff !important;
          }

          .noPrint {
            display: none !important;
          }

          .onlyPrint {
            display: block !important;
          }

          .requestsTableWrap {
            margin-top: 8px !important;
            overflow: visible !important;
            border: 0 !important;
          }

          .requestsPrintTable {
            width: 100% !important;
            min-width: 0 !important;
            table-layout: fixed !important;
            border-collapse: collapse !important;
            border: 1px solid #111 !important;
          }

          .requestsPrintTable th,
          .requestsPrintTable td {
            border: 1px solid #111 !important;
            padding: 3px 4px !important;
            color: #000 !important;
            font-size: 6.5px !important;
            line-height: 1.2 !important;
            white-space: normal !important;
            overflow-wrap: anywhere !important;
            vertical-align: top !important;
          }

          .requestsPrintTable th {
            background: #e9edf3 !important;
            font-weight: 900 !important;
            text-transform: uppercase !important;
          }

          .requestsPrintTable span,
          .requestsPrintTable strong {
            color: #000 !important;
            font-size: inherit !important;
            line-height: inherit !important;
          }

          .requestsPrintTable .inline-flex {
            display: inline !important;
            border-radius: 0 !important;
            background: transparent !important;
            padding: 0 !important;
            color: #000 !important;
          }
        }
      `}</style>
    </main>
  );
}

function statusClass(status: PaymentStatus) {
  if (status === "Verified") return "bg-[#07834f]";
  if (status === "Rejected") return "bg-[#b42318]";
  if (status === "Cash Request") return "bg-[#8a5a00]";
  return "bg-[#1d70b8]";
}

function Cell({ children }: { children: React.ReactNode }) {
  return (
    <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
      {children}
    </td>
  );
}

function ActionButton({
  children,
  onClick,
}: {
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="border border-[#c4d4e7] bg-[#f8fbff] px-2 py-1 text-xs font-black text-[#002f70]"
    >
      {children}
    </button>
  );
}
