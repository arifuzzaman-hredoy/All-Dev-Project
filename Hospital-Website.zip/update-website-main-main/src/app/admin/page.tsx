import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, ShieldCheck, Sparkles, Wand2 } from "lucide-react";
import { adminNavGroups } from "@/data/admin-navigation";
import { hasAdminSession } from "@/lib/admin-session";

const shortcuts = [
  {
    title: "Edit site settings",
    description:
      "Update logo copy, contact details, and global header content.",
    href: "/admin/site-settings",
    icon: ShieldCheck,
  },
  {
    title: "Homepage sections",
    description:
      "Open the home editors for hero, quick actions, and featured blocks.",
    href: "/admin/sections/home-hero",
    icon: Sparkles,
  },
  {
    title: "Public page copy",
    description:
      "Switch to the individual page editors for About, Contact, and more.",
    href: "/admin/pages/about",
    icon: Wand2,
  },
];

export default async function AdminDashboardPage() {
  if (!(await hasAdminSession())) {
    redirect("/admin/login");
  }

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-[32px] bg-[#062f66] px-6 py-8 text-white shadow-[0_28px_65px_rgba(6,47,102,0.18)] sm:px-8 sm:py-10 lg:px-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(91,192,222,0.22),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(140,198,63,0.16),transparent_34%)]" />
        <div className="relative max-w-3xl">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-200">
            Admin Dashboard
          </p>
          <h1 className="mt-3 text-3xl font-black leading-tight sm:text-4xl lg:text-5xl">
            Minimal, section-based control panel for the public site.
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base lg:text-lg lg:leading-8">
            Every section has its own page, so you can update copy without
            mixing unrelated content. Desktop uses a sidebar, mobile uses a menu
            drawer.
          </p>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        {shortcuts.map((shortcut) => {
          const Icon = shortcut.icon;

          return (
            <Link
              key={shortcut.href}
              href={shortcut.href}
              className="group rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_16px_40px_rgba(15,23,42,0.05)] transition hover:-translate-y-1 hover:border-[#5bc0de]/30 hover:shadow-[0_20px_50px_rgba(15,23,42,0.09)]"
            >
              <div className="flex items-start gap-4">
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-[#eef8ff] text-[#062f66] transition group-hover:bg-[#062f66] group-hover:text-white">
                  <Icon size={22} />
                </span>
                <div className="min-w-0 flex-1">
                  <h2 className="text-lg font-black text-[#062f66]">
                    {shortcut.title}
                  </h2>
                  <p className="mt-2 text-sm leading-6 text-slate-600">
                    {shortcut.description}
                  </p>
                  <span className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-[#0b5bd3]">
                    Open editor
                    <ArrowRight size={15} />
                  </span>
                </div>
              </div>
            </Link>
          );
        })}
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        {adminNavGroups.map((group) => (
          <div
            key={group.label}
            className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_16px_40px_rgba(15,23,42,0.05)] sm:p-6"
          >
            <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
              {group.label}
            </p>
            <div className="mt-4 space-y-3">
              {group.items.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="flex items-center justify-between gap-4 rounded-2xl border border-slate-200 px-4 py-3 transition hover:border-[#5bc0de]/30 hover:bg-slate-50"
                >
                  <div>
                    <p className="font-semibold text-[#062f66]">{item.label}</p>
                    <p className="mt-1 text-sm text-slate-500">
                      {item.description}
                    </p>
                  </div>
                  <ArrowRight size={16} className="shrink-0 text-slate-400" />
                </Link>
              ))}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
