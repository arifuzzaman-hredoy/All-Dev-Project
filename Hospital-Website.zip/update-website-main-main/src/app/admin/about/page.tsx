import AboutPageAdmin from "@/components/admin/AboutPageAdmin";

export default function AdminAboutAliasPage() {
  return <AboutPageAdmin />;
}
