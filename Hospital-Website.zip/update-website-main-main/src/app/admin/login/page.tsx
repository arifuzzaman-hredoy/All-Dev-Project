import type { Metadata } from "next";
import Link from "next/link";
import {
  Activity,
  ArrowUpRight,
  BadgeCheck,
  Fingerprint,
  KeyRound,
  ServerCog,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";
import AdminLoginForm from "@/components/admin/AdminLoginForm";
import CraftedBySignature from "@/components/brand/CraftedBySignature";

export const metadata: Metadata = {
  title: "Admin Login | Update Diagnostic Center",
  description: "Secure login page for the Update Diagnostic Center admin panel.",
};

const trustItems = [
  {
    title: "Secure access",
    text: "Admin workspace stays separated from the public website.",
    icon: ShieldCheck,
  },
  {
    title: "Protected session",
    text: "Admin access is verified through configured credentials.",
    icon: Fingerprint,
  },
  {
    title: "CMS control",
    text: "Manage appointments, doctors, pages, services, and settings.",
    icon: ServerCog,
  },
];

const featureItems = [
  "Independent section editing",
  "Appointment and request management",
  "Doctor and service content control",
  "Production-ready admin workflow",
];

export default function AdminLoginPage() {
  return (
    <main className="relative min-h-dvh overflow-hidden bg-[#eef6ff] px-4 py-6 text-slate-950 sm:px-6 lg:px-8">
      <div className="pointer-events-none absolute left-[-14rem] top-[-16rem] h-[36rem] w-[36rem] rounded-full bg-cyan-300/20 blur-3xl" />
      <div className="pointer-events-none absolute right-[-18rem] top-[6rem] h-[42rem] w-[42rem] rounded-full bg-blue-400/18 blur-3xl" />
      <div className="pointer-events-none absolute bottom-[-16rem] left-1/3 h-[32rem] w-[32rem] rounded-full bg-emerald-300/12 blur-3xl" />

      <div className="relative mx-auto grid min-h-[calc(100dvh-3rem)] w-full max-w-7xl items-center gap-6 lg:grid-cols-[1.08fr_0.92fr]">
        <section className="hidden relative overflow-hidden rounded-[32px] border border-white/70 bg-[#062f66] p-7 text-white shadow-[0_28px_76px_rgba(6,47,102,0.20)] lg:block lg:p-9">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_8%,rgba(103,232,249,0.22),transparent_30%),radial-gradient(circle_at_90%_22%,rgba(255,255,255,0.12),transparent_25%),linear-gradient(135deg,rgba(255,255,255,0.10),transparent_45%)]" />
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full border border-white/10" />
          <div className="pointer-events-none absolute -bottom-28 left-12 h-80 w-80 rounded-full border border-cyan-200/10" />

          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.07] px-4 py-2 text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-100">
              <ShieldCheck size={15} strokeWidth={2.4} />
              Secure admin entry
            </div>

            <div className="mt-8 max-w-3xl">
              <div className="mb-5 flex items-center gap-3 text-cyan-100">
                <Stethoscope size={26} strokeWidth={2.2} />
                <span className="text-xs font-bold uppercase tracking-[0.22em] sm:text-sm">
                  Update Diagnostic Center
                </span>
              </div>

              <h1 className="max-w-3xl text-5xl font-black leading-[1.05] tracking-[-0.045em] xl:text-6xl">
                Control the website from one clean admin workspace.
              </h1>

              <p className="mt-5 max-w-2xl text-base leading-8 text-blue-50/90 xl:text-lg">
                Sign in to manage public pages, appointments, services, doctors,
                health packages, media content, and site settings from a focused
                dashboard.
              </p>
            </div>

            <div className="mt-8 grid gap-3 md:grid-cols-3">
              {trustItems.map((item) => {
                const Icon = item.icon;

                return (
                  <div
                    key={item.title}
                    className="rounded-3xl border border-white/12 bg-white/[0.065] p-4 backdrop-blur transition hover:bg-white/[0.085]"
                  >
                    <Icon
                      className="mb-3 text-cyan-100"
                      size={22}
                      strokeWidth={2.15}
                    />
                    <h2 className="text-sm font-extrabold text-white">
                      {item.title}
                    </h2>
                    <p className="mt-2 text-xs leading-5 text-blue-50/75">
                      {item.text}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="mt-7 rounded-3xl border border-white/12 bg-white/[0.055] p-5">
              <div className="mb-4 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-cyan-100">
                <Activity size={17} strokeWidth={2.25} />
                Admin capabilities
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                {featureItems.map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-3 text-sm font-semibold text-blue-50"
                  >
                    <BadgeCheck
                      size={17}
                      className="shrink-0 text-cyan-100"
                      strokeWidth={2.25}
                    />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[590px] rounded-[32px] border border-white/80 bg-white p-5 shadow-[0_28px_76px_rgba(15,23,42,0.09)] backdrop-blur sm:p-7 lg:p-9">
          <div className="mb-7">
            <div className="mb-5 flex items-center justify-between gap-4">
              <div className="flex min-w-0 items-center gap-3">
                <KeyRound
                  className="shrink-0 text-[#062f66]"
                  size={28}
                  strokeWidth={2.15}
                />
                <div className="min-w-0">
                  <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-cyan-600">
                    Admin login
                  </p>
                  <h2 className="mt-1 text-3xl font-black tracking-[-0.04em] text-[#062f66] sm:text-4xl">
                    Welcome back
                  </h2>
                </div>
              </div>

              <Link
                href="/"
                className="hidden shrink-0 items-center gap-1.5 rounded-full border border-slate-200 px-4 py-2 text-sm font-bold text-slate-600 transition hover:border-[#0b5bd3]/25 hover:bg-blue-50 hover:text-[#0b5bd3] active:scale-[0.98] sm:inline-flex"
              >
                Public site
                <ArrowUpRight size={16} />
              </Link>
            </div>

            <p className="max-w-md text-sm leading-7 text-slate-600">
              Use your admin credentials. Do not share access without role
              planning.
            </p>
          </div>

          <AdminLoginForm />

          <CraftedBySignature variant="login" />
        </section>
      </div>
    </main>
  );
}