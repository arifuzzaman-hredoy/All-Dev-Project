export default function AdminLoading() {
  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fbff_0%,#eef5ff_48%,#ffffff_100%)]">
      <div className="h-0.5 w-full overflow-hidden bg-[#dbe8ff]">
        <div className="h-full w-1/3 animate-pulse bg-[linear-gradient(90deg,#8cc63f,#0a4d8f,#062f66)]" />
      </div>
    </div>
  );
}
