"use server";

import { revalidatePath } from "next/cache";

import { requireAdminSession } from "@/lib/admin-session";
import { deleteAppointment } from "@/lib/appointments";
import { recordAuditLog } from "@/lib/audit-log";

export async function deleteAppointmentAction(id: string) {
  await requireAdminSession();
  await deleteAppointment(id);
  await recordAuditLog({
    action: "APPOINTMENT_DELETE",
    entity: "Appointment",
    entityId: id,
  });
  revalidatePath("/admin/appointments");
}
