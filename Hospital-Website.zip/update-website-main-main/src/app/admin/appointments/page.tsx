import { connection } from "next/server";

import AppointmentsTable from "@/components/admin/appointments/AppointmentsTable";
import { siteSettingsToSiteInfo } from "@/data/site-base";
import { getAppointments } from "@/lib/appointments";
import { getActiveDoctors } from "@/lib/doctors";
import { getPublicSiteSettings } from "@/lib/site-settings";

export default async function AdminAppointmentsPage() {
  await connection();

  const [appointments, doctors, siteSettings] = await Promise.all([
    getAppointments(),
    getActiveDoctors(),
    getPublicSiteSettings(),
  ]);
  const siteInfo = siteSettingsToSiteInfo(siteSettings);

  return (
    <div className="space-y-5">
      <section className="print:hidden">
        <h1 className="text-2xl font-black text-[#062f66]">
          Appointment Requests
        </h1>
        <p className="mt-2 text-sm text-slate-600">
          View, search, print, add manual phone/counter appointments, and remove
          submitted patient appointments.
        </p>
      </section>

      <AppointmentsTable
        appointments={appointments}
        doctors={doctors}
        clinicName={siteInfo.name}
      />
    </div>
  );
}
