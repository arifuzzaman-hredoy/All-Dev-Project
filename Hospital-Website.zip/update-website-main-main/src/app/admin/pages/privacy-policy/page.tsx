import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminPrivacyPolicyPage() {
  return <StaticPageAdminPage pageKey="privacy-policy" />;
}
