import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminPatientGuidePage() {
  return <StaticPageAdminPage pageKey="patient-guide" />;
}
