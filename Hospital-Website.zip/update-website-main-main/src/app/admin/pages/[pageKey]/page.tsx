import { notFound } from "next/navigation";

import SectionEditor from "@/components/admin/SectionEditor";
import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";
import { getAdminSectionPreset } from "@/data/admin-section-presets";
import { STATIC_PAGE_KEYS, type StaticPageKey } from "@/lib/static-pages";

type PageEditorProps = {
  params: Promise<{ pageKey: string }>;
};

function isStaticPageKey(value: string): value is StaticPageKey {
  return (STATIC_PAGE_KEYS as readonly string[]).includes(value);
}

export default async function PublicPageEditor({ params }: PageEditorProps) {
  const { pageKey } = await params;

  if (isStaticPageKey(pageKey)) {
    return <StaticPageAdminPage pageKey={pageKey} />;
  }

  const preset = getAdminSectionPreset(pageKey);

  if (!preset) {
    notFound();
  }

  return <SectionEditor {...preset} />;
}
