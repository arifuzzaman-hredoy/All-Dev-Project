import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminContactPage() {
  return <StaticPageAdminPage pageKey="contact" />;
}
