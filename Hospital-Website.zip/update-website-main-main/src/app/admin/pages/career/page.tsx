import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminCareerPage() {
  return <StaticPageAdminPage pageKey="career" />;
}
