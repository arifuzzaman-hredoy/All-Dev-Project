"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import {
  DEFAULT_PATIENT_STORIES,
  PatientStory,
  fileToDataUrl,
  formatStoryDate,
  linesToParagraphs,
  slugify,
} from "@/lib/patientStories";

type FormState = {
  id: string;
  slug: string;
  title: string;
  date: string;
  image: string;
  excerpt: string;
  leadText: string;
  bodyText: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
};

function makeId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }

  return `story-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function storyToForm(item?: PatientStory): FormState {
  return {
    id: item?.id || makeId(),
    slug: item?.slug || "",
    title: item?.title || "",
    date: item?.date || new Date().toISOString().slice(0, 10),
    image: item?.image || "/slider1.jpeg",
    excerpt: item?.excerpt || "",
    leadText: item?.leadText || "",
    bodyText: item?.body.join("\n") || "",
    active: item?.active ?? true,
    sortOrder: item?.sortOrder || 10,
    createdAt: item?.createdAt || new Date().toISOString(),
  };
}

function makeUniqueSlug(
  stories: PatientStory[],
  baseSlug: string,
  currentId: string
) {
  const rootSlug = baseSlug || "patient-story";
  let slug = rootSlug;
  let counter = 2;

  while (stories.some((item) => item.slug === slug && item.id !== currentId)) {
    slug = `${rootSlug}-${counter}`;
    counter += 1;
  }

  return slug;
}

export default function PatientStoriesAdminPage() {
  const [stories, setStories] = useState<PatientStory[]>(DEFAULT_PATIENT_STORIES);
  const [form, setForm] = useState<FormState>(() => storyToForm());
  const [openForm, setOpenForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");

  useEffect(() => {
    let mounted = true;

    async function loadStories() {
      try {
        const response = await fetch("/api/admin/patient-stories", { cache: "no-store" });
        const payload = (await response.json()) as { stories?: PatientStory[] };
        if (mounted && Array.isArray(payload.stories)) {
          setStories(payload.stories);
        }
      } catch {
        // Keep fallback state if DB load fails.
      }
    }

    void loadStories();
    return () => {
      mounted = false;
    };
  }, []);

  const filteredStories = useMemo(() => {
    const keyword = search.toLowerCase().trim();

    return [...stories]
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .filter((item) => {
        if (!keyword) return true;

        return [
          item.title,
          item.date,
          item.excerpt,
          item.leadText,
          item.slug,
          item.body.join(" "),
        ]
          .join(" ")
          .toLowerCase()
          .includes(keyword);
      });
  }, [stories, search]);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }

  function persist(nextStories: PatientStory[], message: string) {
    const sorted = [...nextStories].sort((a, b) => a.sortOrder - b.sortOrder);
    setStories(sorted);
    showToast(message);

    void fetch("/api/admin/patient-stories", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sorted),
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("Save failed");
        const payload = (await response.json()) as { stories?: PatientStory[] };
        if (Array.isArray(payload.stories)) setStories(payload.stories);
      })
      .catch(() => showToast("DB save failed. Please try again."));
  }

  function updateField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function openAddForm() {
    setEditingId(null);
    setForm(storyToForm());
    setOpenForm(true);
  }

  function openEditForm(item: PatientStory) {
    setEditingId(item.id);
    setForm(storyToForm(item));
    setOpenForm(true);
  }

  function closeForm() {
    setOpenForm(false);
    setEditingId(null);
  }

  async function handleImageUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      showToast("Only image file allowed.");
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      showToast("Keep image size under 3MB.");
      return;
    }

    try {
      updateField("image", await fileToDataUrl(file));
      showToast("Image uploaded successfully.");
    } catch {
      showToast("Image upload failed.");
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const title = form.title.trim();
    const excerpt = form.excerpt.trim();
    const leadText = form.leadText.trim();
    const body = linesToParagraphs(form.bodyText);

    if (!title) return showToast("Story title required.");
    if (!form.date) return showToast("Story date required.");
    if (!excerpt) return showToast("Card short text required.");
    if (!leadText) return showToast("Detail lead text required.");
    if (!body.length) return showToast("Minimum 1 story paragraph required.");

    const finalSlug = makeUniqueSlug(
      stories,
      slugify(form.slug || title),
      form.id
    );
    const payload: PatientStory = {
      id: form.id,
      slug: finalSlug,
      title,
      date: form.date,
      image: form.image.trim() || "/slider1.jpeg",
      excerpt,
      leadText,
      body,
      active: form.active,
      sortOrder: Number(form.sortOrder) || 10,
      createdAt: form.createdAt,
      updatedAt: new Date().toISOString(),
    };

    persist(
      editingId
        ? stories.map((item) => (item.id === editingId ? payload : item))
        : [...stories, payload],
      editingId
        ? "Patient story updated successfully."
        : "Patient story added successfully."
    );
    closeForm();
  }

  function toggleActive(id: string) {
    persist(
      stories.map((item) =>
        item.id === id
          ? { ...item, active: !item.active, updatedAt: new Date().toISOString() }
          : item
      ),
      "Story visibility updated."
    );
  }

  function deleteStory(id: string) {
    const item = stories.find((story) => story.id === id);
    if (!item || !window.confirm(`Delete "${item.title}" story?`)) return;

    persist(
      stories.filter((story) => story.id !== id),
      "Patient story deleted successfully."
    );
  }

  function duplicateStory(item: PatientStory) {
    const id = makeId();
    persist(
      [
        ...stories,
        {
          ...item,
          id,
          slug: makeUniqueSlug(stories, `${item.slug}-copy`, id),
          title: `${item.title} Copy`,
          sortOrder: item.sortOrder + 1,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ],
      "Story duplicated."
    );
  }

  function resetDefault() {
    if (
      !window.confirm(
        "Reset patient stories to default data? Current custom stories will be removed."
      )
    ) {
      return;
    }

    setStories(DEFAULT_PATIENT_STORIES);
    showToast("Default patient stories restoring...");
    void fetch("/api/admin/patient-stories/reset", { method: "POST" })
      .then(async (response) => {
        const payload = (await response.json()) as { stories?: PatientStory[] };
        if (Array.isArray(payload.stories)) setStories(payload.stories);
        showToast("Default patient stories restored.");
      })
      .catch(() => showToast("Reset failed. Please try again."));
  }

  return (
    <main className="min-h-screen bg-[#f4f8fc] p-4 text-[#002f70] sm:p-7">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 rounded-lg bg-[#002f70] px-4 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section className="border border-[#d7e3f1] bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#8061bd]">
              CMS Control
            </p>
            <h1 className="mt-2 text-3xl font-black">Patient Stories</h1>
            <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-[#49668b]">
              Add, edit, upload image, hide, delete, sort and publish patient
              stories. Active stories will show on the public page.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={resetDefault}
              className="border border-[#c7d7ea] bg-white px-4 py-3 text-sm font-black"
            >
              Reset Default
            </button>
            <button
              type="button"
              onClick={openAddForm}
              className="bg-[#002f70] px-4 py-3 text-sm font-black text-white"
            >
              Add Story
            </button>
          </div>
        </div>
      </section>

      <section className="mt-4 grid gap-3 border border-[#d7e3f1] bg-white p-4 md:grid-cols-[2fr_1fr_1fr]">
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Search stories
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search by title, date, story..."
            className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
          />
        </label>
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Total stories
          <input
            value={`${stories.length} stories`}
            readOnly
            className="h-11 border border-[#c6d6e8] bg-[#f8fbff] px-3 text-sm font-semibold"
          />
        </label>
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Public active
          <input
            value={`${stories.filter((item) => item.active).length} active`}
            readOnly
            className="h-11 border border-[#c6d6e8] bg-[#f8fbff] px-3 text-sm font-semibold"
          />
        </label>
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-2">
        {filteredStories.map((item) => (
          <article
            key={item.id}
            className={`overflow-hidden border border-[#d5e2f0] bg-white shadow-sm ${
              item.active ? "" : "opacity-60"
            }`}
          >
            <div className="grid sm:grid-cols-[210px_1fr]">
              <div className="relative min-h-56 bg-[#dfeaf6]">
                <img
                  src={item.image}
                  alt={item.title}
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <span
                  className={`absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-black text-white ${
                    item.active ? "bg-[#079455]" : "bg-[#b42318]"
                  }`}
                >
                  {item.active ? "Active" : "Hidden"}
                </span>
              </div>
              <div className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-black tracking-[0.22em] text-[#8061bd]">
                      {formatStoryDate(item.date)}
                    </p>
                    <h2 className="mt-2 text-xl font-black leading-7">
                      {item.title}
                    </h2>
                  </div>
                  <strong className="rounded-full bg-[#eef6ff] px-3 py-1 text-xs">
                    Sort: {item.sortOrder}
                  </strong>
                </div>
                <p className="mt-3 line-clamp-2 text-sm font-semibold leading-6 text-[#49668b]">
                  {item.excerpt}
                </p>
                <div className="mt-3 flex flex-wrap gap-2 text-xs font-black text-[#27527d]">
                  <span className="rounded-full bg-[#eef6ff] px-3 py-1">
                    /{item.slug}
                  </span>
                  <span className="rounded-full bg-[#eef6ff] px-3 py-1">
                    {item.body.length} paragraphs
                  </span>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => openEditForm(item)}
                    className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleActive(item.id)}
                    className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black"
                  >
                    {item.active ? "Hide" : "Show"}
                  </button>
                  <button
                    type="button"
                    onClick={() => duplicateStory(item)}
                    className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black"
                  >
                    Duplicate
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteStory(item.id)}
                    className="border border-[#ffd1d1] bg-[#fff1f1] px-3 py-2 text-sm font-black text-[#b42318]"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </article>
        ))}
      </section>

      {openForm ? (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-auto bg-slate-900/50 p-4 backdrop-blur-sm">
          <form
            onSubmit={handleSubmit}
            className="max-h-[92vh] w-full max-w-5xl overflow-auto bg-white p-4 shadow-2xl"
          >
            <div className="mb-4 flex flex-wrap items-start justify-between gap-4">
              <div>
                <h2 className="text-xl font-black">
                  {editingId ? "Edit patient story" : "Add patient story"}
                </h2>
                <p className="mt-1 text-sm font-semibold text-[#49668b]">
                  Add picture, title, date, card text, detail content, sorting
                  and visibility.
                </p>
              </div>
              <button
                type="button"
                onClick={closeForm}
                className="border border-[#c6d6e8] bg-white px-4 py-3 text-sm font-bold"
              >
                Close
              </button>
            </div>

            <div className="mb-4 grid gap-3 md:grid-cols-[110px_1fr]">
              <div className="h-[110px] overflow-hidden border border-[#c6d6e8] bg-[#f8fbff]">
                {form.image ? (
                  <img
                    src={form.image}
                    alt="Story preview"
                    className="h-full w-full object-cover"
                  />
                ) : null}
              </div>
              <div className="grid gap-3">
                <input
                  value={form.image}
                  onChange={(event) => updateField("image", event.target.value)}
                  placeholder="/slider1.jpeg or uploaded image"
                  className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none"
                />
                <label className="inline-flex w-fit cursor-pointer bg-[#071126] px-4 py-3 text-sm font-black text-white">
                  Choose File
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <FormInput
                label="Story title *"
                value={form.title}
                onChange={(value) => updateField("title", value)}
                placeholder="Successful Knee Surgery"
              />
              <FormInput
                label="Story date *"
                type="date"
                value={form.date}
                onChange={(value) => updateField("date", value)}
              />
              <FormInput
                label="Slug"
                value={form.slug}
                onChange={(value) => updateField("slug", value)}
                placeholder="auto-from-story-title"
              />
              <FormInput
                label="Sort order"
                type="number"
                value={String(form.sortOrder)}
                onChange={(value) => updateField("sortOrder", Number(value))}
              />
            </div>

            <FormTextarea
              label="Card short text / excerpt *"
              rows={3}
              value={form.excerpt}
              onChange={(value) => updateField("excerpt", value)}
              placeholder="Short text for story card..."
            />
            <FormTextarea
              label="Detail bold lead text *"
              rows={3}
              value={form.leadText}
              onChange={(value) => updateField("leadText", value)}
              placeholder="A careful diagnosis..."
            />
            <FormTextarea
              label="Story detail paragraphs *"
              rows={9}
              value={form.bodyText}
              onChange={(value) => updateField("bodyText", value)}
              placeholder={`Paragraph one...\nParagraph two...\nParagraph three...`}
              help="One line = one paragraph. Detail page-e paragraph hisebe show hobe."
            />

            <label className="mt-4 flex items-center gap-2 text-sm font-black">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(event) => updateField("active", event.target.checked)}
              />
              Active story
            </label>

            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={closeForm}
                className="border border-[#c7d7ea] bg-white px-5 py-3 text-sm font-black"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-[#002f70] px-5 py-3 text-sm font-black text-white"
              >
                {editingId ? "Update Story" : "Add Story"}
              </button>
            </div>
          </form>
        </div>
      ) : null}
    </main>
  );
}

function FormInput({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none"
      />
    </label>
  );
}

function FormTextarea({
  label,
  value,
  onChange,
  placeholder,
  rows,
  help,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  rows: number;
  help?: string;
}) {
  return (
    <label className="mt-4 grid gap-2 text-xs font-black uppercase text-[#24476e]">
      {label}
      <textarea
        rows={rows}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="resize-y border border-[#c6d6e8] px-3 py-3 text-sm font-semibold leading-6 outline-none"
      />
      {help ? (
        <small className="text-xs font-bold normal-case text-[#687f9e]">
          {help}
        </small>
      ) : null}
    </label>
  );
}
