import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminSupportPage() {
  return <StaticPageAdminPage pageKey="support" />;
}
