import AboutPageAdmin from "@/components/admin/AboutPageAdmin";

export default function AdminAboutPage() {
  return <AboutPageAdmin />;
}
