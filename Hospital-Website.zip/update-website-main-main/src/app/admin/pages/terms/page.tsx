import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminTermsPage() {
  return <StaticPageAdminPage pageKey="terms" />;
}
