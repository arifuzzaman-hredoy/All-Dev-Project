"use client";

import LocalContentAdmin from "@/components/admin/LocalContentAdmin";
import {
  DEFAULT_NEWS_MEDIA,
  fileToDataUrl,
  formatNewsDate,
  linesToParagraphs,
  slugify,
} from "@/lib/newsMedia";

export default function AdminNewsMediaPage() {
  return (
    <LocalContentAdmin
      title="News & Media"
      eyebrow="CMS Control"
      description="Add, edit, upload image, hide, delete, sort and publish news and media updates."
      defaultItems={DEFAULT_NEWS_MEDIA}
      slugify={slugify}
      fileToDataUrl={fileToDataUrl}
      linesToParagraphs={linesToParagraphs}
      formatDate={formatNewsDate}
      defaultCategory="Media Update"
      defaultImage="/news/news-1.jpg"
      apiBasePath="/api/admin/content/news-media"
      remoteEventName="news-media-updated"
    />
  );
}
