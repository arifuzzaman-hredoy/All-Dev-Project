"use client";

import LocalContentAdmin from "@/components/admin/LocalContentAdmin";
import {
  DEFAULT_DOCTOR_ARTICLES,
  fileToDataUrl,
  formatArticleDate,
  linesToParagraphs,
  slugify,
} from "@/lib/doctorArticles";

export default function AdminDoctorArticlesPage() {
  return (
    <LocalContentAdmin
      title="Doctor Articles"
      eyebrow="CMS Control"
      description="Add, edit, upload image, author, date, content, visibility and sorting for doctor-written articles."
      defaultItems={DEFAULT_DOCTOR_ARTICLES}
      slugify={slugify}
      fileToDataUrl={fileToDataUrl}
      linesToParagraphs={linesToParagraphs}
      formatDate={formatArticleDate}
      defaultCategory="Doctor Article"
      defaultImage="/doctor-articles/doctor-1.jpg"
      authorLabel="Author"
      apiBasePath="/api/admin/content/doctor-articles"
      remoteEventName="doctor-articles-updated"
    />
  );
}
