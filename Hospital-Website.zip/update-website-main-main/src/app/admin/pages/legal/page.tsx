import AdminPresetPage from "@/components/admin/AdminPresetPage";

export default function AdminLegalPage() {
  return <AdminPresetPage presetKey="legal" />;
}
