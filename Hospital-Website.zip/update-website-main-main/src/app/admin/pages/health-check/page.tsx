"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import {
  HealthPackage,
  createHealthPackage,
  deleteHealthPackage,
  fetchHealthPackages,
  fileToDataUrl,
  linesToArray,
  resetDefaultHealthPackages,
  setHealthPackageActive,
  slugify,
  updateHealthPackage,
} from "@/lib/healthPackages";
import {
  PackageBooking,
  PaymentStatus,
  deletePackageBooking,
  fetchPackageBookings,
  formatDateTime,
  updatePackageBookingStatus,
} from "@/lib/packageBookings";

type FormState = {
  id: string;
  slug: string;
  title: string;
  badge: string;
  price: string;
  target: string;
  subtitle: string;
  image: string;
  testsText: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
};

function makeId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }

  return `health-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function packageToForm(item?: HealthPackage): FormState {
  return {
    id: item?.id || makeId(),
    slug: item?.slug || "",
    title: item?.title || "",
    badge: item?.badge || "HEALTH PACKAGES",
    price: item?.price || "",
    target: item?.target || "",
    subtitle:
      item?.subtitle ||
      "Choose a suitable health check package for preventive care, routine screening, and better health planning.",
    image: item?.image || "/slider1.jpeg",
    testsText: item?.tests.join("\n") || "",
    active: item?.active ?? true,
    sortOrder: item?.sortOrder || 10,
    createdAt: item?.createdAt || new Date().toISOString(),
  };
}

function makeUniqueSlug(
  packages: HealthPackage[],
  baseSlug: string,
  currentId: string
) {
  const rootSlug = baseSlug || "health-package";
  let slug = rootSlug;
  let counter = 2;

  while (packages.some((item) => item.slug === slug && item.id !== currentId)) {
    slug = `${rootSlug}-${counter}`;
    counter += 1;
  }

  return slug;
}

export default function HealthAdminPage() {
  const [packages, setPackages] = useState<HealthPackage[]>([]);
  const [packageRequests, setPackageRequests] = useState<PackageBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState>(() => packageToForm());
  const [openForm, setOpenForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [requestSearch, setRequestSearch] = useState("");
  const [toast, setToast] = useState("");

  async function loadPackages() {
    const nextPackages = await fetchHealthPackages({ admin: true });
    setPackages(nextPackages);
  }

  async function loadPackageRequests() {
    const nextBookings = await fetchPackageBookings();
    setPackageRequests(
      nextBookings.sort(
        (a, b) =>
          new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
      )
    );
  }

  useEffect(() => {
    let active = true;

    Promise.all([fetchHealthPackages({ admin: true }), fetchPackageBookings()])
      .then(([nextPackages, nextBookings]) => {
        if (!active) return;
        setPackages(nextPackages);
        setPackageRequests(
          nextBookings.sort(
            (a, b) =>
              new Date(b.submittedAt).getTime() -
              new Date(a.submittedAt).getTime()
          )
        );
      })
      .catch(() => showToast("Failed to load health package data."))
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const filteredPackages = useMemo(() => {
    const keyword = search.toLowerCase().trim();

    return [...packages]
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .filter((item) => {
        if (!keyword) return true;

        return [
          item.title,
          item.price,
          item.target,
          item.slug,
          item.tests.join(" "),
        ]
          .join(" ")
          .toLowerCase()
          .includes(keyword);
      });
  }, [packages, search]);

  const filteredPackageRequests = useMemo(() => {
    const keyword = requestSearch.toLowerCase().trim();
    const requests = packageRequests;

    if (!keyword) return requests;

    return requests.filter((item) =>
      [
        item.patientName,
        item.phone,
        item.packageName,
        item.packageTarget,
        item.paymentMethod,
        item.transactionId,
        item.paymentStatus,
        item.token,
        item.receiptNo,
      ]
        .join(" ")
        .toLowerCase()
        .includes(keyword)
    );
  }, [packageRequests, requestSearch]);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  }


  function updateField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function openAddForm() {
    setEditingId(null);
    setForm(packageToForm());
    setOpenForm(true);
  }

  function openEditForm(item: HealthPackage) {
    setEditingId(item.id);
    setForm(packageToForm(item));
    setOpenForm(true);
  }

  async function handleImageUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      showToast("Only image file allowed.");
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      showToast("Keep image size under 3MB.");
      return;
    }

    try {
      updateField("image", await fileToDataUrl(file));
      showToast("Image uploaded.");
    } catch {
      showToast("Image upload failed.");
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const title = form.title.trim();
    const price = form.price.trim();
    const tests = linesToArray(form.testsText);

    if (!title) return showToast("Package name required.");
    if (!price) return showToast("Package price required.");
    if (!tests.length) return showToast("Minimum 1 test/item required.");

    const finalSlug = makeUniqueSlug(
      packages,
      slugify(form.slug || title),
      form.id
    );
    const now = new Date().toISOString();
    const payload: HealthPackage = {
      id: form.id,
      slug: finalSlug,
      title,
      name: title,
      badge: form.badge.trim() || "HEALTH PACKAGES",
      price,
      target: form.target.trim(),
      subtitle: form.subtitle.trim(),
      image: form.image.trim() || "/slider1.jpeg",
      tests,
      active: form.active,
      sortOrder: Number(form.sortOrder) || 10,
      createdAt: form.createdAt,
      updatedAt: now,
    };

    try {
      if (editingId) {
        await updateHealthPackage(editingId, payload);
        showToast("Health package updated successfully.");
      } else {
        await createHealthPackage(payload);
        showToast("Health package added successfully.");
      }
      await loadPackages();
      setOpenForm(false);
      setEditingId(null);
    } catch {
      showToast("Health package save failed.");
    }
  }

  async function toggleActive(id: string) {
    const item = packages.find((pkg) => pkg.id === id);
    if (!item) return;

    try {
      await setHealthPackageActive(id, !item.active);
      await loadPackages();
      showToast("Package visibility updated.");
    } catch {
      showToast("Package visibility update failed.");
    }
  }

  async function duplicatePackage(item: HealthPackage) {
    const id = makeId();
    try {
      await createHealthPackage({
        ...item,
        id,
        slug: makeUniqueSlug(packages, `${item.slug}-copy`, id),
        title: `${item.title} Copy`,
        name: `${item.title} Copy`,
        sortOrder: item.sortOrder + 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      await loadPackages();
      showToast("Package duplicated.");
    } catch {
      showToast("Package duplicate failed.");
    }
  }

  async function deletePackageRecord(id: string) {
    const item = packages.find((pkg) => pkg.id === id);
    if (!item || !window.confirm(`Delete "${item.title}" package?`)) return;

    try {
      await deleteHealthPackage(id);
      await loadPackages();
      showToast("Package deleted successfully.");
    } catch {
      showToast("Package delete failed.");
    }
  }

  async function resetDefault() {
    if (
      !window.confirm(
        "Reset health packages to default data? Current custom data will be removed."
      )
    ) {
      return;
    }

    try {
      const nextPackages = await resetDefaultHealthPackages();
      setPackages(nextPackages);
      showToast("Default health packages restored.");
    } catch {
      showToast("Default reset failed.");
    }
  }

  async function handleRequestStatus(id: string, status: PaymentStatus) {
    try {
      await updatePackageBookingStatus(id, status);
      await loadPackageRequests();
      showToast(`Request status updated: ${status}`);
    } catch {
      showToast("Request status update failed.");
    }
  }

  async function handleRequestDelete(id: string) {
    if (!window.confirm("Delete this package request?")) return;

    try {
      await deletePackageBooking(id);
      await loadPackageRequests();
      showToast("Package request deleted.");
    } catch {
      showToast("Package request delete failed.");
    }
  }

  if (loading) {
    return (
      <main className="grid min-h-screen place-items-center bg-[#f4f8fc] p-8 text-center text-[#002f70]">
        <div>
          <h1 className="text-2xl font-black">Loading health package CMS...</h1>
          <p className="mt-2 text-sm font-semibold text-[#49668b]">
            Database theke package data load hocche.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#f4f8fc] p-4 text-[#002f70] sm:p-7">
      {toast ? (
        <div className="fixed right-5 top-5 z-50 rounded-lg bg-[#002f70] px-4 py-3 text-sm font-black text-white shadow-xl">
          {toast}
        </div>
      ) : null}

      <section className="flex flex-col justify-between gap-5 border border-[#d7e3f1] bg-white p-5 shadow-sm lg:flex-row lg:items-center">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#8061bd]">
            CMS Control
          </p>
          <h1 className="mt-2 text-3xl font-black">Health Check Packages</h1>
          <p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-[#49668b]">
            Add, edit, upload image, hide, delete, sort and publish health
            check packages. Active packages will show on the public page.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={resetDefault}
            className="border border-[#c7d7ea] bg-white px-4 py-3 text-sm font-black"
          >
            Reset Default
          </button>
          <button
            type="button"
            onClick={openAddForm}
            className="bg-[#002f70] px-4 py-3 text-sm font-black text-white"
          >
            Add Package
          </button>
        </div>
      </section>

      <section className="mt-4 grid gap-3 border border-[#d7e3f1] bg-white p-4 md:grid-cols-[2fr_1fr_1fr]">
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Search package
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search by name, price, slug, test..."
            className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
          />
        </label>
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Total packages
          <input
            value={`${packages.length} packages`}
            readOnly
            className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold"
          />
        </label>
        <label className="grid gap-2 text-xs font-black uppercase text-[#24476e]">
          Public active
          <input
            value={`${packages.filter((item) => item.active).length} active`}
            readOnly
            className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold"
          />
        </label>
      </section>

      <section className="healthRequestsPrintArea mt-4 border border-[#d7e3f1] bg-white p-4 shadow-sm">
        <section className="onlyPrint hidden">
          <div className="text-center text-[10px]">
            Admin Panel | Update Diagnostic Center
          </div>
          <h1 className="text-lg font-black">Update Diagnostic Center</h1>
          <p className="text-xs">Health Package Booking Requests</p>
          <span className="text-xs">
            Printed: {formatDateTime(new Date().toISOString())}
          </span>
        </section>

        <div className="noPrint flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#8061bd]">
              Live Package Requests
            </p>
            <h2 className="mt-2 text-2xl font-black">
              Who requested health packages
            </h2>
            <p className="mt-1 text-sm font-semibold text-[#49668b]">
              New booking requests update here automatically from the database.
            </p>
          </div>
          <div className="flex w-full flex-col gap-2 sm:flex-row sm:items-end lg:max-w-2xl">
            <label className="grid flex-1 gap-2 text-xs font-black uppercase text-[#24476e]">
              Search requests
              <input
                value={requestSearch}
                onChange={(event) => setRequestSearch(event.target.value)}
                placeholder="Patient, phone, package, token..."
                className="h-11 border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
              />
            </label>
            <button
              type="button"
              onClick={() => window.print()}
              className="h-11 border border-[#c7d7ea] bg-[#002f70] px-4 text-sm font-black text-white"
            >
              Print Requests
            </button>
          </div>
        </div>

        <div className="noPrint mt-4 grid gap-3 md:grid-cols-4">
          <RequestStat label="Total requests" value={packageRequests.length} />
          <RequestStat
            label="Submitted"
            value={
              packageRequests.filter(
                (item) => item.paymentStatus === "Payment Submitted"
              ).length
            }
          />
          <RequestStat
            label="Cash request"
            value={
              packageRequests.filter(
                (item) => item.paymentStatus === "Cash Request"
              ).length
            }
          />
          <RequestStat
            label="Verified"
            value={
              packageRequests.filter((item) => item.paymentStatus === "Verified")
                .length
            }
          />
        </div>

        <div className="healthRequestsTableWrap mt-4 overflow-auto border border-[#bdcfe5]">
          <table className="healthRequestsPrintTable w-max min-w-full border-collapse bg-white">
            <thead>
              <tr>
                {[
                  "Date",
                  "Patient",
                  "Phone",
                  "Package",
                  "Payment",
                  "Token / Receipt",
                  "Status",
                  "Action",
                ].map((heading) => (
                  <th
                    key={heading}
                    className={`border border-[#bdcfe5] bg-[#f0f5fb] p-2 text-left text-xs font-black uppercase text-[#123866] ${
                      heading === "Action" ? "noPrint" : ""
                    }`}
                  >
                    {heading}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredPackageRequests.map((item) => (
                <tr key={item.id}>
                  <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
                    {formatDateTime(item.submittedAt)}
                  </td>
                  <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-black text-[#001b45]">
                    {item.patientName}
                  </td>
                  <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
                    {item.phone}
                  </td>
                  <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
                    <strong>{item.packageName}</strong>
                    {item.packageTarget ? (
                      <>
                        <br />
                        <span>{item.packageTarget}</span>
                      </>
                    ) : null}
                  </td>
                  <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
                    {item.paymentMethod}
                    <br />
                    <span>{item.amountPaid}</span>
                  </td>
                  <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
                    <strong>{item.token}</strong>
                    <br />
                    <span>{item.receiptNo}</span>
                  </td>
                  <td className="whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
                    <RequestStatus status={item.paymentStatus} />
                  </td>
                  <td className="noPrint whitespace-nowrap border border-[#bdcfe5] p-2 align-top text-xs font-semibold text-[#001b45]">
                    <div className="flex flex-wrap gap-1">
                      <button
                        type="button"
                        onClick={() => handleRequestStatus(item.id, "Verified")}
                        className="border border-[#b7e4cf] bg-[#ecfdf3] px-2 py-1 text-xs font-black text-[#067647]"
                      >
                        Verify
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRequestStatus(item.id, "Rejected")}
                        className="border border-[#ffd1d1] bg-[#fff1f1] px-2 py-1 text-xs font-black text-[#b42318]"
                      >
                        Reject
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRequestDelete(item.id)}
                        className="border border-[#d8e6f5] bg-[#f8fbff] px-2 py-1 text-xs font-black text-[#002f70]"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {!filteredPackageRequests.length ? (
                <tr>
                  <td
                    colSpan={8}
                    className="border border-[#bdcfe5] p-6 text-center text-sm font-black text-[#5b6f8e]"
                  >
                    No package request found.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-2">
        {filteredPackages.map((item) => (
          <article
            key={item.id}
            className={`grid overflow-hidden border border-[#d5e2f0] bg-white shadow-sm sm:grid-cols-[190px_1fr] ${
              item.active ? "" : "opacity-60"
            }`}
          >
            <div className="relative min-h-56 bg-[#dfeaf6]">
              <img
                src={item.image}
                alt={item.title}
                className="h-full w-full object-cover"
              />
              <span
                className={`absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-black text-white ${
                  item.active ? "bg-[#079455]" : "bg-[#9b1c1c]"
                }`}
              >
                {item.active ? "Active" : "Hidden"}
              </span>
            </div>
            <div className="p-5">
              <div className="flex flex-wrap justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black">{item.title}</h2>
                  <p className="mt-1 text-sm font-black text-[#49668b]">
                    {item.target || "No target text"}
                  </p>
                </div>
                <strong className="text-xl font-black text-[#35bbea]">
                  {item.price}
                </strong>
              </div>
              <div className="mt-3 flex flex-wrap gap-2 text-xs font-black text-[#27527d]">
                <span className="rounded-full bg-[#eef6ff] px-3 py-1">
                  Sort: {item.sortOrder}
                </span>
                <span className="rounded-full bg-[#eef6ff] px-3 py-1">
                  {item.tests.length} items
                </span>
                <span className="rounded-full bg-[#eef6ff] px-3 py-1">
                  /{item.slug}
                </span>
              </div>
              <ul className="my-4 list-disc pl-5 text-sm font-bold leading-7">
                {item.tests.slice(0, 4).map((test) => (
                  <li key={test}>{test}</li>
                ))}
              </ul>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => openEditForm(item)}
                  className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black text-[#002f70]"
                >
                  Edit
                </button>
                <button
                  onClick={() => toggleActive(item.id)}
                  className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black text-[#002f70]"
                >
                  {item.active ? "Hide" : "Show"}
                </button>
                <button
                  onClick={() => duplicatePackage(item)}
                  className="border border-[#cfe1f5] bg-[#eef6ff] px-3 py-2 text-sm font-black text-[#002f70]"
                >
                  Duplicate
                </button>
                <button
                  onClick={() => deletePackageRecord(item.id)}
                  className="border border-[#ffd1d1] bg-[#fff1f1] px-3 py-2 text-sm font-black text-[#b42318]"
                >
                  Delete
                </button>
              </div>
            </div>
          </article>
        ))}
      </section>

      {openForm ? (
        <div className="fixed inset-0 z-40 grid place-items-center bg-slate-950/45 p-4 backdrop-blur-sm">
          <form
            onSubmit={handleSubmit}
            className="max-h-[92vh] w-full max-w-4xl overflow-auto bg-white p-4 shadow-2xl"
          >
            <div className="flex flex-wrap justify-between gap-3">
              <div>
                <h2 className="text-xl font-black">
                  {editingId ? "Edit health package" : "Add health package"}
                </h2>
                <p className="mt-1 text-sm font-semibold text-[#49668b]">
                  Add image, title, price, target text, package list, sorting
                  and visibility.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setOpenForm(false)}
                className="h-10 border border-[#c6d6e8] px-4 text-sm font-bold"
              >
                Close
              </button>
            </div>

            <div className="mt-4 grid grid-cols-[96px_1fr] gap-3">
              <div className="grid h-24 w-24 place-items-center overflow-hidden border border-[#c6d6e8] bg-[#f8fbff] text-xs font-bold text-[#7d91ad]">
                {form.image ? (
                  <img
                    src={form.image}
                    alt="Package preview"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  "No Image"
                )}
              </div>
              <div className="grid gap-3">
                <input
                  value={form.image}
                  onChange={(event) => updateField("image", event.target.value)}
                  placeholder="/slider1.jpeg or uploaded image"
                  className="h-11 border border-[#c6d6e8] px-3 text-sm outline-none"
                />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="text-sm font-semibold"
                />
              </div>
            </div>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <Field label="Package name *">
                <input
                  value={form.title}
                  onChange={(event) => updateField("title", event.target.value)}
                  placeholder="HAJJ HEALTH CHECK"
                  className="min-h-11 w-full border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
                />
              </Field>
              <Field label="Price *">
                <input
                  value={form.price}
                  onChange={(event) => updateField("price", event.target.value)}
                  placeholder="8,500 BDT"
                  className="min-h-11 w-full border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
                />
              </Field>
              <Field label="Badge">
                <input
                  value={form.badge}
                  onChange={(event) => updateField("badge", event.target.value)}
                  className="min-h-11 w-full border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
                />
              </Field>
              <Field label="Target">
                <input
                  value={form.target}
                  onChange={(event) => updateField("target", event.target.value)}
                  placeholder="FOR MEN / FOR WOMEN"
                  className="min-h-11 w-full border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
                />
              </Field>
              <Field label="Slug">
                <input
                  value={form.slug}
                  onChange={(event) => updateField("slug", event.target.value)}
                  placeholder="auto-from-package-name"
                  className="min-h-11 w-full border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
                />
              </Field>
              <Field label="Sort order">
                <input
                  type="number"
                  value={form.sortOrder}
                  onChange={(event) =>
                    updateField("sortOrder", Number(event.target.value))
                  }
                  className="min-h-11 w-full border border-[#c6d6e8] px-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
                />
              </Field>
            </div>

            <Field label="Package subtitle" className="mt-3">
              <textarea
                rows={3}
                value={form.subtitle}
                onChange={(event) => updateField("subtitle", event.target.value)}
                className="min-h-24 w-full border border-[#c6d6e8] px-3 py-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
              />
            </Field>
            <Field label="Package tests/items *" className="mt-3">
              <textarea
                rows={9}
                value={form.testsText}
                onChange={(event) =>
                  updateField("testsText", event.target.value)
                }
                placeholder={`CBC\nCREATININE-SERUM\nECG`}
                className="min-h-52 w-full border border-[#c6d6e8] px-3 py-3 text-sm font-semibold outline-none focus:border-[#269ad4]"
              />
            </Field>
            <label className="mt-4 flex items-center gap-2 text-sm font-black">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(event) => updateField("active", event.target.checked)}
              />
              Active package
            </label>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setOpenForm(false)}
                className="border border-[#c7d7ea] px-5 py-3 text-sm font-black"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-[#002f70] px-5 py-3 text-sm font-black text-white"
              >
                {editingId ? "Update Package" : "Add Package"}
              </button>
            </div>
          </form>
        </div>
      ) : null}

      <style jsx global>{`
        @media print {
          @page {
            size: A4 landscape;
            margin: 6mm;
          }

          html,
          body {
            width: 297mm;
            min-height: 210mm;
            overflow: visible !important;
            background: #fff !important;
          }

          body * {
            visibility: hidden !important;
          }

          .healthRequestsPrintArea,
          .healthRequestsPrintArea * {
            visibility: visible !important;
          }

          .healthRequestsPrintArea {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            border: 0 !important;
            box-shadow: none !important;
            padding: 0 !important;
            color: #000 !important;
            background: #fff !important;
          }

          .noPrint {
            display: none !important;
          }

          .onlyPrint {
            display: block !important;
          }

          .healthRequestsTableWrap {
            margin-top: 8px !important;
            overflow: visible !important;
            border: 0 !important;
          }

          .healthRequestsPrintTable {
            width: 100% !important;
            min-width: 0 !important;
            table-layout: fixed !important;
            border-collapse: collapse !important;
            border: 1px solid #111 !important;
          }

          .healthRequestsPrintTable th,
          .healthRequestsPrintTable td {
            border: 1px solid #111 !important;
            padding: 4px !important;
            color: #000 !important;
            font-size: 8px !important;
            line-height: 1.25 !important;
            white-space: normal !important;
            overflow-wrap: anywhere !important;
            vertical-align: top !important;
          }

          .healthRequestsPrintTable th {
            background: #e9edf3 !important;
            font-weight: 900 !important;
            text-transform: uppercase !important;
          }

          .healthRequestsPrintTable span,
          .healthRequestsPrintTable strong {
            color: #000 !important;
            font-size: inherit !important;
            line-height: inherit !important;
          }

          .healthRequestsPrintTable .inline-flex {
            display: inline !important;
            border-radius: 0 !important;
            background: transparent !important;
            padding: 0 !important;
            color: #000 !important;
          }
        }
      `}</style>
    </main>
  );
}

function RequestStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="border border-[#d8e6f5] bg-[#f8fbff] p-4">
      <p className="text-xs font-black uppercase tracking-[0.12em] text-[#5b6f8e]">
        {label}
      </p>
      <strong className="mt-2 block text-2xl font-black text-[#002f70]">
        {value}
      </strong>
    </div>
  );
}

function RequestStatus({ status }: { status: PaymentStatus }) {
  const className =
    status === "Verified"
      ? "bg-[#07834f]"
      : status === "Rejected"
        ? "bg-[#b42318]"
        : status === "Cash Request"
          ? "bg-[#8a5a00]"
          : "bg-[#1d70b8]";

  return (
    <span
      className={`inline-flex rounded-full px-2 py-1 text-[11px] font-black text-white ${className}`}
    >
      {status}
    </span>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label
      className={`grid gap-2 text-xs font-black uppercase text-[#24476e] ${className}`}
    >
      {label}
      {children}
    </label>
  );
}
