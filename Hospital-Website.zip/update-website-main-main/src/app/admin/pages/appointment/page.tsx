import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminAppointmentPage() {
  return <StaticPageAdminPage pageKey="appointment" />;
}
