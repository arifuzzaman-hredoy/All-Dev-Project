"use client";

import LocalContentAdmin from "@/components/admin/LocalContentAdmin";
import {
  DEFAULT_HEALTH_BLOGS,
  fileToDataUrl,
  formatBlogDate,
  linesToParagraphs,
  slugify,
} from "@/lib/healthBlogs";

export default function AdminBlogsPage() {
  return (
    <LocalContentAdmin
      title="Health Blogs"
      eyebrow="CMS Control"
      description="Add, edit, upload image, date, category, content, visibility and sorting for health blogs."
      defaultItems={DEFAULT_HEALTH_BLOGS}
      slugify={slugify}
      fileToDataUrl={fileToDataUrl}
      linesToParagraphs={linesToParagraphs}
      formatDate={formatBlogDate}
      defaultCategory="Health Blog"
      defaultImage="/blogs/blog-1.jpg"
      apiBasePath="/api/admin/content/blogs"
      remoteEventName="health-blogs-updated"
    />
  );
}
