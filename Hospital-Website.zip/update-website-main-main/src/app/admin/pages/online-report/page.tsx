import StaticPageAdminPage from "@/components/static-pages/StaticPageAdminPage";

export default function AdminOnlineReportPage() {
  return <StaticPageAdminPage pageKey="online-report" />;
}
