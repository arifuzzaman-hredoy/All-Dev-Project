import { redirect } from "next/navigation";
import { LockKeyhole, ShieldAlert } from "lucide-react";
import AdminUsersManager from "@/components/admin/users/AdminUsersManager";
import { getCurrentAdminUser } from "@/lib/admin-session";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage() {
  const admin = await getCurrentAdminUser();

  if (!admin) {
    redirect("/admin/login");
  }

  if (admin.role !== "SUPER_ADMIN") {
    return (
      <div className="mx-auto max-w-3xl rounded-[32px] border border-amber-200 bg-amber-50 p-8 text-amber-900 shadow-sm">
        <p className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em]">
          <ShieldAlert size={16} /> Super Admin only
        </p>
        <h1 className="mt-3 text-3xl font-black text-amber-950">Access restricted</h1>
        <p className="mt-4 text-sm font-semibold leading-7">
          Your current role is <b>{admin.role}</b>. Admin user management is protected and can only be opened by a Super Admin.
        </p>
        <div className="mt-5 inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm font-black text-amber-900 shadow-sm">
          <LockKeyhole size={17} /> Ask a Super Admin to create or update accounts.
        </div>
      </div>
    );
  }

  return <AdminUsersManager currentAdminEmail={admin.email} />;
}
