import { NextResponse } from "next/server";
import { isHomeSectionTeaserKey } from "@/lib/home-section-teaser-types";
import { getHomeSectionTeaser } from "@/lib/home-section-teasers";

type RouteContext = {
  params: Promise<{ sectionKey: string }>;
};

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: RouteContext) {
  const { sectionKey } = await context.params;

  if (!isHomeSectionTeaserKey(sectionKey)) {
    return NextResponse.json({ message: "Invalid section key." }, { status: 404 });
  }

  const section = await getHomeSectionTeaser(sectionKey);
  return NextResponse.json({ section });
}
