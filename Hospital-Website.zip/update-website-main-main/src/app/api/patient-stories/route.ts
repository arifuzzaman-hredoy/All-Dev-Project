import { NextResponse } from "next/server";
import { listPatientStories } from "@/lib/patient-stories-db";

export async function GET() {
  const stories = await listPatientStories();
  return NextResponse.json({ stories });
}
