import { NextResponse } from "next/server";
import { getPatientStoryBySlug } from "@/lib/patient-stories-db";

export async function GET(_: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const story = await getPatientStoryBySlug(slug);
  if (!story) return NextResponse.json({ error: "Story not found" }, { status: 404 });
  return NextResponse.json({ story });
}
