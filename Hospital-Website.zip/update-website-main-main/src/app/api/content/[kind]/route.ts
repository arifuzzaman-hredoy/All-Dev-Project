import { NextResponse } from "next/server";
import { getContentItems, isContentKind } from "@/lib/content-items-db";

type RouteContext = {
  params: Promise<{ kind: string }>;
};

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: RouteContext) {
  const { kind } = await context.params;

  if (!isContentKind(kind)) {
    return NextResponse.json({ message: "Invalid content kind." }, { status: 404 });
  }

  const items = await getContentItems(kind, true);
  return NextResponse.json({ items });
}
