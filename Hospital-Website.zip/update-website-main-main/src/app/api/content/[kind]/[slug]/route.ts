import { NextResponse } from "next/server";
import { getContentItemBySlug, isContentKind } from "@/lib/content-items-db";

type RouteContext = {
  params: Promise<{ kind: string; slug: string }>;
};

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: RouteContext) {
  const { kind, slug } = await context.params;

  if (!isContentKind(kind)) {
    return NextResponse.json({ message: "Invalid content kind." }, { status: 404 });
  }

  const item = await getContentItemBySlug(kind, slug, true);

  if (!item) {
    return NextResponse.json({ message: "Content item not found." }, { status: 404 });
  }

  return NextResponse.json({ item });
}
