import { NextResponse } from "next/server";

import { createAppointment } from "@/lib/appointments";
import { recordAuditLog } from "@/lib/audit-log";
import { checkPublicMutationRateLimit } from "@/lib/public-rate-limit";
import type { AppointmentSubmissionInput } from "@/types/appointment";

export async function POST(request: Request) {
  const rateLimit = checkPublicMutationRateLimit(request, "appointment-submit");

  if (!rateLimit.ok) {
    return NextResponse.json(
      { message: "Too many appointment requests. Please try again later." },
      {
        status: 429,
        headers: { "Retry-After": String(rateLimit.retryAfterSeconds) },
      },
    );
  }

  try {
    const body = (await request.json()) as AppointmentSubmissionInput;
    const appointment = await createAppointment(body);

    await recordAuditLog({
      action: "PUBLIC_APPOINTMENT_CREATED",
      entity: "Appointment",
      entityId: appointment.id,
      adminId: null,
      request,
      metadata: {
        patientName: appointment.patientName,
        phone: appointment.phone,
        doctorName: appointment.doctorName,
      },
    });

    return NextResponse.json({ appointment }, { status: 201 });
  } catch (caught) {
    const message =
      caught instanceof Error ? caught.message : "Appointment submission failed.";

    return NextResponse.json({ message }, { status: 400 });
  }
}
