import { NextResponse } from "next/server";
import { getActiveDbHealthPackages } from "@/lib/health-packages-db";

export const dynamic = "force-dynamic";

export async function GET() {
  const packages = await getActiveDbHealthPackages();
  return NextResponse.json({ packages });
}
