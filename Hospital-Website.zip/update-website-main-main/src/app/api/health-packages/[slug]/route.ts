import { NextResponse } from "next/server";
import { getDbHealthPackageBySlug } from "@/lib/health-packages-db";

type RouteContext = {
  params: Promise<{ slug: string }>;
};

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const healthPackage = await getDbHealthPackageBySlug(slug);

  if (!healthPackage) {
    return NextResponse.json({ message: "Health package not found." }, { status: 404 });
  }

  return NextResponse.json({ package: healthPackage });
}
