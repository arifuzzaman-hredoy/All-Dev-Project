import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const startedAt = Date.now();

  try {
    await db.$queryRaw`SELECT 1`;

    return NextResponse.json({
      ok: true,
      service: "update-clinic",
      database: "ok",
      uptime: process.uptime(),
      responseMs: Date.now() - startedAt,
    });
  } catch {
    return NextResponse.json(
      {
        ok: false,
        service: "update-clinic",
        database: "error",
        responseMs: Date.now() - startedAt,
      },
      { status: 503 },
    );
  }
}
