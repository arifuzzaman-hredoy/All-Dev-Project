import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { deleteDoctor, updateDoctor } from "@/lib/doctors";
import type { DoctorProfileInput } from "@/types/doctor";

type DoctorRouteContext = {
  params: Promise<{ id: string }>;
};

export async function PUT(request: Request, context: DoctorRouteContext) {
  try {
    await requireAdminSession();

    const { id } = await context.params;
    const body = (await request.json()) as DoctorProfileInput;
    const doctor = await updateDoctor(id, body);

    return NextResponse.json({ doctor });
  } catch (caught) {
    return NextResponse.json(
      {
        message:
          caught instanceof Error ? caught.message : "Doctor update failed.",
      },
      { status: 400 },
    );
  }
}

export async function DELETE(_request: Request, context: DoctorRouteContext) {
  try {
    await requireAdminSession();

    const { id } = await context.params;
    await deleteDoctor(id);

    return NextResponse.json({ ok: true });
  } catch (caught) {
    return NextResponse.json(
      {
        message:
          caught instanceof Error ? caught.message : "Doctor delete failed.",
      },
      { status: 400 },
    );
  }
}
