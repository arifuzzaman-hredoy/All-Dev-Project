import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { createDoctor, getActiveDoctors, getDoctors } from "@/lib/doctors";
import type { DoctorProfileInput } from "@/types/doctor";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const includeAll = url.searchParams.get("all") === "1";

  if (includeAll) {
    await requireAdminSession();
  }

  const doctors = includeAll ? await getDoctors() : await getActiveDoctors();

  return NextResponse.json({ doctors });
}

export async function POST(request: Request) {
  try {
    await requireAdminSession();

    const body = (await request.json()) as DoctorProfileInput;
    const doctor = await createDoctor(body);

    return NextResponse.json({ doctor }, { status: 201 });
  } catch (caught) {
    return NextResponse.json(
      {
        message: caught instanceof Error ? caught.message : "Doctor save failed.",
      },
      { status: 400 },
    );
  }
}
