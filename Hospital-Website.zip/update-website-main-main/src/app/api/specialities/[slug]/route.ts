import { NextResponse } from "next/server";
import { getSpecialityBySlug } from "@/lib/specialities-db";

export async function GET(_: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const speciality = await getSpecialityBySlug(slug);
  if (!speciality) return NextResponse.json({ error: "Speciality not found" }, { status: 404 });
  return NextResponse.json({ speciality });
}
