import { NextResponse } from "next/server";
import { listSpecialities } from "@/lib/specialities-db";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const featuredOnly = url.searchParams.get("featured") === "1";
  const specialities = await listSpecialities({ featuredOnly });
  return NextResponse.json({ specialities });
}
