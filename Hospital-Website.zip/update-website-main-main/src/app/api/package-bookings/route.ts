import { NextResponse } from "next/server";
import { createDbPackageBooking } from "@/lib/health-packages-db";
import { recordAuditLog } from "@/lib/audit-log";
import { checkPublicMutationRateLimit } from "@/lib/public-rate-limit";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const rateLimit = checkPublicMutationRateLimit(request, "package-booking-submit");

  if (!rateLimit.ok) {
    return NextResponse.json(
      { message: "Too many package booking requests. Please try again later." },
      {
        status: 429,
        headers: { "Retry-After": String(rateLimit.retryAfterSeconds) },
      },
    );
  }

  const body = await request.json().catch(() => null);

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid package booking payload." }, { status: 400 });
  }

  const booking = await createDbPackageBooking(body);

  await recordAuditLog({
    action: "PUBLIC_PACKAGE_BOOKING_CREATED",
    entity: "PackageBooking",
    entityId: booking.id,
    adminId: null,
    request,
    metadata: {
      packageName: booking.packageName,
      patientName: booking.patientName,
      phone: booking.phone,
      paymentMethod: booking.paymentMethod,
    },
  });

  return NextResponse.json({ booking }, { status: 201 });
}
