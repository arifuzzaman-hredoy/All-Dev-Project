import { NextResponse } from "next/server";

import { getPublicStaticPageBySlug } from "@/lib/static-pages";

export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ slug: string }>;
};

export async function GET(_request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const page = await getPublicStaticPageBySlug(slug);
  return NextResponse.json({ page });
}
