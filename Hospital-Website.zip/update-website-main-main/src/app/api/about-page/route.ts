import { NextResponse } from "next/server";
import { getAboutPageFromDb } from "@/lib/about-page-db";

export const dynamic = "force-dynamic";

export async function GET() {
  const data = await getAboutPageFromDb();
  return NextResponse.json({ data });
}
