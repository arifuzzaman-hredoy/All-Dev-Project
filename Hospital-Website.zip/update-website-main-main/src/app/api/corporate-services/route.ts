import { NextResponse } from "next/server";
import { getCorporateServicesData } from "@/lib/corporate-services-db";

export async function GET() {
  const data = await getCorporateServicesData();
  return NextResponse.json({ data });
}
