import { FormSubmissionType, type Prisma } from "@prisma/client";
import { NextResponse } from "next/server";

import { createFormSubmission } from "@/lib/form-submissions";
import { sendPublicFormReceivedSms } from "@/lib/sms-workflows";

type PublicFormSubmissionBody = {
  formType?: unknown;
  name?: unknown;
  phone?: unknown;
  email?: unknown;
  subject?: unknown;
  message?: unknown;
  payload?: unknown;
};

const allowedFormTypes = new Set<string>([
  FormSubmissionType.CONTACT,
  FormSubmissionType.CAREER,
  FormSubmissionType.SUPPORT,
  FormSubmissionType.ONLINE_REPORT,
  FormSubmissionType.OTHER,
]);

function cleanText(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function getRequestIp(request: Request) {
  const forwardedFor = request.headers.get("x-forwarded-for");
  if (forwardedFor) return forwardedFor.split(",")[0]?.trim() || "";
  return request.headers.get("x-real-ip") || "";
}

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as
    | PublicFormSubmissionBody
    | null;

  if (!body || typeof body !== "object") {
    return NextResponse.json(
      { message: "Invalid form submission payload." },
      { status: 400 }
    );
  }

  const formType = cleanText(body.formType);
  const name = cleanText(body.name);
  const phone = cleanText(body.phone);
  const email = cleanText(body.email);
  const subject = cleanText(body.subject);
  const message = cleanText(body.message);

  if (!allowedFormTypes.has(formType)) {
    return NextResponse.json(
      { message: "Invalid form type." },
      { status: 400 }
    );
  }

  if (!name || !phone || !message) {
    return NextResponse.json(
      { message: "Name, phone, and message are required." },
      { status: 400 }
    );
  }

  const payload = {
    formType,
    name,
    phone,
    email,
    subject,
    message,
    submittedFrom:
      typeof body.payload === "object" && body.payload !== null
        ? body.payload
        : null,
  } as Prisma.InputJsonValue;

  const submission = await createFormSubmission({
    formType: formType as FormSubmissionType,
    name,
    phone,
    email,
    subject: subject || `${formType.replaceAll("_", " ")} request`,
    message,
    payload,
    ipAddress: getRequestIp(request),
    userAgent: request.headers.get("user-agent") || "",
  });

  await sendPublicFormReceivedSms({
    id: submission.id,
    formType: formType as FormSubmissionType,
    name,
    phone,
    email,
    subject,
    message,
  });

  return NextResponse.json({ submission }, { status: 201 });
}
