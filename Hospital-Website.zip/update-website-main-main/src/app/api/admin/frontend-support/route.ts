import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { getFrontendBackendSupportReport } from "@/lib/frontend-backend-support";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();

  const report = await getFrontendBackendSupportReport();
  return NextResponse.json({ report });
}
