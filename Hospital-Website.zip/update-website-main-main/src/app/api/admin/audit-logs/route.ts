import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { getAuditLogs } from "@/lib/audit-log";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  await requireAdminSession();

  const { searchParams } = new URL(request.url);
  const take = Number(searchParams.get("take") || 100);
  const action = searchParams.get("action") || undefined;
  const entity = searchParams.get("entity") || undefined;
  const adminId = searchParams.get("adminId") || undefined;

  const logs = await getAuditLogs({ take, action, entity, adminId });
  return NextResponse.json({ logs });
}
