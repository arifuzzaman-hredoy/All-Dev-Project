import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  getSiteSettings,
  resetSiteSettings,
  saveSiteSettings,
} from "@/lib/site-settings";
import { DEFAULT_SITE_SETTINGS } from "@/lib/site-settings-types";

export const dynamic = "force-dynamic";

type SiteSettingsPayload = {
  settings?: Record<string, unknown>;
};

export async function GET() {
  await requireAdminSession();
  const settings = await getSiteSettings();
  return NextResponse.json({ settings });
}

export async function PUT(request: Request) {
  await requireAdminSession();
  const body = await request.json().catch(() => null) as SiteSettingsPayload | null;

  if (!body || !body.settings || typeof body.settings !== "object") {
    return NextResponse.json(
      { message: "settings payload is required." },
      { status: 400 },
    );
  }

  const settings = await saveSiteSettings({
    ...DEFAULT_SITE_SETTINGS,
    ...body.settings,
  });
  await recordAuditLog({
    action: "SITE_SETTINGS_UPDATE",
    entity: "SiteSettings",
    entityId: "global",
    metadata: { siteName: settings.siteName ?? null, email: settings.email ?? null },
    request,
  });

  return NextResponse.json({ settings });
}

export async function DELETE(request: Request) {
  await requireAdminSession();
  const settings = await resetSiteSettings();
  await recordAuditLog({
    action: "SITE_SETTINGS_RESET",
    entity: "SiteSettings",
    entityId: "global",
    metadata: { siteName: settings.siteName ?? null },
    request,
  });
  return NextResponse.json({ settings });
}
