import { NextResponse } from "next/server";
import { getCurrentAdminUser } from "@/lib/admin-session";

export async function GET() {
  const admin = await getCurrentAdminUser();

  return NextResponse.json({
    authenticated: Boolean(admin),
    admin,
  });
}
