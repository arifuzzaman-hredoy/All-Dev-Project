import { NextResponse } from "next/server";
import { createAdminSession } from "@/lib/admin-session";
import {
  checkAdminLoginRateLimit,
  getClientIp,
  getLoginRateLimitKey,
  recordAdminLoginAttempt,
} from "@/lib/admin-rate-limit";
import { recordAdminAuthAudit } from "@/lib/audit-log";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as
    | { email?: unknown; password?: unknown }
    | null;
  const email = typeof body?.email === "string" ? body.email : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const rateLimitKey = getLoginRateLimitKey(email, getClientIp(request));
  const limit = checkAdminLoginRateLimit(rateLimitKey);

  if (!limit.ok) {
    return NextResponse.json(
      {
        ok: false,
        message: `Too many login attempts. Try again in ${limit.retryAfterSeconds} seconds.`,
      },
      {
        status: 429,
        headers: { "Retry-After": String(limit.retryAfterSeconds) },
      },
    );
  }

  const result = await createAdminSession(email, password);
  recordAdminLoginAttempt(rateLimitKey, result.ok);
  await recordAdminAuthAudit({
    email,
    ok: result.ok,
    action: result.ok ? "ADMIN_LOGIN_SUCCESS" : "ADMIN_LOGIN_FAILED",
    request,
    reason: result.message,
  });

  return NextResponse.json(result, { status: result.ok ? 200 : 401 });
}
