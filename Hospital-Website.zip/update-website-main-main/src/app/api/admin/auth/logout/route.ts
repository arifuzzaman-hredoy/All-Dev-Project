import { NextResponse } from "next/server";
import { clearAdminSession, getCurrentAdminUser } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";

export async function POST(request: Request) {
  const admin = await getCurrentAdminUser();
  await recordAuditLog({
    adminId: admin?.id ?? null,
    action: "ADMIN_LOGOUT",
    entity: "AdminAuth",
    entityId: admin?.id ?? null,
    metadata: { email: admin?.email ?? null },
    request,
  });
  await clearAdminSession();
  return NextResponse.json({ ok: true });
}

