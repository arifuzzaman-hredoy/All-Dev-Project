import { NextResponse } from "next/server";
import { requestAdminPasswordReset } from "@/lib/admin-password-reset";

export const dynamic = "force-dynamic";

type RequestBody = {
  email?: unknown;
};

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as RequestBody | null;
  const email = typeof body?.email === "string" ? body.email : "";
  const result = await requestAdminPasswordReset(email, request);

  return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}
