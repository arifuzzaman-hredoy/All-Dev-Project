import { NextResponse } from "next/server";
import { completeAdminPasswordReset } from "@/lib/admin-password-reset";

export const dynamic = "force-dynamic";

type RequestBody = {
  email?: unknown;
  resetToken?: unknown;
  password?: unknown;
};

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as RequestBody | null;
  const result = await completeAdminPasswordReset({
    email: typeof body?.email === "string" ? body.email : "",
    resetToken: typeof body?.resetToken === "string" ? body.resetToken : "",
    password: typeof body?.password === "string" ? body.password : "",
    request,
  });

  return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}
