import { NextResponse } from "next/server";
import { verifyAdminPasswordResetCode } from "@/lib/admin-password-reset";

export const dynamic = "force-dynamic";

type RequestBody = {
  email?: unknown;
  code?: unknown;
};

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as RequestBody | null;
  const email = typeof body?.email === "string" ? body.email : "";
  const code = typeof body?.code === "string" ? body.code : "";
  const result = await verifyAdminPasswordResetCode(email, code, request);

  return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}
