import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { getCorporateServicesData, resetCorporateServicesData, saveCorporateServicesData } from "@/lib/corporate-services-db";
import type { CorporateServicesData } from "@/lib/corporateServices";

export async function GET() {
  await requireAdminSession();
  const data = await getCorporateServicesData();
  return NextResponse.json({ data });
}

export async function PUT(request: Request) {
  await requireAdminSession();
  const payload = (await request.json()) as CorporateServicesData;
  const data = await saveCorporateServicesData(payload);
  await recordAuditLog({
    action: "CORPORATE_SERVICES_UPDATE",
    entity: "CorporateServices",
    entityId: "home-corporate-services",
    metadata: { title: data.headingMain ?? null, logos: data.logos?.length ?? 0 },
    request,
  });
  return NextResponse.json({ data });
}

export async function POST(request: Request) {
  await requireAdminSession();
  const payload = await request.json().catch(() => ({}));
  if (payload?.action === "reset") {
    const data = await resetCorporateServicesData();
    await recordAuditLog({
      action: "CORPORATE_SERVICES_RESET",
      entity: "CorporateServices",
      entityId: "home-corporate-services",
      metadata: { title: data.headingMain ?? null },
      request,
    });
    return NextResponse.json({ data });
  }
  const data = await getCorporateServicesData();
  return NextResponse.json({ data });
}
