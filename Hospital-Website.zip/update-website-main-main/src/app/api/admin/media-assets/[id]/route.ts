import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { deleteMediaAsset, updateMediaAsset } from "@/lib/media-assets";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  const payload = await request.json().catch(() => null);

  if (!payload || typeof payload !== "object") {
    return NextResponse.json({ message: "Invalid media payload." }, { status: 400 });
  }

  const asset = await updateMediaAsset(id, payload as { altText?: unknown; folder?: unknown });
  await recordAuditLog({
    action: "MEDIA_UPDATE",
    entity: "MediaAsset",
    entityId: id,
    metadata: { fileName: asset.fileName, url: asset.url, folder: asset.folder },
    request,
  });

  return NextResponse.json({ asset });
}

export async function DELETE(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  const asset = await deleteMediaAsset(id);

  await recordAuditLog({
    action: "MEDIA_DELETE",
    entity: "MediaAsset",
    entityId: id,
    metadata: { fileName: asset.fileName, url: asset.url, folder: asset.folder },
    request,
  });

  return NextResponse.json({ ok: true, asset });
}
