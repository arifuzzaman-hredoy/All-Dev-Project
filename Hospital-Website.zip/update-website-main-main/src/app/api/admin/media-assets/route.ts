import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { getAdminMediaAssets, getMediaAssetCounts } from "@/lib/media-assets";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  await requireAdminSession();

  const url = new URL(request.url);
  const folder = url.searchParams.get("folder") || undefined;
  const q = url.searchParams.get("q") || undefined;
  const take = Number(url.searchParams.get("take") || 120);

  const [assets, counts] = await Promise.all([
    getAdminMediaAssets({ folder, q, take }),
    getMediaAssetCounts(),
  ]);

  return NextResponse.json({ assets, counts });
}
