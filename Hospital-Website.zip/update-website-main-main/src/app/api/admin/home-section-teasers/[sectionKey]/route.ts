import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  isHomeSectionTeaserKey,
  type HomeSectionTeaserConfig,
} from "@/lib/home-section-teaser-types";
import {
  getHomeSectionTeaser,
  resetHomeSectionTeaser,
  saveHomeSectionTeaser,
} from "@/lib/home-section-teasers";

type RouteContext = {
  params: Promise<{ sectionKey: string }>;
};

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: RouteContext) {
  await requireAdminSession();
  const { sectionKey } = await context.params;

  if (!isHomeSectionTeaserKey(sectionKey)) {
    return NextResponse.json({ message: "Invalid section key." }, { status: 404 });
  }

  const section = await getHomeSectionTeaser(sectionKey);
  return NextResponse.json({ section });
}

export async function PUT(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { sectionKey } = await context.params;

  if (!isHomeSectionTeaserKey(sectionKey)) {
    return NextResponse.json({ message: "Invalid section key." }, { status: 404 });
  }

  const payload = (await request.json().catch(() => null)) as Partial<HomeSectionTeaserConfig> | null;

  if (!payload || typeof payload !== "object") {
    return NextResponse.json({ message: "Invalid section payload." }, { status: 400 });
  }

  const section = await saveHomeSectionTeaser(sectionKey, payload);
  await recordAuditLog({
    action: "HOME_TEASER_UPDATE",
    entity: "HomeSectionTeaser",
    entityId: sectionKey,
    metadata: { title: section.title ?? null },
    request,
  });
  return NextResponse.json({ section });
}

export async function POST(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { sectionKey } = await context.params;

  if (!isHomeSectionTeaserKey(sectionKey)) {
    return NextResponse.json({ message: "Invalid section key." }, { status: 404 });
  }

  const payload = await request.json().catch(() => ({}));
  if (payload?.action === "reset") {
    const section = await resetHomeSectionTeaser(sectionKey);
    await recordAuditLog({
      action: "HOME_TEASER_RESET",
      entity: "HomeSectionTeaser",
      entityId: sectionKey,
      metadata: { title: section.title ?? null },
      request,
    });
    return NextResponse.json({ section });
  }

  const section = await getHomeSectionTeaser(sectionKey);
  return NextResponse.json({ section });
}
