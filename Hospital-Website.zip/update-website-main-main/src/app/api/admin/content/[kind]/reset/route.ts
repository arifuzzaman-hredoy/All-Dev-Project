import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { isContentKind, resetContentItems } from "@/lib/content-items-db";

type RouteContext = {
  params: Promise<{ kind: string }>;
};

export const dynamic = "force-dynamic";

export async function POST(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { kind } = await context.params;

  if (!isContentKind(kind)) {
    return NextResponse.json({ message: "Invalid content kind." }, { status: 404 });
  }

  const items = await resetContentItems(kind);
  await recordAuditLog({
    action: "CONTENT_RESET",
    entity: kind,
    metadata: { count: items.length },
    request,
  });
  return NextResponse.json({ items });
}
