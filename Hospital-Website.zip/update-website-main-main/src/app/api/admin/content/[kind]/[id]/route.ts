import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { deleteContentItem, isContentKind, updateContentItem } from "@/lib/content-items-db";

type RouteContext = {
  params: Promise<{ kind: string; id: string }>;
};

export const dynamic = "force-dynamic";

export async function PUT(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { kind, id } = await context.params;

  if (!isContentKind(kind)) {
    return NextResponse.json({ message: "Invalid content kind." }, { status: 404 });
  }

  const body = await request.json().catch(() => null);

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid content payload." }, { status: 400 });
  }

  const item = await updateContentItem(kind, id, body);
  await recordAuditLog({
    action: "CONTENT_UPDATE",
    entity: kind,
    entityId: id,
    metadata: { title: item.title ?? null, slug: item.slug ?? null },
    request,
  });
  return NextResponse.json({ item });
}

export async function DELETE(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { kind, id } = await context.params;

  if (!isContentKind(kind)) {
    return NextResponse.json({ message: "Invalid content kind." }, { status: 404 });
  }

  await deleteContentItem(kind, id);
  await recordAuditLog({
    action: "CONTENT_DELETE",
    entity: kind,
    entityId: id,
    request,
  });
  return NextResponse.json({ ok: true });
}
