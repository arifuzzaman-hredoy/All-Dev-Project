import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { createContentItem, getContentItems, isContentKind } from "@/lib/content-items-db";

type RouteContext = {
  params: Promise<{ kind: string }>;
};

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: RouteContext) {
  await requireAdminSession();
  const { kind } = await context.params;

  if (!isContentKind(kind)) {
    return NextResponse.json({ message: "Invalid content kind." }, { status: 404 });
  }

  const items = await getContentItems(kind, false);
  return NextResponse.json({ items });
}

export async function POST(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { kind } = await context.params;

  if (!isContentKind(kind)) {
    return NextResponse.json({ message: "Invalid content kind." }, { status: 404 });
  }

  const body = await request.json().catch(() => null);

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid content payload." }, { status: 400 });
  }

  const item = await createContentItem(kind, body);
  await recordAuditLog({
    action: "CONTENT_CREATE",
    entity: kind,
    entityId: item.id,
    metadata: { title: item.title ?? null, slug: item.slug ?? null },
    request,
  });
  return NextResponse.json({ item }, { status: 201 });
}
