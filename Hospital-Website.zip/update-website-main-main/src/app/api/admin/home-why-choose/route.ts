import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  getWhyChooseSection,
  saveWhyChooseSection,
  WHY_CHOOSE_SECTION_ID,
} from "@/lib/home-why-choose";
import type { WhyChooseSection } from "@/types/home-why-choose";

export async function GET() {
  await requireAdminSession();
  const section = await getWhyChooseSection();

  return NextResponse.json({ section });
}

export async function PUT(request: Request) {
  try {
    await requireAdminSession();

    const body = (await request.json()) as Partial<WhyChooseSection>;
    const section = await saveWhyChooseSection(body);
    await recordAuditLog({
      action: "HOME_WHY_CHOOSE_UPDATE",
      entity: "WhyChooseSection",
      entityId: WHY_CHOOSE_SECTION_ID,
      metadata: { title: section.title ?? null, specialities: section.specialities?.length ?? 0 },
      request,
    });

    return NextResponse.json({
      message: "Why Choose section updated successfully.",
      section,
    });
  } catch {
    return NextResponse.json(
      { message: "Failed to update section. Please try again." },
      { status: 500 },
    );
  }
}
