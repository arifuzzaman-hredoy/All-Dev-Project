import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { listPatientStories, replacePatientStories } from "@/lib/patient-stories-db";
import type { PatientStory } from "@/lib/patientStories";

export async function GET() {
  await requireAdminSession();
  const stories = await listPatientStories({ admin: true });
  return NextResponse.json({ stories });
}

export async function PUT(request: Request) {
  await requireAdminSession();
  const stories = (await request.json()) as PatientStory[];
  const nextStories = await replacePatientStories(Array.isArray(stories) ? stories : []);
  await recordAuditLog({
    action: "PATIENT_STORIES_REPLACE",
    entity: "PatientStory",
    metadata: { count: nextStories.length },
    request,
  });
  return NextResponse.json({ stories: nextStories });
}
