import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { resetPatientStories } from "@/lib/patient-stories-db";

export async function POST(request: Request) {
  await requireAdminSession();
  const stories = await resetPatientStories();
  await recordAuditLog({
    action: "PATIENT_STORIES_RESET",
    entity: "PatientStory",
    metadata: { count: stories.length },
    request,
  });
  return NextResponse.json({ stories });
}
