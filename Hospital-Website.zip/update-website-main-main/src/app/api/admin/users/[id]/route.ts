import { NextResponse } from "next/server";
import { deactivateAdminUser, updateAdminUser } from "@/lib/admin-users";
import { requireSuperAdminPermission } from "@/lib/admin-permissions";

export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ id: string }>;
};

function permissionResponse(result: { status: 401 | 403; message: string }) {
  return NextResponse.json({ ok: false, message: result.message }, { status: result.status });
}

export async function PATCH(request: Request, context: RouteContext) {
  const permission = await requireSuperAdminPermission();
  if (!permission.ok) return permissionResponse(permission);

  const { id } = await context.params;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const result = await updateAdminUser({
    id,
    name: body.name,
    role: body.role,
    isActive: body.isActive,
    request,
    actorId: permission.admin.id,
  });

  return NextResponse.json(result, { status: result.status });
}

export async function DELETE(request: Request, context: RouteContext) {
  const permission = await requireSuperAdminPermission();
  if (!permission.ok) return permissionResponse(permission);

  const { id } = await context.params;
  const result = await deactivateAdminUser({
    id,
    request,
    actorId: permission.admin.id,
    actorEmail: permission.admin.email,
  });

  return NextResponse.json(result, { status: result.status });
}
