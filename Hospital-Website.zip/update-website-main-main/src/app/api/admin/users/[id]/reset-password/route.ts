import { NextResponse } from "next/server";
import { requireSuperAdminPermission } from "@/lib/admin-permissions";
import { resetAdminUserPassword } from "@/lib/admin-users";

export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ id: string }>;
};

function permissionResponse(result: { status: 401 | 403; message: string }) {
  return NextResponse.json({ ok: false, message: result.message }, { status: result.status });
}

export async function POST(request: Request, context: RouteContext) {
  const permission = await requireSuperAdminPermission();
  if (!permission.ok) return permissionResponse(permission);

  const { id } = await context.params;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const result = await resetAdminUserPassword({
    id,
    password: body.password,
    request,
    actorId: permission.admin.id,
  });

  return NextResponse.json(result, { status: result.status });
}
