import { NextResponse } from "next/server";
import { createAdminUser, listAdminUsers } from "@/lib/admin-users";
import { requireSuperAdminPermission } from "@/lib/admin-permissions";

export const dynamic = "force-dynamic";

function permissionResponse(result: { status: 401 | 403; message: string }) {
  return NextResponse.json({ ok: false, message: result.message }, { status: result.status });
}

export async function GET() {
  const permission = await requireSuperAdminPermission();
  if (!permission.ok) return permissionResponse(permission);

  const admins = await listAdminUsers();
  return NextResponse.json({ ok: true, admins });
}

export async function POST(request: Request) {
  const permission = await requireSuperAdminPermission();
  if (!permission.ok) return permissionResponse(permission);

  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const result = await createAdminUser({
    name: body.name,
    email: body.email,
    role: body.role,
    password: body.password,
    isActive: body.isActive,
    request,
    actorId: permission.admin.id,
  });

  return NextResponse.json(result, { status: result.status });
}
