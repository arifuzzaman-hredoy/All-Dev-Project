import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { getAdminSmsTemplates } from "@/lib/sms-templates";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();

  const templates = await getAdminSmsTemplates();

  return NextResponse.json({ templates });
}
