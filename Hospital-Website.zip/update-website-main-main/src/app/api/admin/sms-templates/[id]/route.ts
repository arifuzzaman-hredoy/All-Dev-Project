import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  getSmsTemplateById,
  updateSmsTemplate,
  type SmsTemplateUpdateInput,
} from "@/lib/sms-templates";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, context: RouteContext) {
  try {
    await requireAdminSession();

    const { id } = await context.params;
    const payload = (await request.json()) as SmsTemplateUpdateInput;

    const before = await getSmsTemplateById(id);
    if (!before) {
      return NextResponse.json(
        { message: "SMS template was not found." },
        { status: 404 },
      );
    }

    const template = await updateSmsTemplate(id, payload);

    await recordAuditLog({
      action: "SMS_TEMPLATE_UPDATE",
      entity: "SmsTemplate",
      entityId: template.id,
      metadata: {
        templateKey: template.templateKey,
        title: template.title,
      },
    });

    return NextResponse.json({ template });
  } catch (caught) {
    return NextResponse.json(
      {
        message:
          caught instanceof Error ? caught.message : "SMS template save failed.",
      },
      { status: 400 },
    );
  }
}