import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { listStaticPages } from "@/lib/static-pages";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();
  const pages = await listStaticPages();
  return NextResponse.json({ pages });
}
