import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  getStaticPage,
  saveStaticPage,
  STATIC_PAGE_KEYS,
  type StaticPageKey,
} from "@/lib/static-pages";

export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ key: string }>;
};

function parseKey(value: string): StaticPageKey | null {
  return (STATIC_PAGE_KEYS as readonly string[]).includes(value)
    ? (value as StaticPageKey)
    : null;
}

export async function GET(_request: Request, context: RouteContext) {
  await requireAdminSession();
  const { key: keyValue } = await context.params;
  const key = parseKey(keyValue);

  if (!key) {
    return NextResponse.json({ message: "Invalid static page key." }, { status: 404 });
  }

  const page = await getStaticPage(key);
  return NextResponse.json({ page });
}

export async function PUT(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { key: keyValue } = await context.params;
  const key = parseKey(keyValue);

  if (!key) {
    return NextResponse.json({ message: "Invalid static page key." }, { status: 404 });
  }

  const body = await request.json().catch(() => null) as { page?: unknown } | null;

  if (!body?.page || typeof body.page !== "object") {
    return NextResponse.json({ message: "page payload is required." }, { status: 400 });
  }

  const page = await saveStaticPage(key, body.page);
  await recordAuditLog({
    action: "STATIC_PAGE_UPDATE",
    entity: "StaticPage",
    entityId: key,
    metadata: { title: page.title ?? null, slug: page.slug ?? null },
    request,
  });
  return NextResponse.json({ page });
}
