import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  resetStaticPage,
  STATIC_PAGE_KEYS,
  type StaticPageKey,
} from "@/lib/static-pages";

export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ key: string }>;
};

function parseKey(value: string): StaticPageKey | null {
  return (STATIC_PAGE_KEYS as readonly string[]).includes(value)
    ? (value as StaticPageKey)
    : null;
}

export async function POST(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { key: keyValue } = await context.params;
  const key = parseKey(keyValue);

  if (!key) {
    return NextResponse.json({ message: "Invalid static page key." }, { status: 404 });
  }

  const page = await resetStaticPage(key);
  await recordAuditLog({
    action: "STATIC_PAGE_RESET",
    entity: "StaticPage",
    entityId: key,
    metadata: { title: page.title ?? null, slug: page.slug ?? null },
    request,
  });
  return NextResponse.json({ page });
}
