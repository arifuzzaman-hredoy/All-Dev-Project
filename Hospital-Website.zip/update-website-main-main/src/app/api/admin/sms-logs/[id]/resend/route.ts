import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { resendSmsLog } from "@/lib/sms-logs";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export const dynamic = "force-dynamic";

export async function POST(_request: Request, context: RouteContext) {
  try {
    await requireAdminSession();

    const { id } = await context.params;
    const log = await resendSmsLog(id);

    await recordAuditLog({
      action: "SMS_LOG_RESEND",
      entity: "SmsLog",
      entityId: log.id,
      metadata: {
        phone: log.phone,
        templateKey: log.templateKey,
        status: log.status,
      },
    });

    return NextResponse.json({ log });
  } catch (caught) {
    return NextResponse.json(
      {
        message:
          caught instanceof Error ? caught.message : "SMS resend failed.",
      },
      { status: 400 },
    );
  }
}