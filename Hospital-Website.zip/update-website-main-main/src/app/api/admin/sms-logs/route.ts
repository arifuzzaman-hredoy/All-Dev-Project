import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { getAdminSmsLogs } from "@/lib/sms-logs";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();

  const logs = await getAdminSmsLogs();

  return NextResponse.json({ logs });
}
