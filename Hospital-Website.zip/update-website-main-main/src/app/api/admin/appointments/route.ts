import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { createManualAppointment } from "@/lib/appointments";
import { recordAuditLog } from "@/lib/audit-log";
import type { ManualAppointmentInput } from "@/types/appointment";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    await requireAdminSession();

    const body = (await request.json()) as ManualAppointmentInput;
    const appointment = await createManualAppointment(body);

    await recordAuditLog({
      action: "APPOINTMENT_MANUAL_CREATE",
      entity: "Appointment",
      entityId: appointment.id,
      metadata: {
        token: appointment.token,
        patientName: appointment.patientName,
        phone: appointment.phone,
        source: appointment.source,
      },
    });

    return NextResponse.json({ appointment }, { status: 201 });
  } catch (caught) {
    return NextResponse.json(
      {
        message:
          caught instanceof Error
            ? caught.message
            : "Manual appointment save failed.",
      },
      { status: 400 },
    );
  }
}
