import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { db } from "@/lib/db";

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireAdminSession();
  const { id } = await params;
  await db.speciality.delete({ where: { id } }).catch(() => null);
  await recordAuditLog({
    action: "SPECIALITY_DELETE",
    entity: "Speciality",
    entityId: id,
    request,
  });
  return NextResponse.json({ ok: true });
}
