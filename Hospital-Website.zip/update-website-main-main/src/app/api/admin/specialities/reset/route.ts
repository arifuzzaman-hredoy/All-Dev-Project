import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { resetSpecialities } from "@/lib/specialities-db";

export async function POST(request: Request) {
  await requireAdminSession();
  const specialities = await resetSpecialities();
  await recordAuditLog({
    action: "SPECIALITIES_RESET",
    entity: "Speciality",
    metadata: { count: specialities.length },
    request,
  });
  return NextResponse.json({ specialities });
}
