import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { listSpecialities, replaceSpecialities } from "@/lib/specialities-db";
import type { SpecialtyItem } from "@/lib/specialties";

export async function GET() {
  await requireAdminSession();
  const specialities = await listSpecialities({ admin: true });
  return NextResponse.json({ specialities });
}

export async function PUT(request: Request) {
  await requireAdminSession();
  const specialities = (await request.json()) as SpecialtyItem[];
  const nextSpecialities = await replaceSpecialities(Array.isArray(specialities) ? specialities : []);
  await recordAuditLog({
    action: "SPECIALITIES_REPLACE",
    entity: "Speciality",
    metadata: { count: nextSpecialities.length },
    request,
  });
  return NextResponse.json({ specialities: nextSpecialities });
}
