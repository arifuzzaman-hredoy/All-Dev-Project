import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { createExportResponse } from "@/lib/admin-exports";

type RouteContext = {
  params: Promise<{ entity: string }>;
};

export const dynamic = "force-dynamic";

export async function GET(request: Request, context: RouteContext) {
  try {
    await requireAdminSession();

    const { entity } = await context.params;

    return createExportResponse(request, entity);
  } catch (caught) {
    return NextResponse.json(
      {
        message:
          caught instanceof Error ? caught.message : "Export failed.",
      },
      { status: 400 },
    );
  }
}