import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { getAdminFormSubmissions } from "@/lib/form-submissions";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();

  const submissions = await getAdminFormSubmissions();
  return NextResponse.json({ submissions });
}
