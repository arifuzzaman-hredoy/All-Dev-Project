import { FormSubmissionStatus } from "@prisma/client";
import { NextResponse } from "next/server";

import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  archiveFormSubmission,
  updateFormSubmissionStatus,
} from "@/lib/form-submissions";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

const allowedStatuses = new Set<string>(Object.values(FormSubmissionStatus));

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, context: RouteContext) {
  const admin = await requireAdminSession();
  const { id } = await context.params;
  const body = (await request.json().catch(() => null)) as {
    status?: unknown;
  } | null;

  if (!body || typeof body.status !== "string" || !allowedStatuses.has(body.status)) {
    return NextResponse.json({ message: "Invalid submission status." }, { status: 400 });
  }

  const submission = await updateFormSubmissionStatus(
    id,
    body.status as FormSubmissionStatus
  );

  await recordAuditLog({
    action: "FORM_SUBMISSION_STATUS_UPDATE",
    entity: "FormSubmission",
    entityId: id,
    adminId: admin.id,
    request,
    metadata: { status: body.status },
  });

  return NextResponse.json({ submission });
}

export async function DELETE(request: Request, context: RouteContext) {
  const admin = await requireAdminSession();
  const { id } = await context.params;

  const submission = await archiveFormSubmission(id);

  await recordAuditLog({
    action: "FORM_SUBMISSION_ARCHIVE",
    entity: "FormSubmission",
    entityId: id,
    adminId: admin.id,
    request,
    metadata: { status: "ARCHIVED" },
  });

  return NextResponse.json({ submission });
}
