import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  getAboutPageFromDb,
  resetAboutPageInDb,
  saveAboutPageToDb,
} from "@/lib/about-page-db";
import { DEFAULT_ABOUT_PAGE, type AboutPageData } from "@/lib/aboutPage";

export const dynamic = "force-dynamic";

type Payload = {
  data?: Partial<AboutPageData>;
};

export async function GET() {
  await requireAdminSession();
  const data = await getAboutPageFromDb();
  return NextResponse.json({ data });
}

export async function PUT(request: Request) {
  await requireAdminSession();
  const body = (await request.json().catch(() => null)) as Payload | null;

  if (!body?.data || typeof body.data !== "object") {
    return NextResponse.json(
      { message: "About page data is required." },
      { status: 400 },
    );
  }

  const data = await saveAboutPageToDb({
    ...DEFAULT_ABOUT_PAGE,
    ...body.data,
  });
  await recordAuditLog({
    action: "ABOUT_PAGE_UPDATE",
    entity: "AboutPage",
    entityId: "about",
    metadata: { title: data.whoTitleMain ?? null },
    request,
  });

  return NextResponse.json({ data });
}

export async function DELETE(request: Request) {
  await requireAdminSession();
  const data = await resetAboutPageInDb();
  await recordAuditLog({
    action: "ABOUT_PAGE_RESET",
    entity: "AboutPage",
    entityId: "about",
    metadata: { title: data.whoTitleMain ?? null },
    request,
  });
  return NextResponse.json({ data });
}
