import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  deleteDbPackageBooking,
  updateDbPackageBookingStatus,
} from "@/lib/health-packages-db";
import type { PaymentStatus } from "@/lib/packageBookings";

type RouteContext = {
  params: Promise<{ id: string }>;
};

const allowedStatuses = new Set<PaymentStatus>([
  "Payment Submitted",
  "Cash Request",
  "Verified",
  "Rejected",
]);

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  const body = (await request.json().catch(() => null)) as { paymentStatus?: unknown } | null;

  if (
    !body ||
    typeof body.paymentStatus !== "string" ||
    !allowedStatuses.has(body.paymentStatus as PaymentStatus)
  ) {
    return NextResponse.json({ message: "Valid paymentStatus is required." }, { status: 400 });
  }

  const booking = await updateDbPackageBookingStatus(
    id,
    body.paymentStatus as PaymentStatus
  );
  await recordAuditLog({
    action: "PACKAGE_BOOKING_STATUS_UPDATE",
    entity: "PackageBooking",
    entityId: id,
    metadata: { paymentStatus: body.paymentStatus },
    request,
  });
  return NextResponse.json({ booking });
}

export async function DELETE(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  await deleteDbPackageBooking(id);
  await recordAuditLog({
    action: "PACKAGE_BOOKING_DELETE",
    entity: "PackageBooking",
    entityId: id,
    request,
  });
  return NextResponse.json({ ok: true });
}
