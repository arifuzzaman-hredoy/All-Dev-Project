import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { getAdminPackageBookings } from "@/lib/health-packages-db";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();
  const bookings = await getAdminPackageBookings();
  return NextResponse.json({ bookings });
}
