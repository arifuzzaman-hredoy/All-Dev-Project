import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { replaceServices } from "@/features/admin/services/service";
import type { ServiceInput } from "@/features/admin/services/schema";

type BulkPayload = {
  services?: unknown[];
};

export const dynamic = "force-dynamic";

export async function PUT(request: Request) {
  await requireAdminSession();
  const body = await request.json().catch(() => null) as BulkPayload | null;

  if (!body || !Array.isArray(body.services)) {
    return NextResponse.json({ message: "services array is required." }, { status: 400 });
  }

  const services = await replaceServices(body.services as ServiceInput[]);
  await recordAuditLog({
    action: "SERVICES_BULK_REPLACE",
    entity: "Service",
    metadata: { count: services.length },
    request,
  });
  return NextResponse.json({ services });
}
