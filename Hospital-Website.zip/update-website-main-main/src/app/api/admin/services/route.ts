import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { createService, getAdminServices } from "@/features/admin/services/service";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();
  const services = await getAdminServices();
  return NextResponse.json({ services });
}

export async function POST(request: Request) {
  await requireAdminSession();
  const body = await request.json().catch(() => null);

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid service payload." }, { status: 400 });
  }

  const service = await createService(body);
  await recordAuditLog({
    action: "SERVICE_CREATE",
    entity: "Service",
    entityId: service.id,
    metadata: { title: service.title ?? null, slug: service.slug ?? null },
    request,
  });
  return NextResponse.json({ service }, { status: 201 });
}
