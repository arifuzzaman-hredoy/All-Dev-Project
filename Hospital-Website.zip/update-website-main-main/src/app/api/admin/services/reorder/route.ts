import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { reorderServices } from "@/features/admin/services/service";

export const dynamic = "force-dynamic";

type ReorderPayload = {
  items?: { id: string; sortOrder: number }[];
};

export async function POST(request: Request) {
  await requireAdminSession();
  const body = await request.json().catch(() => null) as ReorderPayload | null;

  if (!body || !Array.isArray(body.items)) {
    return NextResponse.json({ message: "items array is required." }, { status: 400 });
  }

  await reorderServices(
    body.items.map((item) => ({
      id: String(item.id),
      sortOrder: Number(item.sortOrder) || 0,
    })),
  );
  await recordAuditLog({
    action: "SERVICES_REORDER",
    entity: "Service",
    metadata: { count: body.items.length },
    request,
  });

  return NextResponse.json({ ok: true });
}
