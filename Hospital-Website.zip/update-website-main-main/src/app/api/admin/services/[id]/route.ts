import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  deleteService,
  setServiceActive,
  updateService,
} from "@/features/admin/services/service";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export const dynamic = "force-dynamic";

export async function PUT(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  const body = await request.json().catch(() => null);

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid service payload." }, { status: 400 });
  }

  const service = await updateService(id, body);
  await recordAuditLog({
    action: "SERVICE_UPDATE",
    entity: "Service",
    entityId: id,
    metadata: { title: service.title ?? null, slug: service.slug ?? null },
    request,
  });
  return NextResponse.json({ service });
}

export async function PATCH(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  const body = await request.json().catch(() => null) as { active?: unknown } | null;

  if (!body || typeof body.active !== "boolean") {
    return NextResponse.json({ message: "active boolean is required." }, { status: 400 });
  }

  await setServiceActive(id, body.active);
  await recordAuditLog({
    action: body.active ? "SERVICE_PUBLISH" : "SERVICE_ARCHIVE",
    entity: "Service",
    entityId: id,
    metadata: { active: body.active },
    request,
  });
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  await deleteService(id);
  await recordAuditLog({
    action: "SERVICE_DELETE",
    entity: "Service",
    entityId: id,
    request,
  });
  return NextResponse.json({ ok: true });
}
