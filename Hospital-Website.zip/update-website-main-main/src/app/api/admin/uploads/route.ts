import { randomUUID } from "crypto";
import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { createMediaAsset } from "@/lib/media-assets";
import {
  IMAGE_MAX_FILE_SIZE,
  allowedImageTypes,
  isSafeImageBuffer,
  safeImageBaseName,
} from "@/lib/upload-security";

export async function POST(request: Request) {
  try {
    await requireAdminSession();

    const formData = await request.formData();
    const file = formData.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json(
        { ok: false, message: "Image file is required." },
        { status: 400 },
      );
    }

    if (file.size <= 0 || file.size > IMAGE_MAX_FILE_SIZE) {
      return NextResponse.json(
        { ok: false, message: "Image must be under 5MB." },
        { status: 400 },
      );
    }

    const extension = allowedImageTypes.get(file.type);

    if (!extension) {
      return NextResponse.json(
        { ok: false, message: "Only JPG, PNG, and WEBP images are allowed." },
        { status: 400 },
      );
    }

    const bytes = Buffer.from(await file.arrayBuffer());

    if (!isSafeImageBuffer(bytes, file.type)) {
      return NextResponse.json(
        { ok: false, message: "Invalid or unsafe image file." },
        { status: 400 },
      );
    }

    const directory = path.join(process.cwd(), "public", "uploads", "cms");
    const filename = `${safeImageBaseName(file.name)}-${Date.now()}-${randomUUID()}.${extension}`;

    await fs.mkdir(directory, { recursive: true });
    await fs.writeFile(path.join(directory, filename), bytes);

    const url = `/uploads/cms/${filename}`;
    const asset = await createMediaAsset({
      fileName: filename,
      mimeType: file.type,
      size: file.size,
      url,
      altText: safeImageBaseName(file.name, "cms").replace(/-/g, " "),
      folder: "cms",
    });

    await recordAuditLog({
      action: "MEDIA_UPLOAD",
      entity: "MediaAsset",
      entityId: asset.id,
      metadata: { fileName: file.name, storedName: filename, mimeType: file.type, size: file.size, url },
      request,
    });

    return NextResponse.json({
      ok: true,
      url,
      asset,
    });
  } catch (caught) {
    return NextResponse.json(
      {
        ok: false,
        message: caught instanceof Error ? caught.message : "Upload failed.",
      },
      { status: 500 },
    );
  }
}
