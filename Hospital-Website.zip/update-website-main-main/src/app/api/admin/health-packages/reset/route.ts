import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { resetDbHealthPackagesToDefault } from "@/lib/health-packages-db";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  await requireAdminSession();
  const packages = await resetDbHealthPackagesToDefault();
  await recordAuditLog({
    action: "HEALTH_PACKAGE_RESET",
    entity: "HealthPackage",
    metadata: { count: packages.length },
    request,
  });
  return NextResponse.json({ packages });
}
