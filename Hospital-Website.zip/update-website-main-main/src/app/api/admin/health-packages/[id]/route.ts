import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import {
  deleteDbHealthPackage,
  setDbHealthPackageActive,
  updateDbHealthPackage,
} from "@/lib/health-packages-db";

type RouteContext = {
  params: Promise<{ id: string }>;
};

export const dynamic = "force-dynamic";

export async function PUT(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  const body = await request.json().catch(() => null);

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid health package payload." }, { status: 400 });
  }

  const healthPackage = await updateDbHealthPackage(id, body);
  await recordAuditLog({
    action: "HEALTH_PACKAGE_UPDATE",
    entity: "HealthPackage",
    entityId: id,
    metadata: { title: healthPackage.title ?? healthPackage.name ?? null, slug: healthPackage.slug ?? null },
    request,
  });
  return NextResponse.json({ package: healthPackage });
}

export async function PATCH(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  const body = (await request.json().catch(() => null)) as { active?: unknown } | null;

  if (!body || typeof body.active !== "boolean") {
    return NextResponse.json({ message: "active boolean is required." }, { status: 400 });
  }

  await setDbHealthPackageActive(id, body.active);
  await recordAuditLog({
    action: body.active ? "HEALTH_PACKAGE_PUBLISH" : "HEALTH_PACKAGE_ARCHIVE",
    entity: "HealthPackage",
    entityId: id,
    metadata: { active: body.active },
    request,
  });
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: Request, context: RouteContext) {
  await requireAdminSession();
  const { id } = await context.params;
  await deleteDbHealthPackage(id);
  await recordAuditLog({
    action: "HEALTH_PACKAGE_DELETE",
    entity: "HealthPackage",
    entityId: id,
    request,
  });
  return NextResponse.json({ ok: true });
}
