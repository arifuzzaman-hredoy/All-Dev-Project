import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { recordAuditLog } from "@/lib/audit-log";
import { createDbHealthPackage, getAdminHealthPackages } from "@/lib/health-packages-db";

export const dynamic = "force-dynamic";

export async function GET() {
  await requireAdminSession();
  const packages = await getAdminHealthPackages();
  return NextResponse.json({ packages });
}

export async function POST(request: Request) {
  await requireAdminSession();
  const body = await request.json().catch(() => null);

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Invalid health package payload." }, { status: 400 });
  }

  const healthPackage = await createDbHealthPackage(body);
  await recordAuditLog({
    action: "HEALTH_PACKAGE_CREATE",
    entity: "HealthPackage",
    entityId: healthPackage.id,
    metadata: { title: healthPackage.title ?? healthPackage.name ?? null, slug: healthPackage.slug ?? null },
    request,
  });
  return NextResponse.json({ package: healthPackage }, { status: 201 });
}
