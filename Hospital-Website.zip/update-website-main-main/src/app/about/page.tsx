import AboutPagePublic from "@/components/about/AboutPagePublic";

export default function AboutPage() {
  return <AboutPagePublic />;
}
