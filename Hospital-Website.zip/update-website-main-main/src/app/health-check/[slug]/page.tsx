import HealthPackageDetail from "@/components/health/HealthPackageDetail";

type HealthPackageDynamicPageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export default async function HealthPackageDynamicPage({
  params,
}: HealthPackageDynamicPageProps) {
  const { slug } = await params;

  return <HealthPackageDetail slug={slug} />;
}
