// File: clinic-website/src/app/health-check/heart-check-for-women/page.tsx

import { notFound } from "next/navigation";
import HealthPackageDetail from "@/components/health/HealthPackageDetail";
import { getHealthPackageBySlug } from "@/data/site";

export default function HeartCheckForWomenPage() {
  const healthPackage = getHealthPackageBySlug("heart-check-for-women");

  if (!healthPackage) {
    notFound();
  }

  return <HealthPackageDetail healthPackage={healthPackage} />;
}
