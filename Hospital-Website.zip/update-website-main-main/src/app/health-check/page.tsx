// File: clinic-website/src/app/health-check/page.tsx

import HealthPackageGrid from "@/components/health/HealthPackageGrid";

export default function HealthCheckPage() {
  return <HealthPackageGrid />;
}
