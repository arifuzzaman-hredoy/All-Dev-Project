// File: clinic-website/src/app/health-check/hajj-health-check/page.tsx

import { notFound } from "next/navigation";
import HealthPackageDetail from "@/components/health/HealthPackageDetail";
import { getHealthPackageBySlug } from "@/data/site";

export default function HajjHealthCheckPage() {
  const healthPackage = getHealthPackageBySlug("hajj-health-check");

  if (!healthPackage) {
    notFound();
  }

  return <HealthPackageDetail healthPackage={healthPackage} />;
}
