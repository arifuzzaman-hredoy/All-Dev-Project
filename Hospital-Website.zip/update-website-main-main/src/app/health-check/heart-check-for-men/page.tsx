// File: clinic-website/src/app/health-check/heart-check-for-men/page.tsx

import { notFound } from "next/navigation";
import HealthPackageDetail from "@/components/health/HealthPackageDetail";
import { getHealthPackageBySlug } from "@/data/site";

export default function HeartCheckForMenPage() {
  const healthPackage = getHealthPackageBySlug("heart-check-for-men");

  if (!healthPackage) {
    notFound();
  }

  return <HealthPackageDetail healthPackage={healthPackage} />;
}
