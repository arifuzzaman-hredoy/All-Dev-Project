import { Suspense } from "react";
import HealthPackageBookingForm from "@/components/health/HealthPackageBookingForm";

export default function HealthPackageBookPage() {
  return (
    <Suspense fallback={<div style={{ padding: 40 }}>Loading...</div>}>
      <HealthPackageBookingForm />
    </Suspense>
  );
}
