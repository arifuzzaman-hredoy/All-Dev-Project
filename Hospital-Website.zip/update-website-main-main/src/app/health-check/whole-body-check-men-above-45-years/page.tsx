// File: clinic-website/src/app/health-check/whole-body-check-men-above-45-years/page.tsx

import { notFound } from "next/navigation";
import HealthPackageDetail from "@/components/health/HealthPackageDetail";
import { getHealthPackageBySlug } from "@/data/site";

export default function WholeBodyCheckMenAbove45YearsPage() {
  const healthPackage = getHealthPackageBySlug(
    "whole-body-check-men-above-45-years",
  );

  if (!healthPackage) {
    notFound();
  }

  return <HealthPackageDetail healthPackage={healthPackage} />;
}
