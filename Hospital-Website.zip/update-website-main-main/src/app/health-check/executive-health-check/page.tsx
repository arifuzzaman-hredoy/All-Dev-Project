// File: clinic-website/src/app/health-check/executive-health-check/page.tsx

import { notFound } from "next/navigation";
import HealthPackageDetail from "@/components/health/HealthPackageDetail";
import { getHealthPackageBySlug } from "@/data/site";

export default function ExecutiveHealthCheckPage() {
  const healthPackage = getHealthPackageBySlug("executive-health-check");

  if (!healthPackage) {
    notFound();
  }

  return <HealthPackageDetail healthPackage={healthPackage} />;
}
