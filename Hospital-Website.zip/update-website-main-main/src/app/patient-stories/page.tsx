// File: clinic-website/src/app/patient-stories/page.tsx

import PatientStoriesGrid from "@/components/patient-stories/PatientStoriesGrid";

export default function PatientStoriesPage() {
  return <PatientStoriesGrid />;
}
