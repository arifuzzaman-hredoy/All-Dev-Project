import PatientStoryDetail from "@/components/patient-stories/PatientStoryDetail";

type PatientStoryDynamicPageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export default async function PatientStoryDynamicPage({
  params,
}: PatientStoryDynamicPageProps) {
  const { slug } = await params;

  return <PatientStoryDetail slug={slug} />;
}
