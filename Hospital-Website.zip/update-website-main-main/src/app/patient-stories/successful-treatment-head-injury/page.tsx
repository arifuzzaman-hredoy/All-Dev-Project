// File: clinic-website/src/app/patient-stories/successful-treatment-head-injury/page.tsx

import { notFound } from "next/navigation";
import PatientStoryDetail from "@/components/patient-stories/PatientStoryDetail";
import { getPatientStoryBySlug } from "@/data/site";

export default function SuccessfulTreatmentHeadInjuryPage() {
  const story = getPatientStoryBySlug("successful-treatment-head-injury");

  if (!story) {
    notFound();
  }

  return <PatientStoryDetail story={story} />;
}
