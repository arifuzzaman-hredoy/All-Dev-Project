// File: clinic-website/src/app/patient-stories/successful-knee-surgery/page.tsx

import { notFound } from "next/navigation";
import PatientStoryDetail from "@/components/patient-stories/PatientStoryDetail";
import { getPatientStoryBySlug } from "@/data/site";

export default function SuccessfulKneeSurgeryPage() {
  const story = getPatientStoryBySlug("successful-knee-surgery");

  if (!story) {
    notFound();
  }

  return <PatientStoryDetail story={story} />;
}
