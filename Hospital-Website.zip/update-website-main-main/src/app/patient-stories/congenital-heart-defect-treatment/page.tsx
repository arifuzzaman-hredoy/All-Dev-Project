// File: clinic-website/src/app/patient-stories/congenital-heart-defect-treatment/page.tsx

import { notFound } from "next/navigation";
import PatientStoryDetail from "@/components/patient-stories/PatientStoryDetail";
import { getPatientStoryBySlug } from "@/data/site";

export default function CongenitalHeartDefectTreatmentPage() {
  const story = getPatientStoryBySlug("congenital-heart-defect-treatment");

  if (!story) {
    notFound();
  }

  return <PatientStoryDetail story={story} />;
}
