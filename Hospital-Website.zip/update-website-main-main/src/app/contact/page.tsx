import type { Metadata } from "next";

import { ContactPublicPage } from "@/components/public/CmsPublicPages";
import { getStaticDbPageMetadata } from "@/components/static-pages/StaticDbPage";

export async function generateMetadata(): Promise<Metadata> {
  return getStaticDbPageMetadata("contact");
}

export default function ContactPage() {
  return <ContactPublicPage />;
}
