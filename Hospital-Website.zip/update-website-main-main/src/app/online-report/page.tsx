"use client";

// File: clinic-website/src/app/online-report/page.tsx

import { useState } from "react";
import PublicFormSubmissionForm from "@/components/forms/PublicFormSubmissionForm";
import StaticPage from "@/components/common/StaticPage";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  FileText,
  LockKeyhole,
  Phone,
  RefreshCcw,
  Search,
  ShieldCheck,
  UserRound,
} from "lucide-react";

export default function OnlineReportPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [rememberPassword, setRememberPassword] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);

  return (
    <StaticPage
      title="Online Report"
      description="Access your diagnostic report securely using your UHID or registration number and mobile number."
    >
      <section className="relative overflow-hidden rounded-[34px] bg-[#f7fbff] px-4 py-10 sm:px-6 lg:px-10">
        {/* Premium Minimal Background */}
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[linear-gradient(135deg,#ffffff_0%,#f2f8ff_48%,#f8f3ff_100%)]" />
          <div className="absolute left-[-140px] top-[-120px] h-[320px] w-[320px] rounded-full bg-[#43c7f4]/14 blur-[95px]" />
          <div className="absolute right-[-150px] bottom-[-130px] h-[360px] w-[360px] rounded-full bg-[#8a6bb8]/14 blur-[100px]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(6,47,102,0.055)_1px,transparent_0)] [background-size:28px_28px]" />
        </div>

        <div className="relative z-10 mx-auto grid max-w-5xl items-center gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          {/* Left Content */}
          <div>
            <div className="mb-5 inline-flex items-center gap-3 rounded-full border border-[#dbeafe] bg-white/80 px-4 py-2 shadow-[0_14px_40px_rgba(6,47,102,0.08)] backdrop-blur-md">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#062f66] text-white shadow-[0_10px_25px_rgba(6,47,102,0.18)]">
                <FileText size={16} />
              </span>

              <span className="text-xs font-black uppercase tracking-[0.18em] text-[#8a6bb8]">
                Secure Report Portal
              </span>
            </div>

            <h2 className="max-w-[520px] text-4xl font-black leading-tight tracking-[-0.04em] text-[#062f66] sm:text-5xl">
              View Your{" "}
              <span className="relative inline-block bg-gradient-to-r from-[#8a6bb8] via-[#43c7f4] to-[#062f66] bg-clip-text text-transparent">
                Online Report
                <span className="absolute -bottom-2 left-0 h-[5px] w-full rounded-full bg-gradient-to-r from-[#43c7f4] via-[#8a6bb8]/60 to-transparent" />
              </span>
            </h2>

            <p className="mt-6 max-w-[560px] text-base font-semibold leading-8 text-[#4d6380]">
              Enter your UHID or registration number and mobile number/password
              to access your diagnostic report securely.
            </p>

            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              <div className="group rounded-[22px] border border-[#dbeafe] bg-white/75 p-5 shadow-[0_16px_45px_rgba(6,47,102,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#43c7f4]/12 text-[#43c7f4] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#43c7f4] group-hover:text-white">
                  <ShieldCheck size={23} />
                </span>
                <p className="mt-4 text-sm font-black text-[#062f66]">
                  Secure Access
                </p>
              </div>

              <div className="group rounded-[22px] border border-[#dbeafe] bg-white/75 p-5 shadow-[0_16px_45px_rgba(6,47,102,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8a6bb8]/12 text-[#8a6bb8] transition-all duration-300 group-hover:-translate-y-1 group-hover:rotate-6 group-hover:scale-110 group-hover:bg-[#8a6bb8] group-hover:text-white">
                  <Search size={23} />
                </span>
                <p className="mt-4 text-sm font-black text-[#062f66]">
                  Quick Report Search
                </p>
              </div>
            </div>
          </div>

          {/* Report Login / Reset Card */}
          <div className="relative overflow-hidden rounded-[30px] border border-white/80 bg-white/85 p-6 shadow-[0_26px_80px_rgba(6,47,102,0.12)] backdrop-blur-xl sm:p-8">
            <div className="pointer-events-none absolute right-[-70px] top-[-70px] h-[180px] w-[180px] rounded-full bg-[#43c7f4]/14 blur-[45px]" />
            <div className="pointer-events-none absolute bottom-[-80px] left-[35%] h-[180px] w-[180px] rounded-full bg-[#8a6bb8]/14 blur-[45px]" />

            <div className="relative z-10">
              <div className="mb-7 text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#062f66] text-white shadow-[0_18px_45px_rgba(6,47,102,0.22)]">
                  {forgotMode ? (
                    <RefreshCcw size={28} />
                  ) : (
                    <FileText size={28} />
                  )}
                </div>

                <h3 className="text-2xl font-black tracking-[-0.03em] text-[#062f66]">
                  {forgotMode ? "Reset Report Password" : "Report Login"}
                </h3>

                <p className="mt-2 text-sm font-semibold text-[#5b6b82]">
                  {forgotMode
                    ? "Enter your UHID and mobile number to reset your report password."
                    : "Please enter your report information below."}
                </p>
              </div>

              {!forgotMode ? (
                <form className="space-y-5">
                  <label className="block">
                    <span className="mb-2 block text-sm font-black text-[#062f66]">
                      Enter your UHID / Registration No
                    </span>

                    <div className="group flex items-center gap-3 rounded-2xl border border-[#dbeafe] bg-[#f8fbff] px-4 py-4 shadow-inner transition-all duration-300 focus-within:border-[#43c7f4] focus-within:bg-white focus-within:ring-4 focus-within:ring-[#43c7f4]/15">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#43c7f4]/12 text-[#43c7f4] transition-all duration-300 group-focus-within:-translate-y-0.5 group-focus-within:rotate-6 group-focus-within:scale-110">
                        <UserRound size={20} />
                      </span>

                      <input
                        type="text"
                        placeholder="Enter UHID or Registration No"
                        className="w-full bg-transparent text-sm font-semibold text-[#062f66] outline-none placeholder:text-slate-400"
                      />
                    </div>
                  </label>

                  <label className="block">
                    <span className="mb-2 block text-sm font-black text-[#062f66]">
                      Enter your Mobile Number / Password
                    </span>

                    <div className="group flex items-center gap-3 rounded-2xl border border-[#dbeafe] bg-[#f8fbff] px-4 py-4 shadow-inner transition-all duration-300 focus-within:border-[#8a6bb8] focus-within:bg-white focus-within:ring-4 focus-within:ring-[#8a6bb8]/15">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#8a6bb8]/12 text-[#8a6bb8] transition-all duration-300 group-focus-within:-translate-y-0.5 group-focus-within:rotate-6 group-focus-within:scale-110">
                        <Phone size={20} />
                      </span>

                      <input
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter mobile number or password"
                        className="w-full bg-transparent text-sm font-semibold text-[#062f66] outline-none placeholder:text-slate-400"
                      />

                      <button
                        type="button"
                        onClick={() => setShowPassword((value) => !value)}
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-[#062f66] ring-1 ring-[#dbeafe] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#062f66] hover:text-white"
                        aria-label={
                          showPassword ? "Hide password" : "Show password"
                        }
                      >
                        {showPassword ? (
                          <EyeOff size={19} />
                        ) : (
                          <Eye size={19} />
                        )}
                      </button>
                    </div>
                  </label>

                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <button
                      type="button"
                      onClick={() => setRememberPassword((value) => !value)}
                      className="group inline-flex w-fit items-center gap-2 text-sm font-black text-[#4d6380] transition-colors duration-300 hover:text-[#062f66]"
                    >
                      <span
                        className={`grid h-5 w-5 place-items-center rounded-md border transition-all duration-300 ${
                          rememberPassword
                            ? "border-[#43c7f4] bg-[#43c7f4] text-white"
                            : "border-[#cbd8ea] bg-white text-transparent"
                        }`}
                      >
                        <CheckCircle2 size={14} />
                      </span>
                      Remember password
                    </button>

                    <button
                      type="button"
                      onClick={() => setForgotMode(true)}
                      className="w-fit text-sm font-black text-[#8a6bb8] transition-all duration-300 hover:-translate-y-0.5 hover:text-[#062f66]"
                    >
                      Forgot password?
                    </button>
                  </div>

                  <button
                    type="button"
                    className="group relative mt-2 inline-flex w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-[#062f66] px-8 py-4 text-sm font-black uppercase tracking-[0.08em] text-white shadow-[0_18px_45px_rgba(6,47,102,0.24)] transition-all duration-300 hover:-translate-y-1 hover:bg-[#8a6bb8] hover:shadow-[0_24px_65px_rgba(138,107,184,0.32)]"
                  >
                    <span className="absolute inset-y-0 left-0 w-12 -translate-x-16 rotate-12 bg-white/25 blur-sm transition-transform duration-700 group-hover:translate-x-[520px]" />
                    <LockKeyhole
                      size={18}
                      className="relative z-10 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-6"
                    />
                    <span className="relative z-10">View Report</span>
                    <ArrowRight
                      size={18}
                      className="relative z-10 transition-transform duration-300 group-hover:translate-x-1"
                    />
                  </button>
                </form>
              ) : (
                <form className="space-y-5">
                  <label className="block">
                    <span className="mb-2 block text-sm font-black text-[#062f66]">
                      Enter your UHID / Registration No
                    </span>

                    <div className="group flex items-center gap-3 rounded-2xl border border-[#dbeafe] bg-[#f8fbff] px-4 py-4 shadow-inner transition-all duration-300 focus-within:border-[#43c7f4] focus-within:bg-white focus-within:ring-4 focus-within:ring-[#43c7f4]/15">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#43c7f4]/12 text-[#43c7f4] transition-all duration-300 group-focus-within:-translate-y-0.5 group-focus-within:rotate-6 group-focus-within:scale-110">
                        <UserRound size={20} />
                      </span>

                      <input
                        type="text"
                        placeholder="Enter UHID or Registration No"
                        className="w-full bg-transparent text-sm font-semibold text-[#062f66] outline-none placeholder:text-slate-400"
                      />
                    </div>
                  </label>

                  <label className="block">
                    <span className="mb-2 block text-sm font-black text-[#062f66]">
                      Enter your Mobile Number
                    </span>

                    <div className="group flex items-center gap-3 rounded-2xl border border-[#dbeafe] bg-[#f8fbff] px-4 py-4 shadow-inner transition-all duration-300 focus-within:border-[#8a6bb8] focus-within:bg-white focus-within:ring-4 focus-within:ring-[#8a6bb8]/15">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#8a6bb8]/12 text-[#8a6bb8] transition-all duration-300 group-focus-within:-translate-y-0.5 group-focus-within:rotate-6 group-focus-within:scale-110">
                        <Phone size={20} />
                      </span>

                      <input
                        type="tel"
                        placeholder="Enter mobile number"
                        className="w-full bg-transparent text-sm font-semibold text-[#062f66] outline-none placeholder:text-slate-400"
                      />
                    </div>
                  </label>

                  <button
                    type="button"
                    className="group relative mt-2 inline-flex w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-[#062f66] px-8 py-4 text-sm font-black uppercase tracking-[0.08em] text-white shadow-[0_18px_45px_rgba(6,47,102,0.24)] transition-all duration-300 hover:-translate-y-1 hover:bg-[#8a6bb8] hover:shadow-[0_24px_65px_rgba(138,107,184,0.32)]"
                  >
                    <span className="absolute inset-y-0 left-0 w-12 -translate-x-16 rotate-12 bg-white/25 blur-sm transition-transform duration-700 group-hover:translate-x-[520px]" />
                    <RefreshCcw
                      size={18}
                      className="relative z-10 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:rotate-180"
                    />
                    <span className="relative z-10">Reset Password</span>
                    <ArrowRight
                      size={18}
                      className="relative z-10 transition-transform duration-300 group-hover:translate-x-1"
                    />
                  </button>

                  <button
                    type="button"
                    onClick={() => setForgotMode(false)}
                    className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#eef7ff] px-6 py-3 text-sm font-black text-[#062f66] ring-1 ring-[#dbeafe] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#43c7f4] hover:text-white"
                  >
                    <ArrowLeft
                      size={17}
                      className="transition-transform duration-300 group-hover:-translate-x-1"
                    />
                    Back to Login
                  </button>
                </form>
              )}

              <p className="mt-5 text-center text-xs font-semibold leading-6 text-[#6b7a90]">
                Your report information will be verified securely before access.
              </p>
            </div>
          </div>
        </div>
      </section>
      <PublicFormSubmissionForm
        formType="ONLINE_REPORT"
        title="Need report help?"
        description="Submit your online report issue, UHID/registration support request, or password help request."
        defaultSubject="Online report help request"
        subjectLabel="UHID / Registration No"
        subjectPlaceholder="Enter UHID or registration number if available"
        messageLabel="Report issue details"
        messagePlaceholder="Write your report access problem or password help request"
      />
    </StaticPage>
  );
}
