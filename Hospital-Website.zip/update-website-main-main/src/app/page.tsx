// File: clinic-website/src/app/page.tsx

import HeroSlider from "@/components/home/HeroSlider";
import Hero from "@/components/home/Hero";
import HealthPackageGrid from "@/components/health/HealthPackageGrid";
import PatientStoriesGrid from "@/components/patient-stories/PatientStoriesGrid";
import NewsMediaGrid from "@/components/news-media/NewsMediaGrid";
import DoctorArticlesGrid from "@/components/doctor-articles/DoctorArticlesGrid";
import BlogsGrid from "@/components/blogs/BlogsGrid";
import CorporateServices from "@/components/home/CorporateServices";
import LocationMap from "@/components/contact/LocationMap";
import WhyChoose from "@/components/home/WhyChoose";
import SpecialitiesPreview from "@/components/home/SpecialitiesPreview";
import { getWhyChooseSection } from "@/lib/home-why-choose";
import { readPublicContent } from "@/lib/public-content/storage";
import { connection } from "next/server";

export default async function HomePage() {
  await connection();

  const content = await readPublicContent();
  const whyChooseSection = await getWhyChooseSection();

  return (
    <>
      <HeroSlider content={content.homeHero} />
      <Hero whyChooseSection={whyChooseSection} />
      <SpecialitiesPreview />
      <HealthPackageGrid />
      <PatientStoriesGrid />
      <NewsMediaGrid />
      <DoctorArticlesGrid />
      <BlogsGrid />
      <CorporateServices />
      <LocationMap />
      <WhyChoose />
    </>
  );
}
