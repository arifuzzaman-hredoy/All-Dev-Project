// File: clinic-website/src/app/patient-guide/page.tsx

import StaticPage from "@/components/common/StaticPage";

const guideItems = [
  "Bring national ID, previous prescriptions, and test reports.",
  "Arrive 15 minutes early for outpatient registration.",
  "For admission, contact the care desk for bed and billing guidance.",
  "Keep emergency contact details available during hospital visits.",
];

export default function PatientGuidePage() {
  return (
    <StaticPage
      title="Patient Guide"
      description="Helpful information for appointments, admission, billing, and discharge preparation."
    >
      <div className="grid gap-4">
        {guideItems.map((item, index) => (
          <article key={item} className="rounded-2xl border border-slate-100 p-6 shadow-sm">
            <p className="text-sm font-black text-teal-600">Step {index + 1}</p>
            <h2 className="mt-2 text-xl font-black text-[#0b2f5b]">{item}</h2>
          </article>
        ))}
      </div>
    </StaticPage>
  );
}
