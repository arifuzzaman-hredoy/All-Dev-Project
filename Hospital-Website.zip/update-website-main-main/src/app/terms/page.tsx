import type { Metadata } from "next";

import { LegalPublicPage } from "@/components/public/CmsPublicPages";
import { getStaticDbPageMetadata } from "@/components/static-pages/StaticDbPage";

export async function generateMetadata(): Promise<Metadata> {
  return getStaticDbPageMetadata("terms");
}

export default function TermsPage() {
  return <LegalPublicPage type="terms" />;
}
