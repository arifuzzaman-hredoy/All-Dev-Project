import Container from "@/components/common/Container";
import PageHero from "@/components/common/PageHero";
import AppointmentForm from "@/components/forms/AppointmentForm";
import { siteInfo } from "@/data/site-base";

export default function AppointmentPage() {
  return (
    <>
      <PageHero
        title="Book Appointment"
        description="Select patient problem or doctor, fill patient details, and generate a clean appointment slip instantly."
      />

      <section className="relative overflow-hidden bg-gradient-to-b from-slate-50 via-white to-slate-50 py-12 sm:py-16 lg:py-24">
        <div className="absolute inset-0 -z-10">
          <div className="absolute left-0 top-0 h-72 w-72 rounded-full bg-cyan-100/40 blur-3xl" />
          <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-blue-100/40 blur-3xl" />
        </div>

        <Container>
          <div className="grid gap-8 xl:grid-cols-[1fr_380px]">
            <AppointmentForm />

            <div className="space-y-6">
              <div className="overflow-hidden rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_20px_50px_rgba(15,23,42,0.07)] sm:p-7">
                <div className="inline-flex rounded-full bg-slate-100 px-4 py-2 text-[11px] font-bold uppercase tracking-[0.24em] text-slate-600">
                  Support Center
                </div>

                <h2 className="mt-5 text-3xl font-black tracking-tight text-slate-900">
                  Need Immediate Assistance?
                </h2>

                <p className="mt-4 max-w-md text-sm leading-7 text-slate-600">
                  Our support team can assist with urgent contact details,
                  appointment guidance, and clinic service information.
                </p>

                <div className="mt-7 space-y-4">
                  <div className="flex items-center justify-between gap-4 rounded-[22px] border border-emerald-100 bg-emerald-50/70 p-4 sm:p-5">
                    <div>
                      <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-emerald-700/80">
                        Emergency Hotline
                      </p>

                      <div className="mt-2 flex items-center gap-3">
                        <p className="text-2xl font-black tracking-tight text-slate-900 sm:text-3xl">
                          {siteInfo.emergency}
                        </p>

                        <a
                          href={`tel:${siteInfo.emergency}`}
                          className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-emerald-500 text-white shadow-[0_10px_24px_rgba(16,185,129,0.28)] transition-all duration-300 hover:scale-110 hover:bg-emerald-600 hover:shadow-[0_16px_34px_rgba(16,185,129,0.36)]"
                          aria-label="Call Emergency"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 5.5A2.5 2.5 0 015.5 3h2.15c.6 0 1.13.43 1.23 1.02l.55 3.3a1.25 1.25 0 01-.36 1.1L7.7 9.82a14.5 14.5 0 006.48 6.48l1.4-1.37a1.25 1.25 0 011.1-.36l3.3.55c.59.1 1.02.63 1.02 1.23v2.15A2.5 2.5 0 0118.5 21h-1C9.55 21 3 14.45 3 6.5v-1z"
                            />
                          </svg>
                        </a>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-4 rounded-[22px] border border-cyan-100 bg-cyan-50/70 p-4 sm:p-5">
                    <div>
                      <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-cyan-700/80">
                        General Support
                      </p>

                      <div className="mt-2 flex items-center gap-3">
                        <p className="text-2xl font-black tracking-tight text-slate-900 sm:text-3xl">
                          {siteInfo.phone}
                        </p>

                        <a
                          href={`tel:${siteInfo.phone}`}
                          className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-cyan-500 text-white shadow-[0_10px_24px_rgba(6,182,212,0.28)] transition-all duration-300 hover:scale-110 hover:bg-cyan-600 hover:shadow-[0_16px_34px_rgba(6,182,212,0.36)]"
                          aria-label="Call Support"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 5.5A2.5 2.5 0 015.5 3h2.15c.6 0 1.13.43 1.23 1.02l.55 3.3a1.25 1.25 0 01-.36 1.1L7.7 9.82a14.5 14.5 0 006.48 6.48l1.4-1.37a1.25 1.25 0 011.1-.36l3.3.55c.59.1 1.02.63 1.02 1.23v2.15A2.5 2.5 0 0118.5 21h-1C9.55 21 3 14.45 3 6.5v-1z"
                            />
                          </svg>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-[0_16px_40px_rgba(15,23,42,0.06)]">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 text-amber-600"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13 16h-1v-4h-1m1-4h.01"
                      />
                    </svg>
                  </div>

                  <div>
                    <h3 className="text-base font-black text-slate-900">
                      Service Notice
                    </h3>
                    <p className="mt-1 text-sm text-slate-600">
                      Appointment slips generated here are frontend-only until
                      database booking is connected.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
