import NewsMediaDetail from "@/components/news-media/NewsMediaDetail";

type NewsMediaDynamicPageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export default async function NewsMediaDynamicPage({
  params,
}: NewsMediaDynamicPageProps) {
  const { slug } = await params;
  return <NewsMediaDetail slug={slug} />;
}
