// File: clinic-website/src/app/news-media/page.tsx

import NewsMediaGrid from "@/components/news-media/NewsMediaGrid";

export default function NewsMediaPage() {
  return <NewsMediaGrid />;
}
