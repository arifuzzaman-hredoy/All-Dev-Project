// File: clinic-website/src/app/news-media/specialist-doctor-joined/page.tsx

import { notFound } from "next/navigation";
import NewsMediaDetail from "@/components/news-media/NewsMediaDetail";
import { getNewsMediaBySlug } from "@/data/site";

export default function SpecialistDoctorJoinedPage() {
  const news = getNewsMediaBySlug("specialist-doctor-joined");

  if (!news) {
    notFound();
  }

  return <NewsMediaDetail news={news} />;
}
