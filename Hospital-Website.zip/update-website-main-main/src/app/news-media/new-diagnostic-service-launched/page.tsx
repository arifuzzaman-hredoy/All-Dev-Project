// File: clinic-website/src/app/news-media/new-diagnostic-service-launched/page.tsx

import { notFound } from "next/navigation";
import NewsMediaDetail from "@/components/news-media/NewsMediaDetail";
import { getNewsMediaBySlug } from "@/data/site";

export default function NewDiagnosticServiceLaunchedPage() {
  const news = getNewsMediaBySlug("new-diagnostic-service-launched");

  if (!news) {
    notFound();
  }

  return <NewsMediaDetail news={news} />;
}
