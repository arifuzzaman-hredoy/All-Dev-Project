import type { Metadata } from "next";

import { SupportPublicPage } from "@/components/public/CmsPublicPages";
import { getStaticDbPageMetadata } from "@/components/static-pages/StaticDbPage";

export async function generateMetadata(): Promise<Metadata> {
  return getStaticDbPageMetadata("support");
}

export default function SupportPage() {
  return <SupportPublicPage />;
}
