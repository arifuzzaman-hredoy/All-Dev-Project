import CareerPublicPage from "@/components/career/CareerPublicPage";

export default function CareerPage() {
  return <CareerPublicPage />;
}
