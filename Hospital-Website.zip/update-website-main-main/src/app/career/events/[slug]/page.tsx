import CareerEventDetailPage from "@/components/career/CareerEventDetailPage";

export default function CareerEventPage() {
  return <CareerEventDetailPage />;
}
