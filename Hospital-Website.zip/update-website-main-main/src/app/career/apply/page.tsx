import CareerApplicationForm from "@/components/career/CareerApplicationForm";

type CareerApplyPageProps = {
  searchParams?: Promise<{
    position?: string | string[];
  }>;
};

export default async function CareerApplyPage({
  searchParams,
}: CareerApplyPageProps) {
  const params = await searchParams;
  const position = Array.isArray(params?.position)
    ? params.position[0]
    : params?.position;

  return <CareerApplicationForm position={position} />;
}
