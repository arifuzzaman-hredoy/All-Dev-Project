import type { SectionEditorPreset } from "@/components/admin/SectionEditor";

export const adminSectionPresets: Record<string, SectionEditorPreset> = {
  "home-hero": {
    routeLabel: "Homepage / Hero",
    title: "Homepage hero carousel",
    description:
      "Control the public homepage carousel images, slider behavior, and fixed quick action cards.",
    editor: "homeHero",
    fields: [],
    initialValues: {},
  },
  "home-quick-actions": {
    routeLabel: "Homepage / Quick actions",
    title: "Homepage quick action cards",
    description:
      "Keep the action cards short and practical. These are the utility shortcuts visitors look for first.",
    fields: [
      { key: "title", label: "Title", type: "textarea", rows: 2 },
      { key: "description", label: "Description", type: "textarea", rows: 4 },
      {
        key: "actions",
        label: "Cards",
        type: "list",
        rows: 7,
        helperText: "One card title per line.",
      },
    ],
    initialValues: {
      title: "Fast access to the services people need most.",
      description:
        "Quick actions are the small cards directly below the hero. They should stay short, useful, and easy to scan.",
      actions: [
        "Find a Doctor",
        "Request Appointment",
        "Online Report",
        "Tele Consultation",
        "Patient Guide",
      ],
    },
  },
  "home-why-choose": {
    routeLabel: "Homepage / Why choose us",
    title: "Homepage value proposition",
    description:
      "Use this area to reinforce trust: clear care, organized service, and a patient-first experience.",
    fields: [
      { key: "eyebrow", label: "Eyebrow", type: "text" },
      { key: "title", label: "Title", type: "textarea", rows: 2 },
      { key: "description", label: "Description", type: "textarea", rows: 4 },
      {
        key: "points",
        label: "Bullets",
        type: "list",
        rows: 8,
        helperText: "One point per line.",
      },
    ],
    initialValues: {
      eyebrow: "Why Choose Us",
      title: "Premium healthcare, organized for comfort and confidence.",
      description:
        "Patients and families get clear guidance, thoughtful facilities, and coordinated clinical services in one place.",
      points: [
        "Consultant-led clinical teams",
        "Digital diagnostics and pharmacy support",
        "Transparent patient communication",
        "Comfortable facilities for families",
      ],
    },
  },
  "home-specialities": {
    routeLabel: "Homepage / Specialities",
    title: "Homepage speciality preview",
    description: "Keep the featured speciality list compact and easy to scan.",
    fields: [
      { key: "title", label: "Title", type: "textarea", rows: 2 },
      { key: "description", label: "Description", type: "textarea", rows: 4 },
      {
        key: "specialities",
        label: "Specialities",
        type: "list",
        rows: 8,
        helperText: "One speciality per line.",
      },
    ],
    initialValues: {
      title: "Featured specialities for the homepage",
      description:
        "Use this page to refine the speciality preview cards. Keep names simple and focused on what the public should notice first.",
      specialities: [
        "Cardiology",
        "Neurology",
        "Orthopedics",
        "Pediatrics",
        "Diagnostics",
        "Emergency Care",
      ],
    },
  },
  "home-doctors": {
    routeLabel: "Homepage / Doctors",
    title: "Featured doctors",
    description:
      "Keep the homepage doctor cards concise. The goal is to surface trusted specialists without overcrowding the layout.",
    fields: [
      { key: "title", label: "Title", type: "textarea", rows: 2 },
      { key: "description", label: "Description", type: "textarea", rows: 4 },
      {
        key: "doctors",
        label: "Doctor lines",
        type: "list",
        rows: 8,
        helperText: "Format: Name | role | experience.",
      },
    ],
    initialValues: {
      title: "Meet the doctors highlighted on the homepage.",
      description:
        "Use this page to keep the featured doctors and their specialty blurbs updated.",
      doctors: [
        "Dr. Ayesha Rahman | Consultant Cardiologist | 14 years experience",
        "Dr. Farhan Ahmed | Neurology Specialist | 11 years experience",
        "Dr. Samira Khan | Pediatric Consultant | 10 years experience",
        "Dr. Imran Chowdhury | Orthopedic Surgeon | 16 years experience",
      ],
    },
  },
  "home-news": {
    routeLabel: "Homepage / News",
    title: "Homepage news preview",
    description:
      "Use this section for announcements, operational updates, or awareness campaigns.",
    fields: [
      { key: "title", label: "Title", type: "textarea", rows: 2 },
      { key: "description", label: "Description", type: "textarea", rows: 4 },
      {
        key: "items",
        label: "News items",
        type: "list",
        rows: 8,
        helperText: "One news item per line.",
      },
    ],
    initialValues: {
      title: "Latest announcements and operational updates.",
      description:
        "Use this section for service updates, awareness campaigns, or operational changes that need visibility on the homepage.",
      items: [
        "New preventive cardiac screening package launched",
        "Patient experience desk now available 24/7",
        "Expanded diagnostic schedule for working professionals",
      ],
    },
  },
  "home-blogs": {
    routeLabel: "Homepage / Blogs",
    title: "Homepage blog preview",
    description:
      "These teasers help visitors find practical articles directly from the landing page.",
    fields: [
      { key: "title", label: "Title", type: "textarea", rows: 2 },
      { key: "description", label: "Description", type: "textarea", rows: 4 },
      {
        key: "articles",
        label: "Article titles",
        type: "list",
        rows: 8,
        helperText: "One article title per line.",
      },
    ],
    initialValues: {
      title: "Featured articles from the clinic blog.",
      description:
        "Use this section for short article teasers that keep the homepage useful and educational.",
      articles: [
        "Winter baby health care",
        "Rising measles cases in Bangladesh",
        "Childhood nephrotic syndrome",
      ],
    },
  },
  "home-corporate-services": {
    routeLabel: "Homepage / Corporate services",
    title: "Homepage corporate services",
    description:
      "Keep the service cards short and specific so companies can quickly understand the available support.",
    fields: [
      { key: "title", label: "Title", type: "textarea", rows: 2 },
      { key: "description", label: "Description", type: "textarea", rows: 4 },
      {
        key: "services",
        label: "Services",
        type: "list",
        rows: 7,
        helperText: "One service per line.",
      },
    ],
    initialValues: {
      title: "Corporate health solutions for teams and partners.",
      description:
        "Use this area for workplace packages, screening programs, and B2B support copy.",
      services: [
        "Employee screening",
        "Corporate check-up packages",
        "On-site awareness sessions",
        "Partner support desk",
      ],
    },
  },
  about: {
    routeLabel: "Public pages / About",
    title: "About page content",
    description:
      "Edit the story, section labels, and supporting copy for the About page here.",
    fields: [
      { key: "hero", label: "Hero heading", type: "text" },
      { key: "story", label: "Intro story", type: "textarea", rows: 5 },
      {
        key: "sections",
        label: "Section list",
        type: "list",
        rows: 8,
        helperText: "One section per line.",
      },
    ],
    initialValues: {
      hero: "About Update Diagnostic Center",
      story:
        "Add a concise story about who you are, how the clinic operates, and why patients should trust the care team.",
      sections: [
        "Who we are",
        "Healthcare gallery",
        "Vision, mission, and values",
        "Medical education feature",
      ],
    },
  },
  appointment: {
    routeLabel: "Public pages / Appointment",
    title: "Appointment page content",
    description:
      "Keep the booking page calm and practical. Use it to explain what happens next and where to get urgent help.",
    fields: [
      { key: "title", label: "Hero title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "support",
        label: "Support bullets",
        type: "list",
        rows: 7,
        helperText: "One support note per line.",
      },
    ],
    initialValues: {
      title: "Request Appointment",
      description:
        "Use this page for the booking form intro and emergency guidance. Keep the language calm and direct.",
      support: [
        "Urgent help",
        "Hotline number",
        "Booking instructions",
        "Available consultation windows",
      ],
    },
  },
  contact: {
    routeLabel: "Public pages / Contact",
    title: "Contact page content",
    description:
      "Keep the location and contact copy accurate, short, and easy to scan.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "contacts",
        label: "Contact fields",
        type: "list",
        rows: 6,
        helperText: "One field per line.",
      },
    ],
    initialValues: {
      title: "Contact and location details",
      description:
        "Use this editor for the contact page hero, address copy, map intro, and store locations.",
      contacts: ["Phone", "Emergency", "Email", "Address", "Hours"],
    },
  },
  "health-check": {
    routeLabel: "Public pages / Health check",
    title: "Health check page content",
    description:
      "Group the screening packages clearly so visitors can choose the right health check quickly.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "packages",
        label: "Package list",
        type: "list",
        rows: 8,
        helperText: "One package name per line.",
      },
    ],
    initialValues: {
      title: "Health Check overview",
      description:
        "Use this page to describe the main package categories and how visitors should choose them.",
      packages: [
        "Executive Health Check",
        "Hajj Health Check",
        "Heart Check for Men",
        "Heart Check for Women",
        "Whole Body Check",
      ],
    },
  },
  "online-report": {
    routeLabel: "Public pages / Online report",
    title: "Online report page content",
    description:
      "Explain how people can access reports and who to contact if they need help.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "steps",
        label: "Steps",
        type: "list",
        rows: 7,
        helperText: "One step per line.",
      },
    ],
    initialValues: {
      title: "Online report access",
      description:
        "Use this page to explain the report portal, password rules, and support options.",
      steps: [
        "Enter patient ID",
        "Enter mobile number",
        "Download PDF report",
        "Contact support if needed",
      ],
    },
  },
  "patient-guide": {
    routeLabel: "Public pages / Patient guide",
    title: "Patient guide content",
    description:
      "This page should answer common pre-visit questions about admission, billing, and discharge.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "items",
        label: "Guide items",
        type: "list",
        rows: 8,
        helperText: "One guide item per line.",
      },
    ],
    initialValues: {
      title: "Patient Guide",
      description:
        "Use this page to explain admission, reports, billing, discharge, and support. Keep the tone calm and helpful.",
      items: [
        "Admission process",
        "Billing guidance",
        "Discharge steps",
        "Follow-up instructions",
        "Support desk info",
      ],
    },
  },
  "patient-stories": {
    routeLabel: "Public pages / Patient stories",
    title: "Patient stories content",
    description:
      "Use short story teasers and outcomes that feel reassuring and easy to read.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "stories",
        label: "Stories",
        type: "list",
        rows: 8,
        helperText: "One story per line.",
      },
    ],
    initialValues: {
      title: "Patient success stories",
      description:
        "Use this page to showcase the experience, reassurance, and outcomes that matter to families.",
      stories: [
        "Congenital heart defect treatment",
        "Successful knee surgery",
        "Successful treatment for head injury",
      ],
    },
  },
  "news-media": {
    routeLabel: "Public pages / News & media",
    title: "News and media content",
    description:
      "Keep the updates factual and concise so they can be scanned quickly from the public page.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "items",
        label: "Media items",
        type: "list",
        rows: 8,
        helperText: "One media item per line.",
      },
    ],
    initialValues: {
      title: "News and media updates",
      description:
        "Use this page for service launches, specialist announcements, and awareness programs.",
      items: [
        "Health awareness program",
        "New diagnostic service launched",
        "Specialist doctor joined",
      ],
    },
  },
  "doctor-articles": {
    routeLabel: "Public pages / Doctor articles",
    title: "Doctor article content",
    description:
      "This page should stay educational and practical, with short article teasers that point to useful guidance.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "articles",
        label: "Article titles",
        type: "list",
        rows: 8,
        helperText: "One article title per line.",
      },
    ],
    initialValues: {
      title: "Doctor articles and advice",
      description:
        "Use this page for expert medical articles that stay short enough for a content grid.",
      articles: [
        "Cancer prevention awareness",
        "Diabetic patients during Ramadan fasting",
        "Early detection can save lives",
      ],
    },
  },
  blogs: {
    routeLabel: "Public pages / Blogs",
    title: "Blogs index content",
    description:
      "Keep the blog listing clean and discoverable. These teasers should support the public article cards.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "items",
        label: "Blog items",
        type: "list",
        rows: 8,
        helperText: "One blog title per line.",
      },
    ],
    initialValues: {
      title: "Blogs and awareness posts",
      description:
        "Use this page for the public blog index and the short introductory copy above the grid.",
      items: [
        "Winter baby health care",
        "Rising measles cases in Bangladesh",
        "Childhood nephrotic syndrome",
      ],
    },
  },
  career: {
    routeLabel: "Public pages / Career",
    title: "Career page content",
    description:
      "Keep the recruitment message short, positive, and easy to apply to.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "openings",
        label: "Openings",
        type: "list",
        rows: 7,
        helperText: "One job title per line.",
      },
    ],
    initialValues: {
      title: "Join our team",
      description:
        "Use this page to describe the hiring mindset, culture, and current openings.",
      openings: [
        "Front desk coordinator",
        "Medical officer",
        "Lab technician",
        "Nurse",
      ],
    },
  },
  support: {
    routeLabel: "Public pages / Support",
    title: "Support page content",
    description:
      "Help people find the right contact path quickly and keep the tone reassuring.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "channels",
        label: "Support channels",
        type: "list",
        rows: 7,
        helperText: "One support channel per line.",
      },
    ],
    initialValues: {
      title: "Support center",
      description:
        "Use this page for patient support, hotline guidance, and common contact options.",
      channels: ["Hotline", "Email support", "Front desk", "Emergency help"],
    },
  },
  legal: {
    routeLabel: "Public pages / Legal",
    title: "Legal pages content",
    description:
      "Group the policy pages here so they stay easy to review and update later.",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "description", label: "Description", type: "textarea", rows: 5 },
      {
        key: "pages",
        label: "Pages",
        type: "list",
        rows: 5,
        helperText: "One page name per line.",
      },
    ],
    initialValues: {
      title: "Legal and policy pages",
      description:
        "Keep the privacy policy and terms content in a predictable place so updates stay easy to review.",
      pages: ["Privacy Policy", "Terms and Conditions"],
    },
  },
};

export function getAdminSectionPreset(key: string) {
  return adminSectionPresets[key];
}
