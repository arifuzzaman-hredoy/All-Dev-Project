import { DEFAULT_SITE_SETTINGS, type SiteSettings } from "@/lib/site-settings-types";

export function siteSettingsToSiteInfo(settings: SiteSettings = DEFAULT_SITE_SETTINGS) {
  return {
    name: settings.siteName,
    tagline: settings.tagline,
    description: settings.description,
    phone: settings.phone,
    emergency: settings.emergency,
    whatsapp: settings.whatsapp,
    email: settings.email,
    address: settings.address,
    city: settings.city,
    country: settings.country,
    hours: settings.hours,
    googleMapUrl: settings.googleMapUrl,
    googleMapEmbedUrl: settings.googleMapEmbedUrl,
    facebookUrl: settings.facebookUrl,
    youtubeUrl: settings.youtubeUrl,
    linkedinUrl: settings.linkedinUrl,
    websiteUrl: settings.websiteUrl,
    footerText: settings.footerText,
    copyrightText: settings.copyrightText,
    primaryButtonText: settings.primaryButtonText,
    primaryButtonUrl: settings.primaryButtonUrl,
    secondaryButtonText: settings.secondaryButtonText,
    secondaryButtonUrl: settings.secondaryButtonUrl,
  };
}

export const siteInfo = siteSettingsToSiteInfo();

export const navigation = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Specialities", href: "/specialities" },
  { label: "Health Check", href: "/health-check" },
  { label: "Online Report", href: "/online-report" },
  { label: "Patient Stories", href: "/patient-stories" },
  { label: "Career", href: "/career" },
];
