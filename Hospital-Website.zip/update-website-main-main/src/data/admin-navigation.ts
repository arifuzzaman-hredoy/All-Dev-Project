export {
  adminNavGroups,
  adminSidebarBrand,
  adminSidebarLabels,
  adminSidebarWidths,
} from "@/components/admin/admin-sidebar-customization";
export type {
  AdminNavGroup,
  AdminNavItem,
} from "@/components/admin/admin-sidebar-customization";
