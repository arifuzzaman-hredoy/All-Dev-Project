// File: clinic-website/src/data/site.ts

export const quickActions = [
  {
    title: "Find a Doctor",
    description: "Search experienced consultants by department.",
    href: "/doctors",
    icon: "Stethoscope",
  },
  {
    title: "Request Appointment",
    description: "Book a visit with your preferred specialist.",
    href: "/appointment",
    icon: "CalendarCheck",
  },
  {
    title: "Online Report",
    description: "Access diagnostic reports from anywhere.",
    href: "/online-report",
    icon: "FileText",
  },
  {
    title: "Tele Consultation",
    description: "Speak with a doctor from home.",
    href: "/appointment",
    icon: "Video",
  },
  {
    title: "Patient Guide",
    description: "Prepare for admission, billing, and discharge.",
    href: "/patient-guide",
    icon: "ClipboardList",
  },
];

export const whyChoose = [
  "Consultant-led clinical teams across major specialities",
  "Digital diagnostics, pharmacy, and emergency support under one roof",
  "Transparent patient communication from appointment to discharge",
  "Comfortable facilities designed for families and long-term care",
];

export const specialities = [
  {
    title: "Cardiology",
    description: "Heart care, preventive screening, and cardiac diagnostics.",
    icon: "HeartPulse",
  },
  {
    title: "Neurology",
    description: "Specialized care for brain, spine, and nerve conditions.",
    icon: "Brain",
  },
  {
    title: "Orthopedics",
    description: "Bone, joint, trauma, and sports injury management.",
    icon: "Bone",
  },
  {
    title: "Pediatrics",
    description: "Compassionate care for newborns, children, and teens.",
    icon: "Baby",
  },
  {
    title: "Diagnostics",
    description: "Reliable lab, imaging, and health screening services.",
    icon: "Microscope",
  },
  {
    title: "Emergency Care",
    description: "Round-the-clock urgent care and rapid response support.",
    icon: "Siren",
  },
];

export const doctors = [
  {
    name: "Dr. Ayesha Rahman",
    speciality: "Consultant Cardiologist",
    experience: "14 years experience",
    availability: "Sun, Tue, Thu",
  },
  {
    name: "Dr. Farhan Ahmed",
    speciality: "Neurology Specialist",
    experience: "11 years experience",
    availability: "Mon, Wed, Fri",
  },
  {
    name: "Dr. Samira Khan",
    speciality: "Pediatric Consultant",
    experience: "10 years experience",
    availability: "Sat, Mon, Wed",
  },
  {
    name: "Dr. Imran Chowdhury",
    speciality: "Orthopedic Surgeon",
    experience: "16 years experience",
    availability: "Sun, Tue, Thu",
  },
];

export const news = [
  {
    title: "New preventive cardiac screening package launched",
    date: "May 2026",
    summary:
      "Update Diagnostic Center introduces a practical screening plan for busy families.",
  },
  {
    title: "Patient experience desk now available 24/7",
    date: "April 2026",
    summary:
      "A dedicated team is ready to guide visitors at every stage of care.",
  },
  {
    title: "Expanded diagnostic schedule for working professionals",
    date: "March 2026",
    summary: "Early morning and evening sample collection slots are now open.",
  },
];

export type HealthPackage = {
  slug: string;
  title: string;
  subtitle?: string;
  price: string;
  image: string;
  tests: string[];
};

const commonBodyTests = [
  "CBC",
  "ESR",
  "Blood Grouping",
  "Creatinine-Serum",
  "Urea-Serum",
  "Uric Acid-Serum",
  "Glucose (Fasting)",
  "Glucose (Post Prandial)",
  "Lipid Profile-Serum",
  "Liver Function Test / Profile-Serum",
  "Urine Routine Examination",
  "Chest PA (X-Ray)",
  "ECG",
  "Consultation Fee",
];

export const healthPackages: HealthPackage[] = [
  {
    slug: "hajj-health-check",
    title: "Hajj Health Check",
    price: "8,500 BDT",
    image: "/slider3.jpeg",
    tests: [
      "CBC",
      "Blood Grouping",
      "Creatinine-Serum",
      "Glucose (Random)",
      "ECG",
      "Chest PA (X-Ray)",
      "Urine Routine Examination",
      "Vaccination Fitness Review",
      "Physician Consultation",
      "Medical Certificate Guidance",
    ],
  },
  {
    slug: "executive-health-check",
    title: "Executive Health Check",
    subtitle: "Male / Female",
    price: "18,000 BDT",
    image: "/slider1.jpeg",
    tests: [
      ...commonBodyTests,
      "Thyroid Stimulating Hormone",
      "HbA1c",
      "Ultrasonogram Whole Abdomen",
      "Eye Screening",
      "Dental Screening",
      "Diet Consultation",
    ],
  },
  {
    slug: "heart-check-for-men",
    title: "Heart Check",
    subtitle: "For Men",
    price: "21,000 BDT",
    image: "/slider2.jpeg",
    tests: [
      "Creatinine-Serum",
      "Urea-Serum",
      "Uric Acid-Serum",
      "ECG",
      "Echo Screening",
      "TMT (Tread Mill / Stress Test)",
      "CBC",
      "ESR",
      "ABO & RH Grouping",
      "Spirometry (Basic PFT Test)",
      "Abdomen Whole (Male) Ultrasonogram",
      "Chest PA (X-Ray)",
      "Stool-Routine and Microscopy",
      "Comment on Peripheral Blood Smear",
      "Consultation Fee",
      "Liver Function Test / Profile-Serum",
      "Glucose (Fasting)",
      "Glucose (Post Prandial)",
      "Lipid Profile-Serum",
      "Urine Sugar (Fasting)",
      "Urine Sugar (Post Prandial)",
      "Urine Profile",
    ],
  },
  {
    slug: "heart-check-for-women",
    title: "Heart Check",
    subtitle: "For Women",
    price: "21,500 BDT",
    image: "/pasent.jpeg",
    tests: [
      "Creatinine-Serum",
      "Urea-Serum",
      "ECG",
      "Echo Screening",
      "TMT (Tread Mill / Stress Test)",
      "CBC",
      "ESR",
      "Lipid Profile-Serum",
      "Liver Function Test / Profile-Serum",
      "Glucose (Fasting)",
      "Glucose (Post Prandial)",
      "Chest PA (X-Ray)",
      "Urine Routine Examination",
      "Thyroid Stimulating Hormone",
      "Consultation Fee",
      "Diet Consultation",
    ],
  },
  {
    slug: "whole-body-check-men-above-45-years",
    title: "Whole Body Check",
    subtitle: "For Men Above 45 Years",
    price: "24,000 BDT",
    image: "/update.png",
    tests: [
      ...commonBodyTests,
      "PSA Total",
      "HbA1c",
      "Vitamin D",
      "Ultrasonogram Whole Abdomen",
      "Echo Screening",
      "TMT (Tread Mill / Stress Test)",
      "Physician Consultation",
    ],
  },
  {
    slug: "whole-body-check-men-below-45-years",
    title: "Whole Body Check",
    subtitle: "For Men Below 45 Years",
    price: "17,500 BDT",
    image: "/slider1.jpeg",
    tests: [
      ...commonBodyTests,
      "HbA1c",
      "Vitamin D",
      "Ultrasonogram Whole Abdomen",
      "Physician Consultation",
      "Diet Consultation",
    ],
  },
  {
    slug: "whole-body-check-women-above-45-years",
    title: "Whole Body Check",
    subtitle: "For Women Above 45 Years",
    price: "25,000 BDT",
    image: "/slider2.jpeg",
    tests: [
      ...commonBodyTests,
      "Thyroid Stimulating Hormone",
      "HbA1c",
      "Vitamin D",
      "Ultrasonogram Whole Abdomen",
      "Mammography Screening",
      "Pap Smear",
      "Gynecology Consultation",
    ],
  },
  {
    slug: "whole-body-check-women-below-45-years",
    title: "Whole Body Check",
    subtitle: "For Women Below 45 Years",
    price: "18,500 BDT",
    image: "/pasent.jpeg",
    tests: [
      ...commonBodyTests,
      "Thyroid Stimulating Hormone",
      "HbA1c",
      "Vitamin D",
      "Ultrasonogram Whole Abdomen",
      "Gynecology Consultation",
      "Diet Consultation",
    ],
  },
];

export function getHealthPackageBySlug(slug: string) {
  return healthPackages.find((item) => item.slug === slug);
}

export type PatientStory = {
  slug: string;
  title: string;
  date: string;
  image: string;
  excerpt: string;
  content: string[];
};

export const patientStories: PatientStory[] = [
  {
    slug: "successful-knee-surgery",
    title: "Successful Knee Surgery",
    date: "03 May 2026",
    image: "/slider1.jpeg",
    excerpt:
      "A careful diagnosis, coordinated surgical support, and guided rehabilitation helped the patient return to daily movement with confidence.",
    content: [
      "The patient arrived with long-term knee pain and difficulty walking. After consultation and diagnostic review, the care team prepared a treatment plan focused on comfort, mobility, and recovery confidence.",
      "The surgical team completed the procedure with careful monitoring and clear family communication. Follow-up rehabilitation guidance helped the patient gradually return to routine movement.",
      "This story is prepared as demo content so the clinic team can replace it later with approved real patient testimonials.",
    ],
  },
  {
    slug: "successful-treatment-head-injury",
    title: "Successful Treatment of Head Injury",
    date: "03 May 2026",
    image: "/slider2.jpeg",
    excerpt:
      "Emergency assessment, imaging support, and specialist observation helped the patient receive timely care after a head injury.",
    content: [
      "The patient was brought in after a head injury and received immediate clinical assessment. Diagnostic support helped the medical team understand the risk level and choose the next steps quickly.",
      "Specialists monitored the patient closely, explained the condition to family members, and continued supportive care until the patient became stable.",
      "This page keeps the structure ready for future story publishing with image, date, title, and full article content.",
    ],
  },
  {
    slug: "congenital-heart-defect-treatment",
    title:
      "Successful Treatment of a Child's Congenital Heart Defect by Dr....",
    date: "17 February 2026",
    image: "/pasent.jpeg",
    excerpt:
      "A child received coordinated heart care through careful diagnosis, family counseling, and specialist-led treatment planning.",
    content: [
      "The family visited the hospital for specialist advice after symptoms required further cardiac evaluation. The care team guided them through tests, consultation, and treatment planning.",
      "With specialist support and clear communication, the child received structured care while the family stayed informed at every important step.",
      "Use this demo article as a replaceable template for real patient stories, doctor names, consent-approved images, and complete treatment details.",
    ],
  },
];

export function getPatientStoryBySlug(slug: string) {
  return patientStories.find((item) => item.slug === slug);
}

export type NewsMedia = {
  slug: string;
  title: string;
  date: string;
  image: string;
  excerpt: string;
  content: string[];
};

export const newsMedia: NewsMedia[] = [
  {
    slug: "new-diagnostic-service-launched",
    title: "New Diagnostic Service Launched for Patients",
    date: "May 20, 2026",
    image: "/news/news-1.jpg",
    excerpt:
      "Update Diagnostic Center has introduced a new diagnostic service to support faster patient screening and clearer report guidance.",
    content: [
      "The new diagnostic service is designed to help patients complete essential tests with organized scheduling, guided sample collection, and reliable report handling.",
      "Our team is focused on making the diagnostic journey easier for families, working professionals, and patients who need timely clinical support.",
      "This page is ready for real news content, media updates, press releases, and announcement details.",
    ],
  },
  {
    slug: "health-awareness-program",
    title: "Health Awareness Program Successfully Organized",
    date: "May 12, 2026",
    image: "/news/news-2.jpg",
    excerpt:
      "A health awareness program was organized to encourage preventive screening, healthy habits, and early medical consultation.",
    content: [
      "The program focused on practical wellness guidance, preventive checkups, and the importance of timely diagnosis for common health risks.",
      "Participants received information about health check packages, lifestyle choices, and when to consult specialists for further evaluation.",
      "This article template can be expanded with real event photos, speaker names, and program highlights.",
    ],
  },
  {
    slug: "specialist-doctor-joined",
    title: "New Specialist Doctor Joined Our Medical Team",
    date: "May 05, 2026",
    image: "/news/news-3.jpg",
    excerpt:
      "A new specialist doctor has joined the medical team to strengthen consultation access for patients.",
    content: [
      "The addition of a new specialist supports our goal of making expert consultation more accessible for patients and families.",
      "Patients can request appointments through the website and receive guidance from the care desk for available schedules.",
      "Replace this demo content with the doctor's profile, department, chamber schedule, and official announcement text.",
    ],
  },
];

export function getNewsMediaBySlug(slug: string) {
  return newsMedia.find((item) => item.slug === slug);
}

export type DoctorArticle = {
  slug: string;
  title: string;
  date: string;
  image: string;
  doctor: string;
  excerpt: string;
  content: string[];
};

export const doctorArticles: DoctorArticle[] = [
  {
    slug: "diabetic-patients-ramadan-fasting",
    title: "What Should Diabetic Patients Do During Ramadan Fasting?",
    date: "03 March 2026",
    image: "/doctor-articles/doctor-1.jpg",
    doctor: "Prof. Dr. Ariful Hasan Sarkar",
    excerpt:
      "A practical doctor guideline for diabetic patients who want to fast safely during Ramadan with medical supervision.",
    content: [
      "Diabetic patients should consult their doctor before Ramadan to review medicine timing, diet planning, hydration, and glucose monitoring.",
      "Patients with unstable sugar levels, kidney disease, pregnancy, or repeated hypoglycemia may need a different plan and close follow-up.",
      "This article is demo content and can be replaced with approved doctor advice, department details, and real consultation guidance.",
    ],
  },
  {
    slug: "early-detection-can-save-lives",
    title: "Early Detection Can Save Lives",
    date: "17 February 2026",
    image: "/doctor-articles/doctor-2.jpg",
    doctor: "Dr. Ferdous Shahriar",
    excerpt:
      "Regular screening and early consultation can help detect serious diseases before symptoms become complicated.",
    content: [
      "Many health conditions become easier to treat when detected early. Regular screening helps doctors identify risks and begin care at the right time.",
      "Patients should not ignore persistent symptoms, family history, or recurring discomfort. Consultation and diagnostics can provide clarity.",
      "Use this page to publish doctor-written awareness articles, preventive care notes, and screening campaign content.",
    ],
  },
  {
    slug: "cancer-prevention-awareness",
    title: "Awareness is essential for cancer prevention",
    date: "17 February 2026",
    image: "/doctor-articles/doctor-3.jpg",
    doctor: "Dr. Abdullah Reza Chowdhury",
    excerpt:
      "Lifestyle awareness, screening, and timely specialist consultation can support prevention and early cancer detection.",
    content: [
      "Cancer awareness starts with understanding risk factors, recognizing warning signs, and choosing screening when recommended by specialists.",
      "Healthy habits, tobacco avoidance, vaccination when appropriate, and regular checkups can reduce risk and improve outcomes.",
      "This demo article can later include real doctor interviews, awareness program details, and approved educational content.",
    ],
  },
];

export function getDoctorArticleBySlug(slug: string) {
  return doctorArticles.find((item) => item.slug === slug);
}

export type BlogPost = {
  slug: string;
  title: string;
  date: string;
  image: string;
  excerpt: string;
  content: string[];
};

export const blogPosts: BlogPost[] = [
  {
    slug: "rising-measles-cases-bangladesh",
    title:
      "Rising Measles Cases in Bangladesh: Urgent Measures Needed for Prevention",
    date: "08 April 2026",
    image: "/blogs/blog-1.jpg",
    excerpt:
      "Measles prevention depends on vaccination awareness, early symptom recognition, and timely consultation for children.",
    content: [
      "Measles can spread quickly among children when vaccination coverage is low. Parents should watch for fever, rash, cough, and eye irritation.",
      "Early medical advice helps reduce complications and protects other children through timely isolation and care guidance.",
      "This demo blog can be replaced with approved health education content, campaign details, and prevention guidance.",
    ],
  },
  {
    slug: "childhood-nephrotic-syndrome",
    title: "Childhood Nephrotic Syndrome: Causes, Symptoms, Diagnosis, and...",
    date: "31 January 2026",
    image: "/blogs/blog-2.jpg",
    excerpt:
      "Parents should understand common warning signs such as swelling, urine changes, and repeated fatigue in children.",
    content: [
      "Childhood nephrotic syndrome often appears with swelling around the eyes, legs, or abdomen. Urine changes may also be noticed.",
      "Diagnosis usually includes urine tests, blood tests, and doctor evaluation. Treatment depends on the child's condition and response.",
      "Use this page as a structured article template for pediatric education and specialist-reviewed content.",
    ],
  },
  {
    slug: "winter-baby-health-care",
    title:
      "Winter Baby Health Care: Essential Tips to Keep Your Baby Safe and Healthy i...",
    date: "19 January 2026",
    image: "/blogs/blog-3.jpg",
    excerpt:
      "Winter care for babies includes warmth, hygiene, hydration, feeding support, and watching for breathing difficulty.",
    content: [
      "During winter, babies need comfortable clothing, clean bedding, and protection from cold air without overheating.",
      "Parents should monitor cough, fever, poor feeding, and breathing difficulty. Early consultation is important if symptoms continue.",
      "This demo blog can later be expanded with real pediatric tips, seasonal care campaigns, and family guidance.",
    ],
  },
];

export function getBlogPostBySlug(slug: string) {
  return blogPosts.find((item) => item.slug === slug);
}
