export const ADMIN_SESSION_KEY = "update-diagnostic-admin-session";

export function getAdminBootstrapConfig() {
  return {
    email: process.env.ADMIN_EMAIL || "",
    password: process.env.ADMIN_PASSWORD || "",
    sessionSecret: process.env.ADMIN_SESSION_SECRET || "",
    forceLoginOnRefresh: process.env.ADMIN_FORCE_LOGIN_ON_REFRESH === "true",
  };
}
