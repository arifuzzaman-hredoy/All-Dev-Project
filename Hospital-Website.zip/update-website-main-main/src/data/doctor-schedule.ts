export type DiseaseOption = {
  id: string;
  label: string;
  department: string;
};

export const diseaseOptions: DiseaseOption[] = [
  {
    id: "fever-cold",
    label: "Fever / Cold / Cough",
    department: "General Medicine",
  },
  {
    id: "chest-pain",
    label: "Chest Pain / Heart Problem",
    department: "Cardiology",
  },
  {
    id: "skin",
    label: "Skin / Allergy Problem",
    department: "Dermatology",
  },
  {
    id: "child",
    label: "Child Health Problem",
    department: "Pediatrics",
  },
  {
    id: "bone-joint",
    label: "Bone / Joint Pain",
    department: "Orthopedics",
  },
  {
    id: "pregnancy",
    label: "Pregnancy / Women Health",
    department: "Gynecology",
  },
];
