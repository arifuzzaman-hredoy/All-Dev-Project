export type SiteSettings = {
  siteName: string;
  tagline: string;
  description: string;
  logoUrl: string;
  faviconUrl: string;
  phone: string;
  emergency: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  country: string;
  hours: string;
  googleMapUrl: string;
  googleMapEmbedUrl: string;
  facebookUrl: string;
  youtubeUrl: string;
  linkedinUrl: string;
  websiteUrl: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  primaryButtonText: string;
  primaryButtonUrl: string;
  secondaryButtonText: string;
  secondaryButtonUrl: string;
  footerText: string;
  copyrightText: string;
};

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  siteName: "Update Diagnostic Center",
  tagline: "Advanced care with a human touch",
  description:
    "A modern multi-speciality healthcare destination focused on safe treatment, clear communication, and comfortable patient experiences.",

  logoUrl: "",
  faviconUrl: "",

  phone: "01763-555555",
  emergency: "01971-555555",
  whatsapp: "01763-555555",
  email: "update.diagnostic@gmail.com",

  address: "Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh",
  city: "Rangpur",
  country: "Bangladesh",
  hours: "Open 24/7",
  googleMapUrl: "https://maps.google.com",
  googleMapEmbedUrl: "",

  facebookUrl: "https://facebook.com",
  youtubeUrl: "https://youtube.com",
  linkedinUrl: "https://linkedin.com",
  websiteUrl: "https://example.com",

  seoTitle: "Update Diagnostic Center - Advanced Healthcare",
  seoDescription:
    "Update Diagnostic Center provides modern diagnostic and healthcare services with reliable care, clear communication, and patient-first support.",
  seoKeywords:
    "diagnostic center, hospital, healthcare, Rangpur, doctor, emergency, medical service",

  primaryButtonText: "Book Appointment",
  primaryButtonUrl: "/appointment",
  secondaryButtonText: "Call Emergency",
  secondaryButtonUrl: "tel:01971555555",

  footerText: "Advanced care with a human touch.",
  copyrightText: "© 2026 Update Diagnostic Center. All rights reserved.",
};
