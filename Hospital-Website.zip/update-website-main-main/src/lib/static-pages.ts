import "server-only";

import type { Prisma, PublishStatus } from "@prisma/client";
import { prisma } from "@/lib/db";

export const STATIC_PAGE_KEYS = [
  "about",
  "appointment",
  "contact",
  "support",
  "privacy-policy",
  "terms",
  "patient-guide",
  "online-report",
  "career",
] as const;

export type StaticPageKey = (typeof STATIC_PAGE_KEYS)[number];

export type StaticPageCard = {
  title: string;
  description: string;
};

export type StaticPageContent = {
  id?: string;
  key: StaticPageKey;
  slug: string;
  eyebrow: string;
  title: string;
  description: string;
  heroImage: string;
  body: string[];
  highlights: string[];
  cards: StaticPageCard[];
  primaryButtonLabel: string;
  primaryButtonHref: string;
  secondaryButtonLabel: string;
  secondaryButtonHref: string;
  seoTitle: string;
  seoDescription: string;
  status: PublishStatus;
  sortOrder: number;
  updatedAt?: string;
};

export const STATIC_PAGE_ROUTE_LABELS: Record<StaticPageKey, string> = {
  about: "About",
  appointment: "Appointment",
  contact: "Contact",
  support: "Support",
  "privacy-policy": "Privacy Policy",
  terms: "Terms & Conditions",
  "patient-guide": "Patient Guide",
  "online-report": "Online Report",
  career: "Career",
};

export const DEFAULT_STATIC_PAGES: Record<StaticPageKey, StaticPageContent> = {
  about: {
    key: "about",
    slug: "about",
    eyebrow: "About Update Diagnostic Center",
    title: "Advanced healthcare with a human touch",
    description:
      "Update Diagnostic Center brings diagnostics, specialist consultation, patient support, and modern healthcare guidance into one organized experience.",
    heroImage: "/slider1.jpeg",
    body: [
      "We are building a healthcare experience where patients can understand services clearly, request support quickly, and feel guided from the first visit.",
      "Our team focuses on reliable diagnostic service, specialist access, transparent communication, and a calm environment for families.",
    ],
    highlights: [
      "Modern diagnostic support",
      "Experienced medical team",
      "Patient-first service desk",
      "Organized healthcare journey",
    ],
    cards: [
      {
        title: "Our Mission",
        description:
          "Make reliable healthcare easier to access through clear service guidance, diagnostics, and patient support.",
      },
      {
        title: "Our Vision",
        description:
          "Become a trusted diagnostic and healthcare destination for families and working professionals.",
      },
      {
        title: "Our Values",
        description:
          "Care, clarity, safety, responsibility, and respectful communication with every patient.",
      },
    ],
    primaryButtonLabel: "Book Appointment",
    primaryButtonHref: "/appointment",
    secondaryButtonLabel: "View Services",
    secondaryButtonHref: "/services",
    seoTitle: "About Update Diagnostic Center",
    seoDescription:
      "Learn about Update Diagnostic Center, our healthcare mission, diagnostic services, and patient-first support.",
    status: "PUBLISHED",
    sortOrder: 1,
  },

  appointment: {
    key: "appointment",
    slug: "appointment",
    eyebrow: "Appointment",
    title: "Book Appointment",
    description:
      "Select patient problem or doctor, fill patient details, and generate a clean appointment slip instantly.",
    heroImage: "",
    body: [
      "Our support team can assist with urgent contact details, appointment guidance, and clinic service information.",
      "Appointment slips generated here are frontend-only until database booking is connected.",
    ],
    highlights: [
      "Emergency hotline",
      "General support",
      "Booking instructions",
      "Available consultation windows",
    ],
    cards: [
      { title: "Emergency Hotline", description: "Call the emergency hotline for urgent service guidance." },
      { title: "General Support", description: "Call the support desk for appointment and clinic service information." },
    ],
    primaryButtonLabel: "Book Appointment",
    primaryButtonHref: "/appointment",
    secondaryButtonLabel: "Contact Support",
    secondaryButtonHref: "/contact",
    seoTitle: "Book Appointment - Update Diagnostic Center",
    seoDescription:
      "Request an appointment at Update Diagnostic Center and get support for doctor schedules and clinic services.",
    status: "PUBLISHED",
    sortOrder: 2,
  },
  contact: {
    key: "contact",
    slug: "contact",
    eyebrow: "Contact Us",
    title: "Contact and location details",
    description:
      "Reach the patient desk for appointments, emergency support, diagnostic service guidance, and visitor information.",
    heroImage: "/slider2.jpeg",
    body: [
      "Use the contact page to keep phone numbers, address information, and support notes clear for patients and visitors.",
      "For urgent cases, call the emergency number or visit the nearest emergency desk immediately.",
    ],
    highlights: ["Phone support", "Emergency hotline", "Email guidance", "Location and hours"],
    cards: [
      { title: "Phone", description: "01763-555555" },
      { title: "Emergency", description: "01971-555555" },
      { title: "Email", description: "update.diagnostic@gmail.com" },
      { title: "Address", description: "Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh" },
    ],
    primaryButtonLabel: "Call Now",
    primaryButtonHref: "tel:01763555555",
    secondaryButtonLabel: "Book Appointment",
    secondaryButtonHref: "/appointment",
    seoTitle: "Contact Update Diagnostic Center",
    seoDescription:
      "Contact Update Diagnostic Center for appointments, reports, emergency help, and diagnostic service support.",
    status: "PUBLISHED",
    sortOrder: 3,
  },
  support: {
    key: "support",
    slug: "support",
    eyebrow: "Support Center",
    title: "Get help from our patient support team",
    description:
      "Find the right support channel for appointments, reports, health packages, and patient service information.",
    heroImage: "/slider3.jpeg",
    body: [
      "Our support desk helps patients understand doctor schedules, appointment requests, report access, health packages, and general service information.",
      "Keep this page simple so visitors can quickly choose the right contact path.",
    ],
    highlights: ["Appointment guidance", "Report help", "Package support", "Patient desk information"],
    cards: [
      { title: "Appointment Support", description: "Doctor schedule, booking time, and appointment guidance." },
      { title: "Health Package Guidance", description: "Choose the right diagnostic or health check package." },
      { title: "Online Report Help", description: "Reports, delivery time, and diagnostic service updates." },
      { title: "Patient Desk", description: "Corporate, patient desk, and service information." },
    ],
    primaryButtonLabel: "Contact Support",
    primaryButtonHref: "/contact",
    secondaryButtonLabel: "View Guide",
    secondaryButtonHref: "/patient-guide",
    seoTitle: "Support Center - Update Diagnostic Center",
    seoDescription:
      "Get support for appointments, online reports, health packages, and patient service guidance.",
    status: "PUBLISHED",
    sortOrder: 4,
  },
  "privacy-policy": {
    key: "privacy-policy",
    slug: "privacy-policy",
    eyebrow: "Privacy Policy",
    title: "How we handle patient and visitor information",
    description:
      "This page explains how information may be collected, used, protected, and updated through the website and service channels.",
    heroImage: "",
    body: [
      "We collect information only when it is needed to respond to inquiries, process appointment requests, provide diagnostic support, or improve the service experience.",
      "Personal information should be handled carefully and accessed only by authorized team members for service-related purposes.",
      "This policy text should be reviewed by the organization before production launch.",
    ],
    highlights: ["Information collection", "Service communication", "Data protection", "Policy updates"],
    cards: [
      { title: "Data Use", description: "Information is used to support appointments, reports, inquiries, and patient communication." },
      { title: "Protection", description: "Access should be limited to authorized service and administration team members." },
      { title: "Updates", description: "Policy details can be updated from the admin panel when needed." },
    ],
    primaryButtonLabel: "Contact Us",
    primaryButtonHref: "/contact",
    secondaryButtonLabel: "Terms",
    secondaryButtonHref: "/terms",
    seoTitle: "Privacy Policy - Update Diagnostic Center",
    seoDescription:
      "Read the privacy policy for Update Diagnostic Center website and patient support communication.",
    status: "PUBLISHED",
    sortOrder: 5,
  },
  terms: {
    key: "terms",
    slug: "terms",
    eyebrow: "Terms & Conditions",
    title: "Website and service usage terms",
    description:
      "This page explains general website usage, appointment request limitations, content responsibility, and service communication terms.",
    heroImage: "",
    body: [
      "Website information is provided for general service guidance and should not replace direct consultation with a qualified healthcare professional.",
      "Appointment requests are subject to confirmation, doctor availability, and operational schedules.",
      "Final legal wording should be reviewed by the organization before production launch.",
    ],
    highlights: ["Website usage", "Appointment confirmation", "Service availability", "Content responsibility"],
    cards: [
      { title: "Appointments", description: "Submitting a request does not guarantee confirmation until the team verifies availability." },
      { title: "Medical Guidance", description: "Website content is general information and not a replacement for medical consultation." },
      { title: "Changes", description: "Terms can be updated as services, policies, or operations change." },
    ],
    primaryButtonLabel: "Book Appointment",
    primaryButtonHref: "/appointment",
    secondaryButtonLabel: "Privacy Policy",
    secondaryButtonHref: "/privacy-policy",
    seoTitle: "Terms & Conditions - Update Diagnostic Center",
    seoDescription:
      "Read the terms and conditions for using the Update Diagnostic Center website and online service channels.",
    status: "PUBLISHED",
    sortOrder: 6,
  },
  "patient-guide": {
    key: "patient-guide",
    slug: "patient-guide",
    eyebrow: "Patient Guide",
    title: "Helpful guidance before and after your visit",
    description:
      "Use this page to explain admission, billing, reports, discharge, follow-up, and patient support steps.",
    heroImage: "/pasent.jpeg",
    body: [
      "Patients and families should receive clear information before visiting the center. Keep guidance short, direct, and easy to understand.",
      "Update this page with real admission steps, document requirements, billing guidance, and support desk notes.",
    ],
    highlights: ["Admission process", "Billing guidance", "Report collection", "Follow-up instructions"],
    cards: [
      { title: "Before Visit", description: "Bring required documents, previous reports, and appointment confirmation if available." },
      { title: "During Visit", description: "Follow desk guidance for registration, payment, diagnostics, and consultation flow." },
      { title: "After Visit", description: "Collect reports, review doctor advice, and plan follow-up if recommended." },
    ],
    primaryButtonLabel: "Request Appointment",
    primaryButtonHref: "/appointment",
    secondaryButtonLabel: "Contact Support",
    secondaryButtonHref: "/support",
    seoTitle: "Patient Guide - Update Diagnostic Center",
    seoDescription:
      "Patient guide for admission, billing, reports, follow-up, and support at Update Diagnostic Center.",
    status: "PUBLISHED",
    sortOrder: 7,
  },
  "online-report": {
    key: "online-report",
    slug: "online-report",
    eyebrow: "Online Report",
    title: "Access your diagnostic report online",
    description:
      "Guide patients on report access, registration number usage, password help, and support communication.",
    heroImage: "/slider1.jpeg",
    body: [
      "Patients can use the report portal instructions to find their diagnostic reports when the online report system is connected.",
      "Use this page to explain patient ID, mobile number, password reset, and report support steps.",
    ],
    highlights: ["Enter patient ID", "Use mobile number", "Download report", "Contact support"],
    cards: [
      { title: "Step 1", description: "Enter UHID or registration number." },
      { title: "Step 2", description: "Enter mobile number or report password." },
      { title: "Step 3", description: "View or download the report when available." },
    ],
    primaryButtonLabel: "Contact Report Desk",
    primaryButtonHref: "/contact",
    secondaryButtonLabel: "Patient Guide",
    secondaryButtonHref: "/patient-guide",
    seoTitle: "Online Report - Update Diagnostic Center",
    seoDescription:
      "Access online diagnostic reports and report support guidance from Update Diagnostic Center.",
    status: "PUBLISHED",
    sortOrder: 8,
  },
  career: {
    key: "career",
    slug: "career",
    eyebrow: "Career",
    title: "Want to join our team?",
    description:
      "At Update Diagnostic Center, your career is a journey that touches lives and transforms futures. We believe in the strength of diversity and the power of inclusion to drive exceptional care. Every team member, from every background, is valued for their unique contribution.",
    heroImage: "/career/career-hero.jpg",
    body: [
      "I am pleased to welcome you to our career page.",
      "We believe that our greatest asset is our people. Our healthcare professionals are committed to providing exceptional care to patients and their families, and we are always looking for passionate individuals to join this mission.",
      "Here, you will find opportunities across clinical, nursing, operations, hospitality, finance, HR, supply chain, allied health, and support services. Each role plays a vital part in helping us deliver the highest quality care to our community.",
      "We value diversity, innovation, and collaboration, and we are looking for individuals who share our passion for transforming healthcare and making a difference in the lives of patients.",
    ],
    highlights: ["Join us in transforming healthcare in Bangladesh", "Diverse Team", "Care Mission", "Growth Culture"],
    cards: [
      { title: "Resident Medical Officer", description: "Medical | Dhaka | Full Time | Multiple | N/A" },
      { title: "Staff Nurse", description: "Nursing | Dhaka | Full Time | Multiple | N/A" },
      { title: "Customer Care Officer", description: "Non Medical | Dhaka | Full Time | Multiple | 31 July 2026" },
      { title: "Patient Support Assistant", description: "Non Medical | Dhaka | Full Time | Multiple | N/A" },
      { title: "Infection Control Nurse", description: "Nursing | Dhaka | Full Time | Multiple | N/A" },
    ],
    primaryButtonLabel: "Submit Your Resume",
    primaryButtonHref: "mailto:update.diagnostic@gmail.com",
    secondaryButtonLabel: "Contact HR",
    secondaryButtonHref: "/contact",
    seoTitle: "Career - Update Diagnostic Center",
    seoDescription:
      "Explore career opportunities, openings, and HR contact guidance at Update Diagnostic Center.",
    status: "PUBLISHED",
    sortOrder: 9,
  },
};

function isStaticPageKey(value: string): value is StaticPageKey {
  return (STATIC_PAGE_KEYS as readonly string[]).includes(value);
}

function toStringArray(value: unknown, fallback: string[] = []) {
  if (!Array.isArray(value)) return fallback;
  return value.map((item) => String(item).trim()).filter(Boolean);
}

function toCards(value: unknown, fallback: StaticPageCard[] = []) {
  if (!Array.isArray(value)) return fallback;
  return value
    .map((item) => {
      if (typeof item === "object" && item !== null) {
        const record = item as Record<string, unknown>;
        return {
          title: String(record.title || "").trim(),
          description: String(record.description || "").trim(),
        };
      }
      return null;
    })
    .filter((item): item is StaticPageCard => Boolean(item?.title));
}

function normalizeStatus(value: unknown): PublishStatus {
  return value === "DRAFT" || value === "ARCHIVED" || value === "PUBLISHED"
    ? value
    : "PUBLISHED";
}

export function normalizeStaticPage(
  value: unknown,
  fallbackKey: StaticPageKey,
): StaticPageContent {
  const fallback = DEFAULT_STATIC_PAGES[fallbackKey];
  const row = (typeof value === "object" && value !== null
    ? (value as Record<string, unknown>)
    : {}) as Record<string, unknown>;

  const key = isStaticPageKey(String(row.key || fallback.key))
    ? (String(row.key || fallback.key) as StaticPageKey)
    : fallback.key;

  return {
    id: typeof row.id === "string" ? row.id : undefined,
    key,
    slug: String(row.slug || fallback.slug),
    eyebrow: String(row.eyebrow ?? fallback.eyebrow),
    title: String(row.title || fallback.title),
    description: String(row.description ?? fallback.description),
    heroImage: String(row.heroImage ?? fallback.heroImage),
    body: toStringArray(row.body, fallback.body),
    highlights: toStringArray(row.highlights, fallback.highlights),
    cards: toCards(row.cards, fallback.cards),
    primaryButtonLabel: String(
      row.primaryButtonLabel ?? fallback.primaryButtonLabel,
    ),
    primaryButtonHref: String(row.primaryButtonHref ?? fallback.primaryButtonHref),
    secondaryButtonLabel: String(
      row.secondaryButtonLabel ?? fallback.secondaryButtonLabel,
    ),
    secondaryButtonHref: String(
      row.secondaryButtonHref ?? fallback.secondaryButtonHref,
    ),
    seoTitle: String(row.seoTitle ?? fallback.seoTitle),
    seoDescription: String(row.seoDescription ?? fallback.seoDescription),
    status: normalizeStatus(row.status),
    sortOrder: Number(row.sortOrder ?? fallback.sortOrder) || fallback.sortOrder,
    updatedAt:
      row.updatedAt instanceof Date
        ? row.updatedAt.toISOString()
        : typeof row.updatedAt === "string"
          ? row.updatedAt
          : undefined,
  };
}

function toDbData(page: StaticPageContent) {
  return {
    key: page.key,
    slug: page.slug,
    eyebrow: page.eyebrow,
    title: page.title,
    description: page.description,
    heroImage: page.heroImage,
    body: page.body as Prisma.InputJsonValue,
    highlights: page.highlights as Prisma.InputJsonValue,
    cards: page.cards as Prisma.InputJsonValue,
    primaryButtonLabel: page.primaryButtonLabel,
    primaryButtonHref: page.primaryButtonHref,
    secondaryButtonLabel: page.secondaryButtonLabel,
    secondaryButtonHref: page.secondaryButtonHref,
    seoTitle: page.seoTitle,
    seoDescription: page.seoDescription,
    status: page.status,
    sortOrder: page.sortOrder,
    publishedAt: page.status === "PUBLISHED" ? new Date() : null,
  };
}

export async function getStaticPage(key: StaticPageKey) {
  const row = await prisma.staticPage.findUnique({ where: { key } });
  if (!row) return DEFAULT_STATIC_PAGES[key];
  return normalizeStaticPage(row, key);
}

export async function getPublicStaticPageBySlug(slug: string) {
  const row = await prisma.staticPage.findUnique({ where: { slug } });
  if (!row || row.status !== "PUBLISHED") {
    const fallbackKey = isStaticPageKey(slug) ? slug : "about";
    return DEFAULT_STATIC_PAGES[fallbackKey];
  }
  return normalizeStaticPage(row, row.key as StaticPageKey);
}

export async function listStaticPages() {
  const rows = await prisma.staticPage.findMany({ orderBy: { sortOrder: "asc" } });
  const existing = new Map(rows.map((row) => [row.key, row]));

  return STATIC_PAGE_KEYS.map((key) => {
    const row = existing.get(key);
    return row ? normalizeStaticPage(row, key) : DEFAULT_STATIC_PAGES[key];
  });
}

export async function saveStaticPage(key: StaticPageKey, payload: unknown) {
  const normalized = normalizeStaticPage({ ...(payload as object), key }, key);
  const data = toDbData(normalized);

  const saved = await prisma.staticPage.upsert({
    where: { key },
    update: data,
    create: data,
  });

  return normalizeStaticPage(saved, key);
}

export async function resetStaticPage(key: StaticPageKey) {
  const data = toDbData(DEFAULT_STATIC_PAGES[key]);
  const saved = await prisma.staticPage.upsert({
    where: { key },
    update: data,
    create: data,
  });

  return normalizeStaticPage(saved, key);
}

export async function seedStaticPagesIfMissing() {
  for (const key of STATIC_PAGE_KEYS) {
    const page = DEFAULT_STATIC_PAGES[key];
    const data = toDbData(page);
    await prisma.staticPage.upsert({
      where: { key },
      update: {},
      create: data,
    });
  }
}
