export type CorporateFeatureItem = {
  id: string;
  icon: string;
  label: string;
  value: string;
  active: boolean;
  sortOrder: number;
};

export type CorporateLogoItem = {
  id: string;
  name: string;
  image: string;
  active: boolean;
  sortOrder: number;
};

export type CorporateServicesData = {
  badgeText: string;
  headingMain: string;
  headingAccent: string;
  subtitle: string;
  mainLabel: string;
  mainText: string;
  features: CorporateFeatureItem[];
  logos: CorporateLogoItem[];
  updatedAt: string;
};

export const CORPORATE_SERVICES_STORAGE_KEY =
  "update-diagnostic-center-corporate-services";

export const DEFAULT_CORPORATE_LOGO = "/corporate/bgcci.png";

export const DEFAULT_CORPORATE_SERVICES: CorporateServicesData = {
  badgeText: "Corporate Care",
  headingMain: "Corporate",
  headingAccent: "Services",
  subtitle:
    "Dedicated corporate healthcare support, referral assistance, and streamlined service experience.",
  mainLabel: "One-Stop Service Desk:",
  mainText:
    "For the convenience of corporate clients, Update Diagnostic Center operates a dedicated One-Stop Service Desk in the hospital atrium. This service desk ensures prompt assistance and streamlined experiences for referral patients, international patients and corporate patients.",
  features: [
    {
      id: "support",
      icon: "Headphones",
      label: "Support",
      value: "Prompt Assistance",
      active: true,
      sortOrder: 1,
    },
    {
      id: "hours",
      icon: "Clock3",
      label: "Hours",
      value: "9:00 AM - 5:00 PM",
      active: true,
      sortOrder: 2,
    },
    {
      id: "service",
      icon: "ShieldCheck",
      label: "Service",
      value: "Streamlined Care",
      active: true,
      sortOrder: 3,
    },
  ],
  logos: [
    { id: "bgcci", name: "BGCCI", image: "/corporate/bgcci.png", active: true, sortOrder: 1 },
    { id: "bgapmea", name: "BGAPMEA", image: "/corporate/bgapmea.png", active: true, sortOrder: 2 },
    { id: "akj", name: "AKJ Group", image: "/corporate/akj-group.png", active: true, sortOrder: 3 },
    { id: "bcb", name: "Bangladesh Cricket Board", image: "/corporate/bcb.png", active: true, sortOrder: 4 },
    { id: "bff", name: "Bangladesh Football Federation", image: "/corporate/bff.png", active: true, sortOrder: 5 },
  ],
  updatedAt: "2026-06-12T00:00:00.000Z",
};

export function getCorporateServicesFromStorage(): CorporateServicesData {
  return DEFAULT_CORPORATE_SERVICES;
}

export function saveCorporateServicesToStorage(_data: CorporateServicesData) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event("corporate-services-updated"));
}

export function makeCorporateId(prefix: string) {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `${prefix}-${crypto.randomUUID()}`;
  }
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}
