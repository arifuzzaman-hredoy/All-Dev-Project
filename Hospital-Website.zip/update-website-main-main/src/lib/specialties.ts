export type SpecialtyDoctor = {
  id: string;
  name: string;
  title: string;
  schedule: string;
  time: string;
  room: string;
  fee: string;
  image: string;
  active: boolean;
  sortOrder: number;
};

export type SpecialtyItem = {
  id: string;
  slug: string;
  title: string;
  icon: string;
  shortDescription: string;
  image: string;
  detailTitle: string;
  detailDescription: string;
  services: string[];
  doctors: SpecialtyDoctor[];
  active: boolean;
  featured: boolean;
  showInMenu: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export const SPECIALTIES_STORAGE_KEY =
  "update-diagnostic-center-specialties-cms";

export const DEFAULT_SPECIALTY_IMAGE =
  "data:image/svg+xml;charset=UTF-8," +
  encodeURIComponent(`
  <svg width="900" height="520" viewBox="0 0 900 520" xmlns="http://www.w3.org/2000/svg">
    <rect width="900" height="520" fill="#003173"/>
    <text x="50%" y="48%" dominant-baseline="middle" text-anchor="middle" fill="white" font-size="52" font-family="Arial" font-weight="900">UPDATE</text>
    <text x="50%" y="60%" dominant-baseline="middle" text-anchor="middle" fill="#35bbea" font-size="30" font-family="Arial" font-weight="700">DIAGNOSTIC CENTER</text>
  </svg>
`);

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function makeDoctor(
  name: string,
  title: string,
  sortOrder: number,
): SpecialtyDoctor {
  return {
    id: `doctor-${sortOrder}-${slugify(name)}`,
    name,
    title,
    schedule: "Saturday, Monday, Wednesday",
    time: "10:00 AM - 2:00 PM",
    room: "Room 201",
    fee: "700 BDT",
    image: "",
    active: true,
    sortOrder,
  };
}

function makeSpecialty(
  title: string,
  icon: string,
  shortDescription: string,
  sortOrder: number,
  featured = false,
  services: string[] = [],
): SpecialtyItem {
  const slug = slugify(title);
  const now = "2026-01-01T00:00:00.000Z";

  return {
    id: slug,
    slug,
    title,
    icon,
    shortDescription,
    image: DEFAULT_SPECIALTY_IMAGE,
    detailTitle: `${title} Department`,
    detailDescription: `${title} department provides patient-focused consultation, diagnostic support, treatment planning, and follow-up care through experienced medical professionals.`,
    services: services.length
      ? services
      : [
          "Specialist doctor consultation",
          "Clinical assessment and diagnosis",
          "Required lab and imaging guidance",
          "Treatment planning and follow-up",
          "Patient counselling and care support",
        ],
    doctors: [
      makeDoctor("Dr. A. Rahman", `${title} Specialist`, 1),
      makeDoctor("Dr. Ayesha Rahman", `Consultant - ${title}`, 2),
    ],
    active: true,
    featured,
    showInMenu: true,
    sortOrder,
    createdAt: now,
    updatedAt: now,
  };
}

export const DEFAULT_SPECIALTIES: SpecialtyItem[] = [
  makeSpecialty("Cardiology", "heartPulse", "Heart care, preventive screening, and cardiac diagnostics.", 1, true, [
    "Heart consultation",
    "ECG and cardiac screening",
    "Chest pain evaluation",
    "Hypertension care",
    "Follow-up cardiac treatment planning",
  ]),
  makeSpecialty("Neurology", "brain", "Specialized care for brain, spine, and nerve conditions.", 2, true, [
    "Headache and migraine consultation",
    "Stroke risk assessment",
    "Nerve pain evaluation",
    "Seizure care guidance",
    "Brain and spine diagnostic support",
  ]),
  makeSpecialty("Orthopedics", "bone", "Bone, joint, trauma, and sports injury management.", 3, true, [
    "Bone and joint consultation",
    "Back pain and knee pain care",
    "Fracture follow-up",
    "Sports injury support",
    "Physiotherapy and rehabilitation guidance",
  ]),
  makeSpecialty("Paediatrics", "baby", "Compassionate care for newborns, children, and teens.", 4, true),
  makeSpecialty("Diagnostics", "microscope", "Reliable lab, imaging, and health screening services.", 5, true),
  makeSpecialty("Emergency Care", "ambulance", "Round-the-clock urgent care and rapid response support.", 6, true),
  makeSpecialty("Accident & Emergency", "ambulance", "Emergency and trauma response service.", 7),
  makeSpecialty("Anesthesia And Pain Medicine", "syringe", "Anesthesia and pain management care.", 8),
  makeSpecialty("Cancer Care Centre", "shieldPlus", "Cancer screening, care, and consultation support.", 9),
  makeSpecialty("Cardiology Care Centre", "heartPulse", "Advanced heart care and cardiac support.", 10),
  makeSpecialty("Cardiothoracic & Vascular Surgery", "heartPulse", "Cardiac, thoracic, and vascular surgical support.", 11),
  makeSpecialty("Cardiothoracic Anaesthesia", "pill", "Specialized anaesthesia support for cardiac surgery.", 12),
  makeSpecialty("Child Development Centre", "baby", "Child development assessment and care guidance.", 13),
  makeSpecialty("Counselling Centre", "userRoundCheck", "Patient counselling and emotional care support.", 14),
  makeSpecialty("Critical Care Units", "hospital", "Critical care and intensive monitoring support.", 15),
  makeSpecialty("Dental & Maxillofacial Surgery", "badgePlus", "Dental and facial surgical care.", 16),
  makeSpecialty("Dermatology & Venereology", "sparkles", "Skin, hair, allergy, and venereology care.", 17),
  makeSpecialty("Diabetology & Endocrinology", "droplets", "Diabetes and hormone disorder care.", 18),
  makeSpecialty("Diagnostic & Interventional Radiology", "scanLine", "Radiology and image-guided procedure support.", 19),
  makeSpecialty("Dietetics & Nutrition", "utensils", "Diet planning and nutrition counselling.", 20),
  makeSpecialty("ENT & Head Neck Surgery", "ear", "Ear, nose, throat, and head-neck care.", 21),
  makeSpecialty("Fertility Centre", "sparkles", "Fertility consultation and patient guidance.", 22),
  makeSpecialty("Gastroenterology & Hepatology", "stethoscope", "Digestive system and liver care.", 23),
  makeSpecialty("General & Laparoscopic Surgery", "bandage", "General and minimally invasive surgical support.", 24),
  makeSpecialty("Hematology & Stem Cell Transplant", "droplets", "Blood disorder and transplant care support.", 25),
  makeSpecialty("Hepatobiliary, Pancreatic And Liver Transplant", "hospital", "Liver, pancreas, and transplant support.", 26),
  makeSpecialty("Internal Medicine", "stethoscope", "General adult medicine and diagnosis.", 27),
  makeSpecialty("Joint Care & Wellness Centre", "bone", "Joint pain, mobility, and wellness care.", 28),
  makeSpecialty("Kidney Transplant Program", "hospital", "Kidney transplant and renal care support.", 29),
  makeSpecialty("Lab Medicine", "testTube", "Laboratory medicine and test support.", 30),
  makeSpecialty("Lithotripsy", "circleDot", "Kidney stone treatment support.", 31),
  makeSpecialty("Neonatology", "baby", "Newborn and premature baby care.", 32),
  makeSpecialty("Nephrology", "activity", "Kidney disease consultation and care.", 33),
  makeSpecialty("Neurosurgery", "brain", "Brain and spine surgical care.", 34),
  makeSpecialty("Nuclear Medicine", "activity", "Nuclear medicine diagnostic support.", 35),
  makeSpecialty("Obstetrics And Gynaecology", "sparkles", "Women's health and pregnancy care.", 36),
  makeSpecialty("Ophthalmology", "eye", "Eye care and vision support.", 37),
  makeSpecialty("Paediatric Cardiology", "heartPulse", "Heart care for children.", 38),
  makeSpecialty("Paediatric Surgery & Paediatric Urology", "baby", "Child surgery and urology care.", 39),
  makeSpecialty("Physical Medicine & Rehabilitation", "activity", "Rehabilitation and physical medicine care.", 40),
  makeSpecialty("Plastic, Reconstructive & Cosmetic Surgery", "sparkles", "Plastic and reconstructive surgery support.", 41),
  makeSpecialty("Psychiatry", "brain", "Mental health consultation and support.", 42),
  makeSpecialty("Respiratory Medicine", "activity", "Lung and breathing problem care.", 43),
  makeSpecialty("Rheumatology", "bone", "Joint, arthritis, and autoimmune care.", 44),
  makeSpecialty("Thoracic Surgery", "activity", "Chest and thoracic surgical support.", 45),
  makeSpecialty("Transfusion Medicine", "droplets", "Blood transfusion medicine support.", 46),
  makeSpecialty("Urology", "droplets", "Urinary system and male health care.", 47),
];

function normalizeSpecialty(item: Partial<SpecialtyItem>, index: number) {
  const title = item.title?.trim() || "New Specialty";
  const slug = slugify(item.slug || title);
  const now = new Date().toISOString();

  return {
    id: item.id || slug || makeSpecialtyId(),
    slug: slug || `specialty-${index + 1}`,
    title,
    icon: item.icon || "stethoscope",
    shortDescription: item.shortDescription || "Specialist consultation and care support.",
    image: item.image || DEFAULT_SPECIALTY_IMAGE,
    detailTitle: item.detailTitle || `${title} Department`,
    detailDescription:
      item.detailDescription ||
      `${title} department provides consultation, diagnostic support, and treatment planning.`,
    services: Array.isArray(item.services) ? item.services.filter(Boolean) : [],
    doctors: Array.isArray(item.doctors)
      ? item.doctors.map((doctor, doctorIndex) => ({
          id: doctor.id || `doctor-${doctorIndex + 1}-${slug}`,
          name: doctor.name || "Doctor",
          title: doctor.title || "Consultant",
          schedule: doctor.schedule || "Saturday, Monday, Wednesday",
          time: doctor.time || "10:00 AM - 2:00 PM",
          room: doctor.room || "Room 201",
          fee: doctor.fee || "700 BDT",
          image: doctor.image || "",
          active: doctor.active ?? true,
          sortOrder: Number(doctor.sortOrder) || doctorIndex + 1,
        }))
      : [],
    active: item.active ?? true,
    featured: item.featured ?? false,
    showInMenu: item.showInMenu ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
    createdAt: item.createdAt || now,
    updatedAt: item.updatedAt || now,
  } satisfies SpecialtyItem;
}

export function getSpecialtiesFromStorage(): SpecialtyItem[] {
  return DEFAULT_SPECIALTIES;
}

export function getActiveSpecialties(): SpecialtyItem[] {
  return getSpecialtiesFromStorage()
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

export function getFeaturedSpecialties(): SpecialtyItem[] {
  return getActiveSpecialties().filter((item) => item.featured);
}

export function saveSpecialtiesToStorage(_items: SpecialtyItem[]) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event("specialties-updated"));
}

export function linesToArray(value: string) {
  return value
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);
}

export function doctorsToLines(doctors: SpecialtyDoctor[]) {
  return doctors
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .map((doctor) =>
      [
        doctor.name,
        doctor.title,
        doctor.schedule,
        doctor.time,
        doctor.room,
        doctor.fee,
        doctor.image,
        doctor.active ? "active" : "hidden",
      ].join("|"),
    )
    .join("\n");
}

export function linesToDoctors(value: string): SpecialtyDoctor[] {
  return value
    .split("\n")
    .map((line, index) => {
      const [name, title, schedule, time, room, fee, image, status] = line
        .split("|")
        .map((item) => item.trim());

      if (!name) return null;

      return {
        id: `doctor-${Date.now()}-${index}-${slugify(name)}`,
        name,
        title: title || "Consultant",
        schedule: schedule || "Saturday, Monday, Wednesday",
        time: time || "10:00 AM - 2:00 PM",
        room: room || "Room 201",
        fee: fee || "700 BDT",
        image: image || "",
        active: (status || "active").toLowerCase() !== "hidden",
        sortOrder: index + 1,
      };
    })
    .filter(Boolean) as SpecialtyDoctor[];
}

export function makeSpecialtyId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }

  return `specialty-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}
