import {
  Award,
  BadgeCheck,
  BookOpenCheck,
  Brain,
  GraduationCap,
  HandHeart,
  HeartPulse,
  Lightbulb,
  Medal,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  Target,
  UsersRound,
  type LucideIcon,
} from "lucide-react";

export type AboutIconKey =
  | "award"
  | "badgeCheck"
  | "bookOpenCheck"
  | "brain"
  | "graduationCap"
  | "handHeart"
  | "heartPulse"
  | "lightbulb"
  | "medal"
  | "shieldCheck"
  | "sparkles"
  | "stethoscope"
  | "target"
  | "usersRound";

export const aboutIconOptions: { key: AboutIconKey; label: string }[] = [
  { key: "heartPulse", label: "Heart Pulse" },
  { key: "stethoscope", label: "Medical Care" },
  { key: "shieldCheck", label: "Patient Safety" },
  { key: "handHeart", label: "Trusted Support" },
  { key: "badgeCheck", label: "Quality" },
  { key: "award", label: "Award" },
  { key: "medal", label: "Medal" },
  { key: "lightbulb", label: "Innovation" },
  { key: "sparkles", label: "Respect / Care" },
  { key: "graduationCap", label: "Medical Training" },
  { key: "bookOpenCheck", label: "Medical Learning" },
  { key: "target", label: "Mission / Goal" },
  { key: "usersRound", label: "People / Team" },
  { key: "brain", label: "Specialist Care" },
];

const aboutIconMap: Record<AboutIconKey, LucideIcon> = {
  award: Award,
  badgeCheck: BadgeCheck,
  bookOpenCheck: BookOpenCheck,
  brain: Brain,
  graduationCap: GraduationCap,
  handHeart: HandHeart,
  heartPulse: HeartPulse,
  lightbulb: Lightbulb,
  medal: Medal,
  shieldCheck: ShieldCheck,
  sparkles: Sparkles,
  stethoscope: Stethoscope,
  target: Target,
  usersRound: UsersRound,
};

export function getAboutIcon(iconKey?: string) {
  return aboutIconMap[(iconKey || "stethoscope") as AboutIconKey] || Stethoscope;
}
