import { type Prisma } from "@prisma/client";

import { db } from "@/lib/db";

export type AdminSmsTemplate = {
  id: string;
  templateKey: string;
  title: string;
  message: string;
  variables: string[];
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export type SmsTemplateUpdateInput = {
  title?: unknown;
  message?: unknown;
  variables?: unknown;
  isActive?: unknown;
  sortOrder?: unknown;
};

function cleanText(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function parseVariables(value: unknown) {
  if (Array.isArray(value)) {
    return value.map(String).map((item) => item.trim()).filter(Boolean);
  }

  if (typeof value === "string") {
    return value
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return [];
}

function parseSortOrder(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.round(number)) : 0;
}

function mapSmsTemplate(record: {
  id: string;
  templateKey: string;
  title: string;
  message: string;
  variables: Prisma.JsonValue | null;
  isActive: boolean;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
}): AdminSmsTemplate {
  return {
    id: record.id,
    templateKey: record.templateKey,
    title: record.title,
    message: record.message,
    variables: parseVariables(record.variables),
    isActive: record.isActive,
    sortOrder: record.sortOrder,
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  };
}

export async function getAdminSmsTemplates() {
  const templates = await db.smsTemplate.findMany({
    orderBy: [{ sortOrder: "asc" }, { templateKey: "asc" }],
  });

  return templates.map(mapSmsTemplate);
}

export async function getSmsTemplateById(id: string) {
  const template = await db.smsTemplate.findUnique({ where: { id } });
  return template ? mapSmsTemplate(template) : null;
}

export async function updateSmsTemplate(
  id: string,
  payload: SmsTemplateUpdateInput,
) {
  const title = cleanText(payload.title);
  const message = cleanText(payload.message);
  const variables = parseVariables(payload.variables);
  const sortOrder = parseSortOrder(payload.sortOrder);

  if (!title) throw new Error("Template title is required.");
  if (!message) throw new Error("Template message is required.");

  const template = await db.smsTemplate.update({
    where: { id },
    data: {
      title,
      message,
      variables,
      isActive: Boolean(payload.isActive),
      sortOrder,
    },
  });

  return mapSmsTemplate(template);
}
