export const IMAGE_MAX_FILE_SIZE = 5 * 1024 * 1024;

const signatures: Record<string, number[][]> = {
  "image/jpeg": [[0xff, 0xd8, 0xff]],
  "image/png": [[0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]],
  "image/webp": [
    [0x52, 0x49, 0x46, 0x46],
  ],
};

export const allowedImageTypes = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
]);

function startsWithSignature(bytes: Buffer, signature: number[]) {
  if (bytes.length < signature.length) return false;
  return signature.every((value, index) => bytes[index] === value);
}

export function isSafeImageBuffer(bytes: Buffer, mimeType: string) {
  const expectedSignatures = signatures[mimeType];

  if (!expectedSignatures) return false;

  if (mimeType === "image/webp") {
    const riff = startsWithSignature(bytes, [0x52, 0x49, 0x46, 0x46]);
    const webp = bytes.length >= 12 && bytes.subarray(8, 12).toString("ascii") === "WEBP";
    return riff && webp;
  }

  return expectedSignatures.some((signature) => startsWithSignature(bytes, signature));
}

export function safeImageBaseName(name: string, fallback = "cms-image") {
  const extensionless = name.replace(/\.[^.]+$/, "");
  const slug = extensionless
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);

  return slug || fallback;
}
