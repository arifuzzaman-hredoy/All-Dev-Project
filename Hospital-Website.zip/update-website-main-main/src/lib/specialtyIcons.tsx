import {
  Activity,
  Ambulance,
  Baby,
  BadgePlus,
  Bandage,
  Bone,
  Brain,
  BriefcaseMedical,
  CircleDot,
  Droplets,
  Ear,
  Eye,
  HeartPulse,
  Hospital,
  Microscope,
  Pill,
  ScanLine,
  ShieldPlus,
  Sparkles,
  Stethoscope,
  Syringe,
  TestTube2,
  UserRoundCheck,
  Utensils,
  type LucideIcon,
} from "lucide-react";

export type SpecialtyIconKey =
  | "activity"
  | "ambulance"
  | "baby"
  | "badgePlus"
  | "bandage"
  | "bone"
  | "brain"
  | "briefcaseMedical"
  | "circleDot"
  | "droplets"
  | "ear"
  | "eye"
  | "heartPulse"
  | "hospital"
  | "microscope"
  | "pill"
  | "scanLine"
  | "shieldPlus"
  | "sparkles"
  | "stethoscope"
  | "syringe"
  | "testTube"
  | "userRoundCheck"
  | "utensils";

export const specialtyIconOptions: { key: SpecialtyIconKey; label: string }[] = [
  { key: "heartPulse", label: "Heart Pulse" },
  { key: "brain", label: "Brain / Neurology" },
  { key: "bone", label: "Bone / Orthopedics" },
  { key: "baby", label: "Baby / Pediatrics" },
  { key: "microscope", label: "Microscope / Diagnostics" },
  { key: "ambulance", label: "Ambulance / Emergency" },
  { key: "stethoscope", label: "Stethoscope" },
  { key: "hospital", label: "Hospital" },
  { key: "briefcaseMedical", label: "Medical Briefcase" },
  { key: "shieldPlus", label: "Shield Plus" },
  { key: "testTube", label: "Lab Test Tube" },
  { key: "scanLine", label: "Scan / Radiology" },
  { key: "syringe", label: "Syringe" },
  { key: "pill", label: "Medicine" },
  { key: "droplets", label: "Blood / Transfusion" },
  { key: "eye", label: "Eye / Ophthalmology" },
  { key: "ear", label: "ENT / Ear" },
  { key: "utensils", label: "Nutrition" },
  { key: "sparkles", label: "Cosmetic / Wellness" },
  { key: "activity", label: "Activity / Care" },
  { key: "bandage", label: "Surgery / Bandage" },
  { key: "userRoundCheck", label: "Consultation" },
  { key: "badgePlus", label: "Badge Plus" },
  { key: "circleDot", label: "Default Circle" },
];

const specialtyIconMap: Record<SpecialtyIconKey, LucideIcon> = {
  activity: Activity,
  ambulance: Ambulance,
  baby: Baby,
  badgePlus: BadgePlus,
  bandage: Bandage,
  bone: Bone,
  brain: Brain,
  briefcaseMedical: BriefcaseMedical,
  circleDot: CircleDot,
  droplets: Droplets,
  ear: Ear,
  eye: Eye,
  heartPulse: HeartPulse,
  hospital: Hospital,
  microscope: Microscope,
  pill: Pill,
  scanLine: ScanLine,
  shieldPlus: ShieldPlus,
  sparkles: Sparkles,
  stethoscope: Stethoscope,
  syringe: Syringe,
  testTube: TestTube2,
  userRoundCheck: UserRoundCheck,
  utensils: Utensils,
};

export function getSpecialtyIcon(iconKey?: string) {
  return (
    specialtyIconMap[(iconKey || "stethoscope") as SpecialtyIconKey] ||
    Stethoscope
  );
}
