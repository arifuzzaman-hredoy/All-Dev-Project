export const CAREER_CMS_STORAGE_KEY = "updateDiagnostic.careerCms.v2";
export const CAREER_APPLICATION_STORAGE_KEY =
  "updateDiagnostic.careerApplications.v2";

export const CAREER_CMS_EVENT = "careerCmsChanged";
export const CAREER_APPLICATION_EVENT = "careerApplicationChanged";

export type CareerIconKey =
  | "users"
  | "heart"
  | "growth"
  | "briefcase"
  | "award"
  | "stethoscope"
  | "graduation";

export type CareerHeroSlide = {
  id: string;
  title: string;
  imageUrl: string;
};

export type CareerValueCard = {
  id: string;
  title: string;
  icon: CareerIconKey;
};

export type CareerDepartment = {
  id: string;
  name: string;
};

export type CareerJob = {
  id: string;
  slug: string;
  title: string;
  departmentId: string;
  categoryLabel: string;
  imageUrl: string;
  location: string;
  type: string;
  vacancy: string;
  deadline: string;
  salary: string;
  summary: string;
  details: string;
  responsibilities: string[];
  requirements: string[];
  status: "open" | "closed";
};

export type CareerEventItem = {
  id: string;
  slug: string;
  label: string;
  title: string;
  date: string;
  location: string;
  imageUrl: string;
  excerpt: string;
  contentParagraphs: string[];
};

export type CareerFeatureCard = {
  id: string;
  title: string;
  icon: CareerIconKey;
};

export type CareerCmsData = {
  heroSlides: CareerHeroSlide[];
  intro: {
    badge: string;
    titleBefore: string;
    highlight: string;
    titleAfter: string;
    subtitle: string;
    description: string;
    values: CareerValueCard[];
  };
  hrMessage: {
    name: string;
    designation: string;
    photoUrl: string;
    title: string;
    paragraphs: string[];
  };
  departments: CareerDepartment[];
  jobs: CareerJob[];
  joinUs: {
    titleBefore: string;
    highlight: string;
    description: string;
    buttonLabel: string;
  };
  events: CareerEventItem[];
  feature: {
    badge: string;
    title: string;
    highlight: string;
    description: string;
    imageUrl: string;
    imageLabel: string;
    cards: CareerFeatureCard[];
  };
};

export type CareerApplication = {
  id: string;
  submittedAt: string;
  applyType: "job" | "general";
  jobId?: string;
  jobTitle?: string;
  department?: string;
  fullName: string;
  phone: string;
  email: string;
  address: string;
  education: string;
  experience: string;
  expectedSalary: string;
  coverNote: string;
  resumeFileName?: string;
  resumeDataUrl?: string;
  status: "new" | "reviewed" | "shortlisted" | "rejected";
};

export const uid = (prefix = "id") =>
  `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

export const slugify = (value: string) =>
  value
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");

const isBrowser = () => typeof window !== "undefined";

const safeParse = <T,>(value: string | null, fallback: T): T => {
  if (!value) return fallback;

  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
};

let careerCmsCacheRaw: string | null | undefined;
let careerCmsCacheData: CareerCmsData | undefined;

const withImageFallback = <T extends { id: string; imageUrl: string }>(
  items: T[] | undefined,
  fallbacks: T[],
) => {
  if (!items?.length) return fallbacks;

  return items.map((item, index) => {
    const fallback =
      fallbacks.find((fallbackItem) => fallbackItem.id === item.id) ||
      fallbacks[index];

    return {
      ...item,
      imageUrl: item.imageUrl || fallback?.imageUrl || "",
    };
  });
};

const normalizeCareerCmsData = (
  saved: Partial<CareerCmsData>,
): CareerCmsData => ({
  ...defaultCareerCmsData,
  ...saved,
  intro: { ...defaultCareerCmsData.intro, ...saved.intro },
  joinUs: { ...defaultCareerCmsData.joinUs, ...saved.joinUs },
  heroSlides: withImageFallback(
    saved.heroSlides,
    defaultCareerCmsData.heroSlides,
  ),
  departments: saved.departments?.length
    ? saved.departments
    : defaultCareerCmsData.departments,
  jobs: withImageFallback(saved.jobs, defaultCareerCmsData.jobs),
  events: withImageFallback(saved.events, defaultCareerCmsData.events),
  hrMessage: {
    ...defaultCareerCmsData.hrMessage,
    ...saved.hrMessage,
    photoUrl:
      saved.hrMessage?.photoUrl || defaultCareerCmsData.hrMessage.photoUrl,
  },
  feature: {
    ...defaultCareerCmsData.feature,
    ...saved.feature,
    imageUrl: saved.feature?.imageUrl || defaultCareerCmsData.feature.imageUrl,
  },
});

export const defaultCareerCmsData: CareerCmsData = {
  heroSlides: [
    {
      id: "hero-1",
      title: "Career at Update Diagnostic Center",
      imageUrl: "/doctor-articles/doctor-2.jpg",
    },
    {
      id: "hero-2",
      title: "Team celebration and employee engagement",
      imageUrl: "/slider1.jpeg",
    },
    {
      id: "hero-3",
      title: "Modern diagnostic service with caring people",
      imageUrl: "/news/news-1.jpg",
    },
  ],
  intro: {
    badge: "Career with us",
    titleBefore: "Want to join",
    highlight: "our team",
    titleAfter: "?",
    subtitle: "Join us in transforming healthcare in Bangladesh",
    description:
      "At Update Diagnostic Center, your career is a journey that touches lives and transforms futures. Every team member is valued for their unique contribution.",
    values: [
      { id: "value-1", title: "Diverse Team", icon: "users" },
      { id: "value-2", title: "Care Mission", icon: "heart" },
      { id: "value-3", title: "Growth Culture", icon: "growth" },
    ],
  },
  hrMessage: {
    name: "Kaiser Chowdhury",
    designation: "Senior Director, HR - Bangladesh",
    photoUrl: "/doctor-articles/doctor-1.jpg",
    title: "Message from Senior Director, HR",
    paragraphs: [
      "I am pleased to welcome you to our career page.",
      "We believe that our greatest asset is our people. Our healthcare professionals are committed to serving patients with care, discipline, and responsibility.",
      "If you are passionate about healthcare service and professional growth, we invite you to join our team.",
    ],
  },
  departments: [
    { id: "dept-medical", name: "Medical" },
    { id: "dept-nursing", name: "Nursing" },
    { id: "dept-non-medical", name: "Non Medical" },
  ],
  jobs: [
    {
      id: "job-rmo",
      slug: "resident-medical-officer",
      title: "Resident Medical Officer",
      departmentId: "dept-medical",
      categoryLabel: "Medical",
      imageUrl: "/news/news-1.jpg",
      location: "Dhaka",
      type: "Full Time",
      vacancy: "Multiple",
      deadline: "N/A",
      salary: "Negotiable",
      summary:
        "Responsible for patient care, clinical coordination, and duty roster support.",
      details:
        "The selected candidate will support doctors, patients, and internal healthcare operations with professionalism.",
      responsibilities: [
        "Support day-to-day clinical service",
        "Coordinate with medical teams",
        "Maintain patient care standards",
      ],
      requirements: ["Relevant medical qualification", "Good communication skill"],
      status: "open",
    },
    {
      id: "job-staff-nurse",
      slug: "staff-nurse",
      title: "Staff Nurse",
      departmentId: "dept-nursing",
      categoryLabel: "Nursing",
      imageUrl: "/blogs/blog-2.jpg",
      location: "Dhaka",
      type: "Full Time",
      vacancy: "Multiple",
      deadline: "N/A",
      salary: "Negotiable",
      summary: "Provide nursing care and support patient service activities.",
      details:
        "The selected candidate will work with the clinical team to provide safe and caring service.",
      responsibilities: [
        "Assist patient care",
        "Maintain nursing documentation",
        "Follow clinical safety protocols",
      ],
      requirements: ["Nursing qualification", "Professional attitude"],
      status: "open",
    },
    {
      id: "job-customer-care",
      slug: "customer-care-officer",
      title: "Customer Care Officer",
      departmentId: "dept-non-medical",
      categoryLabel: "Non Medical",
      imageUrl: "/slider4.jpeg",
      location: "Dhaka",
      type: "Full Time",
      vacancy: "Multiple",
      deadline: "31 July 2026",
      salary: "Negotiable",
      summary:
        "Handle patient queries, appointment support, and front-desk communication.",
      details:
        "The selected candidate will communicate with patients and support service coordination.",
      responsibilities: [
        "Answer patient queries",
        "Support appointments",
        "Maintain service quality",
      ],
      requirements: ["Customer service mindset", "Computer operating skill"],
      status: "open",
    },
  ],
  joinUs: {
    titleBefore: "Join",
    highlight: "Us",
    description:
      "Submit your resume, we will contact you when a relevant opportunity becomes available.",
    buttonLabel: "Submit your resume",
  },
  events: [
    {
      id: "event-1",
      slug: "healthy-week-2025",
      label: "Event 01",
      title: "Healthy Week 2025 at Update Diagnostic Center",
      date: "14 July 2025",
      location: "Update Diagnostic Center",
      imageUrl: "/blogs/blog-1.jpg",
      excerpt:
        "A team-focused health awareness activity designed to celebrate wellness, preventive care, and staff participation.",
      contentParagraphs: [
        "Healthy Week 2025 brought employees, service teams, and healthcare professionals together around a shared message of preventive care and workplace wellness.",
        "The program highlighted practical health awareness, patient communication, and team culture.",
        "This detail page is editable from the Career admin panel.",
      ],
    },
    {
      id: "event-2",
      slug: "campus-activation-afmc",
      label: "Event 02",
      title: "Campus Activation in Armed Forces Medical College (AFMC)",
      date: "14 July 2025",
      location: "AFMC",
      imageUrl: "/news/news-2.jpg",
      excerpt:
        "A campus activation program focused on healthcare career engagement.",
      contentParagraphs: [
        "The event connected healthcare students and professionals with Update Diagnostic Center career opportunities.",
        "The team discussed service culture, learning, and future professional growth.",
      ],
    },
    {
      id: "event-3",
      slug: "campus-activation-north-south-university",
      label: "Event 03",
      title: "Campus Activation in North South University",
      date: "01 March 2025",
      location: "North South University",
      imageUrl: "/doctor-articles/doctor-2.jpg",
      excerpt:
        "A meaningful employee engagement and campus outreach activity.",
      contentParagraphs: [
        "This event focused on awareness, communication, and career growth possibilities.",
        "Update Diagnostic Center continues to create meaningful opportunities for healthcare professionals.",
      ],
    },
  ],
  feature: {
    badge: "Career Feature",
    title: "The first MRCP (UK) PACES examination center in Bangladesh",
    highlight: "MRCP (UK) PACES",
    description:
      "Update Diagnostic Center has been chosen as a center for specialist clinical learning, marking a meaningful achievement in medical education. This recognition strengthens our reputation for excellence and creates more opportunities for healthcare professionals to grow their careers locally.",
    imageUrl: "/news/news-2.jpg",
    imageLabel: "Medical Career Growth",
    cards: [
      { id: "feature-1", title: "Clinical Learning", icon: "graduation" },
      { id: "feature-2", title: "Career Excellence", icon: "award" },
      { id: "feature-3", title: "Specialist Growth", icon: "stethoscope" },
    ],
  },
};

export const getCareerCmsData = (): CareerCmsData => {
  if (!isBrowser()) return defaultCareerCmsData;

  const raw = window.localStorage.getItem(CAREER_CMS_STORAGE_KEY);

  if (raw === careerCmsCacheRaw && careerCmsCacheData) {
    return careerCmsCacheData;
  }

  const saved = safeParse<Partial<CareerCmsData>>(
    raw,
    {},
  );

  careerCmsCacheRaw = raw;
  careerCmsCacheData = normalizeCareerCmsData(saved);

  return careerCmsCacheData;
};

export const saveCareerCmsData = (data: CareerCmsData) => {
  if (!isBrowser()) return;

  const raw = JSON.stringify(data);
  careerCmsCacheRaw = raw;
  careerCmsCacheData = normalizeCareerCmsData(data);
  window.localStorage.setItem(CAREER_CMS_STORAGE_KEY, raw);
  window.dispatchEvent(new Event(CAREER_CMS_EVENT));
};

export const resetCareerCmsData = () => {
  if (!isBrowser()) return;

  careerCmsCacheRaw = null;
  careerCmsCacheData = defaultCareerCmsData;
  window.localStorage.removeItem(CAREER_CMS_STORAGE_KEY);
  window.dispatchEvent(new Event(CAREER_CMS_EVENT));
};

export const subscribeCareerCms = (callback: () => void) => {
  if (!isBrowser()) return () => undefined;

  const handler = () => callback();

  window.addEventListener(CAREER_CMS_EVENT, handler);
  window.addEventListener("storage", handler);

  return () => {
    window.removeEventListener(CAREER_CMS_EVENT, handler);
    window.removeEventListener("storage", handler);
  };
};

export const getCareerApplications = (): CareerApplication[] => {
  if (!isBrowser()) return [];

  return safeParse(
    window.localStorage.getItem(CAREER_APPLICATION_STORAGE_KEY),
    [],
  );
};

export const saveCareerApplications = (applications: CareerApplication[]) => {
  if (!isBrowser()) return;

  window.localStorage.setItem(
    CAREER_APPLICATION_STORAGE_KEY,
    JSON.stringify(applications),
  );
  window.dispatchEvent(new Event(CAREER_APPLICATION_EVENT));
};

export const addCareerApplication = (
  application: Omit<CareerApplication, "id" | "submittedAt" | "status">,
) => {
  const nextApplication: CareerApplication = {
    ...application,
    id: uid("application"),
    submittedAt: new Date().toISOString(),
    status: "new",
  };

  saveCareerApplications([nextApplication, ...getCareerApplications()]);
  return nextApplication;
};

export const updateCareerApplicationStatus = (
  id: string,
  status: CareerApplication["status"],
) => {
  const applications = getCareerApplications().map((application) =>
    application.id === id ? { ...application, status } : application,
  );

  saveCareerApplications(applications);
};

export const deleteCareerApplication = (id: string) => {
  const applications = getCareerApplications().filter(
    (application) => application.id !== id,
  );

  saveCareerApplications(applications);
};

export const subscribeCareerApplications = (callback: () => void) => {
  if (!isBrowser()) return () => undefined;

  const handler = () => callback();

  window.addEventListener(CAREER_APPLICATION_EVENT, handler);
  window.addEventListener("storage", handler);

  return () => {
    window.removeEventListener(CAREER_APPLICATION_EVENT, handler);
    window.removeEventListener("storage", handler);
  };
};

export const fileToDataUrl = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("File read failed"));
    reader.readAsDataURL(file);
  });

export const linesToArray = (value: string) =>
  value
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);

export const arrayToLines = (value: string[]) => value.join("\n");
