import {
  SmsDeliveryStatus,
  SmsLogStatus,
  type Prisma,
} from "@prisma/client";

import { db } from "@/lib/db";

type SmsServiceStatus = "PENDING" | "SENT" | "FAILED" | "DISABLED" | "SKIPPED";

export type AdminSmsLog = {
  id: string;
  phone: string;
  message: string;
  provider: string;
  status: SmsLogStatus;
  templateKey: string;
  relatedFormType: string;
  relatedRecordId: string;
  retryCount: number;
  providerMessageId: string;
  providerResponse: Prisma.JsonValue | null;
  errorMessage: string;
  sentAt: string;
  createdAt: string;
  updatedAt: string;
};

function cleanText(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function normalizePhone(phone: string) {
  return phone.trim().replaceAll(" ", "").replaceAll("-", "");
}

function getProvider() {
  return cleanText(process.env.SMS_PROVIDER) || "mock";
}

function getServiceUrl() {
  return cleanText(process.env.SMS_SERVICE_URL).replace(/\/$/, "");
}

function getServiceKey() {
  return cleanText(process.env.SMS_SERVICE_API_KEY);
}

function isSmsEnabled() {
  return process.env.SMS_ENABLED === "true";
}

function normalizeStatus(value: unknown): SmsServiceStatus {
  if (
    value === "PENDING" ||
    value === "SENT" ||
    value === "FAILED" ||
    value === "DISABLED" ||
    value === "SKIPPED"
  ) {
    return value;
  }

  return "FAILED";
}

function toLogStatus(status: SmsServiceStatus): SmsLogStatus {
  switch (status) {
    case "SENT":
      return SmsLogStatus.SENT;
    case "FAILED":
      return SmsLogStatus.FAILED;
    case "DISABLED":
      return SmsLogStatus.DISABLED;
    case "SKIPPED":
      return SmsLogStatus.SKIPPED;
    default:
      return SmsLogStatus.PENDING;
  }
}

function toDeliveryStatus(status: SmsServiceStatus): SmsDeliveryStatus {
  switch (status) {
    case "SENT":
      return SmsDeliveryStatus.SENT;
    case "FAILED":
      return SmsDeliveryStatus.FAILED;
    case "DISABLED":
      return SmsDeliveryStatus.DISABLED;
    case "SKIPPED":
      return SmsDeliveryStatus.SKIPPED;
    default:
      return SmsDeliveryStatus.PENDING;
  }
}

function toJson(value: unknown): Prisma.InputJsonValue | undefined {
  if (value === null || value === undefined) return undefined;

  try {
    return JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;
  } catch {
    return { raw: String(value) };
  }
}

function mapSmsLog(record: {
  id: string;
  phone: string;
  message: string;
  provider: string;
  status: SmsLogStatus;
  templateKey: string | null;
  relatedFormType: string | null;
  relatedRecordId: string | null;
  retryCount: number;
  providerMessageId: string | null;
  providerResponse: Prisma.JsonValue | null;
  errorMessage: string | null;
  sentAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}): AdminSmsLog {
  return {
    id: record.id,
    phone: record.phone,
    message: record.message,
    provider: record.provider,
    status: record.status,
    templateKey: record.templateKey || "",
    relatedFormType: record.relatedFormType || "",
    relatedRecordId: record.relatedRecordId || "",
    retryCount: record.retryCount,
    providerMessageId: record.providerMessageId || "",
    providerResponse: record.providerResponse,
    errorMessage: record.errorMessage || "",
    sentAt: record.sentAt?.toISOString() || "",
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  };
}

async function syncRelatedRecordStatus(log: {
  relatedFormType: string | null;
  relatedRecordId: string | null;
  templateKey: string | null;
  errorMessage: string | null;
}, status: SmsServiceStatus) {
  const relatedRecordId = log.relatedRecordId || "";
  if (!relatedRecordId) return;

  const smsStatus = toDeliveryStatus(status);
  const sentAt = status === "SENT" ? new Date() : null;

  if (log.relatedFormType === "APPOINTMENT") {
    await db.appointment
      .update({
        where: { id: relatedRecordId },
        data: {
          smsStatus,
          smsTemplateKey: log.templateKey || null,
          lastSmsAt: sentAt,
          smsError: log.errorMessage || null,
        },
      })
      .catch(() => null);
  }

  if (log.relatedFormType === "PACKAGE_BOOKING") {
    await db.packageBooking
      .update({
        where: { id: relatedRecordId },
        data: {
          smsStatus,
          smsTemplateKey: log.templateKey || null,
          lastSmsAt: sentAt,
          smsError: log.errorMessage || null,
        },
      })
      .catch(() => null);
  }
}

export async function getAdminSmsLogs() {
  const logs = await db.smsLog.findMany({
    take: 300,
    orderBy: { createdAt: "desc" },
  });

  return logs.map(mapSmsLog);
}

export async function resendSmsLog(id: string) {
  const existing = await db.smsLog.findUnique({ where: { id } });

  if (!existing) {
    throw new Error("SMS log was not found.");
  }

  const provider = getProvider();
  const phone = normalizePhone(existing.phone);

  await db.smsLog.update({
    where: { id },
    data: {
      status: SmsLogStatus.PENDING,
      retryCount: { increment: 1 },
      errorMessage: null,
      provider,
      providerMessageId: null,
      sentAt: null,
    },
  });

  async function finish(status: SmsServiceStatus, payload: {
    providerMessageId?: string | null;
    providerResponse?: unknown;
    errorMessage?: string | null;
    provider?: string;
  }) {
    const updated = await db.smsLog.update({
      where: { id },
      data: {
        status: toLogStatus(status),
        provider: payload.provider || provider,
        providerMessageId: payload.providerMessageId || null,
        providerResponse: toJson(payload.providerResponse),
        errorMessage: payload.errorMessage || null,
        sentAt: status === "SENT" ? new Date() : null,
      },
    });

    await syncRelatedRecordStatus(updated, status);

    return mapSmsLog(updated);
  }

  if (!phone) {
    return finish("FAILED", { errorMessage: "Phone number is empty." });
  }

  if (!existing.message.trim()) {
    return finish("FAILED", { errorMessage: "SMS message is empty." });
  }

  if (!isSmsEnabled()) {
    return finish("DISABLED", {
      errorMessage: "SMS sending is disabled by SMS_ENABLED=false.",
    });
  }

  const serviceUrl = getServiceUrl();

  if (!serviceUrl) {
    return finish("DISABLED", {
      errorMessage: "SMS_SERVICE_URL is not configured.",
    });
  }

  try {
    const response = await fetch(`${serviceUrl}/send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(getServiceKey()
          ? {
              "X-SMS-Service-Key": getServiceKey(),
            }
          : {}),
      },
      body: JSON.stringify({
        phone,
        message: existing.message,
        templateKey: existing.templateKey,
        relatedFormType: existing.relatedFormType,
        relatedRecordId: existing.relatedRecordId,
        metadata: {
          resend: true,
          smsLogId: existing.id,
          retryCount: existing.retryCount + 1,
        },
      }),
    });

    const data = (await response.json().catch(() => null)) as {
      status?: SmsServiceStatus;
      provider?: string;
      providerMessageId?: string | null;
      providerResponse?: unknown;
      errorMessage?: string | null;
    } | null;

    if (!response.ok) {
      return finish("FAILED", {
        providerResponse: data,
        errorMessage: data?.errorMessage || `SMS service HTTP ${response.status}`,
      });
    }

    return finish(normalizeStatus(data?.status), {
      provider: data?.provider || provider,
      providerMessageId: data?.providerMessageId || null,
      providerResponse: data?.providerResponse || data,
      errorMessage: data?.errorMessage || null,
    });
  } catch (caught) {
    return finish("FAILED", {
      errorMessage:
        caught instanceof Error ? caught.message : "SMS service request failed.",
    });
  }
}
