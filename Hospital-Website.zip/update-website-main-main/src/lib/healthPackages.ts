import { healthPackages as siteHealthPackages } from "@/data/site";

export type HealthPackage = {
  id: string;
  slug: string;
  title: string;
  name: string;
  badge: string;
  price: string;
  target: string;
  subtitle: string;
  image: string;
  tests: string[];
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export const HEALTH_PACKAGES_STORAGE_KEY =
  "update-diagnostic-center-health-packages-control";

const seededAt = "2026-06-12T00:00:00.000Z";

export const DEFAULT_HEALTH_PACKAGES: HealthPackage[] = siteHealthPackages.map(
  (item, index) => ({
    id: item.slug,
    slug: item.slug,
    title: item.title,
    name: item.title,
    badge: "HEALTH PACKAGES",
    price: item.price,
    target: item.subtitle || "",
    subtitle:
      "Choose a suitable health check package for preventive care, routine screening, and better health planning.",
    image: item.image,
    tests: item.tests,
    active: true,
    sortOrder: index + 1,
    createdAt: seededAt,
    updatedAt: seededAt,
  })
);

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function normalizeHealthPackage(
  item: Partial<HealthPackage>,
  index = 0
): HealthPackage {
  const title = item.title || item.name || "Health Package";
  const now = new Date().toISOString();

  return {
    id: item.id || slugify(item.slug || title) || `health-package-${index + 1}`,
    slug: item.slug || slugify(title) || `health-package-${index + 1}`,
    title,
    name: item.name || title,
    badge: item.badge || "HEALTH PACKAGES",
    price: item.price || "",
    target: item.target || "",
    subtitle:
      item.subtitle ||
      "Choose a suitable health check package for preventive care, routine screening, and better health planning.",
    image: item.image || "/slider1.jpeg",
    tests: Array.isArray(item.tests) ? item.tests : [],
    active: item.active ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
    createdAt: item.createdAt || now,
    updatedAt: item.updatedAt || now,
  };
}

export async function fetchHealthPackages(options?: { admin?: boolean }) {
  const endpoint = options?.admin
    ? "/api/admin/health-packages"
    : "/api/health-packages";
  const response = await fetch(endpoint, { cache: "no-store" });

  if (!response.ok) {
    throw new Error("Failed to load health packages.");
  }

  const data = (await response.json()) as { packages?: Partial<HealthPackage>[] };
  return (data.packages || []).map(normalizeHealthPackage);
}

export async function fetchActiveHealthPackages() {
  return fetchHealthPackages();
}

export async function fetchHealthPackageBySlug(slug: string) {
  const response = await fetch(`/api/health-packages/${encodeURIComponent(slug)}`, {
    cache: "no-store",
  });

  if (response.status === 404) return null;
  if (!response.ok) throw new Error("Failed to load health package.");

  const data = (await response.json()) as { package?: Partial<HealthPackage> };
  return data.package ? normalizeHealthPackage(data.package) : null;
}

export async function createHealthPackage(payload: HealthPackage) {
  const response = await fetch("/api/admin/health-packages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Failed to create health package.");
  const data = (await response.json()) as { package: Partial<HealthPackage> };
  return normalizeHealthPackage(data.package);
}

export async function updateHealthPackage(id: string, payload: HealthPackage) {
  const response = await fetch(`/api/admin/health-packages/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("Failed to update health package.");
  const data = (await response.json()) as { package: Partial<HealthPackage> };
  return normalizeHealthPackage(data.package);
}

export async function setHealthPackageActive(id: string, active: boolean) {
  const response = await fetch(`/api/admin/health-packages/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ active }),
  });

  if (!response.ok) throw new Error("Failed to update health package status.");
}

export async function deleteHealthPackage(id: string) {
  const response = await fetch(`/api/admin/health-packages/${id}`, {
    method: "DELETE",
  });

  if (!response.ok) throw new Error("Failed to delete health package.");
}

export async function resetDefaultHealthPackages() {
  const response = await fetch("/api/admin/health-packages/reset", {
    method: "POST",
  });

  if (!response.ok) throw new Error("Failed to reset health packages.");
  const data = (await response.json()) as { packages?: Partial<HealthPackage>[] };
  return (data.packages || []).map(normalizeHealthPackage);
}

export function getHealthPackagesFromStorage(): HealthPackage[] {
  return DEFAULT_HEALTH_PACKAGES;
}

export function getActiveHealthPackages() {
  return DEFAULT_HEALTH_PACKAGES.filter((item) => item.active).sort(
    (a, b) => a.sortOrder - b.sortOrder
  );
}

export function saveHealthPackagesToStorage(_packages: HealthPackage[]) {
  void _packages;
  // Deprecated in Phase 3.4. Health packages are now saved through API + Prisma.
}

export function linesToArray(value: string) {
  return value
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}
