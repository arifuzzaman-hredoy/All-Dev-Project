import "server-only";
import { db } from "@/lib/db";
import {
  CORPORATE_SERVICES_STORAGE_KEY,
  DEFAULT_CORPORATE_SERVICES,
  type CorporateServicesData,
} from "@/lib/corporateServices";

function normalizeCorporate(value: unknown): CorporateServicesData {
  if (!value || typeof value !== "object") return DEFAULT_CORPORATE_SERVICES;
  const parsed = value as Partial<CorporateServicesData>;
  return {
    ...DEFAULT_CORPORATE_SERVICES,
    ...parsed,
    features: Array.isArray(parsed.features) ? parsed.features : DEFAULT_CORPORATE_SERVICES.features,
    logos: Array.isArray(parsed.logos) ? parsed.logos : DEFAULT_CORPORATE_SERVICES.logos,
    updatedAt: String(parsed.updatedAt || DEFAULT_CORPORATE_SERVICES.updatedAt),
  };
}

export async function getCorporateServicesData() {
  const row = await db.siteSetting.findUnique({ where: { key: CORPORATE_SERVICES_STORAGE_KEY } });
  return normalizeCorporate(row?.value);
}

export async function saveCorporateServicesData(data: CorporateServicesData) {
  const finalData = { ...data, updatedAt: new Date().toISOString() };
  await db.siteSetting.upsert({
    where: { key: CORPORATE_SERVICES_STORAGE_KEY },
    update: { value: finalData },
    create: { key: CORPORATE_SERVICES_STORAGE_KEY, value: finalData },
  });
  return finalData;
}

export async function resetCorporateServicesData() {
  return saveCorporateServicesData(DEFAULT_CORPORATE_SERVICES);
}
