type RateLimitRecord = {
  attempts: number;
  firstAttemptAt: number;
  blockedUntil: number;
};

const WINDOW_MS = 10 * 60 * 1000;
const BLOCK_MS = 15 * 60 * 1000;
const MAX_FAILED_ATTEMPTS = 5;

const globalForRateLimit = globalThis as unknown as {
  adminLoginRateLimit?: Map<string, RateLimitRecord>;
};

const buckets = globalForRateLimit.adminLoginRateLimit ?? new Map<string, RateLimitRecord>();

globalForRateLimit.adminLoginRateLimit = buckets;

function now() {
  return Date.now();
}

export function getLoginRateLimitKey(email: string, ip: string) {
  const normalizedEmail = email.trim().toLowerCase() || "unknown";
  const normalizedIp = ip.trim() || "unknown";
  return `${normalizedIp}:${normalizedEmail}`;
}

export function getClientIp(request: Request) {
  const forwardedFor = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const realIp = request.headers.get("x-real-ip")?.trim();
  return forwardedFor || realIp || "local";
}

export function checkAdminLoginRateLimit(key: string) {
  const record = buckets.get(key);
  const current = now();

  if (!record) {
    return { ok: true, retryAfterSeconds: 0 };
  }

  if (record.blockedUntil > current) {
    return {
      ok: false,
      retryAfterSeconds: Math.ceil((record.blockedUntil - current) / 1000),
    };
  }

  if (current - record.firstAttemptAt > WINDOW_MS) {
    buckets.delete(key);
  }

  return { ok: true, retryAfterSeconds: 0 };
}

export function recordAdminLoginAttempt(key: string, success: boolean) {
  if (success) {
    buckets.delete(key);
    return;
  }

  const current = now();
  const existing = buckets.get(key);
  const record =
    existing && current - existing.firstAttemptAt <= WINDOW_MS
      ? existing
      : { attempts: 0, firstAttemptAt: current, blockedUntil: 0 };

  record.attempts += 1;

  if (record.attempts >= MAX_FAILED_ATTEMPTS) {
    record.blockedUntil = current + BLOCK_MS;
  }

  buckets.set(key, record);
}
