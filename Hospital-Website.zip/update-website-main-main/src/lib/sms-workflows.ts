import { FormSubmissionType } from "@prisma/client";

import { db } from "@/lib/db";
import { safeSendTemplatedSms, type SendTemplatedSmsResult } from "@/lib/sms";
import type { PackageBooking } from "@/lib/packageBookings";
import type { AppointmentRecord } from "@/types/appointment";

function smsDate(result: SendTemplatedSmsResult) {
  return result.sentAt ? new Date(result.sentAt) : null;
}

async function updateAppointmentSmsStatus(
  id: string,
  templateKey: string,
  result: SendTemplatedSmsResult,
) {
  try {
    await db.appointment.update({
      where: { id },
      data: {
        smsStatus: result.deliveryStatus,
        smsTemplateKey: templateKey,
        lastSmsAt: smsDate(result),
        smsError: result.errorMessage || null,
      },
    });
  } catch (caught) {
    console.error(
      "[sms-workflow] Appointment SMS status update failed:",
      caught instanceof Error ? caught.message : caught,
    );
  }
}

async function updatePackageBookingSmsStatus(
  id: string,
  templateKey: string,
  result: SendTemplatedSmsResult,
) {
  try {
    await db.packageBooking.update({
      where: { id },
      data: {
        smsStatus: result.deliveryStatus,
        smsTemplateKey: templateKey,
        lastSmsAt: smsDate(result),
        smsError: result.errorMessage || null,
      },
    });
  } catch (caught) {
    console.error(
      "[sms-workflow] Package booking SMS status update failed:",
      caught instanceof Error ? caught.message : caught,
    );
  }
}

export async function sendAppointmentReceivedSms(
  appointment: AppointmentRecord,
) {
  const templateKey = "appointment_received";

  const result = await safeSendTemplatedSms({
    phone: appointment.phone,
    templateKey,
    relatedFormType: FormSubmissionType.APPOINTMENT,
    relatedRecordId: appointment.id,
    variables: {
      patientName: appointment.patientName,
      phone: appointment.phone,
      doctorName: appointment.doctorName,
      serviceName: appointment.department,
      preferredDate: appointment.appointmentTime,
      token: appointment.token,
    },
  });

  await updateAppointmentSmsStatus(appointment.id, templateKey, result);

  return result;
}

export async function sendManualAppointmentCreatedSms(
  appointment: AppointmentRecord,
) {
  const templateKey = "appointment_manual_created";

  const result = await safeSendTemplatedSms({
    phone: appointment.phone,
    templateKey,
    relatedFormType: FormSubmissionType.APPOINTMENT,
    relatedRecordId: appointment.id,
    variables: {
      patientName: appointment.patientName,
      phone: appointment.phone,
      preferredDate: appointment.appointmentTime,
      token: appointment.token,
    },
  });

  await updateAppointmentSmsStatus(appointment.id, templateKey, result);

  return result;
}

export async function sendPackageBookingReceivedSms(booking: PackageBooking) {
  const templateKey = "package_booking_received";

  const result = await safeSendTemplatedSms({
    phone: booking.phone,
    templateKey,
    relatedFormType: FormSubmissionType.PACKAGE_BOOKING,
    relatedRecordId: booking.id,
    variables: {
      patientName: booking.patientName,
      phone: booking.phone,
      packageName: booking.packageName,
      preferredDate: booking.submittedAt,
    },
  });

  await updatePackageBookingSmsStatus(booking.id, templateKey, result);

  return result;
}

function formTemplateKey(formType: FormSubmissionType) {
  switch (formType) {
    case FormSubmissionType.CAREER:
      return "career_form_received";
    case FormSubmissionType.SUPPORT:
      return "support_form_received";
    case FormSubmissionType.CONTACT:
      return "contact_form_received";
    case FormSubmissionType.ONLINE_REPORT:
      return "contact_form_received";
    default:
      return "contact_form_received";
  }
}

export async function sendPublicFormReceivedSms(input: {
  id: string;
  formType: FormSubmissionType;
  name: string;
  phone: string;
  email?: string;
  subject?: string;
  message?: string;
}) {
  const templateKey = formTemplateKey(input.formType);

  return safeSendTemplatedSms({
    phone: input.phone,
    templateKey,
    relatedFormType: input.formType,
    relatedRecordId: input.id,
    variables: {
      name: input.name,
      phone: input.phone,
      email: input.email || "",
      subject: input.subject || "",
      message: input.message || "",
    },
  });
}
