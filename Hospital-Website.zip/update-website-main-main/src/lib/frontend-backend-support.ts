import "server-only";

import { FormSubmissionType } from "@prisma/client";
import { db } from "@/lib/db";

export type BackendSupportStatus = "ready" | "configured" | "pending-config" | "needs-attention";

export type BackendSupportCheck = {
  key: string;
  title: string;
  frontendFeature: string;
  backendSupport: string;
  databaseSupport: string;
  status: BackendSupportStatus;
  evidence: string[];
};

export type FrontendBackendSupportReport = {
  generatedAt: string;
  summary: {
    totalChecks: number;
    readyChecks: number;
    pendingConfigChecks: number;
    needsAttentionChecks: number;
  };
  counts: {
    admins: number;
    staticPages: number;
    careerSubmissions: number;
    allSubmissions: number;
    smsTemplates: number;
    smsLogs: number;
    mediaAssets: number;
    auditLogs: number;
    passwordResetTokens: number;
  };
  checks: BackendSupportCheck[];
};

function smsStatus(): BackendSupportStatus {
  if (process.env.SMS_ENABLED === "true") {
    return process.env.SMS_API_URL ? "configured" : "needs-attention";
  }

  return "pending-config";
}

function smsEvidence() {
  if (process.env.SMS_ENABLED === "true") {
    return [
      "SMS_ENABLED=true",
      process.env.SMS_API_URL ? "SMS_API_URL configured" : "SMS_API_URL missing",
      `SMS_PROVIDER=${process.env.SMS_PROVIDER || "custom"}`,
    ];
  }

  return [
    "SMS workflow is connected and logging.",
    "Real sending is intentionally pending until client SMS API credentials are provided.",
    `SMS_PROVIDER=${process.env.SMS_PROVIDER || "mock"}`,
  ];
}

export async function getFrontendBackendSupportReport(): Promise<FrontendBackendSupportReport> {
  const [
    admins,
    staticPages,
    careerSubmissions,
    allSubmissions,
    smsTemplates,
    smsLogs,
    mediaAssets,
    auditLogs,
    passwordResetTokens,
  ] = await Promise.all([
    db.adminUser.count(),
    db.staticPage.count(),
    db.formSubmission.count({ where: { formType: FormSubmissionType.CAREER } }),
    db.formSubmission.count(),
    db.smsTemplate.count(),
    db.smsLog.count(),
    db.mediaAsset.count(),
    db.auditLog.count(),
    db.adminPasswordResetToken.count(),
  ]);

  const checks: BackendSupportCheck[] = [
    {
      key: "admin-auth",
      title: "Admin authentication",
      frontendFeature: "/admin/login and protected admin workspace",
      backendSupport: "Cookie session, password hash verification, protected admin APIs",
      databaseSupport: "AdminUser and AdminSession tables",
      status: admins > 0 ? "ready" : "needs-attention",
      evidence: [
        `${admins} admin user record(s) found`,
        "Admin sessions are stored in database and expired server-side.",
      ],
    },
    {
      key: "admin-forgot-password",
      title: "Admin forgot password",
      frontendFeature: "/admin/forgot-password, /verify, /reset",
      backendSupport: "Request, verify, and complete reset APIs with session clearing",
      databaseSupport: "AdminPasswordResetToken table",
      status: "ready",
      evidence: [
        `${passwordResetTokens} reset token record(s) currently stored`,
        "Reset code hashing, expiry, attempts, and usedAt tracking are supported.",
      ],
    },
    {
      key: "static-pages",
      title: "Public static pages CMS",
      frontendFeature: "Contact, support, privacy policy, terms, and static page layouts",
      backendSupport: "Public static page API and protected admin static page API",
      databaseSupport: "StaticPage table",
      status: staticPages > 0 ? "ready" : "needs-attention",
      evidence: [
        `${staticPages} static page record(s) found`,
        "Frontend developer localStorage CMS is replaced with DB-backed CMS.",
      ],
    },
    {
      key: "career-apply",
      title: "Career application flow",
      frontendFeature: "/career/apply and career application forms",
      backendSupport: "Public form submission API, admin status API, and admin DB applications panel",
      databaseSupport: "FormSubmission table with CAREER formType",
      status: "ready",
      evidence: [
        `${careerSubmissions} career submission record(s) found`,
        `${allSubmissions} total public form submission record(s) found`,
        "Career form submit creates database record and SMS log workflow entry.",
      ],
    },
    {
      key: "contact-support-forms",
      title: "Contact and support forms",
      frontendFeature: "/contact and /support public request flows",
      backendSupport: "Shared public form submission API with admin submissions list",
      databaseSupport: "FormSubmission table",
      status: "ready",
      evidence: [
        `${allSubmissions} total public form submission record(s) found`,
        "All public request forms share one admin-readable database pipeline.",
      ],
    },
    {
      key: "sms-workflow",
      title: "SMS workflow",
      frontendFeature: "Appointment, package, career, contact/support notification readiness",
      backendSupport: "Node workflow + Python SMS service + retry/log-ready architecture",
      databaseSupport: "SmsTemplate and SmsLog tables",
      status: smsStatus(),
      evidence: [
        `${smsTemplates} SMS template record(s) found`,
        `${smsLogs} SMS log record(s) found`,
        ...smsEvidence(),
      ],
    },
    {
      key: "media-library",
      title: "Media and upload support",
      frontendFeature: "Admin media manager and CMS image fields",
      backendSupport: "Protected upload APIs and media library APIs",
      databaseSupport: "MediaAsset table plus filesystem uploads",
      status: "ready",
      evidence: [
        `${mediaAssets} media asset record(s) found`,
        "Upload validation and protected admin upload routes are available.",
      ],
    },
    {
      key: "exports-audit",
      title: "Exports and audit support",
      frontendFeature: "Admin exports, audit log, and operational traceability",
      backendSupport: "Protected exports APIs and audit write helpers",
      databaseSupport: "ExportAudit and AuditLog tables",
      status: "ready",
      evidence: [
        `${auditLogs} audit log record(s) found`,
        "Admin actions can be tracked without reintroducing client-only state.",
      ],
    },
  ];

  return {
    generatedAt: new Date().toISOString(),
    summary: {
      totalChecks: checks.length,
      readyChecks: checks.filter((check) => check.status === "ready" || check.status === "configured").length,
      pendingConfigChecks: checks.filter((check) => check.status === "pending-config").length,
      needsAttentionChecks: checks.filter((check) => check.status === "needs-attention").length,
    },
    counts: {
      admins,
      staticPages,
      careerSubmissions,
      allSubmissions,
      smsTemplates,
      smsLogs,
      mediaAssets,
      auditLogs,
      passwordResetTokens,
    },
    checks,
  };
}
