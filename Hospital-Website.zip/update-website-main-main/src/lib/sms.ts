import {
  SmsDeliveryStatus,
  SmsLogStatus,
  type Prisma,
} from "@prisma/client";

import { db } from "@/lib/db";

type SmsServiceStatus = "PENDING" | "SENT" | "FAILED" | "DISABLED" | "SKIPPED";

type SmsVariableValue = string | number | boolean | null | undefined;

type SendTemplatedSmsInput = {
  phone: string;
  templateKey: string;
  relatedFormType?: string;
  relatedRecordId?: string;
  variables?: Record<string, SmsVariableValue>;
};

export type SendTemplatedSmsResult = {
  logId?: string;
  status: SmsServiceStatus;
  deliveryStatus: SmsDeliveryStatus;
  logStatus: SmsLogStatus;
  provider: string;
  phone: string;
  message: string;
  templateKey: string;
  providerMessageId?: string | null;
  providerResponse?: Prisma.InputJsonValue | null;
  errorMessage?: string | null;
  sentAt?: string | null;
};

function cleanText(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function normalizePhone(phone: string) {
  return phone.trim().replaceAll(" ", "").replaceAll("-", "");
}

function getProvider() {
  return cleanText(process.env.SMS_PROVIDER) || "mock";
}

function getServiceUrl() {
  return cleanText(process.env.SMS_SERVICE_URL).replace(/\/$/, "");
}

function getServiceKey() {
  return cleanText(process.env.SMS_SERVICE_API_KEY);
}

function isSmsEnabled() {
  return process.env.SMS_ENABLED === "true";
}

function getDefaultVariables() {
  return {
    clinicName:
      cleanText(process.env.NEXT_PUBLIC_SITE_NAME) ||
      cleanText(process.env.SITE_NAME) ||
      "Update Clinic",
    clinicPhone:
      cleanText(process.env.NEXT_PUBLIC_CLINIC_PHONE) ||
      cleanText(process.env.CLINIC_PHONE) ||
      cleanText(process.env.NEXT_PUBLIC_PHONE) ||
      "",
  };
}

function normalizeVariables(
  variables?: Record<string, SmsVariableValue>,
): Record<string, string> {
  const merged = {
    ...getDefaultVariables(),
    ...(variables || {}),
  };

  return Object.fromEntries(
    Object.entries(merged).map(([key, value]) => [
      key,
      value === null || value === undefined ? "" : String(value),
    ]),
  );
}

function renderTemplate(message: string, variables?: Record<string, SmsVariableValue>) {
  const data = normalizeVariables(variables);

  return message.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_match, key) => {
    return data[key] || "";
  });
}

function toLogStatus(status: SmsServiceStatus): SmsLogStatus {
  switch (status) {
    case "SENT":
      return SmsLogStatus.SENT;
    case "FAILED":
      return SmsLogStatus.FAILED;
    case "DISABLED":
      return SmsLogStatus.DISABLED;
    case "SKIPPED":
      return SmsLogStatus.SKIPPED;
    default:
      return SmsLogStatus.PENDING;
  }
}

function toDeliveryStatus(status: SmsServiceStatus): SmsDeliveryStatus {
  switch (status) {
    case "SENT":
      return SmsDeliveryStatus.SENT;
    case "FAILED":
      return SmsDeliveryStatus.FAILED;
    case "DISABLED":
      return SmsDeliveryStatus.DISABLED;
    case "SKIPPED":
      return SmsDeliveryStatus.SKIPPED;
    default:
      return SmsDeliveryStatus.PENDING;
  }
}

function toJson(value: unknown): Prisma.InputJsonValue | null {
  if (value === null || value === undefined) return null;

  try {
    return JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;
  } catch {
    return { raw: String(value) };
  }
}

async function updateLog(
  id: string,
  status: SmsServiceStatus,
  payload: {
    provider?: string;
    providerMessageId?: string | null;
    providerResponse?: Prisma.InputJsonValue | null;
    errorMessage?: string | null;
  } = {},
) {
  const logStatus = toLogStatus(status);
  const sentAt = status === "SENT" ? new Date() : null;

  const log = await db.smsLog.update({
    where: { id },
    data: {
      status: logStatus,
      provider: payload.provider || getProvider(),
      providerMessageId: payload.providerMessageId || null,
      providerResponse: payload.providerResponse || undefined,
      errorMessage: payload.errorMessage || null,
      sentAt,
    },
  });

  return {
    log,
    result: {
      logId: log.id,
      status,
      deliveryStatus: toDeliveryStatus(status),
      logStatus,
      provider: log.provider,
      phone: log.phone,
      message: log.message,
      templateKey: log.templateKey || "",
      providerMessageId: log.providerMessageId,
      providerResponse: (log.providerResponse as Prisma.InputJsonValue | null) || null,
      errorMessage: log.errorMessage,
      sentAt: log.sentAt?.toISOString() || null,
    } satisfies SendTemplatedSmsResult,
  };
}

export async function sendTemplatedSms(
  input: SendTemplatedSmsInput,
): Promise<SendTemplatedSmsResult> {
  const phone = normalizePhone(input.phone);
  const provider = getProvider();

  const template = await db.smsTemplate.findUnique({
    where: { templateKey: input.templateKey },
  });

  if (!template) {
    const message = `Missing SMS template: ${input.templateKey}`;
    const log = await db.smsLog.create({
      data: {
        phone,
        message,
        provider,
        status: SmsLogStatus.FAILED,
        templateKey: input.templateKey,
        relatedFormType: input.relatedFormType,
        relatedRecordId: input.relatedRecordId,
        errorMessage: message,
      },
    });

    return {
      logId: log.id,
      status: "FAILED",
      deliveryStatus: SmsDeliveryStatus.FAILED,
      logStatus: SmsLogStatus.FAILED,
      provider,
      phone,
      message,
      templateKey: input.templateKey,
      errorMessage: message,
      sentAt: null,
    };
  }

  const message = renderTemplate(template.message, input.variables);

  const log = await db.smsLog.create({
    data: {
      phone,
      message,
      provider,
      status: SmsLogStatus.PENDING,
      templateKey: template.templateKey,
      relatedFormType: input.relatedFormType,
      relatedRecordId: input.relatedRecordId,
    },
  });

  if (!phone) {
    const { result } = await updateLog(log.id, "FAILED", {
      errorMessage: "Phone number is empty.",
    });
    return result;
  }

  if (!template.isActive) {
    const { result } = await updateLog(log.id, "SKIPPED", {
      errorMessage: "SMS template is inactive.",
    });
    return result;
  }

  if (!isSmsEnabled()) {
    const { result } = await updateLog(log.id, "DISABLED", {
      errorMessage: "SMS sending is disabled by SMS_ENABLED=false.",
    });
    return result;
  }

  const serviceUrl = getServiceUrl();

  if (!serviceUrl) {
    const { result } = await updateLog(log.id, "DISABLED", {
      errorMessage: "SMS_SERVICE_URL is not configured.",
    });
    return result;
  }

  try {
    const response = await fetch(`${serviceUrl}/send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(getServiceKey()
          ? {
              "X-SMS-Service-Key": getServiceKey(),
            }
          : {}),
      },
      body: JSON.stringify({
        phone,
        message,
        templateKey: template.templateKey,
        relatedFormType: input.relatedFormType,
        relatedRecordId: input.relatedRecordId,
        metadata: input.variables || {},
      }),
    });

    const data = (await response.json().catch(() => null)) as {
      status?: SmsServiceStatus;
      provider?: string;
      providerMessageId?: string | null;
      providerResponse?: unknown;
      errorMessage?: string | null;
    } | null;

    if (!response.ok) {
      const { result } = await updateLog(log.id, "FAILED", {
        provider,
        providerResponse: toJson(data),
        errorMessage: data?.errorMessage || `SMS service HTTP ${response.status}`,
      });
      return result;
    }

    const status = data?.status || "FAILED";

    const { result } = await updateLog(log.id, status, {
      provider: data?.provider || provider,
      providerMessageId: data?.providerMessageId || null,
      providerResponse: toJson(data?.providerResponse || data),
      errorMessage: data?.errorMessage || null,
    });

    return result;
  } catch (caught) {
    const { result } = await updateLog(log.id, "FAILED", {
      errorMessage:
        caught instanceof Error ? caught.message : "SMS service request failed.",
    });
    return result;
  }
}

export async function safeSendTemplatedSms(input: SendTemplatedSmsInput) {
  try {
    return await sendTemplatedSms(input);
  } catch (caught) {
    const message =
      caught instanceof Error ? caught.message : "SMS sending failed.";

    console.error("[sms] safeSendTemplatedSms failed:", message);

    return {
      status: "FAILED",
      deliveryStatus: SmsDeliveryStatus.FAILED,
      logStatus: SmsLogStatus.FAILED,
      provider: getProvider(),
      phone: normalizePhone(input.phone),
      message: "",
      templateKey: input.templateKey,
      errorMessage: message,
      sentAt: null,
    } satisfies SendTemplatedSmsResult;
  }
}
