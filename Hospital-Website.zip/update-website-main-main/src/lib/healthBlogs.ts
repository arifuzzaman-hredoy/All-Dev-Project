import { blogPosts as siteBlogPosts } from "@/data/site";

export type HealthBlogItem = {
  id: string;
  slug: string;
  title: string;
  date: string;
  category: string;
  image: string;
  excerpt: string;
  leadText: string;
  body: string[];
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export const HEALTH_BLOGS_STORAGE_KEY =
  "update-diagnostic-center-health-blogs";

const seededAt = "2026-06-12T00:00:00.000Z";

function toDateInput(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toISOString().slice(0, 10);
}

export const DEFAULT_HEALTH_BLOGS: HealthBlogItem[] = siteBlogPosts.map(
  (item, index) => ({
    id: item.slug,
    slug: item.slug,
    title: item.title,
    date: toDateInput(item.date),
    category: "Health Blog",
    image: item.image,
    excerpt: item.excerpt,
    leadText: item.excerpt,
    body: item.content,
    active: true,
    sortOrder: index + 1,
    createdAt: seededAt,
    updatedAt: seededAt,
  })
);

export function slugify(value: string) {
  return value.toLowerCase().trim().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

function normalizeItem(item: Partial<HealthBlogItem>, index: number) {
  const title = item.title || "Health Blog";
  const now = new Date().toISOString();
  return {
    id: item.id || slugify(item.slug || title) || `health-blog-${index + 1}`,
    slug: item.slug || slugify(title) || `health-blog-${index + 1}`,
    title,
    date: item.date || new Date().toISOString().slice(0, 10),
    category: item.category || "Health Blog",
    image: item.image || "/blogs/blog-1.jpg",
    excerpt: item.excerpt || "",
    leadText: item.leadText || item.excerpt || "",
    body: Array.isArray(item.body) ? item.body : [],
    active: item.active ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
    createdAt: item.createdAt || now,
    updatedAt: item.updatedAt || now,
  };
}

export function getHealthBlogsFromStorage(): HealthBlogItem[] {
  return DEFAULT_HEALTH_BLOGS;
}

export function getActiveHealthBlogs() {
  return getHealthBlogsFromStorage()
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

export function saveHealthBlogsToStorage(_items: HealthBlogItem[]) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event("health-blogs-updated"));
}

export function linesToParagraphs(value: string) {
  return value.split("\n").map((item) => item.trim()).filter(Boolean);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

export function formatBlogDate(value: string) {
  try {
    const date = new Date(value.includes("T") ? value : `${value}T00:00:00`);
    if (Number.isNaN(date.getTime())) return value;
    const day = String(date.getDate()).padStart(2, "0");
    const month = date.toLocaleString("en-US", { month: "long" }).toUpperCase();
    return `${day} ${month} ${date.getFullYear()}`;
  } catch {
    return value;
  }
}
