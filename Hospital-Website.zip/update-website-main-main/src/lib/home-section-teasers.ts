import "server-only";

import { prisma } from "@/lib/db";
import {
  DEFAULT_HOME_SECTION_TEASERS,
  HOME_SECTION_TEASERS_SETTING_KEY,
  type HomeSectionTeaserConfig,
  type HomeSectionTeaserKey,
  normalizeHomeSectionTeaser,
  normalizeHomeSectionTeasers,
} from "@/lib/home-section-teaser-types";

export async function getHomeSectionTeasers() {
  const row = await prisma.siteSetting.findUnique({
    where: { key: HOME_SECTION_TEASERS_SETTING_KEY },
  });

  return normalizeHomeSectionTeasers(row?.value);
}

export async function getHomeSectionTeaser(key: HomeSectionTeaserKey) {
  const teasers = await getHomeSectionTeasers();
  return teasers[key];
}

export async function saveHomeSectionTeaser(
  key: HomeSectionTeaserKey,
  payload: Partial<HomeSectionTeaserConfig>,
) {
  const current = await getHomeSectionTeasers();
  const nextValue = {
    ...current,
    [key]: normalizeHomeSectionTeaser(key, {
      ...current[key],
      ...payload,
      key,
    }),
  };

  await prisma.siteSetting.upsert({
    where: { key: HOME_SECTION_TEASERS_SETTING_KEY },
    update: { value: nextValue },
    create: { key: HOME_SECTION_TEASERS_SETTING_KEY, value: nextValue },
  });

  return nextValue[key];
}

export async function resetHomeSectionTeaser(key: HomeSectionTeaserKey) {
  return saveHomeSectionTeaser(key, DEFAULT_HOME_SECTION_TEASERS[key]);
}
