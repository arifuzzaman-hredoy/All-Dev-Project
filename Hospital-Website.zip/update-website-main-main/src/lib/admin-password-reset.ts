import "server-only";

import { createHash, randomBytes } from "crypto";
import { db } from "@/lib/db";
import { hashAdminPassword } from "@/lib/admin-password";
import { recordAuditLog } from "@/lib/audit-log";

const RESET_CODE_LENGTH = 6;
const RESET_CODE_TTL_MINUTES = 15;
const RESET_TOKEN_TTL_MINUTES = 20;
const MAX_VERIFY_ATTEMPTS = 5;

type ResetDeliveryResult = {
  delivered: boolean;
  mode: "webhook" | "screen" | "audit";
  devCode?: string;
  message: string;
};

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

function hashValue(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function createNumericCode() {
  const max = 10 ** RESET_CODE_LENGTH;
  const value = Number.parseInt(randomBytes(4).toString("hex"), 16) % max;
  return String(value).padStart(RESET_CODE_LENGTH, "0");
}

function getClientIp(request?: Request | null) {
  if (!request) return null;

  const forwardedFor = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const realIp = request.headers.get("x-real-ip")?.trim();
  const cfConnectingIp = request.headers.get("cf-connecting-ip")?.trim();

  return cfConnectingIp || realIp || forwardedFor || null;
}

function getUserAgent(request?: Request | null) {
  return request?.headers.get("user-agent") ?? null;
}

function shouldExposeResetCode() {
  return (
    process.env.ADMIN_RESET_SHOW_CODE === "true" ||
    (process.env.NODE_ENV !== "production" && process.env.ADMIN_RESET_SHOW_CODE !== "false")
  );
}

async function deliverResetCode(input: {
  email: string;
  code: string;
  request?: Request | null;
}): Promise<ResetDeliveryResult> {
  const webhookUrl = process.env.ADMIN_RESET_WEBHOOK_URL?.trim();
  const payload = {
    type: "ADMIN_PASSWORD_RESET_CODE",
    site: process.env.NEXT_PUBLIC_SITE_URL || "Update Diagnostic Center",
    email: input.email,
    code: input.code,
    expiresInMinutes: RESET_CODE_TTL_MINUTES,
  };

  if (webhookUrl) {
    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(process.env.ADMIN_RESET_WEBHOOK_SECRET
            ? { Authorization: `Bearer ${process.env.ADMIN_RESET_WEBHOOK_SECRET}` }
            : {}),
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        return {
          delivered: true,
          mode: "webhook",
          message: "Recovery code sent to the configured delivery service.",
        };
      }

      console.error("[admin-reset] Webhook delivery failed", response.status);
    } catch (error) {
      console.error("[admin-reset] Webhook delivery error", error);
    }
  }

  await recordAuditLog({
    action: "ADMIN_PASSWORD_RESET_CODE_CREATED",
    entity: "AdminPasswordResetToken",
    metadata: {
      email: input.email,
      delivery: webhookUrl ? "webhook_failed" : "no_delivery_webhook_configured",
      codeVisibleInAuditForEmergency: process.env.ADMIN_RESET_CODE_IN_AUDIT === "true" ? input.code : null,
    },
    request: input.request,
    adminId: null,
  });

  if (shouldExposeResetCode()) {
    return {
      delivered: true,
      mode: "screen",
      devCode: input.code,
      message: "Recovery code generated. Temporary screen delivery is enabled.",
    };
  }

  return {
    delivered: false,
    mode: "audit",
    message:
      "Recovery code generated. Configure ADMIN_RESET_WEBHOOK_URL or temporarily enable ADMIN_RESET_SHOW_CODE to deliver it.",
  };
}

export async function requestAdminPasswordReset(emailInput: string, request?: Request | null) {
  const email = normalizeEmail(emailInput);

  if (!email || !email.includes("@")) {
    return { ok: false, message: "Enter a valid admin email address." };
  }

  const admin = await db.adminUser.findUnique({
    where: { email },
    select: { id: true, email: true, isActive: true },
  });

  // Keep a generic response for unknown emails to reduce account discovery.
  if (!admin || !admin.isActive) {
    await recordAuditLog({
      action: "ADMIN_PASSWORD_RESET_REQUEST_UNKNOWN_EMAIL",
      entity: "AdminAuth",
      metadata: { email },
      request,
      adminId: null,
    });

    return {
      ok: true,
      message:
        "If this email is configured as an active admin, a recovery code will be generated.",
      deliveryMode: "none" as const,
    };
  }

  const code = createNumericCode();
  const expiresAt = new Date(Date.now() + RESET_CODE_TTL_MINUTES * 60 * 1000);

  await db.$transaction([
    db.adminPasswordResetToken.deleteMany({
      where: {
        adminId: admin.id,
        OR: [{ usedAt: { not: null } }, { expiresAt: { lte: new Date() } }],
      },
    }),
    db.adminPasswordResetToken.updateMany({
      where: {
        adminId: admin.id,
        usedAt: null,
        expiresAt: { gt: new Date() },
      },
      data: { usedAt: new Date() },
    }),
    db.adminPasswordResetToken.create({
      data: {
        adminId: admin.id,
        email: admin.email,
        codeHash: hashValue(code),
        expiresAt,
        requestIp: getClientIp(request),
        userAgent: getUserAgent(request),
      },
    }),
  ]);

  const delivery = await deliverResetCode({ email: admin.email, code, request });

  return {
    ok: true,
    message: delivery.message,
    deliveryMode: delivery.mode,
    devCode: delivery.devCode,
    expiresInMinutes: RESET_CODE_TTL_MINUTES,
  };
}

export async function verifyAdminPasswordResetCode(
  emailInput: string,
  codeInput: string,
  request?: Request | null,
) {
  const email = normalizeEmail(emailInput);
  const code = codeInput.trim();

  if (!email || !code) {
    return { ok: false, message: "Email and recovery code are required." };
  }

  const token = await db.adminPasswordResetToken.findFirst({
    where: {
      email,
      usedAt: null,
      expiresAt: { gt: new Date() },
    },
    orderBy: { createdAt: "desc" },
  });

  if (!token) {
    return { ok: false, message: "Recovery code expired or not found." };
  }

  if (token.attempts >= MAX_VERIFY_ATTEMPTS) {
    await db.adminPasswordResetToken.update({
      where: { id: token.id },
      data: { usedAt: new Date() },
    });

    return { ok: false, message: "Too many attempts. Request a new code." };
  }

  const codeOk = hashValue(code) === token.codeHash;

  if (!codeOk) {
    await db.adminPasswordResetToken.update({
      where: { id: token.id },
      data: { attempts: { increment: 1 } },
    });

    return { ok: false, message: "Invalid recovery code." };
  }

  const resetToken = randomBytes(32).toString("hex");
  const resetTokenHash = hashValue(resetToken);

  await db.adminPasswordResetToken.update({
    where: { id: token.id },
    data: {
      verifiedAt: new Date(),
      resetTokenHash,
      expiresAt: new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60 * 1000),
    },
  });

  await recordAuditLog({
    action: "ADMIN_PASSWORD_RESET_CODE_VERIFIED",
    entity: "AdminPasswordResetToken",
    entityId: token.id,
    metadata: { email },
    request,
    adminId: token.adminId,
  });

  return {
    ok: true,
    message: "Recovery code verified.",
    resetToken,
    expiresInMinutes: RESET_TOKEN_TTL_MINUTES,
  };
}

export async function completeAdminPasswordReset(input: {
  email: string;
  resetToken: string;
  password: string;
  request?: Request | null;
}) {
  const email = normalizeEmail(input.email);
  const resetToken = input.resetToken.trim();
  const password = input.password;

  if (!email || !resetToken || !password) {
    return { ok: false, message: "Reset token and new password are required." };
  }

  if (password.length < 12) {
    return { ok: false, message: "Password must be at least 12 characters." };
  }

  const token = await db.adminPasswordResetToken.findFirst({
    where: {
      email,
      resetTokenHash: hashValue(resetToken),
      verifiedAt: { not: null },
      usedAt: null,
      expiresAt: { gt: new Date() },
    },
    orderBy: { createdAt: "desc" },
  });

  if (!token) {
    return { ok: false, message: "Reset session expired or invalid." };
  }

  await db.$transaction([
    db.adminUser.update({
      where: { id: token.adminId },
      data: { passwordHash: hashAdminPassword(password) },
    }),
    db.adminSession.deleteMany({ where: { adminId: token.adminId } }),
    db.adminPasswordResetToken.update({
      where: { id: token.id },
      data: { usedAt: new Date() },
    }),
  ]);

  await recordAuditLog({
    action: "ADMIN_PASSWORD_RESET_COMPLETED",
    entity: "AdminUser",
    entityId: token.adminId,
    metadata: { email, sessionsCleared: true },
    request: input.request,
    adminId: token.adminId,
  });

  return { ok: true, message: "Admin password updated. Please login again." };
}
