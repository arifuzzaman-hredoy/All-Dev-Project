import { doctorArticles as siteDoctorArticles } from "@/data/site";

export type DoctorArticle = {
  id: string;
  slug: string;
  title: string;
  author: string;
  date: string;
  category: string;
  image: string;
  excerpt: string;
  leadText: string;
  body: string[];
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export const DOCTOR_ARTICLES_STORAGE_KEY =
  "update-diagnostic-center-doctor-articles";

const seededAt = "2026-06-12T00:00:00.000Z";

function toDateInput(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toISOString().slice(0, 10);
}

export const DEFAULT_DOCTOR_ARTICLES: DoctorArticle[] =
  siteDoctorArticles.map((item, index) => ({
    id: item.slug,
    slug: item.slug,
    title: item.title,
    author: item.doctor,
    date: toDateInput(item.date),
    category: "Doctor Article",
    image: item.image,
    excerpt: item.excerpt,
    leadText: item.excerpt,
    body: item.content,
    active: true,
    sortOrder: index + 1,
    createdAt: seededAt,
    updatedAt: seededAt,
  }));

export function slugify(value: string) {
  return value.toLowerCase().trim().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

function normalizeItem(item: Partial<DoctorArticle>, index: number) {
  const title = item.title || "Doctor Article";
  const now = new Date().toISOString();
  return {
    id: item.id || slugify(item.slug || title) || `doctor-article-${index + 1}`,
    slug: item.slug || slugify(title) || `doctor-article-${index + 1}`,
    title,
    author: item.author || "",
    date: item.date || new Date().toISOString().slice(0, 10),
    category: item.category || "Doctor Article",
    image: item.image || "/doctor-articles/doctor-1.jpg",
    excerpt: item.excerpt || "",
    leadText: item.leadText || item.excerpt || "",
    body: Array.isArray(item.body) ? item.body : [],
    active: item.active ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
    createdAt: item.createdAt || now,
    updatedAt: item.updatedAt || now,
  };
}

export function getDoctorArticlesFromStorage(): DoctorArticle[] {
  return DEFAULT_DOCTOR_ARTICLES;
}

export function getActiveDoctorArticles() {
  return getDoctorArticlesFromStorage()
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

export function saveDoctorArticlesToStorage(_items: DoctorArticle[]) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event("doctor-articles-updated"));
}

export function linesToParagraphs(value: string) {
  return value.split("\n").map((item) => item.trim()).filter(Boolean);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

export function formatArticleDate(value: string) {
  try {
    const date = new Date(value.includes("T") ? value : `${value}T00:00:00`);
    if (Number.isNaN(date.getTime())) return value;
    const day = String(date.getDate()).padStart(2, "0");
    const month = date.toLocaleString("en-US", { month: "long" }).toUpperCase();
    return `${day} ${month} ${date.getFullYear()}`;
  } catch {
    return value;
  }
}
