import { randomUUID } from "crypto";

import { Prisma } from "@prisma/client";

import { db } from "@/lib/db";
import type { DoctorProfile, DoctorProfileInput } from "@/types/doctor";

function parseExperienceYears(value: string | null | undefined) {
  if (!value) return 0;
  const match = value.match(/\d+/);
  return match ? Number(match[0]) : 0;
}

function splitTimeRange(value: string) {
  const text = value.trim();
  if (!text) return { startTime: "", endTime: "" };
  if (!text.includes("-")) return { startTime: text, endTime: text };

  const [startTime, ...rest] = text.split("-");
  return {
    startTime: startTime.trim(),
    endTime: rest.join("-").trim() || startTime.trim(),
  };
}

function joinTimeRange(startTime?: string | null, endTime?: string | null) {
  const start = String(startTime || "").trim();
  const end = String(endTime || "").trim();

  if (!start && !end) return "";
  if (!end || start === end) return start;
  return `${start} - ${end}`;
}

function sortDoctors(doctors: DoctorProfile[]) {
  return [...doctors].sort((left, right) => {
    const order = left.sortOrder - right.sortOrder;
    if (order !== 0) return order;

    return left.name.localeCompare(right.name);
  });
}

function mapDoctor(record: {
  id: string;
  name: string;
  designation: string | null;
  department: string | null;
  qualifications: string | null;
  experience: string | null;
  imageUrl: string | null;
  consultationFee: number | null;
  isActive: boolean;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
  schedules?: {
    day: string;
    startTime: string;
    endTime: string;
    room: string | null;
    sortOrder: number;
  }[];
}): DoctorProfile {
  const schedules = [...(record.schedules || [])].sort((left, right) => {
    const order = left.sortOrder - right.sortOrder;
    if (order !== 0) return order;
    return left.day.localeCompare(right.day);
  });
  const firstSchedule = schedules[0];

  return {
    id: record.id,
    name: record.name,
    designation: record.designation || "",
    department: record.department || "",
    specialist: record.qualifications || "",
    experienceYears: parseExperienceYears(record.experience),
    availableDays: schedules.map((schedule) => schedule.day).filter(Boolean),
    consultationTime: joinTimeRange(firstSchedule?.startTime, firstSchedule?.endTime),
    room: firstSchedule?.room || "",
    fee: record.consultationFee || 0,
    imageUrl: record.imageUrl || "",
    isActive: record.isActive,
    sortOrder: record.sortOrder,
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  };
}

function validateDoctorInput(input: DoctorProfileInput) {
  if (!input.name.trim()) throw new Error("Doctor name is required.");
  if (!input.department.trim()) throw new Error("Department is required.");
  if (!input.availableDays.length) {
    throw new Error("At least one available day is required.");
  }
  if (!Number.isFinite(input.fee) || input.fee < 0) {
    throw new Error("Fee must be a valid number.");
  }
  if (!Number.isFinite(input.experienceYears) || input.experienceYears < 0) {
    throw new Error("Experience must be a valid number.");
  }
}

function cleanInput(input: DoctorProfileInput) {
  validateDoctorInput(input);

  return {
    name: input.name.trim(),
    designation: input.designation.trim(),
    department: input.department.trim(),
    specialist: input.specialist.trim(),
    experienceYears: input.experienceYears,
    availableDays: input.availableDays.map((day) => day.trim()).filter(Boolean),
    consultationTime: input.consultationTime.trim(),
    room: input.room.trim(),
    fee: input.fee,
    imageUrl: input.imageUrl.trim(),
    isActive: input.isActive,
    sortOrder: input.sortOrder,
  } satisfies DoctorProfileInput;
}

async function replaceDoctorSchedules(
  tx: Prisma.TransactionClient,
  doctorId: string,
  input: DoctorProfileInput,
) {
  const { startTime, endTime } = splitTimeRange(input.consultationTime);

  await tx.doctorSchedule.deleteMany({ where: { doctorId } });

  if (!input.availableDays.length) return;

  await tx.doctorSchedule.createMany({
    data: input.availableDays.map((day, index) => ({
      doctorId,
      day,
      startTime: startTime || "N/A",
      endTime: endTime || startTime || "N/A",
      room: input.room || null,
      sortOrder: index,
      isActive: input.isActive,
    })),
  });
}

export async function getDoctors() {
  const doctors = await db.doctor.findMany({
    include: { schedules: { orderBy: { sortOrder: "asc" } } },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });

  return sortDoctors(doctors.map(mapDoctor));
}

export async function getActiveDoctors() {
  const doctors = await db.doctor.findMany({
    where: { isActive: true },
    include: { schedules: { where: { isActive: true }, orderBy: { sortOrder: "asc" } } },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });

  return sortDoctors(doctors.map(mapDoctor));
}

export async function getDoctor(id: string) {
  const doctor = await db.doctor.findUnique({
    where: { id },
    include: { schedules: { orderBy: { sortOrder: "asc" } } },
  });

  return doctor ? mapDoctor(doctor) : null;
}

export async function createDoctor(input: DoctorProfileInput) {
  const clean = cleanInput(input);
  const id = `dr-${randomUUID()}`;

  const doctor = await db.$transaction(async (tx) => {
    const created = await tx.doctor.create({
      data: {
        id,
        slug: id,
        name: clean.name,
        designation: clean.designation,
        department: clean.department,
        specialty: clean.department,
        qualifications: clean.specialist,
        experience: `${clean.experienceYears} years`,
        imageUrl: clean.imageUrl,
        consultationFee: clean.fee,
        isActive: clean.isActive,
        sortOrder: clean.sortOrder,
      },
    });

    await replaceDoctorSchedules(tx, created.id, clean);

    return tx.doctor.findUniqueOrThrow({
      where: { id: created.id },
      include: { schedules: { orderBy: { sortOrder: "asc" } } },
    });
  });

  return mapDoctor(doctor);
}

export async function updateDoctor(id: string, input: DoctorProfileInput) {
  const clean = cleanInput(input);

  const existing = await db.doctor.findUnique({ where: { id } });
  if (!existing) throw new Error("Doctor not found.");

  const doctor = await db.$transaction(async (tx) => {
    await tx.doctor.update({
      where: { id },
      data: {
        name: clean.name,
        designation: clean.designation,
        department: clean.department,
        specialty: clean.department,
        qualifications: clean.specialist,
        experience: `${clean.experienceYears} years`,
        imageUrl: clean.imageUrl,
        consultationFee: clean.fee,
        isActive: clean.isActive,
        sortOrder: clean.sortOrder,
      },
    });

    await replaceDoctorSchedules(tx, id, clean);

    return tx.doctor.findUniqueOrThrow({
      where: { id },
      include: { schedules: { orderBy: { sortOrder: "asc" } } },
    });
  });

  return mapDoctor(doctor);
}

export async function deleteDoctor(id: string) {
  await db.doctor.delete({ where: { id } });
}
