import {
  ExportEntityType,
  ExportFormat,
  type Prisma,
} from "@prisma/client";

import { db } from "@/lib/db";

type ExportEntity =
  | "appointments"
  | "form-submissions"
  | "package-bookings"
  | "sms-logs";

type ExportFormatKey = "csv" | "excel" | "html" | "print";

type ExportDataset = {
  entityType: ExportEntityType;
  title: string;
  headers: string[];
  rows: Record<string, unknown>[];
};

function formatDate(value: Date | string | null | undefined) {
  if (!value) return "";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toISOString();
}

function stringifyValue(value: unknown) {
  if (value === null || value === undefined) return "";
  if (value instanceof Date) return formatDate(value);
  if (Array.isArray(value)) return value.join(", ");
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

function csvCell(value: unknown) {
  const text = stringifyValue(value).replace(/\r?\n/g, " ");
  return `"${text.replaceAll('"', '""')}"`;
}

function htmlEscape(value: unknown) {
  return stringifyValue(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function normalizeEntity(value: string): ExportEntity {
  if (
    value === "appointments" ||
    value === "form-submissions" ||
    value === "package-bookings" ||
    value === "sms-logs"
  ) {
    return value;
  }

  throw new Error("Invalid export entity.");
}

function normalizeFormat(value: string | null): ExportFormatKey {
  if (value === "excel" || value === "html" || value === "print") return value;
  return "csv";
}

function toExportFormat(value: ExportFormatKey) {
  switch (value) {
    case "excel":
      return ExportFormat.XLSX;
    case "html":
      return ExportFormat.HTML;
    case "print":
      return ExportFormat.PRINT;
    default:
      return ExportFormat.CSV;
  }
}

function fileStamp() {
  return new Date().toISOString().slice(0, 19).replaceAll(":", "-");
}

function fileExtension(format: ExportFormatKey) {
  if (format === "excel") return "xls";
  if (format === "html" || format === "print") return "html";
  return "csv";
}

function createFileName(entity: ExportEntity, format: ExportFormatKey) {
  return `${entity}-${fileStamp()}.${fileExtension(format)}`;
}

function getRequestIp(request: Request) {
  const forwardedFor = request.headers.get("x-forwarded-for");
  if (forwardedFor) return forwardedFor.split(",")[0]?.trim() || "";
  return request.headers.get("x-real-ip") || "";
}

async function appointmentDataset(): Promise<ExportDataset> {
  const records = await db.appointment.findMany({
    orderBy: { createdAt: "desc" },
  });

  const headers = [
    "Token",
    "Patient Name",
    "Phone",
    "Email",
    "Age",
    "Gender",
    "Disease",
    "Department",
    "Doctor",
    "Appointment Time",
    "Room",
    "Fee",
    "Source",
    "SMS Status",
    "Created At",
  ];

  return {
    entityType: ExportEntityType.APPOINTMENTS,
    title: "Appointments Export",
    headers,
    rows: records.map((item) => ({
      Token: item.token || item.id,
      "Patient Name": item.patientName,
      Phone: item.patientPhone,
      Email: item.patientEmail || "",
      Age: item.patientAge || "",
      Gender: item.patientGender || "",
      Disease: item.disease || item.message || "",
      Department: item.serviceName || "",
      Doctor: item.doctorName || "",
      "Appointment Time": item.appointmentTime || "",
      Room: item.room || "",
      Fee: item.fee || 0,
      Source: item.source,
      "SMS Status": item.smsStatus,
      "Created At": formatDate(item.createdAt),
    })),
  };
}

async function formSubmissionsDataset(): Promise<ExportDataset> {
  const records = await db.formSubmission.findMany({
    orderBy: { createdAt: "desc" },
  });

  const headers = [
    "Form Type",
    "Name",
    "Phone",
    "Email",
    "Subject",
    "Message",
    "Status",
    "Source",
    "IP Address",
    "Created At",
  ];

  return {
    entityType: ExportEntityType.FORM_SUBMISSIONS,
    title: "Form Submissions Export",
    headers,
    rows: records.map((item) => ({
      "Form Type": item.formType,
      Name: item.name || "",
      Phone: item.phone || "",
      Email: item.email || "",
      Subject: item.subject || "",
      Message: item.message || "",
      Status: item.status,
      Source: item.source,
      "IP Address": item.ipAddress || "",
      "Created At": formatDate(item.createdAt),
    })),
  };
}

async function packageBookingsDataset(): Promise<ExportDataset> {
  const records = await db.packageBooking.findMany({
    orderBy: { createdAt: "desc" },
  });

  const headers = [
    "Token",
    "Receipt No",
    "Package",
    "Patient Name",
    "Phone",
    "Email",
    "Age",
    "Gender",
    "Problem",
    "Address",
    "Payment Method",
    "Payment Number",
    "Transaction ID",
    "Amount Paid",
    "Payment Status",
    "SMS Status",
    "Created At",
  ];

  return {
    entityType: ExportEntityType.PACKAGE_BOOKINGS,
    title: "Package Bookings Export",
    headers,
    rows: records.map((item) => ({
      Token: item.token || "",
      "Receipt No": item.receiptNo || "",
      Package: item.packageName || "",
      "Patient Name": item.patientName,
      Phone: item.phone,
      Email: item.email || "",
      Age: item.age || "",
      Gender: item.gender || "",
      Problem: item.diseaseProblem || item.message || "",
      Address: item.address || "",
      "Payment Method": item.paymentMethod || "",
      "Payment Number": item.paymentNumber || "",
      "Transaction ID": item.transactionId || "",
      "Amount Paid": item.amountPaid || "",
      "Payment Status": item.paymentStatus || "",
      "SMS Status": item.smsStatus,
      "Created At": formatDate(item.createdAt),
    })),
  };
}

async function smsLogsDataset(): Promise<ExportDataset> {
  const records = await db.smsLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 2000,
  });

  const headers = [
    "Phone",
    "Template Key",
    "Message",
    "Provider",
    "Status",
    "Retry Count",
    "Related Type",
    "Related ID",
    "Provider Message ID",
    "Error",
    "Sent At",
    "Created At",
  ];

  return {
    entityType: ExportEntityType.SMS_LOGS,
    title: "SMS Logs Export",
    headers,
    rows: records.map((item) => ({
      Phone: item.phone,
      "Template Key": item.templateKey || "",
      Message: item.message,
      Provider: item.provider,
      Status: item.status,
      "Retry Count": item.retryCount,
      "Related Type": item.relatedFormType || "",
      "Related ID": item.relatedRecordId || "",
      "Provider Message ID": item.providerMessageId || "",
      Error: item.errorMessage || "",
      "Sent At": formatDate(item.sentAt),
      "Created At": formatDate(item.createdAt),
    })),
  };
}

export async function getExportDataset(entity: ExportEntity) {
  switch (entity) {
    case "appointments":
      return appointmentDataset();
    case "form-submissions":
      return formSubmissionsDataset();
    case "package-bookings":
      return packageBookingsDataset();
    case "sms-logs":
      return smsLogsDataset();
    default:
      throw new Error("Invalid export entity.");
  }
}

function toCsv(dataset: ExportDataset) {
  const headerLine = dataset.headers.map(csvCell).join(",");
  const lines = dataset.rows.map((row) =>
    dataset.headers.map((header) => csvCell(row[header])).join(","),
  );

  return `\uFEFF${[headerLine, ...lines].join("\r\n")}`;
}

function toHtml(dataset: ExportDataset, printable = false) {
  const rows = dataset.rows
    .map(
      (row) => `
        <tr>
          ${dataset.headers
            .map((header) => `<td>${htmlEscape(row[header])}</td>`)
            .join("")}
        </tr>`,
    )
    .join("");

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${htmlEscape(dataset.title)}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; color: #0f172a; }
    .top { display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; margin-bottom: 18px; }
    h1 { margin: 0; color: #062f66; font-size: 24px; }
    p { margin: 6px 0 0; color: #475569; font-size: 13px; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th { background: #eaf7ff; color: #062f66; text-align: left; }
    th, td { border: 1px solid #dbe8ff; padding: 8px; vertical-align: top; }
    tr:nth-child(even) td { background: #f8fbff; }
    .print-btn { border: 0; background: #43c7f4; color: white; padding: 10px 16px; border-radius: 999px; font-weight: 800; cursor: pointer; }
    @media print {
      .print-btn { display: none; }
      body { margin: 10mm; }
      table { font-size: 10px; }
    }
  </style>
</head>
<body>
  <div class="top">
    <div>
      <h1>${htmlEscape(dataset.title)}</h1>
      <p>Total rows: ${dataset.rows.length}</p>
      <p>Generated at: ${formatDate(new Date())}</p>
    </div>
    ${printable ? `<button class="print-btn" onclick="window.print()">Print / Save PDF</button>` : ""}
  </div>

  <table>
    <thead>
      <tr>${dataset.headers.map((header) => `<th>${htmlEscape(header)}</th>`).join("")}</tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
</body>
</html>`;
}

export async function createExportResponse(
  request: Request,
  entityParam: string,
) {
  const url = new URL(request.url);
  const entity = normalizeEntity(entityParam);
  const format = normalizeFormat(url.searchParams.get("format"));
  const dataset = await getExportDataset(entity);
  const fileName = createFileName(entity, format);

  await db.exportAudit.create({
    data: {
      entityType: dataset.entityType,
      format: toExportFormat(format),
      filters: {
        entity,
        format,
      } as Prisma.InputJsonValue,
      totalRows: dataset.rows.length,
      fileName,
      ipAddress: getRequestIp(request) || null,
      userAgent: request.headers.get("user-agent") || null,
    },
  });

  if (format === "excel") {
    return new Response(toHtml(dataset), {
      headers: {
        "Content-Type": "application/vnd.ms-excel; charset=utf-8",
        "Content-Disposition": `attachment; filename="${fileName}"`,
        "Cache-Control": "no-store",
      },
    });
  }

  if (format === "html" || format === "print") {
    return new Response(toHtml(dataset, true), {
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Content-Disposition": `inline; filename="${fileName}"`,
        "Cache-Control": "no-store",
      },
    });
  }

  return new Response(toCsv(dataset), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}
