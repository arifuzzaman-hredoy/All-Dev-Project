import type { PublishStatus } from "@prisma/client";
import "server-only";
import { db } from "@/lib/db";
import {
  DEFAULT_HEALTH_BLOGS,
  type HealthBlogItem,
  slugify as blogSlugify,
} from "@/lib/healthBlogs";
import {
  DEFAULT_NEWS_MEDIA,
  type NewsMediaItem,
  slugify as newsSlugify,
} from "@/lib/newsMedia";
import {
  DEFAULT_DOCTOR_ARTICLES,
  type DoctorArticle,
  slugify as articleSlugify,
} from "@/lib/doctorArticles";

export type ContentKind = "blogs" | "news-media" | "doctor-articles";
export type ContentItem = HealthBlogItem | NewsMediaItem | DoctorArticle;

type ContentPayload = Partial<ContentItem> & {
  body?: string[];
  author?: string;
};

const KIND_DEFAULTS: Record<ContentKind, ContentItem[]> = {
  blogs: DEFAULT_HEALTH_BLOGS,
  "news-media": DEFAULT_NEWS_MEDIA,
  "doctor-articles": DEFAULT_DOCTOR_ARTICLES,
};

const KIND_META: Record<
  ContentKind,
  { defaultCategory: string; defaultImage: string; slugify: (value: string) => string }
> = {
  blogs: {
    defaultCategory: "Health Blog",
    defaultImage: "/blogs/blog-1.jpg",
    slugify: blogSlugify,
  },
  "news-media": {
    defaultCategory: "Media Update",
    defaultImage: "/news/news-1.jpg",
    slugify: newsSlugify,
  },
  "doctor-articles": {
    defaultCategory: "Doctor Article",
    defaultImage: "/doctor-articles/doctor-1.jpg",
    slugify: articleSlugify,
  },
};

export function isContentKind(value: string): value is ContentKind {
  return value === "blogs" || value === "news-media" || value === "doctor-articles";
}

function toIso(value: Date | string | null | undefined) {
  if (!value) return new Date().toISOString();
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
}

function toDateInput(value: Date | string | null | undefined) {
  if (!value) return new Date().toISOString().slice(0, 10);
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? String(value).slice(0, 10) : date.toISOString().slice(0, 10);
}

function toPublishedAt(value: unknown) {
  const text = String(value || "").trim();
  if (!text) return null;
  const date = new Date(text.includes("T") ? text : `${text}T00:00:00`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function bodyFromJson(value: unknown, fallback?: string | null) {
  if (Array.isArray(value)) {
    return value.map((item) => String(item).trim()).filter(Boolean);
  }

  if (typeof value === "string") {
    return value.split("\n").map((item) => item.trim()).filter(Boolean);
  }

  if (fallback) {
    return String(fallback)
      .split(/\n{2,}|\n/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return [];
}

function normalizePayload(kind: ContentKind, payload: ContentPayload) {
  const meta = KIND_META[kind];
  const title = String(payload.title || "Untitled").trim();
  const slug = meta.slugify(String(payload.slug || title)) || `${kind}-${Date.now()}`;
  const body = Array.isArray(payload.body)
    ? payload.body.map((item) => String(item).trim()).filter(Boolean)
    : [];

  return {
    id: payload.id ? String(payload.id) : undefined,
    slug,
    title,
    category: String(payload.category || meta.defaultCategory).trim() || meta.defaultCategory,
    imageUrl: String(payload.image || meta.defaultImage).trim() || meta.defaultImage,
    excerpt: String(payload.excerpt || "").trim(),
    leadText: String(payload.leadText || payload.excerpt || "").trim(),
    body,
    content: body.join("\n\n"),
    status: payload.active === false ? "DRAFT" : "PUBLISHED",
    sortOrder: Number(payload.sortOrder) || 0,
    dateText: String(payload.date || new Date().toISOString().slice(0, 10)),
    publishedAt: toPublishedAt(payload.date),
    author: String(payload.author || "").trim(),
  };
}

function mapBlog(row: Awaited<ReturnType<typeof db.blog.findMany>>[number]): HealthBlogItem {
  const body = bodyFromJson(row.body, row.content);
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    date: row.dateText || toDateInput(row.publishedAt),
    category: row.category || "Health Blog",
    image: row.imageUrl || "/blogs/blog-1.jpg",
    excerpt: row.excerpt || "",
    leadText: row.leadText || row.excerpt || "",
    body,
    active: row.status === "PUBLISHED",
    sortOrder: row.sortOrder || 0,
    createdAt: toIso(row.createdAt),
    updatedAt: toIso(row.updatedAt),
  };
}

function mapNews(row: Awaited<ReturnType<typeof db.newsMedia.findMany>>[number]): NewsMediaItem {
  const body = bodyFromJson(row.body, row.content);
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    date: row.dateText || toDateInput(row.publishedAt),
    category: row.category || "Media Update",
    image: row.imageUrl || "/news/news-1.jpg",
    excerpt: row.excerpt || "",
    leadText: row.leadText || row.excerpt || "",
    body,
    active: row.status === "PUBLISHED",
    sortOrder: row.sortOrder || 0,
    createdAt: toIso(row.createdAt),
    updatedAt: toIso(row.updatedAt),
  };
}

function mapDoctorArticle(
  row: Awaited<ReturnType<typeof db.doctorArticle.findMany>>[number]
): DoctorArticle {
  const body = bodyFromJson(row.body, row.content);
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    author: row.doctorName || "",
    date: row.dateText || toDateInput(row.publishedAt),
    category: row.category || "Doctor Article",
    image: row.imageUrl || "/doctor-articles/doctor-1.jpg",
    excerpt: row.excerpt || "",
    leadText: row.leadText || row.excerpt || "",
    body,
    active: row.status === "PUBLISHED",
    sortOrder: row.sortOrder || 0,
    createdAt: toIso(row.createdAt),
    updatedAt: toIso(row.updatedAt),
  };
}

export async function getContentItems(kind: ContentKind, publishedOnly = false) {
  const where = publishedOnly ? { status: "PUBLISHED" as const } : undefined;
  const orderBy = [{ sortOrder: "asc" as const }, { createdAt: "asc" as const }];

  if (kind === "blogs") {
    const rows = await db.blog.findMany({ where, orderBy });
    return rows.map(mapBlog);
  }

  if (kind === "news-media") {
    const rows = await db.newsMedia.findMany({ where, orderBy });
    return rows.map(mapNews);
  }

  const rows = await db.doctorArticle.findMany({ where, orderBy });
  return rows.map(mapDoctorArticle);
}

export async function getContentItemBySlug(kind: ContentKind, slug: string, publishedOnly = false) {
  const where = publishedOnly ? { slug, status: "PUBLISHED" as const } : { slug };

  if (kind === "blogs") {
    const row = await db.blog.findFirst({ where });
    return row ? mapBlog(row) : null;
  }

  if (kind === "news-media") {
    const row = await db.newsMedia.findFirst({ where });
    return row ? mapNews(row) : null;
  }

  const row = await db.doctorArticle.findFirst({ where });
  return row ? mapDoctorArticle(row) : null;
}

export async function createContentItem(kind: ContentKind, payload: ContentPayload) {
  const data = normalizePayload(kind, payload);

  if (kind === "blogs") {
    const row = await db.blog.create({
      data: {
        ...(data.id ? { id: data.id } : {}),
        slug: data.slug,
        title: data.title,
        category: data.category,
        imageUrl: data.imageUrl,
        excerpt: data.excerpt,
        leadText: data.leadText,
        body: data.body,
        content: data.content,
        status: data.status as PublishStatus,
        sortOrder: data.sortOrder,
        dateText: data.dateText,
        publishedAt: data.publishedAt,
      },
    });
    return mapBlog(row);
  }

  if (kind === "news-media") {
    const row = await db.newsMedia.create({
      data: {
        ...(data.id ? { id: data.id } : {}),
        slug: data.slug,
        title: data.title,
        category: data.category,
        imageUrl: data.imageUrl,
        excerpt: data.excerpt,
        leadText: data.leadText,
        body: data.body,
        content: data.content,
        status: data.status as PublishStatus,
        sortOrder: data.sortOrder,
        dateText: data.dateText,
        publishedAt: data.publishedAt,
      },
    });
    return mapNews(row);
  }

  const row = await db.doctorArticle.create({
    data: {
      ...(data.id ? { id: data.id } : {}),
      slug: data.slug,
      title: data.title,
      category: data.category,
      imageUrl: data.imageUrl,
      excerpt: data.excerpt,
      leadText: data.leadText,
      body: data.body,
      content: data.content,
      doctorName: data.author,
      status: data.status as PublishStatus,
      sortOrder: data.sortOrder,
      dateText: data.dateText,
      publishedAt: data.publishedAt,
    },
  });
  return mapDoctorArticle(row);
}

export async function updateContentItem(kind: ContentKind, id: string, payload: ContentPayload) {
  const data = normalizePayload(kind, { ...payload, id });

  if (kind === "blogs") {
    const row = await db.blog.update({
      where: { id },
      data: {
        slug: data.slug,
        title: data.title,
        category: data.category,
        imageUrl: data.imageUrl,
        excerpt: data.excerpt,
        leadText: data.leadText,
        body: data.body,
        content: data.content,
        status: data.status as PublishStatus,
        sortOrder: data.sortOrder,
        dateText: data.dateText,
        publishedAt: data.publishedAt,
      },
    });
    return mapBlog(row);
  }

  if (kind === "news-media") {
    const row = await db.newsMedia.update({
      where: { id },
      data: {
        slug: data.slug,
        title: data.title,
        category: data.category,
        imageUrl: data.imageUrl,
        excerpt: data.excerpt,
        leadText: data.leadText,
        body: data.body,
        content: data.content,
        status: data.status as PublishStatus,
        sortOrder: data.sortOrder,
        dateText: data.dateText,
        publishedAt: data.publishedAt,
      },
    });
    return mapNews(row);
  }

  const row = await db.doctorArticle.update({
    where: { id },
    data: {
      slug: data.slug,
      title: data.title,
      category: data.category,
      imageUrl: data.imageUrl,
      excerpt: data.excerpt,
      leadText: data.leadText,
      body: data.body,
      content: data.content,
      doctorName: data.author,
      status: data.status as PublishStatus,
      sortOrder: data.sortOrder,
      dateText: data.dateText,
      publishedAt: data.publishedAt,
    },
  });
  return mapDoctorArticle(row);
}

export async function deleteContentItem(kind: ContentKind, id: string) {
  if (kind === "blogs") return db.blog.delete({ where: { id } });
  if (kind === "news-media") return db.newsMedia.delete({ where: { id } });
  return db.doctorArticle.delete({ where: { id } });
}

export async function resetContentItems(kind: ContentKind) {
  const defaults = KIND_DEFAULTS[kind];

  if (kind === "blogs") await db.blog.deleteMany();
  if (kind === "news-media") await db.newsMedia.deleteMany();
  if (kind === "doctor-articles") await db.doctorArticle.deleteMany();

  for (const item of defaults) {
    await createContentItem(kind, item);
  }

  return getContentItems(kind, false);
}
