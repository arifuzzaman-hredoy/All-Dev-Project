import {
  FormSubmissionStatus,
  FormSubmissionType,
  SubmissionSource,
  type FormSubmission as DbFormSubmission,
  type Prisma,
} from "@prisma/client";

import { db } from "@/lib/db";

export type AdminFormSubmission = {
  id: string;
  formType: FormSubmissionType;
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
  payload: Prisma.JsonValue;
  status: FormSubmissionStatus;
  source: SubmissionSource;
  ipAddress: string;
  userAgent: string;
  createdAt: string;
  updatedAt: string;
};

export type CreateFormSubmissionInput = {
  formType: FormSubmissionType;
  name?: string | null;
  phone?: string | null;
  email?: string | null;
  subject?: string | null;
  message?: string | null;
  payload: Prisma.InputJsonValue;
  status?: FormSubmissionStatus;
  source?: SubmissionSource;
  ipAddress?: string | null;
  userAgent?: string | null;
};

function cleanText(value: string | null | undefined) {
  return typeof value === "string" ? value.trim() : "";
}

export function toAdminFormSubmission(
  record: DbFormSubmission
): AdminFormSubmission {
  return {
    id: record.id,
    formType: record.formType,
    name: record.name || "",
    phone: record.phone || "",
    email: record.email || "",
    subject: record.subject || "",
    message: record.message || "",
    payload: record.payload,
    status: record.status,
    source: record.source,
    ipAddress: record.ipAddress || "",
    userAgent: record.userAgent || "",
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  };
}

export async function createFormSubmission(input: CreateFormSubmissionInput) {
  const submission = await db.formSubmission.create({
    data: {
      formType: input.formType,
      name: cleanText(input.name) || null,
      phone: cleanText(input.phone) || null,
      email: cleanText(input.email) || null,
      subject: cleanText(input.subject) || null,
      message: cleanText(input.message) || null,
      payload: input.payload,
      status: input.status || FormSubmissionStatus.NEW,
      source: input.source || SubmissionSource.PUBLIC_FORM,
      ipAddress: cleanText(input.ipAddress) || null,
      userAgent: cleanText(input.userAgent) || null,
    },
  });

  return toAdminFormSubmission(submission);
}

export async function safeCreateFormSubmission(
  input: CreateFormSubmissionInput
) {
  try {
    return await createFormSubmission(input);
  } catch (error) {
    console.error("[form-submissions] Failed to save submission mirror", error);
    return null;
  }
}

export async function getAdminFormSubmissions() {
  const submissions = await db.formSubmission.findMany({
    orderBy: { createdAt: "desc" },
    take: 800,
  });

  return submissions.map(toAdminFormSubmission);
}

export async function updateFormSubmissionStatus(
  id: string,
  status: FormSubmissionStatus
) {
  const submission = await db.formSubmission.update({
    where: { id },
    data: { status },
  });

  return toAdminFormSubmission(submission);
}

export async function archiveFormSubmission(id: string) {
  return updateFormSubmissionStatus(id, FormSubmissionStatus.ARCHIVED);
}
