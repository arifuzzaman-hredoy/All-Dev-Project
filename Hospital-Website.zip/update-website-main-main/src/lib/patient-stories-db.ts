import "server-only";
import type { PublishStatus } from "@prisma/client";
import { db } from "@/lib/db";
import {
  DEFAULT_PATIENT_STORIES,
  type PatientStory,
  slugify,
} from "@/lib/patientStories";

function toStatus(active: boolean): PublishStatus {
  return active ? "PUBLISHED" : "DRAFT";
}

function toDate(value?: string | null) {
  if (!value) return null;
  const date = new Date(value.includes("T") ? value : `${value}T00:00:00.000Z`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function bodyToArray(value: unknown, fallback?: string | null): string[] {
  if (Array.isArray(value)) return value.map(String).filter(Boolean);
  if (typeof fallback === "string" && fallback.trim()) {
    return fallback
      .split("\n")
      .map((item) => item.trim())
      .filter(Boolean);
  }
  return [];
}

function toPatientStory(row: {
  id: string;
  slug: string;
  patientName: string;
  title: string;
  story: string | null;
  excerpt: string | null;
  leadText: string | null;
  body: unknown;
  imageUrl: string | null;
  dateText: string | null;
  sortOrder: number;
  status: PublishStatus;
  publishedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}): PatientStory {
  const body = bodyToArray(row.body, row.story);
  const date = row.dateText || row.publishedAt?.toISOString().slice(0, 10) || row.createdAt.toISOString().slice(0, 10);
  const excerpt = row.excerpt || row.story || body[0] || "";

  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    date,
    image: row.imageUrl || "/slider1.jpeg",
    excerpt,
    leadText: row.leadText || excerpt,
    body,
    active: row.status === "PUBLISHED",
    sortOrder: row.sortOrder || 10,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function listPatientStories({ admin = false } = {}) {
  const rows = await db.patientStory.findMany({
    where: admin ? undefined : { status: "PUBLISHED" },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });

  if (!rows.length) {
    return admin ? DEFAULT_PATIENT_STORIES : DEFAULT_PATIENT_STORIES.filter((item) => item.active);
  }

  return rows.map(toPatientStory);
}

export async function getPatientStoryBySlug(slug: string, { admin = false } = {}) {
  const row = await db.patientStory.findUnique({ where: { slug } });
  if (!row || (!admin && row.status !== "PUBLISHED")) {
    return DEFAULT_PATIENT_STORIES.find((item) => item.slug === slug && (admin || item.active)) || null;
  }
  return toPatientStory(row);
}

export async function replacePatientStories(stories: PatientStory[]) {
  await db.$transaction(async (tx) => {
    await tx.patientStory.deleteMany();

    for (const [index, item] of stories.entries()) {
      const slug = slugify(item.slug || item.title) || `patient-story-${index + 1}`;
      await tx.patientStory.create({
        data: {
          id: item.id || undefined,
          slug,
          patientName: item.title,
          title: item.title,
          story: item.body.join("\n\n"),
          excerpt: item.excerpt,
          leadText: item.leadText,
          body: item.body,
          imageUrl: item.image,
          dateText: item.date,
          sortOrder: Number(item.sortOrder) || index + 1,
          status: toStatus(item.active),
          publishedAt: item.active ? toDate(item.date) : null,
        },
      });
    }
  });

  return listPatientStories({ admin: true });
}

export async function resetPatientStories() {
  return replacePatientStories(DEFAULT_PATIENT_STORIES);
}
