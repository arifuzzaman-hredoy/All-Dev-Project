type EnvCheckOptions = {
  requireDatabase?: boolean;
  requireAdmin?: boolean;
  requireSiteUrl?: boolean;
};

const envErrors = new Set<string>();
const WEAK_ADMIN_PASSWORDS = new Set([
  "admin",
  "admin123",
  "admin12345",
  "password",
  "password123",
  "123456",
  "12345678",
  "change-me",
  "change-me-to-a-strong-12-plus-character-password",
]);

function isProduction() {
  return process.env.NODE_ENV === "production";
}

function getEnv(name: string) {
  return String(process.env[name] || "").trim();
}

function pushMissing(name: string) {
  if (!getEnv(name)) {
    envErrors.add(`${name} is required.`);
  }
}

function pushInvalidEmail() {
  const email = getEnv("ADMIN_EMAIL");

  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    envErrors.add("ADMIN_EMAIL must be a valid email address.");
  }
}

function pushWeakAdminPassword() {
  const password = getEnv("ADMIN_PASSWORD");

  if (!password) return;

  if (isProduction() && password.length < 12) {
    envErrors.add("ADMIN_PASSWORD must be at least 12 characters in production.");
  }

  if (isProduction() && WEAK_ADMIN_PASSWORDS.has(password.toLowerCase())) {
    envErrors.add("ADMIN_PASSWORD is still a default/weak value. Change it before production.");
  }
}

function pushWeakSessionSecret() {
  const secret = getEnv("ADMIN_SESSION_SECRET");
  const minLength = isProduction() ? 64 : 32;

  if (!secret) return;

  if (secret.length < minLength) {
    envErrors.add(`ADMIN_SESSION_SECRET must be at least ${minLength} characters${isProduction() ? " in production" : ""}.`);
  }

  if (isProduction() && /change-me|secret|password|123456/i.test(secret)) {
    envErrors.add("ADMIN_SESSION_SECRET looks like a placeholder. Generate a random production secret.");
  }
}

function pushUnsafeDatabaseUrl() {
  const databaseUrl = getEnv("DATABASE_URL");

  if (!databaseUrl || !isProduction()) return;

  if (!databaseUrl.startsWith("postgresql://") && !databaseUrl.startsWith("postgres://")) {
    envErrors.add("DATABASE_URL must be a PostgreSQL connection string in production.");
  }

  if (/USER:PASSWORD|HOST:5432|DATABASE|example/i.test(databaseUrl)) {
    envErrors.add("DATABASE_URL still contains placeholder values.");
  }
}

function pushUnsafeSiteUrl() {
  const siteUrl = getEnv("NEXT_PUBLIC_SITE_URL");

  if (!siteUrl || !isProduction()) return;

  if (!siteUrl.startsWith("https://")) {
    envErrors.add("NEXT_PUBLIC_SITE_URL must use https:// in production.");
  }

  if (/localhost|127\.0\.0\.1|0\.0\.0\.0/i.test(siteUrl)) {
    envErrors.add("NEXT_PUBLIC_SITE_URL must not point to localhost in production.");
  }
}

export function validateServerEnv(options: EnvCheckOptions = {}) {
  envErrors.clear();

  if (options.requireDatabase) {
    pushMissing("DATABASE_URL");
    pushUnsafeDatabaseUrl();
  }

  if (options.requireSiteUrl || isProduction()) {
    pushMissing("NEXT_PUBLIC_SITE_URL");
    pushUnsafeSiteUrl();
  }

  if (options.requireAdmin) {
    pushMissing("ADMIN_EMAIL");
    pushMissing("ADMIN_PASSWORD");
    pushMissing("ADMIN_SESSION_SECRET");
    pushInvalidEmail();
    pushWeakAdminPassword();
    pushWeakSessionSecret();
  }

  if (envErrors.size > 0) {
    throw new Error(`Environment configuration error: ${Array.from(envErrors).join(" ")}`);
  }
}

export function getAdminCookieName() {
  return "update-diagnostic-admin";
}
