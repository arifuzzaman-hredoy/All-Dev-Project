import { FormSubmissionType, SubmissionSource } from "@prisma/client";

import { db } from "@/lib/db";
import { safeCreateFormSubmission } from "@/lib/form-submissions";
import {
  sendAppointmentReceivedSms,
  sendManualAppointmentCreatedSms,
} from "@/lib/sms-workflows";
import type {
  AppointmentRecord,
  AppointmentSubmissionInput,
  ManualAppointmentInput,
} from "@/types/appointment";

function createAppointmentToken(submittedAt: string) {
  const date = new Date(submittedAt);
  const datePart = date.toISOString().slice(2, 10).replaceAll("-", "");
  const timePart = String(date.getTime()).slice(-6);

  return `APT-${datePart}-${timePart}`;
}

function validateAppointmentInput(input: AppointmentSubmissionInput) {
  const requiredValues = [
    input.patientName,
    input.phone,
    input.age,
    input.gender,
    input.disease,
    input.doctorId,
    input.department,
    input.doctorName,
    input.appointmentTime,
    input.room,
  ];

  return (
    requiredValues.every((value) => typeof value === "string" && value.trim()) &&
    Array.isArray(input.doctorAvailableDays) &&
    input.doctorAvailableDays.length > 0 &&
    Number.isFinite(input.fee)
  );
}

function validateManualAppointmentInput(input: ManualAppointmentInput) {
  const requiredValues = [
    input.patientName,
    input.phone,
    input.disease,
    input.department,
    input.appointmentTime,
  ];

  return (
    requiredValues.every((value) => typeof value === "string" && value.trim()) &&
    Array.isArray(input.doctorAvailableDays) &&
    Number.isFinite(input.fee)
  );
}

function parseJsonStringArray(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value.map(String).filter(Boolean);
}

function cleanString(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function cleanManualSource(value: unknown) {
  return value === "ADMIN_MANUAL"
    ? SubmissionSource.ADMIN_MANUAL
    : SubmissionSource.PHONE_CALL;
}

function mapAppointment(record: {
  id: string;
  token: string | null;
  patientName: string;
  patientPhone: string;
  patientEmail?: string | null;
  patientAge: string | null;
  patientGender: string | null;
  disease: string | null;
  message: string | null;
  doctorId: string | null;
  serviceName: string | null;
  doctorName: string | null;
  doctorDesignation: string | null;
  specialist: string | null;
  doctorAvailableDays: unknown;
  appointmentTime: string | null;
  room: string | null;
  fee: number | null;
  source?: string | null;
  smsStatus?: string | null;
  createdAt: Date;
  doctor?: {
    name: string;
    designation: string | null;
    department: string | null;
    qualifications: string | null;
    consultationFee: number | null;
    schedules?: {
      day: string;
      startTime: string;
      endTime: string;
      room: string | null;
    }[];
  } | null;
}): AppointmentRecord {
  const firstSchedule = record.doctor?.schedules?.[0];
  const appointmentTime =
    record.appointmentTime ||
    (firstSchedule
      ? firstSchedule.startTime === firstSchedule.endTime
        ? firstSchedule.startTime
        : `${firstSchedule.startTime} - ${firstSchedule.endTime}`
      : "");

  return {
    id: record.id,
    token: record.token || record.id,
    patientName: record.patientName,
    phone: record.patientPhone,
    patientEmail: record.patientEmail || "",
    age: record.patientAge || "",
    gender: record.patientGender || "",
    disease: record.disease || record.message || "",
    doctorId: record.doctorId || "",
    department: record.serviceName || record.doctor?.department || "",
    doctorName: record.doctorName || record.doctor?.name || "",
    doctorDesignation:
      record.doctorDesignation || record.doctor?.designation || "",
    specialist: record.specialist || record.doctor?.qualifications || "",
    doctorAvailableDays:
      parseJsonStringArray(record.doctorAvailableDays).length > 0
        ? parseJsonStringArray(record.doctorAvailableDays)
        : record.doctor?.schedules?.map((schedule) => schedule.day) || [],
    appointmentTime,
    room: record.room || firstSchedule?.room || "",
    fee: record.fee || record.doctor?.consultationFee || 0,
    source: record.source || "",
    smsStatus: record.smsStatus || "",
    submittedAt: record.createdAt.toISOString(),
  };
}

export async function getAppointments() {
  const appointments = await db.appointment.findMany({
    include: {
      doctor: {
        include: {
          schedules: {
            where: { isActive: true },
            orderBy: { sortOrder: "asc" },
          },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  return appointments.map(mapAppointment);
}

export async function createAppointment(input: AppointmentSubmissionInput) {
  if (!validateAppointmentInput(input)) {
    throw new Error("Appointment information is incomplete.");
  }

  const submittedAt = new Date();
  const token = createAppointmentToken(submittedAt.toISOString());
  const doctor = await db.doctor.findUnique({ where: { id: input.doctorId } });

  if (!doctor) {
    throw new Error("Selected doctor was not found.");
  }

  const appointment = await db.appointment.create({
    data: {
      id: token,
      token,
      patientName: input.patientName.trim(),
      patientPhone: input.phone.trim(),
      patientAge: input.age.trim(),
      patientGender: input.gender.trim(),
      disease: input.disease.trim(),
      message: input.disease.trim(),
      doctorId: input.doctorId.trim(),
      serviceName: input.department.trim(),
      doctorName: input.doctorName.trim(),
      doctorDesignation: input.doctorDesignation.trim(),
      specialist: input.specialist.trim(),
      doctorAvailableDays: input.doctorAvailableDays.map((day) => day.trim()),
      appointmentTime: input.appointmentTime.trim(),
      room: input.room.trim(),
      fee: input.fee,
      createdAt: submittedAt,
    },
    include: {
      doctor: {
        include: {
          schedules: {
            where: { isActive: true },
            orderBy: { sortOrder: "asc" },
          },
        },
      },
    },
  });

  const mappedAppointment = mapAppointment(appointment);

  await safeCreateFormSubmission({
    formType: FormSubmissionType.APPOINTMENT,
    name: mappedAppointment.patientName,
    phone: mappedAppointment.phone,
    subject: `Appointment request ${mappedAppointment.token}`,
    message: mappedAppointment.disease,
    payload: {
      appointmentId: mappedAppointment.id,
      token: mappedAppointment.token,
      patientName: mappedAppointment.patientName,
      phone: mappedAppointment.phone,
      age: mappedAppointment.age,
      gender: mappedAppointment.gender,
      disease: mappedAppointment.disease,
      department: mappedAppointment.department,
      doctorName: mappedAppointment.doctorName,
      appointmentTime: mappedAppointment.appointmentTime,
      room: mappedAppointment.room,
      fee: mappedAppointment.fee,
    },
  });

  const smsResult = await sendAppointmentReceivedSms(mappedAppointment);

  return {
    ...mappedAppointment,
    smsStatus: smsResult.deliveryStatus,
  };
}

export async function createManualAppointment(input: ManualAppointmentInput) {
  if (!validateManualAppointmentInput(input)) {
    throw new Error("Manual appointment information is incomplete.");
  }

  const submittedAt = new Date();
  const token = createAppointmentToken(submittedAt.toISOString());
  const source = cleanManualSource(input.source);

  const doctor = input.doctorId
    ? await db.doctor.findUnique({
        where: { id: input.doctorId },
        include: {
          schedules: {
            where: { isActive: true },
            orderBy: { sortOrder: "asc" },
          },
        },
      })
    : null;

  if (input.doctorId && !doctor) {
    throw new Error("Selected doctor was not found.");
  }

  const doctorAvailableDays =
    input.doctorAvailableDays.length > 0
      ? input.doctorAvailableDays.map((day) => day.trim()).filter(Boolean)
      : doctor?.schedules?.map((schedule) => schedule.day).filter(Boolean) || [];

  const patientName = cleanString(input.patientName);
  const phone = cleanString(input.phone);
  const patientEmail = cleanString(input.patientEmail);
  const disease = cleanString(input.disease);
  const message = cleanString(input.message) || disease;
  const department = cleanString(input.department) || doctor?.department || "";
  const doctorName = cleanString(input.doctorName) || doctor?.name || "";
  const doctorDesignation =
    cleanString(input.doctorDesignation) || doctor?.designation || "";
  const specialist = cleanString(input.specialist) || doctor?.qualifications || "";
  const appointmentTime = cleanString(input.appointmentTime);
  const room = cleanString(input.room);
  const fee = Number.isFinite(input.fee) ? Math.max(0, Math.round(input.fee)) : 0;

  const appointment = await db.appointment.create({
    data: {
      id: token,
      token,
      patientName,
      patientPhone: phone,
      patientEmail: patientEmail || null,
      patientAge: cleanString(input.age) || null,
      patientGender: cleanString(input.gender) || null,
      disease,
      message,
      doctorId: doctor?.id || null,
      serviceName: department,
      doctorName,
      doctorDesignation,
      specialist,
      doctorAvailableDays,
      appointmentTime,
      room,
      fee,
      source,
      smsTemplateKey: "appointment_manual_created",
      createdAt: submittedAt,
    },
    include: {
      doctor: {
        include: {
          schedules: {
            where: { isActive: true },
            orderBy: { sortOrder: "asc" },
          },
        },
      },
    },
  });

  const mappedAppointment = mapAppointment(appointment);

  await safeCreateFormSubmission({
    formType: FormSubmissionType.APPOINTMENT,
    source,
    name: mappedAppointment.patientName,
    phone: mappedAppointment.phone,
    email: mappedAppointment.patientEmail,
    subject: `Manual appointment ${mappedAppointment.token}`,
    message: mappedAppointment.disease,
    payload: {
      appointmentId: mappedAppointment.id,
      token: mappedAppointment.token,
      source,
      patientName: mappedAppointment.patientName,
      phone: mappedAppointment.phone,
      email: mappedAppointment.patientEmail,
      age: mappedAppointment.age,
      gender: mappedAppointment.gender,
      disease: mappedAppointment.disease,
      department: mappedAppointment.department,
      doctorName: mappedAppointment.doctorName,
      appointmentTime: mappedAppointment.appointmentTime,
      room: mappedAppointment.room,
      fee: mappedAppointment.fee,
      smsTemplateKey: "appointment_manual_created",
    },
  });

  const smsResult = await sendManualAppointmentCreatedSms(mappedAppointment);

  return {
    ...mappedAppointment,
    smsStatus: smsResult.deliveryStatus,
  };
}

export async function deleteAppointment(id: string) {
  await db.appointment.delete({ where: { id } });
}
