import { db } from "@/lib/db";
import {
  ABOUT_PAGE_STORAGE_KEY,
  DEFAULT_ABOUT_PAGE,
  type AboutFeatureCard,
  type AboutImageCard,
  type AboutPageData,
} from "@/lib/aboutPage";

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizeFeatureCard(
  item: unknown,
  index: number,
  prefix: string,
): AboutFeatureCard {
  const value = isObject(item) ? item : {};

  return {
    id: typeof value.id === "string" && value.id ? value.id : `${prefix}-${index + 1}`,
    icon: typeof value.icon === "string" && value.icon ? value.icon : "stethoscope",
    title: typeof value.title === "string" ? value.title : "New Card",
    text: typeof value.text === "string" ? value.text : "",
    active: typeof value.active === "boolean" ? value.active : true,
    sortOrder: Number(value.sortOrder) || index + 1,
  };
}

function normalizeImageCard(item: unknown, index: number): AboutImageCard {
  const value = isObject(item) ? item : {};

  return {
    id: typeof value.id === "string" && value.id ? value.id : `gallery-${index + 1}`,
    icon: typeof value.icon === "string" && value.icon ? value.icon : "stethoscope",
    image: typeof value.image === "string" ? value.image : "",
    label:
      typeof value.label === "string" && value.label
        ? value.label
        : String(index + 1).padStart(2, "0"),
    active: typeof value.active === "boolean" ? value.active : true,
    sortOrder: Number(value.sortOrder) || index + 1,
  };
}

export function normalizeAboutPage(value: unknown): AboutPageData {
  if (!isObject(value)) return DEFAULT_ABOUT_PAGE;

  const merged = { ...DEFAULT_ABOUT_PAGE, ...value } as AboutPageData;

  return {
    ...merged,
    whoCards: Array.isArray(value.whoCards)
      ? value.whoCards.map((item, index) =>
          normalizeFeatureCard(item, index, "who-card"),
        )
      : DEFAULT_ABOUT_PAGE.whoCards,
    transformImages: Array.isArray(value.transformImages)
      ? value.transformImages.map(normalizeImageCard)
      : DEFAULT_ABOUT_PAGE.transformImages,
    values: Array.isArray(value.values)
      ? value.values.map((item, index) => normalizeFeatureCard(item, index, "value"))
      : DEFAULT_ABOUT_PAGE.values,
    learningCards: Array.isArray(value.learningCards)
      ? value.learningCards.map((item, index) =>
          normalizeFeatureCard(item, index, "learning-card"),
        )
      : DEFAULT_ABOUT_PAGE.learningCards,
    updatedAt:
      typeof value.updatedAt === "string" && value.updatedAt
        ? value.updatedAt
        : DEFAULT_ABOUT_PAGE.updatedAt,
  };
}

export async function getAboutPageFromDb(): Promise<AboutPageData> {
  const row = await db.siteSetting.findUnique({
    where: { key: ABOUT_PAGE_STORAGE_KEY },
  });

  return normalizeAboutPage(row?.value);
}

export async function saveAboutPageToDb(data: AboutPageData): Promise<AboutPageData> {
  const normalized = normalizeAboutPage({
    ...data,
    updatedAt: new Date().toISOString(),
  });

  await db.siteSetting.upsert({
    where: { key: ABOUT_PAGE_STORAGE_KEY },
    update: { value: normalized },
    create: { key: ABOUT_PAGE_STORAGE_KEY, value: normalized },
  });

  return normalized;
}

export async function resetAboutPageInDb(): Promise<AboutPageData> {
  await db.siteSetting.upsert({
    where: { key: ABOUT_PAGE_STORAGE_KEY },
    update: { value: DEFAULT_ABOUT_PAGE },
    create: { key: ABOUT_PAGE_STORAGE_KEY, value: DEFAULT_ABOUT_PAGE },
  });

  return DEFAULT_ABOUT_PAGE;
}
