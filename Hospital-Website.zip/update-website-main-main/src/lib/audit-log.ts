import "server-only";

import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { getCurrentAdminUser } from "@/lib/admin-session";

const DEFAULT_AUDIT_LIMIT = 100;
const MAX_AUDIT_LIMIT = 300;

export type AuditLogInput = {
  action: string;
  entity: string;
  entityId?: string | null;
  metadata?: Prisma.InputJsonValue;
  request?: Request | null;
  adminId?: string | null;
};

export type AuditLogFilters = {
  take?: number;
  action?: string;
  entity?: string;
  adminId?: string;
};

function getIpAddress(request?: Request | null) {
  if (!request) return null;

  const forwardedFor = request.headers.get("x-forwarded-for");
  const realIp = request.headers.get("x-real-ip");
  const cfConnectingIp = request.headers.get("cf-connecting-ip");

  return (
    cfConnectingIp ||
    realIp ||
    forwardedFor?.split(",")[0]?.trim() ||
    null
  );
}

function getUserAgent(request?: Request | null) {
  if (!request) return null;
  return request.headers.get("user-agent");
}

export async function recordAuditLog(input: AuditLogInput) {
  try {
    const currentAdmin =
      input.adminId === undefined ? await getCurrentAdminUser() : null;
    const adminId = input.adminId === undefined ? currentAdmin?.id ?? null : input.adminId;

    await db.auditLog.create({
      data: {
        adminId,
        action: input.action,
        entity: input.entity,
        entityId: input.entityId ?? null,
        ...(input.metadata === undefined ? {} : { metadata: input.metadata }),
        ipAddress: getIpAddress(input.request),
        userAgent: getUserAgent(input.request),
      },
    });
  } catch (caught) {
    console.error("[audit] Failed to write audit log", caught);
  }
}

export async function recordAdminAuthAudit(input: {
  email: string;
  ok: boolean;
  action: "ADMIN_LOGIN_SUCCESS" | "ADMIN_LOGIN_FAILED";
  request?: Request | null;
  reason?: string;
}) {
  try {
    const email = input.email.trim().toLowerCase();
    const admin = email
      ? await db.adminUser.findUnique({
          where: { email },
          select: { id: true, email: true },
        })
      : null;

    await db.auditLog.create({
      data: {
        adminId: admin?.id ?? null,
        action: input.action,
        entity: "AdminAuth",
        entityId: admin?.id ?? null,
        metadata: {
          email,
          ok: input.ok,
          reason: input.reason ?? null,
        },
        ipAddress: getIpAddress(input.request),
        userAgent: getUserAgent(input.request),
      },
    });
  } catch (caught) {
    console.error("[audit] Failed to write auth audit log", caught);
  }
}

export async function getAuditLogs(filters: AuditLogFilters = {}) {
  const take = Math.min(
    Math.max(Number(filters.take || DEFAULT_AUDIT_LIMIT), 1),
    MAX_AUDIT_LIMIT,
  );

  return db.auditLog.findMany({
    where: {
      ...(filters.action ? { action: filters.action } : {}),
      ...(filters.entity ? { entity: filters.entity } : {}),
      ...(filters.adminId ? { adminId: filters.adminId } : {}),
    },
    take,
    orderBy: { createdAt: "desc" },
    include: {
      admin: {
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
        },
      },
    },
  });
}
