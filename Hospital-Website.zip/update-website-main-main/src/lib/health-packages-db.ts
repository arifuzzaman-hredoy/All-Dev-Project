import { FormSubmissionType } from "@prisma/client";

import { DEFAULT_HEALTH_PACKAGES, HealthPackage, normalizeHealthPackage, slugify } from "@/lib/healthPackages";
import { safeCreateFormSubmission } from "@/lib/form-submissions";
import { sendPackageBookingReceivedSms } from "@/lib/sms-workflows";
import { PackageBooking, PaymentStatus, makeReceiptNo, makeToken, normalizePackageBooking } from "@/lib/packageBookings";
import { db } from "@/lib/db";
import type { PackageBooking as DbPackageBooking, Prisma } from "@prisma/client";

type HealthPackageRecord = Prisma.HealthPackageGetPayload<{
  include: { tests: { orderBy: { sortOrder: "asc" } } };
}>;

type PackageBookingRecord = DbPackageBooking;

function parsePrice(value: string) {
  const digits = value.replace(/[^0-9]/g, "");
  return digits ? Number(digits) : null;
}

function statusFromActive(active: boolean) {
  return active ? "PUBLISHED" : "DRAFT";
}

function activeFromStatus(status: string) {
  return status === "PUBLISHED";
}

export function toHealthPackage(record: HealthPackageRecord): HealthPackage {
  return normalizeHealthPackage({
    id: record.id,
    slug: record.slug,
    title: record.title,
    name: record.name || record.title,
    badge: record.badge || "HEALTH PACKAGES",
    price: record.priceText || (record.price ? `${record.price} BDT` : ""),
    target: record.target || "",
    subtitle:
      record.subtitle ||
      record.description ||
      "Choose a suitable health check package for preventive care, routine screening, and better health planning.",
    image: record.imageUrl || "/slider1.jpeg",
    tests: record.tests.map((test) => test.name),
    active: activeFromStatus(record.status),
    sortOrder: record.sortOrder,
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  });
}

function healthPackageData(payload: Partial<HealthPackage>) {
  const title = payload.title?.trim() || payload.name?.trim() || "Health Package";
  const price = payload.price?.trim() || "";
  const subtitle = payload.subtitle?.trim() || "";

  return {
    slug: slugify(payload.slug || title),
    title,
    name: payload.name?.trim() || title,
    badge: payload.badge?.trim() || "HEALTH PACKAGES",
    description: subtitle,
    subtitle,
    target: payload.target?.trim() || "",
    imageUrl: payload.image?.trim() || "/slider1.jpeg",
    price: parsePrice(price),
    priceText: price,
    status: statusFromActive(payload.active ?? true) as "PUBLISHED" | "DRAFT",
    sortOrder: Number(payload.sortOrder) || 10,
  };
}

export async function getAdminHealthPackages() {
  const packages = await db.healthPackage.findMany({
    include: { tests: { orderBy: { sortOrder: "asc" } } },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
  });

  return packages.map(toHealthPackage);
}

export async function getActiveDbHealthPackages() {
  const packages = await db.healthPackage.findMany({
    where: { status: "PUBLISHED" },
    include: { tests: { orderBy: { sortOrder: "asc" } } },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
  });

  return packages.map(toHealthPackage);
}

export async function getDbHealthPackageBySlug(slug: string) {
  const healthPackage = await db.healthPackage.findFirst({
    where: { slug, status: "PUBLISHED" },
    include: { tests: { orderBy: { sortOrder: "asc" } } },
  });

  return healthPackage ? toHealthPackage(healthPackage) : null;
}

export async function createDbHealthPackage(payload: Partial<HealthPackage>) {
  const data = healthPackageData(payload);
  const tests = Array.isArray(payload.tests) ? payload.tests : [];

  const healthPackage = await db.healthPackage.create({
    data: {
      ...data,
      tests: {
        create: tests.map((name, index) => ({ name, sortOrder: index + 1 })),
      },
    },
    include: { tests: { orderBy: { sortOrder: "asc" } } },
  });

  return toHealthPackage(healthPackage);
}

export async function updateDbHealthPackage(
  id: string,
  payload: Partial<HealthPackage>
) {
  const data = healthPackageData(payload);
  const tests = Array.isArray(payload.tests) ? payload.tests : [];

  const healthPackage = await db.$transaction(async (tx) => {
    await tx.healthPackageTest.deleteMany({ where: { packageId: id } });
    return tx.healthPackage.update({
      where: { id },
      data: {
        ...data,
        tests: {
          create: tests.map((name, index) => ({ name, sortOrder: index + 1 })),
        },
      },
      include: { tests: { orderBy: { sortOrder: "asc" } } },
    });
  });

  return toHealthPackage(healthPackage);
}

export async function setDbHealthPackageActive(id: string, active: boolean) {
  await db.healthPackage.update({
    where: { id },
    data: { status: statusFromActive(active) },
  });
}

export async function deleteDbHealthPackage(id: string) {
  await db.healthPackage.delete({ where: { id } });
}

export async function resetDbHealthPackagesToDefault() {
  await db.$transaction(async (tx) => {
    await tx.packageBooking.updateMany({ data: { packageId: null } });
    await tx.healthPackage.deleteMany({});

    for (const [index, item] of DEFAULT_HEALTH_PACKAGES.entries()) {
      await tx.healthPackage.create({
        data: {
          slug: item.slug,
          title: item.title,
          name: item.name,
          badge: item.badge,
          description: item.subtitle,
          subtitle: item.subtitle,
          target: item.target,
          imageUrl: item.image,
          price: parsePrice(item.price),
          priceText: item.price,
          status: statusFromActive(item.active),
          sortOrder: item.sortOrder || index + 1,
          tests: {
            create: item.tests.map((name, testIndex) => ({
              name,
              sortOrder: testIndex + 1,
            })),
          },
        },
      });
    }
  });

  return getAdminHealthPackages();
}

export async function seedDefaultHealthPackagesIfEmpty() {
  const count = await db.healthPackage.count();
  if (count > 0) return { count, created: false };

  await resetDbHealthPackagesToDefault();
  return { count: DEFAULT_HEALTH_PACKAGES.length, created: true };
}

function paymentStatusToBookingStatus(status: PaymentStatus | string | undefined) {
  if (status === "Verified") return "CONFIRMED";
  if (status === "Rejected") return "CANCELLED";
  return "NEW";
}

export function toPackageBooking(record: PackageBookingRecord): PackageBooking {
  return normalizePackageBooking({
    id: record.id,
    token: record.token || "",
    receiptNo: record.receiptNo || "",
    packageSlug: record.packageSlug || "",
    packageName: record.packageName || "",
    packageTarget: record.packageTarget || "",
    packageFee: record.packageFee || "",
    patientName: record.patientName,
    phone: record.phone,
    age: record.age || "",
    gender: record.gender || "",
    diseaseProblem: record.diseaseProblem || "",
    address: record.address || "",
    email: record.email || "",
    paymentMethod: (record.paymentMethod || "Cash Request") as PackageBooking["paymentMethod"],
    paymentNumber: record.paymentNumber || "",
    transactionId: record.transactionId || "",
    amountPaid: record.amountPaid || "",
    paymentStatus: (record.paymentStatus || "Payment Submitted") as PaymentStatus,
    requestNote: record.requestNote || record.message || "",
    submittedAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  });
}

export async function getAdminPackageBookings() {
  const bookings = await db.packageBooking.findMany({
    orderBy: { createdAt: "desc" },
  });

  return bookings.map(toPackageBooking);
}

export async function createDbPackageBooking(payload: Partial<PackageBooking>) {
  const packageSlug = payload.packageSlug?.trim() || "";
  const selectedPackage = packageSlug
    ? await db.healthPackage.findUnique({ where: { slug: packageSlug } })
    : null;
  const paymentStatus = payload.paymentStatus ||
    (payload.paymentMethod === "Cash Request" ? "Cash Request" : "Payment Submitted");

  const booking = await db.packageBooking.create({
    data: {
      token: payload.token || makeToken(),
      receiptNo: payload.receiptNo || makeReceiptNo(),
      packageId: selectedPackage?.id,
      packageSlug: packageSlug || selectedPackage?.slug,
      packageName: payload.packageName || selectedPackage?.title || "Health Package",
      packageTarget: payload.packageTarget || selectedPackage?.target || "",
      packageFee:
        payload.packageFee || selectedPackage?.priceText ||
        (selectedPackage?.price ? `${selectedPackage.price} BDT` : ""),
      patientName: payload.patientName?.trim() || "Unknown Patient",
      phone: payload.phone?.trim() || "",
      age: payload.age || "",
      gender: payload.gender || "",
      diseaseProblem: payload.diseaseProblem || "",
      address: payload.address || "",
      email: payload.email || "",
      paymentMethod: payload.paymentMethod || "Cash Request",
      paymentNumber: payload.paymentNumber || "",
      transactionId: payload.transactionId || "",
      amountPaid:
        payload.amountPaid || payload.packageFee || selectedPackage?.priceText || "",
      paymentStatus,
      requestNote: payload.requestNote || "",
      message: payload.requestNote || payload.diseaseProblem || "",
      status: paymentStatusToBookingStatus(paymentStatus),
    },
  });

  const mappedBooking = toPackageBooking(booking);

  await safeCreateFormSubmission({
    formType: FormSubmissionType.PACKAGE_BOOKING,
    name: mappedBooking.patientName,
    phone: mappedBooking.phone,
    email: mappedBooking.email,
    subject: `Package booking ${mappedBooking.receiptNo}`,
    message: mappedBooking.requestNote || mappedBooking.diseaseProblem,
    payload: {
      bookingId: mappedBooking.id,
      token: mappedBooking.token,
      receiptNo: mappedBooking.receiptNo,
      packageSlug: mappedBooking.packageSlug,
      packageName: mappedBooking.packageName,
      packageTarget: mappedBooking.packageTarget,
      packageFee: mappedBooking.packageFee,
      patientName: mappedBooking.patientName,
      phone: mappedBooking.phone,
      age: mappedBooking.age,
      gender: mappedBooking.gender,
      diseaseProblem: mappedBooking.diseaseProblem,
      address: mappedBooking.address,
      email: mappedBooking.email,
      paymentMethod: mappedBooking.paymentMethod,
      paymentNumber: mappedBooking.paymentNumber,
      transactionId: mappedBooking.transactionId,
      amountPaid: mappedBooking.amountPaid,
      paymentStatus: mappedBooking.paymentStatus,
      requestNote: mappedBooking.requestNote,
    },
  });

  await sendPackageBookingReceivedSms(mappedBooking);

  return mappedBooking;
}

export async function updateDbPackageBookingStatus(
  id: string,
  paymentStatus: PaymentStatus
) {
  const booking = await db.packageBooking.update({
    where: { id },
    data: {
      paymentStatus,
      status: paymentStatusToBookingStatus(paymentStatus),
    },
  });

  return toPackageBooking(booking);
}

export async function deleteDbPackageBooking(id: string) {
  await db.packageBooking.delete({ where: { id } });
}
