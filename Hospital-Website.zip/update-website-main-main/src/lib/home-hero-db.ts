import "server-only";

import type { Prisma } from "@prisma/client";
import { normalizeHomeHeroContent } from "@/features/home-hero/defaults";
import type { HomeHeroContent } from "@/features/home-hero/types";
import { db } from "@/lib/db";
import { readPublicContent } from "@/lib/public-content/storage";

export const HOME_HERO_SETTING_KEY = "home.hero.content";

export async function getHomeHeroContent(): Promise<HomeHeroContent> {
  const row = await db.siteSetting.findUnique({
    where: { key: HOME_HERO_SETTING_KEY },
  });

  if (row?.value) {
    return normalizeHomeHeroContent(row.value);
  }

  // One-time fallback from old JSON storage so existing content is not lost.
  const publicContent = await readPublicContent();
  const homeHero = normalizeHomeHeroContent(publicContent.homeHero);

  const jsonValue = homeHero as unknown as Prisma.InputJsonValue;

  await db.siteSetting.upsert({
    where: { key: HOME_HERO_SETTING_KEY },
    update: { value: jsonValue },
    create: { key: HOME_HERO_SETTING_KEY, value: jsonValue },
  });

  return homeHero;
}

export async function saveHomeHeroContent(
  input: HomeHeroContent,
): Promise<HomeHeroContent> {
  const homeHero = normalizeHomeHeroContent(input);

  const jsonValue = homeHero as unknown as Prisma.InputJsonValue;

  await db.siteSetting.upsert({
    where: { key: HOME_HERO_SETTING_KEY },
    update: { value: jsonValue },
    create: { key: HOME_HERO_SETTING_KEY, value: jsonValue },
  });

  return homeHero;
}
