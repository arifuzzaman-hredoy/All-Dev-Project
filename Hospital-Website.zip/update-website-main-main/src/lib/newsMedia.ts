import { newsMedia as siteNewsMedia } from "@/data/site";

export type NewsMediaItem = {
  id: string;
  slug: string;
  title: string;
  date: string;
  category: string;
  image: string;
  excerpt: string;
  leadText: string;
  body: string[];
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export const NEWS_MEDIA_STORAGE_KEY =
  "update-diagnostic-center-news-media-items";

const seededAt = "2026-06-12T00:00:00.000Z";

function toDateInput(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toISOString().slice(0, 10);
}

export const DEFAULT_NEWS_MEDIA: NewsMediaItem[] = siteNewsMedia.map(
  (item, index) => ({
    id: item.slug,
    slug: item.slug,
    title: item.title,
    date: toDateInput(item.date),
    category: "Media Update",
    image: item.image,
    excerpt: item.excerpt,
    leadText: item.excerpt,
    body: item.content,
    active: true,
    sortOrder: index + 1,
    createdAt: seededAt,
    updatedAt: seededAt,
  })
);

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function normalizeItem(item: Partial<NewsMediaItem>, index: number) {
  const title = item.title || "News Media";
  const now = new Date().toISOString();

  return {
    id: item.id || slugify(item.slug || title) || `news-media-${index + 1}`,
    slug: item.slug || slugify(title) || `news-media-${index + 1}`,
    title,
    date: item.date || new Date().toISOString().slice(0, 10),
    category: item.category || "Media Update",
    image: item.image || "/news/news-1.jpg",
    excerpt: item.excerpt || "",
    leadText: item.leadText || item.excerpt || "",
    body: Array.isArray(item.body) ? item.body : [],
    active: item.active ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
    createdAt: item.createdAt || now,
    updatedAt: item.updatedAt || now,
  };
}

export function getNewsMediaFromStorage(): NewsMediaItem[] {
  return DEFAULT_NEWS_MEDIA;
}

export function getActiveNewsMedia() {
  return getNewsMediaFromStorage()
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

export function saveNewsMediaToStorage(_items: NewsMediaItem[]) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event("news-media-updated"));
}

export function linesToParagraphs(value: string) {
  return value.split("\n").map((item) => item.trim()).filter(Boolean);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

export function formatNewsDate(value: string) {
  try {
    const date = new Date(value.includes("T") ? value : `${value}T00:00:00`);
    if (Number.isNaN(date.getTime())) return value;
    const month = date.toLocaleString("en-US", { month: "long" }).toUpperCase();
    const day = String(date.getDate()).padStart(2, "0");
    return `${month} ${day}, ${date.getFullYear()}`;
  } catch {
    return value;
  }
}
