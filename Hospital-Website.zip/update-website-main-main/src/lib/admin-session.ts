"use server";

import { createHash, randomBytes } from "crypto";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { getAdminCookieName, validateServerEnv } from "@/lib/env";
import { verifyAdminPassword } from "@/lib/admin-password";

const ADMIN_COOKIE = getAdminCookieName();
const SESSION_MAX_AGE_SECONDS = 60 * 60 * 8;

type AdminSessionUser = {
  id: string;
  email: string;
  name: string | null;
  role: string;
};

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

async function deleteCurrentSession(token?: string) {
  if (!token) return;

  await db.adminSession
    .delete({
      where: { tokenHash: hashToken(token) },
    })
    .catch(() => null);
}

async function cleanupExpiredSessions() {
  await db.adminSession
    .deleteMany({
      where: { expiresAt: { lte: new Date() } },
    })
    .catch(() => null);
}

export async function createAdminSession(email: string, password: string) {
  validateServerEnv({ requireAdmin: true });

  const normalizedEmail = normalizeEmail(email);

  if (!normalizedEmail || !password) {
    return { ok: false, message: "Email and password are required." };
  }

  await cleanupExpiredSessions();

  const admin = await db.adminUser.findUnique({
    where: { email: normalizedEmail },
  });

  if (!admin || !admin.isActive) {
    return { ok: false, message: "Invalid username or password." };
  }

  const passwordOk = verifyAdminPassword(password, admin.passwordHash);

  if (!passwordOk) {
    return { ok: false, message: "Invalid username or password." };
  }

  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE_SECONDS * 1000);

  await db.$transaction([
    db.adminSession.create({
      data: {
        tokenHash: hashToken(token),
        adminId: admin.id,
        expiresAt,
      },
    }),
    db.adminUser.update({
      where: { id: admin.id },
      data: { lastLoginAt: new Date() },
    }),
  ]);

  const cookieStore = await cookies();
  const forceLoginOnRefresh = process.env.ADMIN_FORCE_LOGIN_ON_REFRESH === "true";
  const cookieOptions = {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    ...(forceLoginOnRefresh ? {} : { maxAge: SESSION_MAX_AGE_SECONDS }),
  };

  cookieStore.set(ADMIN_COOKIE, token, cookieOptions);

  return { ok: true, message: "Logged in." };
}

export async function clearAdminSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(ADMIN_COOKIE)?.value;

  await deleteCurrentSession(token);
  cookieStore.delete(ADMIN_COOKIE);
}

export async function getCurrentAdminUser(): Promise<AdminSessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(ADMIN_COOKIE)?.value;

  if (!token) return null;

  const session = await db.adminSession.findUnique({
    where: { tokenHash: hashToken(token) },
    include: {
      admin: {
        select: {
          id: true,
          email: true,
          name: true,
          role: true,
          isActive: true,
        },
      },
    },
  });

  if (!session || session.expiresAt <= new Date() || !session.admin.isActive) {
    await deleteCurrentSession(token);
    cookieStore.delete(ADMIN_COOKIE);
    return null;
  }

  return {
    id: session.admin.id,
    email: session.admin.email,
    name: session.admin.name,
    role: session.admin.role,
  };
}

export async function hasAdminSession() {
  return Boolean(await getCurrentAdminUser());
}

export async function requireAdminSession() {
  const admin = await getCurrentAdminUser();

  if (!admin) {
    throw new Error("Unauthorized admin action.");
  }

  return admin;
}
