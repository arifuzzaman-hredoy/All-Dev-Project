export type AboutFeatureCard = {
  id: string;
  icon: string;
  title: string;
  text: string;
  active: boolean;
  sortOrder: number;
};

export type AboutImageCard = {
  id: string;
  icon: string;
  image: string;
  label: string;
  active: boolean;
  sortOrder: number;
};

export type AboutPageData = {
  heroImage: string;
  heroAlt: string;
  whoBadge: string;
  whoTitleMain: string;
  whoTitleAccent: string;
  whoImage: string;
  whoImageLabel: string;
  whoDescription: string;
  whoCards: AboutFeatureCard[];
  transformTitleMain: string;
  transformTitleAccent: string;
  transformImages: AboutImageCard[];
  visionTitle: string;
  visionText: string;
  missionTitle: string;
  missionText: string;
  valuesTitle: string;
  valuesIntro: string;
  values: AboutFeatureCard[];
  learningBadge: string;
  learningImage: string;
  learningImageLabel: string;
  learningTitle: string;
  learningAccent: string;
  learningDescription: string;
  learningCards: AboutFeatureCard[];
  updatedAt: string;
};

export const ABOUT_PAGE_STORAGE_KEY = "update-diagnostic-center-about-page-cms";

export const DEFAULT_ABOUT_IMAGE =
  "data:image/svg+xml;charset=UTF-8," +
  encodeURIComponent(`
  <svg width="1200" height="720" viewBox="0 0 1200 720" xmlns="http://www.w3.org/2000/svg">
    <rect width="1200" height="720" fill="#003173"/>
    <text x="50%" y="48%" dominant-baseline="middle" text-anchor="middle" fill="white" font-size="66" font-family="Arial" font-weight="900">UPDATE DIAGNOSTIC</text>
    <text x="50%" y="60%" dominant-baseline="middle" text-anchor="middle" fill="#35bbea" font-size="34" font-family="Arial" font-weight="700">ABOUT US</text>
  </svg>
`);

const seededAt = "2026-06-12T00:00:00.000Z";

export const DEFAULT_ABOUT_PAGE: AboutPageData = {
  heroImage: "/slider2.jpeg",
  heroAlt: "Update Diagnostic Center team",
  whoBadge: "ABOUT US",
  whoTitleMain: "Who",
  whoTitleAccent: "We Are",
  whoImage: "/doctor-patient.jpeg",
  whoImageLabel: "Patient First Care",
  whoDescription:
    "Update Diagnostic Center is a trusted healthcare destination committed to providing coordinated medical, diagnostic, and wellness services. We focus on accessible care, patient safety, and clear communication so every visitor feels supported from consultation to recovery.",
  whoCards: [
    {
      id: "expert-medical-care",
      icon: "stethoscope",
      title: "Expert Medical Care",
      text: "Experienced care team and reliable diagnostic support.",
      active: true,
      sortOrder: 1,
    },
    {
      id: "patient-safety",
      icon: "shieldCheck",
      title: "Patient Safety",
      text: "Safe, organized, and patient-first service process.",
      active: true,
      sortOrder: 2,
    },
    {
      id: "trusted-support",
      icon: "handHeart",
      title: "Trusted Support",
      text: "Clear communication from consultation to recovery.",
      active: true,
      sortOrder: 3,
    },
  ],
  transformTitleMain: "Transforming Healthcare",
  transformTitleAccent: "in Bangladesh",
  transformImages: [
    {
      id: "transform-1",
      icon: "stethoscope",
      image: "/about/gallery-1.jpg",
      label: "01",
      active: true,
      sortOrder: 1,
    },
    {
      id: "transform-2",
      icon: "heartPulse",
      image: "/about/gallery-2.jpg",
      label: "02",
      active: true,
      sortOrder: 2,
    },
    {
      id: "transform-3",
      icon: "shieldCheck",
      image: "/about/gallery-3.jpg",
      label: "03",
      active: true,
      sortOrder: 3,
    },
    {
      id: "transform-4",
      icon: "sparkles",
      image: "/about/gallery-4.jpg",
      label: "04",
      active: true,
      sortOrder: 4,
    },
  ],
  visionTitle: "OUR VISION",
  visionText:
    "To become a leading tertiary and quaternary care hospital chain, providing best-in-class private healthcare of international standards, accessible to Bangladeshi citizens.",
  missionTitle: "OUR MISSION",
  missionText:
    "Set up quaternary care capabilities in all specialties so that Bangladeshi citizens do not need to travel out of country for medical treatments.",
  valuesTitle: "OUR VALUES",
  valuesIntro:
    "We are committed to providing best-in-class, accessible healthcare for all and encourage our employees and caregivers to share our values:",
  values: [
    {
      id: "quality",
      icon: "badgeCheck",
      title: "Quality",
      text: "We are committed to providing quality healthcare for every patient.",
      active: true,
      sortOrder: 1,
    },
    {
      id: "integrity",
      icon: "award",
      title: "Integrity",
      text: "We do the right thing, every time, even when no one is looking.",
      active: true,
      sortOrder: 2,
    },
    {
      id: "passionate",
      icon: "heartPulse",
      title: "Passionate",
      text: "We are passionate about healthcare and this shows in the care we provide.",
      active: true,
      sortOrder: 3,
    },
    {
      id: "respect",
      icon: "sparkles",
      title: "Respect",
      text: "We are respectful of everyone regardless of our differences and diversity.",
      active: true,
      sortOrder: 4,
    },
    {
      id: "innovative",
      icon: "lightbulb",
      title: "Innovative",
      text: "We believe innovation helps improve patients' experience and caregiver engagement.",
      active: true,
      sortOrder: 5,
    },
  ],
  learningBadge: "MEDICAL LEARNING",
  learningImage: "/about/medical-learning.jpg",
  learningImageLabel: "MEDICAL EDUCATION",
  learningTitle: "The first MRCP (UK) PACES examination center in",
  learningAccent: "Bangladesh",
  learningDescription:
    "Update Diagnostic Center is committed to strengthening healthcare standards through skilled clinicians, modern diagnostic services, and continuous medical learning. This development supports aspiring physicians, improves local training access, and helps patients receive more confident specialist care close to home.",
  learningCards: [
    {
      id: "medical-training",
      icon: "graduationCap",
      title: "Medical Training",
      text: "Continuous learning support for healthcare professionals.",
      active: true,
      sortOrder: 1,
    },
    {
      id: "global-standard",
      icon: "medal",
      title: "Global Standard",
      text: "International standard training and clinical excellence.",
      active: true,
      sortOrder: 2,
    },
    {
      id: "specialist-care",
      icon: "stethoscope",
      title: "Specialist Care",
      text: "Better specialist care through medical knowledge development.",
      active: true,
      sortOrder: 3,
    },
  ],
  updatedAt: seededAt,
};

function normalizeFeatureCard(
  item: Partial<AboutFeatureCard>,
  index: number,
  prefix: string,
): AboutFeatureCard {
  return {
    id: item.id || `${prefix}-${index + 1}`,
    icon: item.icon || "stethoscope",
    title: item.title || "New Card",
    text: item.text || "",
    active: item.active ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
  };
}

function normalizeImageCard(
  item: Partial<AboutImageCard>,
  index: number,
): AboutImageCard {
  return {
    id: item.id || `gallery-${index + 1}`,
    icon: item.icon || "stethoscope",
    image: item.image || DEFAULT_ABOUT_IMAGE,
    label: item.label || String(index + 1).padStart(2, "0"),
    active: item.active ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
  };
}

export function getAboutPageFromStorage(): AboutPageData {
  return DEFAULT_ABOUT_PAGE;
}

export function saveAboutPageToStorage(_data: AboutPageData) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event("about-page-updated"));
}

export function makeAboutId(prefix: string) {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}
