import "server-only";

import { randomBytes } from "crypto";
import type { AdminRole } from "@prisma/client";
import { db } from "@/lib/db";
import { hashAdminPassword } from "@/lib/admin-password";
import { recordAuditLog } from "@/lib/audit-log";
import { isValidAdminRole } from "@/lib/admin-permissions";

export const ADMIN_USER_SELECT = {
  id: true,
  name: true,
  email: true,
  role: true,
  isActive: true,
  lastLoginAt: true,
  createdAt: true,
  updatedAt: true,
} as const;

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

function createTemporaryPassword() {
  return `Adm-${randomBytes(4).toString("hex")}-${randomBytes(3).toString("hex")}`;
}

function cleanName(value: unknown) {
  if (typeof value !== "string") return null;
  const name = value.trim();
  return name || null;
}

function cleanPassword(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

export async function listAdminUsers() {
  return db.adminUser.findMany({
    select: ADMIN_USER_SELECT,
    orderBy: [{ role: "asc" }, { createdAt: "asc" }],
  });
}

export async function createAdminUser(input: {
  name?: unknown;
  email?: unknown;
  role?: unknown;
  password?: unknown;
  isActive?: unknown;
  request?: Request | null;
  actorId: string;
}) {
  const email = normalizeEmail(typeof input.email === "string" ? input.email : "");
  const role = isValidAdminRole(input.role) ? input.role : "ADMIN";
  const suppliedPassword = cleanPassword(input.password);
  const generatedPassword = suppliedPassword ? null : createTemporaryPassword();
  const password = suppliedPassword || generatedPassword || "";

  if (!email || !email.includes("@")) {
    return { ok: false, status: 400, message: "Valid admin email is required." } as const;
  }

  if (password.length < 8) {
    return { ok: false, status: 400, message: "Admin password must be at least 8 characters." } as const;
  }

  const existing = await db.adminUser.findUnique({ where: { email }, select: { id: true } });
  if (existing) {
    return { ok: false, status: 409, message: "An admin user with this email already exists." } as const;
  }

  const admin = await db.adminUser.create({
    data: {
      name: cleanName(input.name),
      email,
      role,
      isActive: input.isActive === false ? false : true,
      passwordHash: hashAdminPassword(password),
    },
    select: ADMIN_USER_SELECT,
  });

  await recordAuditLog({
    action: "ADMIN_USER_CREATED",
    entity: "AdminUser",
    entityId: admin.id,
    adminId: input.actorId,
    request: input.request,
    metadata: { email: admin.email, role: admin.role, isActive: admin.isActive },
  });

  return {
    ok: true,
    status: 201,
    message: generatedPassword
      ? "Admin user created. Copy the temporary password now. It will not be shown again."
      : "Admin user created.",
    admin,
    generatedPassword,
  } as const;
}

export async function updateAdminUser(input: {
  id: string;
  name?: unknown;
  role?: unknown;
  isActive?: unknown;
  request?: Request | null;
  actorId: string;
}) {
  const target = await db.adminUser.findUnique({ where: { id: input.id }, select: ADMIN_USER_SELECT });
  if (!target) return { ok: false, status: 404, message: "Admin user not found." } as const;

  const data: { name?: string | null; role?: AdminRole; isActive?: boolean } = {};

  if (input.name !== undefined) data.name = cleanName(input.name);
  if (input.role !== undefined) {
    if (!isValidAdminRole(input.role)) return { ok: false, status: 400, message: "Invalid admin role." } as const;
    data.role = input.role;
  }
  if (input.isActive !== undefined) data.isActive = Boolean(input.isActive);

  if (Object.keys(data).length === 0) {
    return { ok: false, status: 400, message: "No admin user changes were provided." } as const;
  }

  const wouldRemoveSuperAdmin =
    target.role === "SUPER_ADMIN" &&
    ((data.role && data.role !== "SUPER_ADMIN") || data.isActive === false);

  if (wouldRemoveSuperAdmin) {
    const activeSuperAdmins = await db.adminUser.count({ where: { role: "SUPER_ADMIN", isActive: true } });
    if (activeSuperAdmins <= 1) {
      return { ok: false, status: 400, message: "At least one active Super Admin must remain." } as const;
    }
  }

  const updated = await db.adminUser.update({ where: { id: input.id }, data, select: ADMIN_USER_SELECT });

  if (data.isActive === false) {
    await db.adminSession.deleteMany({ where: { adminId: input.id } });
  }

  await recordAuditLog({
    action: "ADMIN_USER_UPDATED",
    entity: "AdminUser",
    entityId: updated.id,
    adminId: input.actorId,
    request: input.request,
    metadata: { before: { role: target.role, isActive: target.isActive }, after: data },
  });

  return { ok: true, status: 200, message: "Admin user updated.", admin: updated } as const;
}

export async function deactivateAdminUser(input: {
  id: string;
  request?: Request | null;
  actorId: string;
  actorEmail: string;
}) {
  const target = await db.adminUser.findUnique({ where: { id: input.id }, select: ADMIN_USER_SELECT });
  if (!target) return { ok: false, status: 404, message: "Admin user not found." } as const;

  if (target.email === input.actorEmail) {
    return { ok: false, status: 400, message: "You cannot deactivate your own admin account." } as const;
  }

  if (target.role === "SUPER_ADMIN" && target.isActive) {
    const activeSuperAdmins = await db.adminUser.count({ where: { role: "SUPER_ADMIN", isActive: true } });
    if (activeSuperAdmins <= 1) {
      return { ok: false, status: 400, message: "At least one active Super Admin must remain." } as const;
    }
  }

  const updated = await db.adminUser.update({
    where: { id: input.id },
    data: { isActive: false },
    select: ADMIN_USER_SELECT,
  });
  await db.adminSession.deleteMany({ where: { adminId: input.id } });

  await recordAuditLog({
    action: "ADMIN_USER_DEACTIVATED",
    entity: "AdminUser",
    entityId: updated.id,
    adminId: input.actorId,
    request: input.request,
    metadata: { email: updated.email, role: updated.role },
  });

  return { ok: true, status: 200, message: "Admin user deactivated.", admin: updated } as const;
}

export async function resetAdminUserPassword(input: {
  id: string;
  password?: unknown;
  request?: Request | null;
  actorId: string;
}) {
  const target = await db.adminUser.findUnique({ where: { id: input.id }, select: ADMIN_USER_SELECT });
  if (!target) return { ok: false, status: 404, message: "Admin user not found." } as const;

  const suppliedPassword = cleanPassword(input.password);
  const generatedPassword = suppliedPassword ? null : createTemporaryPassword();
  const password = suppliedPassword || generatedPassword || "";

  if (password.length < 8) {
    return { ok: false, status: 400, message: "New password must be at least 8 characters." } as const;
  }

  await db.$transaction([
    db.adminUser.update({
      where: { id: input.id },
      data: { passwordHash: hashAdminPassword(password), isActive: true },
    }),
    db.adminSession.deleteMany({ where: { adminId: input.id } }),
    db.adminPasswordResetToken.updateMany({
      where: { adminId: input.id, usedAt: null },
      data: { usedAt: new Date() },
    }),
  ]);

  await recordAuditLog({
    action: "ADMIN_USER_PASSWORD_RESET_BY_SUPER_ADMIN",
    entity: "AdminUser",
    entityId: target.id,
    adminId: input.actorId,
    request: input.request,
    metadata: { email: target.email, generatedPassword: Boolean(generatedPassword) },
  });

  return {
    ok: true,
    status: 200,
    message: generatedPassword
      ? "Temporary password generated. Copy it now. It will not be shown again."
      : "Admin password updated.",
    generatedPassword,
  } as const;
}
