export type HomeSectionTeaserKey = "home-doctors" | "home-news" | "home-blogs";

export type HomeSectionTeaserConfig = {
  key: HomeSectionTeaserKey;
  eyebrow: string;
  title: string;
  description: string;
  buttonLabel: string;
  buttonHref: string;
  limit: number;
  isActive: boolean;
};

export const HOME_SECTION_TEASER_KEYS = [
  "home-doctors",
  "home-news",
  "home-blogs",
] as const satisfies readonly HomeSectionTeaserKey[];

export const DEFAULT_HOME_SECTION_TEASERS: Record<
  HomeSectionTeaserKey,
  HomeSectionTeaserConfig
> = {
  "home-doctors": {
    key: "home-doctors",
    eyebrow: "Doctors",
    title: "Experienced consultants across key departments.",
    description:
      "Book with active specialists and view current schedules from the doctor directory.",
    buttonLabel: "Meet all doctors",
    buttonHref: "/doctors",
    limit: 4,
    isActive: true,
  },
  "home-news": {
    key: "home-news",
    eyebrow: "News & Media",
    title: "Latest News & Media Updates",
    description:
      "Stay connected with our latest healthcare updates, announcements, media coverage, and important clinic news.",
    buttonLabel: "View All News & Media",
    buttonHref: "/news-media",
    limit: 3,
    isActive: true,
  },
  "home-blogs": {
    key: "home-blogs",
    eyebrow: "Health Blog",
    title: "Latest Blogs",
    description:
      "Read practical health guides, prevention tips, and patient education articles from Update Diagnostic Center.",
    buttonLabel: "View More Blogs",
    buttonHref: "/blogs",
    limit: 3,
    isActive: true,
  },
};

export const HOME_SECTION_TEASERS_SETTING_KEY = "home.sectionTeasers";

export function isHomeSectionTeaserKey(value: string): value is HomeSectionTeaserKey {
  return HOME_SECTION_TEASER_KEYS.includes(value as HomeSectionTeaserKey);
}

function asObject(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function toStringValue(value: unknown, fallback: string) {
  return typeof value === "string" ? value.trim() || fallback : fallback;
}

function toLimitValue(value: unknown, fallback: number) {
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return fallback;
  return Math.min(12, Math.max(1, Math.round(numberValue)));
}

export function normalizeHomeSectionTeaser(
  key: HomeSectionTeaserKey,
  value: unknown,
): HomeSectionTeaserConfig {
  const fallback = DEFAULT_HOME_SECTION_TEASERS[key];
  const input = asObject(value);

  if (!input) return fallback;

  return {
    key,
    eyebrow: toStringValue(input.eyebrow, fallback.eyebrow),
    title: toStringValue(input.title, fallback.title),
    description: toStringValue(input.description, fallback.description),
    buttonLabel: toStringValue(input.buttonLabel, fallback.buttonLabel),
    buttonHref: toStringValue(input.buttonHref, fallback.buttonHref),
    limit: toLimitValue(input.limit, fallback.limit),
    isActive:
      typeof input.isActive === "boolean" ? input.isActive : fallback.isActive,
  };
}

export function normalizeHomeSectionTeasers(
  value: unknown,
): Record<HomeSectionTeaserKey, HomeSectionTeaserConfig> {
  const input = asObject(value) ?? {};

  return HOME_SECTION_TEASER_KEYS.reduce(
    (accumulator, key) => {
      accumulator[key] = normalizeHomeSectionTeaser(key, input[key]);
      return accumulator;
    },
    {} as Record<HomeSectionTeaserKey, HomeSectionTeaserConfig>,
  );
}
