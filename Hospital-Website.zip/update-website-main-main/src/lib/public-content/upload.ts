import { promises as fs } from "fs";
import path from "path";
import { slugify } from "@/lib/public-content/slug";

const allowedImageTypes = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
]);

const extensionByType: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};

export async function savePublicImageUpload(
  file: FormDataEntryValue | null,
  title: string,
) {
  if (!(file instanceof File) || file.size === 0) {
    return "";
  }

  if (!allowedImageTypes.has(file.type)) {
    throw new Error("Featured image must be a JPG, PNG, WEBP, or GIF file.");
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  const directory = path.join(process.cwd(), "public", "uploads");
  const extension = extensionByType[file.type] ?? "jpg";
  const filename = `${slugify(title) || "service"}-${Date.now()}.${extension}`;

  await fs.mkdir(directory, { recursive: true });
  await fs.writeFile(path.join(directory, filename), bytes);

  return `/uploads/${filename}`;
}
