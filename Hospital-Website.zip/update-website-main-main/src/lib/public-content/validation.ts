export type ValidationResult<T> =
  | { ok: true; data: T }
  | { ok: false; errors: string[] };

export function requiredText(value: FormDataEntryValue | null, label: string) {
  const text = typeof value === "string" ? value.trim() : "";

  if (!text) {
    return { value: "", error: `${label} is required.` };
  }

  return { value: text, error: null };
}

export function optionalText(value: FormDataEntryValue | null) {
  return typeof value === "string" ? value.trim() : "";
}

export function optionalNumber(value: FormDataEntryValue | null) {
  const text = optionalText(value);
  if (!text) return 0;

  const number = Number(text);
  return Number.isFinite(number) ? number : 0;
}

export function splitLines(value: string) {
  return value
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);
}
