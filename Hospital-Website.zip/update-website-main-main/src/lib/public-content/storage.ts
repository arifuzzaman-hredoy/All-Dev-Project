import { promises as fs } from "fs";
import path from "path";
import type { AdminService } from "@/features/admin/services/types";
import {
  defaultHomeHeroContent,
  normalizeHomeHeroContent,
} from "@/features/home-hero/defaults";
import type { HomeHeroContent } from "@/features/home-hero/types";

export type PublicContentDocument = {
  homeHero: HomeHeroContent;
  services: AdminService[];
};

const defaultContent: PublicContentDocument = {
  homeHero: defaultHomeHeroContent,
  services: [
    {
      id: "svc-cardiology",
      title: "Cardiology",
      slug: "cardiology",
      shortDescription: "Heart care, preventive screening, and cardiac diagnostics.",
      fullDescription:
        "Comprehensive cardiology support for screening, diagnosis, follow-up, and coordinated specialist care.",
      featuredImage: "/slider2.jpeg",
      galleryImages: ["/slider2.jpeg", "/slider3.jpeg"],
      icon: "HeartPulse",
      priceRange: "Consultation and package pricing available on request",
      order: 1,
      active: true,
      seoTitle: "Cardiology Services",
      seoDescription:
        "Heart care, preventive screening, and cardiac diagnostics at Update Diagnostic Center.",
      createdAt: "2026-06-01T00:00:00.000Z",
      updatedAt: "2026-06-01T00:00:00.000Z",
    },
    {
      id: "svc-neurology",
      title: "Neurology",
      slug: "neurology",
      shortDescription: "Specialized care for brain, spine, and nerve conditions.",
      fullDescription:
        "Neurology services help patients evaluate symptoms, plan diagnostics, and continue specialist-guided care.",
      featuredImage: "/slider3.jpeg",
      galleryImages: ["/slider3.jpeg"],
      icon: "Brain",
      priceRange: "",
      order: 2,
      active: true,
      seoTitle: "Neurology Services",
      seoDescription:
        "Specialized care for brain, spine, and nerve conditions at Update Diagnostic Center.",
      createdAt: "2026-06-01T00:00:00.000Z",
      updatedAt: "2026-06-01T00:00:00.000Z",
    },
    {
      id: "svc-orthopedics",
      title: "Orthopedics",
      slug: "orthopedics",
      shortDescription: "Bone, joint, trauma, and sports injury management.",
      fullDescription:
        "Orthopedic care for bone and joint concerns, injuries, rehabilitation planning, and specialist follow-up.",
      featuredImage: "/update.png",
      galleryImages: ["/update.png"],
      icon: "Bone",
      priceRange: "",
      order: 3,
      active: true,
      seoTitle: "Orthopedics Services",
      seoDescription:
        "Bone, joint, trauma, and sports injury management at Update Diagnostic Center.",
      createdAt: "2026-06-01T00:00:00.000Z",
      updatedAt: "2026-06-01T00:00:00.000Z",
    },
    {
      id: "svc-pediatrics",
      title: "Pediatrics",
      slug: "pediatrics",
      shortDescription: "Compassionate care for newborns, children, and teens.",
      fullDescription:
        "Pediatric services for newborns, children, and teens with family-friendly guidance and follow-up support.",
      featuredImage: "/pasent.jpeg",
      galleryImages: ["/pasent.jpeg"],
      icon: "Baby",
      priceRange: "",
      order: 4,
      active: true,
      seoTitle: "Pediatrics Services",
      seoDescription:
        "Compassionate care for newborns, children, and teens at Update Diagnostic Center.",
      createdAt: "2026-06-01T00:00:00.000Z",
      updatedAt: "2026-06-01T00:00:00.000Z",
    },
    {
      id: "svc-diagnostics",
      title: "Diagnostics",
      slug: "diagnostics",
      shortDescription: "Reliable lab, imaging, and health screening services.",
      fullDescription:
        "Diagnostic services covering lab tests, imaging support, health screening, and report guidance.",
      featuredImage: "/slider1.jpeg",
      galleryImages: ["/slider1.jpeg"],
      icon: "Microscope",
      priceRange: "",
      order: 5,
      active: true,
      seoTitle: "Diagnostics Services",
      seoDescription:
        "Reliable lab, imaging, and health screening services at Update Diagnostic Center.",
      createdAt: "2026-06-01T00:00:00.000Z",
      updatedAt: "2026-06-01T00:00:00.000Z",
    },
    {
      id: "svc-emergency-care",
      title: "Emergency Care",
      slug: "emergency-care",
      shortDescription: "Round-the-clock urgent care and rapid response support.",
      fullDescription:
        "Emergency care support for urgent medical needs with rapid triage and coordinated clinical attention.",
      featuredImage: "/slider4.jpeg",
      galleryImages: ["/slider4.jpeg"],
      icon: "Siren",
      priceRange: "",
      order: 6,
      active: true,
      seoTitle: "Emergency Care Services",
      seoDescription:
        "Round-the-clock urgent care and rapid response support at Update Diagnostic Center.",
      createdAt: "2026-06-01T00:00:00.000Z",
      updatedAt: "2026-06-01T00:00:00.000Z",
    },
  ],
};

function contentPath() {
  return path.join(process.cwd(), "src", "content", "public-content.json");
}

async function ensureContentFile() {
  const filePath = contentPath();
  await fs.mkdir(path.dirname(filePath), { recursive: true });

  try {
    await fs.access(filePath);
  } catch {
    await fs.writeFile(filePath, JSON.stringify(defaultContent, null, 2));
  }
}

export async function readPublicContent() {
  await ensureContentFile();
  const raw = await fs.readFile(contentPath(), "utf8");
  const parsed = JSON.parse(raw) as Partial<PublicContentDocument>;

  return {
    homeHero: normalizeHomeHeroContent(parsed.homeHero),
    services: Array.isArray(parsed.services) ? parsed.services : [],
  } satisfies PublicContentDocument;
}

export async function writePublicContent(content: PublicContentDocument) {
  await ensureContentFile();
  await fs.writeFile(contentPath(), `${JSON.stringify(content, null, 2)}\n`);
}
