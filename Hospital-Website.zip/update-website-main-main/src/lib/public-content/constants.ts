export const PUBLIC_CONTENT_FILE = "src/content/public-content.json";

export const PUBLIC_CONTENT_UPLOAD_DIR = "public/uploads";

export const PUBLIC_CONTENT_REVALIDATE_PATHS = [
  "/",
  "/services",
  "/services/[slug]",
  "/specialities",
];
