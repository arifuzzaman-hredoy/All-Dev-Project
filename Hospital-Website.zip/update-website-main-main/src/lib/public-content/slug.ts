export function slugify(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}

export function ensureSlug(value: string, fallback: string) {
  return slugify(value) || slugify(fallback) || `item-${Date.now()}`;
}
