export function sortByOrder<T extends { order: number; title: string }>(
  items: T[],
) {
  return [...items].sort((a, b) => {
    if (a.order !== b.order) return a.order - b.order;
    return a.title.localeCompare(b.title);
  });
}

export function compactText(value: string, fallback = "") {
  const text = value.trim().replace(/\s+/g, " ");
  return text || fallback;
}
