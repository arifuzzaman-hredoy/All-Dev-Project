import { patientStories as sitePatientStories } from "@/data/site";

export type PatientStory = {
  id: string;
  slug: string;
  title: string;
  date: string;
  image: string;
  excerpt: string;
  leadText: string;
  body: string[];
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export const PATIENT_STORIES_STORAGE_KEY =
  "update-diagnostic-center-patient-stories";

const seededAt = "2026-06-12T00:00:00.000Z";

function toDateInput(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toISOString().slice(0, 10);
}

export const DEFAULT_PATIENT_STORIES: PatientStory[] = sitePatientStories.map(
  (story, index) => ({
    id: story.slug,
    slug: story.slug,
    title: story.title,
    date: toDateInput(story.date),
    image: story.image,
    excerpt: story.excerpt,
    leadText: story.excerpt,
    body: story.content,
    active: true,
    sortOrder: index + 1,
    createdAt: seededAt,
    updatedAt: seededAt,
  })
);

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function normalizeStory(item: Partial<PatientStory>, index: number) {
  const title = item.title || "Patient Story";
  const now = new Date().toISOString();

  return {
    id: item.id || slugify(item.slug || title) || `patient-story-${index + 1}`,
    slug: item.slug || slugify(title) || `patient-story-${index + 1}`,
    title,
    date: item.date || new Date().toISOString().slice(0, 10),
    image: item.image || "/slider1.jpeg",
    excerpt: item.excerpt || "",
    leadText: item.leadText || item.excerpt || "",
    body: Array.isArray(item.body) ? item.body : [],
    active: item.active ?? true,
    sortOrder: Number(item.sortOrder) || index + 1,
    createdAt: item.createdAt || now,
    updatedAt: item.updatedAt || now,
  };
}

export function getPatientStoriesFromStorage(): PatientStory[] {
  return DEFAULT_PATIENT_STORIES;
}

export function getActivePatientStories() {
  return getPatientStoriesFromStorage()
    .filter((item) => item.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

export function savePatientStoriesToStorage(_stories: PatientStory[]) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event("patient-stories-updated"));
}

export function linesToParagraphs(value: string) {
  return value
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

export function formatStoryDate(value: string) {
  try {
    const date = new Date(value.includes("T") ? value : `${value}T00:00:00`);
    if (Number.isNaN(date.getTime())) return value;

    const day = String(date.getDate()).padStart(2, "0");
    const month = date
      .toLocaleString("en-US", { month: "long" })
      .toUpperCase();
    const year = date.getFullYear();

    return `${day} ${month} ${year}`;
  } catch {
    return value;
  }
}
