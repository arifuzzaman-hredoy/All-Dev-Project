import "server-only";
import type { PublishStatus } from "@prisma/client";
import { db } from "@/lib/db";
import {
  DEFAULT_SPECIALTIES,
  DEFAULT_SPECIALTY_IMAGE,
  type SpecialtyDoctor,
  type SpecialtyItem,
  slugify,
} from "@/lib/specialties";

function toStatus(active: boolean): PublishStatus {
  return active ? "PUBLISHED" : "DRAFT";
}

function safeArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function toSpecialty(row: {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  shortDescription: string | null;
  detailTitle: string | null;
  detailDescription: string | null;
  icon: string | null;
  imageUrl: string | null;
  services: unknown;
  doctorsData: unknown;
  featured: boolean;
  showInMenu: boolean;
  status: PublishStatus;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
}): SpecialtyItem {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    icon: row.icon || "stethoscope",
    shortDescription: row.shortDescription || row.description || "Specialist consultation and care support.",
    image: row.imageUrl || DEFAULT_SPECIALTY_IMAGE,
    detailTitle: row.detailTitle || `${row.title} Department`,
    detailDescription: row.detailDescription || row.description || `${row.title} department provides consultation, diagnostic support, and treatment planning.`,
    services: safeArray<string>(row.services),
    doctors: safeArray<SpecialtyDoctor>(row.doctorsData),
    active: row.status === "PUBLISHED",
    featured: row.featured,
    showInMenu: row.showInMenu,
    sortOrder: row.sortOrder || 10,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function listSpecialities({ admin = false, featuredOnly = false } = {}) {
  const rows = await db.speciality.findMany({
    where: {
      ...(admin ? {} : { status: "PUBLISHED" as PublishStatus }),
      ...(featuredOnly ? { featured: true } : {}),
    },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });

  if (!rows.length) {
    const defaults = admin ? DEFAULT_SPECIALTIES : DEFAULT_SPECIALTIES.filter((item) => item.active);
    return featuredOnly ? defaults.filter((item) => item.featured) : defaults;
  }

  return rows.map(toSpecialty);
}

export async function getSpecialityBySlug(slug: string, { admin = false } = {}) {
  const row = await db.speciality.findUnique({ where: { slug } });
  if (!row || (!admin && row.status !== "PUBLISHED")) {
    return DEFAULT_SPECIALTIES.find((item) => item.slug === slug && (admin || item.active)) || null;
  }
  return toSpecialty(row);
}

export async function replaceSpecialities(items: SpecialtyItem[]) {
  await db.$transaction(async (tx) => {
    await tx.doctorSpeciality.deleteMany();
    await tx.speciality.deleteMany();

    for (const [index, item] of items.entries()) {
      const slug = slugify(item.slug || item.title) || `speciality-${index + 1}`;
      await tx.speciality.create({
        data: {
          id: item.id || undefined,
          slug,
          title: item.title,
          description: item.detailDescription || item.shortDescription,
          shortDescription: item.shortDescription,
          detailTitle: item.detailTitle,
          detailDescription: item.detailDescription,
          icon: item.icon,
          imageUrl: item.image,
          services: item.services,
          doctorsData: item.doctors,
          featured: Boolean(item.featured),
          showInMenu: Boolean(item.showInMenu),
          status: toStatus(item.active),
          sortOrder: Number(item.sortOrder) || index + 1,
        },
      });
    }
  });

  return listSpecialities({ admin: true });
}

export async function resetSpecialities() {
  return replaceSpecialities(DEFAULT_SPECIALTIES);
}
