import "server-only";

import type { AdminRole } from "@prisma/client";
import { getCurrentAdminUser } from "@/lib/admin-session";

export const ADMIN_ROLE_OPTIONS = ["SUPER_ADMIN", "ADMIN", "EDITOR"] as const satisfies readonly AdminRole[];

export const ADMIN_ROLE_LABELS: Record<AdminRole, string> = {
  SUPER_ADMIN: "Super Admin",
  ADMIN: "Admin",
  EDITOR: "Editor",
};

export type SuperAdminUser = NonNullable<Awaited<ReturnType<typeof getCurrentAdminUser>>> & {
  role: AdminRole;
};

export type PermissionCheck =
  | { ok: true; admin: SuperAdminUser }
  | { ok: false; status: 401 | 403; message: string };

export function isValidAdminRole(role: unknown): role is AdminRole {
  return typeof role === "string" && ADMIN_ROLE_OPTIONS.includes(role as AdminRole);
}

export function isSuperAdminRole(role?: string | null) {
  return role === "SUPER_ADMIN";
}

export async function requireSuperAdminPermission(): Promise<PermissionCheck> {
  const admin = await getCurrentAdminUser();

  if (!admin) {
    return { ok: false, status: 401, message: "Admin login is required." };
  }

  if (!isSuperAdminRole(admin.role)) {
    return { ok: false, status: 403, message: "Only Super Admin can manage admin users." };
  }

  return { ok: true, admin: admin as SuperAdminUser };
}
