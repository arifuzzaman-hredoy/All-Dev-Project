import "server-only";

import { promises as fs } from "fs";
import path from "path";
import { db } from "@/lib/db";

const MAX_MEDIA_TAKE = 200;

export type AdminMediaAssetInput = {
  fileName: string;
  mimeType: string;
  size: number;
  url: string;
  altText?: string | null;
  folder?: string | null;
};

export type AdminMediaAssetView = {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
  url: string;
  altText: string;
  folder: string;
  createdAt: string;
  updatedAt: string;
};

function serializeMediaAsset(asset: {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
  url: string;
  altText: string | null;
  folder: string | null;
  createdAt: Date;
  updatedAt: Date;
}): AdminMediaAssetView {
  return {
    id: asset.id,
    fileName: asset.fileName,
    mimeType: asset.mimeType,
    size: asset.size,
    url: asset.url,
    altText: asset.altText || "",
    folder: asset.folder || "cms",
    createdAt: asset.createdAt.toISOString(),
    updatedAt: asset.updatedAt.toISOString(),
  };
}

function publicUrlToDiskPath(url: string) {
  const cleanUrl = url.split("?")[0]?.split("#")[0] || "";

  if (!cleanUrl.startsWith("/uploads/")) {
    return null;
  }

  const relativePath = cleanUrl.replace(/^\/+/, "");
  const resolvedPath = path.resolve(process.cwd(), "public", relativePath.replace(/^public\//, ""));
  const uploadsRoot = path.resolve(process.cwd(), "public", "uploads");

  if (!resolvedPath.startsWith(uploadsRoot)) {
    return null;
  }

  return resolvedPath;
}

export async function createMediaAsset(input: AdminMediaAssetInput) {
  const asset = await db.mediaAsset.create({
    data: {
      fileName: input.fileName,
      mimeType: input.mimeType,
      size: input.size,
      url: input.url,
      altText: input.altText?.trim() || null,
      folder: input.folder?.trim() || "cms",
    },
  });

  return serializeMediaAsset(asset);
}

export async function getAdminMediaAssets(options: { folder?: string; q?: string; take?: number } = {}) {
  const take = Math.min(Math.max(Number(options.take || MAX_MEDIA_TAKE), 1), MAX_MEDIA_TAKE);
  const folder = options.folder?.trim();
  const keyword = options.q?.trim();

  const assets = await db.mediaAsset.findMany({
    where: {
      ...(folder && folder !== "all" ? { folder } : {}),
      ...(keyword
        ? {
            OR: [
              { fileName: { contains: keyword, mode: "insensitive" } },
              { altText: { contains: keyword, mode: "insensitive" } },
              { url: { contains: keyword, mode: "insensitive" } },
              { folder: { contains: keyword, mode: "insensitive" } },
            ],
          }
        : {}),
    },
    take,
    orderBy: [{ createdAt: "desc" }, { fileName: "asc" }],
  });

  return assets.map(serializeMediaAsset);
}

export async function getMediaAssetCounts() {
  const [total, cms, hero] = await Promise.all([
    db.mediaAsset.count(),
    db.mediaAsset.count({ where: { folder: "cms" } }),
    db.mediaAsset.count({ where: { folder: "hero" } }),
  ]);

  return { total, cms, hero };
}

export async function updateMediaAsset(id: string, input: { altText?: unknown; folder?: unknown }) {
  const asset = await db.mediaAsset.update({
    where: { id },
    data: {
      ...(typeof input.altText === "string" ? { altText: input.altText.trim() || null } : {}),
      ...(typeof input.folder === "string" ? { folder: input.folder.trim() || "cms" } : {}),
    },
  });

  return serializeMediaAsset(asset);
}

export async function deleteMediaAsset(id: string) {
  const asset = await db.mediaAsset.delete({ where: { id } });
  const diskPath = publicUrlToDiskPath(asset.url);

  if (diskPath) {
    await fs.unlink(diskPath).catch((error: NodeJS.ErrnoException) => {
      if (error.code !== "ENOENT") {
        console.warn(`[media] Could not delete file ${diskPath}`, error);
      }
    });
  }

  return serializeMediaAsset(asset);
}
