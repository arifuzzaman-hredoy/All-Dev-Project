import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

const HASH_PREFIX = "scrypt";
const KEY_LENGTH = 64;
const SCRYPT_OPTIONS = {
  N: 16384,
  r: 8,
  p: 1,
  maxmem: 32 * 1024 * 1024,
} as const;

function safeEqual(left: Buffer, right: Buffer) {
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export function hashAdminPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, KEY_LENGTH, SCRYPT_OPTIONS).toString(
    "hex",
  );

  return [
    HASH_PREFIX,
    SCRYPT_OPTIONS.N,
    SCRYPT_OPTIONS.r,
    SCRYPT_OPTIONS.p,
    salt,
    hash,
  ].join("$");
}

export function verifyAdminPassword(password: string, passwordHash: string) {
  const [prefix, rawN, rawR, rawP, salt, expectedHash] = passwordHash.split("$");

  if (prefix !== HASH_PREFIX || !salt || !expectedHash) return false;

  const N = Number(rawN);
  const r = Number(rawR);
  const p = Number(rawP);

  if (!Number.isFinite(N) || !Number.isFinite(r) || !Number.isFinite(p)) {
    return false;
  }

  const actualHash = scryptSync(password, salt, KEY_LENGTH, {
    N,
    r,
    p,
    maxmem: 32 * 1024 * 1024,
  }).toString("hex");

  return safeEqual(Buffer.from(actualHash, "hex"), Buffer.from(expectedHash, "hex"));
}
