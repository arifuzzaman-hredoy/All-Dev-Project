export type PaymentMethod =
  | "bKash"
  | "Nagad"
  | "Rocket"
  | "Upay"
  | "Cash Request";

export type PaymentStatus =
  | "Payment Submitted"
  | "Cash Request"
  | "Verified"
  | "Rejected";

export type PackageBooking = {
  id: string;
  token: string;
  receiptNo: string;
  packageSlug: string;
  packageName: string;
  packageTarget: string;
  packageFee: string;
  patientName: string;
  phone: string;
  age: string;
  gender: string;
  diseaseProblem: string;
  address: string;
  email: string;
  paymentMethod: PaymentMethod;
  paymentNumber: string;
  transactionId: string;
  amountPaid: string;
  paymentStatus: PaymentStatus;
  requestNote: string;
  submittedAt: string;
  updatedAt: string;
};

export const PACKAGE_BOOKINGS_STORAGE_KEY =
  "update-diagnostic-center-package-bookings";

export function makeBookingId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }

  return `booking-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function makeToken() {
  const date = new Date();
  const yy = String(date.getFullYear()).slice(2);
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  const random = Math.floor(100000 + Math.random() * 900000);

  return `PKG-${yy}${mm}${dd}-${random}`;
}

export function makeReceiptNo() {
  const date = new Date();
  const yy = String(date.getFullYear()).slice(2);
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  const random = Math.floor(1000 + Math.random() * 9000);

  return `RCP-${yy}${mm}${dd}-${random}`;
}

export function normalizePackageBooking(item: Partial<PackageBooking>) {
  const now = new Date().toISOString();

  return {
    id: item.id || makeBookingId(),
    token: item.token || makeToken(),
    receiptNo: item.receiptNo || makeReceiptNo(),
    packageSlug: item.packageSlug || "",
    packageName: item.packageName || "",
    packageTarget: item.packageTarget || "",
    packageFee: item.packageFee || "",
    patientName: item.patientName || "",
    phone: item.phone || "",
    age: item.age || "",
    gender: item.gender || "",
    diseaseProblem: item.diseaseProblem || "",
    address: item.address || "",
    email: item.email || "",
    paymentMethod: item.paymentMethod || "Cash Request",
    paymentNumber: item.paymentNumber || "",
    transactionId: item.transactionId || "",
    amountPaid: item.amountPaid || "",
    paymentStatus: item.paymentStatus || "Payment Submitted",
    requestNote: item.requestNote || "",
    submittedAt: item.submittedAt || now,
    updatedAt: item.updatedAt || now,
  } satisfies PackageBooking;
}

export async function fetchPackageBookings() {
  const response = await fetch("/api/admin/package-bookings", { cache: "no-store" });

  if (!response.ok) throw new Error("Failed to load package bookings.");

  const data = (await response.json()) as { bookings?: Partial<PackageBooking>[] };
  return (data.bookings || []).map(normalizePackageBooking);
}

export async function addPackageBooking(booking: PackageBooking) {
  const response = await fetch("/api/package-bookings", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(booking),
  });

  if (!response.ok) throw new Error("Failed to submit package booking.");

  const data = (await response.json()) as { booking: Partial<PackageBooking> };
  return normalizePackageBooking(data.booking);
}

export async function deletePackageBooking(id: string) {
  const response = await fetch(`/api/admin/package-bookings/${id}`, {
    method: "DELETE",
  });

  if (!response.ok) throw new Error("Failed to delete package booking.");
}

export async function updatePackageBookingStatus(
  id: string,
  status: PaymentStatus
) {
  const response = await fetch(`/api/admin/package-bookings/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ paymentStatus: status }),
  });

  if (!response.ok) throw new Error("Failed to update package booking status.");

  const data = (await response.json()) as { booking: Partial<PackageBooking> };
  return normalizePackageBooking(data.booking);
}

export function getPackageBookingsFromStorage(): PackageBooking[] {
  return [];
}

export function savePackageBookingsToStorage(_bookings: PackageBooking[]) {
  void _bookings;
  // Deprecated in Phase 3.4. Package bookings are now saved through API + Prisma.
}

export function formatDateTime(value: string) {
  try {
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    }).format(new Date(value));
  } catch {
    return value;
  }
}
