import { prisma } from "@/lib/db";
import {
  DEFAULT_SITE_SETTINGS,
  type SiteSettings,
} from "@/lib/site-settings-types";

export const SITE_SETTINGS_KEY = "site.settings";

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function normalizeSiteSettings(value: unknown): SiteSettings {
  if (!isObject(value)) return DEFAULT_SITE_SETTINGS;
  return { ...DEFAULT_SITE_SETTINGS, ...value } as SiteSettings;
}

export async function getSiteSettings(): Promise<SiteSettings> {
  const row = await prisma.siteSetting.findUnique({
    where: { key: SITE_SETTINGS_KEY },
  });

  return normalizeSiteSettings(row?.value);
}

export async function saveSiteSettings(settings: SiteSettings) {
  const normalized = normalizeSiteSettings(settings);

  await prisma.siteSetting.upsert({
    where: { key: SITE_SETTINGS_KEY },
    update: { value: normalized },
    create: {
      key: SITE_SETTINGS_KEY,
      value: normalized,
    },
  });

  return normalized;
}

export async function resetSiteSettings() {
  await prisma.siteSetting.upsert({
    where: { key: SITE_SETTINGS_KEY },
    update: { value: DEFAULT_SITE_SETTINGS },
    create: {
      key: SITE_SETTINGS_KEY,
      value: DEFAULT_SITE_SETTINGS,
    },
  });

  return DEFAULT_SITE_SETTINGS;
}


export async function getPublicSiteSettings(): Promise<SiteSettings> {
  try {
    return await getSiteSettings();
  } catch {
    return DEFAULT_SITE_SETTINGS;
  }
}
