import "server-only";

type RateLimitRecord = {
  count: number;
  firstSeenAt: number;
  blockedUntil: number;
};

export type PublicRateLimitResult = {
  ok: boolean;
  retryAfterSeconds: number;
};

const DEFAULT_WINDOW_MS = 10 * 60 * 1000;
const DEFAULT_BLOCK_MS = 15 * 60 * 1000;
const DEFAULT_MAX_ATTEMPTS = 8;

const globalForPublicRateLimit = globalThis as unknown as {
  publicMutationRateLimit?: Map<string, RateLimitRecord>;
};

const buckets =
  globalForPublicRateLimit.publicMutationRateLimit ??
  new Map<string, RateLimitRecord>();

globalForPublicRateLimit.publicMutationRateLimit = buckets;

function now() {
  return Date.now();
}

export function getRequestIp(request: Request) {
  const forwardedFor = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const realIp = request.headers.get("x-real-ip")?.trim();
  const cfConnectingIp = request.headers.get("cf-connecting-ip")?.trim();

  return cfConnectingIp || realIp || forwardedFor || "local";
}

export function checkPublicMutationRateLimit(
  request: Request,
  action: string,
  options: {
    windowMs?: number;
    blockMs?: number;
    maxAttempts?: number;
  } = {},
): PublicRateLimitResult {
  const windowMs = options.windowMs ?? DEFAULT_WINDOW_MS;
  const blockMs = options.blockMs ?? DEFAULT_BLOCK_MS;
  const maxAttempts = options.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;
  const current = now();
  const key = `${action}:${getRequestIp(request)}`;
  const existing = buckets.get(key);

  if (existing?.blockedUntil && existing.blockedUntil > current) {
    return {
      ok: false,
      retryAfterSeconds: Math.ceil((existing.blockedUntil - current) / 1000),
    };
  }

  const record =
    existing && current - existing.firstSeenAt <= windowMs
      ? existing
      : { count: 0, firstSeenAt: current, blockedUntil: 0 };

  record.count += 1;

  if (record.count > maxAttempts) {
    record.blockedUntil = current + blockMs;
    buckets.set(key, record);
    return {
      ok: false,
      retryAfterSeconds: Math.ceil(blockMs / 1000),
    };
  }

  buckets.set(key, record);

  return { ok: true, retryAfterSeconds: 0 };
}
