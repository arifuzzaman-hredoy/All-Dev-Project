import "server-only";

import { randomUUID } from "crypto";

import { db } from "@/lib/db";
import {
  WHY_CHOOSE_ICON_NAMES,
  type WhyChooseIconName,
  type WhyChooseSection,
  type WhyChooseSpeciality,
} from "@/types/home-why-choose";

export const WHY_CHOOSE_SECTION_ID = "why-choose-main";

const defaultSection: WhyChooseSection = {
  title: "Why Choose Update Diagnostic Center Rangpur",
  description:
    "Update Diagnostic Center is a modern multi-disciplinary healthcare provider committed to improving healthcare quality and patient safety. Our hospital is equipped with advanced diagnostic services, modern clinical support, compassionate service, and a dedicated team of experienced doctors, nurses, and technicians across various medical disciplines.",
  imageUrl: "/pasent.jpeg",
  updatedAt: "2026-06-01T00:00:00.000Z",
  specialities: [
    { id: "accident-emergency", title: "Accident & Emergency", iconName: "Ambulance", isActive: true, sortOrder: 1 },
    { id: "anesthesia-pain", title: "Anesthesia and Pain Medicine", iconName: "Syringe", isActive: true, sortOrder: 2 },
    { id: "cancer-care", title: "Cancer Care Centre", iconName: "Ribbon", isActive: true, sortOrder: 3 },
    { id: "cardiology-care", title: "Cardiology Care Centre", iconName: "HeartPulse", isActive: true, sortOrder: 4 },
    { id: "cardiothoracic", title: "Cardiothoracic & Vascular Surgery", iconName: "Heart", isActive: true, sortOrder: 5 },
    { id: "child-development", title: "Child Development Centre", iconName: "Baby", isActive: true, sortOrder: 6 },
    { id: "critical-care", title: "Critical Care Units", iconName: "Hospital", isActive: true, sortOrder: 7 },
    { id: "dental-surgery", title: "Dental & Maxillofacial Surgery", iconName: "Smile", isActive: true, sortOrder: 8 },
  ],
};

function cleanText(value: unknown, fallback = "") {
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

function cleanNumber(value: unknown, fallback = 0) {
  const numberValue = Number(value);
  return Number.isFinite(numberValue) ? numberValue : fallback;
}

function cleanIconName(value: unknown): WhyChooseIconName {
  if (
    typeof value === "string" &&
    WHY_CHOOSE_ICON_NAMES.includes(value as WhyChooseIconName)
  ) {
    return value as WhyChooseIconName;
  }

  return "HeartPulse";
}

function normalizeSpeciality(
  item: Partial<WhyChooseSpeciality>,
  index: number,
): WhyChooseSpeciality {
  return {
    id: cleanText(item.id) || `speciality-${randomUUID()}`,
    title: cleanText(item.title, "New Speciality"),
    iconName: cleanIconName(item.iconName),
    isActive: typeof item.isActive === "boolean" ? item.isActive : true,
    sortOrder: cleanNumber(item.sortOrder, index + 1),
  };
}

function getStatsValue(value: unknown, key: string, fallback = "") {
  if (!value || typeof value !== "object" || Array.isArray(value)) return fallback;
  const record = value as Record<string, unknown>;
  return cleanText(record[key], fallback);
}

function normalizeSection(input: Partial<WhyChooseSection>): WhyChooseSection {
  const specialities = Array.isArray(input.specialities)
    ? input.specialities
        .map((item, index) => normalizeSpeciality(item, index))
        .filter((item) => item.title)
    : defaultSection.specialities;

  return {
    title: cleanText(input.title, defaultSection.title),
    description: cleanText(input.description, defaultSection.description),
    imageUrl: cleanText(input.imageUrl, defaultSection.imageUrl),
    specialities: specialities.length ? specialities : defaultSection.specialities,
    updatedAt: cleanText(input.updatedAt, new Date().toISOString()),
  };
}

export async function getWhyChooseSection(): Promise<WhyChooseSection> {
  const row = await db.whyChooseSection.findUnique({
    where: { id: WHY_CHOOSE_SECTION_ID },
    include: { items: { orderBy: { sortOrder: "asc" } } },
  });

  if (!row) {
    return saveWhyChooseSection(defaultSection);
  }

  return normalizeSection({
    title: row.title,
    description: row.description || "",
    imageUrl: getStatsValue(row.stats, "imageUrl", defaultSection.imageUrl),
    updatedAt: getStatsValue(row.stats, "updatedAt", row.updatedAt.toISOString()),
    specialities: row.items.map((item) => ({
      id: item.id,
      title: item.title,
      iconName: cleanIconName(item.icon),
      isActive: item.isActive,
      sortOrder: item.sortOrder,
    })),
  });
}

export async function saveWhyChooseSection(
  input: Partial<WhyChooseSection>,
): Promise<WhyChooseSection> {
  const section = normalizeSection({
    ...input,
    updatedAt: new Date().toISOString(),
  });

  await db.$transaction(async (tx) => {
    await tx.whyChooseSection.upsert({
      where: { id: WHY_CHOOSE_SECTION_ID },
      update: {
        title: section.title,
        description: section.description,
        stats: {
          imageUrl: section.imageUrl,
          updatedAt: section.updatedAt,
        },
      },
      create: {
        id: WHY_CHOOSE_SECTION_ID,
        title: section.title,
        description: section.description,
        stats: {
          imageUrl: section.imageUrl,
          updatedAt: section.updatedAt,
        },
      },
    });

    await tx.whyChooseSpeciality.deleteMany({
      where: { sectionId: WHY_CHOOSE_SECTION_ID },
    });

    for (const [index, item] of section.specialities.entries()) {
      await tx.whyChooseSpeciality.create({
        data: {
          id: item.id || `speciality-${randomUUID()}`,
          sectionId: WHY_CHOOSE_SECTION_ID,
          title: item.title,
          icon: item.iconName,
          isActive: item.isActive,
          sortOrder: cleanNumber(item.sortOrder, index + 1),
        },
      });
    }
  });

  return section;
}
