export type DoctorProfile = {
  id: string;
  name: string;
  designation: string;
  department: string;
  specialist: string;
  experienceYears: number;
  availableDays: string[];
  consultationTime: string;
  room: string;
  fee: number;
  imageUrl: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export type DoctorProfileInput = {
  name: string;
  designation: string;
  department: string;
  specialist: string;
  experienceYears: number;
  availableDays: string[];
  consultationTime: string;
  room: string;
  fee: number;
  imageUrl: string;
  isActive: boolean;
  sortOrder: number;
};
