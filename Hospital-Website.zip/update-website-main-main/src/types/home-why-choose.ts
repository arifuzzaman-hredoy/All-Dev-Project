export const WHY_CHOOSE_ICON_NAMES = [
  "Ambulance",
  "Syringe",
  "Ribbon",
  "HeartPulse",
  "Heart",
  "Stethoscope",
  "Baby",
  "Users",
  "Hospital",
  "Smile",
  "UserRoundCheck",
  "FlaskConical",
  "Microscope",
  "Apple",
  "Headphones",
  "Activity",
  "Brain",
  "Bone",
  "Eye",
  "Ear",
  "ShieldCheck",
  "Pill",
  "Cross",
  "ClipboardPlus",
] as const;

export type WhyChooseIconName = (typeof WHY_CHOOSE_ICON_NAMES)[number];

export type WhyChooseSpeciality = {
  id: string;
  title: string;
  iconName: WhyChooseIconName;
  isActive: boolean;
  sortOrder: number;
};

export type WhyChooseSection = {
  title: string;
  description: string;
  imageUrl: string;
  specialities: WhyChooseSpeciality[];
  updatedAt: string;
};
