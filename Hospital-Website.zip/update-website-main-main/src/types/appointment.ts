export type AppointmentSource =
  | "PUBLIC_FORM"
  | "ADMIN_MANUAL"
  | "PHONE_CALL"
  | "IMPORTED"
  | "SYSTEM";

export type AppointmentRecord = {
  id: string;
  token: string;
  patientName: string;
  phone: string;
  patientEmail?: string;
  age: string;
  gender: string;
  disease: string;
  doctorId: string;
  department: string;
  doctorName: string;
  doctorDesignation: string;
  specialist: string;
  doctorAvailableDays: string[];
  appointmentTime: string;
  room: string;
  fee: number;
  source?: AppointmentSource | string;
  smsStatus?: string;
  submittedAt: string;
};

export type AppointmentSubmissionInput = {
  patientName: string;
  phone: string;
  age: string;
  gender: string;
  disease: string;
  doctorId: string;
  department: string;
  doctorName: string;
  doctorDesignation: string;
  specialist: string;
  doctorAvailableDays: string[];
  appointmentTime: string;
  room: string;
  fee: number;
};

export type ManualAppointmentSource = "PHONE_CALL" | "ADMIN_MANUAL";

export type ManualAppointmentDoctor = {
  id: string;
  name: string;
  designation: string;
  department: string;
  specialist: string;
  availableDays: string[];
  consultationTime: string;
  room: string;
  fee: number;
};

export type ManualAppointmentInput = {
  patientName: string;
  phone: string;
  patientEmail?: string;
  age: string;
  gender: string;
  disease: string;
  doctorId?: string;
  department: string;
  doctorName?: string;
  doctorDesignation?: string;
  specialist?: string;
  doctorAvailableDays: string[];
  appointmentTime: string;
  room: string;
  fee: number;
  source: ManualAppointmentSource;
  message?: string;
};
