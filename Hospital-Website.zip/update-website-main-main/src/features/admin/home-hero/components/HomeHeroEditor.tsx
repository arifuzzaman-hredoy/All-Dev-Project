"use client";

import Image from "next/image";
import clsx from "clsx";
import {
  Activity,
  ArrowDown,
  ArrowUp,
  CalendarCheck,
  FileText,
  Headphones,
  ImagePlus,
  Plus,
  Save,
  Stethoscope,
  Trash2,
  Users,
  type LucideIcon,
} from "lucide-react";
import { useMemo, useState, useTransition } from "react";
import { saveHomeHeroAction } from "@/features/admin/home-hero/actions";
import { normalizeHomeHeroContent } from "@/features/home-hero/defaults";
import {
  homeHeroIconKeys,
  type HomeHeroContent,
  type HomeHeroIconKey,
} from "@/features/home-hero/types";

type HomeHeroEditorProps = {
  initialContent: HomeHeroContent;
};

const iconMap: Record<HomeHeroIconKey, LucideIcon> = {
  Stethoscope,
  CalendarCheck,
  FileText,
  Headphones,
  Users,
  Activity,
};

const inputClass =
  "w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#0a4d8f] focus:ring-4 focus:ring-[#0a4d8f]/10";

const labelClass = "mb-2 block text-sm font-black text-slate-700";
const booleanCarouselFields = [
  { key: "autoplay", label: "Autoplay" },
  { key: "showArrows", label: "Show arrows" },
  { key: "showDots", label: "Show dots" },
] as const;

function newId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function sortByOrder<T extends { sortOrder: number }>(items: T[]) {
  return [...items].sort((a, b) => a.sortOrder - b.sortOrder);
}

function renumber<T extends { sortOrder: number }>(items: T[]) {
  return items.map((item, index) => ({ ...item, sortOrder: index + 1 }));
}

function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label className={labelClass}>{label}</label>
      {children}
      {hint ? (
        <p className="mt-2 text-xs font-semibold leading-5 text-slate-500">
          {hint}
        </p>
      ) : null}
    </div>
  );
}

async function uploadHeroImage(file: File) {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch("/api/admin/uploads/hero", {
    method: "POST",
    body: formData,
  });
  const result = (await response.json()) as {
    ok?: boolean;
    url?: string;
    message?: string;
  };

  if (!response.ok || !result.ok || !result.url) {
    throw new Error(result.message || "Upload failed.");
  }

  return result.url;
}

export default function HomeHeroEditor({
  initialContent,
}: HomeHeroEditorProps) {
  const [content, setContent] = useState(() =>
    normalizeHomeHeroContent(initialContent),
  );
  const [message, setMessage] = useState("");
  const [uploadingKey, setUploadingKey] = useState("");
  const [isPending, startTransition] = useTransition();

  const slides = useMemo(() => sortByOrder(content.slides), [content.slides]);
  const quickActions = useMemo(
    () => sortByOrder(content.quickActions),
    [content.quickActions],
  );

  function updateCarousel<K extends keyof HomeHeroContent["carousel"]>(
    key: K,
    value: HomeHeroContent["carousel"][K],
  ) {
    setContent((current) => ({
      ...current,
      carousel: { ...current.carousel, [key]: value },
    }));
  }

  function updateSlide<K extends keyof HomeHeroContent["slides"][number]>(
    id: string,
    key: K,
    value: HomeHeroContent["slides"][number][K],
  ) {
    setContent((current) => ({
      ...current,
      slides: current.slides.map((slide) =>
        slide.id === id ? { ...slide, [key]: value } : slide,
      ),
    }));
  }

  function updateQuickAction<
    K extends keyof HomeHeroContent["quickActions"][number],
  >(
    id: string,
    key: K,
    value: HomeHeroContent["quickActions"][number][K],
  ) {
    setContent((current) => ({
      ...current,
      quickActions: current.quickActions.map((action) =>
        action.id === id ? { ...action, [key]: value } : action,
      ),
    }));
  }

  function moveSlide(id: string, direction: -1 | 1) {
    setContent((current) => {
      const sorted = sortByOrder(current.slides);
      const index = sorted.findIndex((slide) => slide.id === id);
      const targetIndex = index + direction;

      if (index < 0 || targetIndex < 0 || targetIndex >= sorted.length) {
        return current;
      }

      const next = [...sorted];
      const [item] = next.splice(index, 1);
      next.splice(targetIndex, 0, item);

      return { ...current, slides: renumber(next) };
    });
  }

  function moveQuickAction(id: string, direction: -1 | 1) {
    setContent((current) => {
      const sorted = sortByOrder(current.quickActions);
      const index = sorted.findIndex((action) => action.id === id);
      const targetIndex = index + direction;

      if (index < 0 || targetIndex < 0 || targetIndex >= sorted.length) {
        return current;
      }

      const next = [...sorted];
      const [item] = next.splice(index, 1);
      next.splice(targetIndex, 0, item);

      return { ...current, quickActions: renumber(next) };
    });
  }

  function addSlide() {
    setContent((current) => ({
      ...current,
      slides: [
        ...current.slides,
        {
          id: newId("hero-slide"),
          title: "",
          subtitle: "",
          description: "",
          imageUrl: "",
          mobileImageUrl: "",
          imageAlt: "Homepage hero image",
          primaryButtonLabel: "",
          primaryButtonHref: "",
          secondaryButtonLabel: "",
          secondaryButtonHref: "",
          isActive: true,
          sortOrder: current.slides.length + 1,
        },
      ],
    }));
  }

  function deleteSlide(id: string) {
    setContent((current) => ({
      ...current,
      slides: renumber(current.slides.filter((slide) => slide.id !== id)),
    }));
  }

  function addQuickAction() {
    setContent((current) => ({
      ...current,
      quickActions: [
        ...current.quickActions,
        {
          id: newId("quick-action"),
          label: "New Action",
          href: "/",
          icon: "Stethoscope",
          isActive: true,
          sortOrder: current.quickActions.length + 1,
        },
      ],
    }));
  }

  function deleteQuickAction(id: string) {
    setContent((current) => ({
      ...current,
      quickActions: renumber(
        current.quickActions.filter((action) => action.id !== id),
      ),
    }));
  }

  async function handleUpload(
    file: File | undefined,
    key: string,
    onUploaded: (url: string) => void,
  ) {
    if (!file) return;

    setUploadingKey(key);
    setMessage("");

    try {
      const url = await uploadHeroImage(file);
      onUploaded(url);
      setMessage("Image uploaded.");
    } catch (caught) {
      setMessage(caught instanceof Error ? caught.message : "Upload failed.");
    } finally {
      setUploadingKey("");
    }
  }

  function save() {
    setMessage("");

    startTransition(async () => {
      const result = await saveHomeHeroAction(content);
      setMessage(result.message);
    });
  }

  return (
    <section className="grid gap-6 xl:grid-cols-[minmax(0,1.25fr)_380px]">
      <div className="space-y-6">
        <div className="rounded-[28px] border border-[#dbe8ff] bg-white p-5 shadow-[0_18px_50px_rgba(6,47,102,0.06)] sm:p-7">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">
            Homepage / Hero
          </p>
          <h2 className="mt-2 text-2xl font-bold text-[#062f66] sm:text-3xl">
            Homepage hero controls
          </h2>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-600 sm:text-base">
            Control only the public homepage carousel images, slider behavior,
            and fixed quick action cards.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <button
              type="button"
              onClick={save}
              disabled={isPending || Boolean(uploadingKey)}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 py-3 text-sm font-black text-white transition hover:bg-[#0a4d8f] disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
            >
              <Save size={16} />
              {isPending ? "Saving..." : "Save hero"}
            </button>
            {message ? (
              <p className="rounded-full bg-slate-100 px-4 py-3 text-sm font-bold text-slate-700">
                {message}
              </p>
            ) : null}
          </div>
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
          <h3 className="text-lg font-black text-[#062f66]">General</h3>
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <Field label="Welcome text">
              <input
                value={content.welcomeText}
                onChange={(event) =>
                  setContent((current) => ({
                    ...current,
                    welcomeText: event.target.value,
                  }))
                }
                className={inputClass}
              />
            </Field>
            <Field label="Hero logo URL" hint="Optional. Example: /update.png">
              <input
                value={content.heroLogoUrl || ""}
                onChange={(event) =>
                  setContent((current) => ({
                    ...current,
                    heroLogoUrl: event.target.value,
                  }))
                }
                className={inputClass}
              />
            </Field>
            <Field label="Hero logo alt text">
              <input
                value={content.heroLogoAlt || ""}
                onChange={(event) =>
                  setContent((current) => ({
                    ...current,
                    heroLogoAlt: event.target.value,
                  }))
                }
                className={inputClass}
              />
            </Field>
          </div>
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
          <h3 className="text-lg font-black text-[#062f66]">Carousel</h3>
          <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {booleanCarouselFields.map(({ key, label }) => (
              <button
                key={key}
                type="button"
                onClick={() =>
                  updateCarousel(key, !content.carousel[key])
                }
                className={clsx(
                  "rounded-2xl px-4 py-3 text-sm font-black transition",
                  content.carousel[key]
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-slate-100 text-slate-600",
                )}
              >
                {label}: {content.carousel[key] ? "On" : "Off"}
              </button>
            ))}
            <Field label="Speed (ms)">
              <input
                type="number"
                min={1500}
                max={30000}
                value={content.carousel.intervalMs}
                onChange={(event) =>
                  updateCarousel("intervalMs", Number(event.target.value))
                }
                className={inputClass}
              />
            </Field>
            <Field label="Overlay opacity">
              <input
                type="number"
                min={0}
                max={80}
                value={content.carousel.overlayOpacity}
                onChange={(event) =>
                  updateCarousel("overlayOpacity", Number(event.target.value))
                }
                className={inputClass}
              />
            </Field>
            <Field label="Desktop height">
              <input
                type="number"
                min={360}
                max={760}
                value={content.carousel.desktopHeight}
                onChange={(event) =>
                  updateCarousel("desktopHeight", Number(event.target.value))
                }
                className={inputClass}
              />
            </Field>
            <Field label="Mobile height">
              <input
                type="number"
                min={200}
                max={520}
                value={content.carousel.mobileHeight}
                onChange={(event) =>
                  updateCarousel("mobileHeight", Number(event.target.value))
                }
                className={inputClass}
              />
            </Field>
          </div>
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-lg font-black text-[#062f66]">Hero images</h3>
              <p className="mt-1 text-sm text-slate-500">
                Upload desktop/mobile images, reorder slides, and toggle active
                slides.
              </p>
            </div>
            <button
              type="button"
              onClick={addSlide}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#062f66] px-4 py-3 text-sm font-black text-white"
            >
              <Plus size={16} />
              Add slide
            </button>
          </div>

          <div className="mt-5 space-y-4">
            {slides.map((slide, index) => (
              <div
                key={slide.id}
                className="rounded-[24px] border border-slate-200 bg-[#f8fbff] p-4"
              >
                <div className="grid gap-4 lg:grid-cols-[220px_minmax(0,1fr)]">
                  <div>
                    <div className="relative h-32 overflow-hidden rounded-2xl bg-slate-200">
                      {slide.imageUrl ? (
                        <Image
                          src={slide.imageUrl}
                          alt={slide.imageAlt || "Hero preview"}
                          fill
                          sizes="220px"
                          className="object-cover"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-slate-400">
                          <ImagePlus size={30} />
                        </div>
                      )}
                    </div>
                    <div className="mt-3 grid gap-2">
                      <label className="inline-flex cursor-pointer items-center justify-center rounded-2xl bg-white px-3 py-2 text-xs font-black text-[#062f66] ring-1 ring-slate-200">
                        {uploadingKey === `${slide.id}-desktop`
                          ? "Uploading..."
                          : "Upload desktop image"}
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          className="sr-only"
                          onChange={(event) =>
                            handleUpload(
                              event.target.files?.[0],
                              `${slide.id}-desktop`,
                              (url) => updateSlide(slide.id, "imageUrl", url),
                            )
                          }
                        />
                      </label>
                      <label className="inline-flex cursor-pointer items-center justify-center rounded-2xl bg-white px-3 py-2 text-xs font-black text-[#062f66] ring-1 ring-slate-200">
                        {uploadingKey === `${slide.id}-mobile`
                          ? "Uploading..."
                          : "Upload mobile image"}
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          className="sr-only"
                          onChange={(event) =>
                            handleUpload(
                              event.target.files?.[0],
                              `${slide.id}-mobile`,
                              (url) =>
                                updateSlide(slide.id, "mobileImageUrl", url),
                            )
                          }
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          updateSlide(slide.id, "imageUrl", "");
                          updateSlide(slide.id, "mobileImageUrl", "");
                        }}
                        className="rounded-2xl bg-rose-50 px-3 py-2 text-xs font-black text-rose-700"
                      >
                        Remove image
                      </button>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <Field label="Desktop image URL">
                      <input
                        value={slide.imageUrl}
                        onChange={(event) =>
                          updateSlide(slide.id, "imageUrl", event.target.value)
                        }
                        className={inputClass}
                      />
                    </Field>
                    <Field label="Mobile image URL">
                      <input
                        value={slide.mobileImageUrl || ""}
                        onChange={(event) =>
                          updateSlide(
                            slide.id,
                            "mobileImageUrl",
                            event.target.value,
                          )
                        }
                        className={inputClass}
                      />
                    </Field>
                    <Field label="Image alt text">
                      <input
                        value={slide.imageAlt}
                        onChange={(event) =>
                          updateSlide(slide.id, "imageAlt", event.target.value)
                        }
                        className={inputClass}
                      />
                    </Field>
                    <Field label="Title">
                      <input
                        value={slide.title || ""}
                        onChange={(event) =>
                          updateSlide(slide.id, "title", event.target.value)
                        }
                        className={inputClass}
                      />
                    </Field>
                    <Field label="Primary button label">
                      <input
                        value={slide.primaryButtonLabel || ""}
                        onChange={(event) =>
                          updateSlide(
                            slide.id,
                            "primaryButtonLabel",
                            event.target.value,
                          )
                        }
                        className={inputClass}
                      />
                    </Field>
                    <Field label="Primary button URL">
                      <input
                        value={slide.primaryButtonHref || ""}
                        onChange={(event) =>
                          updateSlide(
                            slide.id,
                            "primaryButtonHref",
                            event.target.value,
                          )
                        }
                        className={inputClass}
                      />
                    </Field>
                    <div className="flex flex-wrap gap-2 md:col-span-2">
                      <button
                        type="button"
                        onClick={() =>
                          updateSlide(slide.id, "isActive", !slide.isActive)
                        }
                        className={clsx(
                          "rounded-2xl px-4 py-3 text-sm font-black",
                          slide.isActive
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-amber-50 text-amber-700",
                        )}
                      >
                        {slide.isActive ? "Active" : "Inactive"}
                      </button>
                      <button
                        type="button"
                        onClick={() => moveSlide(slide.id, -1)}
                        disabled={index === 0}
                        className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm font-black text-slate-700 ring-1 ring-slate-200 disabled:opacity-40"
                      >
                        <ArrowUp size={15} />
                        Up
                      </button>
                      <button
                        type="button"
                        onClick={() => moveSlide(slide.id, 1)}
                        disabled={index === slides.length - 1}
                        className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm font-black text-slate-700 ring-1 ring-slate-200 disabled:opacity-40"
                      >
                        <ArrowDown size={15} />
                        Down
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteSlide(slide.id)}
                        className="inline-flex items-center gap-2 rounded-2xl bg-rose-50 px-4 py-3 text-sm font-black text-rose-700"
                      >
                        <Trash2 size={15} />
                        Delete slide
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-lg font-black text-[#062f66]">
                Quick action cards
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                These cards stay fixed while carousel images change.
              </p>
            </div>
            <button
              type="button"
              onClick={addQuickAction}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#062f66] px-4 py-3 text-sm font-black text-white"
            >
              <Plus size={16} />
              Add card
            </button>
          </div>

          <div className="mt-5 space-y-4">
            {quickActions.map((action, index) => {
              const Icon = iconMap[action.icon];

              return (
                <div
                  key={action.id}
                  className="rounded-[24px] border border-slate-200 bg-[#f8fbff] p-4"
                >
                  <div className="grid gap-4 md:grid-cols-[1fr_1fr_170px]">
                    <Field label="Card text">
                      <input
                        value={action.label}
                        onChange={(event) =>
                          updateQuickAction(
                            action.id,
                            "label",
                            event.target.value,
                          )
                        }
                        className={inputClass}
                      />
                    </Field>
                    <Field label="Card link">
                      <input
                        value={action.href}
                        onChange={(event) =>
                          updateQuickAction(
                            action.id,
                            "href",
                            event.target.value,
                          )
                        }
                        className={inputClass}
                      />
                    </Field>
                    <Field label="Icon">
                      <select
                        value={action.icon}
                        onChange={(event) =>
                          updateQuickAction(
                            action.id,
                            "icon",
                            event.target.value as HomeHeroIconKey,
                          )
                        }
                        className={inputClass}
                      >
                        {homeHeroIconKeys.map((key) => (
                          <option key={key} value={key}>
                            {key}
                          </option>
                        ))}
                      </select>
                    </Field>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    <span className="grid size-11 place-items-center rounded-full bg-[#062f66] text-white">
                      <Icon size={20} />
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        updateQuickAction(
                          action.id,
                          "isActive",
                          !action.isActive,
                        )
                      }
                      className={clsx(
                        "rounded-2xl px-4 py-3 text-sm font-black",
                        action.isActive
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-amber-50 text-amber-700",
                      )}
                    >
                      {action.isActive ? "Active" : "Inactive"}
                    </button>
                    <button
                      type="button"
                      onClick={() => moveQuickAction(action.id, -1)}
                      disabled={index === 0}
                      className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm font-black text-slate-700 ring-1 ring-slate-200 disabled:opacity-40"
                    >
                      <ArrowUp size={15} />
                      Up
                    </button>
                    <button
                      type="button"
                      onClick={() => moveQuickAction(action.id, 1)}
                      disabled={index === quickActions.length - 1}
                      className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm font-black text-slate-700 ring-1 ring-slate-200 disabled:opacity-40"
                    >
                      <ArrowDown size={15} />
                      Down
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteQuickAction(action.id)}
                      className="inline-flex items-center gap-2 rounded-2xl bg-rose-50 px-4 py-3 text-sm font-black text-rose-700"
                    >
                      <Trash2 size={15} />
                      Delete card
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-[26px] border border-[#dbe8ff] bg-[#062f66] p-5 text-white shadow-[0_18px_45px_rgba(6,47,102,0.16)]">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-cyan-200">
            Live summary
          </p>
          <div className="mt-4 space-y-3 text-sm text-cyan-50">
            <p>{slides.filter((slide) => slide.isActive).length} active slides</p>
            <p>
              {quickActions.filter((action) => action.isActive).length} active
              quick action cards
            </p>
            <p>
              Autoplay {content.carousel.autoplay ? "on" : "off"} every{" "}
              {content.carousel.intervalMs}ms
            </p>
          </div>
        </div>

        <div className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)]">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">
            Upload rules
          </p>
          <p className="mt-3 text-sm leading-7 text-slate-600">
            JPG, PNG, and WEBP only. Maximum size is 5MB. Uploaded files are
            stored in <span className="font-bold">public/uploads/hero</span>.
          </p>
        </div>
      </aside>
    </section>
  );
}
