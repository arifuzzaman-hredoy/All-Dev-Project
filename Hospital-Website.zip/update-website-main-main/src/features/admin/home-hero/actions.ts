"use server";

import { revalidatePath } from "next/cache";
import { requireAdminSession } from "@/lib/admin-session";
import { saveHomeHeroContent } from "@/lib/home-hero-db";
import { recordAuditLog } from "@/lib/audit-log";
import type { HomeHeroContent } from "@/features/home-hero/types";

export type HomeHeroActionState = {
  status: "idle" | "success" | "error";
  message: string;
};

export async function saveHomeHeroAction(
  content: HomeHeroContent,
): Promise<HomeHeroActionState> {
  try {
    await requireAdminSession();
    await saveHomeHeroContent(content);
    await recordAuditLog({
      action: "HOME_HERO_UPDATE",
      entity: "HomeHero",
      entityId: "home-hero",
      metadata: { slides: content.slides?.length ?? 0 },
    });

    revalidatePath("/");
    revalidatePath("/admin/sections/home-hero");
    revalidatePath("/admin/sections/home-quick-actions");

    return {
      status: "success",
      message: "Homepage hero updated.",
    };
  } catch (caught) {
    return {
      status: "error",
      message:
        caught instanceof Error ? caught.message : "Could not save hero.",
    };
  }
}
