import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import type { AdminService } from "./types";
import type { ServiceInput } from "./schema";

type ServiceWithRelations = Prisma.ServiceGetPayload<{
  include: { features: true; faqs: true };
}>;

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => String(item || "").trim()).filter(Boolean);
}

function toGallery(value: unknown): string[] {
  return toStringArray(value);
}

function normalizeStatus(active?: boolean, status?: string) {
  if (active === false || status === "draft") return "DRAFT" as const;
  return "PUBLISHED" as const;
}

function mapDbService(service: ServiceWithRelations): AdminService {
  const galleryImages = toGallery(service.galleryImages);
  const highlights = toStringArray(service.highlights);
  const facilities = toStringArray(service.facilities);
  const symptoms = toStringArray(service.symptoms);
  const active = service.status === "PUBLISHED";
  const featuredImage = service.featuredImage || service.imageUrl || "";
  const priceRange = service.priceRange || service.priceText || "";
  const shortDescription =
    service.shortDescription || service.description || service.subtitle || "";
  const fullDescription =
    service.fullDescription || service.description || service.overview || "";

  return {
    id: service.id,
    slug: service.slug,
    title: service.title,
    subtitle: service.subtitle || shortDescription,
    shortDescription,
    overview: service.overview || fullDescription,
    fullDescription,
    featuredImage,
    imageUrl: featuredImage,
    galleryImages,
    icon: service.icon || "activity",
    priceRange,
    priceNote: priceRange,
    duration: service.duration || "",
    availableTime: service.availableTime || "",
    doctorName: service.doctorName || "",
    doctorTitle: service.doctorTitle || "",
    phone: service.phone || "10666",
    order: service.sortOrder,
    sortOrder: service.sortOrder,
    active,
    status: active ? "active" : "draft",
    featured: service.featured,
    highlights: highlights.length
      ? highlights
      : service.features.map((feature) => feature.title).filter(Boolean),
    facilities,
    symptoms,
    faqs: service.faqs
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((faq) => ({ question: faq.question, answer: faq.answer })),
    seoTitle: service.seoTitle || service.title,
    seoDescription: service.seoDescription || shortDescription,
    createdAt: service.createdAt.toISOString(),
    updatedAt: service.updatedAt.toISOString(),
  };
}

function cleanStringArray(values?: string[]) {
  return Array.isArray(values)
    ? values.map((item) => item.trim()).filter(Boolean)
    : [];
}

function cleanFaqs(input: ServiceInput) {
  return (input.faqs || [])
    .map((faq) => ({
      question: String(faq.question || "").trim(),
      answer: String(faq.answer || "").trim(),
    }))
    .filter((faq) => faq.question || faq.answer);
}

function toServiceData(input: ServiceInput) {
  const shortDescription = String(
    input.shortDescription || input.subtitle || "",
  ).trim();
  const fullDescription = String(
    input.fullDescription || input.overview || shortDescription,
  ).trim();
  const featuredImage = String(
    input.imageUrl || input.featuredImage || "",
  ).trim();
  const priceRange = String(input.priceNote || input.priceRange || "").trim();
  const sortOrder = Number(input.sortOrder ?? input.order ?? 0) || 0;

  return {
    slug: String(input.slug || "").trim(),
    title: String(input.title || "").trim(),
    subtitle: String(input.subtitle || shortDescription).trim(),
    description: shortDescription,
    shortDescription,
    overview: String(input.overview || fullDescription).trim(),
    fullDescription,
    icon: String(input.icon || "activity").trim(),
    imageUrl: featuredImage,
    featuredImage,
    galleryImages: cleanStringArray(input.galleryImages),
    priceText: priceRange,
    priceRange,
    duration: String(input.duration || "").trim(),
    availableTime: String(input.availableTime || "").trim(),
    doctorName: String(input.doctorName || "").trim(),
    doctorTitle: String(input.doctorTitle || "").trim(),
    phone: String(input.phone || "10666").trim(),
    featured: Boolean(input.featured),
    highlights: cleanStringArray(input.highlights),
    facilities: cleanStringArray(input.facilities),
    symptoms: cleanStringArray(input.symptoms),
    seoTitle: String(input.seoTitle || input.title || "").trim(),
    seoDescription: String(input.seoDescription || shortDescription).trim(),
    status: normalizeStatus(input.active, input.status),
    sortOrder,
  };
}

async function findByIdOrSlug(id: string) {
  return prisma.service.findFirst({
    where: { OR: [{ id }, { slug: id }] },
    include: { features: true, faqs: true },
  });
}

export async function getAdminServices() {
  const services = await prisma.service.findMany({
    include: { features: true, faqs: true },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });

  return services.map(mapDbService);
}

export async function getAdminService(id: string) {
  const service = await findByIdOrSlug(id);
  return service ? mapDbService(service) : null;
}

async function assertSlugAvailable(slug: string, id?: string) {
  const existing = await prisma.service.findUnique({ where: { slug } });

  if (existing && existing.id !== id) {
    throw new Error("A service with this slug already exists.");
  }
}

async function syncRelations(serviceId: string, input: ServiceInput) {
  const highlights = cleanStringArray(input.highlights);
  const faqs = cleanFaqs(input);

  await prisma.serviceFeature.deleteMany({ where: { serviceId } });
  await prisma.serviceFaq.deleteMany({ where: { serviceId } });

  if (highlights.length > 0) {
    await prisma.serviceFeature.createMany({
      data: highlights.map((title, index) => ({
        serviceId,
        title,
        text: "",
        sortOrder: index + 1,
      })),
    });
  }

  if (faqs.length > 0) {
    await prisma.serviceFaq.createMany({
      data: faqs.map((faq, index) => ({
        serviceId,
        question: faq.question,
        answer: faq.answer,
        sortOrder: index + 1,
      })),
    });
  }
}

export async function createService(input: ServiceInput) {
  const data = toServiceData(input);

  if (!data.title) throw new Error("Service title is required.");
  if (!data.slug) throw new Error("Service slug is required.");

  await assertSlugAvailable(data.slug);

  const service = await prisma.service.create({ data });
  await syncRelations(service.id, input);

  const created = await getAdminService(service.id);
  if (!created) throw new Error("Service was created but could not be loaded.");
  return created;
}

export async function updateService(id: string, input: ServiceInput) {
  const existing = await findByIdOrSlug(id);

  if (!existing) {
    throw new Error("Service was not found.");
  }

  const data = toServiceData(input);

  if (!data.title) throw new Error("Service title is required.");
  if (!data.slug) throw new Error("Service slug is required.");

  await assertSlugAvailable(data.slug, existing.id);

  await prisma.service.update({
    where: { id: existing.id },
    data,
  });

  await syncRelations(existing.id, input);

  const updated = await getAdminService(existing.id);
  if (!updated) throw new Error("Service was updated but could not be loaded.");
  return updated;
}

export async function deleteService(id: string) {
  const existing = await findByIdOrSlug(id);

  if (!existing) {
    throw new Error("Service was not found.");
  }

  await prisma.service.delete({ where: { id: existing.id } });
}

export async function setServiceActive(id: string, active: boolean) {
  const existing = await findByIdOrSlug(id);

  if (!existing) {
    throw new Error("Service was not found.");
  }

  await prisma.service.update({
    where: { id: existing.id },
    data: { status: active ? "PUBLISHED" : "DRAFT" },
  });
}

export async function reorderServices(items: { id: string; sortOrder: number }[]) {
  await prisma.$transaction(
    items.map((item) =>
      prisma.service.update({
        where: { id: item.id },
        data: { sortOrder: item.sortOrder },
      }),
    ),
  );
}

export async function replaceServices(services: ServiceInput[]) {
  await prisma.$transaction(async (tx) => {
    await tx.serviceFaq.deleteMany();
    await tx.serviceFeature.deleteMany();
    await tx.service.deleteMany();

    for (const [index, service] of services.entries()) {
      const data = toServiceData({ ...service, sortOrder: index + 1, order: index + 1 });

      const created = await tx.service.create({
        data: {
          id: service.id || undefined,
          ...data,
        },
      });

      const highlights = cleanStringArray(service.highlights);
      const faqs = cleanFaqs(service);

      if (highlights.length > 0) {
        await tx.serviceFeature.createMany({
          data: highlights.map((title, featureIndex) => ({
            serviceId: created.id,
            title,
            text: "",
            sortOrder: featureIndex + 1,
          })),
        });
      }

      if (faqs.length > 0) {
        await tx.serviceFaq.createMany({
          data: faqs.map((faq, faqIndex) => ({
            serviceId: created.id,
            question: faq.question,
            answer: faq.answer,
            sortOrder: faqIndex + 1,
          })),
        });
      }
    }
  });

  return getAdminServices();
}
