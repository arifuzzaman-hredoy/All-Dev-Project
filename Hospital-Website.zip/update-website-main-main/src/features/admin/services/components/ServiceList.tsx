import Link from "next/link";
import { ExternalLink, Pencil } from "lucide-react";
import type { AdminService } from "../types";
import ServiceDeleteButton from "./ServiceDeleteButton";
import ServiceStatusToggle from "./ServiceStatusToggle";

type ServiceListProps = {
  services: AdminService[];
  selectedId?: string;
};

export default function ServiceList({ services, selectedId }: ServiceListProps) {
  if (services.length === 0) {
    return (
      <div className="rounded-[28px] border border-dashed border-slate-300 bg-white p-8 text-center">
        <h2 className="text-lg font-black text-[#062f66]">No services yet</h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          Create the first service to publish it on the public services page.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.05)]">
      <div className="border-b border-slate-200 px-5 py-4">
        <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
          Service library
        </p>
        <h2 className="mt-1 text-xl font-black text-[#062f66]">
          {services.length} managed services
        </h2>
      </div>

      <div className="divide-y divide-slate-100">
        {services.map((service) => (
          <article
            key={service.id}
            className={[
              "grid gap-4 px-5 py-5 lg:grid-cols-[1fr_auto] lg:items-center",
              selectedId === service.id ? "bg-cyan-50/45" : "bg-white",
            ].join(" ")}
          >
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-lg font-black text-[#062f66]">
                  {service.title}
                </h3>
                <ServiceStatusToggle id={service.id} active={service.active} />
                <span className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-500">
                  Order {service.order}
                </span>
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                {service.shortDescription}
              </p>
              <p className="mt-2 text-xs font-semibold text-slate-400">
                /services/{service.slug}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <Link
                href={`/admin/services?edit=${service.id}`}
                className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 transition hover:border-cyan-200 hover:text-[#062f66]"
              >
                <Pencil size={13} />
                Edit
              </Link>
              <Link
                href={`/services/${service.slug}`}
                className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 transition hover:border-cyan-200 hover:text-[#062f66]"
              >
                <ExternalLink size={13} />
                View
              </Link>
              <ServiceDeleteButton id={service.id} />
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
