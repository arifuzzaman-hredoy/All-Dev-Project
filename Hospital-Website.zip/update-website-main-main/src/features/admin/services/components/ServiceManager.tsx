"use client";

import Link from "next/link";
import clsx from "clsx";
import {
  Activity,
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Bone,
  Brain,
  CheckCircle2,
  Copy,
  Download,
  Eye,
  FileText,
  HeartPulse,
  ImageIcon,
  Microscope,
  Pencil,
  Plus,
  RefreshCcw,
  Save,
  Search,
  Siren,
  Stethoscope,
  Trash2,
  Upload,
  Users,
  XCircle,
} from "lucide-react";

import { createElement, useMemo, useState, type ChangeEvent } from "react";

type ServiceStatus = "active" | "draft";

type AdminService = {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  shortDescription: string;
  overview: string;
  fullDescription: string;
  priceNote: string;
  duration: string;
  availableTime: string;
  doctorName: string;
  doctorTitle: string;
  phone: string;
  imageUrl: string;
  icon: string;
  status: ServiceStatus;
  featured: boolean;
  sortOrder: number;
  highlights: string[];
  facilities: string[];
  symptoms: string[];
  faqs: {
    question: string;
    answer: string;
  }[];
};

type ServiceManagerProps = {
  services?: Partial<AdminService>[];
  selectedService?: Partial<AdminService> | null;
};

const ICONS = [
  { key: "heart", label: "Cardiology", icon: HeartPulse },
  { key: "brain", label: "Neurology", icon: Brain },
  { key: "bone", label: "Orthopedics", icon: Bone },
  { key: "child", label: "Pediatrics", icon: Users },
  { key: "lab", label: "Diagnostics", icon: Microscope },
  { key: "emergency", label: "Emergency", icon: Siren },
  { key: "activity", label: "General", icon: Activity },
  { key: "doctor", label: "Doctor", icon: Stethoscope },
];

const DEFAULT_SERVICES: AdminService[] = [
  {
    id: "service-cardiology",
    slug: "cardiology",
    title: "Cardiology",
    subtitle: "Heart care, preventive screening, and cardiac diagnostics.",
    shortDescription:
      "Heart care, preventive screening, and cardiac diagnostics.",
    overview:
      "Comprehensive cardiology support for screening, diagnosis, follow-up, and coordinated specialist care.",
    fullDescription:
      "Our cardiology service is designed for patients who need reliable heart checkup, blood pressure review, ECG, echo, cardiac risk assessment, and specialist consultation. The department focuses on early detection, clear explanation, and safe treatment planning.",
    priceNote: "Consultation and package pricing available on request",
    duration: "30-45 minutes",
    availableTime: "Every day, 9:00 AM - 8:00 PM",
    doctorName: "Dr. Specialist Consultant",
    doctorTitle: "Consultant Cardiologist",
    phone: "10666",
    imageUrl: "",
    icon: "heart",
    status: "active",
    featured: true,
    sortOrder: 1,
    highlights: [
      "ECG and cardiac screening",
      "Blood pressure and heart risk assessment",
      "Specialist consultation",
    ],
    facilities: [
      "Modern diagnostic support",
      "Follow-up care",
      "Emergency referral support",
    ],
    symptoms: ["Chest pain", "Shortness of breath", "High blood pressure"],
    faqs: [
      {
        question: "Do I need an appointment?",
        answer:
          "Appointment is recommended, but emergency cases should contact the hotline immediately.",
      },
    ],
  },
  {
    id: "service-neurology",
    slug: "neurology",
    title: "Neurology",
    subtitle: "Specialized care for brain, spine, and nerve conditions.",
    shortDescription: "Specialized care for brain, spine, and nerve conditions.",
    overview:
      "Neurology service for headache, stroke risk, seizure, nerve pain, and spine-related conditions.",
    fullDescription:
      "The neurology department supports patients with brain, nerve, and spine-related problems through consultation, diagnosis, and treatment planning.",
    priceNote: "Consultation and package pricing available on request",
    duration: "30-45 minutes",
    availableTime: "Every day, 10:00 AM - 7:00 PM",
    doctorName: "Dr. Neurology Consultant",
    doctorTitle: "Consultant Neurologist",
    phone: "10666",
    imageUrl: "",
    icon: "brain",
    status: "active",
    featured: false,
    sortOrder: 2,
    highlights: [
      "Headache evaluation",
      "Stroke risk review",
      "Nerve pain consultation",
    ],
    facilities: ["Specialist care", "Diagnostic coordination", "Follow-up plan"],
    symptoms: ["Severe headache", "Weakness", "Numbness"],
    faqs: [],
  },
  {
    id: "service-orthopedics",
    slug: "orthopedics",
    title: "Orthopedics",
    subtitle: "Bone, joint, trauma, and sports injury management.",
    shortDescription: "Bone, joint, trauma, and sports injury management.",
    overview:
      "Orthopedic support for bone, joint, back pain, trauma, and injury-related care.",
    fullDescription:
      "Our orthopedic service helps patients with joint pain, injury, fracture review, spine discomfort, and mobility issues.",
    priceNote: "Consultation and package pricing available on request",
    duration: "30 minutes",
    availableTime: "Every day, 9:00 AM - 6:00 PM",
    doctorName: "Dr. Orthopedic Consultant",
    doctorTitle: "Consultant Orthopedic Surgeon",
    phone: "10666",
    imageUrl: "",
    icon: "bone",
    status: "active",
    featured: false,
    sortOrder: 3,
    highlights: ["Joint pain care", "Trauma review", "Sports injury support"],
    facilities: [
      "X-ray coordination",
      "Pain management guidance",
      "Follow-up support",
    ],
    symptoms: ["Back pain", "Joint swelling", "Injury pain"],
    faqs: [],
  },
  {
    id: "service-pediatrics",
    slug: "pediatrics",
    title: "Pediatrics",
    subtitle: "Compassionate care for newborns, children, and teens.",
    shortDescription: "Compassionate care for newborns, children, and teens.",
    overview:
      "Pediatric care for children, newborns, growth monitoring, vaccination guidance, and common illness support.",
    fullDescription:
      "Our pediatrics service provides child-friendly consultation and diagnosis support for newborns, children, and teenagers.",
    priceNote: "Consultation and package pricing available on request",
    duration: "25-40 minutes",
    availableTime: "Every day, 9:00 AM - 7:00 PM",
    doctorName: "Dr. Pediatric Consultant",
    doctorTitle: "Consultant Pediatrician",
    phone: "10666",
    imageUrl: "",
    icon: "child",
    status: "active",
    featured: false,
    sortOrder: 4,
    highlights: ["Child consultation", "Growth monitoring", "Vaccination guidance"],
    facilities: ["Child-friendly care", "Diagnosis support", "Follow-up plan"],
    symptoms: ["Fever", "Cough", "Growth concern"],
    faqs: [],
  },
  {
    id: "service-diagnostics",
    slug: "diagnostics",
    title: "Diagnostics",
    subtitle: "Reliable lab, imaging, and health screening services.",
    shortDescription: "Reliable lab, imaging, and health screening services.",
    overview:
      "Diagnostic support for lab tests, imaging, screening, reports, and health checkup packages.",
    fullDescription:
      "Our diagnostics service focuses on reliable testing, fast reporting, and accurate coordination with doctors.",
    priceNote: "Test and package pricing available on request",
    duration: "Depends on test type",
    availableTime: "Open 24/7",
    doctorName: "Diagnostic Department",
    doctorTitle: "Lab & Imaging Support",
    phone: "10666",
    imageUrl: "",
    icon: "lab",
    status: "active",
    featured: false,
    sortOrder: 5,
    highlights: ["Lab testing", "Imaging support", "Health screening"],
    facilities: ["Reliable reports", "Modern equipment", "Fast sample collection"],
    symptoms: ["Routine checkup", "Doctor advised test", "Health screening"],
    faqs: [],
  },
  {
    id: "service-emergency-care",
    slug: "emergency-care",
    title: "Emergency Care",
    subtitle: "Round-the-clock urgent care and rapid response support.",
    shortDescription: "Round-the-clock urgent care and rapid response support.",
    overview:
      "Emergency care support for urgent medical situations, quick response, and rapid coordination.",
    fullDescription:
      "Our emergency care service is available for urgent cases where fast response and proper coordination are critical.",
    priceNote: "Emergency support available on request",
    duration: "Immediate response",
    availableTime: "Open 24/7",
    doctorName: "Emergency Medical Team",
    doctorTitle: "Emergency Care Unit",
    phone: "10666",
    imageUrl: "",
    icon: "emergency",
    status: "active",
    featured: true,
    sortOrder: 6,
    highlights: ["24/7 emergency support", "Rapid response", "Urgent care coordination"],
    facilities: ["Emergency hotline", "Fast triage", "Referral support"],
    symptoms: ["Severe pain", "Breathing difficulty", "Emergency condition"],
    faqs: [],
  },
];

const emptyService: AdminService = {
  id: "",
  slug: "",
  title: "",
  subtitle: "",
  shortDescription: "",
  overview: "",
  fullDescription: "",
  priceNote: "Consultation and package pricing available on request",
  duration: "",
  availableTime: "",
  doctorName: "",
  doctorTitle: "",
  phone: "10666",
  imageUrl: "",
  icon: "activity",
  status: "active",
  featured: false,
  sortOrder: 1,
  highlights: [""],
  facilities: [""],
  symptoms: [""],
  faqs: [{ question: "", answer: "" }],
};

const inputClass =
  "w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#0a4d8f] focus:ring-4 focus:ring-[#0a4d8f]/10";

const labelClass = "mb-2 block text-sm font-black text-slate-700";

function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

function normalizeService(
  service: Partial<AdminService>,
  index: number,
): AdminService {
  const title = service.title || `Service ${index + 1}`;
  const slug = service.slug || slugify(title);

  return {
    ...emptyService,
    ...service,
    id: service.id || `service-${slug}-${Date.now()}-${index}`,
    slug,
    title,
    subtitle: service.subtitle || service.shortDescription || "",
    shortDescription: service.shortDescription || service.subtitle || "",
    sortOrder: service.sortOrder || index + 1,
    highlights: service.highlights?.length ? service.highlights : [""],
    facilities: service.facilities?.length ? service.facilities : [""],
    symptoms: service.symptoms?.length ? service.symptoms : [""],
    faqs: service.faqs?.length ? service.faqs : [{ question: "", answer: "" }],
  };
}

function getIcon(iconKey: string) {
  return ICONS.find((item) => item.key === iconKey)?.icon || Activity;
}

function readImageAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Only image files are allowed."));
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      reject(new Error("Image size must be under 2MB."));
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      if (typeof reader.result === "string") resolve(reader.result);
      else reject(new Error("Could not read image."));
    };

    reader.onerror = () => reject(new Error("Could not read image."));
    reader.readAsDataURL(file);
  });
}

function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label className={labelClass}>{label}</label>
      {children}
      {hint ? (
        <p className="mt-2 text-xs font-semibold leading-5 text-slate-500">
          {hint}
        </p>
      ) : null}
    </div>
  );
}

type ServiceManagerInitialState = {
  items: AdminService[];
  editingId: string;
  form: AdminService;
};

function createInitialServiceState(
  services: Partial<AdminService>[],
  selectedService?: Partial<AdminService> | null,
): ServiceManagerInitialState {
  const fallback = {
    items: DEFAULT_SERVICES.map(normalizeService).sort(
      (a, b) => a.sortOrder - b.sortOrder,
    ),
    editingId: "",
    form: emptyService,
  };

  try {
    const source = services.length > 0
      ? services.map(normalizeService)
      : fallback.items;

    const items = source.sort((a, b) => a.sortOrder - b.sortOrder);
    const first =
      items.find((item) => item.id === selectedService?.id) ||
      items.find((item) => item.slug === selectedService?.slug) ||
      items[0] ||
      emptyService;

    return {
      items,
      editingId: first.id,
      form: first,
    };
  } catch {
    const first = fallback.items[0] || emptyService;

    return {
      items: fallback.items,
      editingId: first.id,
      form: first,
    };
  }
}

function cleanArray(values: string[]) {
  return values.map((item) => item.trim()).filter(Boolean);
}

export default function ServiceManager({
  services = [],
  selectedService,
}: ServiceManagerProps) {
  const initialState = createInitialServiceState(services, selectedService);
  const [items, setItems] = useState<AdminService[]>(initialState.items);
  const [editingId, setEditingId] = useState<string>(initialState.editingId);
  const [form, setForm] = useState<AdminService>(initialState.form);
  const [query, setQuery] = useState("");
  const [message, setMessage] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const filteredServices = useMemo(() => {
    const keyword = query.toLowerCase().trim();

    return items
      .filter((item) => {
        if (!keyword) return true;

        return (
          item.title.toLowerCase().includes(keyword) ||
          item.slug.toLowerCase().includes(keyword) ||
          item.shortDescription.toLowerCase().includes(keyword)
        );
      })
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [items, query]);

  const activeCount = items.filter((item) => item.status === "active").length;
  const draftCount = items.filter((item) => item.status === "draft").length;

  function persist(
    nextItems: AdminService[],
    customMessage = "Saved successfully.",
  ) {
    const sorted = nextItems
      .map((item, index) => ({
        ...item,
        sortOrder: index + 1,
        order: index + 1,
      }))
      .sort((a, b) => a.sortOrder - b.sortOrder);

    setItems(sorted);
    setMessage(customMessage);
  }

  async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
    const response = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const message =
        typeof data.message === "string" ? data.message : "Request failed.";
      throw new Error(message);
    }

    return data as T;
  }

  function startCreate() {
    const nextOrder = items.length + 1;
    const nextService: AdminService = {
      ...emptyService,
      id: `service-${Date.now()}`,
      title: "",
      slug: "",
      sortOrder: nextOrder,
    };

    setEditingId("");
    setForm(nextService);
    setMessage("New service form ready.");
  }

  function startEdit(service: AdminService) {
    setEditingId(service.id);
    setForm(service);
    setMessage(`Editing ${service.title}.`);
  }

  function updateField<K extends keyof AdminService>(
    key: K,
    value: AdminService[K],
  ) {
    setForm((current) => {
      if (key === "title") {
        const title = String(value);

        return {
          ...current,
          title,
          slug:
            !current.slug || current.slug === slugify(current.title)
              ? slugify(title)
              : current.slug,
        };
      }

      return { ...current, [key]: value };
    });
  }

  function updateArrayField(
    key: "highlights" | "facilities" | "symptoms",
    index: number,
    value: string,
  ) {
    setForm((current) => ({
      ...current,
      [key]: current[key].map((item, itemIndex) =>
        itemIndex === index ? value : item,
      ),
    }));
  }

  function addArrayItem(key: "highlights" | "facilities" | "symptoms") {
    setForm((current) => ({
      ...current,
      [key]: [...current[key], ""],
    }));
  }

  function removeArrayItem(
    key: "highlights" | "facilities" | "symptoms",
    index: number,
  ) {
    setForm((current) => ({
      ...current,
      [key]: current[key].filter((_, itemIndex) => itemIndex !== index),
    }));
  }

  function updateFaq(
    index: number,
    key: "question" | "answer",
    value: string,
  ) {
    setForm((current) => ({
      ...current,
      faqs: current.faqs.map((faq, faqIndex) =>
        faqIndex === index ? { ...faq, [key]: value } : faq,
      ),
    }));
  }

  function addFaq() {
    setForm((current) => ({
      ...current,
      faqs: [...current.faqs, { question: "", answer: "" }],
    }));
  }

  function removeFaq(index: number) {
    setForm((current) => ({
      ...current,
      faqs: current.faqs.filter((_, faqIndex) => faqIndex !== index),
    }));
  }

  async function handleImageUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const dataUrl = await readImageAsDataUrl(file);
      updateField("imageUrl", dataUrl);
      setMessage("Service image uploaded.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Image upload failed.");
    }
  }

  async function saveService() {
    const title = form.title.trim();
    const slug = slugify(form.slug || form.title);

    if (!title) {
      setMessage("Service title is required.");
      return;
    }

    if (!slug) {
      setMessage("Service slug is required.");
      return;
    }

    const duplicate = items.find(
      (item) => item.slug === slug && item.id !== form.id,
    );

    if (duplicate) {
      setMessage("This slug already exists. Use a unique slug.");
      return;
    }

    const finalService: AdminService = {
      ...form,
      title,
      slug,
      subtitle: form.subtitle.trim(),
      shortDescription: form.shortDescription.trim() || form.subtitle.trim(),
      overview: form.overview.trim(),
      fullDescription: form.fullDescription.trim(),
      priceNote: form.priceNote.trim(),
      duration: form.duration.trim(),
      availableTime: form.availableTime.trim(),
      doctorName: form.doctorName.trim(),
      doctorTitle: form.doctorTitle.trim(),
      phone: form.phone.trim(),
      highlights: cleanArray(form.highlights),
      facilities: cleanArray(form.facilities),
      symptoms: cleanArray(form.symptoms),
      faqs: form.faqs.filter(
        (faq) => faq.question.trim() || faq.answer.trim(),
      ),
      sortOrder: form.sortOrder || items.length + 1,
    };

    const exists = items.some((item) => item.id === form.id);

    setIsSaving(true);

    try {
      const payload = await requestJson<{ service: AdminService }>(
        exists ? `/api/admin/services/${form.id}` : "/api/admin/services",
        {
          method: exists ? "PUT" : "POST",
          body: JSON.stringify(finalService),
        },
      );

      const savedService = normalizeService(payload.service, items.length);
      const nextItems = exists
        ? items.map((item) => (item.id === form.id ? savedService : item))
        : [...items, savedService];

      setEditingId(savedService.id);
      setForm(savedService);
      persist(nextItems, exists ? "Service updated in database." : "New service added to database.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Service save failed.");
    } finally {
      setIsSaving(false);
    }
  }

  async function removeService(id: string) {
    const target = items.find((item) => item.id === id);

    const ok = window.confirm(
      `Delete "${target?.title || "this service"}"? This cannot be undone in the database.`,
    );

    if (!ok) return;

    setIsSaving(true);

    try {
      await requestJson<{ ok: boolean }>(`/api/admin/services/${id}`, {
        method: "DELETE",
      });

      const nextItems = items.filter((item) => item.id !== id);
      persist(nextItems, "Service removed from database.");

      if (editingId === id) {
        const first = nextItems[0];

        if (first) {
          setEditingId(first.id);
          setForm(first);
        } else {
          startCreate();
        }
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Service delete failed.");
    } finally {
      setIsSaving(false);
    }
  }

  async function duplicateService(service: AdminService) {
    const copy: AdminService = {
      ...service,
      id: `service-${Date.now()}`,
      title: `${service.title} Copy`,
      slug: `${service.slug}-copy-${Date.now().toString().slice(-4)}`,
      sortOrder: items.length + 1,
      status: "draft",
      featured: false,
    };

    setIsSaving(true);

    try {
      const payload = await requestJson<{ service: AdminService }>(
        "/api/admin/services",
        {
          method: "POST",
          body: JSON.stringify(copy),
        },
      );
      const savedCopy = normalizeService(payload.service, items.length);
      persist([...items, savedCopy], "Service duplicated as draft in database.");
      setEditingId(savedCopy.id);
      setForm(savedCopy);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Duplicate failed.");
    } finally {
      setIsSaving(false);
    }
  }

  async function toggleStatus(service: AdminService) {
    const nextStatus: ServiceStatus =
      service.status === "active" ? "draft" : "active";

    setIsSaving(true);

    try {
      await requestJson<{ ok: boolean }>(`/api/admin/services/${service.id}`, {
        method: "PATCH",
        body: JSON.stringify({ active: nextStatus === "active" }),
      });

      const nextItems = items.map((item) =>
        item.id === service.id
          ? { ...item, status: nextStatus, active: nextStatus === "active" }
          : item,
      );

      persist(nextItems, `Service marked as ${nextStatus} in database.`);

      if (form.id === service.id) {
        setForm((current) => ({
          ...current,
          status: nextStatus,
          active: nextStatus === "active",
        }));
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Status update failed.");
    } finally {
      setIsSaving(false);
    }
  }

  async function moveService(id: string, direction: "up" | "down") {
    const sorted = [...items].sort((a, b) => a.sortOrder - b.sortOrder);
    const index = sorted.findIndex((item) => item.id === id);

    if (index === -1) return;

    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= sorted.length) return;

    const temp = sorted[index];
    sorted[index] = sorted[targetIndex];
    sorted[targetIndex] = temp;

    const nextItems = sorted.map((item, itemIndex) => ({
      ...item,
      sortOrder: itemIndex + 1,
      order: itemIndex + 1,
    }));

    persist(nextItems, "Service order updated locally.");

    try {
      await requestJson<{ ok: boolean }>("/api/admin/services/reorder", {
        method: "POST",
        body: JSON.stringify({
          items: nextItems.map((item) => ({
            id: item.id,
            sortOrder: item.sortOrder,
          })),
        }),
      });
      setMessage("Service order updated in database.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Order update failed.");
    }
  }

  async function resetAll() {
    const ok = window.confirm("Reset all services to default data?");
    if (!ok) return;

    const defaults = DEFAULT_SERVICES.map(normalizeService);
    setIsSaving(true);

    try {
      const payload = await requestJson<{ services: AdminService[] }>(
        "/api/admin/services/bulk",
        {
          method: "PUT",
          body: JSON.stringify({ services: defaults }),
        },
      );
      const nextItems = payload.services.map(normalizeService);
      persist(nextItems, "All services reset to default in database.");
      setEditingId(nextItems[0]?.id || "");
      setForm(nextItems[0] || emptyService);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Reset failed.");
    } finally {
      setIsSaving(false);
    }
  }

  async function copyJson() {
    await navigator.clipboard.writeText(JSON.stringify(items, null, 2));
    setMessage("Services JSON copied.");
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify(items, null, 2)], {
      type: "application/json",
    });

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");

    anchor.href = url;
    anchor.download = "services-data.json";
    anchor.click();

    URL.revokeObjectURL(url);
    setMessage("Services JSON exported.");
  }

  const formIcon = getIcon(form.icon);

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-[32px] border border-slate-200/80 bg-white shadow-[0_28px_75px_rgba(15,23,42,0.08)]">
        <div className="relative overflow-hidden bg-[linear-gradient(135deg,#062f66,#0a4d8f,#07315f)] px-6 py-8 text-white sm:px-8">
          <div className="pointer-events-none absolute -right-10 -top-10 size-40 rounded-full bg-[#8cc63f]/20 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-12 left-16 size-36 rounded-full bg-cyan-300/15 blur-3xl" />

          <div className="relative flex flex-col gap-6 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-200">
                Public website control
              </p>

              <h1 className="mt-3 text-3xl font-black leading-tight sm:text-4xl">
                Services management
              </h1>

              <p className="mt-4 max-w-3xl text-sm leading-7 text-blue-50 sm:text-base">
                Add, edit, disable, remove, sort, publish, upload image, and
                control each service details page from one place.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={startCreate}
                className="inline-flex items-center gap-2 rounded-2xl bg-[#8cc63f] px-4 py-3 text-sm font-black text-[#062f66] shadow-[0_14px_30px_rgba(140,198,63,0.25)] transition hover:brightness-105"
              >
                <Plus size={16} />
                Add Service
              </button>

              <button
                type="button"
                onClick={copyJson}
                className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-black text-white transition hover:bg-white/20"
              >
                <Copy size={16} />
                Copy JSON
              </button>

              <button
                type="button"
                onClick={exportJson}
                className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-black text-white transition hover:bg-white/20"
              >
                <Download size={16} />
                Export
              </button>
            </div>
          </div>
        </div>

        <div className="grid gap-4 border-b border-slate-200 bg-white px-6 py-4 sm:grid-cols-3 sm:px-8">
          <div className="rounded-2xl border border-slate-200 bg-[#f8fbff] px-4 py-3">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
              Total services
            </p>
            <p className="mt-1 text-2xl font-black text-[#062f66]">
              {items.length}
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-[#f8fbff] px-4 py-3">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
              Published
            </p>
            <p className="mt-1 text-2xl font-black text-emerald-600">
              {activeCount}
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-[#f8fbff] px-4 py-3">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
              Draft
            </p>
            <p className="mt-1 text-2xl font-black text-amber-600">
              {draftCount}
            </p>
          </div>
        </div>

        {message ? (
          <div className="border-b border-slate-200 bg-[#f3f9ec] px-6 py-3 text-sm font-bold text-[#406f12] sm:px-8">
            {message}
          </div>
        ) : null}
      </section>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_560px]">
        <div className="space-y-6">
          <section className="rounded-[32px] border border-slate-200/80 bg-white p-5 shadow-[0_18px_55px_rgba(15,23,42,0.06)]">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-xl font-black text-slate-950">
                  Service list
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  Click any card to select and edit. Hover shows the same
                  premium outline.
                </p>
              </div>

              <div className="relative w-full sm:max-w-xs">
                <Search
                  size={16}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search service..."
                  className="w-full rounded-2xl border border-slate-200 bg-[#f8fbff] py-3 pl-11 pr-4 text-sm font-semibold outline-none transition focus:border-[#0a4d8f] focus:ring-4 focus:ring-[#0a4d8f]/10"
                />
              </div>
            </div>

            <div className="mt-5 grid gap-4">
              {filteredServices.map((service, index) => {
                const Icon = getIcon(service.icon);
                const active = service.id === editingId;

                return (
                  <article
                    key={service.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => startEdit(service)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        startEdit(service);
                      }
                    }}
                    className={clsx(
                      "group/service relative cursor-pointer overflow-hidden rounded-[28px] border p-4 outline-none transition-all duration-300",
                      "focus-visible:border-[#0a4d8f] focus-visible:bg-[#f8fbff] focus-visible:shadow-[0_18px_45px_rgba(6,47,102,0.12)]",
                      active
                        ? "border-[#0a4d8f] bg-[#f8fbff] shadow-[0_18px_45px_rgba(6,47,102,0.12)]"
                        : "border-slate-200 bg-white hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:shadow-[0_18px_45px_rgba(6,47,102,0.12)]",
                    )}
                  >
                    <span
                      className={clsx(
                        "absolute bottom-5 left-0 top-5 w-1 rounded-r-full bg-[#0a4d8f] transition-opacity duration-300",
                        active
                          ? "opacity-100"
                          : "opacity-0 group-hover/service:opacity-100",
                      )}
                    />

                    <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                      <div className="flex min-w-0 gap-4">
                        <div
                          className={clsx(
                            "grid size-12 shrink-0 place-items-center rounded-2xl transition-all duration-300",
                            active
                              ? "bg-cyan-50 text-teal-600 shadow-[0_12px_26px_rgba(6,47,102,0.08)]"
                              : "bg-cyan-50 text-teal-600 group-hover/service:scale-105 group-hover/service:shadow-[0_12px_26px_rgba(6,47,102,0.08)]",
                          )}
                        >
                          <Icon size={22} />
                        </div>

                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-lg font-black text-[#062f66]">
                              {service.title}
                            </h3>

                            <span
                              className={clsx(
                                "rounded-full px-2.5 py-1 text-[11px] font-black uppercase tracking-[0.12em]",
                                service.status === "active"
                                  ? "bg-emerald-50 text-emerald-700"
                                  : "bg-amber-50 text-amber-700",
                              )}
                            >
                              {service.status}
                            </span>

                            {service.featured ? (
                              <span className="rounded-full bg-[#8cc63f]/15 px-2.5 py-1 text-[11px] font-black uppercase tracking-[0.12em] text-[#4b7f13]">
                                Featured
                              </span>
                            ) : null}
                          </div>

                          <p className="mt-1 text-xs font-black uppercase tracking-[0.14em] text-slate-400">
                            /services/{service.slug}
                          </p>

                          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
                            {service.shortDescription || service.subtitle}
                          </p>
                        </div>
                      </div>

                      <div
                        className="flex flex-wrap gap-2"
                        onClick={(event) => event.stopPropagation()}
                      >
                        <Link
                          href={`/services/${service.slug}`}
                          target="_blank"
                          className="grid size-10 place-items-center rounded-2xl border border-slate-200 bg-white text-slate-600 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66]"
                          title="Preview public page"
                        >
                          <Eye size={16} />
                        </Link>

                        <button
                          type="button"
                          onClick={() => startEdit(service)}
                          className="grid size-10 place-items-center rounded-2xl border border-slate-200 bg-white text-slate-600 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66]"
                          title="Edit"
                        >
                          <Pencil size={16} />
                        </button>

                        <button
                          type="button"
                          onClick={() => duplicateService(service)}
                          className="grid size-10 place-items-center rounded-2xl border border-slate-200 bg-white text-slate-600 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66]"
                          title="Duplicate"
                        >
                          <Copy size={16} />
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleStatus(service)}
                          className={clsx(
                            "grid size-10 place-items-center rounded-2xl border bg-white transition",
                            service.status === "active"
                              ? "border-emerald-200 text-emerald-600 hover:bg-emerald-50"
                              : "border-amber-200 text-amber-600 hover:bg-amber-50",
                          )}
                          title="Toggle status"
                        >
                          {service.status === "active" ? (
                            <CheckCircle2 size={16} />
                          ) : (
                            <XCircle size={16} />
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => moveService(service.id, "up")}
                          disabled={index === 0}
                          className="grid size-10 place-items-center rounded-2xl border border-slate-200 bg-white text-slate-600 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66] disabled:cursor-not-allowed disabled:opacity-40"
                          title="Move up"
                        >
                          <ArrowUp size={16} />
                        </button>

                        <button
                          type="button"
                          onClick={() => moveService(service.id, "down")}
                          disabled={index === filteredServices.length - 1}
                          className="grid size-10 place-items-center rounded-2xl border border-slate-200 bg-white text-slate-600 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66] disabled:cursor-not-allowed disabled:opacity-40"
                          title="Move down"
                        >
                          <ArrowDown size={16} />
                        </button>

                        <button
                          type="button"
                          onClick={() => removeService(service.id)}
                          className="grid size-10 place-items-center rounded-2xl border border-red-200 bg-red-50 text-red-600 transition hover:bg-red-100"
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}

              {filteredServices.length === 0 ? (
                <div className="rounded-[28px] border border-dashed border-slate-300 bg-[#f8fbff] p-8 text-center">
                  <p className="font-black text-slate-700">No service found.</p>
                  <p className="mt-2 text-sm text-slate-500">
                    Try another search or add a new service.
                  </p>
                </div>
              ) : null}
            </div>
          </section>

          <section className="rounded-[32px] border border-slate-200/80 bg-white p-5 shadow-[0_18px_55px_rgba(15,23,42,0.06)]">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black text-slate-950">
                  Public card preview
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  This is close to what users see on services page.
                </p>
              </div>

              <Link
                href={form.slug ? `/services/${form.slug}` : "/services"}
                target="_blank"
                className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66]"
              >
                <Eye size={16} />
                Preview
              </Link>
            </div>

            <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_280px]">
              <div className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_40px_rgba(15,23,42,0.05)] transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:shadow-[0_18px_45px_rgba(6,47,102,0.12)]">
                <div className="grid size-12 place-items-center rounded-2xl bg-cyan-50 text-teal-600">
                  {createElement(formIcon, { size: 22 })}
                </div>

                <h3 className="mt-5 text-xl font-black text-[#062f66]">
                  {form.title || "Service title"}
                </h3>

                <p className="mt-3 text-sm leading-7 text-slate-600">
                  {form.shortDescription || "Short service description"}
                </p>

                <p className="mt-5 text-xs font-black uppercase tracking-[0.18em] text-cyan-700">
                  {form.priceNote ||
                    "Consultation and package pricing available on request"}
                </p>
              </div>

              <div className="overflow-hidden rounded-[28px] border border-slate-200 bg-[#f8fbff] transition hover:border-[#0a4d8f] hover:shadow-[0_18px_45px_rgba(6,47,102,0.12)]">
                {form.imageUrl ? (
                  <img
                    src={form.imageUrl}
                    alt={form.title}
                    className="h-56 w-full object-cover"
                  />
                ) : (
                  <div className="grid h-56 place-items-center text-slate-400">
                    <div className="text-center">
                      <ImageIcon className="mx-auto" size={34} />
                      <p className="mt-2 text-sm font-bold">No image added</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </section>
        </div>

        <aside className="space-y-6">
          <section className="sticky top-6 rounded-[32px] border border-slate-200/80 bg-white p-5 shadow-[0_20px_60px_rgba(15,23,42,0.08)]">
            <div className="mb-5 flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700">
                  Full access editor
                </p>
                <h2 className="mt-2 text-2xl font-black text-slate-950">
                  {editingId ? "Edit service" : "Create service"}
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  Card, service details page, image, SEO-like content, and CTA
                  information.
                </p>
              </div>

              <button
                type="button"
                onClick={startCreate}
                className="grid size-11 shrink-0 place-items-center rounded-2xl bg-[#062f66] text-white transition hover:bg-[#0a4d8f]"
                title="Create new"
              >
                <Plus size={18} />
              </button>
            </div>

            <div className="max-h-[calc(100vh-170px)] space-y-5 overflow-y-auto pr-1">
              <div className="rounded-[28px] border border-slate-200 bg-[#f8fbff] p-4 transition hover:border-[#0a4d8f] hover:shadow-[0_18px_45px_rgba(6,47,102,0.10)]">
                <div className="grid gap-5">
                  <Field label="Service title">
                    <input
                      className={inputClass}
                      value={form.title}
                      onChange={(event) =>
                        updateField("title", event.target.value)
                      }
                      placeholder="Cardiology"
                    />
                  </Field>

                  <Field
                    label="URL slug"
                    hint="Public page URL: /services/your-slug"
                  >
                    <input
                      className={inputClass}
                      value={form.slug}
                      onChange={(event) =>
                        updateField("slug", slugify(event.target.value))
                      }
                      placeholder="cardiology"
                    />
                  </Field>

                  <Field label="Icon">
                    <div className="grid grid-cols-4 gap-2">
                      {ICONS.map((item) => {
                        const Icon = item.icon;
                        const active = form.icon === item.key;

                        return (
                          <button
                            key={item.key}
                            type="button"
                            onClick={() => updateField("icon", item.key)}
                            className={clsx(
                              "grid place-items-center rounded-2xl border p-3 transition",
                              active
                                ? "border-[#0a4d8f] bg-[#062f66] text-[#8cc63f]"
                                : "border-slate-200 bg-white text-slate-500 hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66]",
                            )}
                            title={item.label}
                          >
                            <Icon size={20} />
                          </button>
                        );
                      })}
                    </div>
                  </Field>

                  <Field label="Service image">
                    <label className="flex cursor-pointer items-center justify-between gap-3 rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-4 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff]">
                      <span className="flex items-center gap-3 text-sm font-bold text-slate-600">
                        <Upload size={17} />
                        Upload service image
                      </span>

                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageUpload}
                      />
                    </label>
                  </Field>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <button
                      type="button"
                      onClick={() =>
                        updateField(
                          "status",
                          form.status === "active" ? "draft" : "active",
                        )
                      }
                      className={clsx(
                        "rounded-2xl px-4 py-3 text-sm font-black transition",
                        form.status === "active"
                          ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                          : "bg-amber-50 text-amber-700 hover:bg-amber-100",
                      )}
                    >
                      Status: {form.status}
                    </button>

                    <button
                      type="button"
                      onClick={() => updateField("featured", !form.featured)}
                      className={clsx(
                        "rounded-2xl px-4 py-3 text-sm font-black transition",
                        form.featured
                          ? "bg-[#8cc63f]/15 text-[#4b7f13] hover:bg-[#8cc63f]/25"
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                      )}
                    >
                      {form.featured ? "Featured: Yes" : "Featured: No"}
                    </button>
                  </div>
                </div>
              </div>

              <div className="rounded-[28px] border border-slate-200 bg-white p-4 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:shadow-[0_18px_45px_rgba(6,47,102,0.10)]">
                <div className="mb-4 flex items-center gap-2">
                  <FileText size={18} className="text-[#062f66]" />
                  <h3 className="font-black text-slate-950">Text content</h3>
                </div>

                <div className="grid gap-5">
                  <Field label="Subtitle">
                    <input
                      className={inputClass}
                      value={form.subtitle}
                      onChange={(event) =>
                        updateField("subtitle", event.target.value)
                      }
                      placeholder="Heart care, preventive screening..."
                    />
                  </Field>

                  <Field label="Short card description">
                    <textarea
                      className={clsx(inputClass, "min-h-24 resize-y")}
                      value={form.shortDescription}
                      onChange={(event) =>
                        updateField("shortDescription", event.target.value)
                      }
                      placeholder="This text appears on the services card."
                    />
                  </Field>

                  <Field label="Service overview">
                    <textarea
                      className={clsx(inputClass, "min-h-28 resize-y")}
                      value={form.overview}
                      onChange={(event) =>
                        updateField("overview", event.target.value)
                      }
                      placeholder="This appears in service overview section."
                    />
                  </Field>

                  <Field label="Full details">
                    <textarea
                      className={clsx(inputClass, "min-h-40 resize-y")}
                      value={form.fullDescription}
                      onChange={(event) =>
                        updateField("fullDescription", event.target.value)
                      }
                      placeholder="Write full details for the individual service page."
                    />
                  </Field>

                  <Field label="Price note">
                    <input
                      className={inputClass}
                      value={form.priceNote}
                      onChange={(event) =>
                        updateField("priceNote", event.target.value)
                      }
                      placeholder="Consultation and package pricing available on request"
                    />
                  </Field>
                </div>
              </div>

              <div className="rounded-[28px] border border-slate-200 bg-white p-4 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:shadow-[0_18px_45px_rgba(6,47,102,0.10)]">
                <h3 className="mb-4 font-black text-slate-950">
                  Appointment / doctor info
                </h3>

                <div className="grid gap-5">
                  <Field label="Duration">
                    <input
                      className={inputClass}
                      value={form.duration}
                      onChange={(event) =>
                        updateField("duration", event.target.value)
                      }
                      placeholder="30-45 minutes"
                    />
                  </Field>

                  <Field label="Available time">
                    <input
                      className={inputClass}
                      value={form.availableTime}
                      onChange={(event) =>
                        updateField("availableTime", event.target.value)
                      }
                      placeholder="Every day, 9:00 AM - 8:00 PM"
                    />
                  </Field>

                  <Field label="Doctor name">
                    <input
                      className={inputClass}
                      value={form.doctorName}
                      onChange={(event) =>
                        updateField("doctorName", event.target.value)
                      }
                      placeholder="Dr. Specialist Consultant"
                    />
                  </Field>

                  <Field label="Doctor title">
                    <input
                      className={inputClass}
                      value={form.doctorTitle}
                      onChange={(event) =>
                        updateField("doctorTitle", event.target.value)
                      }
                      placeholder="Consultant Cardiologist"
                    />
                  </Field>

                  <Field label="Contact number">
                    <input
                      className={inputClass}
                      value={form.phone}
                      onChange={(event) =>
                        updateField("phone", event.target.value)
                      }
                      placeholder="10666"
                    />
                  </Field>
                </div>
              </div>

              {(["highlights", "facilities", "symptoms"] as const).map((key) => (
                <div
                  key={key}
                  className="rounded-[28px] border border-slate-200 bg-white p-4 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:shadow-[0_18px_45px_rgba(6,47,102,0.10)]"
                >
                  <div className="mb-4 flex items-center justify-between gap-3">
                    <h3 className="font-black capitalize text-slate-950">
                      {key}
                    </h3>

                    <button
                      type="button"
                      onClick={() => addArrayItem(key)}
                      className="inline-flex items-center gap-2 rounded-2xl bg-[#062f66] px-3 py-2 text-xs font-black text-white transition hover:bg-[#0a4d8f]"
                    >
                      <Plus size={14} />
                      Add
                    </button>
                  </div>

                  <div className="space-y-3">
                    {form[key].map((value, index) => (
                      <div key={`${key}-${index}`} className="flex gap-2">
                        <input
                          className={inputClass}
                          value={value}
                          onChange={(event) =>
                            updateArrayField(key, index, event.target.value)
                          }
                          placeholder={`Add ${key} item`}
                        />

                        <button
                          type="button"
                          onClick={() => removeArrayItem(key, index)}
                          className="grid size-12 shrink-0 place-items-center rounded-2xl border border-red-200 bg-red-50 text-red-600 transition hover:bg-red-100"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              <div className="rounded-[28px] border border-slate-200 bg-white p-4 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:shadow-[0_18px_45px_rgba(6,47,102,0.10)]">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <h3 className="font-black text-slate-950">FAQs</h3>

                  <button
                    type="button"
                    onClick={addFaq}
                    className="inline-flex items-center gap-2 rounded-2xl bg-[#062f66] px-3 py-2 text-xs font-black text-white transition hover:bg-[#0a4d8f]"
                  >
                    <Plus size={14} />
                    Add FAQ
                  </button>
                </div>

                <div className="space-y-4">
                  {form.faqs.map((faq, index) => (
                    <div
                      key={`faq-${index}`}
                      className="rounded-2xl border border-slate-200 bg-[#f8fbff] p-3 transition hover:border-[#0a4d8f]"
                    >
                      <div className="grid gap-3">
                        <input
                          className={inputClass}
                          value={faq.question}
                          onChange={(event) =>
                            updateFaq(index, "question", event.target.value)
                          }
                          placeholder="FAQ question"
                        />

                        <textarea
                          className={clsx(inputClass, "min-h-24 resize-y")}
                          value={faq.answer}
                          onChange={(event) =>
                            updateFaq(index, "answer", event.target.value)
                          }
                          placeholder="FAQ answer"
                        />

                        <button
                          type="button"
                          onClick={() => removeFaq(index)}
                          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-black text-red-600 transition hover:bg-red-100"
                        >
                          <Trash2 size={16} />
                          Remove FAQ
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={saveService}
                  disabled={isSaving}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#062f66] px-4 py-3 text-sm font-black text-white shadow-[0_14px_30px_rgba(6,47,102,0.18)] transition hover:bg-[#0a4d8f] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <Save size={16} />
                  {isSaving ? "Saving..." : "Save Service"}
                </button>

                <Link
                  href={form.slug ? `/services/${form.slug}` : "/services"}
                  target="_blank"
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66]"
                >
                  <Eye size={16} />
                  Preview Page
                </Link>

                <button
                  type="button"
                  onClick={resetAll}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-black text-amber-700 transition hover:bg-amber-100"
                >
                  <RefreshCcw size={16} />
                  Reset All
                </button>

                <Link
                  href="/admin/services"
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 transition hover:border-[#0a4d8f] hover:bg-[#f8fbff] hover:text-[#062f66]"
                >
                  <ArrowLeft size={16} />
                  All Services
                </Link>
              </div>
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}

