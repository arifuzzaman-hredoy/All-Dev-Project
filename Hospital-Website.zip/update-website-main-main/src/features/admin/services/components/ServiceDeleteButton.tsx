"use client";

import { useActionState } from "react";
import { Trash2 } from "lucide-react";
import { deleteServiceAction } from "../actions";
import type { ServiceActionState } from "../types";

const initialState: ServiceActionState = {
  status: "idle",
  message: "",
};

type ServiceDeleteButtonProps = {
  id: string;
};

export default function ServiceDeleteButton({ id }: ServiceDeleteButtonProps) {
  const [state, formAction, pending] = useActionState(
    deleteServiceAction,
    initialState,
  );

  return (
    <form action={formAction} className="inline-flex items-center gap-2">
      <input type="hidden" name="id" value={id} />
      <button
        type="submit"
        disabled={pending}
        className="inline-flex items-center gap-2 rounded-full border border-rose-200 bg-white px-3 py-1.5 text-xs font-bold text-rose-600 transition hover:bg-rose-50 disabled:opacity-60"
      >
        <Trash2 size={13} />
        {pending ? "Deleting..." : "Delete"}
      </button>
      {state.status === "error" ? (
        <span className="text-xs text-rose-600">{state.message}</span>
      ) : null}
    </form>
  );
}
