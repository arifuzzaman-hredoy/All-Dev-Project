"use client";

import { useActionState, useState } from "react";
import { CheckCircle2, Save } from "lucide-react";
import { saveServiceAction } from "../actions";
import type { AdminService, ServiceActionState } from "../types";

const initialState: ServiceActionState = {
  status: "idle",
  message: "",
};

type ServiceFormProps = {
  service?: AdminService | null;
};

export default function ServiceForm({ service }: ServiceFormProps) {
  const [state, formAction, pending] = useActionState(
    saveServiceAction,
    initialState,
  );
  const [title, setTitle] = useState(service?.title ?? "");
  const [slug, setSlug] = useState(service?.slug ?? "");

  return (
    <form
      action={formAction}
      className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-6"
    >
      <input type="hidden" name="id" value={service?.id ?? ""} />
      <div>
        <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
          {service ? "Update service" : "Create service"}
        </p>
        <h2 className="mt-2 text-2xl font-black text-[#062f66]">
          {service ? service.title : "New public service"}
        </h2>
      </div>

      <div className="mt-6 grid gap-4">
        <label className="grid gap-2">
          <span className="text-sm font-bold text-[#062f66]">Title</span>
          <input
            name="title"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            required
            className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
          />
        </label>

        <label className="grid gap-2">
          <span className="text-sm font-bold text-[#062f66]">Slug</span>
          <input
            name="slug"
            value={slug}
            onChange={(event) => setSlug(event.target.value)}
            placeholder="auto-generated-from-title"
            className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
          />
        </label>

        <label className="grid gap-2">
          <span className="text-sm font-bold text-[#062f66]">
            Short description
          </span>
          <textarea
            name="shortDescription"
            defaultValue={service?.shortDescription}
            required
            rows={3}
            className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-7 outline-none focus:border-[#8cc63f] focus:bg-white"
          />
        </label>

        <label className="grid gap-2">
          <span className="text-sm font-bold text-[#062f66]">
            Full description
          </span>
          <textarea
            name="fullDescription"
            defaultValue={service?.fullDescription}
            required
            rows={6}
            className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-7 outline-none focus:border-[#8cc63f] focus:bg-white"
          />
        </label>

        <div className="grid gap-4 lg:grid-cols-2">
          <label className="grid gap-2">
            <span className="text-sm font-bold text-[#062f66]">
              Featured image path
            </span>
            <input
              name="featuredImage"
              defaultValue={service?.featuredImage}
              placeholder="/slider1.jpeg"
              className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
            />
          </label>

          <label className="grid gap-2">
            <span className="text-sm font-bold text-[#062f66]">
              Upload featured image
            </span>
            <input
              name="featuredImageFile"
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none file:mr-4 file:rounded-full file:border-0 file:bg-[#062f66] file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white focus:border-[#8cc63f] focus:bg-white"
            />
          </label>

          <label className="grid gap-2">
            <span className="text-sm font-bold text-[#062f66]">Icon</span>
            <select
              name="icon"
              defaultValue={service?.icon ?? "HeartPulse"}
              className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
            >
              {["HeartPulse", "Brain", "Bone", "Baby", "Microscope", "Siren"].map(
                (icon) => (
                  <option key={icon} value={icon}>
                    {icon}
                  </option>
                ),
              )}
            </select>
          </label>
        </div>

        <label className="grid gap-2">
          <span className="text-sm font-bold text-[#062f66]">
            Gallery image paths
          </span>
          <textarea
            name="galleryImages"
            defaultValue={service?.galleryImages.join("\n")}
            rows={3}
            placeholder="/slider1.jpeg&#10;/slider2.jpeg"
            className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-7 outline-none focus:border-[#8cc63f] focus:bg-white"
          />
        </label>

        <div className="grid gap-4 lg:grid-cols-2">
          <label className="grid gap-2">
            <span className="text-sm font-bold text-[#062f66]">
              Price or range
            </span>
            <input
              name="priceRange"
              defaultValue={service?.priceRange}
              placeholder="Available on request"
              className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
            />
          </label>

          <label className="grid gap-2">
            <span className="text-sm font-bold text-[#062f66]">Order</span>
            <input
              name="order"
              type="number"
              defaultValue={service?.order ?? 0}
              className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
            />
          </label>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <label className="grid gap-2">
            <span className="text-sm font-bold text-[#062f66]">SEO title</span>
            <input
              name="seoTitle"
              defaultValue={service?.seoTitle}
              className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
            />
          </label>

          <label className="grid gap-2">
            <span className="text-sm font-bold text-[#062f66]">
              SEO description
            </span>
            <input
              name="seoDescription"
              defaultValue={service?.seoDescription}
              className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#8cc63f] focus:bg-white"
            />
          </label>
        </div>

        <label className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700">
          <input
            name="active"
            type="checkbox"
            defaultChecked={service?.active ?? true}
            className="size-4 accent-[#062f66]"
          />
          Active on public website
        </label>
      </div>

      {state.message ? (
        <p
          className={[
            "mt-5 rounded-2xl border px-4 py-3 text-sm",
            state.status === "success"
              ? "border-emerald-200 bg-emerald-50 text-emerald-700"
              : "border-rose-200 bg-rose-50 text-rose-700",
          ].join(" ")}
        >
          {state.message}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={pending}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#0b428b] disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto"
      >
        {state.status === "success" ? <CheckCircle2 size={16} /> : <Save size={16} />}
        {pending ? "Saving..." : service ? "Save service" : "Create service"}
      </button>
    </form>
  );
}
