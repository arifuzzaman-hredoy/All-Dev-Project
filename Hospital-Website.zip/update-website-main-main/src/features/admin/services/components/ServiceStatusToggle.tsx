"use client";

import { useTransition } from "react";
import { toggleServiceStatusAction } from "../actions";

type ServiceStatusToggleProps = {
  id: string;
  active: boolean;
};

export default function ServiceStatusToggle({
  id,
  active,
}: ServiceStatusToggleProps) {
  const [pending, startTransition] = useTransition();

  return (
    <button
      type="button"
      disabled={pending}
      onClick={() => {
        const formData = new FormData();
        formData.set("id", id);
        formData.set("active", String(!active));
        startTransition(() => {
          void toggleServiceStatusAction(formData);
        });
      }}
      className={[
        "rounded-full px-3 py-1.5 text-xs font-bold transition disabled:opacity-60",
        active
          ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
          : "bg-slate-100 text-slate-500 hover:bg-slate-200",
      ].join(" ")}
    >
      {pending ? "Updating..." : active ? "Active" : "Inactive"}
    </button>
  );
}
