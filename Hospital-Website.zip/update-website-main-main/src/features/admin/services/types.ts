export type ServiceStatus = "active" | "draft";

export type AdminService = {
  id: string;
  title: string;
  slug: string;
  shortDescription: string;
  fullDescription: string;
  featuredImage: string;
  galleryImages: string[];
  icon: string;
  priceRange: string;
  order: number;
  active: boolean;
  seoTitle: string;
  seoDescription: string;
  createdAt: string;
  updatedAt: string;

  subtitle?: string;
  overview?: string;
  imageUrl?: string;
  priceNote?: string;
  duration?: string;
  availableTime?: string;
  doctorName?: string;
  doctorTitle?: string;
  phone?: string;
  sortOrder?: number;
  status?: ServiceStatus;
  featured?: boolean;
  highlights?: string[];
  facilities?: string[];
  symptoms?: string[];
  faqs?: {
    question: string;
    answer: string;
  }[];
};

export type ServiceActionState = {
  status: "idle" | "success" | "error";
  message: string;
  fieldErrors?: Record<string, string>;
};
