"use server";

import { revalidatePath } from "next/cache";
import { requireAdminSession } from "@/lib/admin-session";
import { PUBLIC_CONTENT_REVALIDATE_PATHS } from "@/lib/public-content/constants";
import { recordAuditLog } from "@/lib/audit-log";
import { savePublicImageUpload } from "@/lib/public-content/upload";
import { parseServiceForm } from "./schema";
import {
  createService,
  deleteService,
  setServiceActive,
  updateService,
} from "./service";
import type { ServiceActionState } from "./types";

const success = (message: string): ServiceActionState => ({
  status: "success",
  message,
});

const error = (message: string): ServiceActionState => ({
  status: "error",
  message,
});

function revalidateServicePages() {
  for (const route of PUBLIC_CONTENT_REVALIDATE_PATHS) {
    if (route.includes("[slug]")) {
      revalidatePath(route, "page");
    } else {
      revalidatePath(route);
    }
  }
}

export async function saveServiceAction(
  _previousState: ServiceActionState,
  formData: FormData,
): Promise<ServiceActionState> {
  try {
    await requireAdminSession();
    const rawId = formData.get("id");
    const id = typeof rawId === "string" ? rawId : "";
    const parsed = parseServiceForm(formData);

    if (!parsed.ok) {
      return error(parsed.errors.join(" "));
    }

    const uploadedImage = await savePublicImageUpload(
      formData.get("featuredImageFile"),
      parsed.data.title,
    );
    const serviceInput = uploadedImage
      ? { ...parsed.data, featuredImage: uploadedImage }
      : parsed.data;

    if (id) {
      const service = await updateService(id, serviceInput);
      await recordAuditLog({
        action: "SERVICE_UPDATE",
        entity: "Service",
        entityId: id,
        metadata: { title: service.title ?? null, slug: service.slug ?? null },
      });
      revalidateServicePages();
      return success("Service updated and published.");
    }

    const service = await createService(serviceInput);
    await recordAuditLog({
      action: "SERVICE_CREATE",
      entity: "Service",
      entityId: service.id,
      metadata: { title: service.title ?? null, slug: service.slug ?? null },
    });
    revalidateServicePages();
    return success("Service created and published.");
  } catch (caught) {
    return error(caught instanceof Error ? caught.message : "Save failed.");
  }
}

export async function deleteServiceAction(
  _previousState: ServiceActionState,
  formData: FormData,
): Promise<ServiceActionState> {
  try {
    await requireAdminSession();
    const id = formData.get("id");

    if (typeof id !== "string" || !id) {
      return error("Service id is missing.");
    }

    await deleteService(id);
    await recordAuditLog({
      action: "SERVICE_DELETE",
      entity: "Service",
      entityId: id,
    });
    revalidateServicePages();
    return success("Service deleted.");
  } catch (caught) {
    return error(caught instanceof Error ? caught.message : "Delete failed.");
  }
}

export async function toggleServiceStatusAction(formData: FormData) {
  await requireAdminSession();
  const id = formData.get("id");
  const active = formData.get("active") === "true";

  if (typeof id !== "string" || !id) {
    throw new Error("Service id is missing.");
  }

  await setServiceActive(id, active);
  await recordAuditLog({
    action: active ? "SERVICE_PUBLISH" : "SERVICE_ARCHIVE",
    entity: "Service",
    entityId: id,
    metadata: { active },
  });
  revalidateServicePages();
}
