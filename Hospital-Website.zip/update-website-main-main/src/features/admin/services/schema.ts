import { ensureSlug } from "@/lib/public-content/slug";
import {
  optionalNumber,
  optionalText,
  requiredText,
  splitLines,
  type ValidationResult,
} from "@/lib/public-content/validation";
import type { AdminService } from "./types";

export type ServiceInput = Partial<AdminService> & {
  title: string;
  slug: string;
  shortDescription: string;
  fullDescription: string;
};

export function parseServiceForm(
  formData: FormData,
): ValidationResult<ServiceInput> {
  const title = requiredText(formData.get("title"), "Service title");
  const shortDescription = requiredText(
    formData.get("shortDescription"),
    "Short description",
  );
  const fullDescription = requiredText(
    formData.get("fullDescription"),
    "Full description",
  );
  const errors = [title.error, shortDescription.error, fullDescription.error]
    .filter((error): error is string => Boolean(error));

  const slug = ensureSlug(optionalText(formData.get("slug")), title.value);
  const seoTitle = optionalText(formData.get("seoTitle"));
  const seoDescription = optionalText(formData.get("seoDescription"));

  if (errors.length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    data: {
      title: title.value,
      slug,
      subtitle: shortDescription.value,
      shortDescription: shortDescription.value,
      overview: fullDescription.value,
      fullDescription: fullDescription.value,
      featuredImage: optionalText(formData.get("featuredImage")),
      imageUrl: optionalText(formData.get("featuredImage")),
      galleryImages: splitLines(optionalText(formData.get("galleryImages"))),
      icon: optionalText(formData.get("icon")) || "activity",
      priceRange: optionalText(formData.get("priceRange")),
      priceNote: optionalText(formData.get("priceRange")),
      order: optionalNumber(formData.get("order")),
      sortOrder: optionalNumber(formData.get("order")),
      active: formData.get("active") === "on",
      status: formData.get("active") === "on" ? "active" : "draft",
      featured: false,
      highlights: [],
      facilities: [],
      symptoms: [],
      faqs: [],
      seoTitle: seoTitle || title.value,
      seoDescription: seoDescription || shortDescription.value,
    },
  };
}
