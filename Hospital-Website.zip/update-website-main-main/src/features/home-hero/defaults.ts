import type { HomeHeroContent, HomeHeroIconKey } from "./types";
import { homeHeroIconKeys } from "./types";

export const defaultHomeHeroContent: HomeHeroContent = {
  welcomeText: "Welcome to Update Diagnostic Center Rangpur.",
  heroLogoUrl: "",
  heroLogoAlt: "Update Diagnostic Center",
  carousel: {
    autoplay: true,
    intervalMs: 5000,
    showArrows: true,
    showDots: true,
    overlayOpacity: 18,
    desktopHeight: 530,
    mobileHeight: 240,
  },
  slides: [
    {
      id: "hero-1",
      imageUrl: "/images/hero/hero-1.jpg",
      imageAlt: "Update Diagnostic Center building hero image",
      isActive: true,
      sortOrder: 1,
    },
    {
      id: "hero-2",
      imageUrl: "/images/hero/hero-2.jpg",
      imageAlt: "Update Diagnostic Center healthcare facility",
      isActive: true,
      sortOrder: 2,
    },
    {
      id: "hero-3",
      imageUrl: "/images/hero/hero-3.jpg",
      imageAlt: "Update Diagnostic Center patient care",
      isActive: true,
      sortOrder: 3,
    },
  ],
  quickActions: [
    {
      id: "find-doctor",
      label: "Find A Doctor",
      href: "/doctors",
      icon: "Stethoscope",
      isActive: true,
      sortOrder: 1,
    },
    {
      id: "appointment",
      label: "Request An Appointment",
      href: "/appointment",
      icon: "CalendarCheck",
      isActive: true,
      sortOrder: 2,
    },
    {
      id: "online-report",
      label: "Online Report",
      href: "/online-report",
      icon: "FileText",
      isActive: true,
      sortOrder: 3,
    },
    {
      id: "tele-online",
      label: "Tele-Online",
      href: "/tele-online",
      icon: "Headphones",
      isActive: true,
      sortOrder: 4,
    },
    {
      id: "patient-guide",
      label: "Patient & Visitors Guide",
      href: "/patient-guide",
      icon: "Users",
      isActive: true,
      sortOrder: 5,
    },
  ],
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function text(value: unknown, fallback = "") {
  return typeof value === "string" ? value : fallback;
}

function bool(value: unknown, fallback: boolean) {
  return typeof value === "boolean" ? value : fallback;
}

function numberInRange(
  value: unknown,
  fallback: number,
  minimum: number,
  maximum: number,
) {
  const number = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(Math.max(number, minimum), maximum);
}

function iconKey(value: unknown): HomeHeroIconKey {
  if (typeof value === "string") {
    const match = homeHeroIconKeys.find((key) => key === value);
    if (match) return match;
  }

  return "Stethoscope";
}

export function normalizeHomeHeroContent(value: unknown): HomeHeroContent {
  if (!isRecord(value)) return defaultHomeHeroContent;

  const carousel = isRecord(value.carousel) ? value.carousel : {};
  const fallback = defaultHomeHeroContent;
  const slides = Array.isArray(value.slides)
    ? value.slides
        .filter(isRecord)
        .map((slide, index) => ({
          id: text(slide.id, `hero-slide-${index + 1}`),
          title: text(slide.title),
          subtitle: text(slide.subtitle),
          description: text(slide.description),
          imageUrl: text(slide.imageUrl),
          mobileImageUrl: text(slide.mobileImageUrl),
          imageAlt: text(slide.imageAlt, "Homepage hero image"),
          primaryButtonLabel: text(slide.primaryButtonLabel),
          primaryButtonHref: text(slide.primaryButtonHref),
          secondaryButtonLabel: text(slide.secondaryButtonLabel),
          secondaryButtonHref: text(slide.secondaryButtonHref),
          isActive: bool(slide.isActive, true),
          sortOrder: numberInRange(slide.sortOrder, index + 1, 1, 999),
        }))
        .filter((slide) => slide.imageUrl)
    : [];

  const quickActions = Array.isArray(value.quickActions)
    ? value.quickActions
        .filter(isRecord)
        .map((action, index) => ({
          id: text(action.id, `quick-action-${index + 1}`),
          label: text(action.label, "Quick Action"),
          href: text(action.href, "/"),
          icon: iconKey(action.icon),
          isActive: bool(action.isActive, true),
          sortOrder: numberInRange(action.sortOrder, index + 1, 1, 999),
        }))
    : [];

  return {
    welcomeText: text(value.welcomeText, fallback.welcomeText),
    heroLogoUrl: text(value.heroLogoUrl),
    heroLogoAlt: text(value.heroLogoAlt, fallback.heroLogoAlt),
    carousel: {
      autoplay: bool(carousel.autoplay, fallback.carousel.autoplay),
      intervalMs: numberInRange(
        carousel.intervalMs,
        fallback.carousel.intervalMs,
        1500,
        30000,
      ),
      showArrows: bool(carousel.showArrows, fallback.carousel.showArrows),
      showDots: bool(carousel.showDots, fallback.carousel.showDots),
      overlayOpacity: numberInRange(
        carousel.overlayOpacity,
        fallback.carousel.overlayOpacity,
        0,
        80,
      ),
      desktopHeight: numberInRange(
        carousel.desktopHeight,
        fallback.carousel.desktopHeight,
        360,
        760,
      ),
      mobileHeight: numberInRange(
        carousel.mobileHeight,
        fallback.carousel.mobileHeight,
        200,
        520,
      ),
    },
    slides: slides.length ? slides : fallback.slides,
    quickActions: quickActions.length ? quickActions : fallback.quickActions,
  };
}

