export const homeHeroIconKeys = [
  "Stethoscope",
  "CalendarCheck",
  "FileText",
  "Headphones",
  "Users",
  "Activity",
] as const;

export type HomeHeroIconKey = (typeof homeHeroIconKeys)[number];

export type HomeHeroContent = {
  welcomeText: string;
  heroLogoUrl?: string;
  heroLogoAlt?: string;
  carousel: {
    autoplay: boolean;
    intervalMs: number;
    showArrows: boolean;
    showDots: boolean;
    overlayOpacity: number;
    desktopHeight: number;
    mobileHeight: number;
  };
  slides: Array<{
    id: string;
    title?: string;
    subtitle?: string;
    description?: string;
    imageUrl: string;
    mobileImageUrl?: string;
    imageAlt: string;
    primaryButtonLabel?: string;
    primaryButtonHref?: string;
    secondaryButtonLabel?: string;
    secondaryButtonHref?: string;
    isActive: boolean;
    sortOrder: number;
  }>;
  quickActions: Array<{
    id: string;
    label: string;
    href: string;
    icon: HomeHeroIconKey;
    isActive: boolean;
    sortOrder: number;
  }>;
};

