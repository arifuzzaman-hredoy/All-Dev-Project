import Container from "@/components/common/Container";
import type { PublicService } from "../types";
import PublicServiceCard from "./PublicServiceCard";

type PublicServicesGridProps = {
  services: PublicService[];
};

export default function PublicServicesGrid({ services }: PublicServicesGridProps) {
  if (services.length === 0) {
    return (
      <section className="bg-slate-50 py-16 sm:py-20">
        <Container>
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center">
            <h2 className="text-xl font-black text-[#062f66]">
              Services are being updated
            </h2>
            <p className="mt-3 text-sm leading-7 text-slate-600">
              Please check again soon or contact the front desk for current
              service availability.
            </p>
          </div>
        </Container>
      </section>
    );
  }

  return (
    <section className="bg-slate-50 py-16 sm:py-20">
      <Container>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <PublicServiceCard key={service.id} service={service} />
          ))}
        </div>
      </Container>
    </section>
  );
}
