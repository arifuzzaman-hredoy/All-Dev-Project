import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, CalendarCheck } from "lucide-react";
import Container from "@/components/common/Container";
import type { PublicService } from "../types";

type PublicServiceDetailProps = {
  service: PublicService;
};

export default function PublicServiceDetail({
  service,
}: PublicServiceDetailProps) {
  return (
    <>
      <section className="bg-[#062f66] py-10 text-white sm:py-14 lg:py-20">
        <Container>
          <Link
            href="/services"
            className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:bg-white/15"
          >
            <ArrowLeft size={16} />
            All services
          </Link>
          <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_420px] lg:items-center">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-cyan-200 sm:text-sm">
                Update Diagnostic Center
              </p>
              <h1 className="mt-3 text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
                {service.title}
              </h1>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-blue-50 sm:text-base lg:text-lg lg:leading-8">
                {service.shortDescription}
              </p>
            </div>

            <div className="relative aspect-[4/3] overflow-hidden rounded-[28px] border border-white/15 bg-white/10">
              {service.featuredImage ? (
                <Image
                  src={service.featuredImage}
                  alt={service.title}
                  fill
                  sizes="(min-width: 1024px) 420px, 100vw"
                  className="object-cover"
                />
              ) : (
                <div className="flex h-full items-center justify-center px-6 text-center text-sm text-cyan-100">
                  Image coming soon
                </div>
              )}
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-white py-14 sm:py-18">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_340px]">
            <article className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.05)] sm:p-8">
              <h2 className="text-2xl font-black text-[#062f66]">
                Service overview
              </h2>
              <p className="mt-4 whitespace-pre-line text-sm leading-8 text-slate-600 sm:text-base">
                {service.fullDescription}
              </p>
            </article>

            <aside className="rounded-[28px] border border-slate-200 bg-slate-50 p-6">
              <h2 className="text-lg font-black text-[#062f66]">
                Need this service?
              </h2>
              {service.priceRange ? (
                <p className="mt-3 text-sm font-semibold text-slate-700">
                  {service.priceRange}
                </p>
              ) : null}
              <p className="mt-3 text-sm leading-7 text-slate-600">
                Contact the appointment desk for schedule, consultant
                availability, and preparation instructions.
              </p>
              <Link
                href="/appointment"
                className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#062f66] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#0b428b]"
              >
                <CalendarCheck size={16} />
                Request appointment
              </Link>
            </aside>
          </div>
        </Container>
      </section>
    </>
  );
}
