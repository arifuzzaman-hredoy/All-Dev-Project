import { cache } from "react";
import { prisma } from "@/lib/db";
import type { PublicService } from "./types";

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => String(item || "").trim()).filter(Boolean);
}

type DbService = Awaited<ReturnType<typeof getServiceRows>>[number];

async function getServiceRows() {
  return prisma.service.findMany({
    where: { status: "PUBLISHED" },
    include: { features: true, faqs: true },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });
}

function toPublicService(service: DbService): PublicService {
  const shortDescription =
    service.shortDescription || service.description || service.subtitle || "";
  const fullDescription =
    service.fullDescription || service.description || service.overview || "";

  return {
    id: service.id,
    title: service.title,
    slug: service.slug,
    shortDescription,
    fullDescription,
    featuredImage: service.featuredImage || service.imageUrl || "",
    galleryImages: toStringArray(service.galleryImages),
    icon: service.icon || "HeartPulse",
    priceRange: service.priceRange || service.priceText || "",
    order: service.sortOrder,
    seoTitle: service.seoTitle || service.title,
    seoDescription: service.seoDescription || shortDescription,
  };
}

export const getPublicServices = cache(async () => {
  const services = await getServiceRows();
  return services.map(toPublicService);
});

export const getPublicServiceBySlug = cache(async (slug: string) => {
  const service = await prisma.service.findFirst({
    where: { slug, status: "PUBLISHED" },
    include: { features: true, faqs: true },
  });

  return service ? toPublicService(service) : null;
});
