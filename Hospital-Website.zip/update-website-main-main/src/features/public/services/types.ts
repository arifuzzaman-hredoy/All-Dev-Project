export type PublicService = {
  id: string;
  title: string;
  slug: string;
  shortDescription: string;
  fullDescription: string;
  featuredImage: string;
  galleryImages: string[];
  icon: string;
  priceRange: string;
  order: number;
  seoTitle: string;
  seoDescription: string;
};
