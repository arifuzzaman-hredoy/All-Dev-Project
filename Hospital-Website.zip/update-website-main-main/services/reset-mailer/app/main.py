import html
import os
import smtplib
import ssl
from email.message import EmailMessage
from typing import Any

from fastapi import FastAPI, HTTPException, Request

app = FastAPI(title="Update Project Reset Mailer", version="1.0.0")


def env_bool(key: str, default: bool = False) -> bool:
    value = os.getenv(key)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def get_required_env(key: str) -> str:
    value = os.getenv(key, "").strip()
    if not value:
        raise HTTPException(status_code=500, detail=f"{key} is not configured")
    return value


def get_payload_value(payload: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = payload.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def verify_webhook_secret(request: Request) -> None:
    expected = (
        os.getenv("RESET_MAILER_WEBHOOK_SECRET", "").strip()
        or os.getenv("ADMIN_RESET_WEBHOOK_SECRET", "").strip()
    )

    if not expected:
        raise HTTPException(status_code=500, detail="Webhook secret is not configured")

    auth_header = request.headers.get("authorization", "").strip()
    bearer_token = ""
    if auth_header.lower().startswith("bearer "):
        bearer_token = auth_header.split(" ", 1)[1].strip()

    received = (
        request.headers.get("x-admin-reset-webhook-secret", "").strip()
        or request.headers.get("x-reset-webhook-secret", "").strip()
        or request.headers.get("x-webhook-secret", "").strip()
        or bearer_token
    )

    if received != expected:
        raise HTTPException(status_code=401, detail="Invalid webhook secret")


def build_email(to_email: str, code: str, expires_in: str, site: str) -> EmailMessage:
    smtp_from = os.getenv("SMTP_FROM", "").strip() or get_required_env("SMTP_USER")
    subject = os.getenv("RESET_MAIL_SUBJECT", "Update Diagnostic Center admin recovery code")

    safe_code = html.escape(code)
    safe_site = html.escape(site)
    safe_expires = html.escape(expires_in)

    plain_body = f"""Update Diagnostic Center admin password recovery

Your recovery code is: {code}

This code will expire in {expires_in} minutes.

Site: {site}

If you did not request this code, ignore this email.
"""

    html_body = f"""
    <div style="font-family:Arial,sans-serif;background:#f5f8fc;padding:24px">
      <div style="max-width:560px;margin:auto;background:#ffffff;border-radius:18px;padding:28px;border:1px solid #e6edf5">
        <p style="color:#0f766e;letter-spacing:4px;font-size:12px;font-weight:700">ADMIN PASSWORD RECOVERY</p>
        <h1 style="color:#083a70;margin:0 0 12px">Recovery code</h1>
        <p style="color:#334155;font-size:15px;line-height:1.7">
          Use the code below to verify your admin password reset request.
        </p>
        <div style="font-size:34px;letter-spacing:8px;font-weight:800;color:#082f63;background:#eff6ff;border:1px solid #bfdbfe;border-radius:14px;padding:18px 22px;text-align:center;margin:22px 0">
          {safe_code}
        </div>
        <p style="color:#475569;font-size:14px">This code will expire in <b>{safe_expires} minutes</b>.</p>
        <p style="color:#64748b;font-size:13px">Site: {safe_site}</p>
        <hr style="border:none;border-top:1px solid #e2e8f0;margin:24px 0" />
        <p style="color:#94a3b8;font-size:12px">If you did not request this code, ignore this email.</p>
      </div>
    </div>
    """

    msg = EmailMessage()
    msg["From"] = smtp_from
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.set_content(plain_body)
    msg.add_alternative(html_body, subtype="html")
    return msg


def send_email(message: EmailMessage) -> None:
    host = get_required_env("SMTP_HOST")
    port = int(os.getenv("SMTP_PORT", "465"))
    user = get_required_env("SMTP_USER")
    password = get_required_env("SMTP_PASS").replace(" ", "")
    secure = env_bool("SMTP_SECURE", port == 465)
    starttls = env_bool("SMTP_STARTTLS", not secure)

    if secure:
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(host, port, context=context, timeout=30) as server:
            server.login(user, password)
            server.send_message(message)
    else:
        with smtplib.SMTP(host, port, timeout=30) as server:
            if starttls:
                context = ssl.create_default_context()
                server.starttls(context=context)
            server.login(user, password)
            server.send_message(message)


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "smtpConfigured": bool(os.getenv("SMTP_HOST") and os.getenv("SMTP_USER") and os.getenv("SMTP_PASS")),
    }


@app.post("/admin-reset-email")
async def admin_reset_email(request: Request) -> dict[str, Any]:
    verify_webhook_secret(request)

    payload = await request.json()

    to_email = get_payload_value(payload, "email", "adminEmail", "to")
    code = get_payload_value(payload, "code", "resetCode", "recoveryCode")
    expires_in = get_payload_value(payload, "expiresInMinutes", "ttlMinutes") or os.getenv("ADMIN_RESET_CODE_TTL_MINUTES", "10")
    site = get_payload_value(payload, "site", "siteUrl") or os.getenv("NEXT_PUBLIC_SITE_URL", "https://update.techteamlead.com")

    if "@" not in to_email:
        raise HTTPException(status_code=400, detail="Valid recipient email is required")

    if not code:
        raise HTTPException(status_code=400, detail="Recovery code is required")

    message = build_email(to_email=to_email, code=code, expires_in=expires_in, site=site)
    send_email(message)

    return {
        "ok": True,
        "sent": True,
        "to": to_email,
    }
