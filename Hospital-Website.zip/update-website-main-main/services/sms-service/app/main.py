from __future__ import annotations

import os
import time
import uuid
from typing import Any, Literal

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    sms_service_api_key: str = ""
    sms_enabled: bool = False
    sms_provider: str = "mock"

    sms_api_url: str = ""
    sms_api_key: str = ""
    sms_sender_id: str = "UpdateClinic"
    sms_timeout_seconds: int = 15

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()

SmsStatus = Literal["PENDING", "SENT", "FAILED", "DISABLED", "SKIPPED"]


class SendSmsRequest(BaseModel):
    phone: str = Field(..., min_length=3)
    message: str = Field(..., min_length=1)
    templateKey: str | None = None
    relatedFormType: str | None = None
    relatedRecordId: str | None = None
    metadata: dict[str, Any] | None = None


class SendSmsResponse(BaseModel):
    status: SmsStatus
    provider: str
    phone: str
    message: str
    templateKey: str | None = None
    providerMessageId: str | None = None
    providerResponse: dict[str, Any] | None = None
    errorMessage: str | None = None
    durationMs: int


app = FastAPI(
    title="Update Clinic SMS Service",
    version="0.1.0",
    description="Provider-ready SMS service for Update Clinic appointment and form automation.",
)


def validate_service_key(x_sms_service_key: str | None) -> None:
    if not settings.sms_service_api_key:
        return

    if x_sms_service_key != settings.sms_service_api_key:
        raise HTTPException(status_code=401, detail="Invalid SMS service key.")


def normalize_phone(phone: str) -> str:
    return phone.strip().replace(" ", "").replace("-", "")


async def send_with_mock(payload: SendSmsRequest) -> SendSmsResponse:
    started = time.perf_counter()
    message_id = f"mock-{uuid.uuid4()}"

    return SendSmsResponse(
        status="SENT",
        provider="mock",
        phone=normalize_phone(payload.phone),
        message=payload.message,
        templateKey=payload.templateKey,
        providerMessageId=message_id,
        providerResponse={
            "mock": True,
            "message": "SMS accepted by mock provider.",
        },
        durationMs=int((time.perf_counter() - started) * 1000),
    )


async def send_with_custom_api(payload: SendSmsRequest) -> SendSmsResponse:
    started = time.perf_counter()

    if not settings.sms_api_url:
        return SendSmsResponse(
            status="FAILED",
            provider="custom",
            phone=normalize_phone(payload.phone),
            message=payload.message,
            templateKey=payload.templateKey,
            errorMessage="SMS_API_URL is not configured.",
            durationMs=int((time.perf_counter() - started) * 1000),
        )

    request_body = {
        "api_key": settings.sms_api_key,
        "sender_id": settings.sms_sender_id,
        "phone": normalize_phone(payload.phone),
        "message": payload.message,
        "template_key": payload.templateKey,
        "related_form_type": payload.relatedFormType,
        "related_record_id": payload.relatedRecordId,
        "metadata": payload.metadata or {},
    }

    try:
        async with httpx.AsyncClient(timeout=settings.sms_timeout_seconds) as client:
            response = await client.post(settings.sms_api_url, json=request_body)

        response_text = response.text[:2000]

        if response.status_code >= 400:
            return SendSmsResponse(
                status="FAILED",
                provider="custom",
                phone=normalize_phone(payload.phone),
                message=payload.message,
                templateKey=payload.templateKey,
                errorMessage=f"Provider HTTP {response.status_code}: {response_text}",
                providerResponse={
                    "status_code": response.status_code,
                    "body": response_text,
                },
                durationMs=int((time.perf_counter() - started) * 1000),
            )

        provider_json: dict[str, Any]
        try:
            provider_json = response.json()
        except ValueError:
            provider_json = {"body": response_text}

        provider_message_id = (
            str(provider_json.get("message_id"))
            if provider_json.get("message_id")
            else str(provider_json.get("id"))
            if provider_json.get("id")
            else None
        )

        return SendSmsResponse(
            status="SENT",
            provider="custom",
            phone=normalize_phone(payload.phone),
            message=payload.message,
            templateKey=payload.templateKey,
            providerMessageId=provider_message_id,
            providerResponse=provider_json,
            durationMs=int((time.perf_counter() - started) * 1000),
        )
    except Exception as error:
        return SendSmsResponse(
            status="FAILED",
            provider="custom",
            phone=normalize_phone(payload.phone),
            message=payload.message,
            templateKey=payload.templateKey,
            errorMessage=str(error),
            durationMs=int((time.perf_counter() - started) * 1000),
        )


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "ok": True,
        "service": "sms-service",
        "provider": settings.sms_provider,
        "enabled": settings.sms_enabled,
    }


@app.post("/send", response_model=SendSmsResponse)
async def send_sms(
    payload: SendSmsRequest,
    x_sms_service_key: str | None = Header(default=None),
) -> SendSmsResponse:
    validate_service_key(x_sms_service_key)

    started = time.perf_counter()

    if not settings.sms_enabled:
        return SendSmsResponse(
            status="DISABLED",
            provider=settings.sms_provider,
            phone=normalize_phone(payload.phone),
            message=payload.message,
            templateKey=payload.templateKey,
            errorMessage="SMS sending is disabled by SMS_ENABLED=false.",
            durationMs=int((time.perf_counter() - started) * 1000),
        )

    provider = settings.sms_provider.strip().lower()

    if provider == "mock":
        return await send_with_mock(payload)

    if provider == "custom":
        return await send_with_custom_api(payload)

    return SendSmsResponse(
        status="FAILED",
        provider=provider,
        phone=normalize_phone(payload.phone),
        message=payload.message,
        templateKey=payload.templateKey,
        errorMessage=f"Unsupported SMS provider: {provider}",
        durationMs=int((time.perf_counter() - started) * 1000),
    )
