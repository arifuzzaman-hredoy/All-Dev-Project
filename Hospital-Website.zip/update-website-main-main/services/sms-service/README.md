# Update Clinic SMS Service

Standalone Python FastAPI SMS service for Update Clinic.

## Features

- Mock provider for local testing
- Custom provider-ready API sender
- API key protection with X-SMS-Service-Key
- Health endpoint: GET /health
- SMS send endpoint: POST /send
- Designed for Next.js + Prisma SmsLog integration

## Local setup

Run from this folder:

G:\Current Project\Development\Update Project\update-website-git-final\services\sms-service

Commands:

python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item ".env.example" ".env"
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000

## Health check

Invoke-RestMethod -Uri "http://127.0.0.1:8000/health" -Method GET

## Send test SMS

By default SMS_ENABLED=false, so send test returns DISABLED.

$body = @{
  phone = "01700000000"
  message = "Test SMS from Update Clinic"
  templateKey = "appointment_received"
  relatedFormType = "APPOINTMENT"
  relatedRecordId = "test-record"
} | ConvertTo-Json -Depth 10

Invoke-RestMethod `
  -Uri "http://127.0.0.1:8000/send" `
  -Method POST `
  -ContentType "application/json" `
  -Headers @{ "X-SMS-Service-Key" = "change-this-secret-key" } `
  -Body $body

## Enable mock sending

Edit .env:

SMS_ENABLED=true
SMS_PROVIDER=mock

Then restart service.

## Custom SMS provider

Edit .env:

SMS_ENABLED=true
SMS_PROVIDER=custom
SMS_API_URL=https://sms-provider.example/send
SMS_API_KEY=provider-api-key
SMS_SENDER_ID=UpdateClinic

## Next phase

Phase 7.7 will connect Next.js API to this Python service and update Prisma SmsLog.
