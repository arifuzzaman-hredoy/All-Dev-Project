#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/update_project}"
COMPOSE_SERVICE="${COMPOSE_SERVICE:-update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"
PASSWORD_FILE="${PASSWORD_FILE:-/root/update_project_final_admin_password.txt}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/update_project}"
ROTATE_SESSION_SECRET="${ROTATE_SESSION_SECRET:-true}"
ROTATE_SMS_INTERNAL_KEY="${ROTATE_SMS_INTERNAL_KEY:-true}"

cd "$APP_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "[security-finalize] Missing $APP_DIR/$ENV_FILE" >&2
  exit 1
fi

mkdir -p "$BACKUP_DIR"
cp "$ENV_FILE" "$ENV_FILE.backup_security_finalization_$(date +%Y%m%d_%H%M%S)"
chmod 600 "$ENV_FILE"

set_env_value() {
  local key="$1"
  local value="$2"
  if grep -q "^${key}=" "$ENV_FILE"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$ENV_FILE"
  else
    printf '\n%s=%s\n' "$key" "$value" >> "$ENV_FILE"
  fi
}

echo "[security-finalize] Generating final admin password"
NEW_ADMIN_PASSWORD="$(openssl rand -hex 12)"
printf '%s\n' "$NEW_ADMIN_PASSWORD" > "$PASSWORD_FILE"
chmod 600 "$PASSWORD_FILE"
set_env_value "ADMIN_PASSWORD" "$NEW_ADMIN_PASSWORD"

if [[ "$ROTATE_SESSION_SECRET" == "true" ]]; then
  echo "[security-finalize] Rotating ADMIN_SESSION_SECRET"
  set_env_value "ADMIN_SESSION_SECRET" "$(openssl rand -hex 48)"
fi

if [[ "$ROTATE_SMS_INTERNAL_KEY" == "true" ]]; then
  echo "[security-finalize] Rotating SMS_SERVICE_API_KEY"
  set_env_value "SMS_SERVICE_API_KEY" "$(openssl rand -hex 32)"
fi

set_env_value "ADMIN_RESET_SHOW_CODE" "false"
set_env_value "ADMIN_RESET_CODE_IN_AUDIT" "false"
chmod 600 "$ENV_FILE"

echo "[security-finalize] Recreating containers so env is reloaded"
docker compose up -d --force-recreate "$COMPOSE_SERVICE" sms_service
sleep 20

echo "[security-finalize] Syncing final admin password into database"
docker compose exec -T "$COMPOSE_SERVICE" node <<'NODE'
const { PrismaClient } = require("@prisma/client");
const { randomBytes, scryptSync } = require("crypto");

const prisma = new PrismaClient();

function hashAdminPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 32 * 1024 * 1024,
  }).toString("hex");

  return ["scrypt", 16384, 8, 1, salt, hash].join("$");
}

async function main() {
  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || "");
  const name = String(process.env.ADMIN_NAME || "Super Admin").trim() || "Super Admin";

  if (!email || !password) throw new Error("ADMIN_EMAIL or ADMIN_PASSWORD missing.");
  if (password.length < 12) throw new Error("ADMIN_PASSWORD is too short.");

  const admin = await prisma.adminUser.upsert({
    where: { email },
    update: {
      name,
      passwordHash: hashAdminPassword(password),
      role: "SUPER_ADMIN",
      isActive: true,
    },
    create: {
      name,
      email,
      passwordHash: hashAdminPassword(password),
      role: "SUPER_ADMIN",
      isActive: true,
    },
  });

  await prisma.adminSession.deleteMany({ where: { adminId: admin.id } });

  await prisma.auditLog.create({
    data: {
      adminId: admin.id,
      action: "SECURITY_FINALIZATION_ADMIN_PASSWORD_ROTATED",
      entity: "AdminUser",
      entityId: admin.id,
      metadata: {
        source: "scripts/vps-security-finalize.sh",
        sessionsCleared: true,
        rotatedAt: new Date().toISOString(),
      },
    },
  }).catch(() => null);

  console.log({ ok: true, email, passwordLength: password.length, sessionsCleared: true });
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => prisma.$disconnect());
NODE

echo "[security-finalize] Running production env check"
npm run env:check:production

echo "[security-finalize] Running security check"
npm run security:check:production

echo "[security-finalize] Creating final clean source backup"
tar -czf "$BACKUP_DIR/final_client_ready_after_security_finalization_$(date +%Y%m%d_%H%M%S).tar.gz" \
  --exclude='.git' \
  --exclude='node_modules' \
  --exclude='.next' \
  -C "$(dirname "$APP_DIR")" "$(basename "$APP_DIR")"

echo "[security-finalize] Container status"
docker compose ps

echo "[security-finalize] Final admin password file: $PASSWORD_FILE"
echo "[security-finalize] Do not paste this password in chat. Share privately only."
