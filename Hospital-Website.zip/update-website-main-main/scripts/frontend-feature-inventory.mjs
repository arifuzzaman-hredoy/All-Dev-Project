#!/usr/bin/env node
/*
 * Phase 8.4 frontend feature inventory helper.
 *
 * Usage:
 *   node scripts/frontend-feature-inventory.mjs /path/to/frontend-reference
 *   FRONTEND_REFERENCE_DIR=/path/to/frontend-reference npm run frontend:inventory
 */

import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";

const projectRoot = process.cwd();
const referenceRoot = path.resolve(
  process.argv[2] || process.env.FRONTEND_REFERENCE_DIR || "../frontend-reference",
);
const outputDir = path.join(projectRoot, "docs", "generated");

const ignoredParts = new Set([
  ".git",
  ".next",
  "node_modules",
  ".turbo",
  "coverage",
]);

const ignoredFiles = new Set([
  "tsconfig.tsbuildinfo",
]);

function sha256(filePath) {
  return createHash("sha256").update(readFileSync(filePath)).digest("hex");
}

function shouldIgnore(relativePath) {
  const parts = relativePath.split(path.sep);
  return parts.some((part) => ignoredParts.has(part)) || ignoredFiles.has(parts.at(-1));
}

function walk(root, base = root) {
  const files = [];

  if (!existsSync(root)) return files;

  for (const entry of readdirSync(root)) {
    const fullPath = path.join(root, entry);
    const relativePath = path.relative(base, fullPath);

    if (shouldIgnore(relativePath)) continue;

    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      files.push(...walk(fullPath, base));
      continue;
    }

    if (stat.isFile()) {
      files.push(relativePath.split(path.sep).join("/"));
    }
  }

  return files.sort((a, b) => a.localeCompare(b));
}

function getFileMap(root) {
  const map = new Map();
  for (const relativePath of walk(root)) {
    map.set(relativePath, sha256(path.join(root, relativePath)));
  }
  return map;
}

function classifyRoute(relativePath) {
  if (!relativePath.startsWith("src/app/")) return null;
  if (!/(page|layout|loading|error|not-found|route)\.(tsx|ts)$/.test(relativePath)) return null;

  return relativePath
    .replace(/^src\/app/, "")
    .replace(/\/(page|layout|loading|error|not-found|route)\.(tsx|ts)$/, "") || "/";
}

function classifyStatus(relativePath, currentFiles) {
  if (currentFiles.has(relativePath)) return "present";

  const productionReplacements = new Map([
    ["src/proxy.ts", "middleware.ts"],
    ["src/lib/pageCms.ts", "src/lib/static-pages.ts"],
    ["src/lib/publicPagesCms.ts", "src/lib/static-pages.ts"],
  ]);

  const replacement = productionReplacements.get(relativePath);
  if (replacement && currentFiles.has(replacement)) {
    return `production-replaced-by:${replacement}`;
  }

  if (relativePath === "h origin main") {
    return "ignored-reference-artifact";
  }

  return "missing";
}

if (!existsSync(referenceRoot)) {
  console.error(`Reference directory not found: ${referenceRoot}`);
  console.error("Pass the frontend developer source directory as the first argument.");
  process.exit(1);
}

const current = getFileMap(projectRoot);
const reference = getFileMap(referenceRoot);

const same = [];
const different = [];
const missing = [];
const referenceInventory = [];

for (const [relativePath, hash] of reference.entries()) {
  const status = classifyStatus(relativePath, current);
  referenceInventory.push({
    path: relativePath,
    route: classifyRoute(relativePath),
    status,
  });

  if (!current.has(relativePath)) {
    missing.push({ path: relativePath, status });
    continue;
  }

  if (current.get(relativePath) === hash) {
    same.push(relativePath);
  } else {
    different.push(relativePath);
  }
}

const currentOnly = [...current.keys()].filter((relativePath) => !reference.has(relativePath));
const missingReal = missing.filter((item) => item.status === "missing");
const productionReplaced = missing.filter((item) => item.status.startsWith("production-replaced-by"));
const ignoredArtifacts = missing.filter((item) => item.status === "ignored-reference-artifact");

const summary = {
  generatedAt: new Date().toISOString(),
  projectRoot,
  referenceRoot,
  counts: {
    referenceFiles: reference.size,
    currentFiles: current.size,
    same: same.length,
    different: different.length,
    currentOnly: currentOnly.length,
    missingTotal: missing.length,
    missingReal: missingReal.length,
    productionReplaced: productionReplaced.length,
    ignoredArtifacts: ignoredArtifacts.length,
  },
  missing,
  different,
  currentOnly,
  referenceInventory,
};

mkdirSync(outputDir, { recursive: true });
writeFileSync(
  path.join(outputDir, "frontend-feature-inventory.json"),
  JSON.stringify(summary, null, 2),
);

const markdown = `# Generated Frontend Feature Inventory\n\nGenerated: ${summary.generatedAt}\n\nReference: \`${referenceRoot}\`\n\nCurrent project: \`${projectRoot}\`\n\n## Summary\n\n| Metric | Count |\n|---|---:|\n| Reference files | ${summary.counts.referenceFiles} |\n| Current files | ${summary.counts.currentFiles} |\n| Same files | ${summary.counts.same} |\n| Different files | ${summary.counts.different} |\n| Current-only production files | ${summary.counts.currentOnly} |\n| Missing total | ${summary.counts.missingTotal} |\n| Missing real | ${summary.counts.missingReal} |\n| Production replaced | ${summary.counts.productionReplaced} |\n| Ignored reference artifacts | ${summary.counts.ignoredArtifacts} |\n\n## Missing / replaced files\n\n${missing.map((item) => `- \`${item.path}\` — ${item.status}`).join("\n") || "None"}\n\n## Different reference files\n\n${different.map((item) => `- \`${item}\``).join("\n") || "None"}\n`;

writeFileSync(path.join(outputDir, "frontend-feature-inventory.md"), markdown);

console.log("Frontend feature inventory completed.");
console.log(summary.counts);
console.log(`JSON: ${path.join(outputDir, "frontend-feature-inventory.json")}`);
console.log(`Markdown: ${path.join(outputDir, "frontend-feature-inventory.md")}`);

if (missingReal.length > 0) {
  console.error("Real missing files found:");
  for (const item of missingReal) console.error(`- ${item.path}`);
  process.exitCode = 2;
}
