#!/usr/bin/env bash
set -euo pipefail

PROJECT_NAME="${PROJECT_NAME:-update_project}"
PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"
APP_CONTAINER="${APP_CONTAINER:-update_project}"
UPLOADS_VOLUME="${UPLOADS_VOLUME:-update_project_uploads}"
CONTENT_VOLUME="${CONTENT_VOLUME:-update_project_content}"
BACKUP_FILE="${1:-${BACKUP_FILE:-}}"
CONFIRM="${CONFIRM:-NO}"
RESTORE_DATABASE="${RESTORE_DATABASE:-NO}"
CONFIRM_DATABASE_RESTORE="${CONFIRM_DATABASE_RESTORE:-NO}"
SKIP_PRE_RESTORE_BACKUP="${SKIP_PRE_RESTORE_BACKUP:-NO}"
RESTORE_TMP=""

log() {
  printf '\n[restore] %s\n' "$*"
}

warn() {
  printf '\n[restore:WARNING] %s\n' "$*" >&2
}

fail() {
  printf '\n[restore:ERROR] %s\n' "$*" >&2
  exit 1
}

cleanup() {
  if [[ -n "${RESTORE_TMP}" && -d "${RESTORE_TMP}" ]]; then
    rm -rf "${RESTORE_TMP}"
  fi
}
trap cleanup EXIT

command -v docker >/dev/null 2>&1 || fail "docker is not installed."
command -v tar >/dev/null 2>&1 || fail "tar is not installed."

if [[ -z "${BACKUP_FILE}" ]]; then
  BACKUP_FILE="$(find "${BACKUP_ROOT}" -maxdepth 1 -type f -name "${PROJECT_NAME}_*.tar.gz" | sort -r | head -n 1 || true)"
fi

[[ -n "${BACKUP_FILE}" ]] || fail "No backup file provided and no backup archive found in ${BACKUP_ROOT}."
[[ -f "${BACKUP_FILE}" ]] || fail "Backup file not found: ${BACKUP_FILE}"

if [[ "${CONFIRM}" != "YES" ]]; then
  cat <<MESSAGE
Restore is destructive.
It can overwrite Docker volume data for:
- ${UPLOADS_VOLUME}
- ${CONTENT_VOLUME}

To continue, run:
  CONFIRM=YES bash scripts/restore.sh "${BACKUP_FILE}"

Database restore is skipped by default. To restore database too:
  CONFIRM=YES RESTORE_DATABASE=YES CONFIRM_DATABASE_RESTORE=YES bash scripts/restore.sh "${BACKUP_FILE}"
MESSAGE
  exit 1
fi

load_env() {
  local env_path="${PROJECT_ROOT}/${ENV_FILE}"
  if [[ -f "${env_path}" ]]; then
    # shellcheck disable=SC1090
    set -a
    source "${env_path}"
    set +a
  else
    warn "${env_path} not found. Database restore env values may be missing."
  fi
}

restore_volume_from_tar() {
  local volume_name="$1"
  local source_tar="$2"

  if [[ ! -f "${source_tar}" ]]; then
    warn "Backup item not found: ${source_tar}. Skipping ${volume_name}."
    return 0
  fi

  log "Restoring Docker volume: ${volume_name}"
  docker volume create "${volume_name}" >/dev/null
  docker run --rm \
    -v "${volume_name}:/data" \
    -v "$(dirname "${source_tar}"):/backup:ro" \
    alpine:3.20 \
    sh -c "rm -rf /data/* /data/.[!.]* /data/..?* 2>/dev/null || true; cd /data && tar -xzf /backup/$(basename "${source_tar}")"
}

restore_database() {
  local db_file="$1"

  if [[ "${RESTORE_DATABASE}" == "YES" && "${CONFIRM_DATABASE_RESTORE}" != "YES" ]]; then
    fail "Database restore requires CONFIRM_DATABASE_RESTORE=YES in addition to RESTORE_DATABASE=YES."
  fi

  if [[ "${RESTORE_DATABASE}" != "YES" ]]; then
    warn "Database restore skipped. Set RESTORE_DATABASE=YES to restore database.sql."
    return 0
  fi

  if [[ ! -f "${db_file}" ]]; then
    warn "database.sql not found in backup. Skipping DB restore."
    return 0
  fi

  load_env

  if [[ -n "${POSTGRES_CONTAINER:-}" && -n "${POSTGRES_DB:-}" && -n "${POSTGRES_USER:-}" ]]; then
    if docker inspect "${POSTGRES_CONTAINER}" >/dev/null 2>&1; then
      log "Restoring PostgreSQL into Docker container: ${POSTGRES_CONTAINER}"
      cat "${db_file}" | docker exec -i -e PGPASSWORD="${POSTGRES_PASSWORD:-}" "${POSTGRES_CONTAINER}" \
        psql -U "${POSTGRES_USER}" -d "${POSTGRES_DB}"
      return 0
    fi
    warn "POSTGRES_CONTAINER is set but container not found: ${POSTGRES_CONTAINER}"
  fi

  if [[ -n "${DATABASE_URL:-}" ]]; then
    if command -v psql >/dev/null 2>&1; then
      log "Restoring PostgreSQL using DATABASE_URL"
      psql "${DATABASE_URL}" < "${db_file}"
      return 0
    fi
    fail "DATABASE_URL exists but psql is not installed on host."
  fi

  warn "No database restore configuration found. Skipping DB restore."
}

log "Backup file: ${BACKUP_FILE}"

if [[ -f "${PROJECT_ROOT}/scripts/backup-verify.sh" ]]; then
  bash "${PROJECT_ROOT}/scripts/backup-verify.sh" "${BACKUP_FILE}"
else
  tar -tzf "${BACKUP_FILE}" >/dev/null
fi

if [[ "${SKIP_PRE_RESTORE_BACKUP}" != "YES" && -f "${PROJECT_ROOT}/scripts/backup.sh" ]]; then
  log "Creating safety backup before restore..."
  bash "${PROJECT_ROOT}/scripts/backup.sh" || warn "Pre-restore backup failed. Continuing because restore was explicitly confirmed."
fi

RESTORE_TMP="$(mktemp -d)"
tar -xzf "${BACKUP_FILE}" -C "${RESTORE_TMP}"
EXTRACTED_DIR="$(find "${RESTORE_TMP}" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
[[ -n "${EXTRACTED_DIR}" ]] || fail "Could not find extracted backup folder."

log "Stopping app container before volume restore..."
(cd "${PROJECT_ROOT}" 2>/dev/null && docker compose stop "${APP_CONTAINER}" 2>/dev/null || true)

restore_volume_from_tar "${UPLOADS_VOLUME}" "${EXTRACTED_DIR}/uploads-volume.tar.gz"
restore_volume_from_tar "${CONTENT_VOLUME}" "${EXTRACTED_DIR}/content-volume.tar.gz"
restore_database "${EXTRACTED_DIR}/database.sql"

log "Starting app again..."
(cd "${PROJECT_ROOT}" 2>/dev/null && docker compose up -d || true)

log "Restore complete. Run smoke test now:"
echo "  bash scripts/backup-smoke-test.sh"
echo "  docker compose ps"
echo "  docker compose logs --tail=100 ${APP_CONTAINER}"
