-- Update Clinic PostgreSQL database preparation
-- This file is a SAFE TEMPLATE for manual psql usage.
-- Recommended production method: run scripts/postgres-create-update-clinic.sh instead.
--
-- Default values:
--   Database: update_clinic
--   User:     update_clinic_user
--
-- IMPORTANT:
-- PostgreSQL cannot run CREATE DATABASE inside some transaction contexts.
-- If you run this manually, run each block separately from psql as postgres/root.

-- 1) Create application user / role
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'update_clinic_user') THEN
    CREATE ROLE update_clinic_user LOGIN PASSWORD 'CHANGE_ME_STRONG_DB_PASSWORD';
  ELSE
    RAISE NOTICE 'Role update_clinic_user already exists, skipping create.';
  END IF;
END
$$;

-- 2) Create database manually if missing:
-- Run from shell, not inside this SQL transaction:
-- createdb -O update_clinic_user update_clinic

-- 3) Grant privileges after database exists
GRANT ALL PRIVILEGES ON DATABASE update_clinic TO update_clinic_user;

-- 4) Connect to database, then run:
-- \c update_clinic
-- GRANT ALL ON SCHEMA public TO update_clinic_user;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO update_clinic_user;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO update_clinic_user;
