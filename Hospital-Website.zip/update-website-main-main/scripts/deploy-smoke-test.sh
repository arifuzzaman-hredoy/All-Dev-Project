#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${DOMAIN:-update.techteamlead.com}"
APP_PORT="${APP_PORT:-4090}"
APP_CONTAINER="${APP_CONTAINER:-update_project}"

command -v docker >/dev/null 2>&1 || { echo "Docker missing" >&2; exit 1; }
command -v curl >/dev/null 2>&1 || { echo "curl missing" >&2; exit 1; }

echo "Checking container status..."
docker compose ps

echo
echo "Checking direct app port..."
curl -I --max-time 15 "http://127.0.0.1:${APP_PORT}" | sed -n '1,12p'

echo
echo "Checking container logs tail..."
docker compose logs --tail=80 "${APP_CONTAINER}"

echo
if command -v nginx >/dev/null 2>&1; then
  echo "Checking Nginx config..."
  nginx -t
  echo
  echo "Checking Nginx domain proxy with Host header..."
  curl -I --max-time 15 -H "Host: ${DOMAIN}" "http://127.0.0.1" | sed -n '1,16p'
fi

echo
echo "Deploy smoke test complete."
