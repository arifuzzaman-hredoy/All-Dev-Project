#!/usr/bin/env bash
set -euo pipefail

APP_CONTAINER="${APP_CONTAINER:-update_project}"

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: Docker is not installed or not available in PATH." >&2
  exit 1
fi

if ! docker ps --format '{{.Names}}' | grep -qx "$APP_CONTAINER"; then
  echo "ERROR: Container '$APP_CONTAINER' is not running." >&2
  echo "Run: docker compose up -d" >&2
  exit 1
fi

printf "Writing storage test files inside container...\n"
docker exec "$APP_CONTAINER" sh -lc 'mkdir -p /app/public/uploads /app/src/content && date -u > /app/public/uploads/.storage-healthcheck && printf "{\"ok\":true,\"checkedAt\":\"%s\"}\n" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > /app/src/content/.storage-healthcheck.json'

printf "Checking files...\n"
docker exec "$APP_CONTAINER" sh -lc 'test -f /app/public/uploads/.storage-healthcheck && test -f /app/src/content/.storage-healthcheck.json && echo "Storage write test: PASS"'

cat <<MESSAGE

Now test persistence:
  docker compose restart update_project
  bash scripts/storage-smoke-test.sh

If it still says PASS after restart, volumes are working.

MESSAGE
