#!/usr/bin/env bash
set -Eeuo pipefail

DB_NAME="${DB_NAME:-update_clinic}"
DB_USER="${DB_USER:-update_clinic_user}"
DB_PASSWORD="${DB_PASSWORD:-}"
DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5432}"
POSTGRES_SUPERUSER="${POSTGRES_SUPERUSER:-postgres}"

log() { printf '\033[1;34m[postgres-create]\033[0m %s\n' "$*"; }
err() { printf '\033[1;31m[postgres-create:error]\033[0m %s\n' "$*" >&2; }

if [[ -z "$DB_PASSWORD" ]]; then
  err "DB_PASSWORD is required. Example: DB_PASSWORD='strong-password' bash scripts/postgres-create-update-clinic.sh"
  exit 1
fi

if ! command -v psql >/dev/null 2>&1; then
  err "psql not found. Install PostgreSQL client/server first. On Ubuntu: apt install -y postgresql postgresql-contrib"
  exit 1
fi

run_psql() {
  if [[ "$(id -u)" -eq 0 ]] && id "$POSTGRES_SUPERUSER" >/dev/null 2>&1; then
    sudo -u "$POSTGRES_SUPERUSER" psql -v ON_ERROR_STOP=1 "$@"
  else
    psql -U "$POSTGRES_SUPERUSER" -v ON_ERROR_STOP=1 "$@"
  fi
}

log "Preparing PostgreSQL database '$DB_NAME' and user '$DB_USER'..."

ROLE_EXISTS="$(run_psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" || true)"
if [[ "$ROLE_EXISTS" == "1" ]]; then
  log "Role already exists: $DB_USER"
  run_psql -c "ALTER ROLE \"${DB_USER}\" WITH LOGIN PASSWORD '${DB_PASSWORD//\'/\'\'}';"
else
  log "Creating role: $DB_USER"
  run_psql -c "CREATE ROLE \"${DB_USER}\" WITH LOGIN PASSWORD '${DB_PASSWORD//\'/\'\'}';"
fi

DB_EXISTS="$(run_psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" || true)"
if [[ "$DB_EXISTS" == "1" ]]; then
  log "Database already exists: $DB_NAME"
else
  log "Creating database: $DB_NAME"
  run_psql -c "CREATE DATABASE \"${DB_NAME}\" OWNER \"${DB_USER}\";"
fi

log "Applying privileges..."
run_psql -c "GRANT ALL PRIVILEGES ON DATABASE \"${DB_NAME}\" TO \"${DB_USER}\";"
run_psql -d "$DB_NAME" -c "GRANT ALL ON SCHEMA public TO \"${DB_USER}\";"
run_psql -d "$DB_NAME" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO \"${DB_USER}\";"
run_psql -d "$DB_NAME" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO \"${DB_USER}\";"

log "Done. Add this to .env.production:"
printf '\nDATABASE_URL="postgresql://%s:%s@%s:%s/%s?schema=public"\n\n' "$DB_USER" "$DB_PASSWORD" "$DB_HOST" "$DB_PORT" "$DB_NAME"
