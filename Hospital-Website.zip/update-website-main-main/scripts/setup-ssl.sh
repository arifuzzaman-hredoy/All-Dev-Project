#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${DOMAIN:-update.techteamlead.com}"
EMAIL="${EMAIL:-techtemlead@gmail.com}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "ERROR: Run this script as root on the VPS." >&2
  exit 1
fi

if [[ -z "${DOMAIN}" || -z "${EMAIL}" ]]; then
  echo "ERROR: DOMAIN and EMAIL are required." >&2
  exit 1
fi

echo "Checking Certbot installation..."
if ! command -v certbot >/dev/null 2>&1; then
  apt-get update
  apt-get install -y certbot python3-certbot-nginx
fi

echo "Checking DNS resolution for ${DOMAIN}..."
if command -v getent >/dev/null 2>&1; then
  getent ahosts "${DOMAIN}" | head -5 || true
fi

echo "Requesting Let's Encrypt SSL certificate for ${DOMAIN}..."
certbot --nginx \
  -d "${DOMAIN}" \
  --email "${EMAIL}" \
  --agree-tos \
  --redirect \
  --non-interactive

echo "Testing Nginx after SSL..."
nginx -t
systemctl reload nginx

echo "SSL setup complete: https://${DOMAIN}"
