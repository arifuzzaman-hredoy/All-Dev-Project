#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
APP_PORT="${APP_PORT:-4090}"
ENV_FILE="${ENV_FILE:-.env.production}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:${APP_PORT}/api/health}"

pass() { printf '[PASS] %s\n' "$*"; }
warn() { printf '[WARN] %s\n' "$*"; }
fail() { printf '[FAIL] %s\n' "$*"; exit 1; }

[[ -d "$PROJECT_ROOT" ]] || fail "Project root missing: $PROJECT_ROOT"
cd "$PROJECT_ROOT"

command -v git >/dev/null 2>&1 && pass "git installed" || fail "git missing"
command -v docker >/dev/null 2>&1 && pass "docker installed" || fail "docker missing"
docker compose version >/dev/null 2>&1 && pass "docker compose installed" || fail "docker compose missing"
command -v nginx >/dev/null 2>&1 && pass "nginx installed" || warn "nginx missing"
command -v psql >/dev/null 2>&1 && pass "psql installed" || warn "psql missing"
command -v curl >/dev/null 2>&1 && pass "curl installed" || fail "curl missing"

[[ -f "$ENV_FILE" ]] && pass "$ENV_FILE exists" || fail "$ENV_FILE missing"
[[ -f Dockerfile ]] && pass "Dockerfile exists" || fail "Dockerfile missing"
[[ -f docker-compose.yml ]] && pass "docker-compose.yml exists" || fail "docker-compose.yml missing"
[[ -d prisma/migrations ]] && pass "Prisma migrations exist" || fail "prisma/migrations missing"

if [[ -f scripts/production-env-check.js ]]; then
  node scripts/production-env-check.js --env="$ENV_FILE" --production && pass "production env check" || fail "production env check failed"
fi

docker compose config >/dev/null && pass "docker compose config valid" || fail "docker compose config invalid"

if docker compose ps >/dev/null 2>&1; then
  pass "docker compose ps works"
else
  warn "docker compose ps failed; app may not be running yet"
fi

if curl -fsS --max-time 10 "$HEALTH_URL" >/dev/null; then
  pass "health URL OK: $HEALTH_URL"
else
  warn "health URL not OK yet: $HEALTH_URL"
fi

if command -v nginx >/dev/null 2>&1; then
  nginx -t && pass "nginx config OK" || fail "nginx config invalid"
fi

printf '\nFinal VPS check complete.\n'
