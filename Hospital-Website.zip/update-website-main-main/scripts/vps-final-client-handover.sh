#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/var/www/update_project}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/update_project}"
APP_SERVICE="${APP_SERVICE:-update_project}"
BASE_URL="${QA_BASE_URL:-https://update.techteamlead.com}"
STAMP="$(date +%Y%m%d_%H%M%S)"
SOURCE_ZIP="${BACKUP_DIR}/final_client_source_${STAMP}.zip"
SERVER_BACKUP="${BACKUP_DIR}/final_client_server_backup_${STAMP}.tar.gz"
ADMIN_PASSWORD_FILE="/root/update_project_final_admin_password.txt"

echo "=== Phase 8.8 VPS Final Client Handover ==="
echo "Project: ${PROJECT_DIR}"
echo "Backup:  ${BACKUP_DIR}"
echo "Base URL: ${BASE_URL}"

cd "${PROJECT_DIR}"
mkdir -p "${BACKUP_DIR}"

echo "=== 1) Git status and commit ==="
git fetch origin main || true
git status --short
GIT_HEAD="$(git rev-parse --short HEAD)"
echo "HEAD=${GIT_HEAD}"

echo "=== 2) Production checks ==="
npm run env:check:production
npm run db:validate
npm run db:generate
npm run frontend:inventory
npm run backend:support-check
npm run qa:regression
npm run security:check:production
npm run lint
npm run typecheck
npm run build
npm run sms:check

echo "=== 3) Docker rebuild and restart ==="
docker compose build --no-cache
docker compose down --remove-orphans
docker compose up -d
sleep 25
docker compose ps

echo "=== 4) Live smoke test ==="
QA_BASE_URL="${BASE_URL}" npm run qa:live-smoke

echo "=== 5) Clean repo garbage before packaging ==="
git clean -fd -- . \
  ':(exclude).env' \
  ':(exclude).env.production' \
  ':(exclude).env.*' \
  ':(exclude)public/uploads' \
  ':(exclude)public/uploads/**'

echo "=== 6) Create source ZIP from Git HEAD ==="
git archive --format=zip --output="${SOURCE_ZIP}" HEAD
chmod 600 "${SOURCE_ZIP}"
ls -lah "${SOURCE_ZIP}"

echo "=== 7) Create server backup ==="
tar -czf "${SERVER_BACKUP}" \
  --exclude='.git' \
  --exclude='node_modules' \
  --exclude='.next' \
  -C "$(dirname "${PROJECT_DIR}")" "$(basename "${PROJECT_DIR}")"
chmod 600 "${SERVER_BACKUP}"
ls -lah "${SERVER_BACKUP}"

echo "=== 8) Final status ==="
git status --short
git log --oneline -5
docker compose ps
curl -I "${BASE_URL}/api/health"
curl -I "${BASE_URL}/admin/login"
curl -I "${BASE_URL}/career/apply"

echo "=== 9) Admin password file reminder ==="
if [ -f "${ADMIN_PASSWORD_FILE}" ]; then
  ls -lah "${ADMIN_PASSWORD_FILE}"
  echo "Admin password file exists. Do not paste it in chat. Share privately only."
else
  echo "WARNING: ${ADMIN_PASSWORD_FILE} not found. Rotate admin password before client handover."
fi

echo "=== Phase 8.8 handover completed ==="
echo "Source ZIP: ${SOURCE_ZIP}"
echo "Server backup: ${SERVER_BACKUP}"
