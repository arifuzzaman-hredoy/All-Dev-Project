#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"
USE_DOCKER="${USE_DOCKER:-false}"
APP_SERVICE="${APP_SERVICE:-update_project}"

log() {
  printf '\n[prisma-seed] %s\n' "$*"
}

fail() {
  printf '\n[prisma-seed:ERROR] %s\n' "$*" >&2
  exit 1
}

cd "${PROJECT_ROOT}"

if [[ -f "${ENV_FILE}" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "${ENV_FILE}"
  set +a
fi

[[ -n "${DATABASE_URL:-}" ]] || fail "DATABASE_URL is missing. Set it in ${PROJECT_ROOT}/${ENV_FILE} or export it."
[[ -f "prisma/seed.js" ]] || fail "prisma/seed.js missing. Apply Phase 2.3 patch first."

if [[ "${USE_DOCKER}" == "true" ]]; then
  command -v docker >/dev/null 2>&1 || fail "docker is not installed."
  docker compose version >/dev/null 2>&1 || fail "docker compose plugin is missing."
  log "Running seed inside Docker service: ${APP_SERVICE}"
  docker compose run --rm --no-deps "${APP_SERVICE}" npm run db:seed
else
  command -v npm >/dev/null 2>&1 || fail "npm is not installed."
  log "Generating Prisma client..."
  npm run db:generate
  log "Running database seed..."
  npm run db:seed
fi

log "Seed complete."
