#!/usr/bin/env bash
cat <<'PACK'
Update Clinic VPS Command Pack
==============================

1) Go to project:
cd /var/www/update_project

2) Env check:
npm run env:check:production

3) Build/check before deploy:
npm run deploy:check

4) Docker deploy:
bash scripts/deploy.sh

5) Health check:
curl http://127.0.0.1:4090/api/health

6) Logs:
docker compose logs --tail=200 update_project

7) Backup:
bash scripts/backup.sh

8) Verify backup:
bash scripts/backup-verify.sh /var/backups/update_project/YOUR_BACKUP_FILE.tar.gz

9) Restore backup:
RESTORE_CONFIRM=YES RESTORE_DATABASE_CONFIRM=YES bash scripts/restore.sh /var/backups/update_project/YOUR_BACKUP_FILE.tar.gz

10) Final VPS check:
bash scripts/vps-final-check.sh

Read full docs:
- docs/PHASE_5_4_PRODUCTION_DEPLOYMENT_GUIDE.md
- docs/VPS_COMMAND_PACK.md
- docs/GITHUB_ACTIONS_DEPLOYMENT_GUIDE.md
- docs/SSL_NGINX_RUNBOOK.md
- docs/BACKUP_ROLLBACK_RUNBOOK.md
- docs/POST_DEPLOYMENT_QA_CHECKLIST.md
- docs/CLIENT_HANDOVER_GUIDE.md
PACK
