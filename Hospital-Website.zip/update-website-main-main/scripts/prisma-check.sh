#!/usr/bin/env bash
set -euo pipefail

echo "[prisma-check] Validating Prisma schema..."
npx prisma validate

echo "[prisma-check] Generating Prisma client..."
npx prisma generate

echo "[prisma-check] PASS"
