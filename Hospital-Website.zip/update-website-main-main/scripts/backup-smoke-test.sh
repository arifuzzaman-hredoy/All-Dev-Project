#!/usr/bin/env bash
set -euo pipefail

PROJECT_NAME="${PROJECT_NAME:-update_project}"
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/update_project}"

printf '\n[backup-smoke-test] Running backup script...\n'
bash scripts/backup.sh

LATEST_BACKUP="$(find "${BACKUP_ROOT}" -maxdepth 1 -type f -name "${PROJECT_NAME}_*.tar.gz" | sort -r | head -n 1 || true)"

if [[ -z "${LATEST_BACKUP}" || ! -f "${LATEST_BACKUP}" ]]; then
  echo "[backup-smoke-test:ERROR] No backup archive found." >&2
  exit 1
fi

printf '\n[backup-smoke-test] Latest backup:\n'
ls -lh "${LATEST_BACKUP}"

printf '\n[backup-smoke-test] Archive contents preview:\n'
tar -tzf "${LATEST_BACKUP}" | sed -n '1,80p'

printf '\n[backup-smoke-test] PASS\n'
