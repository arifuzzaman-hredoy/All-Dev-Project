#!/usr/bin/env node
import { PrismaClient, FormSubmissionType } from "@prisma/client";

const prisma = new PrismaClient();

function statusLine(label, ok, detail = "") {
  const marker = ok ? "OK" : "CHECK";
  console.log(`${marker.padEnd(6)} ${label}${detail ? `: ${detail}` : ""}`);
  return ok;
}

async function main() {
  console.log("=== Phase 8.5 Backend Support Check ===");

  const [
    admins,
    staticPages,
    careerSubmissions,
    submissions,
    smsTemplates,
    smsLogs,
    mediaAssets,
    auditLogs,
    resetTokens,
    activeSuperAdmins,
  ] = await Promise.all([
    prisma.adminUser.count(),
    prisma.staticPage.count(),
    prisma.formSubmission.count({ where: { formType: FormSubmissionType.CAREER } }),
    prisma.formSubmission.count(),
    prisma.smsTemplate.count(),
    prisma.smsLog.count(),
    prisma.mediaAsset.count(),
    prisma.auditLog.count(),
    prisma.adminPasswordResetToken.count(),
    prisma.adminUser.count({ where: { role: "SUPER_ADMIN", isActive: true } }),
  ]);

  const checks = [
    statusLine("Admin auth backend", admins > 0, `${admins} admin user(s)`),
    statusLine("Static pages DB CMS", staticPages > 0, `${staticPages} page(s)`),
    statusLine("Career applications backend", true, `${careerSubmissions} career / ${submissions} total submission(s)`),
    statusLine("SMS templates", smsTemplates > 0, `${smsTemplates} template(s)`),
    statusLine("SMS logs", true, `${smsLogs} log(s), SMS_ENABLED=${process.env.SMS_ENABLED || "false"}`),
    statusLine("Media backend", true, `${mediaAssets} media asset(s)`),
    statusLine("Audit backend", true, `${auditLogs} audit log(s)`),
    statusLine("Forgot password backend", true, `${resetTokens} reset token record(s)`),
    statusLine("Super Admin management", activeSuperAdmins > 0, `${activeSuperAdmins} active super admin(s)`),
  ];

  const hardFailures = checks.filter((ok) => !ok).length;

  console.log("=== Summary ===");
  console.log({
    generatedAt: new Date().toISOString(),
    hardFailures,
    smsProvider: process.env.SMS_PROVIDER || "mock",
    smsConfigured: process.env.SMS_ENABLED === "true" ? Boolean(process.env.SMS_API_URL) : false,
  });

  if (hardFailures > 0) {
    process.exitCode = 1;
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

