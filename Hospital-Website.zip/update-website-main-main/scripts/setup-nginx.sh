#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${DOMAIN:-update.techteamlead.com}"
PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
NGINX_CONF_SOURCE="${NGINX_CONF_SOURCE:-${PROJECT_ROOT}/nginx/${DOMAIN}.conf}"
NGINX_AVAILABLE="/etc/nginx/sites-available/${DOMAIN}"
NGINX_ENABLED="/etc/nginx/sites-enabled/${DOMAIN}"
APP_PORT="${APP_PORT:-4090}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "ERROR: Run this script as root on the VPS." >&2
  exit 1
fi

if [[ ! -f "${NGINX_CONF_SOURCE}" ]]; then
  echo "ERROR: Nginx config not found: ${NGINX_CONF_SOURCE}" >&2
  echo "Run this from the deployed project root or set PROJECT_ROOT=/path/to/project." >&2
  exit 1
fi

echo "Checking Nginx installation..."
if ! command -v nginx >/dev/null 2>&1; then
  apt-get update
  apt-get install -y nginx
fi

echo "Checking app port ${APP_PORT} on localhost..."
if command -v ss >/dev/null 2>&1; then
  ss -ltn | grep -q ":${APP_PORT} " || echo "WARNING: Nothing is listening on port ${APP_PORT} yet. Start Docker app before final test."
fi

echo "Installing Nginx site config for ${DOMAIN}..."
if [[ -f "${NGINX_AVAILABLE}" ]]; then
  cp "${NGINX_AVAILABLE}" "${NGINX_AVAILABLE}.bak.$(date +%Y%m%d%H%M%S)"
fi

cp "${NGINX_CONF_SOURCE}" "${NGINX_AVAILABLE}"
ln -sfn "${NGINX_AVAILABLE}" "${NGINX_ENABLED}"

# Disable default Nginx site to avoid domain conflicts.
rm -f /etc/nginx/sites-enabled/default

nginx -t
systemctl enable nginx >/dev/null 2>&1 || true
systemctl reload nginx

echo "Nginx setup complete for ${DOMAIN}."
echo "Next test: bash scripts/nginx-smoke-test.sh"
echo "After DNS points to this VPS, run: EMAIL=techtemlead@gmail.com bash scripts/setup-ssl.sh"
