#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"
USE_DOCKER="${USE_DOCKER:-false}"
APP_SERVICE="${APP_SERVICE:-update_project}"

log() {
  printf '\n[prisma-migrate] %s\n' "$*"
}

fail() {
  printf '\n[prisma-migrate:ERROR] %s\n' "$*" >&2
  exit 1
}

cd "${PROJECT_ROOT}"

if [[ -f "${ENV_FILE}" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "${ENV_FILE}"
  set +a
fi

[[ -n "${DATABASE_URL:-}" ]] || fail "DATABASE_URL is missing. Set it in ${PROJECT_ROOT}/${ENV_FILE} or export it."
[[ -d "prisma/migrations" ]] || fail "prisma/migrations directory missing. Apply Phase 2.3 patch first."

if [[ "${USE_DOCKER}" == "true" ]]; then
  command -v docker >/dev/null 2>&1 || fail "docker is not installed."
  docker compose version >/dev/null 2>&1 || fail "docker compose plugin is missing."
  log "Running migration inside Docker service: ${APP_SERVICE}"
  docker compose run --rm --no-deps "${APP_SERVICE}" npm run db:migrate:deploy
else
  command -v npm >/dev/null 2>&1 || fail "npm is not installed."
  log "Generating Prisma client..."
  npm run db:generate
  log "Applying Prisma migrations..."
  npm run db:migrate:deploy
fi

log "Migration complete."
