import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}

async function checkSmsService() {
  const serviceUrl = clean(process.env.SMS_SERVICE_URL);

  if (!serviceUrl) {
    return {
      checked: false,
      ok: false,
      message: "SMS_SERVICE_URL is not configured.",
    };
  }

  try {
    const response = await fetch(`${serviceUrl.replace(/\/$/, "")}/health`, {
      cache: "no-store",
    });

    const body = await response.json().catch(() => null);

    return {
      checked: true,
      ok: response.ok,
      status: response.status,
      body,
    };
  } catch (error) {
    return {
      checked: true,
      ok: false,
      message: error instanceof Error ? error.message : "SMS service failed.",
    };
  }
}

async function main() {
  const smsEnabled = process.env.SMS_ENABLED === "true";
  const smsProvider = clean(process.env.SMS_PROVIDER) || "mock";
  const smsServiceUrl = clean(process.env.SMS_SERVICE_URL);
  const smsApiUrl = clean(process.env.SMS_API_URL);
  const smsSenderId = clean(process.env.SMS_SENDER_ID);
  const templateCount = await prisma.smsTemplate.count();

  console.log("=== SMS Production Check ===");
  console.log("SMS_ENABLED:", smsEnabled);
  console.log("SMS_PROVIDER:", smsProvider);
  console.log("SMS_SERVICE_URL:", smsServiceUrl || "missing");
  console.log("SMS_API_URL:", smsApiUrl ? "configured" : "missing");
  console.log("SMS_SENDER_ID:", smsSenderId || "missing");
  console.log("SmsTemplate count:", templateCount);

  if (templateCount < 8) {
    console.log("WARNING: SMS templates are missing. Run: npm run sms:seed");
  }

  const serviceCheck = await checkSmsService();
  console.log("SMS service check:", serviceCheck);

  if (smsEnabled && !smsServiceUrl) {
    throw new Error("SMS_ENABLED=true but SMS_SERVICE_URL is missing.");
  }

  if (smsEnabled && smsProvider === "custom" && !smsApiUrl) {
    throw new Error("SMS_PROVIDER=custom but SMS_API_URL is missing.");
  }

  console.log("SMS production check completed.");
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
