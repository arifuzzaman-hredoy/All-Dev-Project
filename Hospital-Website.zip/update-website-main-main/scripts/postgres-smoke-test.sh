#!/usr/bin/env bash
set -Eeuo pipefail

DB_NAME="${DB_NAME:-update_clinic}"
DB_USER="${DB_USER:-update_clinic_user}"
DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5432}"
DB_PASSWORD="${DB_PASSWORD:-}"
DATABASE_URL="${DATABASE_URL:-}"
TABLE_NAME="phase_2_1_smoke_test"

log() { printf '\033[1;34m[postgres-smoke-test]\033[0m %s\n' "$*"; }
err() { printf '\033[1;31m[postgres-smoke-test:error]\033[0m %s\n' "$*" >&2; }

if ! command -v psql >/dev/null 2>&1; then
  err "psql not found."
  exit 1
fi

PSQL_ARGS=()
if [[ -n "$DATABASE_URL" ]]; then
  PSQL_ARGS=("$DATABASE_URL")
else
  if [[ -z "$DB_PASSWORD" ]]; then
    err "Set DB_PASSWORD or DATABASE_URL before running this script."
    exit 1
  fi
  export PGPASSWORD="$DB_PASSWORD"
  PSQL_ARGS=(-h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME")
fi

log "Creating temporary smoke-test table..."
psql "${PSQL_ARGS[@]}" -v ON_ERROR_STOP=1 <<SQL
CREATE TABLE IF NOT EXISTS ${TABLE_NAME} (
  id SERIAL PRIMARY KEY,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO ${TABLE_NAME} (message) VALUES ('phase-2-1-postgres-ok');
SELECT id, message, created_at FROM ${TABLE_NAME} ORDER BY id DESC LIMIT 1;
DROP TABLE ${TABLE_NAME};
SQL

log "PASS"
