#!/usr/bin/env node
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const SITE_SETTINGS_KEY = "site.settings";
const siteSettings = {
  siteName: "Update Diagnostic Center",
  tagline: "Advanced care with a human touch",
  description:
    "A modern multi-speciality healthcare destination focused on safe treatment, clear communication, and comfortable patient experiences.",
  logoUrl: "",
  faviconUrl: "",
  phone: "01763-555555",
  emergency: "01971-555555",
  whatsapp: "01763-555555",
  email: "update.diagnostic@gmail.com",
  address: "Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh",
  city: "Rangpur",
  country: "Bangladesh",
  hours: "7:00 AM – 11:00 PM",
  googleMapUrl: "https://maps.google.com/?q=Update+Diagnostic+Rangpur",
  googleMapEmbedUrl: "",
  facebookUrl: "https://www.facebook.com/updatediagnostic/",
  youtubeUrl: "",
  linkedinUrl: "",
  websiteUrl: "https://update.techteamlead.com",
  seoTitle: "Update Diagnostic Center - Advanced Healthcare",
  seoDescription:
    "Update Diagnostic Center provides modern diagnostic and healthcare services with reliable care, clear communication, and patient-first support.",
  seoKeywords:
    "diagnostic center, hospital, healthcare, Rangpur, doctor, emergency, medical service",
  primaryButtonText: "Book Appointment",
  primaryButtonUrl: "/appointment",
  secondaryButtonText: "Call Now",
  secondaryButtonUrl: "tel:01763555555",
  footerText: "Advanced care with a human touch.",
  copyrightText: "© 2026 Update Diagnostic Center. All rights reserved.",
};

const LEGACY_REPLACEMENTS = new Map([
  ["+880 " + "1700 " + "000 000", siteSettings.phone],
  ["+8801700000000", "01763555555"],
  ["tel:+8801700000000", "tel:01763555555"],
  ["tel:10666", "tel:01971555555"],
  ["10666", siteSettings.emergency],
  ["hello" + "@carepointhospital.com", siteSettings.email],
  ["mailto:hello" + "@carepointhospital.com", `mailto:${siteSettings.email}`],
  ["Plot " + "12, " + "Health " + "Avenue, Rangpur", siteSettings.address],
  ["Care" + "Point", "Update Diagnostic Center"],
]);

function replaceLegacyString(value) {
  let next = value;
  for (const [legacy, replacement] of LEGACY_REPLACEMENTS.entries()) {
    next = next.split(legacy).join(replacement);
  }
  return next;
}

function replaceLegacyValues(value) {
  if (typeof value === "string") return replaceLegacyString(value);
  if (Array.isArray(value)) return value.map((item) => replaceLegacyValues(item));
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [key, replaceLegacyValues(item)]),
    );
  }
  return value;
}

function patchStaticPage(page) {
  const patched = replaceLegacyValues(page);

  if (patched.key === "contact") {
    patched.cards = [
      { title: "Phone", description: siteSettings.phone },
      { title: "Emergency", description: siteSettings.emergency },
      { title: "Email", description: siteSettings.email },
      { title: "Address", description: siteSettings.address },
    ];
    patched.primaryButtonLabel = "Call Now";
    patched.primaryButtonHref = "tel:01763555555";
    patched.secondaryButtonLabel = "Book Appointment";
    patched.secondaryButtonHref = "/appointment";
  }

  if (patched.key === "career") {
    patched.primaryButtonHref = `mailto:${siteSettings.email}`;
  }

  return patched;
}

async function main() {
  const demoDoctorWhere = {
    OR: [
      { name: { equals: "ridoy", mode: "insensitive" } },
      { name: { equals: "sabbir", mode: "insensitive" } },
      { designation: { contains: "kkkk", mode: "insensitive" } },
      { designation: { contains: "eeee", mode: "insensitive" } },
      { department: { contains: "kkkk", mode: "insensitive" } },
      { department: { contains: "eeee", mode: "insensitive" } },
    ],
  };

  const demoDoctors = await prisma.doctor.findMany({
    where: demoDoctorWhere,
    select: { id: true, name: true },
  });
  const demoDoctorIds = demoDoctors.map((doctor) => doctor.id);

  if (demoDoctorIds.length > 0) {
    await prisma.doctorSchedule.deleteMany({ where: { doctorId: { in: demoDoctorIds } } });
    await prisma.doctor.updateMany({
      where: { id: { in: demoDoctorIds } },
      data: { isActive: false },
    });
  }

  const savedSettings = await prisma.siteSetting.upsert({
    where: { key: SITE_SETTINGS_KEY },
    update: { value: siteSettings },
    create: { key: SITE_SETTINGS_KEY, value: siteSettings },
  });

  const pages = await prisma.staticPage.findMany();
  let staticPagesPatched = 0;

  for (const page of pages) {
    const patched = patchStaticPage({
      key: page.key,
      slug: page.slug,
      eyebrow: page.eyebrow,
      title: page.title,
      description: page.description,
      heroImage: page.heroImage,
      body: page.body,
      highlights: page.highlights,
      cards: page.cards,
      primaryButtonLabel: page.primaryButtonLabel,
      primaryButtonHref: page.primaryButtonHref,
      secondaryButtonLabel: page.secondaryButtonLabel,
      secondaryButtonHref: page.secondaryButtonHref,
      seoTitle: page.seoTitle,
      seoDescription: page.seoDescription,
      status: page.status,
      sortOrder: page.sortOrder,
      publishedAt: page.publishedAt,
    });

    const before = JSON.stringify({
      eyebrow: page.eyebrow,
      title: page.title,
      description: page.description,
      heroImage: page.heroImage,
      body: page.body,
      highlights: page.highlights,
      cards: page.cards,
      primaryButtonLabel: page.primaryButtonLabel,
      primaryButtonHref: page.primaryButtonHref,
      secondaryButtonLabel: page.secondaryButtonLabel,
      secondaryButtonHref: page.secondaryButtonHref,
      seoTitle: page.seoTitle,
      seoDescription: page.seoDescription,
    });
    const after = JSON.stringify({
      eyebrow: patched.eyebrow,
      title: patched.title,
      description: patched.description,
      heroImage: patched.heroImage,
      body: patched.body,
      highlights: patched.highlights,
      cards: patched.cards,
      primaryButtonLabel: patched.primaryButtonLabel,
      primaryButtonHref: patched.primaryButtonHref,
      secondaryButtonLabel: patched.secondaryButtonLabel,
      secondaryButtonHref: patched.secondaryButtonHref,
      seoTitle: patched.seoTitle,
      seoDescription: patched.seoDescription,
    });

    if (before !== after) {
      await prisma.staticPage.update({
        where: { id: page.id },
        data: {
          eyebrow: patched.eyebrow,
          title: patched.title,
          description: patched.description,
          heroImage: patched.heroImage,
          body: patched.body,
          highlights: patched.highlights,
          cards: patched.cards,
          primaryButtonLabel: patched.primaryButtonLabel,
          primaryButtonHref: patched.primaryButtonHref,
          secondaryButtonLabel: patched.secondaryButtonLabel,
          secondaryButtonHref: patched.secondaryButtonHref,
          seoTitle: patched.seoTitle,
          seoDescription: patched.seoDescription,
        },
      });
      staticPagesPatched += 1;
    }
  }

  console.log(
    JSON.stringify(
      {
        ok: true,
        demoDoctorsFound: demoDoctors,
        demoDoctorsDeactivated: demoDoctorIds.length,
        siteSettingsUpdated: Boolean(savedSettings?.id),
        staticPagesChecked: pages.length,
        staticPagesPatched,
        contact: {
          phone: siteSettings.phone,
          emergency: siteSettings.emergency,
          email: siteSettings.email,
          address: siteSettings.address,
        },
      },
      null,
      2,
    ),
  );
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => prisma.$disconnect());
