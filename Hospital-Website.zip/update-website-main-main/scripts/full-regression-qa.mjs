#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const fail = [];
const warn = [];
const pass = [];

function exists(relativePath) {
  return fs.existsSync(path.join(root, relativePath));
}

function read(relativePath) {
  return fs.readFileSync(path.join(root, relativePath), "utf8");
}

function assertFile(relativePath, label = relativePath) {
  if (exists(relativePath)) pass.push(`file:${label}`);
  else fail.push(`Missing required file: ${relativePath}`);
}

function assertContains(relativePath, patterns, label = relativePath) {
  if (!exists(relativePath)) {
    fail.push(`Missing file for content check: ${relativePath}`);
    return;
  }
  const content = read(relativePath);
  for (const pattern of patterns) {
    const ok = pattern instanceof RegExp ? pattern.test(content) : content.includes(pattern);
    if (ok) pass.push(`content:${label}:${pattern.toString()}`);
    else fail.push(`Missing expected content in ${relativePath}: ${pattern.toString()}`);
  }
}

function listFiles(dir) {
  const out = [];
  const absDir = path.join(root, dir);
  if (!fs.existsSync(absDir)) return out;
  const stack = [absDir];
  while (stack.length) {
    const current = stack.pop();
    for (const item of fs.readdirSync(current, { withFileTypes: true })) {
      const abs = path.join(current, item.name);
      if (item.isDirectory()) stack.push(abs);
      else out.push(path.relative(root, abs).replaceAll(path.sep, "/"));
    }
  }
  return out.sort();
}

const requiredPublicRoutes = [
  "src/app/page.tsx",
  "src/app/about/page.tsx",
  "src/app/services/page.tsx",
  "src/app/doctors/page.tsx",
  "src/app/appointment/page.tsx",
  "src/app/career/page.tsx",
  "src/app/career/apply/page.tsx",
  "src/app/career/events/[slug]/page.tsx",
  "src/app/contact/page.tsx",
  "src/app/privacy-policy/page.tsx",
  "src/app/terms/page.tsx",
  "src/app/support/page.tsx",
];

const requiredAdminRoutes = [
  "src/app/admin/page.tsx",
  "src/app/admin/login/page.tsx",
  "src/app/admin/forgot-password/page.tsx",
  "src/app/admin/forgot-password/verify/page.tsx",
  "src/app/admin/forgot-password/reset/page.tsx",
  "src/app/admin/career/page.tsx",
  "src/app/admin/form-submissions/page.tsx",
  "src/app/admin/frontend-support/page.tsx",
  "src/app/admin/sms-logs/page.tsx",
  "src/app/admin/sms-templates/page.tsx",
  "src/app/admin/exports/page.tsx",
  "src/app/admin/loading.tsx",
];

const requiredApiRoutes = [
  "src/app/api/health/route.ts",
  "src/app/api/form-submissions/route.ts",
  "src/app/api/admin/form-submissions/route.ts",
  "src/app/api/admin/form-submissions/[id]/route.ts",
  "src/app/api/admin/auth/login/route.ts",
  "src/app/api/admin/auth/logout/route.ts",
  "src/app/api/admin/auth/me/route.ts",
  "src/app/api/admin/auth/password-reset/request/route.ts",
  "src/app/api/admin/auth/password-reset/verify/route.ts",
  "src/app/api/admin/auth/password-reset/complete/route.ts",
  "src/app/api/admin/users/route.ts",
  "src/app/api/admin/users/[id]/route.ts",
  "src/app/api/admin/users/[id]/reset-password/route.ts",
  "src/app/api/admin/frontend-support/route.ts",
  "src/app/api/admin/sms-logs/route.ts",
  "src/app/api/admin/sms-templates/route.ts",
  "src/app/api/admin/exports/[entity]/route.ts",
];

const requiredComponents = [
  "src/components/career/CareerApplicationForm.tsx",
  "src/components/career/CareerPublicPage.tsx",
  "src/components/admin/CareerDbApplications.tsx",
  "src/components/admin/AdminLoginForm.tsx",
  "src/components/admin/AdminShell.tsx",
  "src/components/admin/AdminSidebar.tsx",
  "src/components/admin/users/AdminUsersManager.tsx",
  "src/components/public/PublicSitePage.tsx",
  "src/components/public/CmsPublicPages.tsx",
  "src/components/admin/PublicPageEditor.tsx",
];

const requiredLibs = [
  "src/lib/admin-session.ts",
  "src/lib/admin-password.ts",
  "src/lib/admin-password-reset.ts",
  "src/lib/admin-permissions.ts",
  "src/lib/admin-users.ts",
  "src/lib/frontend-backend-support.ts",
  "src/lib/sms.ts",
  "src/lib/careerCms.ts",
];

const requiredScripts = [
  "scripts/frontend-feature-inventory.mjs",
  "scripts/backend-support-check.mjs",
  "scripts/production-sms-check.mjs",
  "scripts/seed-sms-templates.mjs",
  "scripts/production-content-cleanup.mjs",
];

for (const file of [
  ...requiredPublicRoutes,
  ...requiredAdminRoutes,
  ...requiredApiRoutes,
  ...requiredComponents,
  ...requiredLibs,
  ...requiredScripts,
]) {
  assertFile(file);
}

assertContains("src/components/career/CareerApplicationForm.tsx", [
  "fetch(\"/api/form-submissions\"",
  "formType: \"CAREER\"",
], "career apply backend submit");

assertContains("src/components/admin/CareerDbApplications.tsx", [
  "fetch(\"/api/admin/form-submissions",
  "CAREER",
], "admin career db panel");

assertContains("src/app/admin/career/page.tsx", ["CareerDbApplications"], "admin career page");

assertContains("src/components/admin/AdminLoginForm.tsx", ["/api/admin/auth/login", "/admin/forgot-password"], "admin login real endpoint + reset link");

assertContains("src/app/admin/forgot-password/page.tsx", ["/api/admin/auth/password-reset/request"], "forgot password request api");
assertContains("src/app/admin/forgot-password/verify/page.tsx", ["/api/admin/auth/password-reset/verify"], "forgot password verify api");
assertContains("src/app/admin/forgot-password/reset/page.tsx", ["/api/admin/auth/password-reset/complete"], "forgot password complete api");

assertContains("src/lib/admin-password-reset.ts", [
  "adminPasswordResetToken",
  "expiresAt",
  "resetTokenHash",
], "password reset backend lib");


assertContains("src/app/api/admin/users/route.ts", [
  "requireSuperAdminPermission",
  "createAdminUser",
  "listAdminUsers",
], "admin users api");

assertContains("src/components/admin/users/AdminUsersManager.tsx", [
  "/api/admin/users",
  "SUPER_ADMIN",
  "Temporary password",
], "admin users manager");

assertContains("docker-compose.yml", [
  "reset_mailer",
  "services/reset-mailer",
], "python reset mailer compose service");

assertContains("services/reset-mailer/app/main.py", [
  "SMTP_HOST",
  "admin-reset-email",
  "RESET_MAILER_WEBHOOK_SECRET",
], "python reset mailer smtp service");

assertContains("scripts/production-content-cleanup.mjs", [
  "Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh",
  "replaceLegacyValues",
  "staticPagesPatched",
], "production content cleanup parity");

assertContains("src/lib/admin-password.ts", [
  "scryptSync",
  "verifyAdminPassword",
  "hashAdminPassword",
], "admin password hash helper");

assertContains("prisma/schema.prisma", [
  "model AdminPasswordResetToken",
  "model FormSubmission",
  "model SmsLog",
  "model SmsTemplate",
  "model ExportAudit",
], "required prisma models");

const prismaMigrations = listFiles("prisma/migrations").filter((file) => file.endsWith("migration.sql"));
if (prismaMigrations.length > 0) pass.push(`prisma:migrations:${prismaMigrations.length}`);
else warn.push("No Prisma migration files found. Use prisma migrate dev before production DB deploy if schema changed.");

const packageJson = JSON.parse(read("package.json"));
const requiredPackageScripts = [
  "lint",
  "typecheck",
  "build",
  "db:generate",
  "db:migrate:deploy",
  "frontend:inventory",
  "backend:support-check",
  "sms:check",
  "production:content-cleanup",
];
for (const scriptName of requiredPackageScripts) {
  if (packageJson.scripts?.[scriptName]) pass.push(`package-script:${scriptName}`);
  else fail.push(`Missing package script: ${scriptName}`);
}

const docsRequired = [
  "docs/PHASE_8_1_ADMIN_FORGOT_PASSWORD.md",
  "docs/PHASE_8_2_PUBLIC_STATIC_PAGE_FRONTEND_PARITY.md",
  "docs/PHASE_8_3_ADMIN_UI_UX_PARITY.md",
  "docs/PHASE_8_4_FRONTEND_FEATURE_INVENTORY.md",
  "docs/PHASE_8_5_BACKEND_SUPPORT_FOR_FRONTEND_FEATURES.md",
  "docs/PHASE_9_2_PUBLIC_CONTACT_PARITY_FIX.md",
];
for (const file of docsRequired) assertFile(file);

const forbiddenLegacyContent = [
  "+880 " + "1700 " + "000 000",
  "hello" + "@carepointhospital.com",
  "Plot " + "12, " + "Health " + "Avenue, Rangpur",
  "Care" + "Point",
];
const sourceFiles = listFiles("src")
  .concat(listFiles("prisma"), listFiles("scripts"))
  .filter((file) => /\.(ts|tsx|js|mjs|json)$/.test(file));
for (const file of sourceFiles) {
  const content = read(file);
  const found = forbiddenLegacyContent.filter((item) => content.includes(item));
  if (found.length > 0) fail.push(`Legacy public content found in ${file}: ${found.join(", ")}`);
}
if (fail.every((item) => !item.startsWith("Legacy public content found"))) {
  pass.push("content:legacy-contact-clean");
}

const report = {
  ok: fail.length === 0,
  checkedAt: new Date().toISOString(),
  summary: {
    passedChecks: pass.length,
    warnings: warn.length,
    failures: fail.length,
    publicRoutes: requiredPublicRoutes.length,
    adminRoutes: requiredAdminRoutes.length,
    apiRoutes: requiredApiRoutes.length,
    components: requiredComponents.length,
    prismaMigrationFiles: prismaMigrations.length,
  },
  failures: fail,
  warnings: warn,
};

const outputDir = path.join(root, "docs", "generated");
fs.mkdirSync(outputDir, { recursive: true });
fs.writeFileSync(path.join(outputDir, "phase-8-6-regression-report.json"), JSON.stringify(report, null, 2));

const markdown = [
  "# Phase 8.6 Regression QA Report",
  "",
  `Generated: ${report.checkedAt}`,
  "",
  `Status: ${report.ok ? "PASS" : "FAIL"}`,
  "",
  "## Summary",
  "",
  `- Passed checks: ${report.summary.passedChecks}`,
  `- Warnings: ${report.summary.warnings}`,
  `- Failures: ${report.summary.failures}`,
  `- Public routes checked: ${report.summary.publicRoutes}`,
  `- Admin routes checked: ${report.summary.adminRoutes}`,
  `- API routes checked: ${report.summary.apiRoutes}`,
  `- Components checked: ${report.summary.components}`,
  `- Prisma migration files: ${report.summary.prismaMigrationFiles}`,
  "",
  "## Warnings",
  "",
  ...(warn.length ? warn.map((item) => `- ${item}`) : ["- None"]),
  "",
  "## Failures",
  "",
  ...(fail.length ? fail.map((item) => `- ${item}`) : ["- None"]),
  "",
].join("\n");
fs.writeFileSync(path.join(outputDir, "phase-8-6-regression-report.md"), markdown);

console.log(JSON.stringify(report, null, 2));

if (fail.length > 0) process.exit(1);
