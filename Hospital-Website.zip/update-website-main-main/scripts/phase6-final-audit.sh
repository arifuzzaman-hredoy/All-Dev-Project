#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-$(pwd)}"
DOMAIN="${DOMAIN:-update.techteamlead.com}"
APP_PORT="${APP_PORT:-4090}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:${APP_PORT}/api/health}"
PUBLIC_URL="${PUBLIC_URL:-https://${DOMAIN}}"
CHECK_RUNNING_APP="${CHECK_RUNNING_APP:-NO}"
CHECK_PUBLIC_DOMAIN="${CHECK_PUBLIC_DOMAIN:-NO}"

pass() { printf '[PASS] %s\n' "$*"; }
warn() { printf '[WARN] %s\n' "$*"; }
fail() { printf '[FAIL] %s\n' "$*" >&2; exit 1; }

cd "$PROJECT_ROOT"

[[ -f package.json ]] || fail "package.json missing"
[[ -f prisma/schema.prisma ]] || fail "Prisma schema missing"
[[ -f Dockerfile ]] || fail "Dockerfile missing"
[[ -f docker-compose.yml ]] || fail "docker-compose.yml missing"
[[ -f .github/workflows/deploy.yml ]] || fail "GitHub Actions workflow missing"

pass "required project files exist"

if grep -R "localStorage" src --exclude-dir=.next >/tmp/update-localstorage-check.txt 2>/dev/null; then
  cat /tmp/update-localstorage-check.txt
  fail "localStorage reference found in src"
fi
pass "no localStorage usage in src"

if grep -R "public-content.json" src/app src/components src/features --exclude-dir=.next >/tmp/update-public-content-check.txt 2>/dev/null; then
  cat /tmp/update-public-content-check.txt
  fail "public-content.json runtime dependency found"
fi
pass "no public-content.json runtime dependency in app/components/features"

if grep -n "node:20-bookworm-slim" Dockerfile >/dev/null; then
  pass "Dockerfile uses Debian slim base"
else
  fail "Dockerfile is not using node:20-bookworm-slim"
fi

if grep -n "host.docker.internal:host-gateway" docker-compose.yml >/dev/null; then
  pass "docker-compose has host.docker.internal gateway mapping"
else
  fail "docker-compose missing host.docker.internal gateway mapping"
fi

if grep -n "DATABASE_URL" docker-compose.yml >/dev/null; then
  pass "docker-compose passes DATABASE_URL"
else
  fail "docker-compose missing DATABASE_URL"
fi

if grep -n "host.docker.internal" scripts/backup.sh >/dev/null && grep -n "schema" scripts/backup.sh >/dev/null; then
  pass "backup script handles Prisma schema and Docker host URL"
else
  fail "backup script hardening missing"
fi

bash -n scripts/deploy.sh && pass "deploy.sh syntax OK"
bash -n scripts/backup.sh && pass "backup.sh syntax OK"
bash -n scripts/phase6-post-deploy-check.sh && pass "phase6 post deploy syntax OK"

npm run lint
pass "lint passed"

npm run typecheck
pass "typecheck passed"

if [[ "$CHECK_RUNNING_APP" == "YES" ]]; then
  curl -fsS --max-time 15 "$HEALTH_URL" >/dev/null && pass "health endpoint OK: $HEALTH_URL" || fail "health endpoint failed"
else
  warn "running app health check skipped. Set CHECK_RUNNING_APP=YES to enable."
fi

if [[ "$CHECK_PUBLIC_DOMAIN" == "YES" ]]; then
  curl -fsSI --max-time 20 "$PUBLIC_URL" >/dev/null && pass "public domain OK: $PUBLIC_URL" || fail "public domain failed"
else
  warn "public domain check skipped. Set CHECK_PUBLIC_DOMAIN=YES to enable."
fi

printf '\nPhase 6 final audit complete.\n'
