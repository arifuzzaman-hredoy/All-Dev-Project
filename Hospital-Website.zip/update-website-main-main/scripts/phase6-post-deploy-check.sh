#!/usr/bin/env bash
set -euo pipefail

APP_PORT="${APP_PORT:-4090}"
DOMAIN="${DOMAIN:-update.techteamlead.com}"
APP_CONTAINER="${APP_CONTAINER:-update_project}"
BASE_URL="${BASE_URL:-http://127.0.0.1:${APP_PORT}}"
PUBLIC_URL="${PUBLIC_URL:-https://${DOMAIN}}"
CHECK_PUBLIC="${CHECK_PUBLIC:-NO}"

pass() { printf '[PASS] %s\n' "$*"; }
warn() { printf '[WARN] %s\n' "$*"; }
fail() { printf '[FAIL] %s\n' "$*" >&2; exit 1; }

command -v curl >/dev/null 2>&1 || fail "curl missing"
command -v docker >/dev/null 2>&1 || fail "docker missing"

docker compose ps || fail "docker compose ps failed"

if docker compose ps "$APP_CONTAINER" | grep -qiE 'running|up'; then
  pass "container appears running: $APP_CONTAINER"
else
  warn "container may not be running: $APP_CONTAINER"
fi

curl -fsS --max-time 15 "${BASE_URL}/api/health" >/dev/null && pass "health OK: ${BASE_URL}/api/health" || fail "health failed"
curl -fsSI --max-time 15 "${BASE_URL}/" >/dev/null && pass "home OK" || fail "home failed"
curl -fsSI --max-time 15 "${BASE_URL}/admin/login" >/dev/null && pass "admin login page OK" || fail "admin login failed"
curl -fsSI --max-time 15 "${BASE_URL}/services" >/dev/null && pass "services page OK" || warn "services page check failed"
curl -fsSI --max-time 15 "${BASE_URL}/appointment" >/dev/null && pass "appointment page OK" || warn "appointment page check failed"

if [[ "$CHECK_PUBLIC" == "YES" ]]; then
  curl -fsSI --max-time 20 "$PUBLIC_URL" >/dev/null && pass "public domain OK: $PUBLIC_URL" || fail "public domain failed"
  curl -fsS --max-time 20 "${PUBLIC_URL}/api/health" >/dev/null && pass "public health OK" || fail "public health failed"
else
  warn "Skipping public domain check. Set CHECK_PUBLIC=YES PUBLIC_URL=https://your-domain to enable."
fi

if command -v nginx >/dev/null 2>&1; then
  nginx -t && pass "nginx config OK" || fail "nginx config invalid"
fi

printf '\nRecent app logs:\n'
docker compose logs --tail=80 "$APP_CONTAINER" || true

printf '\nPhase 6 post-deploy check complete.\n'
