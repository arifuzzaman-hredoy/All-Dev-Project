#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"
APP_PORT="${APP_PORT:-4090}"
DOMAIN="${DOMAIN:-update.techteamlead.com}"

pass() { printf '[PASS] %s\n' "$*"; }
warn() { printf '[WARN] %s\n' "$*"; }
fail() { printf '[FAIL] %s\n' "$*" >&2; exit 1; }

[[ -d "$PROJECT_ROOT" ]] || fail "Project root missing: $PROJECT_ROOT"
cd "$PROJECT_ROOT"

[[ -f package.json ]] && pass "package.json found" || fail "package.json missing"
[[ -f Dockerfile ]] && pass "Dockerfile found" || fail "Dockerfile missing"
[[ -f docker-compose.yml ]] && pass "docker-compose.yml found" || fail "docker-compose.yml missing"
[[ -d prisma/migrations ]] && pass "Prisma migrations found" || fail "Prisma migrations missing"
[[ -f "$ENV_FILE" ]] && pass "$ENV_FILE found" || fail "$ENV_FILE missing"

command -v node >/dev/null 2>&1 && pass "node installed: $(node -v)" || fail "node missing"
command -v npm >/dev/null 2>&1 && pass "npm installed: $(npm -v)" || fail "npm missing"
command -v git >/dev/null 2>&1 && pass "git installed" || fail "git missing"
command -v docker >/dev/null 2>&1 && pass "docker installed" || fail "docker missing"
docker compose version >/dev/null 2>&1 && pass "docker compose installed" || fail "docker compose missing"
command -v curl >/dev/null 2>&1 && pass "curl installed" || fail "curl missing"

node scripts/production-env-check.js --env="$ENV_FILE" --production && pass "production env valid" || fail "production env invalid"
npm run db:validate && pass "Prisma schema valid" || fail "Prisma validate failed"
docker compose config >/dev/null && pass "docker compose config valid" || fail "docker compose config invalid"

if command -v ss >/dev/null 2>&1; then
  if ss -ltn | grep -q ":${APP_PORT} "; then
    warn "Port ${APP_PORT} is already listening. If this is an existing app, this is OK."
  else
    pass "Port ${APP_PORT} is free before deploy"
  fi
fi

if command -v getent >/dev/null 2>&1; then
  echo "DNS preview for ${DOMAIN}:"
  getent ahosts "$DOMAIN" | head -5 || warn "DNS not resolving yet"
fi

printf '\nPhase 6 preflight complete.\n'
