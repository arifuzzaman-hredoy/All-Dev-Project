#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
DOMAIN="${DOMAIN:-update.techteamlead.com}"
APP_PORT="${APP_PORT:-4090}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "ERROR: Run this script as root on the VPS." >&2
  exit 1
fi

log() {
  printf '\n[bootstrap] %s\n' "$*"
}

log "Updating apt packages..."
apt-get update

log "Installing base packages..."
apt-get install -y ca-certificates curl gnupg git ufw fail2ban nginx certbot python3-certbot-nginx

if ! command -v docker >/dev/null 2>&1; then
  log "Installing Docker official repository..."
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg

  . /etc/os-release
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list

  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

log "Enabling services..."
systemctl enable --now docker
systemctl enable --now nginx
systemctl enable --now fail2ban || true

log "Opening firewall ports. This keeps SSH open."
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow "${APP_PORT}/tcp" comment "Temporary direct app port for testing" || true
ufw --force enable
ufw status verbose || true

log "Creating project root: ${PROJECT_ROOT}"
mkdir -p "${PROJECT_ROOT}"

cat <<MESSAGE

Bootstrap complete.

Next VPS commands:
  cd ${PROJECT_ROOT}
  git clone https://github.com/techtemlead-lab/update-website.git .
  cp .env.example .env.production
  nano .env.production
  chmod +x scripts/*.sh
  bash scripts/deploy.sh

Important:
- If GitHub Actions deploy fails by SSH, check VPS_HOST/VPS_USERNAME/VPS_PASSWORD/VPS_PORT secrets.
- If you later restrict SSH to fixed IP only, GitHub hosted runner deploy can fail because runner IP changes.

MESSAGE
