#!/usr/bin/env bash
cat <<'PACK'
Phase 6 Emergency Commands
==========================

1) See running containers:
cd /var/www/update_project
docker compose ps

2) Read app logs:
docker compose logs --tail=200 update_project

3) Restart app:
docker compose restart update_project

4) Rebuild app:
docker compose build --no-cache
docker compose up -d

5) Check app directly:
curl -I http://127.0.0.1:4090
curl -fsS http://127.0.0.1:4090/api/health

6) Check Nginx:
nginx -t
systemctl reload nginx
journalctl -u nginx --no-pager -n 100

7) Backup before rollback:
bash scripts/backup.sh

8) Git rollback:
git log --oneline -10
git reset --hard PREVIOUS_GOOD_COMMIT
npm install
npm run db:generate
npm run db:migrate:deploy
npm run build
docker compose build --no-cache
docker compose up -d
bash scripts/phase6-post-deploy-check.sh

9) Backup restore:
bash scripts/backup-verify.sh /var/backups/update_project/YOUR_BACKUP.tar.gz
RESTORE_CONFIRM=YES RESTORE_DATABASE_CONFIRM=YES bash scripts/restore.sh /var/backups/update_project/YOUR_BACKUP.tar.gz
docker compose up -d
bash scripts/phase6-post-deploy-check.sh
PACK
