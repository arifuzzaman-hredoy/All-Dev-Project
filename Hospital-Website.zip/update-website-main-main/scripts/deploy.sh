#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
DEPLOY_REPO_URL="${DEPLOY_REPO_URL:-git@github-update-website:techtemlead-lab/update-website.git}"
DEPLOY_BRANCH="${DEPLOY_BRANCH:-main}"
APP_CONTAINER="${APP_CONTAINER:-update_project}"
APP_PORT="${APP_PORT:-4090}"
ENV_FILE="${ENV_FILE:-.env.production}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:${APP_PORT}/api/health}"
RUN_PRE_DEPLOY_BACKUP="${RUN_PRE_DEPLOY_BACKUP:-true}"
RUN_DB_MIGRATIONS="${RUN_DB_MIGRATIONS:-true}"
RUN_PRODUCTION_CONTENT_CLEANUP="${RUN_PRODUCTION_CONTENT_CLEANUP:-true}"

log() {
  printf '\n[deploy] %s\n' "$*"
}

fail() {
  printf '\n[deploy:ERROR] %s\n' "$*" >&2
  exit 1
}

command -v git >/dev/null 2>&1 || fail "git is not installed on this VPS."
command -v docker >/dev/null 2>&1 || fail "docker is not installed on this VPS."
docker compose version >/dev/null 2>&1 || fail "docker compose plugin is not installed on this VPS."
command -v curl >/dev/null 2>&1 || fail "curl is not installed on this VPS."

log "Deploy root: ${PROJECT_ROOT}"
mkdir -p "$(dirname "${PROJECT_ROOT}")"

if [[ ! -d "${PROJECT_ROOT}/.git" ]]; then
  if [[ -d "${PROJECT_ROOT}" && -n "$(ls -A "${PROJECT_ROOT}" 2>/dev/null || true)" ]]; then
    fail "${PROJECT_ROOT} exists but is not a git repository. Move it away or initialize it correctly."
  fi

  log "Cloning repository..."
  git clone --branch "${DEPLOY_BRANCH}" "${DEPLOY_REPO_URL}" "${PROJECT_ROOT}"
fi

cd "${PROJECT_ROOT}"

log "Fetching latest code from ${DEPLOY_BRANCH}..."
git remote set-url origin "${DEPLOY_REPO_URL}"
git fetch origin "${DEPLOY_BRANCH}"
git reset --hard "origin/${DEPLOY_BRANCH}"
git clean -fd

[[ -f "${ENV_FILE}" ]] || fail "Missing ${PROJECT_ROOT}/${ENV_FILE}. Keep production env on the VPS only."

if [[ -f "scripts/production-env-check.js" ]]; then
  log "Checking production environment..."
  node scripts/production-env-check.js --env="${ENV_FILE}" --production || fail "Production environment check failed."
fi

[[ -f "Dockerfile" ]] || fail "Dockerfile missing."
[[ -f "docker-compose.yml" ]] || fail "docker-compose.yml missing."

log "Making scripts executable..."
chmod +x scripts/*.sh || true

if [[ "${RUN_PRE_DEPLOY_BACKUP}" == "true" && -f "scripts/backup.sh" ]]; then
  log "Creating pre-deploy backup..."
  BACKUP_REQUIRE_DATABASE="${BACKUP_REQUIRE_DATABASE:-YES}" bash scripts/backup.sh || fail "Pre-deploy backup failed."
fi

if [[ -f "scripts/prepare-volumes.sh" ]]; then
  log "Preparing persistent Docker volumes..."
  bash scripts/prepare-volumes.sh
fi

log "Building Docker image..."
docker compose build --pull

if [[ "${RUN_DB_MIGRATIONS}" == "true" && -d "prisma/migrations" ]]; then
  log "Running Prisma migrations..."
  docker compose run --rm --no-deps "${APP_CONTAINER}" npm run db:migrate:deploy || fail "Prisma migration failed."
else
  log "Skipping Prisma migrations. RUN_DB_MIGRATIONS=${RUN_DB_MIGRATIONS}"
fi

log "Starting updated container..."
docker compose up -d --remove-orphans

log "Container status..."
docker compose ps

log "Waiting for app health: ${HEALTH_URL}"
for i in $(seq 1 30); do
  if curl -fsS --max-time 10 "${HEALTH_URL}" >/dev/null; then
    log "Healthcheck PASS"
    break
  fi

  if [[ "$i" == "30" ]]; then
    log "Container logs:"
    docker compose logs --tail=180 "${APP_CONTAINER}" || true
    fail "Healthcheck failed after 30 attempts."
  fi

  sleep 4
done

if [[ "${RUN_PRODUCTION_CONTENT_CLEANUP}" == "true" ]]; then
  log "Running production content cleanup..."
  docker compose exec -T "${APP_CONTAINER}" npm run production:content-cleanup || fail "Production content cleanup failed."
else
  log "Skipping production content cleanup. RUN_PRODUCTION_CONTENT_CLEANUP=${RUN_PRODUCTION_CONTENT_CLEANUP}"
fi

if command -v nginx >/dev/null 2>&1; then
  log "Testing Nginx config..."
  nginx -t || fail "Nginx config test failed."
  systemctl reload nginx || true
fi

log "Cleaning unused Docker images lightly..."
docker image prune -f >/dev/null 2>&1 || true

log "Deploy complete."
log "Health URL: ${HEALTH_URL}"
