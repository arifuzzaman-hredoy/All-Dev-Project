#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"

cd "${PROJECT_ROOT}"

if [[ -f "${ENV_FILE}" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "${ENV_FILE}"
  set +a
fi

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "[prisma-status:ERROR] DATABASE_URL is missing."
  exit 1
fi

npm run db:migrate:status
