#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execSync } from 'node:child_process';

const root = process.cwd();
const args = new Set(process.argv.slice(2));
const shouldWrite = args.has('--write');
const now = new Date().toISOString();

function exists(rel) {
  return fs.existsSync(path.join(root, rel));
}

function readJson(rel) {
  return JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8'));
}

function sha256(rel) {
  const filePath = path.join(root, rel);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return null;
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(filePath));
  return hash.digest('hex');
}

function safeGit(command) {
  try {
    return execSync(command, { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
  } catch {
    return null;
  }
}

const packageJson = readJson('package.json');
const checks = [];
const warnings = [];
const failures = [];

function check(name, ok, details = '') {
  checks.push({ name, ok: Boolean(ok), details });
  if (!ok) failures.push({ name, details });
}

function warn(name, condition, details = '') {
  if (condition) warnings.push({ name, details });
}

const requiredSourceFiles = [
  'package.json',
  'package-lock.json',
  'Dockerfile',
  'docker-compose.yml',
  'next.config.ts',
  'middleware.ts',
  'prisma/schema.prisma',
  'src/app/admin/login/page.tsx',
  'src/components/admin/AdminLoginForm.tsx',
  'src/app/admin/forgot-password/page.tsx',
  'src/app/admin/forgot-password/verify/page.tsx',
  'src/app/admin/forgot-password/reset/page.tsx',
  'src/app/api/admin/auth/password-reset/request/route.ts',
  'src/app/api/admin/auth/password-reset/verify/route.ts',
  'src/app/api/admin/auth/password-reset/complete/route.ts',
  'src/app/career/page.tsx',
  'src/app/career/apply/page.tsx',
  'src/components/career/CareerApplicationForm.tsx',
  'src/components/admin/CareerDbApplications.tsx',
  'src/app/admin/career/page.tsx',
  'src/app/api/form-submissions/route.ts',
  'src/app/api/admin/form-submissions/route.ts',
  'src/app/contact/page.tsx',
  'src/app/support/page.tsx',
  'src/app/privacy-policy/page.tsx',
  'src/app/terms/page.tsx',
  'scripts/full-regression-qa.mjs',
  'scripts/live-smoke-test.mjs',
  'scripts/security-finalization-check.mjs',
  'scripts/vps-security-finalize.sh',
  'scripts/client-package-finalizer.mjs',
  'scripts/vps-final-client-handover.sh',
];

for (const rel of requiredSourceFiles) {
  check(`Required file exists: ${rel}`, exists(rel), rel);
}

const requiredScripts = [
  'db:generate',
  'lint',
  'typecheck',
  'build',
  'sms:check',
  'frontend:inventory',
  'backend:support-check',
  'qa:full',
  'qa:deploy-ready',
  'qa:live-smoke',
  'security:check',
  'security:check:production',
  'client:package:check',
  'client:package:write',
  'client:handover:vps',
  'phase8:final',
];

for (const scriptName of requiredScripts) {
  check(`package.json script exists: ${scriptName}`, Boolean(packageJson.scripts?.[scriptName]), scriptName);
}

const docs = [
  'docs/PHASE_8_1_ADMIN_FORGOT_PASSWORD.md',
  'docs/PHASE_8_2_PUBLIC_STATIC_PAGE_FRONTEND_PARITY.md',
  'docs/PHASE_8_3_ADMIN_UI_UX_PARITY.md',
  'docs/PHASE_8_4_FRONTEND_FEATURE_INVENTORY.md',
  'docs/PHASE_8_5_BACKEND_SUPPORT_FOR_FRONTEND_FEATURES.md',
  'docs/PHASE_8_6_FULL_REGRESSION_QA.md',
  'docs/PHASE_8_7_SECURITY_FINALIZATION.md',
  'docs/PHASE_8_8_FINAL_CLIENT_PACKAGE_BACKUP.md',
  'docs/CLIENT_HANDOVER_SUMMARY.md',
  'docs/FINAL_DEPLOY_GITHUB_VPS_CHECKLIST.md',
];

for (const rel of docs) {
  check(`Phase/client doc exists: ${rel}`, exists(rel), rel);
}

const forbiddenSensitiveFiles = [
  '.env',
  '.env.local',
  '.env.production',
  '.env.development.local',
  'id_rsa',
  'id_ed25519',
];

for (const rel of forbiddenSensitiveFiles) {
  check(`Sensitive file not packaged: ${rel}`, !exists(rel), rel);
}

const prismaSchema = fs.existsSync(path.join(root, 'prisma/schema.prisma'))
  ? fs.readFileSync(path.join(root, 'prisma/schema.prisma'), 'utf8')
  : '';
check('Prisma model exists: AdminUser', /model\s+AdminUser\s+/.test(prismaSchema));
check('Prisma model exists: AdminPasswordResetToken', /model\s+AdminPasswordResetToken\s+/.test(prismaSchema));
check('Prisma model exists: FormSubmission', /model\s+FormSubmission\s+/.test(prismaSchema));
check('Prisma model exists: SmsLog', /model\s+SmsLog\s+/.test(prismaSchema));
check('Prisma model exists: SmsTemplate', /model\s+SmsTemplate\s+/.test(prismaSchema));

const migrationsDir = path.join(root, 'prisma/migrations');
const migrations = fs.existsSync(migrationsDir)
  ? fs.readdirSync(migrationsDir).filter((entry) => fs.statSync(path.join(migrationsDir, entry)).isDirectory()).sort()
  : [];
check('Prisma migrations directory has migrations', migrations.length > 0, `${migrations.length} migrations`);

const gitHead = safeGit('git rev-parse --short HEAD');
const gitBranch = safeGit('git rev-parse --abbrev-ref HEAD');
const gitStatus = safeGit('git status --short');
warn('Git context unavailable in archive package', !gitHead, 'This is normal for downloaded ZIP packages created by git archive.');
warn('Git working tree has uncommitted changes', Boolean(gitStatus), gitStatus || '');

const coreHashes = [
  'package.json',
  'prisma/schema.prisma',
  'src/components/career/CareerApplicationForm.tsx',
  'src/components/admin/CareerDbApplications.tsx',
  'src/components/admin/AdminLoginForm.tsx',
  'src/app/api/admin/auth/password-reset/complete/route.ts',
].map((rel) => ({ file: rel, sha256: sha256(rel) }));

const report = {
  phase: '8.8',
  name: 'Final Client Package + Backup',
  generatedAt: now,
  project: packageJson.name,
  version: packageJson.version,
  git: {
    branch: gitBranch,
    head: gitHead,
    statusClean: gitStatus === '',
  },
  summary: {
    status: failures.length === 0 ? 'PASS' : 'FAIL',
    passed: checks.filter((item) => item.ok).length,
    failures: failures.length,
    warnings: warnings.length,
    migrations: migrations.length,
  },
  checks,
  failures,
  warnings,
  migrations,
  coreHashes,
  handoverNotes: [
    'Real SMS sending remains configuration-dependent until the client provides SMS provider API credentials.',
    'Admin password must be delivered privately and never committed or sent in public chat.',
    'Run npm run qa:deploy-ready and npm run security:check:production on the VPS before final handover.',
    'Create a final source archive with git archive and a final server backup after deploy.',
  ],
};

function toMarkdown(data) {
  const lines = [];
  lines.push('# Phase 8.8 Final Client Package Report');
  lines.push('');
  lines.push(`Generated: ${data.generatedAt}`);
  lines.push(`Status: **${data.summary.status}**`);
  lines.push('');
  lines.push('## Summary');
  lines.push('');
  lines.push(`- Passed checks: ${data.summary.passed}`);
  lines.push(`- Failures: ${data.summary.failures}`);
  lines.push(`- Warnings: ${data.summary.warnings}`);
  lines.push(`- Prisma migrations: ${data.summary.migrations}`);
  lines.push(`- Git branch: ${data.git.branch || 'not available in archive'}`);
  lines.push(`- Git HEAD: ${data.git.head || 'not available in archive'}`);
  lines.push('');
  lines.push('## Failures');
  lines.push('');
  if (data.failures.length === 0) lines.push('- None');
  for (const item of data.failures) lines.push(`- ${item.name}${item.details ? ` — ${item.details}` : ''}`);
  lines.push('');
  lines.push('## Warnings');
  lines.push('');
  if (data.warnings.length === 0) lines.push('- None');
  for (const item of data.warnings) lines.push(`- ${item.name}${item.details ? ` — ${item.details}` : ''}`);
  lines.push('');
  lines.push('## Core Hashes');
  lines.push('');
  for (const item of data.coreHashes) lines.push(`- ${item.file}: \`${item.sha256 || 'missing'}\``);
  lines.push('');
  lines.push('## Handover Notes');
  lines.push('');
  for (const note of data.handoverNotes) lines.push(`- ${note}`);
  lines.push('');
  return lines.join('\n');
}

if (shouldWrite) {
  const outDir = path.join(root, 'docs/generated');
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, 'phase-8-8-client-package-report.json'), JSON.stringify(report, null, 2));
  fs.writeFileSync(path.join(outDir, 'phase-8-8-client-package-report.md'), toMarkdown(report));
}

console.log(JSON.stringify({
  status: report.summary.status,
  passed: report.summary.passed,
  failures: report.summary.failures,
  warnings: report.summary.warnings,
  reportWritten: shouldWrite,
}, null, 2));

if (failures.length > 0) process.exit(1);
