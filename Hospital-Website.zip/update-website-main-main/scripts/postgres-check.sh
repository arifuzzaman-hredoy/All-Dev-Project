#!/usr/bin/env bash
set -Eeuo pipefail

DB_NAME="${DB_NAME:-update_clinic}"
DB_USER="${DB_USER:-update_clinic_user}"
DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5432}"
DB_PASSWORD="${DB_PASSWORD:-}"
DATABASE_URL="${DATABASE_URL:-}"

log() { printf '\033[1;34m[postgres-check]\033[0m %s\n' "$*"; }
err() { printf '\033[1;31m[postgres-check:error]\033[0m %s\n' "$*" >&2; }

if ! command -v psql >/dev/null 2>&1; then
  err "psql not found. Install PostgreSQL client/server first."
  exit 1
fi

if [[ -n "$DATABASE_URL" ]]; then
  log "Checking connection using DATABASE_URL..."
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -c "SELECT current_database() AS database, current_user AS user, NOW() AS checked_at;"
else
  if [[ -z "$DB_PASSWORD" ]]; then
    err "Set DB_PASSWORD or DATABASE_URL before running this script."
    err "Example: DB_PASSWORD='password' bash scripts/postgres-check.sh"
    exit 1
  fi
  log "Checking connection to $DB_HOST:$DB_PORT/$DB_NAME as $DB_USER..."
  PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -v ON_ERROR_STOP=1 -c "SELECT current_database() AS database, current_user AS user, NOW() AS checked_at;"
fi

log "PASS"
