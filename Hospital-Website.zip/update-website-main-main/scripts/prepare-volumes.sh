#!/usr/bin/env bash
set -euo pipefail

APP_CONTAINER="${APP_CONTAINER:-update_project}"
UPLOADS_VOLUME="${UPLOADS_VOLUME:-update_project_uploads}"
CONTENT_VOLUME="${CONTENT_VOLUME:-update_project_content}"

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: Docker is not installed or not available in PATH." >&2
  exit 1
fi

printf "Creating persistent Docker volumes if missing...\n"
docker volume create "$UPLOADS_VOLUME" >/dev/null
docker volume create "$CONTENT_VOLUME" >/dev/null

printf "\nVolumes ready:\n"
docker volume ls --filter "name=${UPLOADS_VOLUME}" --filter "name=${CONTENT_VOLUME}"

printf "\nInspect uploads volume:\n"
docker volume inspect "$UPLOADS_VOLUME" --format '{{ .Name }} -> {{ .Mountpoint }}'

printf "\nInspect content volume:\n"
docker volume inspect "$CONTENT_VOLUME" --format '{{ .Name }} -> {{ .Mountpoint }}'

cat <<MESSAGE

Next commands:
  docker compose build
  docker compose up -d
  docker compose ps

After the app starts, run:
  bash scripts/storage-smoke-test.sh

MESSAGE
