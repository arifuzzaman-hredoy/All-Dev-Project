import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const templates = [
  {
    templateKey: "appointment_received",
    title: "Appointment received SMS",
    message:
      "Dear {{patientName}}, your appointment request has been received. Token: {{token}}. We will contact you soon. - {{clinicName}}",
    variables: [
      "patientName",
      "phone",
      "doctorName",
      "serviceName",
      "preferredDate",
      "token",
      "clinicName",
      "clinicPhone"
    ],
    sortOrder: 10
  },
  {
    templateKey: "appointment_manual_created",
    title: "Manual appointment created SMS",
    message:
      "Dear {{patientName}}, your appointment has been created by {{clinicName}}. Token: {{token}}. For help call {{clinicPhone}}.",
    variables: [
      "patientName",
      "phone",
      "preferredDate",
      "token",
      "clinicName",
      "clinicPhone"
    ],
    sortOrder: 20
  },
  {
    templateKey: "appointment_confirmed",
    title: "Appointment confirmed SMS",
    message:
      "Dear {{patientName}}, your appointment has been confirmed. Token: {{token}}. Please arrive on time. - {{clinicName}}",
    variables: [
      "patientName",
      "phone",
      "preferredDate",
      "token",
      "clinicName"
    ],
    sortOrder: 30
  },
  {
    templateKey: "appointment_cancelled",
    title: "Appointment cancelled SMS",
    message:
      "Dear {{patientName}}, your appointment request has been cancelled. For help call {{clinicPhone}}. - {{clinicName}}",
    variables: [
      "patientName",
      "phone",
      "token",
      "clinicName",
      "clinicPhone"
    ],
    sortOrder: 40
  },
  {
    templateKey: "package_booking_received",
    title: "Package booking received SMS",
    message:
      "Dear {{patientName}}, your health package booking request has been received. Package: {{packageName}}. We will contact you soon. - {{clinicName}}",
    variables: [
      "patientName",
      "phone",
      "packageName",
      "preferredDate",
      "clinicName",
      "clinicPhone"
    ],
    sortOrder: 50
  },
  {
    templateKey: "contact_form_received",
    title: "Contact form received SMS",
    message:
      "Dear {{name}}, thank you for contacting {{clinicName}}. We have received your message and will respond soon.",
    variables: [
      "name",
      "phone",
      "clinicName",
      "clinicPhone"
    ],
    sortOrder: 60
  },
  {
    templateKey: "support_form_received",
    title: "Support form received SMS",
    message:
      "Dear {{name}}, your support request has been received by {{clinicName}}. We will contact you soon.",
    variables: [
      "name",
      "phone",
      "clinicName",
      "clinicPhone"
    ],
    sortOrder: 70
  },
  {
    templateKey: "career_form_received",
    title: "Career form received SMS",
    message:
      "Dear {{name}}, your career application has been received by {{clinicName}}. Our HR team will review it.",
    variables: [
      "name",
      "phone",
      "clinicName"
    ],
    sortOrder: 80
  }
];

async function main() {
  for (const template of templates) {
    await prisma.smsTemplate.upsert({
      where: { templateKey: template.templateKey },
      update: {
        title: template.title,
        message: template.message,
        variables: template.variables,
        sortOrder: template.sortOrder,
        isActive: true
      },
      create: {
        templateKey: template.templateKey,
        title: template.title,
        message: template.message,
        variables: template.variables,
        sortOrder: template.sortOrder,
        isActive: true
      }
    });
  }

  console.log(`Seeded ${templates.length} SMS templates.`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
