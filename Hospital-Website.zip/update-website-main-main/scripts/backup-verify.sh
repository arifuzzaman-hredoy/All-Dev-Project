#!/usr/bin/env bash
set -euo pipefail

BACKUP_FILE="${1:-${BACKUP_FILE:-}}"

fail() {
  printf '\n[backup-verify:ERROR] %s\n' "$*" >&2
  exit 1
}

log() {
  printf '\n[backup-verify] %s\n' "$*"
}

[[ -n "${BACKUP_FILE}" ]] || fail "Provide backup archive path: bash scripts/backup-verify.sh /path/file.tar.gz"
[[ -f "${BACKUP_FILE}" ]] || fail "Backup file not found: ${BACKUP_FILE}"
command -v tar >/dev/null 2>&1 || fail "tar is not installed."

log "Checking archive: ${BACKUP_FILE}"
tar -tzf "${BACKUP_FILE}" >/dev/null

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "${TMP_DIR}"' EXIT

tar -xzf "${BACKUP_FILE}" -C "${TMP_DIR}"
EXTRACTED_DIR="$(find "${TMP_DIR}" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
[[ -n "${EXTRACTED_DIR}" ]] || fail "Archive does not contain a backup folder."
[[ -f "${EXTRACTED_DIR}/MANIFEST.txt" ]] || fail "MANIFEST.txt missing."

if [[ -f "${EXTRACTED_DIR}/SHA256SUMS.txt" ]]; then
  log "Verifying SHA256 checksums..."
  (cd "${EXTRACTED_DIR}" && sha256sum -c SHA256SUMS.txt)
else
  log "SHA256SUMS.txt not found. Legacy backup archive; tar integrity passed only."
fi

log "Backup archive looks valid."
