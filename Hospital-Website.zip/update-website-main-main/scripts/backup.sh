#!/usr/bin/env bash
set -euo pipefail

PROJECT_NAME="${PROJECT_NAME:-update_project}"
PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"
APP_CONTAINER="${APP_CONTAINER:-update_project}"
UPLOADS_VOLUME="${UPLOADS_VOLUME:-update_project_uploads}"
CONTENT_VOLUME="${CONTENT_VOLUME:-update_project_content}"
KEEP_BACKUPS="${KEEP_BACKUPS:-14}"
BACKUP_REQUIRE_DATABASE="${BACKUP_REQUIRE_DATABASE:-YES}"
DATABASE_BACKED_UP="NO"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
WORK_DIR="${BACKUP_ROOT}/${PROJECT_NAME}_${TIMESTAMP}"
ARCHIVE_PATH="${BACKUP_ROOT}/${PROJECT_NAME}_${TIMESTAMP}.tar.gz"

log() {
  printf '\n[backup] %s\n' "$*"
}

warn() {
  printf '\n[backup:WARNING] %s\n' "$*" >&2
}

fail() {
  printf '\n[backup:ERROR] %s\n' "$*" >&2
  exit 1
}

command -v docker >/dev/null 2>&1 || fail "docker is not installed."
command -v tar >/dev/null 2>&1 || fail "tar is not installed."

mkdir -p "${BACKUP_ROOT}"
mkdir -p "${WORK_DIR}"

load_env() {
  local env_path="${PROJECT_ROOT}/${ENV_FILE}"
  if [[ -f "${env_path}" ]]; then
    # shellcheck disable=SC1090
    set -a
    source "${env_path}"
    set +a
  else
    warn "${env_path} not found. Database backup env values may be missing."
  fi
}

write_manifest() {
  {
    echo "project_name=${PROJECT_NAME}"
    echo "project_root=${PROJECT_ROOT}"
    echo "created_at=$(date -Iseconds)"
    echo "host=$(hostname)"
    echo "app_container=${APP_CONTAINER}"
    echo "uploads_volume=${UPLOADS_VOLUME}"
    echo "content_volume=${CONTENT_VOLUME}"
    echo "git_commit=$(cd "${PROJECT_ROOT}" 2>/dev/null && git rev-parse HEAD 2>/dev/null || echo unknown)"
    echo "git_branch=$(cd "${PROJECT_ROOT}" 2>/dev/null && git rev-parse --abbrev-ref HEAD 2>/dev/null || echo unknown)"
    echo
    echo "docker_compose_ps<<EOF"
    (cd "${PROJECT_ROOT}" 2>/dev/null && docker compose ps 2>/dev/null || true)
    echo "EOF"
    echo
    echo "prisma_status<<EOF"
    (cd "${PROJECT_ROOT}" 2>/dev/null && npm run db:migrate:status 2>/dev/null || true)
    echo "EOF"
  } > "${WORK_DIR}/MANIFEST.txt"
}

volume_exists() {
  docker volume inspect "$1" >/dev/null 2>&1
}

backup_docker_volume() {
  local volume_name="$1"
  local output_name="$2"

  if volume_exists "${volume_name}"; then
    log "Backing up Docker volume: ${volume_name}"
    docker run --rm \
      -v "${volume_name}:/data:ro" \
      -v "${WORK_DIR}:/backup" \
      alpine:3.20 \
      sh -c "cd /data && tar -czf /backup/${output_name} ."
  else
    warn "Docker volume not found: ${volume_name}. Skipping ${output_name}."
  fi
}

backup_host_path() {
  local source_path="$1"
  local output_name="$2"

  if [[ -d "${source_path}" ]]; then
    log "Backing up host path: ${source_path}"
    tar -czf "${WORK_DIR}/${output_name}" -C "${source_path}" .
  else
    warn "Host path not found: ${source_path}. Skipping ${output_name}."
  fi
}

backup_database() {
  load_env

  local db_output="${WORK_DIR}/database.sql"

  if [[ -n "${POSTGRES_CONTAINER:-}" && -n "${POSTGRES_DB:-}" && -n "${POSTGRES_USER:-}" ]]; then
    if docker inspect "${POSTGRES_CONTAINER}" >/dev/null 2>&1; then
      log "Backing up PostgreSQL from Docker container: ${POSTGRES_CONTAINER}"
      docker exec -e PGPASSWORD="${POSTGRES_PASSWORD:-}" "${POSTGRES_CONTAINER}" \
        pg_dump -U "${POSTGRES_USER}" -d "${POSTGRES_DB}" --clean --if-exists > "${db_output}"
      DATABASE_BACKED_UP="YES"
      return 0
    fi
    warn "POSTGRES_CONTAINER is set but container not found: ${POSTGRES_CONTAINER}"
  fi

  if [[ -n "${DATABASE_URL:-}" ]]; then
    if command -v pg_dump >/dev/null 2>&1; then
      log "Backing up PostgreSQL using DATABASE_URL"

      # Prisma supports ?schema=public in DATABASE_URL, but pg_dump does not.
      # Strip Prisma-only query params before passing the URL to pg_dump.
      local pg_dump_url="${DATABASE_URL}"
      if command -v python3 >/dev/null 2>&1; then
        pg_dump_url="$(DATABASE_URL="${DATABASE_URL}" python3 - <<'PYURL'
import os
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

url = os.environ["DATABASE_URL"]
parts = urlsplit(url)
query = urlencode(
    [(key, value) for key, value in parse_qsl(parts.query, keep_blank_values=True) if key != "schema"],
    doseq=True,
)
hostname = parts.hostname
port = parts.port
username = parts.username
password = parts.password

if hostname == "host.docker.internal":
    hostname = "127.0.0.1"

auth = ""
if username:
    auth += username
    if password:
        auth += ":" + password
    auth += "@"

netloc = auth + hostname
if port:
    netloc += ":" + str(port)

print(urlunsplit((parts.scheme, netloc, parts.path, query, parts.fragment)))
PYURL
)"
      fi

      pg_dump "${pg_dump_url}" --clean --if-exists > "${db_output}"
      DATABASE_BACKED_UP="YES"
      return 0
    fi
    if [[ "${BACKUP_REQUIRE_DATABASE}" == "YES" ]]; then
      fail "DATABASE_URL exists but pg_dump is not installed on host. Install postgresql-client or set BACKUP_REQUIRE_DATABASE=NO."
    fi
    warn "DATABASE_URL exists, but pg_dump is not installed on host. Skipping DB backup."
    return 0
  fi

  if [[ "${BACKUP_REQUIRE_DATABASE}" == "YES" ]]; then
    fail "Database backup is required, but no DATABASE_URL or PostgreSQL container configuration was found."
  fi

  warn "No database backup configured. Skipping because BACKUP_REQUIRE_DATABASE=${BACKUP_REQUIRE_DATABASE}."
}

cleanup_old_backups() {
  if [[ "${KEEP_BACKUPS}" =~ ^[0-9]+$ ]] && [[ "${KEEP_BACKUPS}" -gt 0 ]]; then
    log "Keeping latest ${KEEP_BACKUPS} backup archive(s)."
    find "${BACKUP_ROOT}" -maxdepth 1 -type f -name "${PROJECT_NAME}_*.tar.gz" \
      | sort -r \
      | tail -n +$((KEEP_BACKUPS + 1)) \
      | xargs -r rm -f
  else
    warn "KEEP_BACKUPS is not a positive number. Skipping cleanup."
  fi
}

log "Starting backup for ${PROJECT_NAME}"
log "Project root: ${PROJECT_ROOT}"
log "Backup root: ${BACKUP_ROOT}"

write_manifest

backup_docker_volume "${UPLOADS_VOLUME}" "uploads-volume.tar.gz"
backup_docker_volume "${CONTENT_VOLUME}" "content-volume.tar.gz"

# Host fallback backups are useful before/after Docker volume migration.
backup_host_path "${PROJECT_ROOT}/public/uploads" "uploads-host.tar.gz"
backup_host_path "${PROJECT_ROOT}/src/content" "content-host.tar.gz"

backup_database

if [[ "${BACKUP_REQUIRE_DATABASE}" == "YES" && "${DATABASE_BACKED_UP}" != "YES" ]]; then
  fail "Database backup was required but did not complete."
fi

log "Writing SHA256 checksums..."
(cd "${WORK_DIR}" && find . -type f ! -name SHA256SUMS.txt -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.txt)

log "Creating final backup archive: ${ARCHIVE_PATH}"
tar -czf "${ARCHIVE_PATH}" -C "${BACKUP_ROOT}" "$(basename "${WORK_DIR}")"
rm -rf "${WORK_DIR}"
cleanup_old_backups

log "Backup complete: ${ARCHIVE_PATH}"
ls -lh "${ARCHIVE_PATH}"
