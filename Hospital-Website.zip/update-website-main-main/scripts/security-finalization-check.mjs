#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

const root = process.cwd();
const args = process.argv.slice(2);
const envArg = args.find((arg) => arg.startsWith("--env="));
const envFile = envArg ? envArg.split("=").slice(1).join("=") : null;
const requireEnv = args.includes("--production") || args.includes("--require-env");
const writeReport = args.includes("--write") || process.env.SECURITY_REPORT_WRITE === "true";

const requiredFiles = [
  ".gitignore",
  ".env.production.example",
  "Dockerfile",
  "docker-compose.yml",
  "middleware.ts",
  "scripts/production-env-check.js",
  "scripts/full-regression-qa.mjs",
  "scripts/live-smoke-test.mjs",
  "scripts/vps-security-finalize.sh",
  "prisma/schema.prisma",
  "src/app/api/admin/auth/login/route.ts",
  "src/app/api/admin/auth/password-reset/request/route.ts",
  "src/app/api/admin/auth/password-reset/verify/route.ts",
  "src/app/api/admin/auth/password-reset/complete/route.ts",
  "src/app/admin/forgot-password/page.tsx",
  "src/app/admin/forgot-password/verify/page.tsx",
  "src/app/admin/forgot-password/reset/page.tsx",
];

const report = {
  phase: "8.7",
  name: "Security Finalization",
  generatedAt: new Date().toISOString(),
  status: "PASS",
  passed: [],
  warnings: [],
  failures: [],
  checks: {},
};

function addPass(message) {
  report.passed.push(message);
}

function addWarning(message) {
  report.warnings.push(message);
}

function addFailure(message) {
  report.failures.push(message);
  report.status = "FAIL";
}

function exists(relPath) {
  return fs.existsSync(path.join(root, relPath));
}

function read(relPath) {
  return fs.readFileSync(path.join(root, relPath), "utf8");
}

function parseEnv(content) {
  const values = {};
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const index = line.indexOf("=");
    if (index < 0) continue;
    const key = line.slice(0, index).trim();
    let value = line.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    values[key] = value;
  }
  return values;
}

function placeholder(value) {
  return /change-me|change-this|replace|placeholder|example|your-|admin12345|USER:PASSWORD|CHANGE_ME/i.test(String(value || ""));
}

function shellGit(argsList) {
  try {
    return execFileSync("git", argsList, { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
  } catch {
    return null;
  }
}

for (const file of requiredFiles) {
  if (exists(file)) addPass(`Required file exists: ${file}`);
  else addFailure(`Required file missing: ${file}`);
}

if (exists(".gitignore")) {
  const gitignore = read(".gitignore");
  for (const pattern of [".env", ".env.production", "node_modules", ".next", "*.backup.*", "*.log"]) {
    if (gitignore.includes(pattern)) addPass(`.gitignore protects ${pattern}`);
    else addFailure(`.gitignore missing ${pattern}`);
  }
}

for (const forbidden of [".env.production", ".env.local", ".env"]) {
  if (exists(forbidden)) addFailure(`Sensitive env file is present in source package: ${forbidden}`);
  else addPass(`Sensitive env file not present in source package: ${forbidden}`);
}

if (exists(".env.production.example")) {
  const values = parseEnv(read(".env.production.example"));
  if (values.ADMIN_RESET_SHOW_CODE === "false") addPass("ADMIN_RESET_SHOW_CODE defaults to false in production example");
  else addFailure("ADMIN_RESET_SHOW_CODE should default to false in .env.production.example");

  if (values.SMS_ENABLED === "false") addPass("SMS_ENABLED defaults to false in production example");
  else addFailure("SMS_ENABLED should default to false until client SMS API is configured");

  if (values.SMS_PROVIDER === "mock") addPass("SMS_PROVIDER defaults to mock in production example");
  else addWarning("SMS_PROVIDER should normally default to mock before client API credentials");
}

if (exists("prisma/schema.prisma")) {
  const schema = read("prisma/schema.prisma");
  const schemaChecks = [
    ["AdminUser", /model\s+AdminUser\s+{/],
    ["AdminSession", /model\s+AdminSession\s+{/],
    ["AdminPasswordResetToken", /model\s+AdminPasswordResetToken\s+{/],
    ["AuditLog", /model\s+AuditLog\s+{/],
    ["SmsLog", /model\s+SmsLog\s+{/],
    ["FormSubmission", /model\s+FormSubmission\s+{/],
  ];
  for (const [name, regex] of schemaChecks) {
    if (regex.test(schema)) addPass(`Prisma model exists: ${name}`);
    else addFailure(`Prisma model missing: ${name}`);
  }
  if (/passwordResetTokens\s+AdminPasswordResetToken\[\]/.test(schema)) {
    addPass("AdminUser relation to password reset tokens exists");
  } else {
    addFailure("AdminUser missing passwordResetTokens relation");
  }
}

if (exists("middleware.ts")) {
  const middleware = read("middleware.ts");
  const hasRecoveryPrefix = middleware.includes('pathname.startsWith("/admin/forgot-password")') ||
    middleware.includes("pathname.startsWith('/admin/forgot-password')");
  for (const route of ["/admin/forgot-password", "/admin/forgot-password/verify", "/admin/forgot-password/reset"]) {
    if (hasRecoveryPrefix || middleware.includes(route)) addPass(`Middleware allows public recovery route: ${route}`);
    else addFailure(`Middleware does not allow recovery route: ${route}`);
  }
}

const envPath = envFile ? path.resolve(root, envFile) : null;
if (envPath) {
  if (!fs.existsSync(envPath)) {
    if (requireEnv) addFailure(`Requested env file missing: ${envFile}`);
    else addWarning(`Requested env file missing: ${envFile}`);
  } else {
    const values = parseEnv(fs.readFileSync(envPath, "utf8"));
    const requiredEnvKeys = ["NODE_ENV", "DATABASE_URL", "NEXT_PUBLIC_SITE_URL", "ADMIN_EMAIL", "ADMIN_PASSWORD", "ADMIN_SESSION_SECRET"];
    for (const key of requiredEnvKeys) {
      if (values[key]) addPass(`${envFile}: ${key} is set`);
      else addFailure(`${envFile}: ${key} is missing`);
    }
    if (values.NODE_ENV === "production") addPass(`${envFile}: NODE_ENV=production`);
    else addFailure(`${envFile}: NODE_ENV must be production`);
    if (String(values.NEXT_PUBLIC_SITE_URL || "").startsWith("https://")) addPass(`${envFile}: NEXT_PUBLIC_SITE_URL uses HTTPS`);
    else addFailure(`${envFile}: NEXT_PUBLIC_SITE_URL must use HTTPS`);
    if (String(values.ADMIN_PASSWORD || "").length >= 12 && !placeholder(values.ADMIN_PASSWORD)) addPass(`${envFile}: ADMIN_PASSWORD looks non-default`);
    else addFailure(`${envFile}: ADMIN_PASSWORD must be strong/non-default`);
    if (String(values.ADMIN_SESSION_SECRET || "").length >= 64 && !placeholder(values.ADMIN_SESSION_SECRET)) addPass(`${envFile}: ADMIN_SESSION_SECRET looks strong`);
    else addFailure(`${envFile}: ADMIN_SESSION_SECRET must be 64+ chars and non-default`);
    if (values.ADMIN_RESET_SHOW_CODE === "true") addFailure(`${envFile}: ADMIN_RESET_SHOW_CODE must not be true in production`);
    else addPass(`${envFile}: ADMIN_RESET_SHOW_CODE is not public-display mode`);
    if (values.SMS_ENABLED === "true" && (!values.SMS_API_URL || !values.SMS_API_KEY)) {
      addFailure(`${envFile}: SMS_ENABLED=true requires SMS_API_URL and SMS_API_KEY`);
    } else {
      addPass(`${envFile}: SMS configuration is internally consistent`);
    }
  }
} else {
  addWarning("No env file checked. Run npm run security:check:production on VPS after creating .env.production.");
}

const gitStatus = shellGit(["status", "--short"]);
if (gitStatus === null) {
  addWarning("Git status not available in this source package context.");
} else if (gitStatus) {
  addWarning("Git working tree is not clean. Review before deploy.");
  report.checks.gitStatus = gitStatus.split(/\r?\n/).slice(0, 30);
} else {
  addPass("Git working tree is clean");
}

const migrationsDir = path.join(root, "prisma", "migrations");
if (fs.existsSync(migrationsDir)) {
  const migrations = fs.readdirSync(migrationsDir).filter((name) => fs.statSync(path.join(migrationsDir, name)).isDirectory());
  report.checks.prismaMigrationCount = migrations.length;
  if (migrations.length > 0) addPass(`Prisma migrations present: ${migrations.length}`);
  else addFailure("No Prisma migrations found");
}

report.summary = {
  passed: report.passed.length,
  warnings: report.warnings.length,
  failures: report.failures.length,
};

fs.mkdirSync(path.join(root, "docs", "generated"), { recursive: true });
if (writeReport) {
  const jsonPath = path.join(root, "docs", "generated", "phase-8-7-security-report.json");
  const mdPath = path.join(root, "docs", "generated", "phase-8-7-security-report.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2));
  fs.writeFileSync(mdPath, [
    "# Phase 8.7 Security Finalization Report",
    "",
    `Generated: ${report.generatedAt}`,
    `Status: ${report.status}`,
    "",
    "## Summary",
    "",
    `- Passed: ${report.summary.passed}`,
    `- Warnings: ${report.summary.warnings}`,
    `- Failures: ${report.summary.failures}`,
    "",
    "## Failures",
    "",
    ...(report.failures.length ? report.failures.map((item) => `- ${item}`) : ["- None"]),
    "",
    "## Warnings",
    "",
    ...(report.warnings.length ? report.warnings.map((item) => `- ${item}`) : ["- None"]),
    "",
    "## Passed Checks",
    "",
    ...report.passed.map((item) => `- ${item}`),
    "",
  ].join("\n"));
  console.log(`[security-check] Wrote ${path.relative(root, jsonPath)}`);
  console.log(`[security-check] Wrote ${path.relative(root, mdPath)}`);
}

console.log("=== Security Finalization Check ===");
console.log(`Status: ${report.status}`);
console.log(`Passed: ${report.summary.passed}`);
console.log(`Warnings: ${report.summary.warnings}`);
console.log(`Failures: ${report.summary.failures}`);

for (const warning of report.warnings) console.warn(`[warning] ${warning}`);
for (const failure of report.failures) console.error(`[failure] ${failure}`);

if (report.failures.length > 0) process.exit(1);
