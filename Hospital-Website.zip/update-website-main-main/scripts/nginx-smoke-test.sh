#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${DOMAIN:-update.techteamlead.com}"
APP_PORT="${APP_PORT:-4090}"

if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is required." >&2
  exit 1
fi

echo "Testing direct Docker app on localhost:${APP_PORT}..."
curl -I --max-time 15 "http://127.0.0.1:${APP_PORT}" | sed -n '1,12p'

echo
if command -v nginx >/dev/null 2>&1; then
  echo "Testing Nginx config..."
  nginx -t
fi

echo
echo "Testing Nginx HTTP reverse proxy with Host header..."
curl -I --max-time 15 -H "Host: ${DOMAIN}" "http://127.0.0.1" | sed -n '1,16p'

echo
if curl -fsS --max-time 15 -H "Host: ${DOMAIN}" "http://127.0.0.1" >/dev/null; then
  echo "Nginx reverse proxy test: PASS"
else
  echo "Nginx reverse proxy test: FAIL" >&2
  exit 1
fi
