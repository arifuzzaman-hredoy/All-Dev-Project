#!/usr/bin/env node
/* eslint-disable @typescript-eslint/no-require-imports */
const fs = require("fs");
const path = require("path");

const args = process.argv.slice(2);
const envArg = args.find((arg) => arg.startsWith("--env="));
const envFile = envArg ? envArg.split("=").slice(1).join("=") : ".env.production";
const forceProduction = args.includes("--production");
const fullPath = path.resolve(process.cwd(), envFile);
const errors = [];
const warnings = [];

function parseEnv(content) {
  const values = {};
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const index = line.indexOf("=");
    if (index < 0) continue;
    const key = line.slice(0, index).trim();
    let value = line.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    values[key] = value;
  }
  return values;
}

function requireValue(values, key) {
  if (!values[key] || !String(values[key]).trim()) {
    errors.push(`${key} is required.`);
  }
}

function hasPlaceholder(value) {
  return /change-me|USER:PASSWORD|HOST:5432|DATABASE|example|your-|admin12345/i.test(String(value || ""));
}

if (!fs.existsSync(fullPath)) {
  console.error(`[env-check] Missing ${fullPath}`);
  process.exit(1);
}

const values = parseEnv(fs.readFileSync(fullPath, "utf8"));
const nodeEnv = values.NODE_ENV || process.env.NODE_ENV || "development";
const isProduction = forceProduction || nodeEnv === "production";

requireValue(values, "DATABASE_URL");
requireValue(values, "NEXT_PUBLIC_SITE_URL");
requireValue(values, "ADMIN_EMAIL");
requireValue(values, "ADMIN_PASSWORD");
requireValue(values, "ADMIN_SESSION_SECRET");

if (values.ADMIN_EMAIL && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.ADMIN_EMAIL)) {
  errors.push("ADMIN_EMAIL must be a valid email address.");
}

if (values.DATABASE_URL && !/^postgres(ql)?:\/\//.test(values.DATABASE_URL)) {
  errors.push("DATABASE_URL must be PostgreSQL.");
}

if (hasPlaceholder(values.DATABASE_URL)) {
  errors.push("DATABASE_URL contains placeholder/example values.");
}

if (isProduction) {
  if (values.NODE_ENV !== "production") {
    errors.push("NODE_ENV must be production in .env.production.");
  }
  if (!String(values.NEXT_PUBLIC_SITE_URL || "").startsWith("https://")) {
    errors.push("NEXT_PUBLIC_SITE_URL must use https:// in production.");
  }
  if (/localhost|127\.0\.0\.1|0\.0\.0\.0/i.test(values.NEXT_PUBLIC_SITE_URL || "")) {
    errors.push("NEXT_PUBLIC_SITE_URL must not point to localhost in production.");
  }
  if (String(values.ADMIN_PASSWORD || "").length < 12 || hasPlaceholder(values.ADMIN_PASSWORD)) {
    errors.push("ADMIN_PASSWORD must be strong and non-default in production.");
  }
  if (String(values.ADMIN_SESSION_SECRET || "").length < 64 || hasPlaceholder(values.ADMIN_SESSION_SECRET)) {
    errors.push("ADMIN_SESSION_SECRET must be a random 64+ character value in production.");
  }
} else {
  if (String(values.ADMIN_SESSION_SECRET || "").length < 32) {
    warnings.push("ADMIN_SESSION_SECRET should be at least 32 characters for local/dev.");
  }
}

if (errors.length > 0) {
  console.error("\n[env-check] FAILED");
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`[env-check] PASS: ${envFile}`);
if (warnings.length > 0) {
  for (const warning of warnings) console.warn(`[env-check:warning] ${warning}`);
}
