#!/usr/bin/env node
const baseUrl = (process.env.QA_BASE_URL || process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:4090").replace(/\/$/, "");
const includeWriteTest = process.env.QA_WRITE_TEST === "true";

const routes = [
  "/",
  "/about",
  "/services",
  "/doctors",
  "/appointment",
  "/career",
  "/career/apply",
  "/contact",
  "/privacy-policy",
  "/terms",
  "/support",
  "/admin/login",
];

const apis = [
  ["/api/health", [200]],
  ["/api/site-settings", [200]],
  ["/api/specialities", [200]],
  ["/api/health-packages", [200]],
  ["/api/form-submissions", [405]],
];

const forbiddenContent = [
  "+880 " + "1700 " + "000 000",
  "hello" + "@carepointhospital.com",
  "Plot " + "12, " + "Health " + "Avenue, Rangpur",
  "Care" + "Point",
];

const contentRoutes = ["/", "/about", "/services", "/career", "/contact", "/support"];

async function checkGet(path, expected = [200]) {
  const url = `${baseUrl}${path}`;
  const response = await fetch(url, { method: "GET", redirect: "follow" });
  const ok = expected.includes(response.status);
  return { path, status: response.status, expected, ok };
}

async function checkNoForbiddenContent(path) {
  const url = `${baseUrl}${path}`;
  const response = await fetch(url, { method: "GET", redirect: "follow" });
  const text = await response.text();
  const found = forbiddenContent.filter((item) => text.includes(item));
  return {
    path: `${path} content parity`,
    status: response.status,
    expected: [200],
    ok: response.status === 200 && found.length === 0,
    found,
  };
}

async function checkSiteSettingsContent() {
  const response = await fetch(`${baseUrl}/api/site-settings`, { method: "GET" });
  const data = await response.json().catch(() => null);
  const text = JSON.stringify(data);
  const found = forbiddenContent.filter((item) => text.includes(item));
  const hasUpdatedContact =
    text.includes("01763-555555") &&
    text.includes("01971-555555") &&
    text.includes("update.diagnostic@gmail.com") &&
    text.includes("Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh");

  return {
    path: "/api/site-settings content parity",
    status: response.status,
    expected: [200],
    ok: response.status === 200 && found.length === 0 && hasUpdatedContact,
    found,
  };
}

async function writeCareerTest() {
  const marker = `qa-${Date.now()}`;
  const response = await fetch(`${baseUrl}/api/form-submissions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      formType: "CAREER",
      name: "Automated QA Career User",
      phone: "01722222222",
      email: `${marker}@example.com`,
      subject: "Career Application - Automated QA",
      message: "Automated live smoke test for career form submission.",
      payload: {
        applyType: "job",
        jobTitle: "Automated QA Position",
        source: "phase-9-2-live-smoke-test",
        marker,
      },
    }),
  });
  const body = await response.json().catch(() => null);
  return {
    path: "/api/form-submissions POST CAREER",
    status: response.status,
    expected: [200, 201],
    ok: [200, 201].includes(response.status) && Boolean(body?.submission?.id),
    submissionId: body?.submission?.id ?? null,
    marker,
  };
}

const results = [];
for (const route of routes) results.push(await checkGet(route, [200]));
for (const [route, expected] of apis) results.push(await checkGet(route, expected));
results.push(await checkSiteSettingsContent());
for (const route of contentRoutes) results.push(await checkNoForbiddenContent(route));
if (includeWriteTest) results.push(await writeCareerTest());

const failed = results.filter((item) => !item.ok);
console.table(results.map(({ path, status, expected, ok }) => ({ path, status, expected: expected.join("/"), ok })));
console.log(JSON.stringify({ baseUrl, includeWriteTest, ok: failed.length === 0, failed }, null, 2));
if (failed.length > 0) process.exit(1);
