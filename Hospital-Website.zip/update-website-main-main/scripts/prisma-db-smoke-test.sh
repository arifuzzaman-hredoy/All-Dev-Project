#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/update_project}"
ENV_FILE="${ENV_FILE:-.env.production}"

cd "${PROJECT_ROOT}"

if [[ -f "${ENV_FILE}" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "${ENV_FILE}"
  set +a
fi

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "[prisma-db-smoke-test:ERROR] DATABASE_URL is missing."
  exit 1
fi

node <<'NODE'
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const counts = {
    doctors: await prisma.doctor.count(),
    appointments: await prisma.appointment.count(),
    services: await prisma.service.count(),
    siteSettings: await prisma.siteSetting.count(),
    heroSlides: await prisma.homeHeroSlide.count(),
  };
  console.log('[prisma-db-smoke-test] PASS', counts);
}

main()
  .catch((error) => {
    console.error('[prisma-db-smoke-test:ERROR]', error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
NODE
