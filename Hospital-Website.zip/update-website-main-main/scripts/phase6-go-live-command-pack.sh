#!/usr/bin/env bash
cat <<'PACK'
Phase 6 Go-live Command Pack
============================

LOCAL WINDOWS POWERSHELL
------------------------
cd "G:\Current Project\Development\Update Project\update-website-main"
npm install
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
npm run dev

VPS FIRST SETUP
---------------
apt update && apt upgrade -y
apt install -y git curl unzip ufw fail2ban nginx certbot python3-certbot-nginx postgresql-client
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker

VPS PROJECT SETUP
-----------------
mkdir -p /var/www
cd /var/www
git clone YOUR_GITHUB_REPO_URL update_project
cd /var/www/update_project
chmod +x scripts/*.sh
cp .env.production.example .env.production
nano .env.production
npm install
npm run env:check:production
bash scripts/phase6-live-preflight.sh

VPS DATABASE + BUILD
--------------------
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run db:migrate:status
npm run deploy:check

VPS DOCKER LIVE DEPLOY
----------------------
docker compose build --no-cache
docker compose up -d
bash scripts/phase6-post-deploy-check.sh

VPS NGINX + SSL
---------------
DOMAIN=update.techteamlead.com APP_PORT=4090 bash scripts/setup-nginx.sh
DOMAIN=update.techteamlead.com EMAIL=admin@example.com bash scripts/setup-ssl.sh
CHECK_PUBLIC=YES PUBLIC_URL=https://update.techteamlead.com bash scripts/phase6-post-deploy-check.sh

BACKUP
------
bash scripts/backup.sh
LATEST_BACKUP=$(find /var/backups/update_project -maxdepth 1 -type f -name 'update_project_*.tar.gz' | sort -r | head -n 1)
bash scripts/backup-verify.sh "$LATEST_BACKUP"

FINAL CHECK
-----------
bash scripts/vps-final-check.sh
curl -I https://update.techteamlead.com
curl -fsS https://update.techteamlead.com/api/health

ROLLBACK HELP
-------------
bash scripts/phase6-emergency-commands.sh
PACK
