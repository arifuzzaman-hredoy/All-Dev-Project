import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  {
    linterOptions: {
      reportUnusedDisableDirectives: false,
    },
    rules: {
      // Frontend design is locked to the client-approved UI. Do not rewrite
      // visual components just to satisfy React compiler stylistic lint rules.
      "react-hooks/set-state-in-effect": "off",
      "@typescript-eslint/no-unused-vars": "off",
      // This project still has reusable CMS/admin image components that accept
      // arbitrary local/data URLs. Convert them module-by-module later instead
      // of blocking validation with raw image warnings.
      "@next/next/no-img-element": "off",
    },
  },
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",

    // Prisma seed is a Node/CommonJS operational script, not app source.
    "prisma/seed.js",
  ]),
]);

export default eslintConfig;
