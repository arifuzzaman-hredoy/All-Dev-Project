# Phase 1.3 — Nginx + SSL Guide

This phase adds the Nginx reverse proxy layer for the Dockerized Update Clinic app.

## Target setup

```txt
Visitor -> https://update.techteamlead.com -> Nginx 80/443 -> Docker app on 127.0.0.1:4090
```

The Docker app keeps listening on host port `4090`. Nginx handles public HTTP/HTTPS traffic.

## Added files

```txt
nginx/update.techteamlead.com.conf
scripts/setup-nginx.sh
scripts/setup-ssl.sh
scripts/nginx-smoke-test.sh
docs/NGINX_SSL_GUIDE.md
```

## Prerequisites

Before running this phase on the VPS:

```txt
1. Docker app should already run from Phase 1.1/1.2
2. DNS A record should point update.techteamlead.com to 198.54.121.88
3. Port 80 and 443 must be open on the VPS/firewall
```

## VPS commands

Run on VPS as root:

```bash
cd /var/www/update_project

chmod +x scripts/setup-nginx.sh scripts/setup-ssl.sh scripts/nginx-smoke-test.sh

# Make sure app is running first
docker compose up -d
docker compose ps

# Install/enable Nginx reverse proxy
bash scripts/setup-nginx.sh

# Test Nginx proxy before SSL
bash scripts/nginx-smoke-test.sh
```

Then install SSL after DNS points correctly:

```bash
EMAIL=techtemlead@gmail.com DOMAIN=update.techteamlead.com bash scripts/setup-ssl.sh
```

## Manual SSL command

If you do not want to use the script:

```bash
certbot --nginx -d update.techteamlead.com --email techtemlead@gmail.com --agree-tos --redirect
```

## Test URLs

```txt
http://update.techteamlead.com
https://update.techteamlead.com
https://update.techteamlead.com/admin
```

## Common problems

### 1. Certbot fails with unauthorized

DNS is probably not pointing to the VPS yet. Check:

```bash
getent ahosts update.techteamlead.com
```

It should show:

```txt
198.54.121.88
```

### 2. Nginx returns 502 Bad Gateway

The Docker app is not running or not listening on host port `4090`.

Check:

```bash
docker compose ps
docker compose logs --tail=100 update_project
curl -I http://127.0.0.1:4090
```

### 3. Nginx config test fails

Check syntax:

```bash
nginx -t
```

Then inspect:

```bash
cat /etc/nginx/sites-available/update.techteamlead.com
```

## Important warning

Do not point Nginx directly to container port `3000`. In this phase Docker publishes app host port `4090`, so Nginx should proxy to:

```txt
http://127.0.0.1:4090
```

Later, if you remove host port exposure and put Nginx in Docker network, the proxy target will change. Do not mix both strategies.
