# Phase 9.2 — Public Contact / Site Settings Parity Fix

## Goal

Remove old demo public contact content from source defaults, seed data, static-page records, and live QA checks.

## Fixed legacy values

- Legacy demo phone number
- Legacy demo email address
- Legacy demo street address
- Legacy demo vendor/brand text

## Production contact values

- Phone: `01763-555555`
- Emergency: `01971-555555`
- Email: `update.diagnostic@gmail.com`
- Address: `Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh`

## Changed areas

- Site settings defaults
- Admin site settings fallback form
- Static page defaults for Contact and Career
- Prisma seed defaults
- Production content cleanup script
- Live smoke test public content parity check
- Regression QA source-level legacy content check
- Deploy script now runs production content cleanup after deployment

## VPS command after deploy

```bash
cd /var/www/update_project

docker compose exec -T update_project npm run production:content-cleanup

docker compose exec -T update_project env QA_BASE_URL=https://update.techteamlead.com npm run qa:live-smoke
```

## Expected result

The public website and `/api/site-settings` should no longer render old demo phone, email, address, or legacy demo brand text.
