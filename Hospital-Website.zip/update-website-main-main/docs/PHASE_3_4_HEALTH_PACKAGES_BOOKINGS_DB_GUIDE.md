# Phase 3.4 — Health Packages + Package Bookings DB-backed

## What changed

Health Packages and Package Bookings are now handled through API routes and Prisma instead of browser-only local state.

## Data flow

### Health packages

Admin page:

`/admin/pages/health-check`

uses:

- `GET /api/admin/health-packages`
- `POST /api/admin/health-packages`
- `PUT /api/admin/health-packages/:id`
- `PATCH /api/admin/health-packages/:id`
- `DELETE /api/admin/health-packages/:id`
- `POST /api/admin/health-packages/reset`

Public pages use:

- `GET /api/health-packages`
- `GET /api/health-packages/:slug`

Database tables:

- `HealthPackage`
- `HealthPackageTest`

### Package bookings

Public booking form uses:

- `POST /api/package-bookings`

Admin package requests use:

- `GET /api/admin/package-bookings`
- `PATCH /api/admin/package-bookings/:id`
- `DELETE /api/admin/package-bookings/:id`

Database table:

- `PackageBooking`

## Important production note

Local/dev can use Neon `DATABASE_URL`. For VPS production, replace `DATABASE_URL` with the VPS PostgreSQL connection string in `.env.production`.
