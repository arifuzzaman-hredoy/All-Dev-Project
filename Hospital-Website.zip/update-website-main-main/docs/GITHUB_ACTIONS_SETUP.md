# Phase 1.4 — GitHub Actions CI/CD Setup

This phase adds auto deployment after push to the `main` branch.

## Flow

```txt
Push to GitHub main
  -> GitHub Actions validates project
  -> SSH into VPS
  -> Pull latest code in /var/www/update_project
  -> Docker compose build
  -> Docker compose up -d
  -> Healthcheck http://127.0.0.1:4090
  -> Reload Nginx
```

## Added files

```txt
.github/workflows/deploy.yml
scripts/deploy.sh
scripts/server-bootstrap.sh
scripts/deploy-smoke-test.sh
docs/GITHUB_ACTIONS_SETUP.md
```

## Required GitHub Secrets

Go to:

```txt
GitHub Repo -> Settings -> Secrets and variables -> Actions -> New repository secret
```

Add these secrets:

```txt
VPS_HOST=198.54.121.88
VPS_USERNAME=root
VPS_PASSWORD=YOUR_VPS_ROOT_PASSWORD
VPS_PORT=22
DEPLOY_REPO_URL=https://github.com/techtemlead-lab/update-website.git
```

Do not put quotes around secret values.

## VPS prerequisites

Run once on the VPS as root if Docker/Nginx are not installed yet:

```bash
cd /var/www/update_project
chmod +x scripts/server-bootstrap.sh
bash scripts/server-bootstrap.sh
```

If the project does not exist yet, first run:

```bash
mkdir -p /var/www/update_project
cd /var/www/update_project
git clone https://github.com/techtemlead-lab/update-website.git .
```

## Production env file

On VPS:

```bash
cd /var/www/update_project
cp .env.example .env.production
nano .env.production
```

Minimum required values:

```txt
NODE_ENV=production
APP_PORT=4090
NEXT_PUBLIC_SITE_URL=https://update.techteamlead.com
ADMIN_EMAIL=CHANGE_ME_REAL_ADMIN_EMAIL
ADMIN_PASSWORD=CHANGE_ME_STRONG_PASSWORD
ADMIN_SESSION_SECRET=CHANGE_ME_RANDOM_64_CHARACTER_SECRET
ADMIN_FORCE_LOGIN_ON_REFRESH=false
DATABASE_URL=postgresql://update_clinic_user:CHANGE_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public
```

Generate admin session secret:

```bash
openssl rand -hex 32
```

## Manual deploy command

Before testing GitHub Actions, test manual deploy on VPS:

```bash
cd /var/www/update_project
chmod +x scripts/*.sh
bash scripts/deploy.sh
bash scripts/deploy-smoke-test.sh
```

## GitHub Actions test

After secrets are added:

```bash
git add .
git commit -m "Add production CI/CD deploy"
git push origin main
```

Then check:

```txt
GitHub Repo -> Actions -> Deploy Update Clinic
```

## Common failure reasons

### 1. SSH login failed

Wrong secret:

```txt
VPS_HOST / VPS_USERNAME / VPS_PASSWORD / VPS_PORT
```

Also check the VPS allows password SSH login.

### 2. Project root exists but is not git repo

The workflow expects:

```txt
/var/www/update_project
```

to be a clean git clone. If you manually uploaded random files there, move it away:

```bash
mv /var/www/update_project /var/www/update_project_manual_backup_$(date +%Y%m%d%H%M%S)
mkdir -p /var/www/update_project
git clone https://github.com/techtemlead-lab/update-website.git /var/www/update_project
```

### 3. Missing .env.production

Create it:

```bash
cd /var/www/update_project
cp .env.example .env.production
nano .env.production
```

### 4. Docker build fails

Run manually on VPS:

```bash
cd /var/www/update_project
docker compose build --no-cache
```

### 5. Healthcheck fails

Check:

```bash
docker compose ps
docker compose logs --tail=160 update_project
curl -I http://127.0.0.1:4090
```

## Important security warning

Password-based GitHub Actions deploy works, but SSH key deploy is better.

Also, your earlier requirement said `Allowed SSH IP only`. That conflicts with GitHub hosted runners because their outbound IP can change. If you lock SSH to one fixed IP, GitHub Actions may fail unless you use a self-hosted runner or maintain GitHub's IP ranges yourself.
