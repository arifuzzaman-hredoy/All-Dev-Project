# Phase 3.6 — Patient Stories + Specialities + Corporate Services DB-backed

## What changed

- Patient stories admin/public flow now uses API + PostgreSQL instead of browser-only localStorage.
- Specialities admin/public flow now uses API + PostgreSQL instead of browser-only localStorage.
- Corporate services homepage section now saves/loads from `SiteSetting` JSON in PostgreSQL.
- Public pages still keep fallback defaults if the API/database is temporarily unavailable.

## Test order

```powershell
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run db:migrate:status
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
npm run dev
```

## Browser tests

- `/admin/pages/patient-stories`
- `/patient-stories`
- `/patient-stories/[slug]`
- `/admin/sections/home-specialities`
- `/specialities`
- `/specialities/[slug]`
- `/admin/sections/home-corporate-services`
- `/`

## Production note

Development can use Neon. Production VPS should use the VPS PostgreSQL `DATABASE_URL` in `.env.production`.
