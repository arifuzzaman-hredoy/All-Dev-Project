# Phase 0 LocalStorage to Database Map

This file lists modules that still save data in browser `localStorage`. These must be migrated to PostgreSQL + Prisma in later phases.

## Critical localStorage modules

| Area | Current file | Current storage problem | Future DB target |
|---|---|---|---|
| Site settings | `src/app/admin/site-settings/page.tsx` | Saves only in current browser | `SiteSetting` table |
| Services admin UI | `src/features/admin/services/components/ServiceManager.tsx` | Admin edits can disconnect from public JSON data | `Service`, `ServiceFeature`, `ServiceFaq` tables |
| Health packages | `src/lib/healthPackages.ts` | Browser-only CMS data | `HealthPackage`, `HealthPackageTest` tables |
| Package bookings | `src/lib/packageBookings.ts` | Public booking from one browser is not visible to admin on another device | `PackageBooking` table |
| Specialities | `src/lib/specialties.ts` | Browser-only CMS data | `Speciality`, `SpecialityDoctor` tables |
| Health blogs | `src/lib/healthBlogs.ts` | Browser-only content | `Blog` table |
| News/media | `src/lib/newsMedia.ts` | Browser-only content | `NewsMedia` table |
| Doctor articles | `src/lib/doctorArticles.ts` | Browser-only content | `DoctorArticle` table |
| Patient stories | `src/lib/patientStories.ts` | Browser-only content | `PatientStory` table |
| Corporate services | `src/lib/corporateServices.ts` | Browser-only homepage/corporate content | `CorporateService`, `CorporateLogo` tables |

## Current localStorage keys

```txt
update-diagnostic-center-site-settings
update-diagnostic-center-services-control
HEALTH_PACKAGES_STORAGE_KEY
PACKAGE_BOOKINGS_STORAGE_KEY
SPECIALTIES_STORAGE_KEY
HEALTH_BLOGS_STORAGE_KEY
NEWS_MEDIA_STORAGE_KEY
DOCTOR_ARTICLES_STORAGE_KEY
PATIENT_STORIES_STORAGE_KEY
CORPORATE_SERVICES_STORAGE_KEY
```

## Migration rule

Do not migrate all modules at once. Use this order:

1. Package bookings
2. Health packages
3. Services
4. Site settings
5. Blogs/news/articles
6. Specialities/patient stories/corporate services

Reason: package bookings and services are the most likely to fail real business usage first.
