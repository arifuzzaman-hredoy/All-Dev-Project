# Phase 1.5 — Backup + Restore Guide

This phase adds backup/restore scripts for the Update Clinic production deployment.

## Why this phase exists

The current project still stores important data in local files:

```txt
public/uploads/*
src/content/*.json
```

After Phase 1.2, those paths are protected using Docker named volumes:

```txt
update_project_uploads -> /app/public/uploads
update_project_content -> /app/src/content
```

So the backup script protects:

```txt
Docker uploads volume
Docker content volume
Host public/uploads fallback
Host src/content fallback
Optional PostgreSQL dump for future Phase 2+
```

## Added files

```txt
scripts/backup.sh
scripts/restore.sh
scripts/backup-smoke-test.sh
docs/BACKUP_RESTORE_GUIDE.md
```

## Backup location

Default:

```txt
/var/backups/update_project
```

Backup archive format:

```txt
update_project_YYYYMMDD_HHMMSS.tar.gz
```

## Run backup manually

Run on the VPS as root:

```bash
cd /var/www/update_project
chmod +x scripts/*.sh
bash scripts/backup.sh
```

## Smoke test backup

```bash
cd /var/www/update_project
bash scripts/backup-smoke-test.sh
```

Expected:

```txt
[backup-smoke-test] PASS
```

## Restore latest backup

Restore is destructive, so confirmation is required.

```bash
cd /var/www/update_project
CONFIRM=YES bash scripts/restore.sh
```

## Restore a specific backup

```bash
cd /var/www/update_project
CONFIRM=YES bash scripts/restore.sh /var/backups/update_project/update_project_20260612_193000.tar.gz
```

## Database backup support

Before Phase 2, database backup will be skipped. That is expected.

After PostgreSQL is added, the script can backup database using either Docker container values:

```env
POSTGRES_CONTAINER=update_project_postgres
POSTGRES_DB=update_clinic
POSTGRES_USER=update_clinic_user
POSTGRES_PASSWORD=CHANGE_DB_PASSWORD
```

or by using:

```env
DATABASE_URL=postgresql://update_clinic_user:CHANGE_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public
```

If the database is outside Docker and only `DATABASE_URL` is used, the VPS must have PostgreSQL client tools installed:

```bash
apt-get update
apt-get install -y postgresql-client
```

## Restore database

Database restore is skipped by default for safety.

To restore database too:

```bash
cd /var/www/update_project
CONFIRM=YES RESTORE_DATABASE=YES bash scripts/restore.sh /var/backups/update_project/BACKUP_FILE.tar.gz
```

## Automatic cleanup

Default behavior keeps the latest 14 backup archives:

```bash
KEEP_BACKUPS=14 bash scripts/backup.sh
```

To keep 30:

```bash
KEEP_BACKUPS=30 bash scripts/backup.sh
```

## Add cron backup later

Daily 2:30 AM VPS time:

```bash
crontab -e
```

Add:

```cron
30 2 * * * cd /var/www/update_project && /usr/bin/bash scripts/backup.sh >> /var/log/update_project_backup.log 2>&1
```

## Important warning

Never run this in production unless you intentionally want to delete persistent data:

```bash
docker compose down -v
```

That command removes Docker volumes. Your uploads/content can be lost.
