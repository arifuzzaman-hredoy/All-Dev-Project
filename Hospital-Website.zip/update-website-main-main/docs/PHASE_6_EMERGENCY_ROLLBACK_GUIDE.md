# Phase 6 — Emergency Rollback Guide

Use this only when production deployment is broken.

## Option A — Git rollback to previous commit

```bash
cd /var/www/update_project
bash scripts/backup.sh
git log --oneline -10
git reset --hard PREVIOUS_GOOD_COMMIT
npm install
npm run db:generate
npm run db:migrate:deploy
npm run build
docker compose build --no-cache
docker compose up -d
bash scripts/phase6-post-deploy-check.sh
```

## Option B — Restore backup archive

List backups:

```bash
ls -lh /var/backups/update_project
```

Verify archive:

```bash
bash scripts/backup-verify.sh /var/backups/update_project/YOUR_BACKUP.tar.gz
```

Restore with explicit confirmation:

```bash
RESTORE_CONFIRM=YES RESTORE_DATABASE_CONFIRM=YES bash scripts/restore.sh /var/backups/update_project/YOUR_BACKUP.tar.gz
```

Restart:

```bash
docker compose up -d
bash scripts/phase6-post-deploy-check.sh
```

## Option C — Nginx rollback

```bash
nginx -t
ls -lh /etc/nginx/sites-available/update_project*
cp /etc/nginx/sites-available/update_project.bak.YYYYMMDDHHMMSS /etc/nginx/sites-available/update_project
nginx -t
systemctl reload nginx
```

## Emergency status commands

```bash
docker compose ps
docker compose logs --tail=200 update_project
curl -I http://127.0.0.1:4090
curl -I https://update.techteamlead.com
journalctl -u nginx --no-pager -n 100
```

