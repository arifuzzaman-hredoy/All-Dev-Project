# Phase 8.1 — Real Admin Forgot Password System

This phase adds a backend-backed admin password recovery flow.

## Added routes

- `/admin/forgot-password` — request recovery code
- `/admin/forgot-password/verify` — verify recovery code
- `/admin/forgot-password/reset` — set new admin password

## Added APIs

- `POST /api/admin/auth/password-reset/request`
- `POST /api/admin/auth/password-reset/verify`
- `POST /api/admin/auth/password-reset/complete`

## Added database model

- `AdminPasswordResetToken`

## Security behavior

- Reset code is stored as SHA-256 hash.
- Reset token is stored as SHA-256 hash.
- Code expires in 15 minutes.
- Verified reset token expires in 20 minutes.
- Invalid code attempts are limited.
- Old admin sessions are cleared after password reset.
- Audit logs are recorded.

## Delivery configuration

For production delivery, configure a webhook:

```env
ADMIN_RESET_WEBHOOK_URL=https://example.com/admin-reset-webhook
ADMIN_RESET_WEBHOOK_SECRET=your-secret
```

For temporary local/testing screen delivery only:

```env
ADMIN_RESET_SHOW_CODE=true
```

Do not keep `ADMIN_RESET_SHOW_CODE=true` for final public production unless the client accepts that security tradeoff.
