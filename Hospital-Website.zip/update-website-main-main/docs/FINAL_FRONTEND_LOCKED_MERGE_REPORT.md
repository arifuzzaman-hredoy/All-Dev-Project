# Final Frontend-Locked Merge Report

## Source files

- Frontend source of truth: `update-website-main.zip`
- Backend/Database/DevOps source of truth: `update-website-main (1).zip`

## Merge rule

Public frontend design was restored from the frontend source package. Backend, Prisma database, admin APIs, Docker, GitHub Actions, scripts, audit, media manager, and hardening were kept from the backend/current package.

## Important production rule

Do not push any package that visually changes the public frontend. Before final push, compare the live pages with the frontend source package visually.

## Required final checks on VPS

```bash
cd /var/www/update_project
npm ci
npm run db:generate
npm run lint
npm run typecheck
npm run phase6:final-audit
docker compose build --pull
docker compose run --rm --no-deps update_project npm run db:migrate:deploy
docker compose up -d --remove-orphans
curl -i http://127.0.0.1:4090/api/health
curl -I https://update.techteamlead.com
```

## Rollback note

A backup should be made before applying this package. If public design does not match the frontend source package, rollback before pushing to GitHub.
