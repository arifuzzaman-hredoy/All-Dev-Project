# Phase 8.8 — Final Client Package + Backup

Phase 8.8 is the last packaging phase for the Update Diagnostic Center project. It does not replace production features. It verifies that the project is ready for client handover, generates a repeatable final-package report, and provides a VPS command pack for final GitHub, live-server, backup, and source ZIP verification.

## Goal

- Keep all Phase 8.1 to 8.7 features intact.
- Confirm frontend feature parity work is included.
- Confirm required backend, database, SMS, security, QA, and DevOps scripts exist.
- Provide a repeatable client-ready source ZIP and VPS backup workflow.
- Keep secrets out of the package.

## Included in this phase

- `scripts/client-package-finalizer.mjs`
- `scripts/vps-final-client-handover.sh`
- `docs/CLIENT_HANDOVER_SUMMARY.md`
- `docs/FINAL_DEPLOY_GITHUB_VPS_CHECKLIST.md`
- `docs/generated/phase-8-8-client-package-report.json`
- `docs/generated/phase-8-8-client-package-report.md`

## New commands

```bash
npm run client:package:check
npm run client:package:write
npm run client:handover:vps
npm run phase8:final
```

## Local verification

```powershell
cd "G:\Current Project\Development\Update Project\update-website-git-final"

npm install
npm run db:generate
npm run qa:full
npm run security:check
npm run client:package:write
npm run phase8:final
```

## VPS final handover command

Run only after the final ZIP is pushed to GitHub and pulled on the VPS.

```bash
cd /var/www/update_project

npm run client:handover:vps
```

This command runs production checks, rebuilds Docker images, restarts the application, runs live smoke checks, creates a clean source ZIP from Git HEAD, creates a server backup, and prints final status.

## Real SMS note

Real SMS sending remains dependent on the client SMS provider credentials. Until those are provided, the project should remain:

```env
SMS_ENABLED=false
SMS_PROVIDER=mock
```

When credentials are provided:

```env
SMS_ENABLED=true
SMS_PROVIDER=custom
SMS_API_URL=CLIENT_SMS_API_URL
SMS_API_KEY=CLIENT_SMS_API_KEY
SMS_SENDER_ID=CLIENT_SENDER_ID
```

Then run:

```bash
cd /var/www/update_project

docker compose up -d --force-recreate update_project sms_service
npm run sms:check
```

## Handover rule

Do not send admin password or API secrets in public chat. Deliver admin credentials privately only after final security rotation.
