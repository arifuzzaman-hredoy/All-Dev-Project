# Phase 7.1 — Form + SMS Automation Audit

Generated: 2026-06-13T11:07:34.918Z

## 1. Current Prisma Models Found

Total models: 27

Existing important models:

- Appointment ✅
- PackageBooking ✅
- AdminUser ✅
- AdminSession ✅
- AuditLog ✅

Missing planned models:

- FormSubmission ❌
- SmsTemplate ❌
- SmsLog ❌
- ExportAudit ❌

## 2. API Routes Found

- src/app/api/about-page/route.ts
- src/app/api/admin/about-page/route.ts
- src/app/api/admin/audit-logs/route.ts
- src/app/api/admin/auth/login/route.ts
- src/app/api/admin/auth/logout/route.ts
- src/app/api/admin/auth/me/route.ts
- src/app/api/admin/content/[kind]/reset/route.ts
- src/app/api/admin/content/[kind]/route.ts
- src/app/api/admin/content/[kind]/[id]/route.ts
- src/app/api/admin/corporate-services/route.ts
- src/app/api/admin/health-packages/reset/route.ts
- src/app/api/admin/health-packages/route.ts
- src/app/api/admin/health-packages/[id]/route.ts
- src/app/api/admin/home-section-teasers/[sectionKey]/route.ts
- src/app/api/admin/home-why-choose/route.ts
- src/app/api/admin/media-assets/route.ts
- src/app/api/admin/media-assets/[id]/route.ts
- src/app/api/admin/package-bookings/route.ts
- src/app/api/admin/package-bookings/[id]/route.ts
- src/app/api/admin/patient-stories/reset/route.ts
- src/app/api/admin/patient-stories/route.ts
- src/app/api/admin/patient-stories/[id]/route.ts
- src/app/api/admin/services/bulk/route.ts
- src/app/api/admin/services/reorder/route.ts
- src/app/api/admin/services/route.ts
- src/app/api/admin/services/[id]/route.ts
- src/app/api/admin/site-settings/route.ts
- src/app/api/admin/specialities/reset/route.ts
- src/app/api/admin/specialities/route.ts
- src/app/api/admin/specialities/[id]/route.ts
- src/app/api/admin/static-pages/route.ts
- src/app/api/admin/static-pages/[key]/reset/route.ts
- src/app/api/admin/static-pages/[key]/route.ts
- src/app/api/admin/uploads/hero/route.ts
- src/app/api/admin/uploads/route.ts
- src/app/api/appointments/route.ts
- src/app/api/content/[kind]/route.ts
- src/app/api/content/[kind]/[slug]/route.ts
- src/app/api/corporate-services/route.ts
- src/app/api/doctors/route.ts
- src/app/api/doctors/[id]/route.ts
- src/app/api/health/route.ts
- src/app/api/health-packages/route.ts
- src/app/api/health-packages/[slug]/route.ts
- src/app/api/home-section-teasers/[sectionKey]/route.ts
- src/app/api/package-bookings/route.ts
- src/app/api/patient-stories/route.ts
- src/app/api/patient-stories/[slug]/route.ts
- src/app/api/site-settings/route.ts
- src/app/api/specialities/route.ts
- src/app/api/specialities/[slug]/route.ts
- src/app/api/static-pages/[slug]/route.ts

## 3. Admin Pages Found

- src/app/admin/about/page.tsx
- src/app/admin/appointments/page.tsx
- src/app/admin/audit-logs/page.tsx
- src/app/admin/doctors/page.tsx
- src/app/admin/home/page.tsx
- src/app/admin/login/page.tsx
- src/app/admin/media/page.tsx
- src/app/admin/package-requests/page.tsx
- src/app/admin/page.tsx
- src/app/admin/pages/about/page.tsx
- src/app/admin/pages/appointment/page.tsx
- src/app/admin/pages/blogs/page.tsx
- src/app/admin/pages/career/page.tsx
- src/app/admin/pages/contact/page.tsx
- src/app/admin/pages/doctor-articles/page.tsx
- src/app/admin/pages/health-check/page.tsx
- src/app/admin/pages/legal/page.tsx
- src/app/admin/pages/news-media/page.tsx
- src/app/admin/pages/online-report/page.tsx
- src/app/admin/pages/patient-guide/page.tsx
- src/app/admin/pages/patient-stories/page.tsx
- src/app/admin/pages/privacy-policy/page.tsx
- src/app/admin/pages/support/page.tsx
- src/app/admin/pages/terms/page.tsx
- src/app/admin/pages/[pageKey]/page.tsx
- src/app/admin/sections/home-blogs/page.tsx
- src/app/admin/sections/home-corporate-services/page.tsx
- src/app/admin/sections/home-doctors/page.tsx
- src/app/admin/sections/home-hero/page.tsx
- src/app/admin/sections/home-news/page.tsx
- src/app/admin/sections/home-quick-actions/page.tsx
- src/app/admin/sections/home-specialities/page.tsx
- src/app/admin/sections/home-why-choose/page.tsx
- src/app/admin/sections/[sectionKey]/page.tsx
- src/app/admin/services/page.tsx
- src/app/admin/site-settings/page.tsx

## 4. Public Pages Found

- src/app/about/page.tsx
- src/app/appointment/page.tsx
- src/app/blogs/childhood-nephrotic-syndrome/page.tsx
- src/app/blogs/page.tsx
- src/app/blogs/rising-measles-cases-bangladesh/page.tsx
- src/app/blogs/winter-baby-health-care/page.tsx
- src/app/blogs/[slug]/page.tsx
- src/app/career/page.tsx
- src/app/contact/page.tsx
- src/app/doctor-articles/cancer-prevention-awareness/page.tsx
- src/app/doctor-articles/diabetic-patients-ramadan-fasting/page.tsx
- src/app/doctor-articles/early-detection-can-save-lives/page.tsx
- src/app/doctor-articles/page.tsx
- src/app/doctor-articles/[slug]/page.tsx
- src/app/doctors/page.tsx
- src/app/health-check/book/page.tsx
- src/app/health-check/executive-health-check/page.tsx
- src/app/health-check/hajj-health-check/page.tsx
- src/app/health-check/heart-check-for-men/page.tsx
- src/app/health-check/heart-check-for-women/page.tsx
- src/app/health-check/page.tsx
- src/app/health-check/whole-body-check-men-above-45-years/page.tsx
- src/app/health-check/whole-body-check-men-below-45-years/page.tsx
- src/app/health-check/whole-body-check-women-above-45-years/page.tsx
- src/app/health-check/whole-body-check-women-below-45-years/page.tsx
- src/app/health-check/[slug]/page.tsx
- src/app/news-media/health-awareness-program/page.tsx
- src/app/news-media/new-diagnostic-service-launched/page.tsx
- src/app/news-media/page.tsx
- src/app/news-media/specialist-doctor-joined/page.tsx
- src/app/news-media/[slug]/page.tsx
- src/app/online-report/page.tsx
- src/app/page.tsx
- src/app/patient-guide/page.tsx
- src/app/patient-stories/congenital-heart-defect-treatment/page.tsx
- src/app/patient-stories/page.tsx
- src/app/patient-stories/successful-knee-surgery/page.tsx
- src/app/patient-stories/successful-treatment-head-injury/page.tsx
- src/app/patient-stories/[slug]/page.tsx
- src/app/privacy-policy/page.tsx
- src/app/services/page.tsx
- src/app/services/[slug]/page.tsx
- src/app/specialities/page.tsx
- src/app/specialities/[slug]/page.tsx
- src/app/support/page.tsx
- src/app/terms/page.tsx

## 5. Possible Form Components / Booking Components

- src/app/admin/appointments/page.tsx
- src/app/admin/pages/appointment/page.tsx
- src/app/appointment/page.tsx
- src/components/admin/AdminLoginForm.tsx
- src/components/admin/appointments/AppointmentFilters.tsx
- src/components/admin/appointments/AppointmentPrintButton.tsx
- src/components/admin/appointments/AppointmentsTable.tsx
- src/components/admin/doctors/DoctorForm.tsx
- src/components/admin/home-why-choose/WhyChooseForm.tsx
- src/components/forms/AppointmentForm.tsx
- src/components/health/HealthPackageBookingForm.tsx
- src/features/admin/services/components/ServiceForm.tsx

## 6. API Route Keyword Summary

### src/app/api/about-page/route.ts
Keywords: export

### src/app/api/admin/about-page/route.ts
Keywords: export

### src/app/api/admin/audit-logs/route.ts
Keywords: export

### src/app/api/admin/auth/login/route.ts
Keywords: POST(, export

### src/app/api/admin/auth/logout/route.ts
Keywords: POST(, export

### src/app/api/admin/auth/me/route.ts
Keywords: export

### src/app/api/admin/content/[kind]/reset/route.ts
Keywords: POST(, export

### src/app/api/admin/content/[kind]/route.ts
Keywords: POST(, export

### src/app/api/admin/content/[kind]/[id]/route.ts
Keywords: export

### src/app/api/admin/corporate-services/route.ts
Keywords: POST(, export

### src/app/api/admin/health-packages/reset/route.ts
Keywords: POST(, export

### src/app/api/admin/health-packages/route.ts
Keywords: POST(, export

### src/app/api/admin/health-packages/[id]/route.ts
Keywords: export

### src/app/api/admin/home-section-teasers/[sectionKey]/route.ts
Keywords: POST(, export

### src/app/api/admin/home-why-choose/route.ts
Keywords: export

### src/app/api/admin/media-assets/route.ts
Keywords: export

### src/app/api/admin/media-assets/[id]/route.ts
Keywords: export

### src/app/api/admin/package-bookings/route.ts
Keywords: PackageBooking, export

### src/app/api/admin/package-bookings/[id]/route.ts
Keywords: PackageBooking, export

### src/app/api/admin/patient-stories/reset/route.ts
Keywords: POST(, export

### src/app/api/admin/patient-stories/route.ts
Keywords: export

### src/app/api/admin/patient-stories/[id]/route.ts
Keywords: export

### src/app/api/admin/services/bulk/route.ts
Keywords: export

### src/app/api/admin/services/reorder/route.ts
Keywords: POST(, export

### src/app/api/admin/services/route.ts
Keywords: POST(, export

### src/app/api/admin/services/[id]/route.ts
Keywords: export

### src/app/api/admin/site-settings/route.ts
Keywords: export

### src/app/api/admin/specialities/reset/route.ts
Keywords: POST(, export

### src/app/api/admin/specialities/route.ts
Keywords: export

### src/app/api/admin/specialities/[id]/route.ts
Keywords: export

### src/app/api/admin/static-pages/route.ts
Keywords: export

### src/app/api/admin/static-pages/[key]/reset/route.ts
Keywords: POST(, export

### src/app/api/admin/static-pages/[key]/route.ts
Keywords: export

### src/app/api/admin/uploads/hero/route.ts
Keywords: POST(, export

### src/app/api/admin/uploads/route.ts
Keywords: POST(, export

### src/app/api/appointments/route.ts
Keywords: POST(, Appointment, export

### src/app/api/content/[kind]/route.ts
Keywords: export

### src/app/api/content/[kind]/[slug]/route.ts
Keywords: export

### src/app/api/corporate-services/route.ts
Keywords: export

### src/app/api/doctors/route.ts
Keywords: POST(, export

### src/app/api/doctors/[id]/route.ts
Keywords: export

### src/app/api/health/route.ts
Keywords: export

### src/app/api/health-packages/route.ts
Keywords: export

### src/app/api/health-packages/[slug]/route.ts
Keywords: export

### src/app/api/home-section-teasers/[sectionKey]/route.ts
Keywords: export

### src/app/api/package-bookings/route.ts
Keywords: POST(, PackageBooking, export

### src/app/api/patient-stories/route.ts
Keywords: export

### src/app/api/patient-stories/[slug]/route.ts
Keywords: export

### src/app/api/site-settings/route.ts
Keywords: export

### src/app/api/specialities/route.ts
Keywords: export

### src/app/api/specialities/[slug]/route.ts
Keywords: export

### src/app/api/static-pages/[slug]/route.ts
Keywords: export

## 7. Form Component Keyword Summary

### src/app/admin/appointments/page.tsx
Keywords: Appointment, export

### src/app/admin/pages/appointment/page.tsx
Keywords: Appointment, export

### src/app/appointment/page.tsx
Keywords: Appointment, export

### src/components/admin/AdminLoginForm.tsx
Keywords: fetch(, export

### src/components/admin/appointments/AppointmentFilters.tsx
Keywords: Appointment, export, html

### src/components/admin/appointments/AppointmentPrintButton.tsx
Keywords: Appointment, export

### src/components/admin/appointments/AppointmentsTable.tsx
Keywords: Appointment, export

### src/components/admin/doctors/DoctorForm.tsx
Keywords: fetch(, export

### src/components/admin/home-why-choose/WhyChooseForm.tsx
Keywords: fetch(, export

### src/components/forms/AppointmentForm.tsx
Keywords: fetch(, Appointment, export, html

### src/components/health/HealthPackageBookingForm.tsx
Keywords: PackageBooking, export, html

### src/features/admin/services/components/ServiceForm.tsx
Keywords: export

## 8. Admin Page Keyword Summary

### src/app/admin/about/page.tsx
Keywords: export

### src/app/admin/appointments/page.tsx
Keywords: Appointment, export

### src/app/admin/audit-logs/page.tsx
Keywords: export

### src/app/admin/doctors/page.tsx
Keywords: export

### src/app/admin/home/page.tsx
Keywords: export

### src/app/admin/login/page.tsx
Keywords: export

### src/app/admin/media/page.tsx
Keywords: export

### src/app/admin/package-requests/page.tsx
Keywords: PackageBooking, export, html

### src/app/admin/page.tsx
Keywords: export

### src/app/admin/pages/about/page.tsx
Keywords: export

### src/app/admin/pages/appointment/page.tsx
Keywords: Appointment, export

### src/app/admin/pages/blogs/page.tsx
Keywords: export

### src/app/admin/pages/career/page.tsx
Keywords: export

### src/app/admin/pages/contact/page.tsx
Keywords: export

### src/app/admin/pages/doctor-articles/page.tsx
Keywords: export

### src/app/admin/pages/health-check/page.tsx
Keywords: PackageBooking, export, html

### src/app/admin/pages/legal/page.tsx
Keywords: export

### src/app/admin/pages/news-media/page.tsx
Keywords: export

### src/app/admin/pages/online-report/page.tsx
Keywords: export

### src/app/admin/pages/patient-guide/page.tsx
Keywords: export

### src/app/admin/pages/patient-stories/page.tsx
Keywords: fetch(, export

### src/app/admin/pages/privacy-policy/page.tsx
Keywords: export

### src/app/admin/pages/support/page.tsx
Keywords: export

### src/app/admin/pages/terms/page.tsx
Keywords: export

### src/app/admin/pages/[pageKey]/page.tsx
Keywords: export

### src/app/admin/sections/home-blogs/page.tsx
Keywords: export

### src/app/admin/sections/home-corporate-services/page.tsx
Keywords: fetch(, export

### src/app/admin/sections/home-doctors/page.tsx
Keywords: export

### src/app/admin/sections/home-hero/page.tsx
Keywords: export

### src/app/admin/sections/home-news/page.tsx
Keywords: export

### src/app/admin/sections/home-quick-actions/page.tsx
Keywords: export

### src/app/admin/sections/home-specialities/page.tsx
Keywords: fetch(, export

### src/app/admin/sections/home-why-choose/page.tsx
Keywords: export

### src/app/admin/sections/[sectionKey]/page.tsx
Keywords: export

### src/app/admin/services/page.tsx
Keywords: export

### src/app/admin/site-settings/page.tsx
Keywords: fetch(, Appointment, export

## 9. Phase 7.1 Initial Conclusion

Need manual review from this audit:
- Appointment public submit DB save status
- Contact form DB save status
- Career form DB save status
- Package booking DB save status
- Support form DB save status
- Online report form DB save status
- Existing admin listing pages
- Export feature availability
- SMS feature availability
