# Phase 8.6 — Full Regression QA

Phase 8.6 adds a repeatable QA layer for the full production project before final client handover.

## Goal

Make sure the frontend parity work and backend/database/devops integration remain intact after Phase 8.1 to Phase 8.5.

## Added scripts

```bash
npm run qa:regression
npm run qa:full
npm run qa:deploy-ready
npm run qa:live-smoke
npm run qa:live-smoke:write
```

## What `qa:regression` checks

- Required public routes exist.
- Required admin routes exist.
- Required API routes exist.
- Career Apply form posts to `/api/form-submissions`.
- Admin Career Applications reads from `/api/admin/form-submissions`.
- Forgot password pages use real backend API routes.
- Password reset backend library exists and uses token expiry/hash logic.
- Required Prisma models exist.
- Critical docs and support scripts exist.
- A generated report is written to `docs/generated/phase-8-6-regression-report.*`.

## What `qa:full` runs

```bash
npm run db:generate
npm run frontend:inventory
npm run backend:support-check
npm run qa:regression
npm run lint
npm run typecheck
npm run build
```

## What `qa:deploy-ready` runs

```bash
npm run env:check:production
npm run db:validate
npm run db:generate
npm run frontend:inventory
npm run backend:support-check
npm run qa:regression
npm run lint
npm run typecheck
npm run build
npm run sms:check
```

Use this on VPS after `.env.production` is configured.

## Live smoke test

For already deployed server:

```bash
QA_BASE_URL=https://update.techteamlead.com npm run qa:live-smoke
```

Write test for Career application endpoint:

```bash
QA_BASE_URL=https://update.techteamlead.com QA_WRITE_TEST=true npm run qa:live-smoke
```

After write test, clean generated test submission from admin panel or database if needed.

## Acceptance criteria

- `npm run qa:full` passes locally.
- `npm run qa:deploy-ready` passes on VPS.
- `QA_BASE_URL=https://update.techteamlead.com npm run qa:live-smoke` passes on VPS.
- Docker containers are healthy.
- Production logs have no critical runtime error.
- Git status is clean before final backup.
