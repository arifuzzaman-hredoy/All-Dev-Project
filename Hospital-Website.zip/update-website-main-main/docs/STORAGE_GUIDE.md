# Phase 1.2 — Persistent Storage Guide

This phase adds persistent Docker volumes for the current file-based parts of the project.

## Why this is needed

The current project still stores some data in local files:

```txt
public/uploads/*
src/content/*.json
```

Without Docker volumes, these files can be lost when the container/image is rebuilt or redeployed.

## Added volumes

```txt
update_project_uploads -> /app/public/uploads
update_project_content -> /app/src/content
```

## Important limitation

This is not the final backend architecture.

This phase only protects the current file-based storage while the project is still migrating to real PostgreSQL + Prisma CMS.

Final target:

```txt
Database content -> PostgreSQL
Uploaded media -> Docker volume or object storage such as Cloudflare R2/S3
```

## Local test

Run from project root:

```bash
bash scripts/prepare-volumes.sh
docker compose build
docker compose up -d
bash scripts/storage-smoke-test.sh
docker compose restart update_project
bash scripts/storage-smoke-test.sh
```

Expected result:

```txt
Storage write test: PASS
```

## VPS test

Run on VPS project root:

```bash
cd /var/www/update_project
bash scripts/prepare-volumes.sh
docker compose build
docker compose up -d
bash scripts/storage-smoke-test.sh
docker compose restart update_project
bash scripts/storage-smoke-test.sh
```

## How to inspect volumes

```bash
docker volume inspect update_project_uploads
docker volume inspect update_project_content
```

## Do not delete these volumes unless you want to delete stored data

Dangerous commands:

```bash
docker volume rm update_project_uploads
docker volume rm update_project_content
docker compose down -v
```

Do not run `docker compose down -v` in production unless you intentionally want to remove the app's persistent data.
