# Phase 3.1 — DB-backed Admin Auth

## What changed

Admin login is now verified from the PostgreSQL `AdminUser` table instead of comparing `ADMIN_EMAIL` and `ADMIN_PASSWORD` directly at runtime.

The environment values are now used only as bootstrap/seed values:

- `ADMIN_EMAIL`
- `ADMIN_NAME`
- `ADMIN_PASSWORD`
- `ADMIN_FORCE_LOGIN_ON_REFRESH`

Running `npm run db:seed` creates or updates a `SUPER_ADMIN` record and stores the password as a Node `scrypt` hash.

## Important

If you change `ADMIN_PASSWORD`, run:

```powershell
npm run db:seed
```

That will update the database admin password and clear existing admin sessions.

## Local test

```powershell
npm run db:generate
npm run db:seed
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
npm run dev
```

Open:

```txt
http://localhost:4090/admin
```

Login with the email/password from `.env`.

## Production/VPS note

For production, create PostgreSQL on the VPS and put that VPS DB connection string in `.env.production` as `DATABASE_URL`.

Do not use the Neon URL in production if the production decision is VPS PostgreSQL.
