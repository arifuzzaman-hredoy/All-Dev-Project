# Update Clinic — Phase 2.3 Prisma Migration + Seed Guide

## Status

This phase creates the initial PostgreSQL database tables and adds seed tooling.

Important: the live app UI/API is still not fully database-connected. That starts from Phase 3 and Phase 4.

## Added files

```txt
prisma/migrations/20260612150000_init/migration.sql
prisma/migrations/migration_lock.toml
prisma/seed.js
scripts/prisma-migrate.sh
scripts/prisma-seed.sh
scripts/prisma-status.sh
scripts/prisma-db-smoke-test.sh
```

## Added package scripts

```bash
npm run db:seed
npm run db:migrate:status
```

Existing scripts from Phase 2.2 are still used:

```bash
npm run db:validate
npm run db:generate
npm run db:migrate:deploy
```

## Local test

Run from local project root:

```powershell
npm install
$env:DATABASE_URL="postgresql://update_clinic_user:YOUR_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public"
npm run db:validate
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run db:migrate:status
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
```

## VPS test

Run from VPS:

```bash
cd /var/www/update_project
chmod +x scripts/*.sh

bash scripts/prisma-migrate.sh
bash scripts/prisma-seed.sh
bash scripts/prisma-status.sh
bash scripts/prisma-db-smoke-test.sh
```

## Docker-based migration test

If you want to run migration/seed inside the Docker image:

```bash
cd /var/www/update_project

docker compose build
USE_DOCKER=true bash scripts/prisma-migrate.sh
USE_DOCKER=true bash scripts/prisma-seed.sh
bash scripts/prisma-db-smoke-test.sh
```

## Seed source

The seed script reads current file-based content from:

```txt
src/content/doctors.json
src/content/appointments.json
src/content/public-content.json
src/content/home-why-choose.json
```

Then it writes mapped data into PostgreSQL tables.

## What this phase does not do

```txt
It does not replace localStorage yet.
It does not convert public pages to DB queries yet.
It does not convert admin CRUD to Prisma yet.
It does not replace current env-based admin login yet.
```

Those are Phase 3 and Phase 4 jobs.

## Deploy behavior

`scripts/deploy.sh` now runs Prisma migrations after Docker build and before starting the updated container.

To skip migration temporarily:

```bash
RUN_DB_MIGRATIONS=false bash scripts/deploy.sh
```

Do not skip migrations after the app starts using database tables.
