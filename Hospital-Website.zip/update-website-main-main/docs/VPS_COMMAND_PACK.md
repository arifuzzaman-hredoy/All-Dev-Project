# VPS Command Pack — Update Clinic

Use these commands as copy-paste blocks. Replace placeholders before running.

## A. Local Windows PowerShell final check

```powershell
cd "G:\Current Project\Development\Update Project\update-website-main"

npm install
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run db:migrate:status
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
```

## B. VPS bootstrap

```bash
apt update && apt upgrade -y
apt install -y git curl ca-certificates gnupg nginx certbot python3-certbot-nginx ufw fail2ban postgresql postgresql-contrib
systemctl enable --now nginx postgresql fail2ban
```

## C. Docker install on Ubuntu VPS

```bash
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
. /etc/os-release
printf "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu %s stable\n" "$VERSION_CODENAME" > /etc/apt/sources.list.d/docker.list
apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
docker --version
docker compose version
```

## D. Firewall

```bash
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
ufw status
```

## E. PostgreSQL DB create

```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE update_clinic;
CREATE USER update_clinic_user WITH ENCRYPTED PASSWORD 'REPLACE_STRONG_DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE update_clinic TO update_clinic_user;
\c update_clinic
GRANT ALL ON SCHEMA public TO update_clinic_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO update_clinic_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO update_clinic_user;
\q
```

## F. Clone project

```bash
mkdir -p /var/www
cd /var/www
git clone YOUR_GITHUB_REPO_URL update_project
cd /var/www/update_project
chmod +x scripts/*.sh
```

## G. Env setup

```bash
cd /var/www/update_project
cp .env.production.example .env.production
openssl rand -hex 64
nano .env.production
```

## H. Production check

```bash
cd /var/www/update_project
npm install
npm run env:check:production
npm run deploy:check
```

## I. First Docker deploy

```bash
cd /var/www/update_project
bash scripts/prepare-volumes.sh
docker compose build --pull
docker compose run --rm --no-deps update_project npm run db:migrate:deploy
docker compose run --rm --no-deps update_project npm run db:seed
docker compose up -d --remove-orphans
docker compose ps
curl http://127.0.0.1:4090/api/health
```

## J. Nginx

```bash
cd /var/www/update_project
cp nginx/nginx/update.techteamlead.com.conf /etc/nginx/sites-available/update_project.conf
nano /etc/nginx/sites-available/update_project.conf
ln -sf /etc/nginx/sites-available/update_project.conf /etc/nginx/sites-enabled/update_project.conf
nginx -t
systemctl reload nginx
```

## K. SSL

```bash
certbot --nginx -d YOUR_DOMAIN --redirect
certbot renew --dry-run
systemctl reload nginx
```

## L. Backup

```bash
cd /var/www/update_project
bash scripts/backup.sh
ls -lah /var/backups/update_project
bash scripts/backup-verify.sh /var/backups/update_project/YOUR_BACKUP_FILE.tar.gz
```

## M. Restore

```bash
cd /var/www/update_project
RESTORE_CONFIRM=YES RESTORE_DATABASE_CONFIRM=YES bash scripts/restore.sh /var/backups/update_project/YOUR_BACKUP_FILE.tar.gz
```

## N. Normal update deploy

```bash
cd /var/www/update_project
git pull origin main
bash scripts/deploy.sh
```

## O. Debug commands

```bash
docker compose ps
docker compose logs --tail=200 update_project
curl -I http://127.0.0.1:4090
curl http://127.0.0.1:4090/api/health
nginx -t
systemctl status nginx --no-pager
journalctl -u nginx -n 100 --no-pager
```
