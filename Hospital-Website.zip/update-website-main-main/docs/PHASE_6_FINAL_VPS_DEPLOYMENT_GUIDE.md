# Phase 6 — Final VPS Deployment Preparation + Live Deploy Guide

This guide is the final go-live runbook for the Update Clinic project.

## Locked rules

- Public frontend design is locked.
- Do not edit public UI/components while deploying.
- Production database must be PostgreSQL on the VPS or a managed PostgreSQL URL.
- Production must use Prisma migrations, not `prisma db push`.
- `.env`, `.env.local`, and `.env.production` must never be pushed to GitHub.

## Production paths

```bash
PROJECT_ROOT=/var/www/update_project
APP_PORT=4090
DOMAIN=update.techteamlead.com
ENV_FILE=.env.production
APP_CONTAINER=update_project
BACKUP_ROOT=/var/backups/update_project
```

Change `DOMAIN` and GitHub repository values before live deploy.

---

## Step 1 — VPS base preparation

Run as root or sudo user on the VPS:

```bash
apt update && apt upgrade -y
apt install -y git curl unzip ufw fail2ban nginx certbot python3-certbot-nginx postgresql-client
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker
```

Check:

```bash
docker --version
docker compose version
nginx -v
certbot --version
```

---

## Step 2 — Clone project

```bash
mkdir -p /var/www
cd /var/www
git clone YOUR_GITHUB_REPOSITORY_URL update_project
cd /var/www/update_project
chmod +x scripts/*.sh
```

---

## Step 3 — Create production env

```bash
cp .env.production.example .env.production
nano .env.production
```

Required production values:

```env
NODE_ENV=production
NEXT_PUBLIC_SITE_URL=https://update.techteamlead.com
DATABASE_URL=postgresql://USER:PASSWORD@127.0.0.1:5432/update_clinic?schema=public
ADMIN_EMAIL=real-admin@example.com
ADMIN_PASSWORD=change-to-strong-12-plus-character-password
ADMIN_SESSION_SECRET=64-plus-character-random-secret
APP_PORT=4090
```

Generate a strong secret:

```bash
openssl rand -hex 64
```

Validate:

```bash
npm install
npm run env:check:production
npm run db:validate
```

---

## Step 4 — Fresh database migration

Production fresh database must use:

```bash
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run db:migrate:status
```

Do not run this in production:

```bash
npx prisma db push
```

---

## Step 5 — Production build check

```bash
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
```

---

## Step 6 — Docker deploy

```bash
docker compose build --no-cache
docker compose up -d
docker compose ps
docker compose logs --tail=100 update_project
curl -fsS http://127.0.0.1:4090/api/health
```

---

## Step 7 — Nginx + SSL

Set domain env and install Nginx config:

```bash
DOMAIN=update.techteamlead.com APP_PORT=4090 bash scripts/setup-nginx.sh
```

After DNS A record points to the VPS IP:

```bash
DOMAIN=update.techteamlead.com EMAIL=admin@example.com bash scripts/setup-ssl.sh
```

Test:

```bash
curl -I https://update.techteamlead.com
curl -fsS https://update.techteamlead.com/api/health
```

---

## Step 8 — Backup before and after go-live

```bash
bash scripts/backup.sh
LATEST_BACKUP=$(find /var/backups/update_project -maxdepth 1 -type f -name 'update_project_*.tar.gz' | sort -r | head -n 1)
bash scripts/backup-verify.sh "$LATEST_BACKUP"
```

---

## Step 9 — Final go-live smoke test

```bash
bash scripts/phase6-live-preflight.sh
bash scripts/phase6-post-deploy-check.sh
bash scripts/vps-final-check.sh
```

---

## Step 10 — GitHub Actions deploy

Required GitHub Secrets:

```txt
VPS_HOST
VPS_USERNAME
VPS_PASSWORD
VPS_PORT
DEPLOY_REPO_URL
```

Then push to main:

```bash
git add .
git commit -m "production ready phase 6"
git push origin main
```

Watch GitHub Actions logs and then run VPS final check.

