# Final Admin CMS Test Checklist

Use this checklist after every production deployment.

## Public site

- [ ] Home page loads
- [ ] Hero slider loads from DB
- [ ] Quick actions load from DB
- [ ] Services page loads
- [ ] Service detail page loads
- [ ] Doctors page loads
- [ ] Health packages page loads
- [ ] Blogs/news/articles pages load
- [ ] Patient stories page loads
- [ ] Contact page loads from DB static page/site settings
- [ ] Support page loads from DB static page/site settings
- [ ] Privacy policy and terms load from DB

## Admin CMS

- [ ] Admin login works
- [ ] Site settings save and public header/footer update
- [ ] Home hero save and public homepage updates
- [ ] Static page save and public page updates
- [ ] Services CRUD works
- [ ] Doctors CRUD works
- [ ] Specialities CRUD works
- [ ] Health packages CRUD works
- [ ] Blogs/news/doctor articles CRUD works
- [ ] Patient stories CRUD works
- [ ] Media upload works
- [ ] Media alt text update works
- [ ] Media delete works
- [ ] Audit logs show admin activity

## Forms

- [ ] Appointment form creates DB record
- [ ] Package booking form creates DB record
- [ ] Repeated spam receives 429 after rate limit
- [ ] Admin can update appointment/package status

## Production health

```bash
cd /var/www/update_project
curl -i http://127.0.0.1:4090/api/health
curl -I https://update.techteamlead.com
docker compose ps
bash scripts/backup.sh
bash scripts/backup-verify.sh
```
