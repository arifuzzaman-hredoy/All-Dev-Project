# Phase 2.2 — Prisma Setup Guide

This phase adds Prisma as the database access layer for the Update Clinic project.

## What this phase does

- Adds `@prisma/client` and `prisma` packages.
- Adds `prisma/schema.prisma` with the production database model foundation.
- Adds `src/lib/db.ts` as the shared Prisma client entry point.
- Adds Prisma npm scripts.
- Updates Dockerfile so Prisma schema exists before `npm ci` and Prisma client can be generated inside Docker.

## What this phase does not do yet

- It does not migrate existing JSON/localStorage data into PostgreSQL.
- It does not connect public/admin pages to database CRUD yet.
- It does not create migrations yet. That is Phase 2.3.

## Required environment variable

```env
DATABASE_URL="postgresql://update_clinic_user:CHANGE_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public"
```

## Local test commands

Windows PowerShell from project root:

```powershell
cd "G:\Current Project\Development\Update Clinic\update-website-main"

npm install

$env:DATABASE_URL="postgresql://update_clinic_user:CHANGE_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public"
npm run db:validate
npm run db:generate
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
```

## VPS test commands

VPS server terminal from project root:

```bash
cd /var/www/update_project

npm install
export DATABASE_URL="postgresql://update_clinic_user:CHANGE_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public"

npm run db:validate
npm run db:generate
npm run typecheck
```

## Docker note

The Dockerfile now copies the `prisma/` folder before `npm ci`, then runs:

```bash
npm run db:generate
```

This is intentional. Without it, future backend code that imports Prisma can fail during Docker build.

## Important warning

Do not run migration commands yet unless Phase 2.3 files are applied.

Phase 2.2 validates and generates Prisma client only. Phase 2.3 will add migration/seed workflow.
