# Phase 8.7 — Security Finalization

Phase 8.7 completes the final security layer before client handover. It does not replace the existing production deployment flow. It adds repeatable security verification and a VPS finalization command so the handover can be performed consistently without exposing secrets in chat or committed files.

## What this phase adds

- Final security verification script.
- VPS security finalization script.
- Admin password rotation workflow.
- Optional session secret rotation workflow.
- Optional internal SMS service key rotation workflow.
- Forced `ADMIN_RESET_SHOW_CODE=false` for production safety.
- Forced `ADMIN_RESET_CODE_IN_AUDIT=false` for production safety.
- Admin database password hash sync after password rotation.
- Admin sessions clear after password rotation.
- Final clean backup creation.
- Security checklist and generated report support.

## New commands

```bash
npm run security:check
npm run security:check:write
npm run security:check:production
npm run security:finalize:vps
npm run phase8:client-ready
```

## Local/security package check

Run this after extracting the source ZIP locally:

```powershell
cd "G:\Current Project\Development\Update Project\update-website-git-final"

npm install
npm run db:generate
npm run qa:full
npm run security:check
```

## VPS production finalization

Run this only on the VPS after the project has been deployed and `.env.production` exists:

```bash
cd /var/www/update_project

npm run security:finalize:vps
```

The script will generate a new admin password file at:

```txt
/root/update_project_final_admin_password.txt
```

Do not paste the password in chat or commit it to GitHub. Share it privately with the client.

## Production env safety

For production handover, these values should normally stay disabled unless a real delivery channel is configured:

```env
ADMIN_RESET_SHOW_CODE=false
ADMIN_RESET_CODE_IN_AUDIT=false
SMS_ENABLED=false
SMS_PROVIDER=mock
```

When the client provides SMS credentials, SMS can be enabled with:

```env
SMS_ENABLED=true
SMS_PROVIDER=custom
SMS_API_URL=CLIENT_SMS_API_URL
SMS_API_KEY=CLIENT_SMS_API_KEY
SMS_SENDER_ID=CLIENT_SENDER_ID
```

## Handover security result

The project is client-ready only after these are true:

- `npm run qa:deploy-ready` passes.
- `npm run security:check:production` passes on VPS.
- `docker compose ps` shows healthy containers.
- Live route checks return `200`.
- Git working tree is clean.
- Final backup is created after security finalization.
