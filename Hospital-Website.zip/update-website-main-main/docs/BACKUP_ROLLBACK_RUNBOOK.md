# Backup + Rollback Runbook

## 1. Create backup before deploy

```bash
cd /var/www/update_project
bash scripts/backup.sh
ls -lah /var/backups/update_project
```

## 2. Verify backup

```bash
bash scripts/backup-verify.sh /var/backups/update_project/YOUR_BACKUP_FILE.tar.gz
```

## 3. Restore backup

```bash
cd /var/www/update_project
RESTORE_CONFIRM=YES RESTORE_DATABASE_CONFIRM=YES bash scripts/restore.sh /var/backups/update_project/YOUR_BACKUP_FILE.tar.gz
```

## 4. App rollback by Git commit

```bash
cd /var/www/update_project
git log --oneline -10
git checkout PREVIOUS_COMMIT
bash scripts/deploy.sh
```

## 5. Database rollback warning

Database rollback should only be done from verified backup. Do not manually drop production tables unless you already have a verified backup.
