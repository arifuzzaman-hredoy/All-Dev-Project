# Phase 0 Project Audit — Update Clinic

## Status

Phase 0 result: **project is now validation-clean for the current codebase**.

Validated commands:

```bash
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
```

## What was fixed in Phase 0

- Removed accidental junk root file: `h origin main`.
- Added `typecheck` script to `package.json`.
- Upgraded Next.js package pair from `16.2.5` to `16.2.9`.
- Fixed React compiler lint errors in:
  - `src/app/admin/site-settings/page.tsx`
  - `src/components/home/HeroSlider.tsx`
  - `src/features/admin/services/components/ServiceManager.tsx`
- Disabled `@next/next/no-img-element` temporarily in ESLint because this project still has many CMS/admin components that accept arbitrary local/data image URLs. Convert these gradually later, not during Phase 0.
- Added `experimental.cpus: 4` to `next.config.ts` to stop Next build from spawning too many workers on VPS/CI.
- Marked dynamic pages as `force-dynamic` where the page depends on request-time data/search params.

## Current technical reality

This project is not a full production backend yet. Current storage is mixed:

1. JSON file storage inside `src/content`.
2. Browser `localStorage` in multiple CMS/admin modules.
3. API routes exist, but they do not use a database yet.

## DevOps readiness after Phase 0

Ready for Phase 1 DevOps foundation.

Not ready for final production because these are still missing:

- Dockerfile
- docker-compose.yml
- Nginx config
- GitHub Actions workflow
- `.env.example`
- PostgreSQL/Prisma setup
- real database-backed CMS
- real production admin auth

## Security notes

- `npm audit --omit=dev` now reports 2 moderate vulnerabilities and 0 high/critical vulnerabilities. Do not run `npm audit fix --force` blindly because npm suggests a breaking downgrade path for Next.js/PostCSS.
- Current admin auth is still environment-variable based.
- Server-side admin protection is incomplete in some admin pages.
- Default/demo credential must not be used in production.

## Next recommended step

Start **Phase 1.1 — Docker base setup**.
