# Phase 3.5 — Blogs, News & Doctor Articles DB CMS

This phase converts three localStorage CMS modules to database-backed CMS modules:

- Health Blogs
- News & Media
- Doctor Articles

## New API

Public:

```txt
GET /api/content/blogs
GET /api/content/blogs/[slug]
GET /api/content/news-media
GET /api/content/news-media/[slug]
GET /api/content/doctor-articles
GET /api/content/doctor-articles/[slug]
```

Admin protected:

```txt
GET    /api/admin/content/[kind]
POST   /api/admin/content/[kind]
PUT    /api/admin/content/[kind]/[id]
DELETE /api/admin/content/[kind]/[id]
POST   /api/admin/content/[kind]/reset
```

Valid `kind` values:

```txt
blogs
news-media
doctor-articles
```

## Important

This phase assumes Phase 3.4 was applied first. If migration files were missing earlier, apply the patch then run:

```powershell
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run build
```

For Neon development DB already synced by `db push`, use `db push` again only for development. For VPS production, use final migration files.
