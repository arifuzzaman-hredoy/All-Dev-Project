# Client Handover Guide

## Admin URL

```txt
https://YOUR_DOMAIN/admin/login
```

## Admin credentials

Use production credentials from `.env.production`. Do not share `.env.production` with the client.

## Admin sections

```txt
Doctors
Appointments
Services
Health packages
Package requests
Blogs
News & Media
Doctor articles
Patient stories
Specialities
Static pages
Site settings
Audit logs
```

## Backup location

```txt
/var/backups/update_project
```

## Normal maintenance commands

```bash
cd /var/www/update_project
docker compose ps
docker compose logs --tail=100 update_project
bash scripts/backup.sh
```

## Emergency rollback

```bash
cd /var/www/update_project
git log --oneline -10
git checkout PREVIOUS_COMMIT
bash scripts/deploy.sh
```
