# Generated Frontend Feature Inventory

Generated: 2026-06-13T16:57:03.459Z

Reference: `/mnt/data/phase84_front/send`

Current project: `/mnt/data/phase84_work`

## Summary

| Metric | Count |
|---|---:|
| Reference files | 279 |
| Current files | 486 |
| Same files | 196 |
| Different files | 79 |
| Current-only production files | 211 |
| Missing total | 4 |
| Missing real | 0 |
| Production replaced | 3 |
| Ignored reference artifacts | 1 |

## Missing / replaced files

- `h origin main` — ignored-reference-artifact
- `src/lib/pageCms.ts` — production-replaced-by:src/lib/static-pages.ts
- `src/lib/publicPagesCms.ts` — production-replaced-by:src/lib/static-pages.ts
- `src/proxy.ts` — production-replaced-by:middleware.ts

## Different reference files

- `eslint.config.mjs`
- `next.config.ts`
- `package-lock.json`
- `package.json`
- `README.md`
- `src/app/admin/appointments/actions.ts`
- `src/app/admin/appointments/page.tsx`
- `src/app/admin/career/page.tsx`
- `src/app/admin/forgot-password/page.tsx`
- `src/app/admin/forgot-password/reset/page.tsx`
- `src/app/admin/forgot-password/verify/page.tsx`
- `src/app/admin/package-requests/page.tsx`
- `src/app/admin/pages/[pageKey]/page.tsx`
- `src/app/admin/pages/appointment/page.tsx`
- `src/app/admin/pages/blogs/page.tsx`
- `src/app/admin/pages/career/page.tsx`
- `src/app/admin/pages/contact/page.tsx`
- `src/app/admin/pages/doctor-articles/page.tsx`
- `src/app/admin/pages/health-check/page.tsx`
- `src/app/admin/pages/legal/page.tsx`
- `src/app/admin/pages/news-media/page.tsx`
- `src/app/admin/pages/online-report/page.tsx`
- `src/app/admin/pages/patient-guide/page.tsx`
- `src/app/admin/pages/patient-stories/page.tsx`
- `src/app/admin/pages/support/page.tsx`
- `src/app/admin/sections/home-blogs/page.tsx`
- `src/app/admin/sections/home-corporate-services/page.tsx`
- `src/app/admin/sections/home-doctors/page.tsx`
- `src/app/admin/sections/home-news/page.tsx`
- `src/app/admin/sections/home-specialities/page.tsx`
- `src/app/admin/site-settings/page.tsx`
- `src/app/api/admin/auth/login/route.ts`
- `src/app/api/admin/auth/logout/route.ts`
- `src/app/api/admin/auth/me/route.ts`
- `src/app/api/admin/home-why-choose/route.ts`
- `src/app/api/admin/uploads/hero/route.ts`
- `src/app/api/admin/uploads/route.ts`
- `src/app/api/appointments/route.ts`
- `src/app/appointment/page.tsx`
- `src/app/contact/page.tsx`
- `src/app/online-report/page.tsx`
- `src/app/privacy-policy/page.tsx`
- `src/app/support/page.tsx`
- `src/app/terms/page.tsx`
- `src/components/admin/AboutPageAdmin.tsx`
- `src/components/admin/admin-sidebar-customization.ts`
- `src/components/admin/AdminAuthGate.tsx`
- `src/components/admin/AdminLoginForm.tsx`
- `src/components/admin/AdminPresetPage.tsx`
- `src/components/admin/appointments/AppointmentsTable.tsx`
- `src/components/admin/LocalContentAdmin.tsx`
- `src/components/admin/PublicPageEditor.tsx`
- `src/components/career/CareerApplicationForm.tsx`
- `src/components/home/HeroSlider.tsx`
- `src/components/public/CmsPublicPages.tsx`
- `src/components/public/PublicSitePage.tsx`
- `src/data/admin-auth.ts`
- `src/data/site-base.ts`
- `src/features/admin/home-hero/actions.ts`
- `src/features/admin/services/actions.ts`
- `src/features/admin/services/components/ServiceManager.tsx`
- `src/features/admin/services/schema.ts`
- `src/features/admin/services/service.ts`
- `src/features/admin/services/types.ts`
- `src/features/public/services/queries.ts`
- `src/lib/aboutPage.ts`
- `src/lib/admin-session.ts`
- `src/lib/appointments.ts`
- `src/lib/corporateServices.ts`
- `src/lib/doctorArticles.ts`
- `src/lib/doctors.ts`
- `src/lib/healthBlogs.ts`
- `src/lib/healthPackages.ts`
- `src/lib/home-why-choose.ts`
- `src/lib/newsMedia.ts`
- `src/lib/packageBookings.ts`
- `src/lib/patientStories.ts`
- `src/lib/specialties.ts`
- `src/types/appointment.ts`
