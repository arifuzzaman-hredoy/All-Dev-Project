# GitHub Actions Deployment Guide

## 1. Workflow path

The deployment workflow must be here:

```txt
.github/workflows/deploy.yml
```

## 2. Required GitHub Secrets

Create these secrets in GitHub repository settings:

```txt
VPS_HOST              VPS IP address or hostname
VPS_USERNAME          SSH username, usually root or deploy
VPS_PASSWORD          SSH password if password-based SSH is used
VPS_PORT              Usually 22
DEPLOY_REPO_URL       GitHub repository clone URL
```

Recommended optional secrets:

```txt
APP_DOMAIN            Production domain
PROJECT_ROOT          /var/www/update_project
```

## 3. Before first CI/CD deploy

The VPS must already have:

- Docker and Docker Compose plugin
- Nginx
- PostgreSQL database and user
- `/var/www/update_project/.env.production`
- Domain DNS pointing to VPS IP

## 4. First run

Push to main branch or run manually from GitHub Actions:

```txt
Actions → Deploy Update Clinic → Run workflow
```

## 5. Expected result

GitHub Actions will:

```txt
1. Run npm ci
2. Run lint/typecheck/build
3. SSH into VPS
4. Pull latest main
5. Run scripts/deploy.sh
6. Build Docker image
7. Run migrations
8. Restart app
9. Run health check
```

## 6. Failure recovery

On VPS:

```bash
cd /var/www/update_project
docker compose logs --tail=200 update_project
bash scripts/deploy-smoke-test.sh
bash scripts/backup-smoke-test.sh
```

If latest deploy broke app:

```bash
cd /var/www/update_project
git log --oneline -5
git checkout PREVIOUS_COMMIT
bash scripts/deploy.sh
```
