# Frontend Feature Parity Matrix

This matrix records the production decision for the frontend developer reference features.

| Area | Reference status | Production status | Decision |
|---|---|---|---|
| Career public page | Present | Present | Included and production-backed. |
| Career apply page | Present | Present | Included; submit flow connected to `/api/form-submissions`. |
| Career event detail page | Present | Present | Included. |
| Admin career page | Present | Present | Replaced/enhanced with DB-backed career applications panel. |
| Admin forgot password pages | Present | Present | Included with real reset APIs and DB token flow. |
| Admin login UI | Present | Present | Included with real auth endpoint preserved. |
| Admin shell/sidebar UI | Present | Present | Included with production navigation preserved. |
| Public contact/support/legal pages | Present | Present | Included with DB-backed static page content. |
| Public page localStorage helpers | Present | Not copied as storage | Replaced by DB-backed static page APIs. |
| Proxy/admin route guard | Present | Present through `middleware.ts` | Production replacement retained. |
| Backend/API/auth/DB/DevOps | Limited/demo in reference | Present in production | Production implementation retained. |

## Final parity note

The production project is not a byte-for-byte copy of the frontend reference. It is a production merge: frontend design/feature intent from the reference plus real backend, database, SMS workflow, admin auth, Docker, Nginx, SSL, and deployment hardening from the current project.
