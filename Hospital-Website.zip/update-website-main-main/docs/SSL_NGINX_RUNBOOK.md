# SSL + Nginx Runbook

## 1. DNS check

Run on local machine or VPS:

```bash
dig +short YOUR_DOMAIN
```

The result must be the VPS public IP.

## 2. Nginx config

Run on VPS:

```bash
cd /var/www/update_project
cp nginx/nginx/update.techteamlead.com.conf /etc/nginx/sites-available/update_project.conf
nano /etc/nginx/sites-available/update_project.conf
```

Change:

```txt
server_name update.techteamlead.com;
```

to your production domain.

## 3. Enable site

```bash
ln -sf /etc/nginx/sites-available/update_project.conf /etc/nginx/sites-enabled/update_project.conf
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

## 4. SSL

```bash
certbot --nginx -d YOUR_DOMAIN --redirect
certbot renew --dry-run
systemctl reload nginx
```

## 5. Verify

```bash
curl -I https://YOUR_DOMAIN
curl https://YOUR_DOMAIN/api/health
```
