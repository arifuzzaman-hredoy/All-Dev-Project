# Phase 9.1 — Multi Admin + SMTP Reset Email

## Completed scope

- Super Admin-only admin user management page at `/admin/users`.
- DB-backed admin user listing, creation, role update, activation/deactivation, and password reset.
- Protected API routes:
  - `GET/POST /api/admin/users`
  - `PATCH/DELETE /api/admin/users/[id]`
  - `POST /api/admin/users/[id]/reset-password`
- Forgot-password reset code continues to target the registered `AdminUser.email` address.
- Python FastAPI reset mailer service added at `services/reset-mailer`.
- SMTP/Gmail App Password delivery supported through `ADMIN_RESET_WEBHOOK_URL=http://reset_mailer:8010/admin-reset-email`.
- `docker-compose.yml` includes `reset_mailer` service on the internal Docker network.
- Audit logs are written for admin user creation, update, deactivation, and super-admin password resets.

## Security rules

- Public admin registration is not allowed.
- Only a logged-in `SUPER_ADMIN` can create or manage admin panel users.
- At least one active Super Admin is always protected.
- Temporary passwords are shown only once and never stored in plain text.
- SMTP secrets must stay in `.env.production` only and must never be committed to GitHub.

## Required production env

```env
ADMIN_RESET_SHOW_CODE=false
ADMIN_RESET_CODE_IN_AUDIT=false
ADMIN_RESET_CODE_TTL_MINUTES=10
ADMIN_RESET_WEBHOOK_URL=http://reset_mailer:8010/admin-reset-email
ADMIN_RESET_WEBHOOK_SECRET=CHANGE_ME_LONG_RANDOM_WEBHOOK_SECRET
RESET_MAILER_WEBHOOK_SECRET=CHANGE_ME_LONG_RANDOM_WEBHOOK_SECRET

SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_STARTTLS=false
SMTP_USER=techtemlead@gmail.com
SMTP_PASS=GMAIL_APP_PASSWORD_WITHOUT_SPACES
SMTP_FROM=Update Diagnostic Center <techtemlead@gmail.com>
RESET_MAIL_SUBJECT=Update Diagnostic Center admin recovery code
```

## Test checklist

```bash
npm run db:generate
npm run backend:support-check
npm run qa:regression
npm run lint
npm run typecheck
npm run build
npm run security:check
```
