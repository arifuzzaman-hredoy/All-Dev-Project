# Phase 6 — Live Deploy Checklist

Use this checklist during the live deployment window.

## Before deploy

- [ ] Frontend visual compare has passed.
- [ ] Client approved frontend design.
- [ ] Production domain selected.
- [ ] DNS access available.
- [ ] VPS root/sudo access available.
- [ ] GitHub repository access available.
- [ ] `.env.production` values prepared.
- [ ] Strong admin password prepared.
- [ ] Strong `ADMIN_SESSION_SECRET` generated.
- [ ] PostgreSQL database created.
- [ ] Backup folder exists: `/var/backups/update_project`.

## Deploy commands

```bash
cd /var/www/update_project
chmod +x scripts/*.sh
npm install
npm run env:check:production
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run deploy:check
docker compose build --no-cache
docker compose up -d
bash scripts/phase6-post-deploy-check.sh
```

## Nginx/SSL

```bash
DOMAIN=update.techteamlead.com APP_PORT=4090 bash scripts/setup-nginx.sh
DOMAIN=update.techteamlead.com EMAIL=admin@example.com bash scripts/setup-ssl.sh
```

## After deploy

- [ ] `/api/health` returns OK.
- [ ] Home page loads.
- [ ] Admin login works.
- [ ] Admin audit logs page works.
- [ ] Appointment form submit works.
- [ ] Package booking submit works.
- [ ] Image upload works.
- [ ] Backup created and verified.
- [ ] GitHub Actions deploy tested.
- [ ] SSL auto-renew test passed.

## Public QA URLs

```txt
/
/about
/services
/doctors
/appointment
/health-check
/blogs
/news-media
/doctor-articles
/patient-stories
/specialities
/contact
/support
/privacy-policy
/terms
/patient-guide
/online-report
/career
```

## Admin QA URLs

```txt
/admin
/admin/login
/admin/doctors
/admin/appointments
/admin/services
/admin/pages/health-check
/admin/package-requests
/admin/pages/blogs
/admin/pages/news-media
/admin/pages/doctor-articles
/admin/pages/patient-stories
/admin/sections/home-hero
/admin/sections/home-why-choose
/admin/site-settings
/admin/audit-logs
```

