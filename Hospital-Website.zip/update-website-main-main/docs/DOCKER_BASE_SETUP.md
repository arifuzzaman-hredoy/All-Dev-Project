# Docker Base Setup — Phase 1.1

This phase adds a Docker base for the Update Clinic Next.js app.

## What this phase does

- Builds the project inside Docker
- Uses `npm ci` for locked dependency installation
- Runs `npm run typecheck` during Docker build
- Runs `npm run build` during Docker build
- Runs the production app using `next start`
- Runs as non-root user inside the production container
- Exposes the app internally on port `3000`
- Maps host port through `APP_PORT`, default `4090`

## Why not standalone Docker yet?

The project currently has mixed file-based CMS, localStorage-based CMS, and many dynamic routes. Next.js build trace collection was hanging. For this phase, the safer Docker setup is:

```txt
production node_modules + .next + public + src/content
```

This is not the smallest Docker image, but it is safer for the current project. After the database/CMS migration, this can be optimized.

## Important limitation

This phase does not yet add persistent Docker volumes for file uploads or JSON content storage.

Your current app still writes some admin data to local files:

```txt
src/content/*.json
public/uploads/*
```

Phase 1.2 will add persistent storage so those files are not lost after container rebuild/redeploy.

## Local URL

```txt
http://localhost:4090
```

## VPS temporary URL before Nginx

```txt
http://198.54.121.88:4090
```

## Production domain with Nginx/SSL

Nginx + SSL will be added in a later phase.
