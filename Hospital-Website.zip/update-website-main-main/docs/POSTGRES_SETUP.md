# Update Clinic — Phase 2.1 PostgreSQL Setup

## Goal

Prepare a PostgreSQL database on the VPS for the future Prisma backend.

This phase does **not** convert the application code to database yet. It only creates/checks:

- PostgreSQL database
- PostgreSQL user
- Database privileges
- `DATABASE_URL` value
- Connection smoke test

## Recommended database values

```env
DB_NAME=update_clinic
DB_USER=update_clinic_user
DB_HOST=127.0.0.1
DB_PORT=5432
```

Generate a strong password on the VPS:

```bash
openssl rand -base64 32
```

## VPS setup

Run from VPS as root:

```bash
cd /var/www/update_project
chmod +x scripts/postgres-create-update-clinic.sh scripts/postgres-check.sh scripts/postgres-smoke-test.sh

DB_PASSWORD='CHANGE_THIS_STRONG_PASSWORD' bash scripts/postgres-create-update-clinic.sh
```

The script prints a `DATABASE_URL`. Add that line to:

```txt
/var/www/update_project/.env.production
```

Example:

```env
DATABASE_URL="postgresql://update_clinic_user:CHANGE_THIS_STRONG_PASSWORD@127.0.0.1:5432/update_clinic?schema=public"
```

## Connection test

```bash
DB_PASSWORD='CHANGE_THIS_STRONG_PASSWORD' bash scripts/postgres-check.sh
DB_PASSWORD='CHANGE_THIS_STRONG_PASSWORD' bash scripts/postgres-smoke-test.sh
```

Expected result:

```txt
[postgres-check] PASS
[postgres-smoke-test] PASS
```

## If PostgreSQL is not installed

Ubuntu 24.04:

```bash
apt update
apt install -y postgresql postgresql-contrib
systemctl enable postgresql
systemctl start postgresql
systemctl status postgresql --no-pager
```

## Important warning

Do not expose PostgreSQL publicly unless you absolutely need remote DB access. For this VPS deployment, keep:

```env
DB_HOST=127.0.0.1
```

The Next.js container can access host PostgreSQL with the correct Docker network strategy later. In Phase 2.2/2.3 we will adjust `DATABASE_URL` if PostgreSQL runs inside Docker instead of host.

## Current limitation

After Phase 2.1, the app still does not use PostgreSQL. Actual application database integration starts in:

- Phase 2.2 Prisma install/config
- Phase 2.3 initial migration/seed
- Phase 3 Backend API + Prisma
- Phase 4 localStorage → real CMS migration
