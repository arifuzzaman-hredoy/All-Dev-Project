# Regression QA Checklist

## Local checks

```powershell
cd "G:\Current Project\Development\Update Project\update-website-git-final"
npm install
npm run db:generate
npm run qa:full
```

## VPS deploy-ready checks

```bash
cd /var/www/update_project
npm run qa:deploy-ready
```

## Docker checks

```bash
cd /var/www/update_project
docker compose build --no-cache
docker compose down --remove-orphans
docker compose up -d
sleep 25
docker compose ps
```

## Live checks

```bash
cd /var/www/update_project
QA_BASE_URL=https://update.techteamlead.com npm run qa:live-smoke
```

## Career write test

```bash
cd /var/www/update_project
QA_BASE_URL=https://update.techteamlead.com QA_WRITE_TEST=true npm run qa:live-smoke
```

Expected result: POST `/api/form-submissions` returns a submission id.

## Manual admin checks

- `/admin/login` login works with current private credential.
- `/admin/career` loads database applications.
- Career application status update works.
- SMS logs page loads.
- SMS template page loads.
- Export center loads.
- Public pages load on desktop and mobile.

## Final handover checks

- `git status --short` has no output.
- `docker compose ps` shows healthy containers.
- Final backup exists under `/var/backups/update_project`.
- Admin password is rotated and delivered privately.
- Real SMS remains pending until client provides API credentials.
