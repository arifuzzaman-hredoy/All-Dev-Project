# Phase 3.7 — Homepage Sections DB-backed Guide

## What changed

Phase 3.7 moves core homepage section data to database-backed storage.

## Hero + Quick Actions

Hero content is stored in `SiteSetting`:

- key: `home.hero.content`

This is intentional because the existing hero editor has more fields than the original `HomeHeroSlide` table could safely store. Using JSON in `SiteSetting` preserves all existing fields without data loss.

## Why Choose

Why Choose content uses:

- `WhyChooseSection`
- `WhyChooseSpeciality`

`WhyChooseSpeciality` now has:

- `isActive Boolean @default(true)`

## Production note

You are currently using Neon for local/dev. During VPS deployment, replace `DATABASE_URL` with the VPS PostgreSQL URL and run migrations against the VPS DB.
