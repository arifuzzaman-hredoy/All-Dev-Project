# Phase 3.2 — Doctors + Appointments DB CRUD

## What changed

Doctors and appointments now use PostgreSQL through Prisma instead of writing to these JSON files:

- `src/content/doctors.json`
- `src/content/appointments.json`

The JSON files can still stay in the project as seed source data, but runtime CRUD now goes to the database.

## Affected app areas

- Public doctor list through `/api/doctors`
- Admin doctors page
- Doctor add/edit/delete APIs
- Public appointment submit API
- Admin appointment request table
- Appointment delete server action

## Required command after replacing files

```powershell
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run db:migrate:status
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
npm run dev
```

## Browser test

Open:

- http://localhost:4090/admin/doctors
- http://localhost:4090/appointment
- http://localhost:4090/admin/appointments

Test:

1. Login to admin.
2. Add a new doctor.
3. Edit the doctor.
4. Disable/enable the doctor.
5. Submit a public appointment using that doctor.
6. Confirm the appointment appears in `/admin/appointments`.
7. Delete that appointment.

## Production note

For VPS production, use the VPS PostgreSQL `DATABASE_URL`. This patch does not hardcode Neon.
