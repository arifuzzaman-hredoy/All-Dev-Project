# Neon PostgreSQL Local Database Guide

This project is configured to use port `4090` for local/dev and Docker host access.

## 1. Create local env

Copy `.env.local.example` to `.env.local`:

```bash
cp .env.local.example .env.local
```

Then paste your real Neon `DATABASE_URL` into `.env.local`.

Important: keep `sslmode=require` in the URL.

## 2. Install and validate

```bash
npm install
npm run db:validate
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
```

## 3. Run locally

```bash
npm run dev
```

Open:

```txt
http://localhost:4090
http://localhost:4090/admin
```

## Security warning

Do not commit `.env.local` or `.env.production`. If a real database URL was pasted into chat, screenshots, or shared files, rotate the database password before final production.
