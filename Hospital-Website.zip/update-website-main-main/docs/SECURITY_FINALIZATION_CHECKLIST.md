# Security Finalization Checklist

Use this checklist immediately before client handover.

## Source and repository

- [ ] GitHub `main` has the latest code.
- [ ] VPS `HEAD` matches `origin/main`.
- [ ] `git status --short` is clean.
- [ ] `.env`, `.env.production`, and local backups are not committed.
- [ ] Final client source ZIP is created from Git HEAD, not from a working folder with untracked files.

## Environment

- [ ] `NODE_ENV=production`.
- [ ] `NEXT_PUBLIC_SITE_URL` uses HTTPS.
- [ ] `DATABASE_URL` points to production PostgreSQL.
- [ ] `ADMIN_PASSWORD` is strong and newly rotated.
- [ ] `ADMIN_SESSION_SECRET` is random and 64+ characters.
- [ ] `ADMIN_RESET_SHOW_CODE=false`.
- [ ] `ADMIN_RESET_CODE_IN_AUDIT=false`.
- [ ] `SMS_ENABLED=false` unless client SMS API is configured.
- [ ] `SMS_PROVIDER=mock` unless client SMS API is configured.

## Admin security

- [ ] Admin password hash is synced into database.
- [ ] Old admin sessions are cleared after password rotation.
- [ ] Admin login route returns `200`.
- [ ] Admin login works with the final password.
- [ ] Final password is shared privately only.

## Backend security

- [ ] Password reset request API exists.
- [ ] Password reset verify API exists.
- [ ] Password reset complete API exists.
- [ ] Reset token expires.
- [ ] Reset token is one-time use.
- [ ] Reset flow clears old sessions after password update.

## Deployment

- [ ] Docker build passes.
- [ ] Containers are healthy.
- [ ] Nginx/SSL live route checks pass.
- [ ] App logs show no critical runtime error.
- [ ] SMS service health passes.

## Backup

- [ ] Environment backup created before rotation.
- [ ] Final source/server backup created after rotation.
- [ ] Backup file permission restricted where needed.
- [ ] Backup path is recorded in handover notes.
