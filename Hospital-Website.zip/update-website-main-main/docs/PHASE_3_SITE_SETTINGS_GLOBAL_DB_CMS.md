# Phase 3 — Site Settings Global DB CMS

## Status

Completed for the current project package.

## Goal

Keep the frontend design exactly the same while making global site identity and contact data come from the PostgreSQL-backed `SiteSetting` record instead of hardcoded `siteInfo` values.

## DB Source

Site settings are stored in the `SiteSetting` table using this key:

```txt
site.settings
```

The shared helper is:

```ts
getPublicSiteSettings()
```

It safely falls back to `DEFAULT_SITE_SETTINGS` if the database is unavailable during local development.

## Connected Public Areas

- Root metadata / SEO defaults
- Favicon metadata
- Header emergency number and logo
- Footer description, phone, email, address, hours, copyright, and logo
- Contact page fallback contact information
- Contact Google map URL/embed URL
- Appointment page emergency/support phone values
- Support page contact CTA values
- Terms and privacy dynamic organization name/email text
- Admin appointments print clinic name

## Admin Area

`/admin/site-settings` now saves and reads settings through:

```txt
/api/admin/site-settings
```

The localStorage fallback was removed from the site settings admin page so global settings remain database controlled.

## Frontend UI

No design or layout change was made. Only data source wiring was changed.
