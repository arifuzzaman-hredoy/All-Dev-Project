# Post Deployment QA Checklist

After production deploy, test these pages:

```txt
/
/about
/services
/doctors
/appointment
/health-check
/blogs
/news-media
/doctor-articles
/patient-stories
/specialities
/contact
/support
/privacy-policy
/terms
/patient-guide
/online-report
/career
/admin/login
/admin
/admin/audit-logs
/api/health
```

Admin CRUD test:

```txt
1. Login
2. Site settings save
3. Service edit/save
4. Doctor edit/save
5. Blog/news/article edit/save
6. Health package edit/save
7. Appointment submit from public page
8. Package booking submit
9. Audit log visible
10. Logout
```

Frontend locked visual compare:

```txt
Desktop 1440px
Laptop 1366px
Tablet 768px
Mobile 390px
```

Check:

```txt
Header same
Footer same
Hero same
Spacing same
Colors same
Cards same
Images same
Mobile menu same
No broken images
```
