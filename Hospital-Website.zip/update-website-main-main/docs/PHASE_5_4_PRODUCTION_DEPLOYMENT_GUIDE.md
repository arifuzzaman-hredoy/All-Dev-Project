# Phase 5.4 — Final Production Deployment Guide

This guide is for deploying the Update Clinic project on a VPS without changing the locked frontend design.

## 0. Production rules

- Do not commit `.env`, `.env.local`, or `.env.production`.
- Do not run `npx prisma db push` in production.
- Use `npm run db:migrate:deploy` for production database migrations.
- Rotate the local Neon database URL and admin credentials before going live if they were ever shared in chat or screenshots.
- Keep frontend public UI files locked unless the client approves design changes.

## 1. Local final test before upload/push

Run this in **local Windows PowerShell** from your project root:

```powershell
cd "G:\Current Project\Development\Update Project\update-website-main"

npm install
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run db:migrate:status

npm run lint -- --max-warnings=0
npm run typecheck
npm run build
```

Expected:

```txt
lint       PASS
typecheck  PASS
build      PASS
```

## 2. VPS base path

Recommended production path:

```bash
/var/www/update_project
```

Recommended app port:

```bash
4090
```

## 3. First-time VPS setup

Run on the **VPS server** as root or sudo user:

```bash
apt update && apt upgrade -y
apt install -y git curl ca-certificates gnupg nginx certbot python3-certbot-nginx ufw fail2ban postgresql postgresql-contrib

install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
. /etc/os-release
printf "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu %s stable\n" "$VERSION_CODENAME" > /etc/apt/sources.list.d/docker.list
apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker nginx postgresql fail2ban
```

Firewall:

```bash
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
ufw status
```

## 4. PostgreSQL setup on VPS

Run on **VPS server**:

```bash
sudo -u postgres psql
```

Inside `psql`:

```sql
CREATE DATABASE update_clinic;
CREATE USER update_clinic_user WITH ENCRYPTED PASSWORD 'REPLACE_STRONG_DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE update_clinic TO update_clinic_user;
\c update_clinic
GRANT ALL ON SCHEMA public TO update_clinic_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO update_clinic_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO update_clinic_user;
\q
```

Connection string format:

```txt
postgresql://update_clinic_user:REPLACE_STRONG_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public
```

## 5. Project clone

Run on **VPS server**:

```bash
mkdir -p /var/www
cd /var/www

git clone YOUR_GITHUB_REPO_URL update_project
cd /var/www/update_project
chmod +x scripts/*.sh
```

## 6. Production env file

Run on **VPS server**:

```bash
cd /var/www/update_project
cp .env.production.example .env.production
nano .env.production
```

Required values:

```env
NODE_ENV=production
APP_PORT=4090
NEXT_PUBLIC_SITE_URL="https://YOUR_DOMAIN"
DATABASE_URL="postgresql://update_clinic_user:REPLACE_STRONG_DB_PASSWORD@127.0.0.1:5432/update_clinic?schema=public"
ADMIN_EMAIL="real-admin@example.com"
ADMIN_PASSWORD="REPLACE_WITH_STRONG_12_PLUS_CHARACTER_PASSWORD"
ADMIN_SESSION_SECRET="REPLACE_WITH_RANDOM_64_PLUS_CHARACTER_SECRET"
ADMIN_FORCE_LOGIN_ON_REFRESH="false"
PROJECT_NAME="update_project"
PROJECT_ROOT="/var/www/update_project"
BACKUP_ROOT="/var/backups/update_project"
BACKUP_REQUIRE_DATABASE="YES"
KEEP_BACKUPS="14"
```

Generate a strong session secret:

```bash
openssl rand -hex 64
```

## 7. Pre-deploy check

Run on **VPS server**:

```bash
cd /var/www/update_project
npm install
npm run env:check:production
npm run deploy:check
```

## 8. Docker deploy

Run on **VPS server**:

```bash
cd /var/www/update_project
chmod +x scripts/*.sh
bash scripts/prepare-volumes.sh

docker compose build --pull
docker compose run --rm --no-deps update_project npm run db:migrate:deploy
docker compose run --rm --no-deps update_project npm run db:seed
docker compose up -d --remove-orphans

docker compose ps
docker compose logs --tail=120 update_project
curl -I http://127.0.0.1:4090
curl http://127.0.0.1:4090/api/health
```

## 9. Nginx setup

Replace domain first:

```bash
cd /var/www/update_project
cp nginx/nginx/update.techteamlead.com.conf /etc/nginx/sites-available/update_project.conf
nano /etc/nginx/sites-available/update_project.conf
```

Enable config:

```bash
ln -sf /etc/nginx/sites-available/update_project.conf /etc/nginx/sites-enabled/update_project.conf
nginx -t
systemctl reload nginx
```

## 10. SSL setup

Before SSL, domain DNS `A` record must point to VPS IP.

Run on **VPS server**:

```bash
certbot --nginx -d YOUR_DOMAIN --redirect
certbot renew --dry-run
systemctl reload nginx
```

## 11. Production smoke test

Open:

```txt
https://YOUR_DOMAIN
https://YOUR_DOMAIN/api/health
https://YOUR_DOMAIN/admin/login
```

Then test:

- Admin login
- Site settings save
- Service edit/save
- Blog/news edit/save
- Appointment submit
- Health package booking submit
- Audit logs page
- Backup script

## 12. Normal deploy after first setup

Run on **VPS server**:

```bash
cd /var/www/update_project
git pull origin main
bash scripts/deploy.sh
```

Or use GitHub Actions after secrets are configured.
