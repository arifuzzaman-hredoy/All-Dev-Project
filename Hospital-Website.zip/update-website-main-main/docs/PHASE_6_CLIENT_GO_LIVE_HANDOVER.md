# Phase 6 — Client Go-live Handover

## Production URLs

```txt
Website: https://update.techteamlead.com
Admin:   https://update.techteamlead.com/admin
```

## Admin login

Admin email and password must be shared securely, not inside GitHub or public docs.

## Client testing checklist

- Home page design
- Mobile responsive view
- Doctor list
- Service list/detail
- Appointment form
- Health check booking
- Blog/news/article pages
- Patient stories
- Contact/support pages
- Admin login
- Admin content update
- Image upload

## Maintenance commands

```bash
cd /var/www/update_project
bash scripts/backup.sh
docker compose logs --tail=200 update_project
bash scripts/vps-final-check.sh
```

## Backup policy

Recommended:

- Daily database/content backup
- Keep at least 14 backups
- Verify backup after creation
- Test restore before major release

## Do not share

- `.env.production`
- Database URL
- Admin password
- Session secret
- VPS password
- GitHub secrets

