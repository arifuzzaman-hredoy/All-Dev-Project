# Phase 4.1 — Static Pages DB-backed

This phase moves the main static public pages from hardcoded/static component content to PostgreSQL-backed CMS content.

## DB-backed public pages

- `/about`
- `/contact`
- `/support`
- `/privacy-policy`
- `/terms`
- `/patient-guide`
- `/online-report`
- `/career`

## Admin editors

- `/admin/pages/about`
- `/admin/pages/contact`
- `/admin/pages/support`
- `/admin/pages/privacy-policy`
- `/admin/pages/terms`
- `/admin/pages/legal`
- `/admin/pages/patient-guide`
- `/admin/pages/online-report`
- `/admin/pages/career`

## API routes

Admin protected:

- `GET /api/admin/static-pages`
- `GET /api/admin/static-pages/[key]`
- `PUT /api/admin/static-pages/[key]`
- `POST /api/admin/static-pages/[key]/reset`

Public:

- `GET /api/static-pages/[slug]`

## Database model

Adds `StaticPage` model with:

- key
- slug
- eyebrow
- title
- description
- heroImage
- body JSON
- highlights JSON
- cards JSON
- CTA labels/links
- SEO title/description
- publish status

## Production rule

Fresh VPS PostgreSQL:

```bash
npm run db:migrate:deploy
npm run db:seed
npm run build
```

Current dev Neon database:

```bash
npm run db:generate
npm run db:migrate:deploy
npm run db:seed
npm run lint -- --max-warnings=0
npm run typecheck
npm run build
npm run dev
```

Do not use `db push` unless a dev-only emergency sync is needed.
