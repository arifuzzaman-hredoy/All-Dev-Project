# Phase 3.3 — Services + Site Settings Database-backed

## What changed

Services are now managed through PostgreSQL/Prisma instead of `src/content/public-content.json` or browser localStorage behavior.

Site Settings are now saved to the `SiteSetting` table under key:

```txt
site.settings
```

## Important

Development can use Neon DATABASE_URL. Production can use VPS PostgreSQL later by changing only `DATABASE_URL` in `.env.production`.

## Database changes

Migration:

```txt
prisma/migrations/20260612190000_services_site_settings_db/migration.sql
```

Adds richer fields to `Service`:

- shortDescription
- overview
- fullDescription
- featuredImage
- galleryImages
- priceRange
- duration
- availableTime
- doctorName
- doctorTitle
- phone
- featured
- highlights
- facilities
- symptoms
- seoTitle
- seoDescription

## Admin APIs

```txt
GET    /api/admin/services
POST   /api/admin/services
PUT    /api/admin/services/[id]
PATCH  /api/admin/services/[id]
DELETE /api/admin/services/[id]
POST   /api/admin/services/reorder
PUT    /api/admin/services/bulk
GET    /api/admin/site-settings
PUT    /api/admin/site-settings
DELETE /api/admin/site-settings
```

All admin APIs require admin session.
