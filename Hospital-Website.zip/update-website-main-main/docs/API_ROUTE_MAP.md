# Phase 0 API Route Map

## Existing API routes

```txt
src/app/api/admin/auth/login/route.ts
src/app/api/admin/auth/logout/route.ts
src/app/api/admin/auth/me/route.ts
src/app/api/admin/home-why-choose/route.ts
src/app/api/admin/uploads/route.ts
src/app/api/admin/uploads/hero/route.ts
src/app/api/appointments/route.ts
src/app/api/doctors/route.ts
src/app/api/doctors/[id]/route.ts
```

## Current storage used by backend-like routes

| Feature | Current storage | Production problem |
|---|---|---|
| Appointments | `src/content/appointments.json` | No DB transaction, weak for concurrent writes |
| Doctors | `src/content/doctors.json` | No DB query/migration/backup system |
| Home why choose | `src/content/home-why-choose.json` | File write can be lost during deploy without persistent volume |
| Home hero/public content | `src/content/public-content.json` | File-based CMS only |
| Uploads | `public/uploads/*` | Needs persistent volume or object storage |

## Required future API groups

```txt
/api/admin/site-settings
/api/admin/services
/api/admin/health-packages
/api/admin/package-bookings
/api/admin/blogs
/api/admin/news-media
/api/admin/doctor-articles
/api/admin/patient-stories
/api/admin/specialities
/api/admin/corporate-services
/api/admin/media
```

## Phase 3/4 API rule

Every admin mutation must:

1. validate input,
2. check admin session server-side,
3. write to Prisma/PostgreSQL,
4. return a consistent JSON response,
5. revalidate public routes when needed.
