/* eslint-disable no-console */
const { PrismaClient } = require('@prisma/client');
const { randomBytes, scryptSync } = require('crypto');
const fs = require('fs/promises');
const path = require('path');

const prisma = new PrismaClient();

const CONTENT_DIR = path.join(process.cwd(), 'src', 'content');

const DEFAULT_HOME_SECTION_TEASERS = {
  'home-doctors': {
    key: 'home-doctors',
    eyebrow: 'Doctors',
    title: 'Experienced consultants across key departments.',
    description: 'Book with active specialists and view current schedules from the doctor directory.',
    buttonLabel: 'Meet all doctors',
    buttonHref: '/doctors',
    limit: 4,
    isActive: true,
  },
  'home-news': {
    key: 'home-news',
    eyebrow: 'News & Media',
    title: 'Latest News & Media Updates',
    description: 'Stay connected with our latest healthcare updates, announcements, media coverage, and important clinic news.',
    buttonLabel: 'View All News & Media',
    buttonHref: '/news-media',
    limit: 3,
    isActive: true,
  },
  'home-blogs': {
    key: 'home-blogs',
    eyebrow: 'Health Blog',
    title: 'Latest Blogs',
    description: 'Read practical health guides, prevention tips, and patient education articles from Update Diagnostic Center.',
    buttonLabel: 'View More Blogs',
    buttonHref: '/blogs',
    limit: 3,
    isActive: true,
  },
};



const DEFAULT_HEALTH_PACKAGES = [
  {
    slug: 'hajj-health-check',
    title: 'Hajj Health Check',
    target: '',
    price: '8,500 BDT',
    image: '/slider3.jpeg',
    tests: ['CBC', 'Blood Grouping', 'Creatinine-Serum', 'Glucose (Random)', 'ECG', 'Chest PA (X-Ray)', 'Urine Routine Examination', 'Vaccination Fitness Review', 'Physician Consultation', 'Medical Certificate Guidance'],
  },
  {
    slug: 'executive-health-check',
    title: 'Executive Health Check',
    target: 'Male / Female',
    price: '18,000 BDT',
    image: '/slider1.jpeg',
    tests: ['CBC', 'ESR', 'Lipid Profile', 'Liver Function Test', 'Kidney Function Test', 'HbA1c', 'Ultrasonogram Whole Abdomen', 'ECG', 'Eye Screening', 'Dental Screening', 'Diet Consultation'],
  },
  {
    slug: 'heart-check-for-men',
    title: 'Heart Check',
    target: 'For Men',
    price: '21,000 BDT',
    image: '/slider2.jpeg',
    tests: ['Creatinine-Serum', 'Urea-Serum', 'Uric Acid-Serum', 'ECG', 'Echo Screening', 'TMT', 'CBC', 'ESR', 'Lipid Profile-Serum', 'Chest PA (X-Ray)', 'Consultation Fee'],
  },
  {
    slug: 'heart-check-for-women',
    title: 'Heart Check',
    target: 'For Women',
    price: '21,500 BDT',
    image: '/pasent.jpeg',
    tests: ['Creatinine-Serum', 'Urea-Serum', 'ECG', 'Echo Screening', 'TMT', 'CBC', 'ESR', 'Lipid Profile-Serum', 'Thyroid Stimulating Hormone', 'Chest PA (X-Ray)', 'Consultation Fee'],
  },
  {
    slug: 'whole-body-check-men-below-45-years',
    title: 'Whole Body Check',
    target: 'Men Below 45 Years',
    price: '15,000 BDT',
    image: '/slider1.jpeg',
    tests: ['CBC', 'ESR', 'Blood Grouping', 'Glucose (Fasting)', 'Lipid Profile', 'Liver Function Test', 'Kidney Function Test', 'Urine Profile', 'Chest PA (X-Ray)', 'ECG'],
  },
  {
    slug: 'whole-body-check-men-above-45-years',
    title: 'Whole Body Check',
    target: 'Men Above 45 Years',
    price: '19,000 BDT',
    image: '/slider3.jpeg',
    tests: ['CBC', 'ESR', 'HbA1c', 'Lipid Profile', 'Liver Function Test', 'Kidney Function Test', 'PSA Screening', 'Ultrasonogram Whole Abdomen', 'Chest PA (X-Ray)', 'ECG'],
  },
  {
    slug: 'whole-body-check-women-below-45-years',
    title: 'Whole Body Check',
    target: 'Women Below 45 Years',
    price: '15,500 BDT',
    image: '/pasent.jpeg',
    tests: ['CBC', 'ESR', 'Blood Grouping', 'Glucose (Fasting)', 'Lipid Profile', 'Liver Function Test', 'Kidney Function Test', 'Urine Profile', 'Thyroid Screening', 'ECG'],
  },
  {
    slug: 'whole-body-check-women-above-45-years',
    title: 'Whole Body Check',
    target: 'Women Above 45 Years',
    price: '19,500 BDT',
    image: '/slider2.jpeg',
    tests: ['CBC', 'ESR', 'HbA1c', 'Lipid Profile', 'Liver Function Test', 'Kidney Function Test', 'Thyroid Screening', 'Ultrasonogram Whole Abdomen', 'Chest PA (X-Ray)', 'ECG'],
  },
];


const DEFAULT_HEALTH_BLOGS = [
  {
    slug: 'rising-measles-cases-bangladesh',
    title: 'Rising Measles Cases in Bangladesh: Urgent Measures Needed for Prevention',
    date: '2026-04-08',
    image: '/blogs/blog-1.jpg',
    excerpt: 'Measles prevention depends on vaccination awareness, early symptom recognition, and timely consultation for children.',
    body: [
      'Measles can spread quickly among children when vaccination coverage is low. Parents should watch for fever, rash, cough, and eye irritation.',
      'Early medical advice helps reduce complications and protects other children through timely isolation and care guidance.',
      'This demo blog can be replaced with approved health education content, campaign details, and prevention guidance.',
    ],
  },
  {
    slug: 'childhood-nephrotic-syndrome',
    title: 'Childhood Nephrotic Syndrome: Causes, Symptoms, Diagnosis, and...',
    date: '2026-01-31',
    image: '/blogs/blog-2.jpg',
    excerpt: 'Parents should understand common warning signs such as swelling, urine changes, and repeated fatigue in children.',
    body: [
      'Childhood nephrotic syndrome often appears with swelling around the eyes, legs, or abdomen. Urine changes may also be noticed.',
      'Diagnosis usually includes urine tests, blood tests, and doctor evaluation. Treatment depends on the child\'s condition and response.',
      'Use this page as a structured article template for pediatric education and specialist-reviewed content.',
    ],
  },
  {
    slug: 'winter-baby-health-care',
    title: 'Winter Baby Health Care: Essential Tips to Keep Your Baby Safe and Healthy i...',
    date: '2026-01-19',
    image: '/blogs/blog-3.jpg',
    excerpt: 'Winter care for babies includes warmth, hygiene, hydration, feeding support, and watching for breathing difficulty.',
    body: [
      'During winter, babies need comfortable clothing, clean bedding, and protection from cold air without overheating.',
      'Parents should monitor cough, fever, poor feeding, and breathing difficulty. Early consultation is important if symptoms continue.',
      'This demo blog can later be expanded with real pediatric tips, seasonal care campaigns, and family guidance.',
    ],
  },
];

const DEFAULT_NEWS_MEDIA = [
  {
    slug: 'new-diagnostic-service-launched',
    title: 'New Diagnostic Service Launched for Patients',
    date: '2026-05-20',
    image: '/news/news-1.jpg',
    excerpt: 'Update Diagnostic Center has introduced a new diagnostic service to support faster patient screening and clearer report guidance.',
    body: [
      'The new diagnostic service is designed to help patients complete essential tests with organized scheduling, guided sample collection, and reliable report handling.',
      'Our team is focused on making the diagnostic journey easier for families, working professionals, and patients who need timely clinical support.',
      'This page is ready for real news content, media updates, press releases, and announcement details.',
    ],
  },
  {
    slug: 'health-awareness-program',
    title: 'Health Awareness Program Successfully Organized',
    date: '2026-05-12',
    image: '/news/news-2.jpg',
    excerpt: 'A health awareness program was organized to encourage preventive screening, healthy habits, and early medical consultation.',
    body: [
      'The program focused on practical wellness guidance, preventive checkups, and the importance of timely diagnosis for common health risks.',
      'Participants received information about health check packages, lifestyle choices, and when to consult specialists for further evaluation.',
      'This article template can be expanded with real event photos, speaker names, and program highlights.',
    ],
  },
  {
    slug: 'specialist-doctor-joined',
    title: 'New Specialist Doctor Joined Our Medical Team',
    date: '2026-05-05',
    image: '/news/news-3.jpg',
    excerpt: 'A new specialist doctor has joined the medical team to strengthen consultation access for patients.',
    body: [
      'The addition of a new specialist supports our goal of making expert consultation more accessible for patients and families.',
      'Patients can request appointments through the website and receive guidance from the care desk for available schedules.',
      'Replace this demo content with the doctor\'s profile, department, chamber schedule, and official announcement text.',
    ],
  },
];

const DEFAULT_DOCTOR_ARTICLES = [
  {
    slug: 'diabetic-patients-ramadan-fasting',
    title: 'What Should Diabetic Patients Do During Ramadan Fasting?',
    author: 'Prof. Dr. Ariful Hasan Sarkar',
    date: '2026-03-03',
    image: '/doctor-articles/doctor-1.jpg',
    excerpt: 'A practical doctor guideline for diabetic patients who want to fast safely during Ramadan with medical supervision.',
    body: [
      'Diabetic patients should consult their doctor before Ramadan to review medicine timing, diet planning, hydration, and glucose monitoring.',
      'Patients with unstable sugar levels, kidney disease, pregnancy, or repeated hypoglycemia may need a different plan and close follow-up.',
      'This article is demo content and can be replaced with approved doctor advice, department details, and real consultation guidance.',
    ],
  },
  {
    slug: 'early-detection-can-save-lives',
    title: 'Early Detection Can Save Lives',
    author: 'Dr. Ferdous Shahriar',
    date: '2026-02-17',
    image: '/doctor-articles/doctor-2.jpg',
    excerpt: 'Regular screening and early consultation can help detect serious diseases before symptoms become complicated.',
    body: [
      'Many health conditions become easier to treat when detected early. Regular screening helps doctors identify risks and begin care at the right time.',
      'Patients should not ignore persistent symptoms, family history, or recurring discomfort. Consultation and diagnostics can provide clarity.',
      'Use this page to publish doctor-written awareness articles, preventive care notes, and screening campaign content.',
    ],
  },
  {
    slug: 'cancer-prevention-awareness',
    title: 'Awareness is essential for cancer prevention',
    author: 'Dr. Abdullah Reza Chowdhury',
    date: '2026-02-17',
    image: '/doctor-articles/doctor-3.jpg',
    excerpt: 'Lifestyle awareness, screening, and timely specialist consultation can support prevention and early cancer detection.',
    body: [
      'Cancer awareness starts with understanding risk factors, recognizing warning signs, and choosing screening when recommended by specialists.',
      'Healthy habits, tobacco avoidance, vaccination when appropriate, and regular checkups can reduce risk and improve outcomes.',
      'This demo article can later include real doctor interviews, awareness program details, and approved educational content.',
    ],
  },
];

const DEFAULT_SITE_SETTINGS = {
  siteName: 'Update Diagnostic Center',
  tagline: 'Advanced care with a human touch',
  description: 'A modern multi-speciality healthcare destination focused on safe treatment, clear communication, and comfortable patient experiences.',
  logoUrl: '',
  faviconUrl: '',
  phone: '01763-555555',
  emergency: '01971-555555',
  whatsapp: '01763-555555',
  email: 'update.diagnostic@gmail.com',
  address: 'Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh',
  city: 'Rangpur',
  country: 'Bangladesh',
  hours: 'Open 24/7',
  googleMapUrl: 'https://maps.google.com',
  googleMapEmbedUrl: '',
  facebookUrl: 'https://facebook.com',
  youtubeUrl: 'https://youtube.com',
  linkedinUrl: 'https://linkedin.com',
  websiteUrl: process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:4090',
  seoTitle: 'Update Diagnostic Center - Advanced Healthcare',
  seoDescription: 'Update Diagnostic Center provides modern diagnostic and healthcare services with reliable care, clear communication, and patient-first support.',
  seoKeywords: 'diagnostic center, hospital, healthcare, Rangpur, doctor, emergency, medical service',
  primaryButtonText: 'Book Appointment',
  primaryButtonUrl: '/appointment',
  secondaryButtonText: 'Call Emergency',
  secondaryButtonUrl: 'tel:01971555555',
  footerText: 'Advanced care with a human touch.',
  copyrightText: '© 2026 Update Diagnostic Center. All rights reserved.',
};


const DEFAULT_STATIC_PAGES = [
  {
    key: 'about',
    slug: 'about',
    eyebrow: 'About Update Diagnostic Center',
    title: 'Advanced healthcare with a human touch',
    description: 'Update Diagnostic Center brings diagnostics, specialist consultation, patient support, and modern healthcare guidance into one organized experience.',
    heroImage: '/slider1.jpeg',
    body: ['We are building a healthcare experience where patients can understand services clearly, request support quickly, and feel guided from the first visit.', 'Our team focuses on reliable diagnostic service, specialist access, transparent communication, and a calm environment for families.'],
    highlights: ['Modern diagnostic support', 'Experienced medical team', 'Patient-first service desk', 'Organized healthcare journey'],
    cards: [{ title: 'Our Mission', description: 'Make reliable healthcare easier to access through clear service guidance, diagnostics, and patient support.' }, { title: 'Our Vision', description: 'Become a trusted diagnostic and healthcare destination for families and working professionals.' }, { title: 'Our Values', description: 'Care, clarity, safety, responsibility, and respectful communication with every patient.' }],
    primaryButtonLabel: 'Book Appointment', primaryButtonHref: '/appointment', secondaryButtonLabel: 'View Services', secondaryButtonHref: '/services', seoTitle: 'About Update Diagnostic Center', seoDescription: 'Learn about Update Diagnostic Center, our healthcare mission, diagnostic services, and patient-first support.', sortOrder: 1,
  },
  {
    key: 'contact', slug: 'contact', eyebrow: 'Contact Us', title: 'Contact and location details', description: 'Reach the patient desk for appointments, emergency support, diagnostic service guidance, and visitor information.', heroImage: '/slider2.jpeg',
    body: ['Use the contact page to keep phone numbers, address information, and support notes clear for patients and visitors.', 'For urgent cases, call the emergency number or visit the nearest emergency desk immediately.'],
    highlights: ['Phone support', 'Emergency hotline', 'Email guidance', 'Location and hours'],
    cards: [{ title: 'Phone', description: '01763-555555' }, { title: 'Emergency', description: '01971-555555' }, { title: 'Email', description: 'update.diagnostic@gmail.com' }, { title: 'Address', description: 'Dhap (Opposite Police Fari), Jail Road, Rangpur, Bangladesh' }],
    primaryButtonLabel: 'Call Now', primaryButtonHref: 'tel:01763555555', secondaryButtonLabel: 'Book Appointment', secondaryButtonHref: '/appointment', seoTitle: 'Contact Update Diagnostic Center', seoDescription: 'Contact Update Diagnostic Center for appointments, reports, emergency help, and diagnostic service support.', sortOrder: 2,
  },
  {
    key: 'support', slug: 'support', eyebrow: 'Support Center', title: 'Get help from our patient support team', description: 'Find the right support channel for appointments, reports, health packages, and patient service information.', heroImage: '/slider3.jpeg',
    body: ['Our support desk helps patients understand doctor schedules, appointment requests, report access, health packages, and general service information.', 'Keep this page simple so visitors can quickly choose the right contact path.'],
    highlights: ['Appointment guidance', 'Report help', 'Package support', 'Patient desk information'],
    cards: [{ title: 'Appointment Support', description: 'Doctor schedule, booking time, and appointment guidance.' }, { title: 'Health Package Guidance', description: 'Choose the right diagnostic or health check package.' }, { title: 'Online Report Help', description: 'Reports, delivery time, and diagnostic service updates.' }, { title: 'Patient Desk', description: 'Corporate, patient desk, and service information.' }],
    primaryButtonLabel: 'Contact Support', primaryButtonHref: '/contact', secondaryButtonLabel: 'View Guide', secondaryButtonHref: '/patient-guide', seoTitle: 'Support Center - Update Diagnostic Center', seoDescription: 'Get support for appointments, online reports, health packages, and patient service guidance.', sortOrder: 3,
  },
  {
    key: 'privacy-policy', slug: 'privacy-policy', eyebrow: 'Privacy Policy', title: 'How we handle patient and visitor information', description: 'This page explains how information may be collected, used, protected, and updated through the website and service channels.', heroImage: '',
    body: ['We collect information only when it is needed to respond to inquiries, process appointment requests, provide diagnostic support, or improve the service experience.', 'Personal information should be handled carefully and accessed only by authorized team members for service-related purposes.', 'This policy text should be reviewed by the organization before production launch.'],
    highlights: ['Information collection', 'Service communication', 'Data protection', 'Policy updates'],
    cards: [{ title: 'Data Use', description: 'Information is used to support appointments, reports, inquiries, and patient communication.' }, { title: 'Protection', description: 'Access should be limited to authorized service and administration team members.' }, { title: 'Updates', description: 'Policy details can be updated from the admin panel when needed.' }],
    primaryButtonLabel: 'Contact Us', primaryButtonHref: '/contact', secondaryButtonLabel: 'Terms', secondaryButtonHref: '/terms', seoTitle: 'Privacy Policy - Update Diagnostic Center', seoDescription: 'Read the privacy policy for Update Diagnostic Center website and patient support communication.', sortOrder: 4,
  },
  {
    key: 'terms', slug: 'terms', eyebrow: 'Terms & Conditions', title: 'Website and service usage terms', description: 'This page explains general website usage, appointment request limitations, content responsibility, and service communication terms.', heroImage: '',
    body: ['Website information is provided for general service guidance and should not replace direct consultation with a qualified healthcare professional.', 'Appointment requests are subject to confirmation, doctor availability, and operational schedules.', 'Final legal wording should be reviewed by the organization before production launch.'],
    highlights: ['Website usage', 'Appointment confirmation', 'Service availability', 'Content responsibility'],
    cards: [{ title: 'Appointments', description: 'Submitting a request does not guarantee confirmation until the team verifies availability.' }, { title: 'Medical Guidance', description: 'Website content is general information and not a replacement for medical consultation.' }, { title: 'Changes', description: 'Terms can be updated as services, policies, or operations change.' }],
    primaryButtonLabel: 'Book Appointment', primaryButtonHref: '/appointment', secondaryButtonLabel: 'Privacy Policy', secondaryButtonHref: '/privacy-policy', seoTitle: 'Terms & Conditions - Update Diagnostic Center', seoDescription: 'Read the terms and conditions for using the Update Diagnostic Center website and online service channels.', sortOrder: 5,
  },
  {
    key: 'patient-guide', slug: 'patient-guide', eyebrow: 'Patient Guide', title: 'Helpful guidance before and after your visit', description: 'Use this page to explain admission, billing, reports, discharge, follow-up, and patient support steps.', heroImage: '/pasent.jpeg',
    body: ['Patients and families should receive clear information before visiting the center. Keep guidance short, direct, and easy to understand.', 'Update this page with real admission steps, document requirements, billing guidance, and support desk notes.'],
    highlights: ['Admission process', 'Billing guidance', 'Report collection', 'Follow-up instructions'],
    cards: [{ title: 'Before Visit', description: 'Bring required documents, previous reports, and appointment confirmation if available.' }, { title: 'During Visit', description: 'Follow desk guidance for registration, payment, diagnostics, and consultation flow.' }, { title: 'After Visit', description: 'Collect reports, review doctor advice, and plan follow-up if recommended.' }],
    primaryButtonLabel: 'Request Appointment', primaryButtonHref: '/appointment', secondaryButtonLabel: 'Contact Support', secondaryButtonHref: '/support', seoTitle: 'Patient Guide - Update Diagnostic Center', seoDescription: 'Patient guide for admission, billing, reports, follow-up, and support at Update Diagnostic Center.', sortOrder: 6,
  },
  {
    key: 'online-report', slug: 'online-report', eyebrow: 'Online Report', title: 'Access your diagnostic report online', description: 'Guide patients on report access, registration number usage, password help, and support communication.', heroImage: '/slider1.jpeg',
    body: ['Patients can use the report portal instructions to find their diagnostic reports when the online report system is connected.', 'Use this page to explain patient ID, mobile number, password reset, and report support steps.'],
    highlights: ['Enter patient ID', 'Use mobile number', 'Download report', 'Contact support'],
    cards: [{ title: 'Step 1', description: 'Enter UHID or registration number.' }, { title: 'Step 2', description: 'Enter mobile number or report password.' }, { title: 'Step 3', description: 'View or download the report when available.' }],
    primaryButtonLabel: 'Contact Report Desk', primaryButtonHref: '/contact', secondaryButtonLabel: 'Patient Guide', secondaryButtonHref: '/patient-guide', seoTitle: 'Online Report - Update Diagnostic Center', seoDescription: 'Access online diagnostic reports and report support guidance from Update Diagnostic Center.', sortOrder: 7,
  },
  {
    key: 'career', slug: 'career', eyebrow: 'Career', title: 'Join our healthcare team', description: 'Share recruitment messages, workplace culture, current openings, and resume submission guidance from the admin panel.', heroImage: '/career/career-hero.jpg',
    body: ['We welcome responsible, caring, and service-minded people who want to contribute to a better patient experience.', 'Update this page with real openings, HR contact details, requirements, and application instructions.'],
    highlights: ['Professional workplace', 'Patient-first culture', 'Training support', 'Growth opportunities'],
    cards: [{ title: 'Front Desk Coordinator', description: 'Support patient registration, appointment guidance, and service communication.' }, { title: 'Medical Officer', description: 'Assist clinical operations and patient care coordination.' }, { title: 'Lab Technician', description: 'Support reliable diagnostic operations and sample handling.' }, { title: 'Nurse', description: 'Provide patient support, care assistance, and clinical coordination.' }],
    primaryButtonLabel: 'Send Resume', primaryButtonHref: 'mailto:update.diagnostic@gmail.com', secondaryButtonLabel: 'Contact HR', secondaryButtonHref: '/contact', seoTitle: 'Career - Update Diagnostic Center', seoDescription: 'Explore career opportunities, openings, and HR contact guidance at Update Diagnostic Center.', sortOrder: 8,
  },
];

const PASSWORD_HASH_KEY_LENGTH = 64;
const PASSWORD_HASH_OPTIONS = {
  N: 16384,
  r: 8,
  p: 1,
  maxmem: 32 * 1024 * 1024,
};

function hashAdminPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, PASSWORD_HASH_KEY_LENGTH, PASSWORD_HASH_OPTIONS).toString('hex');

  return [
    'scrypt',
    PASSWORD_HASH_OPTIONS.N,
    PASSWORD_HASH_OPTIONS.r,
    PASSWORD_HASH_OPTIONS.p,
    salt,
    hash,
  ].join('$');
}

function isPlaceholder(value) {
  return !value || String(value).includes('CHANGE_ME') || String(value).includes('YOUR_');
}

function slugify(value) {
  return String(value || '')
    .toLowerCase()
    .trim()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || `item-${Date.now()}`;
}

function toInt(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function parsePrice(value) {
  const digits = String(value || '').replace(/[^0-9]/g, '');
  return digits ? Number(digits) : null;
}

function toDate(value) {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

async function readJson(fileName, fallback) {
  try {
    const raw = await fs.readFile(path.join(CONTENT_DIR, fileName), 'utf8');
    return JSON.parse(raw);
  } catch (error) {
    console.warn(`[seed] ${fileName} not found or invalid. Using fallback.`);
    return fallback;
  }
}

function splitTimeRange(value) {
  const text = String(value || '').trim();
  if (!text.includes('-')) return { startTime: text || 'N/A', endTime: text || 'N/A' };
  const [startTime, ...rest] = text.split('-');
  return {
    startTime: startTime.trim() || 'N/A',
    endTime: rest.join('-').trim() || 'N/A',
  };
}


async function seedAdminUser() {
  const email = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || '');
  const name = String(process.env.ADMIN_NAME || 'Super Admin').trim() || 'Super Admin';

  if (isPlaceholder(email) || isPlaceholder(password)) {
    console.log('[seed] Admin user skipped. Set ADMIN_EMAIL and ADMIN_PASSWORD to create/update DB admin.');
    return;
  }

  if (password.length < 8) {
    throw new Error('[seed] ADMIN_PASSWORD must be at least 8 characters for DB-backed admin auth.');
  }

  const passwordHash = hashAdminPassword(password);

  const admin = await prisma.adminUser.upsert({
    where: { email },
    update: {
      name,
      passwordHash,
      role: 'SUPER_ADMIN',
      isActive: true,
    },
    create: {
      name,
      email,
      passwordHash,
      role: 'SUPER_ADMIN',
      isActive: true,
    },
  });

  await prisma.adminSession.deleteMany({ where: { adminId: admin.id } });

  console.log(`[seed] Admin user seeded: ${email}`);
}

async function seedSiteSettings() {
  const now = new Date();
  const publicContent = await readJson('public-content.json', {});
  const homeHeroContent = publicContent && typeof publicContent === 'object' && publicContent.homeHero
    ? publicContent.homeHero
    : {
        welcomeText: 'Welcome to Update Diagnostic Center Rangpur.',
        heroLogoUrl: '',
        heroLogoAlt: 'Update Diagnostic Center',
        carousel: {
          autoplay: true,
          intervalMs: 5000,
          showArrows: true,
          showDots: true,
          overlayOpacity: 18,
          desktopHeight: 530,
          mobileHeight: 240,
        },
        slides: [
          { id: 'hero-1', imageUrl: '/images/hero/hero-1.jpg', imageAlt: 'Homepage hero image', isActive: true, sortOrder: 1 },
        ],
        quickActions: [
          { id: 'find-doctor', label: 'Find A Doctor', href: '/doctors', icon: 'Stethoscope', isActive: true, sortOrder: 1 },
          { id: 'appointment', label: 'Request An Appointment', href: '/appointment', icon: 'CalendarCheck', isActive: true, sortOrder: 2 },
        ],
      };

  const settings = [
    {
      key: 'site.settings',
      value: DEFAULT_SITE_SETTINGS,
    },
    {
      key: 'site.identity',
      value: {
        siteName: DEFAULT_SITE_SETTINGS.siteName,
        siteUrl: process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:4090',
        seededAt: now.toISOString(),
      },
    },
    {
      key: 'home.hero.content',
      value: homeHeroContent,
    },
    {
      key: 'home.sectionTeasers',
      value: DEFAULT_HOME_SECTION_TEASERS,
    },
    {
      key: 'devops.phase',
      value: {
        phase: '4.3',
        note: 'About page and site settings are DB-primary while frontend design remains locked through Phase 4.3.'
      },
    },
  ];

  for (const setting of settings) {
    await prisma.siteSetting.upsert({
      where: { key: setting.key },
      update: { value: setting.value },
      create: setting,
    });
  }

  console.log(`[seed] Site settings seeded: ${settings.length}`);
}

async function seedDoctors() {
  const doctors = await readJson('doctors.json', []);
  if (!Array.isArray(doctors) || doctors.length === 0) {
    console.log('[seed] No doctors found. Skipping doctors.');
    return new Set();
  }

  const doctorIds = new Set();

  for (const doctor of doctors) {
    const id = String(doctor.id || slugify(doctor.name));
    const availableDays = Array.isArray(doctor.availableDays) ? doctor.availableDays : [];
    const { startTime, endTime } = splitTimeRange(doctor.consultationTime);

    await prisma.doctor.upsert({
      where: { slug: id },
      update: {
        name: String(doctor.name || 'Unnamed Doctor'),
        designation: String(doctor.designation || ''),
        department: String(doctor.department || ''),
        specialty: String(doctor.department || ''),
        qualifications: String(doctor.specialist || ''),
        experience: doctor.experienceYears ? `${doctor.experienceYears} years` : '',
        imageUrl: String(doctor.imageUrl || ''),
        consultationFee: toInt(doctor.fee, 0),
        isActive: doctor.isActive !== false,
        sortOrder: toInt(doctor.sortOrder, 0),
      },
      create: {
        id,
        slug: id,
        name: String(doctor.name || 'Unnamed Doctor'),
        designation: String(doctor.designation || ''),
        department: String(doctor.department || ''),
        specialty: String(doctor.department || ''),
        qualifications: String(doctor.specialist || ''),
        experience: doctor.experienceYears ? `${doctor.experienceYears} years` : '',
        imageUrl: String(doctor.imageUrl || ''),
        consultationFee: toInt(doctor.fee, 0),
        isActive: doctor.isActive !== false,
        sortOrder: toInt(doctor.sortOrder, 0),
      },
    });

    await prisma.doctorSchedule.deleteMany({ where: { doctorId: id } });

    for (const [index, day] of availableDays.entries()) {
      await prisma.doctorSchedule.create({
        data: {
          doctorId: id,
          day: String(day),
          startTime,
          endTime,
          room: String(doctor.room || ''),
          sortOrder: index,
          isActive: doctor.isActive !== false,
        },
      });
    }

    doctorIds.add(id);
  }

  console.log(`[seed] Doctors seeded: ${doctorIds.size}`);
  return doctorIds;
}

async function seedAppointments(validDoctorIds) {
  const appointments = await readJson('appointments.json', []);
  if (!Array.isArray(appointments) || appointments.length === 0) {
    console.log('[seed] No appointments found. Skipping appointments.');
    return;
  }

  let count = 0;

  for (const appointment of appointments) {
    const id = String(appointment.id || appointment.token || `appointment-${count + 1}`);
    const token = String(appointment.token || id);
    const doctorId = appointment.doctorId && validDoctorIds.has(String(appointment.doctorId))
      ? String(appointment.doctorId)
      : null;
    const createdAt = toDate(appointment.submittedAt) || new Date();
    const doctorAvailableDays = Array.isArray(appointment.doctorAvailableDays)
      ? appointment.doctorAvailableDays.map(String).filter(Boolean)
      : [];
    const serviceName = String(appointment.department || appointment.doctorName || '');
    const disease = String(appointment.disease || '');

    await prisma.appointment.upsert({
      where: { id },
      update: {
        token,
        patientName: String(appointment.patientName || 'Unknown Patient'),
        patientPhone: String(appointment.phone || ''),
        patientAge: String(appointment.age || ''),
        patientGender: String(appointment.gender || ''),
        disease,
        preferredTime: String(appointment.appointmentTime || ''),
        appointmentTime: String(appointment.appointmentTime || ''),
        message: disease,
        doctorId,
        serviceName,
        doctorName: String(appointment.doctorName || ''),
        doctorDesignation: String(appointment.doctorDesignation || ''),
        specialist: String(appointment.specialist || ''),
        doctorAvailableDays,
        room: String(appointment.room || ''),
        fee: toInt(appointment.fee, 0),
      },
      create: {
        id,
        token,
        patientName: String(appointment.patientName || 'Unknown Patient'),
        patientPhone: String(appointment.phone || ''),
        patientAge: String(appointment.age || ''),
        patientGender: String(appointment.gender || ''),
        disease,
        preferredTime: String(appointment.appointmentTime || ''),
        appointmentTime: String(appointment.appointmentTime || ''),
        message: disease,
        doctorId,
        serviceName,
        doctorName: String(appointment.doctorName || ''),
        doctorDesignation: String(appointment.doctorDesignation || ''),
        specialist: String(appointment.specialist || ''),
        doctorAvailableDays,
        room: String(appointment.room || ''),
        fee: toInt(appointment.fee, 0),
        createdAt,
      },
    });

    count += 1;
  }

  console.log(`[seed] Appointments seeded: ${count}`);
}

async function seedServices() {
  const publicContent = await readJson('public-content.json', { services: [] });
  const services = Array.isArray(publicContent.services) ? publicContent.services : [];

  if (services.length === 0) {
    console.log('[seed] No services found. Skipping services.');
    return;
  }

  for (const service of services) {
    const slug = slugify(service.slug || service.title);
    const id = String(service.id || `svc-${slug}`);
    const shortDescription = String(service.shortDescription || service.description || '');
    const fullDescription = String(service.fullDescription || service.description || shortDescription);
    const featuredImage = String(service.featuredImage || service.imageUrl || '');
    const priceRange = String(service.priceRange || service.priceText || '');
    const galleryImages = Array.isArray(service.galleryImages) ? service.galleryImages : [];

    await prisma.service.upsert({
      where: { slug },
      update: {
        title: String(service.title || 'Untitled Service'),
        subtitle: String(service.subtitle || shortDescription),
        description: fullDescription,
        shortDescription,
        overview: String(service.overview || fullDescription),
        fullDescription,
        icon: String(service.icon || 'activity'),
        imageUrl: featuredImage,
        featuredImage,
        galleryImages,
        priceText: priceRange,
        priceRange,
        duration: String(service.duration || ''),
        availableTime: String(service.availableTime || ''),
        doctorName: String(service.doctorName || ''),
        doctorTitle: String(service.doctorTitle || ''),
        phone: String(service.phone || '01971-555555'),
        featured: Boolean(service.featured),
        highlights: Array.isArray(service.highlights) ? service.highlights : [],
        facilities: Array.isArray(service.facilities) ? service.facilities : [],
        symptoms: Array.isArray(service.symptoms) ? service.symptoms : [],
        seoTitle: String(service.seoTitle || service.title || 'Untitled Service'),
        seoDescription: String(service.seoDescription || shortDescription),
        status: service.active === false ? 'DRAFT' : 'PUBLISHED',
        sortOrder: toInt(service.order ?? service.sortOrder, 0),
      },
      create: {
        id,
        slug,
        title: String(service.title || 'Untitled Service'),
        subtitle: String(service.subtitle || shortDescription),
        description: fullDescription,
        shortDescription,
        overview: String(service.overview || fullDescription),
        fullDescription,
        icon: String(service.icon || 'activity'),
        imageUrl: featuredImage,
        featuredImage,
        galleryImages,
        priceText: priceRange,
        priceRange,
        duration: String(service.duration || ''),
        availableTime: String(service.availableTime || ''),
        doctorName: String(service.doctorName || ''),
        doctorTitle: String(service.doctorTitle || ''),
        phone: String(service.phone || '01971-555555'),
        featured: Boolean(service.featured),
        highlights: Array.isArray(service.highlights) ? service.highlights : [],
        facilities: Array.isArray(service.facilities) ? service.facilities : [],
        symptoms: Array.isArray(service.symptoms) ? service.symptoms : [],
        seoTitle: String(service.seoTitle || service.title || 'Untitled Service'),
        seoDescription: String(service.seoDescription || shortDescription),
        status: service.active === false ? 'DRAFT' : 'PUBLISHED',
        sortOrder: toInt(service.order ?? service.sortOrder, 0),
      },
    });
  }

  console.log(`[seed] Services seeded: ${services.length}`);
}

async function seedWhyChoose() {
  const section = await readJson('home-why-choose.json', null);
  if (!section || !section.title) {
    console.log('[seed] No why-choose section found. Skipping why-choose.');
    return;
  }

  const sectionId = 'why-choose-main';

  await prisma.whyChooseSection.upsert({
    where: { id: sectionId },
    update: {
      title: String(section.title || 'Why Choose Us'),
      description: String(section.description || ''),
      stats: {
        imageUrl: section.imageUrl || '',
        source: 'src/content/home-why-choose.json',
      },
    },
    create: {
      id: sectionId,
      title: String(section.title || 'Why Choose Us'),
      description: String(section.description || ''),
      stats: {
        imageUrl: section.imageUrl || '',
        source: 'src/content/home-why-choose.json',
      },
    },
  });

  await prisma.whyChooseSpeciality.deleteMany({ where: { sectionId } });

  const specialities = Array.isArray(section.specialities) ? section.specialities : [];

  for (const [index, item] of specialities.entries()) {
    await prisma.whyChooseSpeciality.create({
      data: {
        id: String(item.id || slugify(item.title)),
        sectionId,
        title: String(item.title || 'Untitled Speciality'),
        icon: String(item.iconName || item.icon || 'HeartPulse'),
        isActive: item.isActive !== false,
        sortOrder: toInt(item.sortOrder, index + 1),
      },
    });
  }

  console.log(`[seed] Why-choose specialities seeded: ${specialities.length}`);
}

async function seedHealthPackages() {
  const existingCount = await prisma.healthPackage.count();
  if (existingCount > 0) {
    console.log(`[seed] Health packages already exist: ${existingCount}`);
    return;
  }

  for (const [index, item] of DEFAULT_HEALTH_PACKAGES.entries()) {
    await prisma.healthPackage.create({
      data: {
        slug: slugify(item.slug || item.title),
        title: String(item.title || 'Health Package'),
        name: String(item.title || 'Health Package'),
        badge: 'HEALTH PACKAGES',
        description: 'Choose a suitable health check package for preventive care, routine screening, and better health planning.',
        subtitle: 'Choose a suitable health check package for preventive care, routine screening, and better health planning.',
        target: String(item.target || ''),
        imageUrl: String(item.image || '/slider1.jpeg'),
        price: parsePrice(item.price),
        priceText: String(item.price || ''),
        status: 'PUBLISHED',
        sortOrder: index + 1,
        tests: {
          create: item.tests.map((name, testIndex) => ({
            name: String(name),
            sortOrder: testIndex + 1,
          })),
        },
      },
    });
  }

  console.log(`[seed] Health packages seeded: ${DEFAULT_HEALTH_PACKAGES.length}`);
}


async function seedContentArticles() {
  const blogCount = await prisma.blog.count();
  if (blogCount === 0) {
    for (const [index, item] of DEFAULT_HEALTH_BLOGS.entries()) {
      await prisma.blog.create({
        data: {
          slug: slugify(item.slug || item.title),
          title: String(item.title),
          category: 'Health Blog',
          imageUrl: String(item.image || '/blogs/blog-1.jpg'),
          excerpt: String(item.excerpt || ''),
          leadText: String(item.excerpt || ''),
          body: item.body,
          content: item.body.join('\n\n'),
          status: 'PUBLISHED',
          sortOrder: index + 1,
          dateText: String(item.date || ''),
          publishedAt: toDate(item.date),
        },
      });
    }
  }

  const newsCount = await prisma.newsMedia.count();
  if (newsCount === 0) {
    for (const [index, item] of DEFAULT_NEWS_MEDIA.entries()) {
      await prisma.newsMedia.create({
        data: {
          slug: slugify(item.slug || item.title),
          title: String(item.title),
          category: 'Media Update',
          imageUrl: String(item.image || '/news/news-1.jpg'),
          excerpt: String(item.excerpt || ''),
          leadText: String(item.excerpt || ''),
          body: item.body,
          content: item.body.join('\n\n'),
          status: 'PUBLISHED',
          sortOrder: index + 1,
          dateText: String(item.date || ''),
          publishedAt: toDate(item.date),
        },
      });
    }
  }

  const articleCount = await prisma.doctorArticle.count();
  if (articleCount === 0) {
    for (const [index, item] of DEFAULT_DOCTOR_ARTICLES.entries()) {
      await prisma.doctorArticle.create({
        data: {
          slug: slugify(item.slug || item.title),
          title: String(item.title),
          category: 'Doctor Article',
          doctorName: String(item.author || ''),
          imageUrl: String(item.image || '/doctor-articles/doctor-1.jpg'),
          excerpt: String(item.excerpt || ''),
          leadText: String(item.excerpt || ''),
          body: item.body,
          content: item.body.join('\n\n'),
          status: 'PUBLISHED',
          sortOrder: index + 1,
          dateText: String(item.date || ''),
          publishedAt: toDate(item.date),
        },
      });
    }
  }

  console.log(`[seed] Content articles seeded: blogs=${await prisma.blog.count()}, news=${await prisma.newsMedia.count()}, doctorArticles=${await prisma.doctorArticle.count()}`);
}


async function seedStaticPages() {
  for (const page of DEFAULT_STATIC_PAGES) {
    await prisma.staticPage.upsert({
      where: { key: page.key },
      update: {},
      create: {
        ...page,
        status: 'PUBLISHED',
        publishedAt: new Date(),
      },
    });
  }

  console.log(`[seed] Static pages seeded: ${await prisma.staticPage.count()}`);
}

async function seedDefaults() {
  const existingHeroCount = await prisma.homeHeroSlide.count();
  if (existingHeroCount === 0) {
    await prisma.homeHeroSlide.create({
      data: {
        title: 'Update Diagnostic Center',
        subtitle: 'Reliable healthcare support in Rangpur',
        description: 'Modern diagnostics, experienced doctors, and patient-focused service.',
        imageUrl: '/slider1.jpeg',
        ctaLabel: 'Book Appointment',
        ctaHref: '/appointment',
        sortOrder: 1,
      },
    });
    console.log('[seed] Default home hero slide seeded: 1');
  }
}

async function main() {
  console.log('[seed] Starting Update Clinic database seed...');

  await seedAdminUser();
  await seedSiteSettings();
  const doctorIds = await seedDoctors();
  await seedAppointments(doctorIds);
  await seedServices();
  await seedHealthPackages();
  await seedContentArticles();
  await seedWhyChoose();
  await seedStaticPages();
  await seedDefaults();

  const counts = {
    admins: await prisma.adminUser.count(),
    doctors: await prisma.doctor.count(),
    appointments: await prisma.appointment.count(),
    services: await prisma.service.count(),
    healthPackages: await prisma.healthPackage.count(),
    packageBookings: await prisma.packageBooking.count(),
    blogs: await prisma.blog.count(),
    newsMedia: await prisma.newsMedia.count(),
    doctorArticles: await prisma.doctorArticle.count(),
    whyChooseSections: await prisma.whyChooseSection.count(),
    siteSettings: await prisma.siteSetting.count(),
    staticPages: await prisma.staticPage.count(),
  };

  console.log('[seed] Complete:', counts);
}

main()
  .catch((error) => {
    console.error('[seed:ERROR]', error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
