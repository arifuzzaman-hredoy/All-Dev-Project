-- Phase 3.7: Homepage sections final DB cleanup.
-- Safe for local Neon dev DB that was previously synced with `prisma db push`.

ALTER TABLE "WhyChooseSpeciality"
ADD COLUMN IF NOT EXISTS "isActive" BOOLEAN NOT NULL DEFAULT true;

CREATE INDEX IF NOT EXISTS "WhyChooseSpeciality_isActive_idx" ON "WhyChooseSpeciality"("isActive");

-- Home hero content and quick actions are stored as full JSON in SiteSetting
-- under key `home.hero.content` to preserve every existing UI field.
