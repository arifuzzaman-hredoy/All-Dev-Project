-- Phase 3.5: Blogs + news/media + doctor articles database-backed CMS fields.
-- These are additive and safe for existing development databases already synced with prisma db push.

ALTER TABLE "Blog" ADD COLUMN IF NOT EXISTS "category" TEXT DEFAULT 'Health Blog';
ALTER TABLE "Blog" ADD COLUMN IF NOT EXISTS "leadText" TEXT;
ALTER TABLE "Blog" ADD COLUMN IF NOT EXISTS "body" JSONB;
ALTER TABLE "Blog" ADD COLUMN IF NOT EXISTS "sortOrder" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "Blog" ADD COLUMN IF NOT EXISTS "dateText" TEXT;

UPDATE "Blog"
SET
  "category" = COALESCE("category", 'Health Blog'),
  "leadText" = COALESCE("leadText", "excerpt"),
  "dateText" = COALESCE("dateText", CASE WHEN "publishedAt" IS NULL THEN NULL ELSE to_char("publishedAt", 'YYYY-MM-DD') END),
  "body" = COALESCE("body", to_jsonb(ARRAY[COALESCE("content", "excerpt", '')]::text[]))
WHERE true;

ALTER TABLE "NewsMedia" ADD COLUMN IF NOT EXISTS "category" TEXT DEFAULT 'Media Update';
ALTER TABLE "NewsMedia" ADD COLUMN IF NOT EXISTS "leadText" TEXT;
ALTER TABLE "NewsMedia" ADD COLUMN IF NOT EXISTS "body" JSONB;
ALTER TABLE "NewsMedia" ADD COLUMN IF NOT EXISTS "sortOrder" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "NewsMedia" ADD COLUMN IF NOT EXISTS "dateText" TEXT;

UPDATE "NewsMedia"
SET
  "category" = COALESCE("category", 'Media Update'),
  "leadText" = COALESCE("leadText", "excerpt"),
  "dateText" = COALESCE("dateText", CASE WHEN "publishedAt" IS NULL THEN NULL ELSE to_char("publishedAt", 'YYYY-MM-DD') END),
  "body" = COALESCE("body", to_jsonb(ARRAY[COALESCE("content", "excerpt", '')]::text[]))
WHERE true;

ALTER TABLE "DoctorArticle" ADD COLUMN IF NOT EXISTS "category" TEXT DEFAULT 'Doctor Article';
ALTER TABLE "DoctorArticle" ADD COLUMN IF NOT EXISTS "leadText" TEXT;
ALTER TABLE "DoctorArticle" ADD COLUMN IF NOT EXISTS "body" JSONB;
ALTER TABLE "DoctorArticle" ADD COLUMN IF NOT EXISTS "sortOrder" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "DoctorArticle" ADD COLUMN IF NOT EXISTS "dateText" TEXT;

UPDATE "DoctorArticle"
SET
  "category" = COALESCE("category", 'Doctor Article'),
  "leadText" = COALESCE("leadText", "excerpt"),
  "dateText" = COALESCE("dateText", CASE WHEN "publishedAt" IS NULL THEN NULL ELSE to_char("publishedAt", 'YYYY-MM-DD') END),
  "body" = COALESCE("body", to_jsonb(ARRAY[COALESCE("content", "excerpt", '')]::text[]))
WHERE true;

CREATE INDEX IF NOT EXISTS "Blog_sortOrder_idx" ON "Blog"("sortOrder");
CREATE INDEX IF NOT EXISTS "NewsMedia_sortOrder_idx" ON "NewsMedia"("sortOrder");
CREATE INDEX IF NOT EXISTS "DoctorArticle_sortOrder_idx" ON "DoctorArticle"("sortOrder");
