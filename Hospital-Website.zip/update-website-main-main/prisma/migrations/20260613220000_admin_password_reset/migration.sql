-- Phase 8.1: Real admin forgot-password reset token storage.
CREATE TABLE "AdminPasswordResetToken" (
    "id" TEXT NOT NULL,
    "adminId" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "codeHash" TEXT NOT NULL,
    "resetTokenHash" TEXT,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "verifiedAt" TIMESTAMP(3),
    "usedAt" TIMESTAMP(3),
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "requestIp" TEXT,
    "userAgent" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdminPasswordResetToken_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "AdminPasswordResetToken_adminId_idx" ON "AdminPasswordResetToken"("adminId");
CREATE INDEX "AdminPasswordResetToken_email_idx" ON "AdminPasswordResetToken"("email");
CREATE INDEX "AdminPasswordResetToken_expiresAt_idx" ON "AdminPasswordResetToken"("expiresAt");
CREATE INDEX "AdminPasswordResetToken_resetTokenHash_idx" ON "AdminPasswordResetToken"("resetTokenHash");
CREATE INDEX "AdminPasswordResetToken_createdAt_idx" ON "AdminPasswordResetToken"("createdAt");

ALTER TABLE "AdminPasswordResetToken"
ADD CONSTRAINT "AdminPasswordResetToken_adminId_fkey"
FOREIGN KEY ("adminId") REFERENCES "AdminUser"("id") ON DELETE CASCADE ON UPDATE CASCADE;
