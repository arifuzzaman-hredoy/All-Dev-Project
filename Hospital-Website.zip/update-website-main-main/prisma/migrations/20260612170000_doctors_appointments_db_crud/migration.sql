-- Phase 3.2: Preserve the public appointment form snapshot fields in PostgreSQL.
-- Existing Phase 2 rows stay valid because every added Appointment column is nullable.

ALTER TABLE "DoctorSchedule" ADD COLUMN IF NOT EXISTS "sortOrder" INTEGER NOT NULL DEFAULT 0;

ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "token" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "patientGender" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "disease" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "appointmentTime" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "doctorName" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "doctorDesignation" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "specialist" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "doctorAvailableDays" JSONB;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "room" TEXT;
ALTER TABLE "Appointment" ADD COLUMN IF NOT EXISTS "fee" INTEGER;

UPDATE "Appointment"
SET "token" = COALESCE("token", "id")
WHERE "token" IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS "Appointment_token_key" ON "Appointment"("token");
