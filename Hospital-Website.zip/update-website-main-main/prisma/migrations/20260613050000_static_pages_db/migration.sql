-- Phase 4.1: Static public pages DB-backed CMS.
-- Safe additive migration for fresh VPS migration flow and existing Neon dev DB.

CREATE TABLE IF NOT EXISTS "StaticPage" (
  "id" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "eyebrow" TEXT,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "heroImage" TEXT,
  "body" JSONB,
  "highlights" JSONB,
  "cards" JSONB,
  "primaryButtonLabel" TEXT,
  "primaryButtonHref" TEXT,
  "secondaryButtonLabel" TEXT,
  "secondaryButtonHref" TEXT,
  "seoTitle" TEXT,
  "seoDescription" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'PUBLISHED',
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "publishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "StaticPage_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "StaticPage_key_key" ON "StaticPage"("key");
CREATE UNIQUE INDEX IF NOT EXISTS "StaticPage_slug_key" ON "StaticPage"("slug");
CREATE INDEX IF NOT EXISTS "StaticPage_status_idx" ON "StaticPage"("status");
CREATE INDEX IF NOT EXISTS "StaticPage_sortOrder_idx" ON "StaticPage"("sortOrder");
