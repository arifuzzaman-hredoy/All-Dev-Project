-- Phase 3.4: Health packages + package bookings database-backed CMS fields.

ALTER TABLE "HealthPackage" ADD COLUMN IF NOT EXISTS "name" TEXT;
ALTER TABLE "HealthPackage" ADD COLUMN IF NOT EXISTS "badge" TEXT DEFAULT 'HEALTH PACKAGES';
ALTER TABLE "HealthPackage" ADD COLUMN IF NOT EXISTS "subtitle" TEXT;
ALTER TABLE "HealthPackage" ADD COLUMN IF NOT EXISTS "target" TEXT;
ALTER TABLE "HealthPackage" ADD COLUMN IF NOT EXISTS "priceText" TEXT;

ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "token" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "receiptNo" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "packageSlug" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "packageTarget" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "packageFee" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "age" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "gender" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "diseaseProblem" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "address" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "paymentMethod" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "paymentNumber" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "transactionId" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "amountPaid" TEXT;
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "paymentStatus" TEXT DEFAULT 'Payment Submitted';
ALTER TABLE "PackageBooking" ADD COLUMN IF NOT EXISTS "requestNote" TEXT;

UPDATE "HealthPackage"
SET
  "name" = COALESCE("name", "title"),
  "badge" = COALESCE("badge", 'HEALTH PACKAGES'),
  "priceText" = COALESCE("priceText", CASE WHEN "price" IS NULL THEN NULL ELSE "price"::TEXT END);

UPDATE "PackageBooking"
SET
  "paymentStatus" = COALESCE("paymentStatus", 'Payment Submitted'),
  "packageFee" = COALESCE("packageFee", CASE WHEN "packageName" IS NULL THEN NULL ELSE '' END);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'PackageBooking_token_key'
  ) THEN
    CREATE UNIQUE INDEX "PackageBooking_token_key" ON "PackageBooking"("token") WHERE "token" IS NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'PackageBooking_receiptNo_key'
  ) THEN
    CREATE UNIQUE INDEX "PackageBooking_receiptNo_key" ON "PackageBooking"("receiptNo") WHERE "receiptNo" IS NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'PackageBooking_packageSlug_idx'
  ) THEN
    CREATE INDEX "PackageBooking_packageSlug_idx" ON "PackageBooking"("packageSlug");
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'PackageBooking_paymentStatus_idx'
  ) THEN
    CREATE INDEX "PackageBooking_paymentStatus_idx" ON "PackageBooking"("paymentStatus");
  END IF;
END $$;
