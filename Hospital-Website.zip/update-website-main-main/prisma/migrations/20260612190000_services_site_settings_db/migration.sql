-- Phase 3.3: Services + site settings database-backed support.
-- Add richer service CMS fields without dropping existing data.

ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "shortDescription" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "overview" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "fullDescription" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "featuredImage" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "galleryImages" JSONB;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "priceRange" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "duration" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "availableTime" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "doctorName" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "doctorTitle" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "phone" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "featured" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "highlights" JSONB;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "facilities" JSONB;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "symptoms" JSONB;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "seoTitle" TEXT;
ALTER TABLE "Service" ADD COLUMN IF NOT EXISTS "seoDescription" TEXT;

UPDATE "Service"
SET
  "shortDescription" = COALESCE("shortDescription", "description", "subtitle"),
  "overview" = COALESCE("overview", "description"),
  "fullDescription" = COALESCE("fullDescription", "description"),
  "featuredImage" = COALESCE("featuredImage", "imageUrl"),
  "priceRange" = COALESCE("priceRange", "priceText"),
  "seoTitle" = COALESCE("seoTitle", "title"),
  "seoDescription" = COALESCE("seoDescription", "description", "subtitle")
WHERE true;
