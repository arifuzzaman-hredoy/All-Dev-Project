-- CreateEnum
CREATE TYPE "FormSubmissionType" AS ENUM ('APPOINTMENT', 'CONTACT', 'CAREER', 'PACKAGE_BOOKING', 'SUPPORT', 'ONLINE_REPORT', 'HEALTH_PACKAGE', 'OTHER');

-- CreateEnum
CREATE TYPE "FormSubmissionStatus" AS ENUM ('NEW', 'READ', 'IN_PROGRESS', 'RESOLVED', 'ARCHIVED', 'SPAM');

-- CreateEnum
CREATE TYPE "SubmissionSource" AS ENUM ('PUBLIC_FORM', 'ADMIN_MANUAL', 'PHONE_CALL', 'IMPORTED', 'SYSTEM');

-- CreateEnum
CREATE TYPE "SmsDeliveryStatus" AS ENUM ('PENDING', 'SENT', 'FAILED', 'DISABLED', 'SKIPPED');

-- CreateEnum
CREATE TYPE "SmsLogStatus" AS ENUM ('PENDING', 'SENT', 'FAILED', 'DISABLED', 'SKIPPED');

-- CreateEnum
CREATE TYPE "ExportEntityType" AS ENUM ('APPOINTMENTS', 'FORM_SUBMISSIONS', 'SMS_LOGS', 'PACKAGE_BOOKINGS');

-- CreateEnum
CREATE TYPE "ExportFormat" AS ENUM ('CSV', 'XLSX', 'PDF', 'HTML', 'PRINT');

-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN     "lastSmsAt" TIMESTAMP(3),
ADD COLUMN     "smsError" TEXT,
ADD COLUMN     "smsStatus" "SmsDeliveryStatus" NOT NULL DEFAULT 'PENDING',
ADD COLUMN     "smsTemplateKey" TEXT,
ADD COLUMN     "source" "SubmissionSource" NOT NULL DEFAULT 'PUBLIC_FORM';

-- AlterTable
ALTER TABLE "PackageBooking" ADD COLUMN     "lastSmsAt" TIMESTAMP(3),
ADD COLUMN     "smsError" TEXT,
ADD COLUMN     "smsStatus" "SmsDeliveryStatus" NOT NULL DEFAULT 'PENDING',
ADD COLUMN     "smsTemplateKey" TEXT,
ADD COLUMN     "source" "SubmissionSource" NOT NULL DEFAULT 'PUBLIC_FORM';

-- AlterTable
ALTER TABLE "StaticPage" ALTER COLUMN "updatedAt" DROP DEFAULT;

-- CreateTable
CREATE TABLE "FormSubmission" (
    "id" TEXT NOT NULL,
    "formType" "FormSubmissionType" NOT NULL,
    "name" TEXT,
    "phone" TEXT,
    "email" TEXT,
    "subject" TEXT,
    "message" TEXT,
    "payload" JSONB NOT NULL,
    "status" "FormSubmissionStatus" NOT NULL DEFAULT 'NEW',
    "source" "SubmissionSource" NOT NULL DEFAULT 'PUBLIC_FORM',
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FormSubmission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SmsTemplate" (
    "id" TEXT NOT NULL,
    "templateKey" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "variables" JSONB,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SmsTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SmsLog" (
    "id" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "provider" TEXT NOT NULL DEFAULT 'mock',
    "status" "SmsLogStatus" NOT NULL DEFAULT 'PENDING',
    "templateKey" TEXT,
    "relatedFormType" TEXT,
    "relatedRecordId" TEXT,
    "retryCount" INTEGER NOT NULL DEFAULT 0,
    "providerMessageId" TEXT,
    "providerResponse" JSONB,
    "errorMessage" TEXT,
    "sentAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SmsLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExportAudit" (
    "id" TEXT NOT NULL,
    "adminId" TEXT,
    "adminEmail" TEXT,
    "entityType" "ExportEntityType" NOT NULL,
    "format" "ExportFormat" NOT NULL,
    "filters" JSONB,
    "totalRows" INTEGER NOT NULL DEFAULT 0,
    "fileName" TEXT,
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ExportAudit_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "FormSubmission_formType_idx" ON "FormSubmission"("formType");

-- CreateIndex
CREATE INDEX "FormSubmission_status_idx" ON "FormSubmission"("status");

-- CreateIndex
CREATE INDEX "FormSubmission_phone_idx" ON "FormSubmission"("phone");

-- CreateIndex
CREATE INDEX "FormSubmission_email_idx" ON "FormSubmission"("email");

-- CreateIndex
CREATE INDEX "FormSubmission_createdAt_idx" ON "FormSubmission"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "SmsTemplate_templateKey_key" ON "SmsTemplate"("templateKey");

-- CreateIndex
CREATE INDEX "SmsTemplate_isActive_idx" ON "SmsTemplate"("isActive");

-- CreateIndex
CREATE INDEX "SmsTemplate_sortOrder_idx" ON "SmsTemplate"("sortOrder");

-- CreateIndex
CREATE INDEX "SmsLog_status_idx" ON "SmsLog"("status");

-- CreateIndex
CREATE INDEX "SmsLog_phone_idx" ON "SmsLog"("phone");

-- CreateIndex
CREATE INDEX "SmsLog_templateKey_idx" ON "SmsLog"("templateKey");

-- CreateIndex
CREATE INDEX "SmsLog_relatedFormType_relatedRecordId_idx" ON "SmsLog"("relatedFormType", "relatedRecordId");

-- CreateIndex
CREATE INDEX "SmsLog_createdAt_idx" ON "SmsLog"("createdAt");

-- CreateIndex
CREATE INDEX "ExportAudit_adminId_idx" ON "ExportAudit"("adminId");

-- CreateIndex
CREATE INDEX "ExportAudit_adminEmail_idx" ON "ExportAudit"("adminEmail");

-- CreateIndex
CREATE INDEX "ExportAudit_entityType_idx" ON "ExportAudit"("entityType");

-- CreateIndex
CREATE INDEX "ExportAudit_format_idx" ON "ExportAudit"("format");

-- CreateIndex
CREATE INDEX "ExportAudit_createdAt_idx" ON "ExportAudit"("createdAt");
