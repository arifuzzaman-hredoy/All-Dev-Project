-- Phase 3 final baseline migration for Update Clinic.
-- This migration creates the complete PostgreSQL schema needed by the current Prisma models.
-- It is intentionally safe for a fresh VPS PostgreSQL database.

DO $$ BEGIN
  CREATE TYPE "AdminRole" AS ENUM ('SUPER_ADMIN', 'ADMIN', 'EDITOR');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "PublishStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "AppointmentStatus" AS ENUM ('NEW', 'CONFIRMED', 'COMPLETED', 'CANCELLED');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "PackageBookingStatus" AS ENUM ('NEW', 'CONTACTED', 'CONFIRMED', 'COMPLETED', 'CANCELLED');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

CREATE TABLE IF NOT EXISTS "AdminUser" (
  "id" TEXT NOT NULL,
  "name" TEXT,
  "email" TEXT NOT NULL,
  "passwordHash" TEXT NOT NULL,
  "role" "AdminRole" NOT NULL DEFAULT 'ADMIN',
  "isActive" BOOLEAN NOT NULL DEFAULT true,
  "lastLoginAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "AdminUser_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "AdminSession" (
  "id" TEXT NOT NULL,
  "tokenHash" TEXT NOT NULL,
  "adminId" TEXT NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AdminSession_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "AuditLog" (
  "id" TEXT NOT NULL,
  "adminId" TEXT,
  "action" TEXT NOT NULL,
  "entity" TEXT NOT NULL,
  "entityId" TEXT,
  "metadata" JSONB,
  "ipAddress" TEXT,
  "userAgent" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "MediaAsset" (
  "id" TEXT NOT NULL,
  "fileName" TEXT NOT NULL,
  "mimeType" TEXT NOT NULL,
  "size" INTEGER NOT NULL,
  "url" TEXT NOT NULL,
  "altText" TEXT,
  "folder" TEXT DEFAULT 'cms',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "MediaAsset_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "SiteSetting" (
  "id" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "value" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "SiteSetting_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Doctor" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "designation" TEXT,
  "department" TEXT,
  "specialty" TEXT,
  "qualifications" TEXT,
  "experience" TEXT,
  "bio" TEXT,
  "imageUrl" TEXT,
  "phone" TEXT,
  "email" TEXT,
  "consultationFee" INTEGER,
  "isFeatured" BOOLEAN NOT NULL DEFAULT false,
  "isActive" BOOLEAN NOT NULL DEFAULT true,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Doctor_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "DoctorSchedule" (
  "id" TEXT NOT NULL,
  "doctorId" TEXT NOT NULL,
  "day" TEXT NOT NULL,
  "startTime" TEXT NOT NULL,
  "endTime" TEXT NOT NULL,
  "room" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "isActive" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DoctorSchedule_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Appointment" (
  "id" TEXT NOT NULL,
  "token" TEXT,
  "patientName" TEXT NOT NULL,
  "patientPhone" TEXT NOT NULL,
  "patientEmail" TEXT,
  "patientAge" TEXT,
  "patientGender" TEXT,
  "disease" TEXT,
  "preferredDate" TIMESTAMP(3),
  "preferredTime" TEXT,
  "appointmentTime" TEXT,
  "message" TEXT,
  "doctorId" TEXT,
  "serviceName" TEXT,
  "doctorName" TEXT,
  "doctorDesignation" TEXT,
  "specialist" TEXT,
  "doctorAvailableDays" JSONB,
  "room" TEXT,
  "fee" INTEGER,
  "status" "AppointmentStatus" NOT NULL DEFAULT 'NEW',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Appointment_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Service" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "subtitle" TEXT,
  "description" TEXT,
  "shortDescription" TEXT,
  "overview" TEXT,
  "fullDescription" TEXT,
  "icon" TEXT,
  "imageUrl" TEXT,
  "featuredImage" TEXT,
  "galleryImages" JSONB,
  "priceText" TEXT,
  "priceRange" TEXT,
  "duration" TEXT,
  "availableTime" TEXT,
  "doctorName" TEXT,
  "doctorTitle" TEXT,
  "phone" TEXT,
  "featured" BOOLEAN NOT NULL DEFAULT false,
  "highlights" JSONB,
  "facilities" JSONB,
  "symptoms" JSONB,
  "seoTitle" TEXT,
  "seoDescription" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'PUBLISHED',
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Service_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "ServiceFeature" (
  "id" TEXT NOT NULL,
  "serviceId" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "text" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "ServiceFeature_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "ServiceFaq" (
  "id" TEXT NOT NULL,
  "serviceId" TEXT NOT NULL,
  "question" TEXT NOT NULL,
  "answer" TEXT NOT NULL,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "ServiceFaq_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Speciality" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "shortDescription" TEXT,
  "detailTitle" TEXT,
  "detailDescription" TEXT,
  "icon" TEXT,
  "imageUrl" TEXT,
  "services" JSONB,
  "doctorsData" JSONB,
  "featured" BOOLEAN NOT NULL DEFAULT false,
  "showInMenu" BOOLEAN NOT NULL DEFAULT true,
  "status" "PublishStatus" NOT NULL DEFAULT 'PUBLISHED',
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Speciality_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "DoctorSpeciality" (
  "doctorId" TEXT NOT NULL,
  "specialityId" TEXT NOT NULL,
  CONSTRAINT "DoctorSpeciality_pkey" PRIMARY KEY ("doctorId", "specialityId")
);

CREATE TABLE IF NOT EXISTS "HealthPackage" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "name" TEXT,
  "badge" TEXT DEFAULT 'HEALTH PACKAGES',
  "description" TEXT,
  "subtitle" TEXT,
  "target" TEXT,
  "imageUrl" TEXT,
  "price" INTEGER,
  "priceText" TEXT,
  "oldPrice" INTEGER,
  "status" "PublishStatus" NOT NULL DEFAULT 'PUBLISHED',
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "HealthPackage_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "HealthPackageTest" (
  "id" TEXT NOT NULL,
  "packageId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "HealthPackageTest_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "PackageBooking" (
  "id" TEXT NOT NULL,
  "token" TEXT,
  "receiptNo" TEXT,
  "packageId" TEXT,
  "packageSlug" TEXT,
  "packageName" TEXT,
  "packageTarget" TEXT,
  "packageFee" TEXT,
  "patientName" TEXT NOT NULL,
  "phone" TEXT NOT NULL,
  "age" TEXT,
  "gender" TEXT,
  "diseaseProblem" TEXT,
  "address" TEXT,
  "email" TEXT,
  "paymentMethod" TEXT,
  "paymentNumber" TEXT,
  "transactionId" TEXT,
  "amountPaid" TEXT,
  "paymentStatus" TEXT DEFAULT 'Payment Submitted',
  "requestNote" TEXT,
  "preferredDate" TIMESTAMP(3),
  "message" TEXT,
  "status" "PackageBookingStatus" NOT NULL DEFAULT 'NEW',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PackageBooking_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "Blog" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "category" TEXT DEFAULT 'Health Blog',
  "excerpt" TEXT,
  "leadText" TEXT,
  "content" TEXT,
  "body" JSONB,
  "imageUrl" TEXT,
  "authorName" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "dateText" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'DRAFT',
  "publishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Blog_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "DoctorArticle" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "category" TEXT DEFAULT 'Doctor Article',
  "excerpt" TEXT,
  "leadText" TEXT,
  "content" TEXT,
  "body" JSONB,
  "imageUrl" TEXT,
  "doctorName" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "dateText" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'DRAFT',
  "publishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DoctorArticle_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "NewsMedia" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "category" TEXT DEFAULT 'Media Update',
  "excerpt" TEXT,
  "leadText" TEXT,
  "content" TEXT,
  "body" JSONB,
  "imageUrl" TEXT,
  "sourceName" TEXT,
  "sourceUrl" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "dateText" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'DRAFT',
  "publishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "NewsMedia_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "PatientStory" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "patientName" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "story" TEXT,
  "excerpt" TEXT,
  "leadText" TEXT,
  "body" JSONB,
  "imageUrl" TEXT,
  "rating" INTEGER,
  "dateText" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "status" "PublishStatus" NOT NULL DEFAULT 'DRAFT',
  "publishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PatientStory_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "HomeHeroSlide" (
  "id" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "subtitle" TEXT,
  "description" TEXT,
  "imageUrl" TEXT,
  "ctaLabel" TEXT,
  "ctaHref" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'PUBLISHED',
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "HomeHeroSlide_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "HomeQuickAction" (
  "id" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "text" TEXT,
  "icon" TEXT,
  "href" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'PUBLISHED',
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "HomeQuickAction_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "WhyChooseSection" (
  "id" TEXT NOT NULL,
  "eyebrow" TEXT,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "stats" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "WhyChooseSection_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "WhyChooseSpeciality" (
  "id" TEXT NOT NULL,
  "sectionId" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "icon" TEXT,
  "isActive" BOOLEAN NOT NULL DEFAULT true,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "WhyChooseSpeciality_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "CorporateService" (
  "id" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "imageUrl" TEXT,
  "status" "PublishStatus" NOT NULL DEFAULT 'PUBLISHED',
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CorporateService_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "CorporateLogo" (
  "id" TEXT NOT NULL,
  "serviceId" TEXT,
  "name" TEXT NOT NULL,
  "imageUrl" TEXT,
  "href" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "CorporateLogo_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "AdminUser_email_key" ON "AdminUser"("email");
CREATE UNIQUE INDEX IF NOT EXISTS "AdminSession_tokenHash_key" ON "AdminSession"("tokenHash");
CREATE INDEX IF NOT EXISTS "AdminSession_adminId_idx" ON "AdminSession"("adminId");
CREATE INDEX IF NOT EXISTS "AdminSession_expiresAt_idx" ON "AdminSession"("expiresAt");
CREATE INDEX IF NOT EXISTS "AuditLog_adminId_idx" ON "AuditLog"("adminId");
CREATE INDEX IF NOT EXISTS "AuditLog_entity_entityId_idx" ON "AuditLog"("entity", "entityId");
CREATE INDEX IF NOT EXISTS "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");
CREATE INDEX IF NOT EXISTS "MediaAsset_folder_idx" ON "MediaAsset"("folder");
CREATE INDEX IF NOT EXISTS "MediaAsset_createdAt_idx" ON "MediaAsset"("createdAt");
CREATE UNIQUE INDEX IF NOT EXISTS "SiteSetting_key_key" ON "SiteSetting"("key");
CREATE UNIQUE INDEX IF NOT EXISTS "Doctor_slug_key" ON "Doctor"("slug");
CREATE INDEX IF NOT EXISTS "DoctorSchedule_doctorId_idx" ON "DoctorSchedule"("doctorId");
CREATE UNIQUE INDEX IF NOT EXISTS "Appointment_token_key" ON "Appointment"("token");
CREATE INDEX IF NOT EXISTS "Appointment_doctorId_idx" ON "Appointment"("doctorId");
CREATE INDEX IF NOT EXISTS "Appointment_status_idx" ON "Appointment"("status");
CREATE INDEX IF NOT EXISTS "Appointment_createdAt_idx" ON "Appointment"("createdAt");
CREATE UNIQUE INDEX IF NOT EXISTS "Service_slug_key" ON "Service"("slug");
CREATE INDEX IF NOT EXISTS "ServiceFeature_serviceId_idx" ON "ServiceFeature"("serviceId");
CREATE INDEX IF NOT EXISTS "ServiceFaq_serviceId_idx" ON "ServiceFaq"("serviceId");
CREATE UNIQUE INDEX IF NOT EXISTS "Speciality_slug_key" ON "Speciality"("slug");
CREATE INDEX IF NOT EXISTS "Speciality_status_idx" ON "Speciality"("status");
CREATE INDEX IF NOT EXISTS "Speciality_sortOrder_idx" ON "Speciality"("sortOrder");
CREATE UNIQUE INDEX IF NOT EXISTS "HealthPackage_slug_key" ON "HealthPackage"("slug");
CREATE INDEX IF NOT EXISTS "HealthPackageTest_packageId_idx" ON "HealthPackageTest"("packageId");
CREATE UNIQUE INDEX IF NOT EXISTS "PackageBooking_token_key" ON "PackageBooking"("token");
CREATE UNIQUE INDEX IF NOT EXISTS "PackageBooking_receiptNo_key" ON "PackageBooking"("receiptNo");
CREATE INDEX IF NOT EXISTS "PackageBooking_packageId_idx" ON "PackageBooking"("packageId");
CREATE INDEX IF NOT EXISTS "PackageBooking_packageSlug_idx" ON "PackageBooking"("packageSlug");
CREATE INDEX IF NOT EXISTS "PackageBooking_status_idx" ON "PackageBooking"("status");
CREATE INDEX IF NOT EXISTS "PackageBooking_paymentStatus_idx" ON "PackageBooking"("paymentStatus");
CREATE INDEX IF NOT EXISTS "PackageBooking_createdAt_idx" ON "PackageBooking"("createdAt");
CREATE UNIQUE INDEX IF NOT EXISTS "Blog_slug_key" ON "Blog"("slug");
CREATE INDEX IF NOT EXISTS "Blog_status_idx" ON "Blog"("status");
CREATE INDEX IF NOT EXISTS "Blog_publishedAt_idx" ON "Blog"("publishedAt");
CREATE INDEX IF NOT EXISTS "Blog_sortOrder_idx" ON "Blog"("sortOrder");
CREATE UNIQUE INDEX IF NOT EXISTS "DoctorArticle_slug_key" ON "DoctorArticle"("slug");
CREATE INDEX IF NOT EXISTS "DoctorArticle_status_idx" ON "DoctorArticle"("status");
CREATE INDEX IF NOT EXISTS "DoctorArticle_publishedAt_idx" ON "DoctorArticle"("publishedAt");
CREATE INDEX IF NOT EXISTS "DoctorArticle_sortOrder_idx" ON "DoctorArticle"("sortOrder");
CREATE UNIQUE INDEX IF NOT EXISTS "NewsMedia_slug_key" ON "NewsMedia"("slug");
CREATE INDEX IF NOT EXISTS "NewsMedia_status_idx" ON "NewsMedia"("status");
CREATE INDEX IF NOT EXISTS "NewsMedia_publishedAt_idx" ON "NewsMedia"("publishedAt");
CREATE INDEX IF NOT EXISTS "NewsMedia_sortOrder_idx" ON "NewsMedia"("sortOrder");
CREATE UNIQUE INDEX IF NOT EXISTS "PatientStory_slug_key" ON "PatientStory"("slug");
CREATE INDEX IF NOT EXISTS "PatientStory_status_idx" ON "PatientStory"("status");
CREATE INDEX IF NOT EXISTS "PatientStory_publishedAt_idx" ON "PatientStory"("publishedAt");
CREATE INDEX IF NOT EXISTS "PatientStory_sortOrder_idx" ON "PatientStory"("sortOrder");
CREATE INDEX IF NOT EXISTS "HomeHeroSlide_status_idx" ON "HomeHeroSlide"("status");
CREATE INDEX IF NOT EXISTS "HomeHeroSlide_sortOrder_idx" ON "HomeHeroSlide"("sortOrder");
CREATE INDEX IF NOT EXISTS "HomeQuickAction_status_idx" ON "HomeQuickAction"("status");
CREATE INDEX IF NOT EXISTS "HomeQuickAction_sortOrder_idx" ON "HomeQuickAction"("sortOrder");
CREATE INDEX IF NOT EXISTS "WhyChooseSpeciality_sectionId_idx" ON "WhyChooseSpeciality"("sectionId");
CREATE INDEX IF NOT EXISTS "WhyChooseSpeciality_isActive_idx" ON "WhyChooseSpeciality"("isActive");
CREATE UNIQUE INDEX IF NOT EXISTS "CorporateService_slug_key" ON "CorporateService"("slug");
CREATE INDEX IF NOT EXISTS "CorporateService_status_idx" ON "CorporateService"("status");
CREATE INDEX IF NOT EXISTS "CorporateService_sortOrder_idx" ON "CorporateService"("sortOrder");
CREATE INDEX IF NOT EXISTS "CorporateLogo_serviceId_idx" ON "CorporateLogo"("serviceId");

DO $$ BEGIN
  ALTER TABLE "AdminSession" ADD CONSTRAINT "AdminSession_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "AdminUser"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "AdminUser"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "DoctorSchedule" ADD CONSTRAINT "DoctorSchedule_doctorId_fkey" FOREIGN KEY ("doctorId") REFERENCES "Doctor"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "Appointment" ADD CONSTRAINT "Appointment_doctorId_fkey" FOREIGN KEY ("doctorId") REFERENCES "Doctor"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "ServiceFeature" ADD CONSTRAINT "ServiceFeature_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "ServiceFaq" ADD CONSTRAINT "ServiceFaq_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "DoctorSpeciality" ADD CONSTRAINT "DoctorSpeciality_doctorId_fkey" FOREIGN KEY ("doctorId") REFERENCES "Doctor"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "DoctorSpeciality" ADD CONSTRAINT "DoctorSpeciality_specialityId_fkey" FOREIGN KEY ("specialityId") REFERENCES "Speciality"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "HealthPackageTest" ADD CONSTRAINT "HealthPackageTest_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES "HealthPackage"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "PackageBooking" ADD CONSTRAINT "PackageBooking_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES "HealthPackage"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "WhyChooseSpeciality" ADD CONSTRAINT "WhyChooseSpeciality_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "WhyChooseSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  ALTER TABLE "CorporateLogo" ADD CONSTRAINT "CorporateLogo_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "CorporateService"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;
