-- Phase 3.6: Patient Stories + Specialities + Corporate Services DB-backed fields

ALTER TABLE "PatientStory" ADD COLUMN IF NOT EXISTS "excerpt" TEXT;
ALTER TABLE "PatientStory" ADD COLUMN IF NOT EXISTS "leadText" TEXT;
ALTER TABLE "PatientStory" ADD COLUMN IF NOT EXISTS "body" JSONB;
ALTER TABLE "PatientStory" ADD COLUMN IF NOT EXISTS "dateText" TEXT;
ALTER TABLE "PatientStory" ADD COLUMN IF NOT EXISTS "sortOrder" INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS "PatientStory_sortOrder_idx" ON "PatientStory"("sortOrder");

ALTER TABLE "Speciality" ADD COLUMN IF NOT EXISTS "shortDescription" TEXT;
ALTER TABLE "Speciality" ADD COLUMN IF NOT EXISTS "detailTitle" TEXT;
ALTER TABLE "Speciality" ADD COLUMN IF NOT EXISTS "detailDescription" TEXT;
ALTER TABLE "Speciality" ADD COLUMN IF NOT EXISTS "services" JSONB;
ALTER TABLE "Speciality" ADD COLUMN IF NOT EXISTS "doctorsData" JSONB;
ALTER TABLE "Speciality" ADD COLUMN IF NOT EXISTS "featured" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Speciality" ADD COLUMN IF NOT EXISTS "showInMenu" BOOLEAN NOT NULL DEFAULT true;

CREATE INDEX IF NOT EXISTS "Speciality_status_idx" ON "Speciality"("status");
CREATE INDEX IF NOT EXISTS "Speciality_sortOrder_idx" ON "Speciality"("sortOrder");
