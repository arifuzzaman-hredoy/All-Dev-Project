// File: clinic-website/next.config.ts

import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  allowedDevOrigins: ["192.168.2.109"],

  productionBrowserSourceMaps: false,

  // This Docker setup installs production node_modules in the runner image and
  // does not rely on Next standalone trace output. Keep trace collection small
  // so CI/VPS builds do not hang on large dependency trees.
  outputFileTracingExcludes: {
    "/*": ["**/*"],
  },

  turbopack: {
    root: process.cwd(),
  },

  experimental: {
    // Keep production builds stable on small VPS/CI runners.
    cpus: 1,
  },
};

export default nextConfig;
