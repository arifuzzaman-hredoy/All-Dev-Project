import { NextResponse, type NextRequest } from "next/server";
import { getAdminCookieName } from "@/lib/env";
import { applySecurityHeaders } from "@/lib/security-headers";

const adminCookie = getAdminCookieName();

function isPublicAdminAuthPath(pathname: string) {
  return pathname === "/admin/login" || pathname.startsWith("/admin/forgot-password");
}

function isAdminPath(pathname: string) {
  return pathname === "/admin" || pathname.startsWith("/admin/");
}

function isAdminApiPath(pathname: string) {
  return pathname.startsWith("/api/admin/") && !pathname.startsWith("/api/admin/auth/");
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hasCookie = Boolean(request.cookies.get(adminCookie)?.value);

  if (isAdminApiPath(pathname) && !hasCookie) {
    return applySecurityHeaders(
      NextResponse.json(
        { ok: false, message: "Unauthorized admin request." },
        { status: 401 },
      ),
    );
  }

  if (isAdminPath(pathname) && !isPublicAdminAuthPath(pathname) && !hasCookie) {
    const loginUrl = request.nextUrl.clone();
    loginUrl.pathname = "/admin/login";
    loginUrl.searchParams.set("next", pathname);
    return applySecurityHeaders(NextResponse.redirect(loginUrl));
  }

  return applySecurityHeaders(NextResponse.next());
}

export const config = {
  matcher: ["/admin/:path*", "/api/admin/:path*", "/api/:path*"],
};
