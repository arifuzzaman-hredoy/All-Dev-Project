This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
# Update_clinic
# Update_clinic
# update-website

## Phase 8.3 — Admin UI/UX Parity

Phase 8.3 upgrades admin login, shell, sidebar, route loading, and admin navigation UX parity while keeping the real production backend authentication endpoint and existing database-backed admin features.

## Phase 8.5 — Backend Support Verification

This package includes the Phase 8.5 backend support verification layer:

- `/admin/frontend-support`
- `/api/admin/frontend-support`
- `npm run backend:support-check`
- `docs/PHASE_8_5_BACKEND_SUPPORT_FOR_FRONTEND_FEATURES.md`

Purpose: prove that frontend developer features are backed by real APIs/database workflows, not fake localStorage-only flows.

## Phase 8.6 — Full Regression QA

This source package includes Phase 8.6 regression QA tooling.

Useful commands:

```bash
npm run qa:regression
npm run qa:full
npm run qa:deploy-ready
QA_BASE_URL=https://update.techteamlead.com npm run qa:live-smoke
```

Generated reports:

```txt
docs/generated/phase-8-6-regression-report.json
docs/generated/phase-8-6-regression-report.md
```

## Phase 8.8 — Final Client Package + Backup

Final package workflow commands:

```bash
npm run client:package:check
npm run client:package:write
npm run client:handover:vps
npm run phase8:final
```

Use `npm run client:handover:vps` only on the VPS after the final GitHub push and pull. It runs production checks, rebuilds Docker, performs live smoke tests, and creates final source/server backups.
