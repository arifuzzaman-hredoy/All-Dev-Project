# SiamsBay

A modern full-stack eCommerce platform built with **Next.js**, **Prisma**, and **PostgreSQL**, designed for a production-ready online store experience with a powerful admin panel, practical business operations, and a clean customer journey.

---

## Overview

**SiamsBay** is a complete eCommerce solution focused on a modern storefront, smooth checkout flow, and easy day-to-day store management.

It includes:

- a customer-facing storefront
- a feature-rich admin panel
- Cloudinary-based media handling
- category and product management
- guest checkout
- SSLCommerz online payment support
- configurable business settings and policy pages

This project is suitable for businesses that need a reliable, scalable, and client-manageable online store.

---

## Main Features

### Customer-facing features

- Modern homepage with:
  - hero section
  - banner carousel
  - featured products
  - shop by category
  - CTA sections
- Product browsing with:
  - search
  - category/subcategory filtering
  - featured filter
  - stock filter
  - price range filter
  - sorting
  - pagination
- Daraz-style live search suggestions in the header
- Product details page with:
  - image gallery
  - variants
  - related product suggestions
- Wishlist for logged-in users
- Cart and checkout system
- **Guest checkout** support
- Dhaka / outside-Dhaka shipping logic
- Bangladesh district-based checkout
- COD and SSLCommerz online payment
- Order tracking by:
  - logged-in account
  - order ID
  - phone number
- Order details page with:
  - summary
  - courier details
  - delivery details
  - suggested products
- About Us page
- Contact page
- Footer social media links

### Admin features

- Product management
- Category and subcategory management
- Category image upload
- Product image upload
- Variant image upload
- Banner management
- Order management
- Store settings management
- Store policy content management
- About Us content and FAQ management

---

## Tech Stack

### Frontend
- **Next.js 16**
- **React 19**
- **TypeScript**
- **Tailwind CSS**
- **Lucide React**
- **Framer Motion**

### Backend / Database
- **Next.js App Router**
- **Prisma ORM**
- **PostgreSQL**
- **NextAuth**
- **Zod**

### Media / Payments / Deployment
- **Cloudinary**
- **SSLCommerz**
- **Vercel**

---

## Key Modules

## 1. Product Management

The system supports advanced product management with:

- shared product images
- Cloudinary-only media storage
- product variants
- per-variant images
- featured product tagging
- stock control
- related product suggestions

### Variant support

Supported variant examples:

- Color
- Size
- Model
- Measurement

Examples:
- Red / Blue
- XL / XXL
- Model A / Model B
- 2 ml / 5 ml / 1 kg

Each variant can have:

- its own stock
- its own price difference
- its own images

If a variant has no dedicated image, shared product images can be used as fallback.

---

## 2. Category System

The category system includes:

- parent categories
- subcategories
- category tree structure
- category filtering logic
- category image upload
- homepage category showcase

### Category image support

Each category can have a dedicated image uploaded from the admin panel.  
Images are stored on **Cloudinary** and used in the homepage **Shop by Category** section.

---

## 3. Search System

The header search includes a live suggestion system.

### Search features

- instant suggestion dropdown
- product suggestions
- category suggestions
- page shortcuts
- keyboard navigation
- click-to-navigate behavior

This improves product discovery and makes the store easier to use.

---

## 4. Checkout and Orders

The checkout system is optimized for local eCommerce workflows.

### Checkout features

- guest checkout
- logged-in user checkout
- COD support
- SSLCommerz online payment
- district-based shipping selection
- Dhaka / outside-Dhaka shipping calculation
- return and refund policy modal during checkout

### Order tracking

Orders can be tracked through:

- logged-in user order history
- order ID
- phone number

### Order details page includes

- order summary
- payment information
- delivery information
- courier information
- ordered items
- recommendation section

---

## 5. Settings / CMS-like Controls

The admin settings page acts like a lightweight content management area for important store information.

### Managed from settings

- Store name
- Tax rate
- Shipping charges
- Payment method toggles
- Low stock threshold
- Social media links
- Return and Refund Policy
- Privacy Policy
- Terms & Conditions
- About Us content
- About Us FAQs

---

## 6. About Us Page

The About Us page is designed to be simple, professional, and easy to manage.

### Includes

- main About Us text
- automatic business statistics from the database:
  - total products
  - total orders
  - delivered orders
  - total categories
- FAQ section managed from admin settings
- fixed CTA section in code

This keeps the page professional while still allowing the admin to control the important content.

---

## 7. Contact Page

The Contact page is a clean support-focused page that helps customers:

- navigate to products
- navigate to orders
- connect through social channels
- understand where to go for help

---

## Image Upload Strategy

All media uploads are handled through **Cloudinary**.

### Upload use cases

- product images
- variant images
- category images

### Benefits

- no local file dependency
- production-friendly media storage
- better scalability
- optimized hosted image delivery

---

## Project Structure

A simplified structure:

```bash
src/
  app/
    admin/
    api/
    about/
    contact/
    orders/
    products/
  components/
    admin/
    checkout/
    home/
    layout/
    products/
    wishlist/
  lib/
    prisma.ts
    pagination.ts
    category-tree.ts
    slug.ts
    validations/
  prisma/
    schema.prisma
    migrations/
```

---

## Environment Variables

Create a `.env` file and provide the required values.

```env
DATABASE_URL=
NEXTAUTH_URL=
NEXTAUTH_SECRET=

CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=

SSLCOMMERZ_STORE_ID=
SSLCOMMERZ_STORE_PASS=
SSLCOMMERZ_IS_LIVE=
NEXT_PUBLIC_BASE_URL=
```

---

## Local Development Setup

## 1. Install dependencies

```bash
npm install
```

## 2. Configure environment variables

Create a `.env` file and fill in all required values.

## 3. Run database migrations

```bash
npx prisma migrate dev
npx prisma generate
```

## 4. Start the development server

```bash
npm run dev
```

---

## Production Deployment

This project is intended to be deployed on **Vercel** with **PostgreSQL**.

### Recommended production flow

```bash
prisma migrate deploy
prisma generate
next build
```

### Suggested build command

```json
"vercel-build": "prisma generate && prisma migrate deploy && next build"
```

### Important note

Use this in production:

```bash
npx prisma migrate deploy
```

Do **not** use `prisma migrate dev` in production.

---

## Database Notes

The project follows Prisma migration workflow.

### Recommended practices

- use `migrate dev` only for development
- use `migrate deploy` in production
- commit migration files to version control
- keep schema and migration history consistent

---

## Admin Workflow Summary

An admin can:

- manage categories and subcategories
- upload category images
- manage products and variants
- upload product and variant images
- manage banners
- process orders
- manage social links
- manage policy pages
- manage About Us content and FAQs

---

## Customer Workflow Summary

A customer can:

- browse categories
- search products
- filter products
- view product details
- select variants
- add items to wishlist
- checkout as guest or user
- pay online or choose COD
- track orders later using order ID or phone number

---

## Design Goals

This project was built with the following goals:

- a simple and trustworthy eCommerce experience
- easy admin operations
- production-ready asset and database workflow
- client-manageable business content
- a clean foundation for future scaling

---

## Suggested Future Enhancements

Possible future additions:

- invoice generation
- advanced reporting dashboard
- brand management
- coupon analytics
- recently viewed products
- frequently bought together
- review moderation tools
- multi-language support

---

## Client Handover Checklist

Before final launch, confirm:

- production database is connected
- all environment variables are configured
- Cloudinary credentials are valid
- SSLCommerz credentials are correct
- Prisma migrations are applied in production
- social links are configured
- store policies are configured
- About Us content and FAQ are added

---

## License

This project is private and intended for client delivery / business use.

---

## Delivery Note

This solution was built with focus on:

- maintainability
- admin usability
- clean customer experience
- production deployment readiness
