"use client";

import Link from "next/link";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import * as React from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";

export default function LoginPage() {
  const router = useRouter();
  const sp = useSearchParams();
  const next = sp.get("next") || "/";
  const { toast } = useToast();

  const [loading, setLoading] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    setLoading(false);

    if (!res?.ok) {
      toast({
        title: "Login failed",
        variant: "error",
        description: "Check email/password or account blocked.",
      });
      return;
    }

    toast({
      title: "Welcome back!",
      variant: "success",
      description: "Login successful.",
    });
    router.push(next);
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-10">
      <div className="w-full max-w-xl">
        <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
          <div className="inline-flex rounded-sm bg-[#ec407a]/15 px-3 py-1 text-xs font-medium text-[#ad1457]">
            Login
          </div>
          <h2 className="mt-4 text-2xl font-semibold tracking-tight text-slate-900">
            Access your account and orders.
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Sign in to keep your shopping flow connected across devices.
          </p>

          <form onSubmit={onSubmit} className="mt-6 space-y-3">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">
                Email
              </label>
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-3">
                <label className="text-xs font-medium text-slate-600">
                  Password
                </label>
                <Link
                  className="text-xs font-medium text-[#ad1457] underline underline-offset-4"
                  href="/forgot-password"
                >
                  Forgot password?
                </Link>
              </div>
              <Input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                type="password"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
              />
            </div>

            <Button
              className="w-full bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
              disabled={loading}
            >
              {loading ? "Logging in..." : "Login"}
            </Button>
          </form>

          <div className="mt-4 text-sm text-slate-600">
            New here?{" "}
            <Link
              className="font-medium text-[#ad1457] underline underline-offset-4"
              href="/register"
            >
              Create account
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
