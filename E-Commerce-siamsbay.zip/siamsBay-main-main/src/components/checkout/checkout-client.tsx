"use client";

import type { ReactNode } from "react";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  BadgePercent,
  CheckCircle2,
  CreditCard,
  MapPin,
  PackageCheck,
  Phone,
  ReceiptText,
  ShieldCheck,
  Truck,
  UserRound,
  WalletCards,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  loadAppliedCoupon,
  clearAppliedCoupon,
  saveAppliedCoupon,
} from "@/lib/coupon-client";
import { useToast } from "../ui/toast";
import ReturnRefundPolicyModal from "./return-refund-policy-modal";
import { calcTotals, normalizeShippingRules } from "@/lib/pricing";
import { normalizeBangladeshPhone } from "@/lib/validations/checkout";

type CartDetailsItem = {
  qty: number;
  variantId?: string | null;
  variantLabel?: string | null;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    offerPrice: number | null;
    stock: number;
    images: { url: string }[];
  };
};

type CartDetailsResponse = { items: CartDetailsItem[] };

type ValidateOk = {
  ok?: true;
  success?: true;
  code?: string;
  discount?: number;
};

type PublicStoreSettings = {
  ok: true;
  storeName: string;
  currency: string;
  taxRate: number;
  shippingInsideDhaka: number;
  shippingRangpur: number;
  shippingOutsideDhaka: number;
  shippingFreeOver: number;
  shippingDefaultCharge: number;
  shippingRules: unknown[];
  codEnabled: boolean;
  onlineEnabled: boolean;
  manualPaymentEnabled: boolean;
  manualBkashNumber: string;
  manualNagadNumber: string;
  manualRocketNumber: string;
  lowStockThreshold: number;

  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  whatsappUrl: string;
  returnRefundPolicy: string;
};

type PaymentMethod = "COD" | "ONLINE" | "MANUAL";

type CheckoutField =
  | "name"
  | "email"
  | "phone"
  | "line1"
  | "city"
  | "area"
  | "note"
  | "paymentMethod";

type CheckoutFieldErrors = Partial<Record<CheckoutField, string>>;

const CHECKOUT_FIELD_LABELS: Record<CheckoutField, string> = {
  name: "Full name",
  email: "Email",
  phone: "Phone number",
  line1: "Address line 1",
  city: "District",
  area: "Police station",
  note: "Delivery note",
  paymentMethod: "Payment method",
};

const CHECKOUT_FIELD_ORDER: CheckoutField[] = [
  "name",
  "phone",
  "email",
  "line1",
  "city",
  "area",
  "paymentMethod",
  "note",
];

type PoliceStationOption = {
  id: string;
  name: string;
  district: string;
};

type DistrictOption = {
  id: string;
  name: string;
};

type CheckoutClientProps = {
  initialSearchParams?: {
    buyNow?: string;
    productId?: string;
    variantId?: string;
    qty?: string;
  };
};

const COD_CHECKOUT_ENDPOINT = "/api/orders";
const ONLINE_CHECKOUT_ENDPOINT = "/api/payments/sslcommerz/initiate";
const MANUAL_CHECKOUT_ENDPOINT = "/api/payments/manual/initiate";

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function calculateVariantAwarePrice(params: {
  productPrice: number;
  productOfferPrice: number | null;
  variantPriceDiff: number | null;
}) {
  const baseOriginalPrice = safeNumber(params.productPrice, 0);

  const baseDiscountedPrice = safeNumber(
    params.productOfferPrice ?? params.productPrice,
    baseOriginalPrice,
  );

  const variantPriceDiff = safeNumber(params.variantPriceDiff, 0);

  const comparePrice = baseOriginalPrice + variantPriceDiff;

  const rawDiscountRatio =
    baseOriginalPrice > 0 ? baseDiscountedPrice / baseOriginalPrice : 1;

  const discountRatio = Math.min(Math.max(rawDiscountRatio, 0), 1);

  const unitPrice = Math.floor(comparePrice * discountRatio);

  return {
    comparePrice,
    unitPrice,
    offerPrice: unitPrice < comparePrice ? unitPrice : null,
  };
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function parseDetails(input: unknown): CartDetailsResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.items) ? o.items : [];

  const items: CartDetailsItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => {
      const p = (x.product as Record<string, unknown> | undefined) ?? {};
      const qty = Math.max(1, Math.floor(safeNumber(x.qty, 1)));

      return {
        qty,
        variantId:
          typeof x.variantId === "string"
            ? x.variantId
            : x.variantId === null
              ? null
              : undefined,
        variantLabel:
          typeof x.variantLabel === "string"
            ? x.variantLabel
            : x.variantLabel === null
              ? null
              : undefined,
        product: {
          id: safeString(p.id),
          name: safeString(p.name),
          slug: safeString(p.slug),
          price: safeNumber(p.price, 0),
          offerPrice:
            p.offerPrice === null
              ? null
              : typeof p.offerPrice === "number"
                ? p.offerPrice
                : null,
          stock: safeNumber(p.stock, 0),
          images: Array.isArray(p.images)
            ? (p.images as Array<{ url: string }>)
            : [],
        },
      };
    })
    .filter((i) => i.product.id && i.product.slug);

  return { items };
}

function parseSettings(input: unknown): PublicStoreSettings {
  const data = (input as Record<string, unknown> | null) ?? {};

  return {
    ok: true,
    storeName: safeString(data.storeName, "SiamsBay"),
    currency: safeString(data.currency, "BDT"),
    taxRate: Math.max(0, safeNumber(data.taxRate, 0)),
    shippingInsideDhaka: Math.max(0, safeNumber(data.shippingInsideDhaka, 0)),
    shippingRangpur: Math.max(0, safeNumber(data.shippingRangpur, 0)),
    shippingOutsideDhaka: Math.max(0, safeNumber(data.shippingOutsideDhaka, 0)),
    shippingFreeOver: Math.max(0, safeNumber(data.shippingFreeOver, 0)),
    shippingDefaultCharge: Math.max(
      0,
      safeNumber(data.shippingDefaultCharge, 0),
    ),
    shippingRules: Array.isArray(data.shippingRules) ? data.shippingRules : [],
    codEnabled: typeof data.codEnabled === "boolean" ? data.codEnabled : true,
    onlineEnabled:
      typeof data.onlineEnabled === "boolean" ? data.onlineEnabled : false,
    manualPaymentEnabled:
      typeof data.manualPaymentEnabled === "boolean"
        ? data.manualPaymentEnabled
        : false,
    manualBkashNumber: safeString(data.manualBkashNumber, ""),
    manualNagadNumber: safeString(data.manualNagadNumber, ""),
    manualRocketNumber: safeString(data.manualRocketNumber, ""),
    lowStockThreshold: Math.max(0, safeNumber(data.lowStockThreshold, 5)),
    facebookUrl: safeString(data.facebookUrl, ""),
    instagramUrl: safeString(data.instagramUrl, ""),
    youtubeUrl: safeString(data.youtubeUrl, ""),
    tiktokUrl: safeString(data.tiktokUrl, ""),
    whatsappUrl: safeString(data.whatsappUrl, ""),
    returnRefundPolicy: safeString(data.returnRefundPolicy, ""),
  };
}

function getErrorMessage(
  input: unknown,
  fallback = "Something went wrong",
): string {
  const o = input as Record<string, unknown> | null;

  if (!o) return fallback;

  if (typeof o.error === "string" && o.error.trim()) return o.error;
  if (typeof o.message === "string" && o.message.trim()) return o.message;

  return fallback;
}

function getOrderIdFromResponse(input: unknown): string | null {
  const o = input as Record<string, unknown> | null;
  if (!o) return null;

  if (typeof o.orderId === "string") return o.orderId;

  const data =
    typeof o.data === "object" && o.data !== null
      ? (o.data as Record<string, unknown>)
      : null;

  if (data && typeof data.orderId === "string") return data.orderId;
  if (data && typeof data.id === "string") return data.id;

  const order =
    data && typeof data.order === "object" && data.order !== null
      ? (data.order as Record<string, unknown>)
      : null;

  if (order && typeof order.id === "string") return order.id;

  return null;
}

function getGatewayUrlFromResponse(input: unknown): string | null {
  const o = input as Record<string, unknown> | null;
  if (!o) return null;

  if (typeof o.gatewayUrl === "string") return o.gatewayUrl;

  const data =
    typeof o.data === "object" && o.data !== null
      ? (o.data as Record<string, unknown>)
      : null;

  if (data && typeof data.gatewayUrl === "string") return data.gatewayUrl;
  if (data && typeof data.GatewayPageURL === "string")
    return data.GatewayPageURL;

  return null;
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isValidBangladeshPhone(value: string): boolean {
  return /^01\d{9}$/.test(normalizeBangladeshPhone(value));
}

function getFirstCheckoutFieldError(
  errors: CheckoutFieldErrors,
): CheckoutField | null {
  return CHECKOUT_FIELD_ORDER.find((field) => Boolean(errors[field])) ?? null;
}

function FieldError({ message }: { message?: string }) {
  if (!message) return null;

  return <div className="mt-1 text-xs font-medium text-red-600">{message}</div>;
}

function SectionTitle({
  icon,
  title,
  subtitle,
}: {
  icon: ReactNode;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-[#f8bbd0] bg-[#fff1f5] text-[#ad1457]">
        {icon}
      </div>
      <div>
        <div className="text-base font-semibold text-slate-950">{title}</div>
        {subtitle ? (
          <div className="mt-0.5 text-sm text-slate-500">{subtitle}</div>
        ) : null}
      </div>
    </div>
  );
}

function FieldBlock({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-slate-700">
        {label}
      </span>
      {children}
      <FieldError message={error} />
    </label>
  );
}

function SummaryRow({
  label,
  value,
  strong = false,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div
      className={`flex items-center justify-between gap-3 ${
        strong ? "text-base font-semibold text-slate-950" : "text-sm"
      }`}
    >
      <span className={strong ? "" : "text-slate-500"}>{label}</span>
      <span>{value}</span>
    </div>
  );
}

function parsePoliceStations(input: unknown): PoliceStationOption[] {
  const root = (input as Record<string, unknown> | null) ?? {};
  const rows = Array.isArray(root.policeStations) ? root.policeStations : [];

  return rows
    .map((item) => item as Record<string, unknown>)
    .map((item) => ({
      id: safeString(item.id),
      name: safeString(item.name),
      district: safeString(item.district),
    }))
    .filter((item) => item.id && item.name);
}

function parseDistricts(input: unknown): DistrictOption[] {
  const root = (input as Record<string, unknown> | null) ?? {};
  const rows = Array.isArray(root.districts) ? root.districts : [];

  return rows
    .map((item) => item as Record<string, unknown>)
    .map((item) => ({
      id: safeString(item.id),
      name: safeString(item.name),
    }))
    .filter((item) => item.id && item.name);
}

export default function CheckoutClient({
  initialSearchParams,
}: CheckoutClientProps) {
  const { toast } = useToast();

  const isBuyNow = initialSearchParams?.buyNow === "1";
  const buyNowProductId = initialSearchParams?.productId || null;
  const buyNowVariantId = initialSearchParams?.variantId || null;
  const buyNowQty = Math.max(1, Number(initialSearchParams?.qty || "1"));

  const [loading, setLoading] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);

  const [details, setDetails] = useState<CartDetailsResponse>({ items: [] });
  const [settings, setSettings] = useState<PublicStoreSettings>({
    ok: true,
    storeName: "SiamsBay",
    currency: "BDT",
    taxRate: 0,
    shippingInsideDhaka: 0,
    shippingRangpur: 0,
    shippingOutsideDhaka: 0,
    shippingFreeOver: 0,
    shippingDefaultCharge: 0,
    shippingRules: [],
    codEnabled: true,
    onlineEnabled: false,
    manualPaymentEnabled: false,
    manualBkashNumber: "",
    manualNagadNumber: "",
    manualRocketNumber: "",
    lowStockThreshold: 5,
    facebookUrl: "",
    instagramUrl: "",
    youtubeUrl: "",
    tiktokUrl: "",
    whatsappUrl: "",
    returnRefundPolicy: "",
  });

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("COD");

  const [couponCode, setCouponCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [couponMsg, setCouponMsg] = useState("");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [line1, setLine1] = useState("");
  const [line2, setLine2] = useState("");
  const [city, setCity] = useState("");
  const [area, setArea] = useState("");
  const [fieldErrors, setFieldErrors] = useState<CheckoutFieldErrors>({});
  const [touchedFields, setTouchedFields] = useState<
    Partial<Record<CheckoutField, boolean>>
  >({});

  const [districts, setDistricts] = useState<DistrictOption[]>([]);
  const [districtsLoading, setDistrictsLoading] = useState(false);
  const [districtsError, setDistrictsError] = useState("");

  const [policeStations, setPoliceStations] = useState<PoliceStationOption[]>(
    [],
  );
  const [loadingPoliceStations, setLoadingPoliceStations] = useState(false);
  const [policeStationsError, setPoliceStationsError] = useState("");

  const [note, setNote] = useState("");

  const getValidationErrors = (overrides: {
    name?: string;
    email?: string;
    phone?: string;
    line1?: string;
    city?: string;
    area?: string;
    note?: string;
    paymentMethod?: PaymentMethod;
  } = {}): CheckoutFieldErrors => {
    const errors: CheckoutFieldErrors = {};

    const nextName = overrides.name ?? name;
    const nextEmail = overrides.email ?? email;
    const nextPhone = overrides.phone ?? phone;
    const nextLine1 = overrides.line1 ?? line1;
    const nextCity = overrides.city ?? city;
    const nextArea = overrides.area ?? area;
    const nextNote = overrides.note ?? note;
    const nextPaymentMethod = overrides.paymentMethod ?? paymentMethod;

    const trimmedName = nextName.trim();
    const trimmedEmail = nextEmail.trim();
    const trimmedPhone = nextPhone.trim();
    const trimmedLine1 = nextLine1.trim();
    const trimmedNote = nextNote.trim();

    if (!trimmedName) {
      errors.name = "Full name is required.";
    } else if (trimmedName.length < 2) {
      errors.name = "Full name must be at least 2 characters.";
    } else if (trimmedName.length > 120) {
      errors.name = "Full name must be 120 characters or less.";
    }

    if (trimmedEmail && !isValidEmail(trimmedEmail)) {
      errors.email = "Enter a valid email address or leave it empty.";
    }

    if (!trimmedPhone) {
      errors.phone = "Phone number is required.";
    } else if (!isValidBangladeshPhone(trimmedPhone)) {
      errors.phone =
        "Enter an 11-digit Bangladesh number, for example 01XXXXXXXXX.";
    }

    if (!trimmedLine1) {
      errors.line1 = "Address line 1 is required.";
    } else if (trimmedLine1.length < 3) {
      errors.line1 = "Address line 1 must be at least 3 characters.";
    } else if (trimmedLine1.length > 255) {
      errors.line1 = "Address line 1 must be 255 characters or less.";
    }

    if (!nextCity.trim()) {
      errors.city = "Please select a district.";
    }

    if (!nextArea.trim()) {
      errors.area = "Please select a police station.";
    }

    if (trimmedNote.length > 500) {
      errors.note = "Note must be 500 characters or less.";
    }

    if (!enabledPaymentMethods.includes(nextPaymentMethod)) {
      errors.paymentMethod = "Please select an available payment method.";
    }

    return errors;
  };

  const validateFieldNow = (
    field: CheckoutField,
    overrides: Parameters<typeof getValidationErrors>[0] = {},
  ) => {
    const errors = getValidationErrors(overrides);

    setTouchedFields((prev) => ({
      ...prev,
      [field]: true,
    }));

    setFieldErrors((prev) => {
      const next = { ...prev };
      const message = errors[field];

      if (message) {
        next[field] = message;
      } else {
        delete next[field];
      }

      return next;
    });
  };

  const validateCheckoutForm = (): CheckoutFieldErrors => {
    return getValidationErrors();
  };

  const focusCheckoutField = (field: CheckoutField): void => {
    const element = document.querySelector<HTMLElement>(
      `[data-checkout-field="${field}"]`,
    );

    element?.scrollIntoView({ behavior: "smooth", block: "center" });
    window.setTimeout(() => {
      element?.focus({ preventScroll: true });
    }, 250);
  };

  const subtotal = useMemo(() => {
    return details.items.reduce((sum, row) => {
      const unit = row.product.offerPrice ?? row.product.price;
      return sum + unit * row.qty;
    }, 0);
  }, [details.items]);

  const couponItemsPayload = useMemo(
    () =>
      details.items.map((row) => ({
        productId: row.product.id,
        variantId: row.variantId || undefined,
        qty: row.qty,
      })),
    [details.items],
  );

  const totals = useMemo(() => {
    return calcTotals({
      subtotal,
      discount,
      district: city,
      policeStation: area,
      settings: {
        taxRate: settings.taxRate,
        shippingInsideDhaka: settings.shippingInsideDhaka,
        shippingRangpur: settings.shippingRangpur,
        shippingOutsideDhaka: settings.shippingOutsideDhaka,
        shippingFreeOver: settings.shippingFreeOver,
        shippingDefaultCharge: settings.shippingDefaultCharge,
        shippingRules: normalizeShippingRules(settings.shippingRules),
      },
    });
  }, [subtotal, discount, city, area, settings]);

  const shippingLabel = useMemo(() => {
    if (totals.shippingSource === "POLICE_STATION") {
      return "Shipping (Police Station Rule)";
    }

    if (totals.shippingSource === "DISTRICT") {
      return "Shipping (District Rule)";
    }

    if (totals.shippingSource === "DEFAULT") {
      return "Shipping (Default)";
    }

    if (totals.shippingSource === "FREE") {
      return "Shipping (Free)";
    }

    return "Shipping";
  }, [totals.shippingSource]);

  const loadCartMode = async (): Promise<CartDetailsResponse> => {
    const cartRes = await fetch("/api/cart/details", { cache: "no-store" });
    const cartJson: unknown = await cartRes.json().catch(() => null);
    return parseDetails(cartJson);
  };

  const enabledPaymentMethods = useMemo(() => {
    const manualHasNumber = Boolean(
      settings.manualBkashNumber ||
      settings.manualNagadNumber ||
      settings.manualRocketNumber,
    );

    const result: PaymentMethod[] = [];

    if (settings.codEnabled) result.push("COD");
    if (settings.onlineEnabled) result.push("ONLINE");
    if (settings.manualPaymentEnabled && manualHasNumber) result.push("MANUAL");

    return result;
  }, [
    settings.codEnabled,
    settings.onlineEnabled,
    settings.manualPaymentEnabled,
    settings.manualBkashNumber,
    settings.manualNagadNumber,
    settings.manualRocketNumber,
  ]);

  const currentFieldErrors = getValidationErrors();
  const placeOrderDisabled =
    placing ||
    districtsLoading ||
    loadingPoliceStations ||
    districts.length === 0 ||
    policeStations.length === 0 ||
    Object.keys(currentFieldErrors).length > 0;

  const loadBuyNowMode = async (): Promise<CartDetailsResponse> => {
    if (!buyNowProductId) {
      return { items: [] };
    }

    const query = new URLSearchParams();
    query.set("id", buyNowProductId);

    const productRes = await fetch(`/api/products/by-id?${query.toString()}`, {
      cache: "no-store",
    });

    const productJson = (await productRes.json().catch(() => null)) as {
      id?: string;
      name?: string;
      slug?: string;
      price?: number;
      offerPrice?: number | null;
      stock?: number;
      images?: Array<{ url: string }>;
      variants?: Array<{
        id: string;
        type: string;
        value: string;
        priceDiff: number;
        stock: number;
      }>;
    } | null;

    if (!productRes.ok || !productJson?.id || !productJson?.slug) {
      return { items: [] };
    }

    const variant =
      buyNowVariantId && Array.isArray(productJson.variants)
        ? (productJson.variants.find((v) => v.id === buyNowVariantId) ?? null)
        : null;

    const productPrice =
      typeof productJson.price === "number" ? productJson.price : 0;

    const productOfferPrice =
      typeof productJson.offerPrice === "number"
        ? productJson.offerPrice
        : null;

    const priceInfo = calculateVariantAwarePrice({
      productPrice,
      productOfferPrice,
      variantPriceDiff: variant?.priceDiff ?? 0,
    });

    return {
      items: [
        {
          qty: buyNowQty,
          variantId: variant?.id ?? null,
          variantLabel: variant ? `${variant.type}: ${variant.value}` : null,
          product: {
            id: productJson.id,
            name: productJson.name ?? "Product",
            slug: productJson.slug,

            // original variant price
            price: priceInfo.comparePrice,

            // discounted variant price
            offerPrice: priceInfo.offerPrice,

            stock:
              typeof variant?.stock === "number"
                ? variant.stock
                : typeof productJson.stock === "number"
                  ? productJson.stock
                  : 0,
            images: Array.isArray(productJson.images) ? productJson.images : [],
          },
        },
      ],
    };
  };

  const loadDistricts = async (): Promise<void> => {
    setDistrictsLoading(true);
    setDistrictsError("");

    try {
      const r = await fetch("/api/courier/steadfast/police-stations", {
        cache: "no-store",
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        setDistricts([]);
        setDistrictsError(
          getErrorMessage(j, "Failed to load steadfast districts"),
        );
        return;
      }

      const nextDistricts = parseDistricts(j);
      setDistricts(nextDistricts);

      setCity((prev) => {
        if (prev && nextDistricts.some((item) => item.name === prev)) {
          return prev;
        }

        const preferred =
          nextDistricts.find((item) => item.name === "Dhaka")?.name ||
          nextDistricts[0]?.name ||
          "";

        return preferred;
      });
    } catch {
      setDistricts([]);
      setDistrictsError("Failed to load steadfast districts");
    } finally {
      setDistrictsLoading(false);
    }
  };

  const load = async (): Promise<void> => {
    setLoading(true);
    try {
      const settingsRes = await fetch("/api/store/settings/public", {
        cache: "no-store",
      });
      const settingsJson: unknown = await settingsRes.json().catch(() => null);
      setSettings(parseSettings(settingsJson));

      const nextDetails = isBuyNow
        ? await loadBuyNowMode()
        : await loadCartMode();

      setDetails(nextDetails);
    } finally {
      setLoading(false);
    }
  };

  const loadPoliceStations = async (district: string): Promise<void> => {
    const selectedDistrict = district.trim();

    if (!selectedDistrict) {
      setPoliceStations([]);
      setArea("");
      setPoliceStationsError("");
      return;
    }

    setLoadingPoliceStations(true);
    setPoliceStationsError("");

    try {
      const query = new URLSearchParams({ district: selectedDistrict });
      const r = await fetch(
        `/api/courier/steadfast/police-stations?${query.toString()}`,
        {
          cache: "no-store",
        },
      );

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        setPoliceStations([]);
        setArea("");
        setPoliceStationsError(
          getErrorMessage(j, "Failed to load police stations"),
        );
        return;
      }

      const nextStations = parsePoliceStations(j);

      setPoliceStations(nextStations);
      setArea((prev) =>
        nextStations.some((item) => item.name === prev) ? prev : "",
      );

      if (nextStations.length === 0) {
        setPoliceStationsError(
          "No police station found for the selected district",
        );
      }
    } catch {
      setPoliceStations([]);
      setArea("");
      setPoliceStationsError("Failed to load police stations");
    } finally {
      setLoadingPoliceStations(false);
    }
  };

  useEffect(() => {
    void Promise.all([load(), loadDistricts()]);
  }, [isBuyNow, buyNowProductId, buyNowVariantId, buyNowQty]);

  useEffect(() => {
    if (!city) return;
    void loadPoliceStations(city);
  }, [city]);

  useEffect(() => {
    const saved = loadAppliedCoupon();
    if (saved?.code) {
      setCouponCode(saved.code);
    }
  }, []);

  useEffect(() => {
    if (enabledPaymentMethods.includes(paymentMethod)) return;

    const first = enabledPaymentMethods[0];
    if (first) {
      setPaymentMethod(first);
    }
  }, [enabledPaymentMethods, paymentMethod]);

  useEffect(() => {
    const saved = loadAppliedCoupon();
    if (!saved?.code) return;
    if (subtotal <= 0) return;

    const revalidateSavedCoupon = async () => {
      const r = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: saved.code,
          items: couponItemsPayload,
        }),
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        setDiscount(0);
        setCouponMsg(getErrorMessage(j, "Invalid coupon"));
        clearAppliedCoupon();
        return;
      }

      const disc = (j as { discount?: unknown })?.discount;
      const d = typeof disc === "number" ? disc : Number(disc);
      const dd = Number.isFinite(d) ? Math.max(0, Math.floor(d)) : 0;

      setDiscount(dd);
      setCouponMsg("Coupon applied ✅");
      saveAppliedCoupon({ code: saved.code, discount: dd });
    };

    void revalidateSavedCoupon();
  }, [subtotal, couponItemsPayload]);

  const applyCoupon = async (): Promise<void> => {
    const code = couponCode.trim().toUpperCase();
    if (!code) return;

    setCouponMsg("");

    const r = await fetch("/api/coupons/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code,
        items: couponItemsPayload,
      }),
    });

    const j: unknown = await r.json().catch(() => null);

    if (!r.ok) {
      setDiscount(0);
      setCouponMsg(getErrorMessage(j, "Invalid coupon"));
      clearAppliedCoupon();
      return;
    }

    const ok = j as ValidateOk;
    const dd = Math.max(0, Math.floor(safeNumber(ok.discount, 0)));

    setDiscount(dd);
    setCouponMsg("Coupon applied ✅");
    saveAppliedCoupon({ code, discount: dd });
  };

  const buildCheckoutPayload = () => {
    return {
      items: details.items.map((row) => ({
        productId: row.product.id,
        variantId: row.variantId || undefined,
        qty: row.qty,
      })),
      couponCode: couponCode.trim()
        ? couponCode.trim().toUpperCase()
        : undefined,
      paymentMethod,
      name: name.trim(),
      email: email.trim() ? email.trim() : undefined,
      phone: normalizeBangladeshPhone(phone.trim()),
      addressLine1: line1.trim(),
      addressLine2: line2.trim() ? line2.trim() : undefined,
      city,
      area: area.trim(),
      note: note.trim() ? note.trim() : undefined,
    };
  };

  const clearClientCartState = async (): Promise<void> => {
    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "clear" }),
    });

    clearAppliedCoupon();
    window.dispatchEvent(new Event("rhc_cart_updated"));
  };

  const handleBlockedPlaceOrderClick = (): void => {
    if (placing) {
      toast({
        variant: "info",
        title: "Please wait",
        description: "Your order is already being processed.",
      });
      return;
    }

    if (districtsLoading || loadingPoliceStations) {
      toast({
        variant: "info",
        title: "Please wait",
        description: "Delivery locations are still loading.",
      });
      return;
    }

    const nextFieldErrors = validateCheckoutForm();
    setFieldErrors(nextFieldErrors);
    setTouchedFields((prev) => ({
      ...prev,
      ...Object.fromEntries(
        Object.keys(nextFieldErrors).map((field) => [field, true]),
      ),
    }));

    const firstField = getFirstCheckoutFieldError(nextFieldErrors);
    if (firstField) {
      const label = CHECKOUT_FIELD_LABELS[firstField];
      const message = nextFieldErrors[firstField];

      toast({
        variant: "error",
        title: `${label} required`,
        description:
          message && message.toLowerCase().includes("required")
            ? `You didn't fill ${label}.`
            : message || `Please fill ${label}.`,
      });
      focusCheckoutField(firstField);
      return;
    }

    if (districts.length === 0) {
      toast({
        variant: "error",
        title: "Delivery unavailable",
        description: districtsError || "No district available from Steadfast.",
      });
      return;
    }

    if (policeStations.length === 0) {
      toast({
        variant: "error",
        title: "Delivery unavailable",
        description:
          policeStationsError ||
          "No police station available for this district.",
      });
    }
  };

  const placeOrder = async (): Promise<void> => {
    if (details.items.length === 0) return;

    const nextFieldErrors = validateCheckoutForm();
    setFieldErrors(nextFieldErrors);

    if (Object.keys(nextFieldErrors).length > 0) {
      toast({
        variant: "error",
        title: "Check the form",
        description: "Please fix the highlighted fields before placing order.",
      });
      return;
    }

    if (districtsLoading) {
      toast({
        variant: "error",
        title: "Please wait",
        description: "Districts are still loading",
      });
      return;
    }

    if (loadingPoliceStations) {
      toast({
        variant: "error",
        title: "Please wait",
        description: "Police stations are still loading",
      });
      return;
    }

    if (districts.length === 0) {
      toast({
        variant: "error",
        title: "Failed",
        description: districtsError || "No district available from Steadfast",
      });
      return;
    }

    if (policeStations.length === 0) {
      toast({
        variant: "error",
        title: "Failed",
        description:
          policeStationsError ||
          "No police station available for this district",
      });
      return;
    }

    if (paymentMethod === "COD" && !settings.codEnabled) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Cash on Delivery is currently disabled.",
      });
      return;
    }

    if (paymentMethod === "ONLINE" && !settings.onlineEnabled) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Online payment is currently disabled.",
      });
      return;
    }

    if (
      paymentMethod === "MANUAL" &&
      (!settings.manualPaymentEnabled ||
        !(
          settings.manualBkashNumber ||
          settings.manualNagadNumber ||
          settings.manualRocketNumber
        ))
    ) {
      toast({
        variant: "error",
        title: "Failed",
        description: "Manual payment is currently unavailable.",
      });
      return;
    }

    const payload = buildCheckoutPayload();

    setPlacing(true);
    try {
      if (paymentMethod === "COD") {
        const r = await fetch(COD_CHECKOUT_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const j: unknown = await r.json().catch(() => null);

        if (!r.ok) {
          toast({
            variant: "error",
            title: "Failed",
            description: getErrorMessage(j, "Order failed"),
          });
          return;
        }

        const orderId = getOrderIdFromResponse(j);
        if (!orderId) {
          toast({
            variant: "info",
            title: "No ID",
            description: "Order created but order ID was not returned",
          });
          return;
        }

        if (!isBuyNow) {
          await clearClientCartState();
        }

        window.location.href = `/orders/${orderId}?phone=${encodeURIComponent(
          payload.phone,
        )}`;
        return;
      }

      const r = await fetch(ONLINE_CHECKOUT_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (paymentMethod === "MANUAL") {
        const r = await fetch(MANUAL_CHECKOUT_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const j: unknown = await r.json().catch(() => null);

        if (!r.ok) {
          toast({
            variant: "error",
            title: "Failed",
            description: getErrorMessage(j, "Manual payment initiation failed"),
          });
          return;
        }

        const token =
          j &&
          typeof j === "object" &&
          typeof (j as Record<string, unknown>).token === "string"
            ? ((j as Record<string, unknown>).token as string)
            : "";

        if (!token) {
          toast({
            variant: "error",
            title: "Failed",
            description: "Manual payment session token not found",
          });
          return;
        }

        window.location.href = `/payments/manual?token=${encodeURIComponent(token)}`;
        return;
      }

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        toast({
          variant: "error",
          title: "Failed",
          description: getErrorMessage(j, "Payment initiation failed"),
        });
        return;
      }

      const gatewayUrl = getGatewayUrlFromResponse(j);
      if (!gatewayUrl) {
        toast({
          variant: "error",
          title: "Failed",
          description: "Payment gateway URL not found",
        });
        return;
      }

      window.location.href = gatewayUrl;
    } finally {
      setPlacing(false);
    }
  };

  const backHref =
    isBuyNow && details.items[0]?.product?.slug
      ? `/products/${details.items[0].product.slug}`
      : "/cart";

  return (
    <div className="bg-slate-50/70">
      <div className="mx-auto max-w-6xl px-4 py-8 md:py-10">
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <Link
              href={backHref}
              className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 transition hover:text-slate-900"
            >
              <ArrowLeft className="h-4 w-4" />
              {isBuyNow ? "Back to product" : "Back to cart"}
            </Link>
            <div className="mt-3 text-3xl font-semibold tracking-normal text-slate-950">
              {isBuyNow ? "Buy Now Checkout" : "Checkout"}
            </div>
            <div className="mt-1 text-sm text-slate-500">
              {enabledPaymentMethods.length
                ? `${enabledPaymentMethods.length} payment option${
                    enabledPaymentMethods.length === 1 ? "" : "s"
                  } available`
                : "No payment method is currently available"}
            </div>
          </div>

          <div className="flex flex-wrap gap-2 text-xs font-medium">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-emerald-700">
              <ShieldCheck className="h-3.5 w-3.5" />
              Secure checkout
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-sky-200 bg-sky-50 px-3 py-1.5 text-sky-700">
              <Truck className="h-3.5 w-3.5" />
              Steadfast delivery
            </span>
          </div>
        </div>

        {loading ? (
          <Card className="rounded-2xl border border-slate-200 bg-white p-6 text-sm text-slate-600">
            Loading checkout...
          </Card>
        ) : details.items.length === 0 ? (
          <Card className="rounded-2xl border border-slate-200 bg-white p-8">
            <div className="text-base font-semibold text-slate-950">
              {isBuyNow ? "Product not found" : "Cart is empty"}
            </div>
            <div className="mt-4">
              <Link href="/products">
                <Button className="inline-flex items-center gap-2">
                  <PackageCheck className="h-4 w-4" />
                  Browse products
                </Button>
              </Link>
            </div>
          </Card>
        ) : (
          <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_400px]">
            <div className="space-y-5">
              <Card className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <SectionTitle
                  icon={<UserRound className="h-5 w-5" />}
                  title="Contact Details"
                  subtitle="Use the phone number where delivery support can reach you."
                />

                <div className="mt-5 grid gap-4 md:grid-cols-2">
                  <FieldBlock label="Full name" error={fieldErrors.name}>
                    <Input
                      value={name}
                      onChange={(e) => {
                        const value = e.target.value;
                        setName(value);
                        validateFieldNow("name", { name: value });
                      }}
                      onBlur={() => validateFieldNow("name")}
                      className={
                        fieldErrors.name
                          ? "border-red-300 focus:border-red-400 focus:ring-red-100"
                          : "bg-white"
                      }
                      aria-invalid={Boolean(fieldErrors.name)}
                      data-checkout-field="name"
                      placeholder="Your name"
                    />
                  </FieldBlock>

                  <FieldBlock label="Phone number" error={fieldErrors.phone}>
                    <Input
                      value={phone}
                      onChange={(e) => {
                        const value = e.target.value;
                        setPhone(value);
                        validateFieldNow("phone", { phone: value });
                      }}
                      onBlur={() => validateFieldNow("phone")}
                      className={
                        fieldErrors.phone
                          ? "border-red-300 focus:border-red-400 focus:ring-red-100"
                          : "bg-white"
                      }
                      aria-invalid={Boolean(fieldErrors.phone)}
                      data-checkout-field="phone"
                      inputMode="tel"
                      placeholder="01XXXXXXXXX"
                    />
                  </FieldBlock>

                  <div className="md:col-span-2">
                    <FieldBlock label="Email" error={fieldErrors.email}>
                      <Input
                        value={email}
                        onChange={(e) => {
                          const value = e.target.value;
                          setEmail(value);
                          validateFieldNow("email", { email: value });
                        }}
                        onBlur={() => validateFieldNow("email")}
                        className={
                          fieldErrors.email
                            ? "border-red-300 focus:border-red-400 focus:ring-red-100"
                            : "bg-white"
                        }
                        aria-invalid={Boolean(fieldErrors.email)}
                        data-checkout-field="email"
                        placeholder="you@example.com"
                        type="email"
                      />
                    </FieldBlock>
                  </div>
                </div>
              </Card>

              <Card className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <SectionTitle
                  icon={<MapPin className="h-5 w-5" />}
                  title="Delivery Address"
                  subtitle="District and police station calculate the shipping charge."
                />

                <div className="mt-5 grid gap-4">
                  <FieldBlock label="Address line 1" error={fieldErrors.line1}>
                    <Input
                      value={line1}
                      onChange={(e) => {
                        const value = e.target.value;
                        setLine1(value);
                        validateFieldNow("line1", { line1: value });
                      }}
                      onBlur={() => validateFieldNow("line1")}
                      className={
                        fieldErrors.line1
                          ? "border-red-300 focus:border-red-400 focus:ring-red-100"
                          : "bg-white"
                      }
                      aria-invalid={Boolean(fieldErrors.line1)}
                      data-checkout-field="line1"
                      placeholder="House, road, block"
                    />
                  </FieldBlock>

                  <FieldBlock label="Address line 2">
                    <Input
                      value={line2}
                      onChange={(e) => setLine2(e.target.value)}
                      className="bg-white"
                      placeholder="Apartment, landmark"
                    />
                  </FieldBlock>

                  <div className="grid gap-4 md:grid-cols-2">
                    <FieldBlock label="District" error={fieldErrors.city}>
                      <select
                        className={`h-11 w-full rounded-2xl border bg-white px-4 text-sm outline-none transition disabled:bg-slate-50 ${
                          fieldErrors.city
                            ? "border-red-300 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                            : "border-slate-200 focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                        }`}
                        value={city}
                        onChange={(e) => {
                          const value = e.target.value;
                          setCity(value);
                          setArea("");
                          validateFieldNow("city", { city: value, area: "" });
                          if (touchedFields.area) {
                            validateFieldNow("area", { city: value, area: "" });
                          }
                        }}
                        onBlur={() => validateFieldNow("city")}
                        aria-invalid={Boolean(fieldErrors.city)}
                        data-checkout-field="city"
                        disabled={districtsLoading || districts.length === 0}
                      >
                        <option value="">
                          {districtsLoading
                            ? "Loading districts..."
                            : districts.length > 0
                              ? "Select district"
                              : "No district found"}
                        </option>

                        {districts.map((district) => (
                          <option key={district.id} value={district.name}>
                            {district.name}
                          </option>
                        ))}
                      </select>
                    </FieldBlock>

                    <FieldBlock
                      label="Police station"
                      error={fieldErrors.area}
                    >
                      <select
                        className={`h-11 w-full rounded-2xl border bg-white px-4 text-sm outline-none transition disabled:bg-slate-50 ${
                          fieldErrors.area
                            ? "border-red-300 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                            : "border-slate-200 focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                        }`}
                        value={area}
                        onChange={(e) => {
                          const value = e.target.value;
                          setArea(value);
                          validateFieldNow("area", { area: value });
                        }}
                        onBlur={() => validateFieldNow("area")}
                        aria-invalid={Boolean(fieldErrors.area)}
                        data-checkout-field="area"
                        disabled={
                          !city ||
                          loadingPoliceStations ||
                          policeStations.length === 0
                        }
                      >
                        <option value="">
                          {loadingPoliceStations
                            ? "Loading police stations..."
                            : policeStations.length > 0
                              ? "Select police station"
                              : "No police station found"}
                        </option>

                        {policeStations.map((station) => (
                          <option key={station.id} value={station.name}>
                            {station.name}
                          </option>
                        ))}
                      </select>
                    </FieldBlock>
                  </div>

                  {districtsError ? (
                    <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                      {districtsError}
                    </div>
                  ) : null}

                  {policeStationsError ? (
                    <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                      {policeStationsError}
                    </div>
                  ) : null}

                  <FieldBlock label="Delivery note" error={fieldErrors.note}>
                    <Input
                      value={note}
                      onChange={(e) => {
                        const value = e.target.value;
                        setNote(value);
                        validateFieldNow("note", { note: value });
                      }}
                      onBlur={() => validateFieldNow("note")}
                      className={
                        fieldErrors.note
                          ? "border-red-300 focus:border-red-400 focus:ring-red-100"
                          : "bg-white"
                      }
                      aria-invalid={Boolean(fieldErrors.note)}
                      data-checkout-field="note"
                      placeholder="Call before delivery"
                    />
                  </FieldBlock>

                  <div className="grid gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm md:grid-cols-3">
                    <div>
                      <div className="text-xs font-medium text-slate-500">
                        District
                      </div>
                      <div className="mt-1 font-semibold text-slate-950">
                        {city || "Not selected"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs font-medium text-slate-500">
                        Police station
                      </div>
                      <div className="mt-1 font-semibold text-slate-950">
                        {area || "Not selected"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs font-medium text-slate-500">
                        Shipping
                      </div>
                      <div className="mt-1 font-semibold text-slate-950">
                        ৳ {totals.shipping}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <SectionTitle
                  icon={<WalletCards className="h-5 w-5" />}
                  title="Payment Method"
                  subtitle="Choose how you want to complete the order."
                />

                <div className="mt-5 grid gap-3">
                  {settings.codEnabled ? (
                    <label
                      className={`flex cursor-pointer items-center gap-3 rounded-2xl border p-4 transition ${
                        paymentMethod === "COD"
                          ? "border-[#d81b60] bg-[#fff1f5] shadow-sm"
                          : "border-slate-200 bg-white hover:bg-slate-50"
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment-method"
                        value="COD"
                        checked={paymentMethod === "COD"}
                        data-checkout-field="paymentMethod"
                        onChange={() => {
                          setPaymentMethod("COD");
                          validateFieldNow("paymentMethod", {
                            paymentMethod: "COD",
                          });
                        }}
                      />
                      <Truck className="h-5 w-5 text-[#ad1457]" />
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-950">
                          Cash on Delivery
                        </div>
                        <div className="text-xs text-slate-500">
                          Pay when your order is delivered
                        </div>
                      </div>
                    </label>
                  ) : null}

                  {settings.onlineEnabled ? (
                    <label
                      className={`flex cursor-pointer items-center gap-3 rounded-2xl border p-4 transition ${
                        paymentMethod === "ONLINE"
                          ? "border-[#d81b60] bg-[#fff1f5] shadow-sm"
                          : "border-slate-200 bg-white hover:bg-slate-50"
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment-method"
                        value="ONLINE"
                        checked={paymentMethod === "ONLINE"}
                        data-checkout-field="paymentMethod"
                        onChange={() => {
                          setPaymentMethod("ONLINE");
                          validateFieldNow("paymentMethod", {
                            paymentMethod: "ONLINE",
                          });
                        }}
                      />
                      <CreditCard className="h-5 w-5 text-sky-600" />
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-950">
                          Online Payment
                        </div>
                        <div className="text-xs text-slate-500">
                          Pay securely via SSLCommerz
                        </div>
                      </div>
                    </label>
                  ) : null}

                  {settings.manualPaymentEnabled &&
                  (settings.manualBkashNumber ||
                    settings.manualNagadNumber ||
                    settings.manualRocketNumber) ? (
                    <label
                      className={`flex cursor-pointer items-center gap-3 rounded-2xl border p-4 transition ${
                        paymentMethod === "MANUAL"
                          ? "border-[#d81b60] bg-[#fff1f5] shadow-sm"
                          : "border-slate-200 bg-white hover:bg-slate-50"
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment-method"
                        value="MANUAL"
                        checked={paymentMethod === "MANUAL"}
                        data-checkout-field="paymentMethod"
                        onChange={() => {
                          setPaymentMethod("MANUAL");
                          validateFieldNow("paymentMethod", {
                            paymentMethod: "MANUAL",
                          });
                        }}
                      />
                      <Phone className="h-5 w-5 text-emerald-600" />
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-950">
                          Manual Payment
                        </div>
                        <div className="text-xs text-slate-500">
                          Pay via bKash, Nagad or Rocket
                        </div>
                      </div>
                    </label>
                  ) : null}
                </div>
                <FieldError message={fieldErrors.paymentMethod} />

                {paymentMethod === "MANUAL" ? (
                  <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs text-emerald-800">
                    {settings.manualBkashNumber
                      ? `bKash: ${settings.manualBkashNumber}`
                      : ""}
                    {settings.manualNagadNumber
                      ? `${settings.manualBkashNumber ? " • " : ""}Nagad: ${
                          settings.manualNagadNumber
                        }`
                      : ""}
                    {settings.manualRocketNumber
                      ? `${
                          settings.manualBkashNumber ||
                          settings.manualNagadNumber
                            ? " • "
                            : ""
                        }Rocket: ${settings.manualRocketNumber}`
                      : ""}
                  </div>
                ) : null}
              </Card>

              <Card className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <SectionTitle
                  icon={<PackageCheck className="h-5 w-5" />}
                  title={isBuyNow ? "Selected Item" : "Items"}
                />
                <div className="mt-5 divide-y divide-slate-100">
                  {details.items.map((row) => {
                    const unit = row.product.offerPrice ?? row.product.price;
                    return (
                      <div
                        key={`${row.product.id}-${row.variantId ?? "base"}`}
                        className="flex items-center justify-between gap-4 py-3 first:pt-0 last:pb-0"
                      >
                        <div className="min-w-0">
                          <div className="line-clamp-1 text-sm font-semibold text-slate-950">
                            {row.product.name}
                          </div>
                          {row.variantLabel ? (
                            <div className="mt-1 text-xs text-slate-500">
                              {row.variantLabel}
                            </div>
                          ) : null}
                          <div className="mt-1 text-xs text-slate-500">
                            ৳ {unit} x {row.qty}
                          </div>
                        </div>
                        <div className="shrink-0 text-sm font-semibold text-slate-950">
                          ৳ {unit * row.qty}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            </div>

            <aside className="lg:sticky lg:top-24 lg:self-start">
              <Card className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <SectionTitle
                  icon={<ReceiptText className="h-5 w-5" />}
                  title="Order Summary"
                />

                <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-3">
                  <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-950">
                    <BadgePercent className="h-4 w-4 text-[#ad1457]" />
                    Coupon
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="bg-white"
                      placeholder="Enter coupon"
                    />
                    <Button
                      variant="secondary"
                      onClick={() => void applyCoupon()}
                      disabled={subtotal <= 0}
                    >
                      Apply
                    </Button>
                  </div>
                  {couponMsg ? (
                    <div className="mt-2 text-xs font-medium text-slate-500">
                      {couponMsg}
                    </div>
                  ) : null}
                </div>

                <div className="mt-5 space-y-3">
                  <SummaryRow
                    label="Subtotal"
                    value={`৳ ${totals.subtotal}`}
                  />
                  <SummaryRow
                    label="Discount"
                    value={`৳ ${totals.discount}`}
                  />
                  <SummaryRow
                    label={shippingLabel}
                    value={`৳ ${totals.shipping}`}
                  />
                  <SummaryRow label="Tax" value={`৳ ${totals.tax}`} />
                  <div className="border-t border-slate-200 pt-3">
                    <SummaryRow
                      label="Total"
                      value={`৳ ${totals.total}`}
                      strong
                    />
                  </div>
                </div>

                <div className="mt-4 rounded-2xl border border-sky-100 bg-sky-50 px-4 py-3 text-xs text-sky-800">
                  {settings.shippingFreeOver > 0
                    ? `Free shipping over ৳ ${settings.shippingFreeOver}`
                    : `Default shipping ৳ ${settings.shippingDefaultCharge}`}
                  {" • "}
                  {normalizeShippingRules(settings.shippingRules).length} custom
                  rules
                </div>

                <div
                  className={`mt-5 ${placeOrderDisabled ? "cursor-not-allowed" : ""}`}
                  onClick={
                    placeOrderDisabled ? handleBlockedPlaceOrderClick : undefined
                  }
                >
                  <Button
                    className="inline-flex w-full items-center justify-center gap-2 bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
                    onClick={() => void placeOrder()}
                    disabled={placeOrderDisabled}
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    {placing
                      ? paymentMethod === "ONLINE"
                        ? "Redirecting..."
                        : paymentMethod === "MANUAL"
                          ? "Opening payment..."
                          : "Placing order..."
                      : paymentMethod === "ONLINE"
                        ? "Pay Online"
                        : paymentMethod === "MANUAL"
                          ? "Continue to Payment"
                          : "Place Order"}
                  </Button>
                </div>

                <div className="mt-3 text-center text-xs text-slate-500">
                  By placing the order, you agree to our{" "}
                  <button
                    type="button"
                    onClick={() => setPolicyOpen(true)}
                    className="font-medium text-slate-800 underline underline-offset-2 hover:text-black"
                  >
                    Return and Refund Policy
                  </button>
                </div>
              </Card>
            </aside>
          </div>
        )}
      </div>
      <ReturnRefundPolicyModal
        open={policyOpen}
        onClose={() => setPolicyOpen(false)}
        content={settings.returnRefundPolicy}
      />
    </div>
  );
}
