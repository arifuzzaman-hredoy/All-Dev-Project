"use client";

import Image from "next/image";
import { useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "../ui/toast";

type SortKey = "latest" | "highest_rated";

type ReviewItem = {
  id: string;
  rating: number;
  comment: string | null;
  imageUrls: string[];
  createdAt: string;
  helpfulCount: number;
  user: { name: string | null };
  verified: boolean;
};

type ReviewsApiResponse = {
  reviews: ReviewItem[];
  average: number;
};

type VoteApiResponse = { voted: boolean };
type ToggleWishlistErr = { error: string };
const MAX_REVIEW_IMAGES = 5;

function safeNumber(v: unknown, fallback = 0): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeString(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function safeBool(v: unknown, fallback = false): boolean {
  return typeof v === "boolean" ? v : fallback;
}

function parseReviewsResponse(input: unknown): ReviewsApiResponse {
  const o = input as Record<string, unknown>;
  const raw = Array.isArray(o.reviews) ? o.reviews : [];
  const reviews: ReviewItem[] = raw
    .map((x) => x as Record<string, unknown>)
    .map((x) => {
      const userObj =
        (x.user as Record<string, unknown> | null | undefined) ?? null;
      return {
        id: safeString(x.id),
        rating: safeNumber(x.rating, 0),
        comment: typeof x.comment === "string" ? x.comment : null,
        imageUrls: Array.isArray(x.imageUrls)
          ? x.imageUrls
              .map((url) => safeString(url))
              .filter((url) => url.startsWith("/uploads/"))
          : [],
        createdAt: safeString(x.createdAt),
        helpfulCount: safeNumber(x.helpfulCount, 0),
        user: {
          name: userObj
            ? typeof userObj.name === "string"
              ? userObj.name
              : null
            : null,
        },
        verified: safeBool(x.verified, false),
      };
    })
    .filter((r) => r.id && r.rating >= 1 && r.rating <= 5);

  return {
    reviews,
    average: safeNumber(o.average, 0),
  };
}

function parseVoteResponse(input: unknown): VoteApiResponse | null {
  const o = input as Record<string, unknown>;
  if (typeof o.voted === "boolean") return { voted: o.voted };
  return null;
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function Stars({ value }: { value: number }) {
  const v = Math.round(value * 10) / 10;
  const full = Math.floor(v);
  const half = v - full >= 0.5;

  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => {
        const idx = i + 1;
        const filled = idx <= full;
        const isHalf = !filled && half && idx === full + 1;

        return (
          <span
            key={idx}
            className={`text-base ${filled || isHalf ? "text-amber-400" : "text-slate-200"}`}
          >
            {filled ? "★" : isHalf ? "★" : "☆"}
          </span>
        );
      })}
      <span className="ml-2 text-sm text-slate-500">{v.toFixed(1)}</span>
    </div>
  );
}

export default function ProductReviews({ productId }: { productId: string }) {
  const { status } = useSession();

  const [sort, setSort] = useState<SortKey>("latest");
  const [loading, setLoading] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  const [data, setData] = useState<ReviewsApiResponse>({
    reviews: [],
    average: 0,
  });

  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState<string>("");
  const [reviewImages, setReviewImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const { toast } = useToast();

  const fetchReviews = async (): Promise<void> => {
    setLoading(true);
    try {
      const r = await fetch(
        `/api/reviews?productId=${encodeURIComponent(productId)}&sort=${sort}`,
        {
          cache: "no-store",
        },
      );
      const j: unknown = await r.json().catch(() => null);
      setData(parseReviewsResponse(j));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchReviews();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId, sort]);

  useEffect(() => {
    const urls = reviewImages.map((file) => URL.createObjectURL(file));
    setImagePreviews(urls);

    return () => {
      urls.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [reviewImages]);

  const breakdown = useMemo(() => {
    const counts = [0, 0, 0, 0, 0];
    data.reviews.forEach((r) => {
      if (r.rating >= 1 && r.rating <= 5) counts[r.rating - 1] += 1;
    });
    const total = data.reviews.length || 1;
    return counts.map((c) => ({
      count: c,
      pct: Math.round((c / total) * 100),
    }));
  }, [data.reviews]);

  const handleImageChange = (files: FileList | null): void => {
    if (!files?.length) return;

    const selected = Array.from(files).filter((file) =>
      file.type.startsWith("image/"),
    );

    setReviewImages((prev) =>
      [...prev, ...selected].slice(0, MAX_REVIEW_IMAGES),
    );
  };

  const removeImage = (index: number): void => {
    setReviewImages((prev) => prev.filter((_, itemIndex) => itemIndex !== index));
  };

  const submitReview = async (): Promise<void> => {
    if (status !== "authenticated") {
      window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`;
      return;
    }
    if (rating < 1 || rating > 5) {
      return toast({
        variant: "error",
        title: "Failed",
        description: "Rating must be 1-5",
      });
    }
    if (!productId) return;

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.set("productId", productId);
      formData.set("rating", String(rating));
      formData.set("comment", comment.trim() ? comment.trim() : "");
      reviewImages.forEach((file) => {
        formData.append("images", file);
      });

      const r = await fetch("/api/reviews", {
        method: "POST",
        body: formData,
      });

      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        const msg = (j as ToggleWishlistErr | null)?.error || "Failed";
        throw new Error(msg);
      }

      setComment("");
      setRating(5);
      setReviewImages([]);
      await fetchReviews();

      toast({
        variant: "success",
        title: "Review submitted",
        description: "Your review has been submitted successfully.",
      });
    } catch (e) {
      toast({
        variant: "error",
        title: "Failed",
        description: e instanceof Error ? e.message : "Failed",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const voteHelpful = async (reviewId: string): Promise<void> => {
    if (status !== "authenticated") {
      window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`;
      return;
    }

    setData((prev) => ({
      ...prev,
      reviews: prev.reviews.map((r) =>
        r.id === reviewId ? { ...r, helpfulCount: r.helpfulCount + 1 } : r,
      ),
    }));

    try {
      const r = await fetch("/api/reviews/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reviewId }),
      });
      const j: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        throw new Error(
          (j as ToggleWishlistErr | null)?.error || "Vote failed",
        );
      }

      const parsed = parseVoteResponse(j);
      if (parsed && parsed.voted === false) {
        setData((prev) => ({
          ...prev,
          reviews: prev.reviews.map((x) =>
            x.id === reviewId
              ? { ...x, helpfulCount: Math.max(0, x.helpfulCount - 2) }
              : x,
          ),
        }));
      }
    } catch {
      setData((prev) => ({
        ...prev,
        reviews: prev.reviews.map((x) =>
          x.id === reviewId
            ? { ...x, helpfulCount: Math.max(0, x.helpfulCount - 1) }
            : x,
        ),
      }));
    }
  };

  return (
    <div className="grid gap-4">
      <div className="flex flex-col gap-2 px-5 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-2xl font-bold text-slate-950">Reviews</div>
          <div className="text-sm text-slate-500">
            {data.reviews.length} reviews
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-sm text-slate-500">Sort:</div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="rounded-2xl border border-[#f8bbd0] bg-white px-3 py-2 text-sm outline-none focus:border-[#d81b60]"
          >
            <option value="latest">Latest</option>
            <option value="highest_rated">Highest Rated</option>
          </select>
        </div>
      </div>

      <Card className="rounded-[28px] border-[#f8bbd0] bg-white p-4 shadow-sm">
        <div className="grid gap-4 md:grid-cols-[240px_1fr]">
          <div>
            <div className="text-sm font-semibold text-slate-900">
              Average rating
            </div>
            <div className="mt-2 flex items-center gap-3">
              <div className="text-4xl font-semibold">
                {(Math.round(data.average * 10) / 10).toFixed(1)}
              </div>
              <Stars value={data.average} />
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Based on {data.reviews.length} reviews
            </div>
          </div>

          <div className="grid gap-2">
            {[5, 4, 3, 2, 1].map((star) => {
              const idx = star - 1;
              const row = breakdown[idx];
              return (
                <div key={star} className="flex items-center gap-3">
                  <div className="w-12 text-xs text-slate-500">{star}★</div>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-[#fff1f5]">
                    <div
                      className="h-full bg-[#d81b60]"
                      style={{ width: `${row.pct}%` }}
                    />
                  </div>
                  <div className="w-10 text-right text-xs text-slate-500">
                    {row.count}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Card>

      <Card className="rounded-[28px] border-[#f8bbd0] bg-white p-4 shadow-sm">
        <div className="text-base font-semibold text-slate-900">
          Write a review
        </div>

        <div className="mt-3 space-y-3">
          <div>
            <div className="mb-1 text-sm text-slate-500">Rating</div>
            <select
              value={rating}
              onChange={(e) => setRating(Number(e.target.value))}
              className="w-full rounded-2xl border border-[#f8bbd0] bg-white px-3 py-2 text-sm outline-none focus:border-[#d81b60]"
            >
              <option value={5}>5 - Excellent</option>
              <option value={4}>4 - Very Good</option>
              <option value={3}>3 - Good</option>
              <option value={2}>2 - Fair</option>
              <option value={1}>1 - Poor</option>
            </select>
          </div>

          <div>
            <div className="mb-1 text-sm text-slate-500">Comment</div>
            <Input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Write your review"
            />
          </div>

          <div>
            <div className="mb-1 text-sm text-slate-500">Review images</div>
            <label className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-[#f8bbd0] bg-[#fff7fb] px-4 py-6 text-center text-sm text-slate-500 transition hover:border-[#d81b60] hover:bg-[#fff1f5]">
              <span className="font-medium text-slate-900">
                Upload product photos
              </span>
              <span className="mt-1 text-xs">
                PNG, JPG, JPEG, or WEBP. Up to {MAX_REVIEW_IMAGES} images.
              </span>
              <input
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                multiple
                className="sr-only"
                onChange={(e) => {
                  handleImageChange(e.currentTarget.files);
                  e.currentTarget.value = "";
                }}
              />
            </label>

            {imagePreviews.length ? (
              <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-5">
                {imagePreviews.map((url, index) => (
                  <div
                    key={`${url}-${index}`}
                    className="relative aspect-square overflow-hidden rounded-2xl border border-black/10 bg-white"
                  >
                    <Image
                      src={url}
                      alt={`Review image preview ${index + 1}`}
                      fill
                      className="object-cover"
                      sizes="96px"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute right-1 top-1 rounded-full bg-black/70 px-2 py-0.5 text-xs font-medium text-white transition hover:bg-black"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            ) : null}
          </div>

          <Button onClick={() => void submitReview()} disabled={submitting}>
            {submitting ? "Submitting..." : "Submit Review"}
          </Button>
        </div>
      </Card>

      <div className="space-y-3">
        {loading ? (
            <Card className="rounded-3xl border-[#f8bbd0] p-4 text-sm text-slate-500">
            Loading reviews...
          </Card>
        ) : data.reviews.length === 0 ? (
          <Card className="rounded-3xl border-[#f8bbd0] p-4 text-sm text-slate-500">
            No reviews yet.
          </Card>
        ) : (
          data.reviews.map((review) => (
            <Card key={review.id} className="rounded-3xl border-[#f8bbd0] bg-white p-4 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="font-semibold">
                      {review.user.name || "Anonymous"}
                    </div>
                    {review.verified ? (
                      <span className="rounded-full bg-black/5 px-2 py-0.5 text-[11px] text-black/60">
                        Verified Purchase
                      </span>
                    ) : null}
                  </div>

                  <div className="mt-1 flex items-center gap-2">
                    <Stars value={review.rating} />
                  </div>

                  <div className="mt-1 text-xs text-black/50">
                    {formatDate(review.createdAt)}
                  </div>
                </div>

                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => void voteHelpful(review.id)}
                >
                  Helpful ({review.helpfulCount})
                </Button>
              </div>

              {review.comment ? (
                <p className="mt-3 whitespace-pre-line text-sm leading-6 text-black/70">
                  {review.comment}
                </p>
              ) : null}

              {review.imageUrls.length ? (
                <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-5">
                  {review.imageUrls.map((url, index) => (
                    <a
                      key={`${review.id}-${url}`}
                      href={url}
                      target="_blank"
                      rel="noreferrer"
                      className="relative aspect-square overflow-hidden rounded-2xl border border-black/10 bg-black/5"
                    >
                      <Image
                        src={url}
                        alt={`Review image ${index + 1}`}
                        fill
                        className="object-cover transition-transform hover:scale-105"
                        sizes="(max-width: 640px) 30vw, 120px"
                      />
                    </a>
                  ))}
                </div>
              ) : null}
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
