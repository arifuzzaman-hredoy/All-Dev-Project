"use client";

import Link from "next/link";
import { ArrowRight, ChevronRight } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export type PageHeroAction = {
    href: string;
    label: string;
    variant?: "primary" | "secondary";
};

export type PageHeroStat = {
    label: string;
    value: string;
};

type Breadcrumb = {
    label: string;
    href?: string;
};

type PageHeroProps = {
    eyebrow?: string;
    title: string;
    description: string;
    breadcrumbs?: Breadcrumb[];
    actions?: PageHeroAction[];
    stats?: PageHeroStat[];
    className?: string;
    contentClassName?: string;
    align?: "left" | "center";
    children?: ReactNode;
};

export default function PageHero({
    eyebrow = "SiamsBay",
    title,
    description,
    breadcrumbs = [],
    actions = [],
    stats = [],
    className,
    contentClassName,
    align = "left",
    children,
}: PageHeroProps) {
    const centered = align === "center";

    return (
        <section
            className={cn(
                "relative overflow-hidden rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff1f5] via-[#ffe4ec] to-white shadow-[0_18px_60px_-40px_rgba(216,27,96,0.35)]",
                className,
            )}
        >
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(216,27,96,0.08),transparent_28%),radial-gradient(circle_at_bottom_left,rgba(236,72,153,0.08),transparent_30%)]" />

            <div
                className={cn(
                    "relative px-6 py-10 sm:px-8 sm:py-12",
                    centered && "text-center",
                    contentClassName,
                )}
            >
                {breadcrumbs.length ? (
                    <div
                        className={cn(
                            "mb-4 flex flex-wrap items-center gap-2 text-xs text-slate-500",
                            centered && "justify-center",
                        )}
                    >
                        {breadcrumbs.map((crumb, index) => {
                            const isLast = index === breadcrumbs.length - 1;

                            return (
                                <div
                                    key={`${crumb.label}-${index}`}
                                    className="flex items-center gap-2"
                                >
                                    {crumb.href && !isLast ? (
                                        <Link
                                            href={crumb.href}
                                            className="transition hover:text-[#ad1457]"
                                        >
                                            {crumb.label}
                                        </Link>
                                    ) : (
                                        <span className="font-medium text-slate-700">
                                            {crumb.label}
                                        </span>
                                    )}

                                    {!isLast ? <ChevronRight className="h-3 w-3" /> : null}
                                </div>
                            );
                        })}
                    </div>
                ) : null}

                <div className={cn("mt-4 max-w-3xl", centered && "mx-auto")}>
                    <h1 className="text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl lg:text-5xl">
                        {title}
                    </h1>
                    <p className="mt-4 text-sm leading-7 text-slate-700 sm:text-base">
                        {description}
                    </p>

                    {actions.length ? (
                        <div
                            className={cn(
                                "mt-6 flex flex-wrap gap-3",
                                centered && "justify-center",
                            )}
                        >
                            {actions.map((action) => {
                                const isSecondary = action.variant === "secondary";

                                return (
                                    <Link
                                        key={`${action.href}-${action.label}`}
                                        href={action.href}
                                        className={cn(
                                            "group inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-medium transition",
                                            isSecondary
                                                ? "border border-[#f8bbd0] bg-white/75 text-[#ad1457] hover:bg-[#fff1f5]"
                                                : "bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]",
                                        )}
                                    >
                                        <span>{action.label}</span>
                                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                                    </Link>
                                );
                            })}
                        </div>
                    ) : null}
                </div>

                {stats.length ? (
                    <div className="mt-8 grid gap-3 grid-cols-2 xl:grid-cols-4">
                        {stats.map((stat) => (
                            <div
                                key={stat.label}
                                className="rounded-2xl border border-[#f8bbd0] bg-white/75 p-4 text-left shadow-[0_12px_34px_-24px_rgba(216,27,96,0.28)] backdrop-blur"
                            >
                                <div className="text-2xl font-bold text-[#d81b60]">
                                    {stat.value}
                                </div>
                                <div className="mt-1 text-sm text-slate-600">{stat.label}</div>
                            </div>
                        ))}
                    </div>
                ) : null}

                {children}
            </div>
        </section>
    );
}
