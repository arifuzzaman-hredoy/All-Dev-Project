import Link from "next/link";
import { prisma } from "@/lib/prisma";
import {
  Phone,
  Mail,
  MapPin,
  ShoppingBag,
  Heart,
  PackageCheck,
  HelpCircle,
} from "lucide-react";
import Image from "next/image";

type SocialItem = {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  brandClass: string;
};

type FooterLink = {
  label: string;
  href: string;
  icon?: React.ComponentType<{ className?: string }>;
};

type FaqItem = {
  question: string;
  answer: string;
};

function FacebookBrandIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      <path
        fill="currentColor"
        d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.03 3.66 9.2 8.44 9.94v-7.03H7.9v-2.91h2.54V9.84c0-2.52 1.49-3.91 3.77-3.91 1.09 0 2.23.2 2.23.2v2.47h-1.25c-1.24 0-1.63.77-1.63 1.57v1.89h2.77l-.44 2.91h-2.33V22C18.34 21.26 22 17.09 22 12.06Z"
      />
    </svg>
  );
}

function InstagramBrandIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      <path
        fill="currentColor"
        d="M7.8 2h8.4A5.8 5.8 0 0 1 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8A5.8 5.8 0 0 1 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2Zm-.2 2A3.6 3.6 0 0 0 4 7.6v8.8A3.6 3.6 0 0 0 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6A3.6 3.6 0 0 0 16.4 4H7.6Zm9.65 1.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5ZM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"
      />
    </svg>
  );
}

function YoutubeBrandIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      <path
        fill="currentColor"
        d="M23.5 6.2a3 3 0 0 0-2.12-2.12C19.5 3.58 12 3.58 12 3.58s-7.5 0-9.38.5A3 3 0 0 0 .5 6.2 31.2 31.2 0 0 0 0 12a31.2 31.2 0 0 0 .5 5.8 3 3 0 0 0 2.12 2.12c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3 3 0 0 0 2.12-2.12A31.2 31.2 0 0 0 24 12a31.2 31.2 0 0 0-.5-5.8ZM9.6 15.57V8.43L15.83 12 9.6 15.57Z"
      />
    </svg>
  );
}

function TiktokBrandIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      <path
        fill="currentColor"
        d="M16.6 5.82A5.64 5.64 0 0 1 15.74 2h-3.5v13.93a2.93 2.93 0 1 1-2.1-2.8V9.57a6.42 6.42 0 1 0 5.6 6.36V8.87a9.08 9.08 0 0 0 5.32 1.7V7.08a5.58 5.58 0 0 1-4.46-1.26Z"
      />
    </svg>
  );
}

function WhatsappBrandIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      <path
        fill="currentColor"
        d="M20.52 3.48A11.84 11.84 0 0 0 12.1 0C5.54 0 .21 5.33.21 11.89c0 2.1.55 4.15 1.6 5.95L.1 24l6.3-1.65a11.86 11.86 0 0 0 5.69 1.45h.01c6.56 0 11.89-5.33 11.89-11.89a11.84 11.84 0 0 0-3.47-8.43ZM12.1 21.8h-.01a9.86 9.86 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.87 9.87 0 0 1-1.51-5.28C2.21 6.43 6.65 2 12.1 2a9.82 9.82 0 0 1 6.99 2.9 9.82 9.82 0 0 1 2.9 7c0 5.45-4.43 9.9-9.89 9.9Zm5.43-7.41c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.08-.3-.15-1.25-.46-2.38-1.46a8.9 8.9 0 0 1-1.64-2.04c-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.91-2.2-.24-.58-.48-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.09 1.76-.72 2-1.41.25-.7.25-1.3.18-1.42-.08-.13-.27-.2-.57-.35Z"
      />
    </svg>
  );
}

const fallbackFaqs: FaqItem[] = [
  {
    question: "How can I place an order?",
    answer:
      "Choose a product, add it to your cart, and complete checkout with your delivery information.",
  },
  {
    question: "Can I track my order?",
    answer:
      "Yes. Use the Orders page after login, or contact us with your order phone number.",
  },
  {
    question: "How do I contact support?",
    answer:
      "Call, email, or message us on WhatsApp from the contact links in this footer.",
  },
];

function normalizeUrl(url: string | null | undefined): string {
  const value = (url || "").trim();
  if (!value) return "";

  if (
    value.startsWith("http://") ||
    value.startsWith("https://") ||
    value.startsWith("mailto:") ||
    value.startsWith("tel:")
  ) {
    return value;
  }

  return `https://${value}`;
}

function normalizeFaqs(input: unknown): FaqItem[] {
  if (typeof input === "string") {
    try {
      return normalizeFaqs(JSON.parse(input));
    } catch {
      return [];
    }
  }

  if (!Array.isArray(input)) return [];

  return input
    .map((item) => {
      const record = item as Record<string, unknown>;

      return {
        question:
          typeof record.question === "string" ? record.question.trim() : "",
        answer: typeof record.answer === "string" ? record.answer.trim() : "",
      };
    })
    .filter((item) => item.question && item.answer);
}

export default async function SiteFooter() {
  const settings = await prisma.storeSettings.findUnique({
    where: { id: "default" },
    select: {
      storeName: true,
      logoUrl: true,
      facebookUrl: true,
      instagramUrl: true,
      youtubeUrl: true,
      tiktokUrl: true,
      whatsappUrl: true,
      aboutFaqs: true,
    },
  });

  const storeName = settings?.storeName?.trim() || "SiamsBay";
  const branding = {
    storeName,
    logoUrl: settings?.logoUrl?.trim() || "",
  };

  const faqs = normalizeFaqs(settings?.aboutFaqs).slice(0, 4);
  const footerFaqs = faqs.length ? faqs : fallbackFaqs;

  const socialLinks: SocialItem[] = [
    {
      label: "Facebook",
      href: normalizeUrl(settings?.facebookUrl),
      icon: FacebookBrandIcon,
      brandClass: "text-[#1877f2] hover:border-[#1877f2] hover:bg-[#1877f2]",
    },
    {
      label: "Instagram",
      href: normalizeUrl(settings?.instagramUrl),
      icon: InstagramBrandIcon,
      brandClass: "text-[#e4405f] hover:border-[#e4405f] hover:bg-[#e4405f]",
    },
    {
      label: "YouTube",
      href: normalizeUrl(settings?.youtubeUrl),
      icon: YoutubeBrandIcon,
      brandClass: "text-[#ff0000] hover:border-[#ff0000] hover:bg-[#ff0000]",
    },
    {
      label: "TikTok",
      href: normalizeUrl(settings?.tiktokUrl),
      icon: TiktokBrandIcon,
      brandClass: "text-[#000000] hover:border-[#000000] hover:bg-[#000000]",
    },
    {
      label: "WhatsApp",
      href:
        normalizeUrl(settings?.whatsappUrl) || "https://wa.me/8801331960139",
      icon: WhatsappBrandIcon,
      brandClass: "text-[#25d366] hover:border-[#25d366] hover:bg-[#25d366]",
    },
  ].filter((item) => item.href);

  const shopLinks: FooterLink[] = [
    { label: "All Products", href: "/products", icon: ShoppingBag },
    {
      label: "Limited Offers",
      href: "/products?offer=limited",
      icon: PackageCheck,
    },
    {
      label: "Best Sellers",
      href: "/products?sort=best-seller",
      icon: PackageCheck,
    },
    { label: "Wishlist", href: "/wishlist", icon: Heart },
    { label: "Cart", href: "/cart", icon: ShoppingBag },
    { label: "My Orders", href: "/orders", icon: PackageCheck },
  ];

  const supportLinks: FooterLink[] = [
    { label: "About Us", href: "/about-us" },
    { label: "Customer Reviews", href: "/reviews" },
    { label: "Contact", href: "/contact" },
    { label: "Privacy Policy", href: "/privacy-policy" },
    { label: "Terms & Conditions", href: "/terms-conditions" },
  ];

  return (
    <footer className="border-t border-pink-100 bg-gradient-to-b from-[#fff7fb] to-white">
      <div className="mx-auto max-w-7xl px-4 py-16 lg:px-6">
        {/* TOP GRID */}
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4">
          {/* BRAND */}
          <div className="space-y-6">
            <div>
              {/* Logo */}
              <Link href="/" className="group flex shrink-0 items-center gap-3">
                {branding.logoUrl ? (
                  <div className="relative h-16 w-16 shrink-0 transition-transform group-hover:scale-105 sm:h-18 sm:w-18">
                    <Image
                      src={branding.logoUrl}
                      alt={`${branding.storeName} logo`}
                      fill
                      sizes="72px"
                      className="object-contain"
                      priority
                    />
                  </div>
                ) : (
                  <span className="text-base font-semibold tracking-wide text-slate-900">
                    {branding.storeName}
                  </span>
                )}
              </Link>

              <h2 className="text-2xl font-bold tracking-tight text-slate-900">
                {storeName}
              </h2>
              <p className="mt-3 text-sm leading-6 text-slate-600">
                Trusted online shopping with fast delivery, secure payments, and
                quality products.
              </p>
            </div>

            {/* SOCIAL */}
            <div>
              <div className="text-sm font-semibold text-slate-900 mb-3">
                Follow Us
              </div>
              <div className="flex gap-3">
                {socialLinks.map((item) => {
                  const Icon = item.icon;
                  return (
                    <a
                      key={item.label}
                      href={item.href}
                      target="_blank"
                      rel="noreferrer"
                      aria-label={item.label}
                      title={item.label}
                      className={`group flex h-10 w-10 items-center justify-center rounded-full border border-pink-100 bg-white shadow-sm transition hover:text-white ${item.brandClass}`}
                    >
                      <Icon className="h-5 w-5 transition-transform group-hover:scale-110" />
                    </a>
                  );
                })}
              </div>
            </div>

            {/* TRUST BADGE */}
            <div className="rounded-xl border border-pink-100 bg-white px-4 py-3 text-sm text-slate-600 shadow-sm">
              🔒 Secure Checkout <br />
              🚚 Fast Delivery Across Bangladesh
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 sm:col-span-2 lg:col-span-2">
            {/* SHOP */}
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Shop</h3>
              <div className="mt-4 space-y-3 text-sm text-slate-600">
                {shopLinks.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="block transition hover:text-[#d81b60] hover:translate-x-1"
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>

            {/* CUSTOMER CARE */}
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Customer Care
              </h3>
              <div className="mt-4 space-y-3 text-sm text-slate-600">
                {supportLinks.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="block transition hover:text-[#d81b60] hover:translate-x-1"
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* FAQ / HELP */}
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Help & FAQ</h3>

            <div className="mt-4 space-y-3">
              {footerFaqs.slice(0, 3).map((faq, i) => (
                <details
                  key={i}
                  className="group rounded-lg border border-pink-100 bg-white px-3 py-2 text-sm"
                >
                  <summary className="cursor-pointer font-medium text-slate-800 group-open:text-[#d81b60]">
                    {faq.question}
                  </summary>
                  <p className="mt-2 text-slate-600">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </div>

        {/* DIVIDER */}
        <div className="my-10 h-px bg-pink-100" />

        {/* BOTTOM BAR */}
        <div className="flex flex-col gap-4 text-sm text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {storeName}. All rights reserved.
          </p>

          <div className="flex flex-wrap gap-4">
            <Link href="/privacy-policy" className="hover:text-[#d81b60]">
              Privacy
            </Link>
            <Link href="/terms-conditions" className="hover:text-[#d81b60]">
              Terms
            </Link>
            <Link href="/contact" className="hover:text-[#d81b60]">
              Contact
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
