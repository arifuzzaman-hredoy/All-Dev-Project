"use client";

import { useEffect } from "react";
import {
  getGoogleFontsHref,
  getSiteFontStack,
  resolveBanglaFont,
  resolveSiteFont,
} from "@/lib/site-fonts";

const FONT_LINK_ID = "siamsbay-google-fonts";
const FONT_CHANGE_EVENT = "siamsbay:font-settings-changed";

type FontSettings = {
  siteFontFamily?: unknown;
  banglaFontFamily?: unknown;
};

function applyFonts(settings: FontSettings) {
  const siteFont = resolveSiteFont(settings.siteFontFamily);
  const banglaFont = resolveBanglaFont(settings.banglaFontFamily);
  const href = getGoogleFontsHref([siteFont, banglaFont]);

  let link = document.getElementById(FONT_LINK_ID) as HTMLLinkElement | null;

  if (!link) {
    link = document.createElement("link");
    link.id = FONT_LINK_ID;
    link.rel = "stylesheet";
    document.head.appendChild(link);
  }

  if (link.href !== href) {
    link.href = href;
  }

  const stack = getSiteFontStack(siteFont.value, banglaFont.value);
  document.documentElement.style.setProperty("--site-font-family", stack);
  document.body.style.fontFamily = stack;
}

function getFontSettingsFromEvent(event: Event): FontSettings | null {
  if (!(event instanceof CustomEvent)) return null;

  const detail = event.detail;
  if (!detail || typeof detail !== "object") return null;

  return detail as FontSettings;
}

export function SiteFontProvider() {
  useEffect(() => {
    let alive = true;

    const load = async () => {
      try {
        const res = await fetch("/api/store/settings/public", {
          cache: "no-store",
        });
        const data: unknown = await res.json().catch(() => null);

        if (!alive || !res.ok || !data || typeof data !== "object") {
          applyFonts({});
          return;
        }

        applyFonts(data as FontSettings);
      } catch {
        if (alive) applyFonts({});
      }
    };

    const onFontChange = (event: Event) => {
      const settings = getFontSettingsFromEvent(event);
      if (settings) applyFonts(settings);
    };

    void load();
    window.addEventListener(FONT_CHANGE_EVENT, onFontChange);

    return () => {
      alive = false;
      window.removeEventListener(FONT_CHANGE_EVENT, onFontChange);
    };
  }, []);

  return null;
}
