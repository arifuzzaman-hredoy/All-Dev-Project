import Link from "next/link";
import { prisma } from "@/lib/prisma";
import CategoryGrid from "@/components/home/category-grid";
import { ArrowRight } from "lucide-react";

type SliderCategory = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  imageUrl: string | null;
  parent: {
    id: string;
    name: string;
    slug: string;
  } | null;
  _count: {
    products: number;
    children: number;
  };
};

export default async function ShopByCategory() {
  const [categories] = await Promise.all([
    prisma.category.findMany({
      where: {
        isActive: true,
      },
      orderBy: [{ parentId: "asc" }, { name: "asc" }],
      select: {
        id: true,
        name: true,
        slug: true,
        parentId: true,
        imageUrl: true,
        parent: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
        _count: {
          select: {
            products: true,
            children: true,
          },
        },
      },
    }),
    prisma.product.count({
      where: {
        isActive: true,
      },
    }),
  ]);

  const sliderCategories = categories.filter((category) => !category.parentId);

  if (!sliderCategories.length) return null;

  return (
    <section className="space-y-6">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h2 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            <span>Categories</span>
          </h2>
        </div>

        <Link
          href="/categories"
          className="group flex items-center gap-2 rounded-sm bg-[#fff1f5] px-5 py-2.5 text-sm font-medium text-[#ad1457] transition-all ring-1 ring-[#f8bbd0] hover:bg-[#ffe4ec] hover:text-[#8e1042]"
        >
          <span>View all</span>
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </Link>
      </div>

      <CategoryGrid categories={sliderCategories} />
    </section>
  );
}
