import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { notifyReviewSubmitted } from "@/lib/notifications";
import { uploadImageToLocalUploads } from "@/lib/local-uploads";

type ErrorResponse = { error: string };

type ReviewListItem = {
  id: string;
  rating: number;
  comment: string | null;
  imageUrls: string[];
  createdAt: string;
  helpfulCount: number;
  user: { name: string | null };
  verified: boolean;
};

type ReviewListResponse = {
  reviews: ReviewListItem[];
  average: number;
};

type CreateBody = {
  productId: string;
  rating: number;
  comment?: string | null;
  imageUrls?: string[];
  imageFiles?: File[];
};

type SortKey = "latest" | "highest_rated";
const MAX_REVIEW_IMAGES = 5;

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function isValidRating(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v) && v >= 1 && v <= 5;
}

function parseRating(value: unknown): number | null {
  if (typeof value === "number" && isValidRating(value)) return value;
  if (typeof value !== "string") return null;

  const rating = Number(value);
  return isValidRating(rating) ? rating : null;
}

async function parseCreateBody(req: NextRequest): Promise<Partial<CreateBody>> {
  const contentType = req.headers.get("content-type") || "";

  if (!contentType.includes("multipart/form-data")) {
    const bodyUnknown: unknown = await req.json().catch(() => null);
    return bodyUnknown as Partial<CreateBody>;
  }

  const form = await req.formData();
  const productId = form.get("productId");
  const rating = parseRating(form.get("rating"));
  const comment = form.get("comment");
  const imageFiles = form
    .getAll("images")
    .filter((item): item is File => item instanceof File && item.size > 0)
    .slice(0, MAX_REVIEW_IMAGES);

  return {
    productId: typeof productId === "string" ? productId : "",
    rating: rating ?? 0,
    comment: typeof comment === "string" ? comment : null,
    imageFiles,
  };
}

function parseSort(v: string | null): SortKey {
  if (v === "highest_rated") return "highest_rated";
  return "latest";
}

async function requireUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions);

  const userId = session?.user?.id;
  if (!userId || !isNonEmptyString(userId)) return null;

  return userId;
}

export async function GET(
  req: NextRequest,
): Promise<NextResponse<ReviewListResponse | ErrorResponse>> {
  const { searchParams } = new URL(req.url);

  const productId = searchParams.get("productId");
  const sort = parseSort(searchParams.get("sort"));

  if (!isNonEmptyString(productId)) {
    return NextResponse.json({ error: "productId required" }, { status: 400 });
  }

  const orderBy: Prisma.ReviewOrderByWithRelationInput =
    sort === "highest_rated"
      ? { rating: Prisma.SortOrder.desc }
      : { createdAt: Prisma.SortOrder.desc };

  const reviews = await prisma.review.findMany({
    where: { productId: productId.trim() },
    orderBy,
    select: {
      id: true,
      rating: true,
      comment: true,
      imageUrls: true,
      createdAt: true,
      authorName: true,
      userId: true,
      productId: true,
      isVerifiedPurchase: true,
    },
  });

  const average =
    reviews.length > 0
      ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
      : 0;

  const voteCounts = await prisma.reviewVote.groupBy({
    by: ["reviewId"],
    _count: { reviewId: true },
    where: { reviewId: { in: reviews.map((r) => r.id) } },
  });

  const voteMap = new Map<string, number>();
  voteCounts.forEach((v) => voteMap.set(v.reviewId, v._count.reviewId));

  const userIds = Array.from(
    new Set(reviews.map((r) => r.userId).filter((id): id is string => !!id)),
  );
  const users = await prisma.user.findMany({
    where: { id: { in: userIds } },
    select: { id: true, name: true },
  });

  const userMap = new Map<string, string | null>();
  users.forEach((u) => userMap.set(u.id, u.name ?? null));

  const formatted: ReviewListItem[] = reviews.map((r) => ({
    id: r.id,
    rating: r.rating,
    comment: r.comment,
    imageUrls: r.imageUrls,
    createdAt: r.createdAt.toISOString(),
    helpfulCount: voteMap.get(r.id) ?? 0,
    user: {
      name: r.authorName || (r.userId ? (userMap.get(r.userId) ?? null) : null),
    },
    verified: !!r.isVerifiedPurchase,
  }));

  return NextResponse.json({ reviews: formatted, average });
}

export async function POST(
  req: NextRequest,
): Promise<NextResponse<{ ok: true } | ErrorResponse>> {
  const userId = await requireUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Partial<CreateBody>;

  try {
    body = await parseCreateBody(req);
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to upload review images";
    return NextResponse.json({ error: message }, { status: 400 });
  }

  if (!isNonEmptyString(body?.productId)) {
    return NextResponse.json({ error: "productId required" }, { status: 400 });
  }
  if (!isValidRating(body?.rating)) {
    return NextResponse.json({ error: "rating must be 1-5" }, { status: 400 });
  }

  const productId = body.productId.trim();
  const rating = body.rating;
  const comment = typeof body.comment === "string" ? body.comment.trim() : null;
  const providedImageUrls = Array.isArray(body.imageUrls)
    ? body.imageUrls
        .map((url) => (typeof url === "string" ? url.trim() : ""))
        .filter((url) => url.startsWith("/uploads/"))
        .slice(0, MAX_REVIEW_IMAGES)
    : [];

  const existing = await prisma.review.findFirst({
    where: { userId, productId },
    select: { id: true },
  });

  if (existing) {
    return NextResponse.json({ error: "Already reviewed" }, { status: 400 });
  }

  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: {
      id: true,
      name: true,
      slug: true,
    },
  });

  if (!product) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      email: true,
    },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  const delivered = await prisma.orderItem.findFirst({
    where: {
      productId,
      order: {
        userId,
        status: "DELIVERED",
      },
    },
    select: { id: true },
  });

  const uploadedImageUrls = body.imageFiles?.length
    ? await Promise.all(
        body.imageFiles.map((file) => uploadImageToLocalUploads(file, "reviews")),
      )
    : [];

  const imageUrls = [...providedImageUrls, ...uploadedImageUrls].slice(
    0,
    MAX_REVIEW_IMAGES,
  );

  await prisma.review.create({
    data: {
      productId,
      userId,
      rating,
      comment,
      imageUrls,
      isVerifiedPurchase: !!delivered,
    },
  });

  await notifyReviewSubmitted({
    userId: user.id,
    slug: product.slug,
    productName: product.name,
    rating,
    customerName: user.name,
    customerEmail: user.email,
  });

  return NextResponse.json({ ok: true }, { status: 201 });
}
