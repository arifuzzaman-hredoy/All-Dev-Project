import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import PageHero from "@/components/layout/page-hero";
import FAQSection from "@/components/shared/faq-section";

export default async function AboutPage() {
  const [settings, productCount, orderCount, deliveredCount, categoryCount] =
    await Promise.all([
      prisma.storeSettings.findUnique({
        where: { id: "default" },
        select: {
          storeName: true,
          aboutUs: true,
          aboutFaqs: true,
        },
      }),
      prisma.product.count({
        where: { isActive: true },
      }),
      prisma.order.count(),
      prisma.order.count({
        where: { status: "DELIVERED" },
      }),
      prisma.category.count({
        where: { isActive: true },
      }),
    ]);

  const stats = [
    { label: "Products", value: String(productCount) },
    { label: "Orders", value: String(orderCount) },
    { label: "Delivered Orders", value: String(deliveredCount) },
    { label: "Categories", value: String(categoryCount) },
  ];

  return (
    <div className="space-y-12 pb-10">
      <PageHero
        eyebrow="About Us"
        title="A trusted eCommerce experience built for simplicity and confidence."
        description={
          settings?.aboutUs?.trim() ||
          `${settings?.storeName || "SiamsBay"} is committed to making online shopping easier, safer, and more dependable. We focus on trusted products, clear information, and a smooth customer experience from browsing to delivery.`
        }
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "About Us" }]}
        actions={[
          { href: "/products", label: "Explore products" },
          { href: "/contact", label: "Contact us", variant: "secondary" },
        ]}
        stats={stats}
        align="center"
      />

      <section className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.25)] sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
            Our Story
          </p>
          <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            We focus on trust, convenience, and better online service
          </h2>
          <p className="mt-4 text-sm leading-7 text-slate-700 sm:text-base">
            We believe eCommerce should feel simple, helpful, and dependable.
            That is why we focus on providing clear product information,
            authentic items, and a customer-first shopping experience.
          </p>
          <p className="mt-4 text-sm leading-7 text-slate-700 sm:text-base">
            From product discovery to final delivery, our goal is to make every
            step smooth and trustworthy for customers across Bangladesh.
          </p>
        </Card>

        <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-[#ffe4ec] to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.22)] sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
            Why Customers Choose Us
          </p>
          <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            A simple platform with reliable products and dependable support
          </h2>

          <div className="mt-6 space-y-3">
            <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
              <div className="text-sm font-semibold">Trusted Products</div>
              <div className="mt-1 text-sm text-slate-700">
                Carefully selected products with quality and reliability in
                mind.
              </div>
            </div>

            <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
              <div className="text-sm font-semibold">Smooth Experience</div>
              <div className="mt-1 text-sm text-slate-700">
                Easy browsing, secure checkout, and customer-friendly ordering.
              </div>
            </div>

            <div className="rounded-2xl border border-[#f8bbd0] bg-white/80 p-4">
              <div className="text-sm font-semibold">Responsive Support</div>
              <div className="mt-1 text-sm text-slate-700">
                We aim to help customers with product guidance and order help.
              </div>
            </div>
          </div>
        </Card>
      </section>

      <FAQSection />

      <section className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff1f5] via-[#ffe4ec] to-white px-6 py-10 text-center shadow-[0_18px_60px_-44px_rgba(216,27,96,0.22)] sm:px-10 sm:py-14">
        <p className="text-sm font-semibold uppercase tracking-wide text-[#ad1457]">
          Let’s Get Started
        </p>
        <h2 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
          Discover products that make shopping easier and more reliable
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-slate-700 sm:text-base">
          Browse our collection and enjoy a smooth shopping experience built on
          trust, simplicity, and dependable service.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/products"
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#d81b60] px-5 py-3 text-sm font-medium text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] transition hover:bg-[#c2185b]"
          >
            Shop Now
          </Link>
          <Link
            href="/orders"
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-[#f8bbd0] bg-white/75 px-5 py-3 text-sm font-medium text-[#ad1457] transition hover:bg-[#fff1f5]"
          >
            View Orders
          </Link>
        </div>
      </section>
    </div>
  );
}
