import Link from "next/link";
import { notFound } from "next/navigation";

import InvoicePrintButton from "@/components/admin/orders/invoice-print-button";
import OrderInvoiceDocument from "@/components/invoices/order-invoice-document";
import { prisma } from "@/lib/prisma";

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function getReadableOrderId(order: {
  id: string;
  publicOrderId?: string | null;
}) {
  return order.publicOrderId?.trim() || order.id;
}

export default async function AdminInvoicePage({
  params,
}: {
  params: Promise<{ id?: string }> | { id?: string };
}) {
  const resolvedParams = params instanceof Promise ? await params : params;
  const id = resolvedParams?.id;

  if (!isNonEmptyString(id)) return notFound();

  const [order, settings] = await Promise.all([
    prisma.order.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            variant: {
              select: {
                type: true,
                value: true,
              },
            },
          },
        },
      },
    }),
    prisma.storeSettings.findUnique({
      where: { id: "default" },
      select: {
        storeName: true,
        logoUrl: true,
      },
    }),
  ]);

  if (!order) return notFound();

  const displayOrderId = getReadableOrderId(order);
  const storeName = settings?.storeName?.trim() || "SiamsBay";
  const storeLogo = settings?.logoUrl?.trim() || "/logo.png";

  return (
    <>
      <style>{`
        @page {
          size: A4 portrait;
          margin: 8mm;
        }

        @media print {
          html,
          body {
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          body * {
            visibility: hidden !important;
          }

          #invoice-print-root,
          #invoice-print-root * {
            visibility: visible !important;
          }

          #invoice-print-root {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            right: 0 !important;
            margin: 0 auto !important;
            padding: 0 !important;
            background: #ffffff !important;
          }

          .no-print {
            display: none !important;
          }

          .invoice-shell {
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            padding: 0 !important;
          }

          .invoice-card {
            width: 194mm !important;
            max-width: 194mm !important;
            min-height: 0 !important;
            height: auto !important;
            max-height: none !important;
            margin: 0 auto !important;
            border-radius: 5mm !important;
            box-shadow: none !important;
            overflow: visible !important;
            break-inside: auto !important;
            page-break-inside: auto !important;
            page-break-after: auto !important;
          }

          .invoice-table-wrap {
            overflow: visible !important;
          }

          .invoice-table {
            width: 100% !important;
          }

          .invoice-table thead {
            display: table-header-group !important;
          }

          .invoice-table tfoot {
            display: table-footer-group !important;
          }

          .invoice-table tr {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }

          .invoice-table td,
          .invoice-table th {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }

          .invoice-meta-grid,
          .invoice-summary-grid,
          .invoice-summary-card,
          .invoice-note-card,
          .invoice-thankyou {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }

          .print\\:max-w-none {
            max-width: none !important;
          }

          .print\\:px-0,
          .print\\:pb-0 {
            padding-left: 0 !important;
            padding-right: 0 !important;
            padding-bottom: 0 !important;
          }
        }
      `}</style>

      <div className="no-print mx-auto max-w-5xl px-4 pt-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-lg font-semibold">
              Admin Invoice #{displayOrderId}
            </div>
            <div className="text-sm text-black/60">
              Compact A4 invoice with variant and courier details
            </div>
          </div>

          <div className="flex gap-2">
            <Link
              href={`/admin/orders/${order.id}`}
              className="rounded-xl border border-black/10 px-4 py-2 text-sm hover:bg-black/5"
            >
              Back
            </Link>
            <InvoicePrintButton />
          </div>
        </div>
      </div>

      <div
        id="invoice-print-root"
        className="invoice-shell mx-auto max-w-5xl px-4 pb-6 print:max-w-none print:px-0 print:pb-0"
      >
        <OrderInvoiceDocument
          order={order}
          storeName={storeName}
          storeLogo={storeLogo}
          invoiceLabel="Admin Copy"
          subtitle={`Order invoice • ${displayOrderId}`}
        />
      </div>
    </>
  );
}
