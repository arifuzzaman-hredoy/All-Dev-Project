"use client";

import Link from "next/link";
import * as React from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";

export default function ResetPasswordClient() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const token = searchParams.get("token") || "";

  const [password, setPassword] = React.useState("");
  const [confirmPassword, setConfirmPassword] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!token) {
      toast({
        title: "Invalid link",
        variant: "error",
        description: "Please request a new password reset link.",
      });
      return;
    }

    if (password !== confirmPassword) {
      toast({
        title: "Passwords do not match",
        variant: "error",
        description: "Please type the same password twice.",
      });
      return;
    }

    setLoading(true);

    const res = await fetch("/api/auth/reset-password", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, password }),
    });

    const data: unknown = await res.json().catch(() => ({}));
    setLoading(false);

    if (!res.ok) {
      toast({
        title: "Reset failed",
        variant: "error",
        description:
          (data as { error?: string })?.error || "Please request a new link.",
      });
      return;
    }

    toast({
      title: "Password updated",
      variant: "success",
      description: "You can now login with your new password.",
    });
    router.push("/login");
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-10">
      <div className="w-full max-w-xl">
        <Card className="rounded-4xl border border-[#f8bbd0] bg-linear-to-br from-[#fff7fb] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
          <div className="inline-flex rounded-sm bg-[#ec407a]/15 px-3 py-1 text-xs font-medium text-[#ad1457]">
            New password
          </div>
          <h2 className="mt-4 text-2xl font-semibold tracking-tight text-slate-900">
            Choose a new password.
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Your reset link can only be used once.
          </p>

          {!token ? (
            <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              This reset link is missing a token. Please request a new link.
            </div>
          ) : null}

          <form onSubmit={onSubmit} className="mt-6 space-y-3">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">
                New password
              </label>
              <Input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="min 6 characters"
                type="password"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
                minLength={6}
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">
                Confirm password
              </label>
              <Input
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="type it again"
                type="password"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
                minLength={6}
                required
              />
            </div>

            <Button
              className="w-full bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
              disabled={loading || !token}
            >
              {loading ? "Updating..." : "Update password"}
            </Button>
          </form>

          <div className="mt-4 text-sm text-slate-600">
            Need a fresh link?{" "}
            <Link
              className="font-medium text-[#ad1457] underline underline-offset-4"
              href="/forgot-password"
            >
              Request again
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
