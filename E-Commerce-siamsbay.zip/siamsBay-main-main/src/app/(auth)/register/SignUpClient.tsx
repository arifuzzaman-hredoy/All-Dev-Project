"use client";

import Link from "next/link";
import * as React from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import PageHero from "@/components/layout/page-hero";

export default function RegisterPage() {
  const router = useRouter();
  const { toast } = useToast();

  const [loading, setLoading] = React.useState(false);
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });

    setLoading(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      toast({
        title: "Signup failed",
        variant: "error",
        description: data?.error || "Try again.",
      });
      return;
    }

    toast({
      title: "Account created",
      variant: "success",
      description: "Logging you in...",
    });
    await signIn("credentials", { email, password, redirect: false });
    router.push("/");
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-10">
      <div className="grid w-full max-w-xl gap-6">
        <Card className="rounded-[2rem] border border-[#f8bbd0] bg-gradient-to-br from-[#fff7fb] via-white to-white p-6 shadow-[0_18px_60px_-44px_rgba(216,27,96,0.18)]">
          <div className="inline-flex rounded-sm bg-[#ec407a]/15 px-3 py-1 text-xs font-medium text-[#ad1457]">
            Register
          </div>
          <h2 className="mt-4 text-2xl font-semibold tracking-tight text-slate-900">
            Create your account.
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Start shopping with saved addresses, wishlists, and order history.
          </p>

          <form onSubmit={onSubmit} className="mt-6 space-y-3">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">Name</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">
                Email
              </label>
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-600">
                Password
              </label>
              <Input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="min 6 characters"
                type="password"
                className="border-[#f8bbd0] bg-white/80 focus:border-[#d81b60] focus:ring-[#ec407a]/20"
              />
            </div>

            <Button
              className="w-full bg-[#d81b60] text-white shadow-[0_12px_34px_-16px_rgba(216,27,96,0.55)] hover:bg-[#c2185b]"
              disabled={loading}
            >
              {loading ? "Creating..." : "Create account"}
            </Button>
          </form>

          <div className="mt-4 text-sm text-slate-600">
            Already have an account?{" "}
            <Link
              className="font-medium text-[#ad1457] underline underline-offset-4"
              href="/login"
            >
              Login
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
