import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import { logout } from "./actions/auth";
import { NavLink } from "./components/nav-link";
import { MobileNavMenu } from "./components/mobile-nav-menu";
import { ChatWidget } from "./components/chat-widget";
import { getSessionUser } from "./lib/auth";


export const metadata: Metadata = {
  title: "CompanyLearn",
  description: "Internal learning + daily updates",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const user = await getSessionUser();

  const navItems = user
    ? [
        { href: "/dashboard", label: "Dashboard" },
        { href: "/attendance", label: "Attendance" },
        { href: "/trackme", label: "TrackMe" },
        { href: "/updates/today", label: "Daily Update" },
        { href: "/tasks", label: "Tasks" },
        { href: "/learning", label: "Learning" },
        ...(user.role === "ADMIN" || user.role === "LEAD"
          ? [{ href: "/status", label: "Status" }]
          : []),
        ...(user.role === "LEAD" ? [{ href: "/lead", label: "Team Lead" }] : []),
        ...(user.role === "ADMIN"
          ? [
              { href: "/admin", label: "Admin" },
              { href: "/reports", label: "Reports" },
            ]
          : []),
      ]
    : [];

  return (
    <html lang="en" className="h-full antialiased">
      <body className="relative flex min-h-full flex-col overflow-x-hidden bg-[radial-gradient(circle_at_top_left,rgba(239,230,212,0.95),transparent_34%),radial-gradient(circle_at_top_right,rgba(216,239,230,0.9),transparent_28%),linear-gradient(180deg,#fcfaf6_0%,#f7f3ea_58%,#f2ebdf_100%)] font-sans text-stone-900">
        <div className="pointer-events-none fixed inset-0 bg-[linear-gradient(to_right,transparent_0,transparent_39px,rgba(102,79,43,0.08)_40px),linear-gradient(to_bottom,transparent_0,transparent_39px,rgba(102,79,43,0.08)_40px)] bg-[size:40px_40px] opacity-50 [mask-image:linear-gradient(180deg,rgba(0,0,0,0.22),transparent_78%)]" />

        <header className="sticky top-0 z-50 w-full border-b border-slate-900/5 bg-white/55 px-3 py-3 backdrop-blur-2xl">
          <div className="mx-auto flex min-h-[64px] max-w-7xl items-center justify-between gap-4 rounded-[30px] border border-white/75 bg-white/70 px-4 py-2 shadow-[0_24px_70px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:rounded-full md:px-5">
            <Link
              href={user ? "/dashboard" : "/"}
              className="group flex shrink-0 items-center gap-3 no-underline"
            >
              <span className="relative grid h-11 w-11 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-[#174f3e] via-[#1f7a5b] to-[#2ca36f] text-base font-black text-white shadow-[0_16px_36px_rgba(23,79,62,0.32)]">
                <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_30%_15%,rgba(255,255,255,0.45),transparent_35%)]" />
                <span className="relative">TTL</span>
              </span>

              <span className="hidden flex-col leading-tight sm:flex">
                <span className="text-[15px] font-black tracking-[-0.03em] text-slate-950">
                  TechTeamLead
                </span>
                <span className="mt-0.5 text-[11px] font-bold text-slate-500">
                  Task & Learning
                </span>
              </span>
            </Link>

            <div className="hidden min-w-0 flex-1 items-center justify-end gap-3 lg:flex">
              <nav className="flex items-center gap-1 rounded-full border border-white/70 bg-white/35 p-1.5 shadow-inner shadow-white/40 ring-1 ring-slate-900/5 backdrop-blur-xl">
                {user ? (
                  navItems.map((item) => (
                    <NavLink key={item.href} href={item.href} variant="desktop">
                      {item.label}
                    </NavLink>
                  ))
                ) : (
                  <Link
                    href="/login"
                    className="rounded-full bg-gradient-to-br from-[#174f3e] to-[#2ca36f] px-6 py-2.5 text-sm font-black text-white shadow-[0_16px_34px_rgba(23,79,62,0.28)] transition hover:-translate-y-0.5 hover:shadow-[0_20px_44px_rgba(23,79,62,0.36)]"
                  >
                    Login
                  </Link>
                )}
              </nav>

              {user ? (
                <div className="flex shrink-0 items-center gap-2">
                  <NavLink href="/profile" variant="profile">
                    Profile
                  </NavLink>

                  <form action={logout}>
                    <button
                      type="submit"
                      className="rounded-full bg-gradient-to-br from-red-500 to-orange-500 px-5 py-2.5 text-sm font-black text-white shadow-[0_14px_30px_rgba(239,68,68,0.22)] transition duration-300 hover:-translate-y-0.5 hover:shadow-[0_18px_40px_rgba(239,68,68,0.30)] focus:outline-none focus-visible:ring-4 focus-visible:ring-red-300/30"
                    >
                      Logout
                    </button>
                  </form>
                </div>
              ) : null}
            </div>

            <MobileNavMenu
              userRole={user?.role}
              navItems={navItems}
              logoutAction={logout}
            />
          </div>
        </header>

        <main className="relative mx-auto w-full max-w-6xl flex-1 overflow-hidden px-4 py-6 md:px-6 md:py-8">
          {children}
        </main>

        <footer className="relative border-t border-slate-900/10 bg-white/50 px-4 py-5 backdrop-blur-xl md:px-6">
          <div className="mx-auto flex max-w-7xl flex-col gap-3 rounded-[26px] border border-white/70 bg-white/60 p-4 text-xs font-semibold text-slate-500 shadow-[0_18px_50px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl sm:flex-row sm:items-center sm:justify-between">
            <span className="font-black text-slate-700">
              © {new Date().getFullYear()} TechTeamLead
            </span>
            <span>Login, updates, learning, tasks, lead & admin dashboard.</span>
          </div>
        </footer>

        <ChatWidget currentUser={user} />
      </body>
    </html>
  );
}

