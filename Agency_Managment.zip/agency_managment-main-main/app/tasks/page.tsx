import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";
import { createTask, setTaskStatus } from "../actions/tasks";
import { DueCountdownPill } from "../components/due-countdown";

function Notice({
  type,
  children,
}: {
  type: "success" | "error";
  children: ReactNode;
}) {
  const styles = {
    success: "border-emerald-500/20 bg-emerald-500/10 text-emerald-700",
    error: "border-red-500/20 bg-red-500/10 text-red-700",
  };

  return (
    <div
      className={`relative overflow-hidden rounded-[24px] border px-4 py-3 text-sm font-medium shadow-sm backdrop-blur-xl ${styles[type]}`}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_10%_0%,rgba(255,255,255,0.72),transparent_35%)]" />
      <div className="relative flex items-center gap-2">
        <span className="h-2 w-2 rounded-full bg-current shadow-[0_0_14px_currentColor]" />
        <span>{children}</span>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusMap = {
    TODO: {
      label: "To do",
      className:
        "border-amber-500/25 bg-amber-500/10 text-amber-700 shadow-amber-500/10",
    },
    IN_PROGRESS: {
      label: "In progress",
      className:
        "border-sky-500/20 bg-sky-500/10 text-sky-700 shadow-sky-500/10",
    },
    DONE: {
      label: "Done",
      className:
        "border-emerald-500/20 bg-emerald-500/10 text-emerald-700 shadow-emerald-500/10",
    },
  } as const;

  const item = statusMap[status as keyof typeof statusMap] ?? {
    label: status.replaceAll("_", " "),
    className:
      "border-slate-500/20 bg-slate-500/10 text-slate-600 shadow-slate-500/10",
  };

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium shadow-sm ${item.className}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current shadow-[0_0_12px_currentColor]" />
      {item.label}
    </span>
  );
}

function PrimaryButton({ children }: { children: ReactNode }) {
  return (
    <button
      type="submit"
      className="group relative inline-flex min-h-12 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#174f3e] via-[#1f7a5b] to-[#2ca36f] px-7 text-sm font-semibold text-white shadow-[0_18px_42px_rgba(23,79,62,0.30)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_56px_rgba(23,79,62,0.42)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/35"
    >
      <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.42),transparent_34%)] opacity-80 transition group-hover:opacity-100" />
      <span className="pointer-events-none absolute -left-10 top-0 h-full w-8 rotate-12 bg-white/35 blur-sm transition-all duration-700 group-hover:left-[120%]" />
      <span className="relative z-10">{children}</span>
    </button>
  );
}

function SaveButton() {
  return (
    <button
      type="submit"
      className="inline-flex min-h-10 items-center justify-center rounded-full border border-white/80 bg-white/65 px-4 text-xs font-medium text-slate-700 shadow-[0_12px_28px_rgba(15,23,42,0.08),inset_0_1px_0_rgba(255,255,255,0.95)] ring-1 ring-slate-900/5 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white hover:text-[#174f3e] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25"
    >
      Save
    </button>
  );
}

function InputField({
  label,
  children,
  className = "",
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-2 block text-sm font-medium text-slate-700">
        {label}
      </span>
      {children}
    </label>
  );
}

const inputClassName =
  "w-full rounded-[22px] border border-white/80 bg-white/68 px-4 py-3 text-sm text-slate-800 shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_10px_26px_rgba(15,23,42,0.05)] ring-1 ring-slate-900/5 backdrop-blur-xl outline-none transition-all duration-300 placeholder:text-slate-400 focus:border-emerald-500/30 focus:bg-white/90 focus:ring-4 focus:ring-emerald-300/20";

const textareaClassName =
  "w-full resize-y rounded-[24px] border border-white/80 bg-white/68 px-4 py-4 text-sm leading-6 text-slate-800 shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_10px_26px_rgba(15,23,42,0.05)] ring-1 ring-slate-900/5 backdrop-blur-xl outline-none transition-all duration-300 placeholder:text-slate-400 focus:border-emerald-500/30 focus:bg-white/90 focus:ring-4 focus:ring-emerald-300/20";

const selectClassName =
  "w-full rounded-[22px] border border-white/80 bg-white/68 px-4 py-3 text-sm text-slate-800 shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_10px_26px_rgba(15,23,42,0.05)] ring-1 ring-slate-900/5 backdrop-blur-xl outline-none transition-all duration-300 focus:border-emerald-500/30 focus:bg-white/90 focus:ring-4 focus:ring-emerald-300/20";

export default async function TasksPage({
  searchParams,
}: {
  searchParams: Promise<{ created?: string; updated?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const { created, updated, error } = await searchParams;

  const [tasks, assignees] = await Promise.all([
    prisma.task.findMany({
      where: user.role === "EMPLOYEE" ? { assigneeId: user.id } : {},
      orderBy: [{ status: "asc" }, { updatedAt: "desc" }],
      select: {
        id: true,
        title: true,
        description: true,
        status: true,
        dueDay: true,
        assignee: { select: { id: true, name: true } },
        createdBy: { select: { id: true, name: true } },
        updatedAt: true,
      },
      take: 100,
    }),

    user.role === "ADMIN"
      ? prisma.user.findMany({
          orderBy: { name: "asc" },
          select: { id: true, name: true, email: true },
        })
      : user.role === "LEAD"
        ? prisma.user.findMany({
            where: {
              team: { leadId: user.id },
            },
            orderBy: { name: "asc" },
            select: { id: true, name: true, email: true },
          })
        : Promise.resolve([]),
  ]);

  const todoCount = tasks.filter((task) => task.status === "TODO").length;
  const progressCount = tasks.filter(
    (task) => task.status === "IN_PROGRESS",
  ).length;
  const doneCount = tasks.filter((task) => task.status === "DONE").length;

  return (
    <div className="relative space-y-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.23),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.16))]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-52 w-52 rounded-full bg-amber-300/20 blur-3xl" />

        <div className="relative z-10 grid gap-6 lg:grid-cols-[1.2fr_0.8fr] lg:items-end">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#174f3e] shadow-sm">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.85)]" />
              Execution flow
            </span>

            <h1 className="mt-5 text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
              Tasks
            </h1>

            <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-600 md:text-base">
              {user.role === "EMPLOYEE"
                ? "View your assigned work, update progress, and keep your team aligned."
                : "Create assignments, track progress, and keep execution clear across the team."}
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
              <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                Role: {user.role}
              </span>
              <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                Showing {tasks.length} tasks
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 rounded-[28px] border border-white/75 bg-white/50 p-3 shadow-[0_20px_60px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
            <div className="rounded-3xl border border-white/70 bg-white/55 p-4 text-center">
              <p className="text-2xl font-semibold tracking-[-0.04em] text-amber-700">
                {todoCount}
              </p>
              <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.12em] text-slate-400">
                To do
              </p>
            </div>

            <div className="rounded-3xl border border-white/70 bg-white/55 p-4 text-center">
              <p className="text-2xl font-semibold tracking-[-0.04em] text-sky-700">
                {progressCount}
              </p>
              <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.12em] text-slate-400">
                Active
              </p>
            </div>

            <div className="rounded-3xl border border-white/70 bg-white/55 p-4 text-center">
              <p className="text-2xl font-semibold tracking-[-0.04em] text-emerald-700">
                {doneCount}
              </p>
              <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.12em] text-slate-400">
                Done
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Notices */}
      {created ? <Notice type="success">Task created successfully.</Notice> : null}
      {updated ? <Notice type="success">Task updated successfully.</Notice> : null}

      {error === "missing" ? (
        <Notice type="error">Please add a title and select an assignee.</Notice>
      ) : null}

      {error === "forbidden" ? (
        <Notice type="error">You are not allowed to perform this action.</Notice>
      ) : null}

      {/* Create Task */}
      {user.role !== "EMPLOYEE" ? (
        <form
          action={createTask}
          className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6"
        >
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(16,185,129,0.16),transparent_30%),radial-gradient(circle_at_95%_8%,rgba(251,191,36,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

          <div className="relative z-10">
            <div className="mb-6 rounded-[28px] border border-white/70 bg-white/50 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl md:p-5">
              <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
                Create a task
              </h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
                Keep the title clear, assign the right person, and add enough
                context so the task can be completed without confusion.
              </p>
            </div>

            <div className="grid gap-5 md:grid-cols-2">
              <InputField label="Task title" className="md:col-span-2">
                <input
                  name="title"
                  required
                  className={inputClassName}
                  placeholder="Example: Build daily update dashboard UI"
                />
              </InputField>

              <InputField label="Task details" className="md:col-span-2">
                <textarea
                  name="description"
                  className={textareaClassName}
                  rows={4}
                  placeholder="Add expected output, important notes, links, or acceptance criteria..."
                />
              </InputField>

              <InputField label="Assign to">
                <select name="assigneeId" className={selectClassName} required>
                  <option value="">Select team member</option>
                  {assignees.map((assignee) => (
                    <option key={assignee.id} value={assignee.id}>
                      {assignee.name} ({assignee.email})
                    </option>
                  ))}
                </select>
              </InputField>

              <InputField label="Due day (deadline)">
                <input name="dueDay" type="date" className={inputClassName} />
              </InputField>
            </div>

            <div className="mt-6 flex flex-col gap-3 rounded-[28px] border border-white/70 bg-white/45 p-4 shadow-[0_14px_40px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between">
              <p className="text-xs leading-5 text-slate-500">
                After creating the task, it will appear in the task list and the
                assignee can update its progress.
              </p>

              <PrimaryButton>Create task</PrimaryButton>
            </div>
          </div>
        </form>
      ) : null}

      {/* Task List */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10 border-b border-slate-900/10 px-5 py-5 md:px-6">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
                Task list
              </h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">
                Review task ownership, due dates, descriptions and current
                progress.
              </p>
            </div>

            <span className="w-fit rounded-full border border-white/75 bg-white/60 px-3 py-1.5 text-xs font-medium text-slate-500 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
              Latest 100 tasks
            </span>
          </div>
        </div>

        <div className="relative z-10 p-4 md:p-5">
          {tasks.length === 0 ? (
            <div className="rounded-[30px] border border-white/75 bg-white/55 p-8 text-center shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-emerald-500/10 text-[#174f3e]">
                <svg
                  aria-hidden="true"
                  viewBox="0 0 24 24"
                  className="h-7 w-7 fill-none stroke-current stroke-2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M9 12l2 2 4-5M7 4h10a2 2 0 0 1 2 2v14l-3-2-3 2-3-2-3 2V6a2 2 0 0 1 2-2Z"
                  />
                </svg>
              </div>

              <h3 className="mt-4 text-lg font-semibold tracking-[-0.02em] text-slate-950">
                No tasks yet
              </h3>
              <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
                Once a task is created or assigned, it will show up here.
              </p>
            </div>
          ) : (
            <ul className="grid gap-4">
              {tasks.map((task) => (
                <li
                  key={task.id}
                  className="group rounded-[30px] border border-white/75 bg-white/56 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/70 hover:shadow-[0_24px_70px_rgba(15,23,42,0.10)] md:p-5"
                >
                  <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-base font-semibold tracking-[-0.02em] text-slate-950">
                          {task.title}
                        </h3>
                        <StatusBadge status={task.status} />
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2 text-xs font-medium text-slate-500">
                        <span className="rounded-full border border-white/75 bg-white/60 px-3 py-1.5 backdrop-blur-xl">
                          Assignee: {task.assignee.name}
                        </span>

                        <span className="rounded-full border border-white/75 bg-white/60 px-3 py-1.5 backdrop-blur-xl">
                          Created by: {task.createdBy.name}
                        </span>

                        {task.dueDay ? (
                          <>
                            <span className="rounded-full border border-amber-500/20 bg-amber-500/10 px-3 py-1.5 text-amber-700 backdrop-blur-xl">
                              Due: {task.dueDay}
                            </span>
                            <DueCountdownPill dueDay={task.dueDay} />
                          </>
                        ) : null}
                      </div>

                      {task.description ? (
                        <div className="mt-4 whitespace-pre-wrap rounded-[24px] border border-white/75 bg-white/58 p-4 text-sm leading-6 text-slate-600 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
                          {task.description}
                        </div>
                      ) : null}

                      <p className="mt-3 text-xs text-slate-400">
                        Last updated {task.updatedAt.toLocaleString()}
                      </p>
                    </div>

                    <form
                      action={setTaskStatus}
                      className="flex shrink-0 items-center gap-2 rounded-[24px] border border-white/75 bg-white/45 p-2 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl"
                    >
                      <input type="hidden" name="taskId" value={task.id} />

                      <select
                        name="status"
                        defaultValue={task.status}
                        className="min-h-10 min-w-40 rounded-full border border-white/80 bg-white/70 px-3 text-xs font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition focus:border-emerald-500/30 focus:ring-4 focus:ring-emerald-300/20"
                      >
                        <option value="TODO">To do</option>
                        <option value="IN_PROGRESS">In progress</option>
                        <option value="DONE">Done</option>
                      </select>

                      <SaveButton />
                    </form>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}
