import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";
import { todayDayString } from "../lib/dates";

export default async function TeamLeadPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "LEAD") redirect("/status");

  const day = todayDayString();

  const teams = await prisma.team.findMany({
    where: { leadId: user.id },
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      members: {
        orderBy: { name: "asc" },
        select: {
          id: true,
          name: true,
          email: true,
          dailyUpdates: {
            where: { day },
            select: { id: true },
            take: 1,
          },
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Team lead view</h1>
          <p className="mt-1 text-sm text-zinc-600">Status for {day}</p>
        </div>
        <Link href="/status" className="text-sm hover:underline">
          Full status table
        </Link>
      </div>

      {teams.length === 0 ? (
        <div className="rounded-lg border bg-white p-4 shadow-sm text-sm text-zinc-600">
          No teams assigned to you yet.
        </div>
      ) : (
        <div className="space-y-4">
          {teams.map((team) => (
            <div key={team.id} className="rounded-lg border bg-white shadow-sm">
              <div className="border-b px-4 py-3 text-sm font-medium">
                {team.name}
              </div>
              {team.members.length === 0 ? (
                <div className="px-4 py-4 text-sm text-zinc-600">
                  No members.
                </div>
              ) : (
                <ul className="divide-y">
                  {team.members.map((m) => {
                    const submitted = m.dailyUpdates.length > 0;
                    return (
                      <li key={m.id} className="px-4 py-3 flex items-center justify-between gap-4">
                        <div>
                          <div className="font-medium">{m.name}</div>
                          <div className="text-xs text-zinc-500">{m.email}</div>
                        </div>
                        <div className="flex items-center gap-3 text-sm">
                          <span
                            className={
                              submitted
                                ? "rounded bg-green-100 px-2 py-1 text-xs text-green-800"
                                : "rounded bg-amber-100 px-2 py-1 text-xs text-amber-800"
                            }
                          >
                            {submitted ? "Submitted" : "Missing"}
                          </span>
                          {submitted ? (
                            <Link
                              className="text-blue-700 hover:underline"
                              href={`/updates/view/${m.id}/${day}`}
                            >
                              Open
                            </Link>
                          ) : (
                            <span className="text-zinc-400">—</span>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

