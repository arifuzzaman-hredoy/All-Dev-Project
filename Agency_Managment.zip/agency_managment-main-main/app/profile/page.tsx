import { redirect } from "next/navigation";
import { saveProfile } from "../actions/profile";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";
import { noticeClasses, ui } from "../lib/ui";

export default async function ProfilePage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const profile = await prisma.profile.findUnique({
    where: { userId: user.id },
    select: {
      title: true,
      department: true,
      phone: true,
      location: true,
      bio: true,
    },
  });

  const { saved, error } = await searchParams;

  return (
    <div className="space-y-6">
      <section className={ui.heroCard}>
        <span className={ui.eyebrow}>People profile</span>
        <h1 className={ui.pageTitle}>Employee Profile</h1>
        <p className={ui.pageCopy}>{user.email}</p>
      </section>

      {saved ? <div className={noticeClasses("success")}>Profile saved.</div> : null}
      {error === "name" ? <div className={noticeClasses("error")}>Name is required.</div> : null}

      <form action={saveProfile} className={`${ui.panel} p-5 md:p-6`}>
        <div className="mb-5">
          <div className={ui.sectionTitle}>Personal details</div>
          <p className={`${ui.sectionCopy} mt-1`}>
            Keep this current so leads and teammates can understand who is doing what.
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <label className={ui.fieldLabel}>
            Name
            <input name="name" defaultValue={user.name} className={ui.input} required />
          </label>
          <label className={ui.fieldLabel}>
            Title
            <input
              name="title"
              defaultValue={profile?.title ?? ""}
              className={ui.input}
              placeholder="e.g. Software Engineer"
            />
          </label>
          <label className={ui.fieldLabel}>
            Department
            <input
              name="department"
              defaultValue={profile?.department ?? ""}
              className={ui.input}
              placeholder="e.g. Engineering"
            />
          </label>
          <label className={ui.fieldLabel}>
            Phone
            <input name="phone" defaultValue={profile?.phone ?? ""} className={ui.input} />
          </label>
          <label className={ui.fieldLabel}>
            Location
            <input
              name="location"
              defaultValue={profile?.location ?? ""}
              className={ui.input}
              placeholder="e.g. Dhaka"
            />
          </label>
          <div className="md:col-span-2">
            <label className={ui.fieldLabel}>
              Bio
              <textarea
                name="bio"
                defaultValue={profile?.bio ?? ""}
                className={ui.textarea}
                rows={5}
              />
            </label>
          </div>
        </div>
        <button className={`${ui.actionPrimary} mt-6`}>Save profile</button>
      </form>
    </div>
  );
}
