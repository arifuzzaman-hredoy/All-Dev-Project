import { redirect } from "next/navigation";
import { getSessionUser } from "../../../../lib/auth";
import { prisma } from "../../../../lib/db";
import { ui } from "../../../../lib/ui";

export default async function ViewLearningStatusPage({
  params,
}: {
  params: Promise<{ userId: string; day: string }>;
}) {
  const viewer = await getSessionUser();
  if (!viewer) redirect("/login");
  if (viewer.role === "EMPLOYEE") redirect("/dashboard");

  const { userId, day } = await params;

  if (viewer.role === "LEAD") {
    const allowed = await prisma.user.findFirst({
      where: { id: userId, team: { leadId: viewer.id } },
      select: { id: true },
    });
    if (!allowed) redirect("/status");
  }

  const status = await prisma.learningStatus.findUnique({
    where: { userId_day: { userId, day } },
    select: {
      day: true,
      learningPlan: true,
      completedLearning: true,
      updatedAt: true,
      user: { select: { name: true, email: true } },
    },
  });

  if (!status) {
    return (
      <div className="space-y-2">
        <h1 className="text-2xl font-semibold">Learning status</h1>
        <p className="text-sm text-zinc-600">No learning status found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Learning status</h1>
        <p className="mt-1 text-sm text-zinc-600">
          {status.user.name} • {status.user.email}
        </p>
        <p className="mt-1 text-sm text-zinc-600">
          {status.day} • last saved {status.updatedAt.toLocaleString()}
        </p>
      </div>

      <Section title="Learning plan">{status.learningPlan}</Section>
      {status.completedLearning ? (
        <Section title="Completed learning">{status.completedLearning}</Section>
      ) : null}
    </div>
  );
}

function Section({ title, children }: { title: string; children: string }) {
  return (
    <div className={`${ui.panel} p-5`}>
      <div className="text-sm font-medium">{title}</div>
      <pre className={`${ui.proseBlock} mt-3`}>{children}</pre>
    </div>
  );
}
