import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import {
  addLearningItem,
  deleteLearningItem,
  saveLearningStatus,
} from "../actions/learning";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";
import { todayDayString } from "../lib/dates";

function Notice({
  type,
  children,
}: {
  type: "success" | "error";
  children: ReactNode;
}) {
  const styles = {
    success: "border-emerald-500/20 bg-emerald-500/10 text-emerald-700",
    error: "border-red-500/20 bg-red-500/10 text-red-700",
  };

  return (
    <div
      className={`relative overflow-hidden rounded-[24px] border px-4 py-3 text-sm font-medium shadow-sm backdrop-blur-xl ${styles[type]}`}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_10%_0%,rgba(255,255,255,0.72),transparent_35%)]" />
      <div className="relative flex items-center gap-2">
        <span className="h-2 w-2 rounded-full bg-current shadow-[0_0_14px_currentColor]" />
        <span>{children}</span>
      </div>
    </div>
  );
}

function PrimaryButton({ children }: { children: ReactNode }) {
  return (
    <button
      type="submit"
      className="group relative inline-flex min-h-12 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#174f3e] via-[#1f7a5b] to-[#2ca36f] px-7 text-sm font-semibold text-white shadow-[0_18px_42px_rgba(23,79,62,0.30)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_56px_rgba(23,79,62,0.42)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/35"
    >
      <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.42),transparent_34%)] opacity-80 transition group-hover:opacity-100" />
      <span className="pointer-events-none absolute -left-10 top-0 h-full w-8 rotate-12 bg-white/35 blur-sm transition-all duration-700 group-hover:left-[120%]" />
      <span className="relative z-10">{children}</span>
    </button>
  );
}

function DeleteButton() {
  return (
    <button
      type="submit"
      className="inline-flex min-h-10 items-center justify-center rounded-full border border-red-500/15 bg-red-500/10 px-4 text-xs font-medium text-red-700 shadow-[0_10px_24px_rgba(239,68,68,0.08)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-red-500/15 focus:outline-none focus-visible:ring-4 focus-visible:ring-red-300/25"
    >
      Delete
    </button>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-2 block text-sm font-medium text-slate-700">
        {label}
      </span>
      {children}
    </label>
  );
}

function LearningTextarea({
  name,
  defaultValue,
  rows,
  placeholder,
  required = false,
}: {
  name: string;
  defaultValue?: string | null;
  rows: number;
  placeholder: string;
  required?: boolean;
}) {
  return (
    <textarea
      name={name}
      defaultValue={defaultValue ?? ""}
      rows={rows}
      required={required}
      placeholder={placeholder}
      className="w-full resize-y rounded-[24px] border border-white/80 bg-white/68 px-4 py-4 text-sm leading-6 text-slate-800 shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_10px_26px_rgba(15,23,42,0.05)] ring-1 ring-slate-900/5 backdrop-blur-xl outline-none transition-all duration-300 placeholder:text-slate-400 focus:border-emerald-500/30 focus:bg-white/90 focus:ring-4 focus:ring-emerald-300/20"
    />
  );
}

const inputClassName =
  "w-full rounded-[22px] border border-white/80 bg-white/68 px-4 py-3 text-sm text-slate-800 shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_10px_26px_rgba(15,23,42,0.05)] ring-1 ring-slate-900/5 backdrop-blur-xl outline-none transition-all duration-300 placeholder:text-slate-400 focus:border-emerald-500/30 focus:bg-white/90 focus:ring-4 focus:ring-emerald-300/20";

function MetricCard({
  value,
  label,
  tone,
}: {
  value: ReactNode;
  label: string;
  tone: "emerald" | "sky" | "amber";
}) {
  const toneClass = {
    emerald: "text-emerald-700 bg-emerald-500/10 border-emerald-500/15",
    sky: "text-sky-700 bg-sky-500/10 border-sky-500/15",
    amber: "text-amber-700 bg-amber-500/10 border-amber-500/15",
  };

  return (
    <div
      className={`rounded-3xl border p-4 text-center shadow-sm backdrop-blur-xl ${toneClass[tone]}`}
    >
      <p className="text-2xl font-semibold tracking-[-0.04em]">{value}</p>
      <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.12em] opacity-75">
        {label}
      </p>
    </div>
  );
}

export default async function LearningPage({
  searchParams,
}: {
  searchParams: Promise<{
    added?: string;
    deleted?: string;
    saved?: string;
    error?: string;
  }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const day = todayDayString();

  const [status, items] = await Promise.all([
    prisma.learningStatus.findUnique({
      where: { userId_day: { userId: user.id, day } },
      select: {
        learningPlan: true,
        completedLearning: true,
        updatedAt: true,
      },
    }),

    prisma.learningItem.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        title: true,
        url: true,
        notes: true,
        createdAt: true,
      },
      take: 50,
    }),
  ]);

  const { added, deleted, saved, error } = await searchParams;

  const hasPlan = Boolean(status?.learningPlan?.trim());
  const hasCompleted = Boolean(status?.completedLearning?.trim());

  return (
    <div className="relative space-y-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.23),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.16))]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-52 w-52 rounded-full bg-sky-300/20 blur-3xl" />

        <div className="relative z-10 grid gap-6 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#174f3e] shadow-sm">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.85)]" />
              Growth log
            </span>

            <h1 className="mt-5 text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
              Learning
            </h1>

            <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-600 md:text-base">
              Track today&apos;s learning plan, save useful links, and keep your
              notes organized so your progress is easy to review.
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
              <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                {day}
              </span>

              {status?.updatedAt ? (
                <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                  Last saved {status.updatedAt.toLocaleString()}
                </span>
              ) : (
                <span className="rounded-full border border-amber-500/20 bg-amber-500/10 px-3 py-1.5 text-amber-700 backdrop-blur-xl">
                  First learning update today
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 rounded-[28px] border border-white/75 bg-white/50 p-3 shadow-[0_20px_60px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
            <MetricCard
              value={hasPlan ? "Yes" : "No"}
              label="Plan"
              tone={hasPlan ? "emerald" : "amber"}
            />
            <MetricCard
              value={hasCompleted ? "Yes" : "No"}
              label="Done"
              tone={hasCompleted ? "emerald" : "sky"}
            />
            <MetricCard value={items.length} label="Items" tone="sky" />
          </div>
        </div>
      </section>

      {/* Notices */}
      {saved ? (
        <Notice type="success">Learning status saved successfully.</Notice>
      ) : null}

      {added ? (
        <Notice type="success">Learning item added successfully.</Notice>
      ) : null}

      {deleted ? (
        <Notice type="success">Learning item deleted successfully.</Notice>
      ) : null}

      {error === "title" ? (
        <Notice type="error">Please add a title before saving the item.</Notice>
      ) : null}

      {error === "status" ? (
        <Notice type="error">Please write your learning plan before saving.</Notice>
      ) : null}

      {/* Today's Learning Status */}
      <form
        action={saveLearningStatus}
        className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6"
      >
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(16,185,129,0.16),transparent_30%),radial-gradient(circle_at_95%_8%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10">
          <div className="mb-6 rounded-[28px] border border-white/70 bg-white/50 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl md:p-5">
            <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
              Today&apos;s learning status
            </h2>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
              Write what you plan to learn first. Later, update what you
              actually completed before ending the day.
            </p>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <Field label="Learning plan">
              <LearningTextarea
                name="learningPlan"
                defaultValue={status?.learningPlan}
                rows={5}
                required
                placeholder="Example: Learn Prisma relations, revise Next.js server actions, practice PostgreSQL joins..."
              />
            </Field>

            <Field label="Completed learning">
              <LearningTextarea
                name="completedLearning"
                defaultValue={status?.completedLearning}
                rows={5}
                placeholder="Example: Practiced relations, implemented task query, documented what I learned..."
              />
            </Field>
          </div>

          <div className="mt-6 flex flex-col gap-3 rounded-[28px] border border-white/70 bg-white/45 p-4 shadow-[0_14px_40px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs leading-5 text-slate-500">
              You can update this anytime during the day. Your latest saved
              version will be used for reporting.
            </p>

            <PrimaryButton>Save learning status</PrimaryButton>
          </div>
        </div>
      </form>

      {/* Add Learning Item */}
      <form
        action={addLearningItem}
        className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6"
      >
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(59,130,246,0.13),transparent_30%),radial-gradient(circle_at_95%_8%,rgba(251,191,36,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10">
          <div className="mb-6 rounded-[28px] border border-white/70 bg-white/50 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl md:p-5">
            <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
              Add a learning item
            </h2>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
              Save useful topics, links, notes, references, or lessons learned
              while the context is still fresh.
            </p>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <Field label="Title" className="md:col-span-2">
              <input
                name="title"
                required
                className={inputClassName}
                placeholder="Example: Prisma relations in our schema"
              />
            </Field>

            <Field label="Resource link" className="md:col-span-2">
              <input
                name="url"
                type="url"
                className={inputClassName}
                placeholder="https://example.com/article-or-video"
              />
            </Field>

            <Field label="Notes" className="md:col-span-2">
              <LearningTextarea
                name="notes"
                rows={4}
                placeholder="Write the key idea, example, command, mistake, or takeaway..."
              />
            </Field>
          </div>

          <div className="mt-6 flex flex-col gap-3 rounded-[28px] border border-white/70 bg-white/45 p-4 shadow-[0_14px_40px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs leading-5 text-slate-500">
              Saved items will stay in your personal learning library.
            </p>

            <PrimaryButton>Add learning item</PrimaryButton>
          </div>
        </div>
      </form>

      {/* Learning Items */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(16,185,129,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10 border-b border-slate-900/10 px-5 py-5 md:px-6">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
                Your learning library
              </h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">
                Review your saved links, notes and important learning points.
              </p>
            </div>

            <span className="w-fit rounded-full border border-white/75 bg-white/60 px-3 py-1.5 text-xs font-medium text-slate-500 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
              Latest 50 items
            </span>
          </div>
        </div>

        <div className="relative z-10 p-4 md:p-5">
          {items.length === 0 ? (
            <div className="rounded-[30px] border border-white/75 bg-white/55 p-8 text-center shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-emerald-500/10 text-[#174f3e]">
                <svg
                  aria-hidden="true"
                  viewBox="0 0 24 24"
                  className="h-7 w-7 fill-none stroke-current stroke-2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 6v12m6-6H6"
                  />
                </svg>
              </div>

              <h3 className="mt-4 text-lg font-semibold tracking-[-0.02em] text-slate-950">
                No learning items yet
              </h3>

              <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
                Add your first learning item to build a searchable personal
                knowledge history.
              </p>
            </div>
          ) : (
            <ul className="grid gap-4">
              {items.map((item) => (
                <li
                  key={item.id}
                  className="group rounded-[30px] border border-white/75 bg-white/56 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/70 hover:shadow-[0_24px_70px_rgba(15,23,42,0.10)] md:p-5"
                >
                  <div className="flex flex-col gap-5 md:flex-row md:items-start md:justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-base font-semibold tracking-[-0.02em] text-slate-950">
                          {item.title}
                        </h3>

                        <span className="rounded-full border border-white/75 bg-white/60 px-3 py-1.5 text-xs font-medium text-slate-500 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
                          {item.createdAt.toLocaleString()}
                        </span>
                      </div>

                      {item.url ? (
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noreferrer"
                          className="mt-3 inline-flex max-w-full items-center gap-2 truncate rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-2 text-xs font-medium text-[#174f3e] transition hover:bg-emerald-500/15 hover:underline"
                        >
                          <span className="truncate">{item.url}</span>
                          <span aria-hidden="true">↗</span>
                        </a>
                      ) : null}

                      {item.notes ? (
                        <div className="mt-4 whitespace-pre-wrap rounded-[24px] border border-white/75 bg-white/58 p-4 text-sm leading-6 text-slate-600 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
                          {item.notes}
                        </div>
                      ) : null}
                    </div>

                    <form action={deleteLearningItem} className="shrink-0">
                      <input type="hidden" name="id" value={item.id} />
                      <DeleteButton />
                    </form>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}