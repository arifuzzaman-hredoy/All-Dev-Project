import Link from "next/link";
import { redirect } from "next/navigation";
import { resetPassword } from "../actions/auth";
import { getSessionUser } from "../lib/auth";
import { getValidPasswordResetToken } from "../lib/password-reset";
import { noticeClasses, ui } from "../lib/ui";

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (user) redirect("/dashboard");

  const { token, error } = await searchParams;
  const resetToken = token ? await getValidPasswordResetToken(token) : null;
  const isValid = Boolean(resetToken);

  const message =
    error === "missing"
      ? "Password and confirmation are required."
      : error === "match"
        ? "Passwords do not match."
        : error === "invalid"
          ? "This reset link is invalid or has expired."
          : null;

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <section className={ui.heroCard}>
        <span className={ui.eyebrow}>Account recovery</span>
        <h1 className={ui.pageTitle}>Reset password</h1>
        <p className={ui.pageCopy}>
          Choose a new password for your CompanyLearn account.
        </p>
      </section>

      {message ? <div className={noticeClasses("error")}>{message}</div> : null}

      {isValid && token ? (
        <form action={resetPassword} className={`${ui.panel} p-5 md:p-6`}>
          <input type="hidden" name="token" value={token} />
          <label className={ui.fieldLabel}>
            New password
            <input
              name="password"
              type="password"
              autoComplete="new-password"
              className={ui.input}
              minLength={8}
              required
            />
          </label>
          <label className={`${ui.fieldLabel} mt-4 block`}>
            Confirm password
            <input
              name="confirmPassword"
              type="password"
              autoComplete="new-password"
              className={ui.input}
              minLength={8}
              required
            />
          </label>
          <button className={`${ui.actionPrimary} mt-6`}>Reset password</button>
        </form>
      ) : (
        <div className={`${ui.panel} p-5 md:p-6`}>
          <p className={ui.sectionCopy}>
            Request a new reset link to continue.
          </p>
          <Link href="/forgot-password" className={`${ui.actionSecondary} mt-5`}>
            Request new link
          </Link>
        </div>
      )}

      <Link href="/login" className={ui.linkAccent}>
        Back to login
      </Link>
    </div>
  );
}
