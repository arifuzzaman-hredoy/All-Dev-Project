import Link from "next/link";
import { redirect } from "next/navigation";
import { requestPasswordReset } from "../actions/auth";
import { getSessionUser } from "../lib/auth";
import { noticeClasses, ui } from "../lib/ui";

export default async function ForgotPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ sent?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (user) redirect("/dashboard");

  const { sent, error } = await searchParams;

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <section className={ui.heroCard}>
        <span className={ui.eyebrow}>Account recovery</span>
        <h1 className={ui.pageTitle}>Forgot password</h1>
        <p className={ui.pageCopy}>
          Enter your work email and we&apos;ll send a password reset link.
        </p>
      </section>

      {sent ? (
        <div className={noticeClasses("success")}>
          If the email exists in CompanyLearn, a reset link has been sent.
        </div>
      ) : null}
      {error === "missing" ? (
        <div className={noticeClasses("error")}>Email is required.</div>
      ) : null}

      <form action={requestPasswordReset} className={`${ui.panel} p-5 md:p-6`}>
        <label className={ui.fieldLabel}>
          Work email
          <input
            name="email"
            type="email"
            autoComplete="email"
            className={ui.input}
            placeholder="you@company.com"
            required
          />
        </label>
        <button className={`${ui.actionPrimary} mt-6`}>Send reset link</button>
      </form>

      <Link href="/login" className={ui.linkAccent}>
        Back to login
      </Link>
    </div>
  );
}
