import Link from "next/link";
import { redirect } from "next/navigation";
import { submitApplication } from "../actions/applications";
import { getSessionUser } from "../lib/auth";
import { noticeClasses, ui } from "../lib/ui";

export default async function ApplyPage({
  searchParams,
}: {
  searchParams: Promise<{ sent?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (user) redirect("/dashboard");

  const { sent, error } = await searchParams;

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <section className={ui.heroCard}>
        <span className={ui.eyebrow}>Request access</span>
        <h1 className={ui.pageTitle}>Apply for an account</h1>
        <p className={ui.pageCopy}>
          Submit your details and an admin will review your request.
        </p>
      </section>

      {sent ? (
        <div className={noticeClasses("success")}>
          Application submitted. We&apos;ll reach out if approved.
        </div>
      ) : null}
      {error === "missing" ? (
        <div className={noticeClasses("error")}>Name and email are required.</div>
      ) : error === "invalid" ? (
        <div className={noticeClasses("error")}>Please enter a valid email.</div>
      ) : null}

      <form action={submitApplication} className={`${ui.panel} space-y-4 p-5 md:p-6`}>
        <label className={ui.fieldLabel}>
          Full name
          <input
            name="name"
            type="text"
            autoComplete="name"
            className={ui.input}
            placeholder="Your name"
            required
          />
        </label>

        <label className={ui.fieldLabel}>
          Email
          <input
            name="email"
            type="email"
            autoComplete="email"
            className={ui.input}
            placeholder="you@company.com"
            required
          />
        </label>

        <label className={ui.fieldLabel}>
          Notes (optional)
          <textarea
            name="message"
            className={`${ui.textarea} min-h-[120px]`}
            placeholder="Team, role, or anything you want to share"
          />
        </label>

        <button className={`${ui.actionPrimary} mt-2`}>Submit application</button>
      </form>

      <Link href="/login" className={ui.linkAccent}>
        Back to login
      </Link>
    </div>
  );
}
