import { redirect } from "next/navigation";
import { getSessionUser } from "../lib/auth";
import { TrackmeCapture } from "./trackme-capture";

export default async function TrackmePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/58 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.22),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.13),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.16))]" />

        <div className="relative z-10">
          <span className="inline-flex rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-1.5 text-xs font-black uppercase tracking-[0.14em] text-[#174f3e]">
            Permission-based screenshot uploader
          </span>

          <h1 className="mt-5 text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
            TrackMe
          </h1>

          <p className="mt-4 max-w-3xl text-sm font-semibold leading-7 text-slate-600 md:text-base">
            Start press kore browser popup theke Entire Screen select korle ei
            page proti 3 seconds por high-quality screenshot upload korbe. Upload gula admin
            panel e serial by serial dekha jabe.
          </p>
        </div>
      </section>

      <TrackmeCapture />
    </div>
  );
}
