"use client";

import { useEffect, useRef, useState } from "react";

const SCREENSHOT_INTERVAL_MS = 3_000;
const UPLOAD_API = "/api/trackme/upload";
const SCREENSHOT_MAX_WIDTH = 1920;
const SCREENSHOT_JPEG_QUALITY = 0.92;

type CaptureState = "ready" | "starting" | "active" | "uploading" | "stopped" | "error";

function formatTime(totalSeconds: number) {
  const mins = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const secs = String(totalSeconds % 60).padStart(2, "0");
  return `${mins}:${secs}`;
}

function makeScreenshotFileName() {
  const safeDate = new Date().toISOString().replace(/[:.]/g, "-");
  return `screenshot-${safeDate}.jpg`;
}

export function TrackmeCapture() {
  const previewRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const uploadingRef = useRef(false);
  const screenshotCountRef = useRef(0);

  const [state, setState] = useState<CaptureState>("ready");
  const [status, setStatus] = useState("Ready");
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [screenshotCount, setScreenshotCount] = useState(0);
  const [lastFileName, setLastFileName] = useState("None");

  const isActive = state === "active" || state === "uploading";

  function stopTimer() {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }

  function stopTracks() {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;

    if (previewRef.current) {
      previewRef.current.srcObject = null;
    }
  }

  function stopCapture(nextStatus = "Stopped") {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    stopTimer();
    stopTracks();
    uploadingRef.current = false;
    setState("stopped");
    setStatus(nextStatus);
  }

  async function uploadScreenshot(blob: Blob, fileName: string, count: number) {
    const formData = new FormData();
    formData.append("screenshot", blob, fileName);
    formData.append("fileName", fileName);
    formData.append("capturedAt", new Date().toISOString());
    formData.append("count", String(count));

    const response = await fetch(UPLOAD_API, {
      method: "POST",
      body: formData,
      credentials: "include",
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || "Screenshot upload failed");
    }

    const result = (await response.json()) as { fileName?: string };
    setLastFileName(result.fileName || fileName);
  }

  async function captureScreenshot() {
    const preview = previewRef.current;

    if (uploadingRef.current) return;
    if (!streamRef.current || !preview?.videoWidth || !preview.videoHeight) {
      setStatus("Preview not ready yet");
      return;
    }

    try {
      uploadingRef.current = true;
      setState("uploading");
      setStatus("Taking screenshot...");

      const scale = Math.min(1, SCREENSHOT_MAX_WIDTH / preview.videoWidth);
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(preview.videoWidth * scale);
      canvas.height = Math.round(preview.videoHeight * scale);

      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas is not supported.");

      context.drawImage(preview, 0, 0, canvas.width, canvas.height);

      const blob = await new Promise<Blob | null>((resolve) => {
        canvas.toBlob(resolve, "image/jpeg", SCREENSHOT_JPEG_QUALITY);
      });

      if (!blob) {
        setStatus("Screenshot failed");
        return;
      }

      screenshotCountRef.current += 1;
      const nextCount = screenshotCountRef.current;
      setScreenshotCount(nextCount);

      setStatus("Uploading screenshot...");
      await uploadScreenshot(blob, makeScreenshotFileName(), nextCount);

      setState("active");
      setStatus("Screenshot uploaded to server");
    } catch (error) {
      console.error(error);
      setState("active");
      setStatus("Upload failed");
    } finally {
      uploadingRef.current = false;
    }
  }

  async function startCapture() {
    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        alert("Your browser does not support screen capture with getDisplayMedia.");
        return;
      }

      setState("starting");
      setStatus("Waiting for screen permission...");

      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: "monitor",
          frameRate: { ideal: 5, max: 10 },
        },
        audio: false,
      });

      streamRef.current = stream;

      if (previewRef.current) {
        previewRef.current.srcObject = stream;
        previewRef.current.onloadedmetadata = () => {
          void captureScreenshot();
        };
      }

      setScreenshotCount(0);
      screenshotCountRef.current = 0;
      setLastFileName("None");
      setElapsedSeconds(0);
      setStartedAt(Date.now());
      setState("active");
      setStatus("Capture started");

      stream.getVideoTracks()[0]?.addEventListener("ended", () => {
        stopCapture("Screen sharing stopped");
      });

      intervalRef.current = setInterval(() => {
        void captureScreenshot();
      }, SCREENSHOT_INTERVAL_MS);
    } catch (error) {
      console.error(error);
      const permissionDenied =
        error instanceof DOMException && error.name === "NotAllowedError";

      setState("error");
      setStatus(permissionDenied ? "Permission denied" : "Capture failed");
      alert(
        permissionDenied
          ? "Permission denied. You must allow screen sharing from the browser popup."
          : error instanceof Error
            ? error.message
            : "Capture failed."
      );
      stopCapture("Capture failed");
    }
  }

  useEffect(() => {
    if (!startedAt || !isActive) return;

    timerRef.current = setInterval(() => {
      setElapsedSeconds(Math.floor((Date.now() - startedAt) / 1000));
    }, 500);

    return stopTimer;
  }, [isActive, startedAt]);

  useEffect(() => {
    const preview = previewRef.current;

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (preview) preview.onloadedmetadata = null;
      stopTimer();
      stopTracks();
    };
  }, []);

  return (
    <section className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
      <div className="rounded-[30px] border border-white/75 bg-white/62 p-5 shadow-[0_26px_80px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            disabled={isActive || state === "starting"}
            onClick={() => void startCapture()}
            className="inline-flex min-h-11 flex-1 items-center justify-center rounded-2xl bg-[#174f3e] px-5 text-sm font-black text-white shadow-[0_16px_36px_rgba(23,79,62,0.26)] transition hover:-translate-y-0.5 hover:bg-[#1f6b51] disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:translate-y-0 sm:flex-none"
          >
            Start Screenshot Capture
          </button>

          <button
            type="button"
            disabled={!isActive}
            onClick={() => void captureScreenshot()}
            className="inline-flex min-h-11 flex-1 items-center justify-center rounded-2xl border border-slate-200 bg-white/80 px-5 text-sm font-black text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:text-[#174f3e] disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:translate-y-0 sm:flex-none"
          >
            Capture Now
          </button>

          <button
            type="button"
            disabled={!isActive && state !== "starting"}
            onClick={() => stopCapture()}
            className="inline-flex min-h-11 flex-1 items-center justify-center rounded-2xl bg-red-500 px-5 text-sm font-black text-white shadow-[0_16px_36px_rgba(239,68,68,0.20)] transition hover:-translate-y-0.5 hover:bg-red-600 disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:translate-y-0 sm:flex-none"
          >
            Stop
          </button>
        </div>

        <div className="mt-5 grid gap-3 border-t border-slate-900/10 pt-5 text-sm text-slate-600">
          <div
            className={`items-center gap-2 text-sm font-black text-red-600 ${
              isActive ? "flex" : "hidden"
            }`}
          >
            <span className="h-2.5 w-2.5 rounded-full bg-red-500 shadow-[0_0_0_6px_rgba(239,68,68,0.12)]" />
            SCREENSHOT CAPTURE IS ACTIVE
          </div>
          <div>
            Status: <strong className="text-slate-950">{status}</strong>
          </div>
          <div>
            Running Time:{" "}
            <strong className="text-slate-950">{formatTime(elapsedSeconds)}</strong>
          </div>
          <div>
            Interval: <strong className="text-slate-950">Every 3 seconds</strong>
          </div>
          <div>
            Quality:{" "}
            <strong className="text-slate-950">
              High, max {SCREENSHOT_MAX_WIDTH}px wide
            </strong>
          </div>
          <div>
            Total Screenshots:{" "}
            <strong className="text-slate-950">{screenshotCount}</strong>
          </div>
          <div>
            Upload API: <strong className="text-slate-950">{UPLOAD_API}</strong>
          </div>
          <div className="break-words">
            Last file: <span className="font-black text-[#174f3e]">{lastFileName}</span>
          </div>
        </div>

        <p className="mt-5 rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm font-semibold leading-6 text-amber-800">
          Browser secretly screenshot nite dey na. User ke browser popup theke
          screen share permission dite hobe, ar full PC capture korte Entire
          Screen select korte hobe.
        </p>
      </div>

      <div className="rounded-[30px] border border-white/75 bg-white/62 p-5 shadow-[0_26px_80px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
        <video
          ref={previewRef}
          autoPlay
          muted
          playsInline
          className="aspect-video w-full rounded-[24px] border border-slate-900/10 bg-slate-950 object-contain shadow-inner"
        />

        <p className="mt-4 text-sm font-semibold leading-6 text-slate-600">
          Preview dekha gele capture active ache. Proti 3 seconds por screenshot
          server e upload hobe.
        </p>
      </div>
    </section>
  );
}
