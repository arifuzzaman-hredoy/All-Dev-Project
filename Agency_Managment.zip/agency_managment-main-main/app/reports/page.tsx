import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";
import { lastNDaysDayStrings, todayDayString } from "../lib/dates";

function MetricCard({
  label,
  value,
  hint,
  tone = "emerald",
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  tone?: "emerald" | "sky" | "amber" | "slate";
}) {
  const toneStyles = {
    emerald: {
      glow: "bg-emerald-400/18",
      text: "text-emerald-700",
      badge: "border-emerald-500/15 bg-emerald-500/10 text-emerald-700",
    },
    sky: {
      glow: "bg-sky-400/18",
      text: "text-sky-700",
      badge: "border-sky-500/15 bg-sky-500/10 text-sky-700",
    },
    amber: {
      glow: "bg-amber-400/18",
      text: "text-amber-700",
      badge: "border-amber-500/15 bg-amber-500/10 text-amber-700",
    },
    slate: {
      glow: "bg-slate-400/14",
      text: "text-slate-700",
      badge: "border-slate-500/15 bg-slate-500/10 text-slate-600",
    },
  };

  return (
    <div className="group relative overflow-hidden rounded-[30px] border border-white/75 bg-white/58 p-5 shadow-[0_22px_65px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-1 hover:bg-white/72 hover:shadow-[0_32px_90px_rgba(15,23,42,0.12)] md:p-6">
      <div
        className={`pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full blur-3xl ${toneStyles[tone].glow}`}
      />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.12))]" />

      <div className="relative z-10">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <span
            className={`rounded-full border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] ${toneStyles[tone].badge}`}
          >
            Live
          </span>
        </div>

        <div
          className={`mt-4 text-4xl font-semibold tracking-[-0.055em] md:text-5xl ${toneStyles[tone].text}`}
        >
          {value}
        </div>

        {hint ? (
          <p className="mt-3 text-xs leading-5 text-slate-500">{hint}</p>
        ) : null}
      </div>
    </div>
  );
}

function StatusPill({
  children,
  tone = "slate",
}: {
  children: ReactNode;
  tone?: "emerald" | "sky" | "amber" | "slate";
}) {
  const styles = {
    emerald: "border-emerald-500/15 bg-emerald-500/10 text-emerald-700",
    sky: "border-sky-500/15 bg-sky-500/10 text-sky-700",
    amber: "border-amber-500/15 bg-amber-500/10 text-amber-700",
    slate: "border-slate-900/5 bg-white/60 text-slate-600",
  };

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl ${styles[tone]}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current shadow-[0_0_12px_currentColor]" />
      {children}
    </span>
  );
}

function SubmissionBar({
  count,
  max,
}: {
  count: number;
  max: number;
}) {
  const percent = max > 0 ? Math.max(6, Math.round((count / max) * 100)) : 6;

  return (
    <div className="h-2.5 overflow-hidden rounded-full border border-white/70 bg-slate-900/[0.045] shadow-inner">
      <div
        className="h-full rounded-full bg-gradient-to-r from-[#174f3e] via-[#1f7a5b] to-[#2ca36f] shadow-[0_0_18px_rgba(44,163,111,0.45)]"
        style={{ width: `${percent}%` }}
      />
    </div>
  );
}

export default async function ReportsPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");

  const today = todayDayString();
  const days = lastNDaysDayStrings(7);

  const [byDay, openTasks, doneTasks] = await Promise.all([
    prisma.dailyUpdate.groupBy({
      by: ["day"],
      where: { day: { in: days } },
      _count: { _all: true },
    }),
    prisma.task.count({ where: { status: { not: "DONE" } } }),
    prisma.task.count({ where: { status: "DONE" } }),
  ]);

  const counts = new Map(byDay.map((item) => [item.day, item._count._all]));
  const submissionRows = days.map((day) => ({
    day,
    count: counts.get(day) ?? 0,
  }));

  const totalSubmissions = submissionRows.reduce(
    (total, item) => total + item.count,
    0,
  );

  const maxSubmissions = Math.max(
    1,
    ...submissionRows.map((item) => item.count),
  );

  const averageSubmissions = totalSubmissions / Math.max(1, days.length);
  const totalTasks = openTasks + doneTasks;
  const completionRate =
    totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;

  const bestDay = submissionRows.reduce(
    (best, item) => (item.count > best.count ? item : best),
    submissionRows[0] ?? { day: today, count: 0 },
  );

  return (
    <div className="relative space-y-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.23),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.16))]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-52 w-52 rounded-full bg-sky-300/20 blur-3xl" />

        <div className="relative z-10 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#174f3e] shadow-sm">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.85)]" />
              Reporting snapshot
            </span>

            <h1 className="mt-5 text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
              Reports
            </h1>

            <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-600 md:text-base">
              A clean admin overview of task progress and daily update
              submissions for the last 7 days.
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
              <StatusPill tone="emerald">As of {today}</StatusPill>
              <StatusPill tone="sky">Last 7 days</StatusPill>
              <StatusPill tone="slate">Admin view</StatusPill>
            </div>
          </div>

          <Link
            href="/dashboard"
            className="inline-flex min-h-11 w-fit items-center justify-center rounded-full border border-white/80 bg-white/60 px-5 text-sm font-medium text-slate-700 shadow-[0_14px_34px_rgba(15,23,42,0.07),inset_0_1px_0_rgba(255,255,255,0.9)] ring-1 ring-slate-900/5 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/85 hover:text-[#174f3e] hover:shadow-[0_18px_42px_rgba(15,23,42,0.10)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25"
          >
            Back to dashboard
          </Link>
        </div>
      </section>

      {/* Metrics */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Open tasks"
          value={openTasks}
          tone={openTasks > 0 ? "amber" : "emerald"}
          hint={
            openTasks > 0
              ? "Tasks that still need progress or completion."
              : "No open work is currently pending."
          }
        />

        <MetricCard
          label="Completed tasks"
          value={doneTasks}
          tone="emerald"
          hint="Tasks marked as done across the workspace."
        />

        <MetricCard
          label="Completion rate"
          value={`${completionRate}%`}
          tone={completionRate >= 70 ? "emerald" : completionRate >= 40 ? "sky" : "amber"}
          hint={`${doneTasks} done out of ${totalTasks} total tasks.`}
        />

        <MetricCard
          label="7-day submissions"
          value={totalSubmissions}
          tone="sky"
          hint={`Average ${averageSubmissions.toFixed(1)} submissions per day.`}
        />
      </div>

      {/* Insights */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(16,185,129,0.14),transparent_30%),radial-gradient(circle_at_95%_8%,rgba(251,191,36,0.10),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10 grid gap-4 md:grid-cols-3">
          <div className="rounded-[28px] border border-white/75 bg-white/55 p-4 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">
              Best submission day
            </p>
            <p className="mt-2 text-lg font-semibold tracking-[-0.03em] text-slate-950">
              {bestDay.day}
            </p>
            <p className="mt-1 text-sm text-slate-500">
              {bestDay.count} submissions
            </p>
          </div>

          <div className="rounded-[28px] border border-white/75 bg-white/55 p-4 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">
              Task workload
            </p>
            <p className="mt-2 text-lg font-semibold tracking-[-0.03em] text-slate-950">
              {totalTasks} total tasks
            </p>
            <p className="mt-1 text-sm text-slate-500">
              {openTasks} open, {doneTasks} completed
            </p>
          </div>

          <div className="rounded-[28px] border border-white/75 bg-white/55 p-4 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">
              Reporting health
            </p>
            <p className="mt-2 text-lg font-semibold tracking-[-0.03em] text-slate-950">
              {totalSubmissions > 0 ? "Active" : "No submissions"}
            </p>
            <p className="mt-1 text-sm text-slate-500">
              Based on recent daily update activity.
            </p>
          </div>
        </div>
      </section>

      {/* Submissions */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10 border-b border-slate-900/10 px-5 py-5 md:px-6">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
                Daily update submissions
              </h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">
                Submission count by day for the latest 7-day window.
              </p>
            </div>

            <span className="w-fit rounded-full border border-white/75 bg-white/60 px-3 py-1.5 text-xs font-medium text-slate-500 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
              {totalSubmissions} total submissions
            </span>
          </div>
        </div>

        <div className="relative z-10 p-4 md:p-5">
          {/* Mobile cards */}
          <div className="grid gap-3 md:hidden">
            {submissionRows.map((item) => (
              <div
                key={item.day}
                className="rounded-[26px] border border-white/75 bg-white/56 p-4 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl"
              >
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {item.day}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      Daily updates submitted
                    </p>
                  </div>

                  <StatusPill tone={item.count > 0 ? "emerald" : "amber"}>
                    {item.count}
                  </StatusPill>
                </div>

                <div className="mt-4">
                  <SubmissionBar count={item.count} max={maxSubmissions} />
                </div>
              </div>
            ))}
          </div>

          {/* Desktop table */}
          <div className="hidden overflow-hidden rounded-[28px] border border-white/75 bg-white/45 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl md:block">
            <table className="w-full text-left text-sm">
              <thead className="bg-white/55 text-xs uppercase tracking-[0.12em] text-slate-400">
                <tr className="border-b border-slate-900/10">
                  <th className="px-5 py-4 font-medium">Day</th>
                  <th className="px-5 py-4 font-medium">Activity</th>
                  <th className="px-5 py-4 text-right font-medium">
                    Submissions
                  </th>
                </tr>
              </thead>

              <tbody>
                {submissionRows.map((item) => (
                  <tr
                    key={item.day}
                    className="border-b border-slate-900/10 last:border-b-0"
                  >
                    <td className="whitespace-nowrap px-5 py-4 font-medium text-slate-800">
                      {item.day}
                    </td>

                    <td className="px-5 py-4">
                      <SubmissionBar count={item.count} max={maxSubmissions} />
                    </td>

                    <td className="px-5 py-4 text-right">
                      <StatusPill tone={item.count > 0 ? "emerald" : "amber"}>
                        {item.count}
                      </StatusPill>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}