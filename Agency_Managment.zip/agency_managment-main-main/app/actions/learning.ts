"use server";

import { redirect } from "next/navigation";
import { prisma } from "../lib/db";
import { getSessionUser } from "../lib/auth";
import { todayDayString } from "../lib/dates";

export async function saveLearningStatus(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const learningPlan = String(formData.get("learningPlan") || "").trim();
  const completedLearning = String(formData.get("completedLearning") || "").trim();

  if (!learningPlan) redirect("/learning?error=status");

  const day = todayDayString();

  await prisma.learningStatus.upsert({
    where: { userId_day: { userId: user.id, day } },
    create: {
      userId: user.id,
      day,
      learningPlan,
      completedLearning: completedLearning || null,
    },
    update: {
      learningPlan,
      completedLearning: completedLearning || null,
    },
  });

  redirect("/learning?saved=1");
}

export async function addLearningItem(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const title = String(formData.get("title") || "").trim();
  const url = String(formData.get("url") || "").trim();
  const notes = String(formData.get("notes") || "").trim();

  if (!title) redirect("/learning?error=title");

  await prisma.learningItem.create({
    data: {
      userId: user.id,
      title,
      url: url || null,
      notes: notes || null,
    },
  });

  redirect("/learning?added=1");
}

export async function deleteLearningItem(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const id = String(formData.get("id") || "");
  if (!id) redirect("/learning");

  const item = await prisma.learningItem.findUnique({
    where: { id },
    select: { userId: true },
  });
  if (!item || item.userId !== user.id) redirect("/learning");

  await prisma.learningItem.delete({ where: { id } });
  redirect("/learning?deleted=1");
}
