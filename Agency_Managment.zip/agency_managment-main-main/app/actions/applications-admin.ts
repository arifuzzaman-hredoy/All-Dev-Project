"use server";

import { ApplicationStatus } from "@prisma/client";
import { redirect } from "next/navigation";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";

async function requireAdmin() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");
  return user;
}

export async function adminUpdateApplicationStatus(formData: FormData) {
  await requireAdmin();

  const id = String(formData.get("id") || "");
  const status = String(formData.get("status") || "") as ApplicationStatus;

  if (!id) redirect("/admin/applications?error=missing-id");
  if (!Object.values(ApplicationStatus).includes(status)) {
    redirect("/admin/applications?error=invalid-status");
  }

  await prisma.application.update({
    where: { id },
    data: { status },
  });

  redirect("/admin/applications?updated=1");
}

