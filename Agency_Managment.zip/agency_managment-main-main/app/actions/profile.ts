"use server";

import { redirect } from "next/navigation";
import { prisma } from "../lib/db";
import { getSessionUser } from "../lib/auth";

export async function saveProfile(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const name = String(formData.get("name") || "").trim();
  const title = String(formData.get("title") || "").trim();
  const department = String(formData.get("department") || "").trim();
  const phone = String(formData.get("phone") || "").trim();
  const location = String(formData.get("location") || "").trim();
  const bio = String(formData.get("bio") || "").trim();

  if (!name) redirect("/profile?error=name");

  await prisma.user.update({
    where: { id: user.id },
    data: {
      name,
      profile: {
        upsert: {
          create: {
            title: title || null,
            department: department || null,
            phone: phone || null,
            location: location || null,
            bio: bio || null,
          },
          update: {
            title: title || null,
            department: department || null,
            phone: phone || null,
            location: location || null,
            bio: bio || null,
          },
        },
      },
    },
  });

  redirect("/profile?saved=1");
}

