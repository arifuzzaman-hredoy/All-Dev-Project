"use server";

import { redirect } from "next/navigation";
import { prisma } from "../lib/db";
import { setSession, clearSession } from "../lib/auth";
import { hashPassword, verifyPassword } from "../lib/password";
import {
  consumePasswordResetToken,
  createPasswordResetToken,
  getValidPasswordResetToken,
} from "../lib/password-reset";
import { sendPasswordResetEmail } from "../lib/email";

export async function login(formData: FormData) {
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");

  if (!email || !password) redirect("/login?error=missing");

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, passwordHash: true },
  });

  if (!user) redirect("/login?error=invalid");

  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) redirect("/login?error=invalid");

  await setSession(user.id);
  redirect("/dashboard");
}

export async function logout() {
  await clearSession();
  redirect("/login");
}

export async function requestPasswordReset(formData: FormData) {
  const email = String(formData.get("email") || "").trim().toLowerCase();

  if (!email) redirect("/forgot-password?error=missing");

  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, name: true },
  });

  if (user) {
    const rawToken = await createPasswordResetToken(user.id);
    const appUrl = getAppUrl();
    const resetUrl = `${appUrl}/reset-password?token=${encodeURIComponent(rawToken)}`;
    await sendPasswordResetEmail({
      email: user.email,
      name: user.name,
      resetUrl,
    });
  }

  redirect("/forgot-password?sent=1");
}

export async function resetPassword(formData: FormData) {
  const token = String(formData.get("token") || "");
  const password = String(formData.get("password") || "");
  const confirmPassword = String(formData.get("confirmPassword") || "");

  if (!token) redirect("/reset-password?error=invalid");
  if (!password || !confirmPassword) {
    redirect(`/reset-password?token=${encodeURIComponent(token)}&error=missing`);
  }
  if (password !== confirmPassword) {
    redirect(`/reset-password?token=${encodeURIComponent(token)}&error=match`);
  }

  const resetToken = await getValidPasswordResetToken(token);
  if (!resetToken) redirect("/reset-password?error=invalid");

  const passwordHash = await hashPassword(password);

  await prisma.user.update({
    where: { id: resetToken.userId },
    data: { passwordHash },
  });

  await consumePasswordResetToken(resetToken.id);

  redirect("/login?error=reset-success");
}

function getAppUrl() {
  const appUrl = process.env.APP_URL;
  if (!appUrl) {
    throw new Error("APP_URL must be set for password reset emails.");
  }

  return appUrl.replace(/\/$/, "");
}
