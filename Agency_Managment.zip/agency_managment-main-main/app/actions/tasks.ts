"use server";

import { redirect } from "next/navigation";
import { TaskStatus } from "@prisma/client";
import { prisma } from "../lib/db";
import { getSessionUser } from "../lib/auth";

export async function createTask(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  if (user.role === "EMPLOYEE") redirect("/tasks?error=forbidden");

  const title = String(formData.get("title") || "").trim();
  const description = String(formData.get("description") || "").trim();
  const assigneeId = String(formData.get("assigneeId") || "");
  const dueDay = String(formData.get("dueDay") || "").trim();

  if (!title || !assigneeId) redirect("/tasks?error=missing");

  // LEAD can only assign within their teams.
  if (user.role === "LEAD") {
    const teams = await prisma.team.findMany({
      where: { leadId: user.id },
      select: { id: true },
    });
    const teamIds = teams.map((t) => t.id);
    const allowed = await prisma.user.findFirst({
      where: { id: assigneeId, teamId: { in: teamIds } },
      select: { id: true },
    });
    if (!allowed) redirect("/tasks?error=forbidden");
  }

  await prisma.task.create({
    data: {
      title,
      description: description || null,
      dueDay: dueDay || null,
      assigneeId,
      createdById: user.id,
    },
  });

  redirect("/tasks?created=1");
}

export async function setTaskStatus(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const taskId = String(formData.get("taskId") || "");
  const next = String(formData.get("status") || "") as TaskStatus;

  if (!taskId) redirect("/tasks");
  if (!Object.values(TaskStatus).includes(next)) redirect("/tasks");

  const task = await prisma.task.findUnique({
    where: { id: taskId },
    select: { assigneeId: true },
  });
  if (!task) redirect("/tasks");

  if (user.role === "EMPLOYEE" && task.assigneeId !== user.id) {
    redirect("/tasks?error=forbidden");
  }

  await prisma.task.update({ where: { id: taskId }, data: { status: next } });
  redirect("/tasks?updated=1");
}

