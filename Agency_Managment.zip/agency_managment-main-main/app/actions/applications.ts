"use server";

import { redirect } from "next/navigation";
import { prisma } from "../lib/db";

export async function submitApplication(formData: FormData) {
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const message = String(formData.get("message") || "").trim();

  if (!name || !email) redirect("/apply?error=missing");
  if (!email.includes("@")) redirect("/apply?error=invalid");

  await prisma.application.create({
    data: {
      name,
      email,
      message: message || null,
    },
  });

  redirect("/apply?sent=1");
}

