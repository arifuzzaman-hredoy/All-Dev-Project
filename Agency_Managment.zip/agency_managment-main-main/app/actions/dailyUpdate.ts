"use server";

import { redirect } from "next/navigation";
import { prisma } from "../lib/db";
import { getSessionUser } from "../lib/auth";
import { todayDayString } from "../lib/dates";

export async function saveTodayUpdate(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const todayPlan = String(formData.get("todayPlan") || "").trim();
  const completedWork = String(formData.get("completedWork") || "").trim();
  const blockers = String(formData.get("blockers") || "").trim();

  if (!todayPlan) {
    redirect("/updates/today?error=missing");
  }

  const day = todayDayString();

  await prisma.dailyUpdate.upsert({
    where: { userId_day: { userId: user.id, day } },
    create: {
      userId: user.id,
      day,
      todayPlan,
      completedWork: completedWork || null,
      blockers: blockers || null,
    },
    update: {
      todayPlan,
      completedWork: completedWork || null,
      blockers: blockers || null,
    },
  });

  redirect("/updates/today?saved=1");
}
