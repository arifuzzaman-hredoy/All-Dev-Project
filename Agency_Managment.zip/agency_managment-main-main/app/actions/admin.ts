"use server";

import { Role } from "@prisma/client";
import { redirect } from "next/navigation";
import { prisma } from "../lib/db";
import { getSessionUser } from "../lib/auth";
import { hashPassword } from "../lib/password";

async function requireAdmin() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");
  return user;
}

export async function adminCreateUser(formData: FormData) {
  await requireAdmin();

  const email = String(formData.get("email") || "").trim().toLowerCase();
  const name = String(formData.get("name") || "").trim();
  const role = String(formData.get("role") || "EMPLOYEE") as Role;
  const password = String(formData.get("password") || "");
  const teamId = String(formData.get("teamId") || "").trim();

  if (!email || !name || !password) redirect("/admin/users?error=missing");
  if (!Object.values(Role).includes(role)) redirect("/admin/users?error=role");

  const passwordHash = await hashPassword(password);

  await prisma.user.create({
    data: {
      email,
      name,
      role,
      passwordHash,
      teamId: teamId || null,
      profile: { create: {} },
    },
  });

  redirect("/admin/users?created=1");
}

export async function adminUpdateUser(formData: FormData) {
  await requireAdmin();

  const id = String(formData.get("id") || "");
  const role = String(formData.get("role") || "") as Role;
  const teamId = String(formData.get("teamId") || "").trim();
  const chatBlocked = String(formData.get("chatBlocked") || "") === "true";

  if (!id) redirect("/admin/users");
  if (role && !Object.values(Role).includes(role)) redirect("/admin/users?error=role");

  await prisma.user.update({
    where: { id },
    data: {
      ...(role ? { role } : {}),
      teamId: teamId || null,
      chatBlocked,
    },
  });

  redirect("/admin/users?updated=1");
}

export async function adminResetPassword(formData: FormData) {
  await requireAdmin();

  const id = String(formData.get("id") || "");
  const password = String(formData.get("password") || "");
  if (!id || !password) redirect("/admin/users?error=missing");

  const passwordHash = await hashPassword(password);
  await prisma.user.update({ where: { id }, data: { passwordHash } });
  redirect("/admin/users?pw=1");
}

export async function adminCreateTeam(formData: FormData) {
  await requireAdmin();

  const name = String(formData.get("name") || "").trim();
  const leadId = String(formData.get("leadId") || "").trim();
  if (!name) redirect("/admin/teams?error=missing");

  await prisma.team.create({
    data: {
      name,
      leadId: leadId || null,
    },
  });

  if (leadId) {
    await prisma.user.update({
      where: { id: leadId },
      data: { role: Role.LEAD },
    });
  }

  redirect("/admin/teams?created=1");
}

export async function adminUpdateTeam(formData: FormData) {
  await requireAdmin();

  const id = String(formData.get("id") || "");
  const leadId = String(formData.get("leadId") || "").trim();
  if (!id) redirect("/admin/teams");

  await prisma.team.update({
    where: { id },
    data: { leadId: leadId || null },
  });

  if (leadId) {
    await prisma.user.update({
      where: { id: leadId },
      data: { role: Role.LEAD },
    });
  }

  redirect("/admin/teams?updated=1");
}

export async function adminBulkAssignUsersToTeam(formData: FormData) {
  await requireAdmin();

  const teamId = String(formData.get("teamId") || "").trim();
  const memberIds = formData
    .getAll("memberIds")
    .map((value) => String(value).trim())
    .filter(Boolean);

  if (!teamId) redirect("/admin/teams?error=missing_team");
  if (memberIds.length === 0) redirect("/admin/teams?error=missing_members");

  const team = await prisma.team.findUnique({
    where: { id: teamId },
    select: { id: true },
  });
  if (!team) redirect("/admin/teams?error=missing_team");

  await prisma.user.updateMany({
    where: { id: { in: memberIds } },
    data: { teamId },
  });

  redirect("/admin/teams?updated=1");
}
