"use server";

import { AttendanceStatus, Prisma } from "@prisma/client";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "../lib/db";
import { getSessionUser } from "../lib/auth";
import { todayDayString } from "../lib/dates";
import {
  attendanceDayEnd,
  closeStaleOpenAttendanceSessions,
} from "../lib/attendance";

const ATTENDANCE_PATH = "/attendance";
const WORK_START_HOUR = 10;
const DHAKA_OFFSET = "+06:00";

function redirectToAttendance(params: Record<string, string>): never {
  const query = new URLSearchParams(params);
  redirect(`${ATTENDANCE_PATH}?${query.toString()}`);
}

function revalidateAttendanceViews() {
  revalidatePath(ATTENDANCE_PATH);
  revalidatePath("/dashboard");
}

function isUniqueConstraintError(error: unknown) {
  return (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    error.code === "P2002"
  );
}

function getAttendanceStatusForCheckIn(now: Date) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: process.env.APP_TZ || "Asia/Dhaka",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(now);

  const hour = Number(parts.find((part) => part.type === "hour")?.value ?? 0);
  return hour >= WORK_START_HOUR
    ? AttendanceStatus.LATE
    : AttendanceStatus.PRESENT;
}

function parseOptionalDateTime(day: string, value: FormDataEntryValue | null) {
  const time = String(value || "").trim();
  if (!time) return null;

  const date = new Date(`${day}T${time}:00${DHAKA_OFFSET}`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function parseSessionRange(day: string, value: string) {
  const [startRaw, endRaw] = value.split("-").map((item) => item.trim());
  const startedAt = parseOptionalDateTime(day, startRaw || null);
  const parsedEndedAt = parseOptionalDateTime(day, endRaw || null);

  if (!startedAt) return null;
  const endedAt =
    parsedEndedAt ?? (day < todayDayString() ? attendanceDayEnd(day) : null);
  if (endedAt && endedAt <= startedAt) return null;

  return { startedAt, endedAt };
}

function parseSessionRanges(day: string, value: FormDataEntryValue | null) {
  const raw = String(value || "").trim();
  if (!raw) return [];

  return raw
    .split(/[\n,]+/)
    .map((item) => item.trim())
    .filter(Boolean)
    .map((item) => parseSessionRange(day, item));
}

async function requireAdmin() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");
  return user;
}

export async function markPresent() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  await closeStaleOpenAttendanceSessions(user.id);

  const day = todayDayString();
  const now = new Date();

  const existing = await prisma.attendance.findUnique({
    where: { userId_day: { userId: user.id, day } },
    select: {
      id: true,
      checkInAt: true,
      status: true,
      sessions: {
        where: { endedAt: null },
        select: { id: true },
        take: 1,
      },
    },
  });

  if (existing) {
    redirectToAttendance({ saved: "already-present" });
  }

  try {
    await prisma.$transaction(async (tx) => {
      const attendance = await tx.attendance.create({
        data: {
          userId: user.id,
          day,
          checkInAt: now,
          status: getAttendanceStatusForCheckIn(now),
        },
        select: { id: true },
      });

      await tx.attendanceSession.create({
        data: {
          attendanceId: attendance.id,
          startedAt: now,
        },
      });
    });
  } catch (error) {
    if (isUniqueConstraintError(error)) {
      redirectToAttendance({ saved: "already-present" });
    }
    throw error;
  }

  revalidateAttendanceViews();
  redirectToAttendance({ saved: "present" });
}

export async function clockIn() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  await closeStaleOpenAttendanceSessions(user.id);

  const day = todayDayString();
  const now = new Date();

  const existing = await prisma.attendance.findUnique({
    where: { userId_day: { userId: user.id, day } },
    select: {
      id: true,
      checkInAt: true,
      status: true,
      sessions: {
        where: { endedAt: null },
        select: { id: true },
        take: 1,
      },
    },
  });

  if (!existing) {
    redirectToAttendance({ error: "present-required" });
  }

  if (
    existing.status === AttendanceStatus.ABSENT ||
    existing.status === AttendanceStatus.LEAVE
  ) {
    redirectToAttendance({ error: "not-working-day" });
  }

  if (existing?.sessions[0]) {
    redirectToAttendance({ saved: "already-checked-in" });
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.attendance.update({
        where: { id: existing.id },
        data: {
          checkInAt: existing.checkInAt ?? now,
        },
      });

      await tx.attendanceSession.create({
        data: {
          attendanceId: existing.id,
          startedAt: now,
        },
      });
    });
  } catch (error) {
    if (isUniqueConstraintError(error)) {
      redirectToAttendance({ saved: "already-checked-in" });
    }
    throw error;
  }

  revalidateAttendanceViews();
  redirectToAttendance({ saved: "checkin" });
}

export async function clockOut() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  await closeStaleOpenAttendanceSessions(user.id);

  const day = todayDayString();

  const existing = await prisma.attendance.findUnique({
    where: { userId_day: { userId: user.id, day } },
    select: {
      id: true,
      checkInAt: true,
      status: true,
      sessions: {
        where: { endedAt: null },
        orderBy: { startedAt: "desc" },
        select: { id: true },
        take: 1,
      },
    },
  });

  if (!existing) {
    redirectToAttendance({ error: "present-required" });
  }

  if (
    existing.status === AttendanceStatus.ABSENT ||
    existing.status === AttendanceStatus.LEAVE
  ) {
    redirectToAttendance({ error: "not-working-day" });
  }

  if (!existing?.checkInAt) {
    redirectToAttendance({ error: "no-checkin" });
  }

  const activeSession = existing.sessions[0];

  if (!activeSession) {
    redirectToAttendance({ saved: "already-checked-out" });
  }

  const now = new Date();

  const closed = await prisma.$transaction(async (tx) => {
    const updated = await tx.attendanceSession.updateMany({
      where: { id: activeSession.id, endedAt: null },
      data: { endedAt: now },
    });

    if (updated.count === 0) return false;

    await tx.attendance.update({
      where: { id: existing.id },
      data: { checkOutAt: now },
    });

    return true;
  });

  if (!closed) {
    redirectToAttendance({ saved: "already-checked-out" });
  }

  revalidateAttendanceViews();
  redirectToAttendance({ saved: "checkout" });
}

export async function adminSaveAttendance(formData: FormData) {
  await requireAdmin();
  await closeStaleOpenAttendanceSessions();

  const userId = String(formData.get("userId") || "").trim();
  const day = String(formData.get("day") || "").trim();
  const status = String(formData.get("status") || "") as AttendanceStatus;
  const note = String(formData.get("note") || "").trim();

  if (!userId || !day) redirectToAttendance({ error: "missing" });
  if (!Object.values(AttendanceStatus).includes(status)) {
    redirectToAttendance({ day, error: "status" });
  }

  const employee = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true },
  });
  if (!employee) redirectToAttendance({ day, error: "missing-user" });

  const isNonWorkingStatus =
    status === AttendanceStatus.ABSENT || status === AttendanceStatus.LEAVE;

  const parsedSessions = isNonWorkingStatus
    ? []
    : parseSessionRanges(day, formData.get("sessions"));

  if (parsedSessions.some((session) => !session)) {
    redirectToAttendance({ day, error: "sessions" });
  }

  const sessions = parsedSessions as Array<{
    startedAt: Date;
    endedAt: Date | null;
  }>;

  const checkInAt = sessions[0]?.startedAt ?? null;
  const checkOutAt =
    sessions
      .map((session) => session.endedAt)
      .filter((date): date is Date => Boolean(date))
      .at(-1) ?? null;

  await prisma.$transaction(async (tx) => {
    const attendance = await tx.attendance.upsert({
      where: { userId_day: { userId, day } },
      create: {
        userId,
        day,
        status,
        checkInAt,
        checkOutAt,
        note: note || null,
      },
      update: {
        status,
        checkInAt,
        checkOutAt,
        note: note || null,
      },
      select: { id: true },
    });

    await tx.attendanceSession.deleteMany({
      where: { attendanceId: attendance.id },
    });

    if (sessions.length > 0) {
      await tx.attendanceSession.createMany({
        data: sessions.map((session) => ({
          attendanceId: attendance.id,
          startedAt: session.startedAt,
          endedAt: session.endedAt,
        })),
      });
    }
  });

  revalidateAttendanceViews();
  redirectToAttendance({ day, saved: "admin" });
}
