import type { AttendanceStatus } from "@prisma/client";
import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import {
  adminSaveAttendance,
  clockIn,
  clockOut,
  markPresent,
} from "../actions/attendance";
import { AttendanceAutoRefresh } from "./attendance-auto-refresh";
import { getSessionUser } from "../lib/auth";
import {
  closeStaleOpenAttendanceSessions,
  normalizeSessionEndForDisplay,
} from "../lib/attendance";
import { prisma } from "../lib/db";
import { todayDayString } from "../lib/dates";

const ATTENDANCE_STATUSES: AttendanceStatus[] = [
  "PRESENT",
  "LATE",
  "HALF_DAY",
  "ABSENT",
  "LEAVE",
];
const USER_HISTORY_LIMIT = 60;

type AttendanceSession = {
  startedAt: Date;
  endedAt: Date | null;
};

function formatStatus(status?: string | null) {
  if (!status) return "Not marked";
  return status
    .toLowerCase()
    .replaceAll("_", " ")
    .replace(/^\w/, (letter) => letter.toUpperCase());
}

function formatTime(date?: Date | null) {
  if (!date) return "-";
  return new Intl.DateTimeFormat("en-US", {
    timeZone: process.env.APP_TZ || "Asia/Dhaka",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function formatTimeInput(date?: Date | null) {
  if (!date) return "";
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: process.env.APP_TZ || "Asia/Dhaka",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);

  const hour = parts.find((part) => part.type === "hour")?.value ?? "00";
  const minute = parts.find((part) => part.type === "minute")?.value ?? "00";
  return `${hour}:${minute}`;
}

function formatSessionInput(sessions: AttendanceSession[]) {
  const currentDay = todayDayString();

  return sessions
    .map((session) => {
      const start = formatTimeInput(session.startedAt);
      const end = formatTimeInput(
        normalizeSessionEndForDisplay(session, currentDay),
      );
      return end ? `${start}-${end}` : `${start}-`;
    })
    .join(", ");
}

function getWorkedMs(sessions: AttendanceSession[]) {
  const now = Date.now();
  const currentDay = todayDayString();

  return sessions.reduce((total, session) => {
    const displayEnd = normalizeSessionEndForDisplay(session, currentDay);
    const endTime = displayEnd?.getTime() ?? now;
    const startTime = session.startedAt.getTime();
    return total + Math.max(0, endTime - startTime);
  }, 0);
}

function formatDuration(ms: number) {
  if (ms <= 0) return "0h";
  const totalMinutes = Math.floor(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  if (hours && minutes) return `${hours}h ${minutes}m`;
  if (hours) return `${hours}h`;
  return `${minutes}m`;
}

function toneForStatus(status?: string | null) {
  if (status === "PRESENT") return "emerald";
  if (status === "LATE" || status === "HALF_DAY") return "amber";
  if (status === "ABSENT" || status === "LEAVE") return "rose";
  return "slate";
}

function Notice({
  type,
  children,
}: {
  type: "success" | "error";
  children: ReactNode;
}) {
  const styles = {
    success: "border-emerald-500/20 bg-emerald-500/10 text-emerald-700",
    error: "border-red-500/20 bg-red-500/10 text-red-700",
  };

  return (
    <div
      className={`relative overflow-hidden rounded-[24px] border px-4 py-3 text-sm font-medium shadow-sm backdrop-blur-xl ${styles[type]}`}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_10%_0%,rgba(255,255,255,0.72),transparent_35%)]" />
      <div className="relative flex items-center gap-2">
        <span className="h-2 w-2 rounded-full bg-current shadow-[0_0_14px_currentColor]" />
        <span>{children}</span>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status?: string | null }) {
  const tone = toneForStatus(status);
  const styles = {
    emerald:
      "border-emerald-500/20 bg-emerald-500/10 text-emerald-700 shadow-emerald-500/10",
    amber:
      "border-amber-500/25 bg-amber-500/10 text-amber-700 shadow-amber-500/10",
    rose: "border-rose-500/20 bg-rose-500/10 text-rose-700 shadow-rose-500/10",
    slate:
      "border-slate-500/20 bg-slate-500/10 text-slate-600 shadow-slate-500/10",
  };

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium shadow-sm ${styles[tone]}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current shadow-[0_0_12px_currentColor]" />
      {formatStatus(status)}
    </span>
  );
}

function ActionButton({
  children,
  disabled = false,
}: {
  children: ReactNode;
  disabled?: boolean;
}) {
  return (
    <button
      type="submit"
      disabled={disabled}
      className="group relative inline-flex min-h-12 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#174f3e] via-[#1f7a5b] to-[#2ca36f] px-7 text-sm font-semibold text-white shadow-[0_18px_42px_rgba(23,79,62,0.30)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_56px_rgba(23,79,62,0.42)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/35 disabled:cursor-not-allowed disabled:from-slate-400 disabled:via-slate-400 disabled:to-slate-500 disabled:opacity-70 disabled:hover:translate-y-0"
    >
      <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.42),transparent_34%)] opacity-80" />
      <span className="relative z-10">{children}</span>
    </button>
  );
}

function GlassLink({
  href,
  children,
}: {
  href: string;
  children: ReactNode;
}) {
  return (
    <Link
      href={href}
      className="inline-flex min-h-11 items-center justify-center rounded-full border border-white/80 bg-white/60 px-5 text-sm font-medium text-slate-700 shadow-[0_14px_34px_rgba(15,23,42,0.07),inset_0_1px_0_rgba(255,255,255,0.9)] ring-1 ring-slate-900/5 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/85 hover:text-[#174f3e] hover:shadow-[0_18px_42px_rgba(15,23,42,0.10)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25"
    >
      {children}
    </Link>
  );
}

function MetricCard({
  label,
  value,
  hint,
}: {
  label: string;
  value: ReactNode;
  hint: string;
}) {
  return (
    <div className="rounded-[28px] border border-white/75 bg-white/58 p-5 shadow-[0_20px_55px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <div className="mt-3 text-3xl font-semibold tracking-[-0.045em] text-slate-950">
        {value}
      </div>
      <p className="mt-2 text-xs leading-5 text-slate-500">{hint}</p>
    </div>
  );
}

function SessionList({ sessions }: { sessions: AttendanceSession[] }) {
  if (sessions.length === 0) {
    return <p className="text-xs text-slate-400">No work sessions recorded.</p>;
  }

  const currentDay = todayDayString();

  return (
    <div className="grid gap-2">
      {sessions.map((session, index) => {
        const displayEnd = normalizeSessionEndForDisplay(session, currentDay);

        return (
          <div
            key={`${session.startedAt.toISOString()}-${index}`}
            className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-white/70 bg-white/55 px-3 py-2 text-xs text-slate-600"
          >
            <span className="font-medium text-slate-800">
              {formatTime(session.startedAt)} - {formatTime(displayEnd)}
            </span>
            <span>{formatDuration(getWorkedMs([session]))}</span>
          </div>
        );
      })}
    </div>
  );
}

function AdminAttendanceForm({
  formId,
  person,
  day,
}: {
  formId: string;
  person: {
    id: string;
    attendances: Array<{
      status: AttendanceStatus;
      note: string | null;
      sessions: AttendanceSession[];
    }>;
  };
  day: string;
}) {
  const attendance = person.attendances[0];

  return (
    <>
      <td className="px-5 py-4">
        <select
          form={formId}
          name="status"
          defaultValue={attendance?.status ?? "PRESENT"}
          className="w-full rounded-2xl border border-white/80 bg-white/80 px-3 py-2 text-xs font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none focus:ring-4 focus:ring-emerald-300/20"
        >
          {ATTENDANCE_STATUSES.map((status) => (
            <option key={status} value={status}>
              {formatStatus(status)}
            </option>
          ))}
        </select>
      </td>

      <td className="px-5 py-4">
        <input
          form={formId}
          name="sessions"
          defaultValue={formatSessionInput(attendance?.sessions ?? [])}
          placeholder="06:00-08:00, 14:00-20:00"
          className="w-full min-w-[220px] rounded-2xl border border-white/80 bg-white/80 px-3 py-2 text-xs font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none placeholder:text-slate-400 focus:ring-4 focus:ring-emerald-300/20"
        />
      </td>

      <td className="px-5 py-4 text-slate-700">
        {formatDuration(getWorkedMs(attendance?.sessions ?? []))}
      </td>

      <td className="px-5 py-4">
        <input
          form={formId}
          name="note"
          defaultValue={attendance?.note ?? ""}
          placeholder="Optional"
          className="w-full rounded-2xl border border-white/80 bg-white/80 px-3 py-2 text-xs font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none placeholder:text-slate-400 focus:ring-4 focus:ring-emerald-300/20"
        />
      </td>

      <td className="px-5 py-4">
        <form id={formId} action={adminSaveAttendance}>
          <input type="hidden" name="userId" value={person.id} />
          <input type="hidden" name="day" value={day} />
        </form>
        <button
          form={formId}
          type="submit"
          className="inline-flex min-h-10 items-center justify-center rounded-full border border-white/80 bg-white/65 px-4 text-xs font-medium text-slate-700 shadow-[0_12px_28px_rgba(15,23,42,0.08),inset_0_1px_0_rgba(255,255,255,0.95)] ring-1 ring-slate-900/5 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white hover:text-[#174f3e] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25"
        >
          Save
        </button>
      </td>
    </>
  );
}

export default async function AttendancePage({
  searchParams,
}: {
  searchParams: Promise<{ day?: string; saved?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const today = todayDayString();
  const canSeeTeam = user.role === "ADMIN" || user.role === "LEAD";
  await closeStaleOpenAttendanceSessions(canSeeTeam ? undefined : user.id);

  const { day: queryDay, saved, error } = await searchParams;
  const selectedDay =
    queryDay && /^\d{4}-\d{2}-\d{2}$/.test(queryDay) ? queryDay : today;

  const [todayAttendance, recentAttendance] = await Promise.all([
    prisma.attendance.findUnique({
      where: { userId_day: { userId: user.id, day: today } },
      include: { sessions: { orderBy: { startedAt: "asc" } } },
    }),
    prisma.attendance.findMany({
      where: { userId: user.id },
      include: { sessions: { orderBy: { startedAt: "asc" } } },
      orderBy: { day: "desc" },
      take: USER_HISTORY_LIMIT,
    }),
  ]);

  const adminAttendanceHistory =
    user.role === "ADMIN"
      ? await prisma.attendance.findMany({
          include: {
            user: {
              select: {
                name: true,
                email: true,
                role: true,
              },
            },
            sessions: { orderBy: { startedAt: "asc" } },
          },
          orderBy: [{ day: "desc" }, { createdAt: "desc" }],
        })
      : [];

  const todaySessions = todayAttendance?.sessions ?? [];
  const activeSession = todaySessions.find((session) => !session.endedAt);
  const totalWorkedToday = getWorkedMs(todaySessions);
  const hasMarkedPresent = Boolean(todayAttendance);

  const people = canSeeTeam
    ? await prisma.user.findMany({
        where:
          user.role === "ADMIN"
            ? {}
            : {
                team: { leadId: user.id },
              },
        orderBy: { name: "asc" },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          attendances: {
            where: { day: selectedDay },
            select: {
              status: true,
              note: true,
              sessions: {
                select: {
                  startedAt: true,
                  endedAt: true,
                },
                orderBy: { startedAt: "asc" },
              },
            },
            take: 1,
          },
        },
        take: 500,
      })
    : [];

  const markedCount = people.filter((person) => person.attendances[0]).length;
  const workingNowCount = people.filter((person) =>
    person.attendances[0]?.sessions.some((session) => !session.endedAt),
  ).length;
  const absentCount = people.filter((person) =>
    ["ABSENT", "LEAVE"].includes(person.attendances[0]?.status ?? ""),
  ).length;

  return (
    <div className="relative space-y-6">
      <AttendanceAutoRefresh />

      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.23),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.16))]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />

        <div className="relative z-10 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#174f3e] shadow-sm">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.85)]" />
              Attendance
            </span>

            <h1 className="mt-5 text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
              Attendance
            </h1>

            <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-600 md:text-base">
              Clock in and out as many times as needed. The system adds each
              work session into your total hours for the day.
            </p>
          </div>

          <GlassLink href="/dashboard">Back to dashboard</GlassLink>
        </div>
      </section>

      {saved ? (
        <Notice type="success">
          {saved === "present"
            ? "Present marked. Your first work session has started."
            : saved === "checkin"
            ? "Clock-in saved. A new work session has started."
            : saved === "checkout"
              ? "Clock-out saved. Your work session has ended."
              : saved === "admin"
                ? "Attendance updated."
                : "Attendance is already up to date."}
        </Notice>
      ) : null}

      {error ? (
        <Notice type="error">
          {error === "present-required"
            ? "Please press Present first. Work sessions can start only after attendance is marked."
            : error === "no-checkin"
            ? "Please clock in before clocking out."
            : error === "not-working-day"
              ? "This day is marked absent or leave, so work sessions cannot be recorded."
            : error === "sessions"
              ? "Use session format like 06:00-08:00, 14:00-20:00."
              : "Attendance could not be saved. Check the required values and try again."}
        </Notice>
      ) : null}

      <section className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_24px_70px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_15%_0%,rgba(16,185,129,0.16),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.5),rgba(255,255,255,0.14))]" />

          <div className="relative z-10">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
                  Today
                </h2>
                <p className="mt-1 text-sm text-slate-500">{today}</p>
              </div>
              <StatusBadge status={todayAttendance?.status} />
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              <MetricCard
                label="Attendance"
                value={hasMarkedPresent ? "Present" : "Not marked"}
                hint={
                  hasMarkedPresent
                    ? "Your attendance is active for today."
                    : "Press Present to start counting work time."
                }
              />
              <MetricCard
                label="Total time"
                value={formatDuration(totalWorkedToday)}
                hint="Sum of all work sessions today."
              />
              <MetricCard
                label="Current session"
                value={
                  activeSession
                    ? formatTime(activeSession.startedAt)
                    : hasMarkedPresent
                      ? "Closed"
                      : "Waiting"
                }
                hint={
                  activeSession
                    ? "You are currently clocked in."
                    : hasMarkedPresent
                      ? "Start another session when you resume work."
                      : "Mark present to start your first session."
                }
              />
            </div>

            <div className="mt-5 rounded-[28px] border border-white/75 bg-white/50 p-4 ring-1 ring-slate-900/5">
              <h3 className="text-sm font-semibold text-slate-950">
                Today sessions
              </h3>
              <div className="mt-3">
                <SessionList sessions={todaySessions} />
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              {!hasMarkedPresent ? (
                <form action={markPresent}>
                  <ActionButton>Present & start work</ActionButton>
                </form>
              ) : null}

              <form action={clockIn}>
                <ActionButton
                  disabled={!hasMarkedPresent || Boolean(activeSession)}
                >
                  {todaySessions.length > 0 ? "Clock in again" : "Clock in"}
                </ActionButton>
              </form>

              <form action={clockOut}>
                <ActionButton disabled={!hasMarkedPresent || !activeSession}>
                  Clock out
                </ActionButton>
              </form>
            </div>
          </div>
        </div>

        <section className="overflow-hidden rounded-[34px] border border-white/75 bg-white/55 shadow-[0_24px_70px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
          <div className="border-b border-slate-200/70 px-5 py-4">
            <h2 className="text-lg font-semibold tracking-[-0.02em] text-slate-950">
              Your history
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Showing your latest {USER_HISTORY_LIMIT} attendance records.
            </p>
          </div>

          <div className="divide-y divide-slate-200/70">
            {recentAttendance.length === 0 ? (
              <p className="px-5 py-8 text-sm text-slate-500">
                No attendance records yet.
              </p>
            ) : (
              recentAttendance.map((item) => (
                <div key={item.id} className="grid gap-3 px-5 py-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-medium text-slate-950">{item.day}</p>
                      <p className="mt-1 text-xs text-slate-500">
                        {item.sessions.length} sessions,{" "}
                        {formatDuration(getWorkedMs(item.sessions))}
                      </p>
                    </div>
                    <StatusBadge status={item.status} />
                  </div>
                  <SessionList sessions={item.sessions} />
                </div>
              ))
            )}
          </div>
        </section>
      </section>

      {canSeeTeam ? (
        <section className="overflow-hidden rounded-[34px] border border-white/75 bg-white/55 shadow-[0_24px_70px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
          <div className="border-b border-slate-200/70 px-5 py-4">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <h2 className="text-lg font-semibold tracking-[-0.02em] text-slate-950">
                  {user.role === "ADMIN"
                    ? "Company attendance"
                    : "Team attendance"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  {user.role === "ADMIN"
                    ? "Admins can correct status, sessions and notes."
                    : "Leads can review their team's daily attendance."}
                </p>
              </div>

              <form method="get" className="flex flex-wrap items-center gap-2">
                <input
                  type="date"
                  name="day"
                  defaultValue={selectedDay}
                  className="min-h-11 rounded-full border border-white/80 bg-white/75 px-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none focus:ring-4 focus:ring-emerald-300/20"
                />
                <button
                  type="submit"
                  className="inline-flex min-h-11 items-center justify-center rounded-full border border-white/80 bg-white/65 px-5 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition hover:bg-white hover:text-[#174f3e]"
                >
                  View day
                </button>
              </form>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              <MetricCard
                label="Marked"
                value={markedCount}
                hint={`${people.length} people visible for ${selectedDay}.`}
              />
              <MetricCard
                label="Working now"
                value={workingNowCount}
                hint="People with an open work session."
              />
              <MetricCard
                label="Absent or leave"
                value={absentCount}
                hint="People marked absent or on leave."
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[1040px] text-left text-sm">
              <thead className="bg-slate-50/80 text-xs uppercase tracking-[0.12em] text-slate-500">
                <tr className="border-b border-slate-200">
                  <th className="px-5 py-3 font-medium">Employee</th>
                  <th className="px-5 py-3 font-medium">Role</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium">Sessions</th>
                  <th className="px-5 py-3 font-medium">Total</th>
                  <th className="px-5 py-3 font-medium">Note</th>
                  {user.role === "ADMIN" ? (
                    <th className="px-5 py-3 font-medium">Action</th>
                  ) : null}
                </tr>
              </thead>

              <tbody>
                {people.length === 0 ? (
                  <tr>
                    <td
                      colSpan={user.role === "ADMIN" ? 7 : 6}
                      className="px-5 py-10 text-center text-sm text-slate-500"
                    >
                      No people found.
                    </td>
                  </tr>
                ) : (
                  people.map((person) => {
                    const attendance = person.attendances[0];
                    const formId = `attendance-${person.id}`;

                    return (
                      <tr
                        key={person.id}
                        className="border-b border-slate-200 align-middle last:border-b-0 hover:bg-white/70"
                      >
                        <td className="px-5 py-4">
                          <div className="font-medium text-slate-950">
                            {person.name}
                          </div>
                          <div className="mt-1 break-all text-xs text-slate-500">
                            {person.email}
                          </div>
                        </td>

                        <td className="px-5 py-4">
                          <span className="rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-600">
                            {person.role}
                          </span>
                        </td>

                        {user.role === "ADMIN" ? (
                          <AdminAttendanceForm
                            formId={formId}
                            person={person}
                            day={selectedDay}
                          />
                        ) : (
                          <>
                            <td className="px-5 py-4">
                              <StatusBadge status={attendance?.status} />
                            </td>
                            <td className="px-5 py-4 text-slate-600">
                              <SessionList sessions={attendance?.sessions ?? []} />
                            </td>
                            <td className="px-5 py-4 text-slate-700">
                              {formatDuration(
                                getWorkedMs(attendance?.sessions ?? []),
                              )}
                            </td>
                            <td className="px-5 py-4 text-slate-500">
                              {attendance?.note || "-"}
                            </td>
                          </>
                        )}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}

      {user.role === "ADMIN" ? (
        <section className="overflow-hidden rounded-[34px] border border-white/75 bg-white/55 shadow-[0_24px_70px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
          <div className="border-b border-slate-200/70 px-5 py-4">
            <h2 className="text-lg font-semibold tracking-[-0.02em] text-slate-950">
              All users history
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Complete attendance history across every employee.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[1120px] text-left text-sm">
              <thead className="bg-slate-50/80 text-xs uppercase tracking-[0.12em] text-slate-500">
                <tr className="border-b border-slate-200">
                  <th className="px-5 py-3 font-medium">Day</th>
                  <th className="px-5 py-3 font-medium">Employee</th>
                  <th className="px-5 py-3 font-medium">Role</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium">Sessions</th>
                  <th className="px-5 py-3 font-medium">Total</th>
                  <th className="px-5 py-3 font-medium">Note</th>
                </tr>
              </thead>

              <tbody>
                {adminAttendanceHistory.length === 0 ? (
                  <tr>
                    <td
                      colSpan={7}
                      className="px-5 py-10 text-center text-sm text-slate-500"
                    >
                      No attendance history found.
                    </td>
                  </tr>
                ) : (
                  adminAttendanceHistory.map((attendance) => (
                    <tr
                      key={attendance.id}
                      className="border-b border-slate-200 align-top last:border-b-0 hover:bg-white/70"
                    >
                      <td className="px-5 py-4 font-medium text-slate-950">
                        {attendance.day}
                      </td>
                      <td className="px-5 py-4">
                        <div className="font-medium text-slate-950">
                          {attendance.user.name}
                        </div>
                        <div className="mt-1 break-all text-xs text-slate-500">
                          {attendance.user.email}
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <span className="rounded-full border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-600">
                          {attendance.user.role}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <StatusBadge status={attendance.status} />
                      </td>
                      <td className="px-5 py-4 text-slate-600">
                        <SessionList sessions={attendance.sessions} />
                      </td>
                      <td className="px-5 py-4 text-slate-700">
                        {formatDuration(getWorkedMs(attendance.sessions))}
                      </td>
                      <td className="px-5 py-4 text-slate-500">
                        {attendance.note || "-"}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}
    </div>
  );
}
