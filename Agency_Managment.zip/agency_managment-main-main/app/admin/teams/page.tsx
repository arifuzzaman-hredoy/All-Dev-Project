import { Role } from "@prisma/client";
import { redirect } from "next/navigation";
import {
  adminBulkAssignUsersToTeam,
  adminCreateTeam,
  adminUpdateTeam,
} from "../../actions/admin";
import { TeamMemberAdder } from "../../components/team-member-adder";
import { getSessionUser } from "../../lib/auth";
import { prisma } from "../../lib/db";
import { cn, noticeClasses, ui } from "../../lib/ui";

export default async function AdminTeamsPage({
  searchParams,
}: {
  searchParams: Promise<{ created?: string; updated?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");

  const { created, updated, error } = await searchParams;

  const [teams, leads, members] = await Promise.all([
    prisma.team.findMany({
      orderBy: { name: "asc" },
      select: {
        id: true,
        name: true,
        leadId: true,
        lead: { select: { id: true, name: true, email: true } },
        _count: { select: { members: true } },
      },
      take: 200,
    }),
    prisma.user.findMany({
      where: { role: { in: [Role.LEAD, Role.ADMIN, Role.EMPLOYEE] } },
      orderBy: { name: "asc" },
      select: { id: true, name: true, email: true, role: true },
      take: 500,
    }),
    prisma.user.findMany({
      where: { role: { in: [Role.LEAD, Role.EMPLOYEE] } },
      orderBy: { name: "asc" },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        team: { select: { id: true, name: true } },
      },
      take: 800,
    }),
  ]);

  return (
    <div className="space-y-6">
      <section className={ui.heroCard}>
        <span className={ui.eyebrow}>Team structure</span>
        <h1 className={ui.pageTitle}>Manage teams</h1>
        <p className={ui.pageCopy}>Create teams and assign leads.</p>
      </section>

      {created ? <Notice>Created.</Notice> : null}
      {updated ? <Notice>Updated.</Notice> : null}
      {error ? (
        <div className={noticeClasses("error")}>
          Error:{" "}
          {error === "missing_team"
            ? "Please select a team."
            : error === "missing_members"
              ? "Please select at least one member."
              : error}
        </div>
      ) : null}

      <form action={adminCreateTeam} className={`${ui.panel} p-5 md:p-6`}>
        <div className={ui.sectionTitle}>Create team</div>
        <div className="mt-3 grid gap-4 md:grid-cols-2">
          <label className={ui.fieldLabel}>
            Team name
            <input name="name" className={ui.input} required />
          </label>
          <label className={ui.fieldLabel}>
            Lead (optional)
            <select name="leadId" className={ui.select}>
              <option value="" />
              {leads.map((lead) => (
                <option key={lead.id} value={lead.id}>
                  {lead.name} ({lead.email}) — {lead.role}
                </option>
              ))}
            </select>
          </label>
        </div>
        <button className={`${ui.actionPrimary} mt-6`}>Create team</button>
      </form>

      <form action={adminBulkAssignUsersToTeam} className={`${ui.panel} p-5 md:p-6`}>
        <div className={ui.sectionTitle}>Add multiple members</div>
        <p className={`${ui.sectionCopy} mt-2`}>
          Select a team, then add members one by one using the dropdown.
        </p>
        <TeamMemberAdder teams={teams} members={members} />
      </form>

      <div className="space-y-3 md:hidden">
        {teams.map((team) => (
          <div key={team.id} className={`${ui.panel} p-4`}>
            <div className="font-medium">{team.name}</div>
            <div className="mt-1 text-xs text-stone-500">Members: {team._count.members}</div>
            <div className="mt-3 text-sm">
              {team.lead ? (
                <>
                  <div className="font-medium">{team.lead.name}</div>
                  <div className="text-xs text-stone-500">{team.lead.email}</div>
                </>
              ) : (
                <span className="text-stone-500">No lead assigned</span>
              )}
            </div>

            <form action={adminUpdateTeam} className="mt-4 grid gap-2">
              <input type="hidden" name="id" value={team.id} />
              <select
                name="leadId"
                defaultValue={team.leadId ?? ""}
                className={cn(ui.select, "mt-0 px-3 py-2 text-xs")}
              >
                <option value="">(no lead)</option>
                {leads.map((lead) => (
                  <option key={lead.id} value={lead.id}>
                    {lead.name} ({lead.email})
                  </option>
                ))}
              </select>
              <button className={cn(ui.actionSecondary, "px-3 py-2 text-xs")}>Save</button>
            </form>
          </div>
        ))}
      </div>

      <div className="hidden md:block">
        <div className={`${ui.listCard} overflow-x-auto`}>
          <table className="w-full text-sm">
            <thead className="bg-white/60 text-left">
              <tr className={`${ui.softDivider} border-b`}>
                <th className="px-4 py-2 font-medium">Team</th>
                <th className="px-4 py-2 font-medium">Lead</th>
                <th className="px-4 py-2 font-medium">Members</th>
                <th className="px-4 py-2 font-medium">Update</th>
              </tr>
            </thead>
            <tbody>
              {teams.map((team) => (
                <tr key={team.id} className={`${ui.softDivider} border-b last:border-b-0 align-top`}>
                  <td className="px-4 py-3 font-medium">{team.name}</td>
                  <td className="px-4 py-3">
                    {team.lead ? (
                      <>
                        <div className="font-medium">{team.lead.name}</div>
                        <div className="text-xs text-stone-500">{team.lead.email}</div>
                      </>
                    ) : (
                      <span className="text-stone-500">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3">{team._count.members}</td>
                  <td className="px-4 py-3">
                    <form action={adminUpdateTeam} className="flex items-center gap-2">
                      <input type="hidden" name="id" value={team.id} />
                      <select
                        name="leadId"
                        defaultValue={team.leadId ?? ""}
                        className={cn(ui.select, "mt-0 px-3 py-2 text-xs")}
                      >
                        <option value="">(no lead)</option>
                        {leads.map((lead) => (
                          <option key={lead.id} value={lead.id}>
                            {lead.name} ({lead.email})
                          </option>
                        ))}
                      </select>
                      <button className={cn(ui.actionSecondary, "px-3 py-2 text-xs")}>
                        Save
                      </button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Notice({ children }: { children: React.ReactNode }) {
  return <div className={noticeClasses("success")}>{children}</div>;
}
