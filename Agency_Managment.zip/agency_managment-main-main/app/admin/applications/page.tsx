import { ApplicationStatus } from "@prisma/client";
import Link from "next/link";
import { redirect } from "next/navigation";
import { adminUpdateApplicationStatus } from "../../actions/applications-admin";
import { getSessionUser } from "../../lib/auth";
import { prisma } from "../../lib/db";
import { cn, noticeClasses, ui } from "../../lib/ui";

export default async function AdminApplicationsPage({
  searchParams,
}: {
  searchParams: Promise<{ updated?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");

  const { updated, error } = await searchParams;

  const applications = await prisma.application.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      email: true,
      message: true,
      status: true,
      createdAt: true,
    },
    take: 500,
  });

  return (
    <div className="space-y-6">
      <section className={ui.heroCard}>
        <span className={ui.eyebrow}>Requests</span>
        <h1 className={ui.pageTitle}>Applications</h1>
        <p className={ui.pageCopy}>
          Review account requests submitted from <code>/apply</code>.
        </p>
      </section>

      {updated ? <Notice>Updated.</Notice> : null}
      {error ? <div className={noticeClasses("error")}>Error: {error}</div> : null}

      {applications.length === 0 ? (
        <div className={noticeClasses()}>No applications yet.</div>
      ) : (
        <>
          <div className="space-y-3 md:hidden">
            {applications.map((application) => (
              <div key={application.id} className={`${ui.panel} p-4`}>
                <div className="font-medium">{application.name}</div>
                <div className="mt-1 text-xs text-stone-500">{application.email}</div>
                <div className="mt-2 text-xs text-stone-500">
                  {application.createdAt.toLocaleString()}
                </div>
                {application.message ? (
                  <div className="mt-3 whitespace-pre-wrap text-sm">{application.message}</div>
                ) : null}
                <form action={adminUpdateApplicationStatus} className="mt-4 grid gap-2">
                  <input type="hidden" name="id" value={application.id} />
                  <select
                    name="status"
                    defaultValue={application.status}
                    className={cn(ui.select, "mt-0 w-full px-3 py-2 text-xs")}
                  >
                    {Object.values(ApplicationStatus).map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                  <button className={cn(ui.actionSecondary, "px-3 py-2 text-xs")}>Save</button>
                </form>
              </div>
            ))}
          </div>

          <div className="hidden md:block">
            <div className={`${ui.listCard} overflow-x-auto`}>
              <table className="w-full text-sm">
                <thead className="bg-white/60 text-left">
                  <tr className={`${ui.softDivider} border-b`}>
                    <th className="px-4 py-2 font-medium">Applicant</th>
                    <th className="px-4 py-2 font-medium">Details</th>
                    <th className="px-4 py-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {applications.map((application) => (
                    <tr
                      key={application.id}
                      className={`${ui.softDivider} border-b last:border-b-0 align-top`}
                    >
                      <td className="px-4 py-3">
                        <div className="font-medium">{application.name}</div>
                        <div className="text-xs text-stone-500">{application.email}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="text-xs text-stone-500">
                          {application.createdAt.toLocaleString()}
                        </div>
                        {application.message ? (
                          <div className="mt-2 whitespace-pre-wrap text-sm">
                            {application.message}
                          </div>
                        ) : (
                          <div className="mt-2 text-sm text-stone-500">(no notes)</div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <form action={adminUpdateApplicationStatus} className="grid gap-2">
                          <input type="hidden" name="id" value={application.id} />
                          <select
                            name="status"
                            defaultValue={application.status}
                            className={cn(ui.select, "mt-0 w-full px-3 py-2 text-xs")}
                          >
                            {Object.values(ApplicationStatus).map((status) => (
                              <option key={status} value={status}>
                                {status}
                              </option>
                            ))}
                          </select>
                          <button className={cn(ui.actionSecondary, "px-3 py-2 text-xs")}>
                            Save
                          </button>
                        </form>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      <Link href="/admin" className={ui.linkAccent}>
        Back to admin
      </Link>
    </div>
  );
}

function Notice({ children }: { children: React.ReactNode }) {
  return <div className={noticeClasses("success")}>{children}</div>;
}
