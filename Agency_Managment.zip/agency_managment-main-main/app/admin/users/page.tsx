import type { ReactNode } from "react";
import { Role } from "@prisma/client";
import { redirect } from "next/navigation";
import {
  adminCreateUser,
  adminResetPassword,
  adminUpdateUser,
} from "../../actions/admin";
import { getSessionUser } from "../../lib/auth";
import { prisma } from "../../lib/db";

const inputClass =
  "w-full rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 text-sm text-slate-800 shadow-sm outline-none transition placeholder:text-slate-400 focus:border-emerald-500/40 focus:bg-white focus:ring-4 focus:ring-emerald-500/10";

const compactInputClass =
  "w-full rounded-xl border border-slate-200/70 bg-white/85 px-3 py-2 text-xs text-slate-800 shadow-sm outline-none transition placeholder:text-slate-400 focus:border-emerald-500/40 focus:bg-white focus:ring-4 focus:ring-emerald-500/10";

const selectClass =
  "w-full rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 text-sm text-slate-800 shadow-sm outline-none transition focus:border-emerald-500/40 focus:bg-white focus:ring-4 focus:ring-emerald-500/10";

const compactSelectClass =
  "w-full rounded-xl border border-slate-200/70 bg-white/85 px-3 py-2 text-xs text-slate-800 shadow-sm outline-none transition focus:border-emerald-500/40 focus:bg-white focus:ring-4 focus:ring-emerald-500/10";

function Notice({
  type,
  children,
}: {
  type: "success" | "error";
  children: ReactNode;
}) {
  const styles = {
    success: "border-emerald-200 bg-emerald-50 text-emerald-700",
    error: "border-red-200 bg-red-50 text-red-700",
  };

  return (
    <div
      className={`rounded-2xl border px-4 py-3 text-sm font-medium shadow-sm ${styles[type]}`}
    >
      {children}
    </div>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-2 block text-sm font-medium text-slate-700">
        {label}
      </span>
      {children}
    </label>
  );
}

function StatCard({
  label,
  value,
  helper,
}: {
  label: string;
  value: number;
  helper: string;
}) {
  return (
    <div className="rounded-3xl border border-white/70 bg-white/70 p-5 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <p className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-slate-950">
        {value}
      </p>
      <p className="mt-2 text-xs leading-5 text-slate-500">{helper}</p>
    </div>
  );
}

function RoleBadge({ role }: { role: Role }) {
  const styles: Record<Role, string> = {
    EMPLOYEE: "border-slate-200 bg-slate-50 text-slate-700",
    LEAD: "border-sky-200 bg-sky-50 text-sky-700",
    ADMIN: "border-emerald-200 bg-emerald-50 text-emerald-700",
  };

  return (
    <span
      className={`inline-flex rounded-full border px-2.5 py-1 text-[11px] font-medium ${styles[role]}`}
    >
      {role}
    </span>
  );
}

function ChatBadge({ blocked }: { blocked: boolean }) {
  return (
    <span
      className={`inline-flex rounded-full border px-2.5 py-1 text-[11px] font-medium ${
        blocked
          ? "border-red-200 bg-red-50 text-red-700"
          : "border-emerald-200 bg-emerald-50 text-emerald-700"
      }`}
    >
      {blocked ? "Chat blocked" : "Chat allowed"}
    </span>
  );
}

function SaveButton({ children = "Save" }: { children?: ReactNode }) {
  return (
    <button
      type="submit"
      className="inline-flex min-h-10 items-center justify-center rounded-xl border border-slate-200 bg-white px-4 text-xs font-medium text-slate-700 shadow-sm transition hover:border-emerald-300 hover:text-emerald-700 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
    >
      {children}
    </button>
  );
}

function PrimaryButton({ children }: { children: ReactNode }) {
  return (
    <button
      type="submit"
      className="inline-flex min-h-11 items-center justify-center rounded-2xl bg-[#174f3e] px-6 text-sm font-semibold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-[#1f6b51] focus:outline-none focus:ring-4 focus:ring-emerald-500/20"
    >
      {children}
    </button>
  );
}

function UserSettingsForm({
  userId,
  role,
  teamId,
  chatBlocked,
  teams,
}: {
  userId: string;
  role: Role;
  teamId: string | null;
  chatBlocked: boolean;
  teams: Array<{ id: string; name: string }>;
}) {
  return (
    <form action={adminUpdateUser} className="grid gap-2">
      <input type="hidden" name="id" value={userId} />

      <select name="role" defaultValue={role} className={compactSelectClass}>
        <option value={Role.EMPLOYEE}>Employee</option>
        <option value={Role.LEAD}>Lead</option>
        <option value={Role.ADMIN}>Admin</option>
      </select>

      <select
        name="teamId"
        defaultValue={teamId ?? ""}
        className={compactSelectClass}
      >
        <option value="">No team</option>
        {teams.map((team) => (
          <option key={team.id} value={team.id}>
            {team.name}
          </option>
        ))}
      </select>

      <select
        name="chatBlocked"
        defaultValue={chatBlocked ? "true" : "false"}
        className={compactSelectClass}
      >
        <option value="false">Chat allowed</option>
        <option value="true">Chat blocked</option>
      </select>

      <SaveButton />
    </form>
  );
}

function ResetPasswordForm({ userId }: { userId: string }) {
  return (
    <form action={adminResetPassword} className="grid gap-2">
      <input type="hidden" name="id" value={userId} />

      <input
        name="password"
        type="password"
        placeholder="New password"
        className={compactInputClass}
        required
      />

      <SaveButton>Reset password</SaveButton>
    </form>
  );
}

export default async function AdminUsersPage({
  searchParams,
}: {
  searchParams: Promise<{
    created?: string;
    updated?: string;
    pw?: string;
    error?: string;
  }>;
}) {
  const currentUser = await getSessionUser();
  if (!currentUser) redirect("/login");
  if (currentUser.role !== "ADMIN") redirect("/dashboard");

  const { created, updated, pw, error } = await searchParams;

  const [users, teams] = await Promise.all([
    prisma.user.findMany({
      orderBy: { name: "asc" },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        teamId: true,
        chatBlocked: true,
      },
      take: 500,
    }),

    prisma.team.findMany({
      orderBy: { name: "asc" },
      select: { id: true, name: true },
      take: 200,
    }),
  ]);

  const teamNameById = new Map(teams.map((team) => [team.id, team.name]));
  const adminCount = users.filter((entry) => entry.role === Role.ADMIN).length;
  const leadCount = users.filter((entry) => entry.role === Role.LEAD).length;
  const blockedChatCount = users.filter((entry) => entry.chatBlocked).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="rounded-[32px] border border-white/70 bg-white/70 p-5 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl md:p-7">
        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div>
            <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.12em] text-emerald-700">
              Access control
            </span>

            <h1 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 md:text-5xl">
              Manage users
            </h1>

            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-600 md:text-base">
              Create accounts, assign roles, connect users with teams, control
              chat access, and reset passwords from one place.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200/70 bg-white/75 px-4 py-3 text-sm text-slate-600 shadow-sm">
            <span className="font-medium text-slate-900">{users.length}</span>{" "}
            users ·{" "}
            <span className="font-medium text-slate-900">{teams.length}</span>{" "}
            teams
          </div>
        </div>
      </section>

      {/* Notices */}
      <div className="space-y-3">
        {created ? <Notice type="success">User created successfully.</Notice> : null}
        {updated ? <Notice type="success">User updated successfully.</Notice> : null}
        {pw ? <Notice type="success">Password reset successfully.</Notice> : null}
        {error ? <Notice type="error">Error: {error}</Notice> : null}
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="Total users" value={users.length} helper="All accounts in the system." />
        <StatCard label="Admins" value={adminCount} helper="Users with full access." />
        <StatCard label="Leads" value={leadCount} helper="Team lead accounts." />
        <StatCard label="Chat blocked" value={blockedChatCount} helper="Users without chat access." />
      </div>

      {/* Create User */}
      <form
        action={adminCreateUser}
        className="rounded-[32px] border border-white/70 bg-white/70 p-5 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl md:p-6"
      >
        <div className="mb-5">
          <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
            Create user
          </h2>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Add a new account and assign the correct role and team before
            sharing the temporary password.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Name">
            <input
              name="name"
              className={inputClass}
              placeholder="Employee name"
              required
            />
          </Field>

          <Field label="Email">
            <input
              name="email"
              type="email"
              className={inputClass}
              placeholder="name@company.com"
              required
            />
          </Field>

          <Field label="Role">
            <select name="role" className={selectClass} defaultValue={Role.EMPLOYEE}>
              <option value={Role.EMPLOYEE}>Employee</option>
              <option value={Role.LEAD}>Lead</option>
              <option value={Role.ADMIN}>Admin</option>
            </select>
          </Field>

          <Field label="Team">
            <select name="teamId" className={selectClass} defaultValue="">
              <option value="">No team</option>
              {teams.map((team) => (
                <option key={team.id} value={team.id}>
                  {team.name}
                </option>
              ))}
            </select>
          </Field>

          <Field label="Temporary password" className="md:col-span-2">
            <input
              name="password"
              type="password"
              className={inputClass}
              placeholder="Set a temporary password"
              required
            />
          </Field>
        </div>

        <div className="mt-6 flex flex-col gap-3 border-t border-slate-200 pt-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs leading-5 text-slate-500">
            After creating the account, the user can sign in with the temporary
            password.
          </p>

          <PrimaryButton>Create user</PrimaryButton>
        </div>
      </form>

      {/* Mobile User Cards */}
      <div className="grid gap-4 md:hidden">
        {users.length === 0 ? (
          <div className="rounded-[28px] border border-white/70 bg-white/70 p-6 text-center text-sm text-slate-500 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
            No users found.
          </div>
        ) : (
          users.map((entry) => (
            <article
              key={entry.id}
              className="rounded-[28px] border border-white/70 bg-white/70 p-4 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl"
            >
              <div>
                <h3 className="text-base font-semibold tracking-[-0.02em] text-slate-950">
                  {entry.name}
                </h3>
                <p className="mt-1 break-all text-xs text-slate-500">
                  {entry.email}
                </p>
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                <RoleBadge role={entry.role} />
                <ChatBadge blocked={entry.chatBlocked} />
                <span className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600">
                  {entry.teamId ? teamNameById.get(entry.teamId) ?? "Unknown team" : "No team"}
                </span>
              </div>

              <div className="mt-5 grid gap-4">
                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-slate-400">
                    Role, team & chat
                  </p>
                  <UserSettingsForm
                    userId={entry.id}
                    role={entry.role}
                    teamId={entry.teamId}
                    chatBlocked={entry.chatBlocked}
                    teams={teams}
                  />
                </div>

                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-slate-400">
                    Password
                  </p>
                  <ResetPasswordForm userId={entry.id} />
                </div>
              </div>
            </article>
          ))
        )}
      </div>

      {/* Desktop Table */}
      <section className="hidden overflow-hidden rounded-[32px] border border-white/70 bg-white/70 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl md:block">
        <div className="border-b border-slate-200 px-5 py-4">
          <h2 className="text-lg font-semibold tracking-[-0.02em] text-slate-950">
            User list
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Update role, team, chat access or reset password for any user.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-left text-sm">
            <thead className="bg-slate-50/80 text-xs uppercase tracking-[0.12em] text-slate-500">
              <tr className="border-b border-slate-200">
                <th className="px-5 py-3 font-medium">User</th>
                <th className="px-5 py-3 font-medium">Current access</th>
                <th className="px-5 py-3 font-medium">Update access</th>
                <th className="px-5 py-3 font-medium">Reset password</th>
              </tr>
            </thead>

            <tbody>
              {users.length === 0 ? (
                <tr>
                  <td
                    colSpan={4}
                    className="px-5 py-10 text-center text-sm text-slate-500"
                  >
                    No users found.
                  </td>
                </tr>
              ) : (
                users.map((entry) => (
                  <tr
                    key={entry.id}
                    className="border-b border-slate-200 align-top last:border-b-0 hover:bg-white/70"
                  >
                    <td className="px-5 py-4">
                      <div className="font-medium text-slate-950">
                        {entry.name}
                      </div>
                      <div className="mt-1 break-all text-xs text-slate-500">
                        {entry.email}
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex flex-wrap gap-2">
                        <RoleBadge role={entry.role} />
                        <ChatBadge blocked={entry.chatBlocked} />
                        <span className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600">
                          {entry.teamId
                            ? teamNameById.get(entry.teamId) ?? "Unknown team"
                            : "No team"}
                        </span>
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <UserSettingsForm
                        userId={entry.id}
                        role={entry.role}
                        teamId={entry.teamId}
                        chatBlocked={entry.chatBlocked}
                        teams={teams}
                      />
                    </td>

                    <td className="px-5 py-4">
                      <ResetPasswordForm userId={entry.id} />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}