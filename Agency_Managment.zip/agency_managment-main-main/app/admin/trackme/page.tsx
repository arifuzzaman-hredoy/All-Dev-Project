import Image from "next/image";
import { redirect } from "next/navigation";
import { getSessionUser } from "../../lib/auth";
import { listTrackmeScreenshots } from "../../lib/trackme";
import { TrackmeAutoRefresh } from "./auto-refresh";

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat("en", {
    dateStyle: "medium",
    timeStyle: "medium",
  }).format(new Date(value));
}

function formatFileSize(size: number) {
  if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export default async function AdminTrackmePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");

  const screenshots = await listTrackmeScreenshots();

  return (
    <div className="space-y-6">
      <TrackmeAutoRefresh />

      <section className="rounded-[32px] border border-white/70 bg-white/70 p-5 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl md:p-7">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.12em] text-emerald-700">
              TrackMe monitor
            </span>

            <h1 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 md:text-5xl">
              Employee screenshot preview
            </h1>

            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-600 md:text-base">
              Prottek employee er only latest high-quality screenshot ekhane
              dekhano hocche. New screenshot ashle previous image replace hoye
              jabe.
            </p>
          </div>

          <div className="rounded-3xl border border-white/75 bg-white/75 px-5 py-4 text-center shadow-sm ring-1 ring-slate-900/5">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
              Employees
            </p>
            <p className="mt-1 text-4xl font-semibold tracking-[-0.05em] text-[#174f3e]">
              {screenshots.length}
            </p>
          </div>
        </div>
      </section>

      {screenshots.length ? (
        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {screenshots.map((screenshot) => (
            <article
              key={screenshot.fileName}
              className="overflow-hidden rounded-[8px] border border-white/75 bg-white/68 shadow-[0_18px_54px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl"
            >
              <div className="relative aspect-video bg-slate-950">
                <Image
                  src={`/api/trackme/image/${encodeURIComponent(
                    screenshot.fileName
                  )}?v=${encodeURIComponent(screenshot.capturedAt)}`}
                  alt={`${screenshot.userName} screenshot ${screenshot.count}`}
                  fill
                  sizes="(min-width: 1280px) 33vw, (min-width: 768px) 50vw, 100vw"
                  className="object-contain"
                  unoptimized
                />
              </div>

              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="truncate text-base font-black text-slate-950">
                      {screenshot.userName}
                    </h2>
                    <p className="mt-1 truncate text-xs font-semibold text-slate-500">
                      {screenshot.userEmail}
                    </p>
                  </div>

                  <span className="shrink-0 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-2.5 py-1 text-xs font-black text-[#174f3e]">
                    Latest
                  </span>
                </div>

                <div className="mt-3 grid gap-1 text-xs font-semibold text-slate-500">
                  <span>Captured: {formatDateTime(screenshot.capturedAt)}</span>
                  <span>Size: {formatFileSize(screenshot.size)}</span>
                </div>
              </div>
            </article>
          ))}
        </section>
      ) : (
        <section className="rounded-[32px] border border-white/75 bg-white/68 p-8 text-center shadow-sm ring-1 ring-slate-900/5 backdrop-blur-2xl">
          <h2 className="text-2xl font-semibold tracking-[-0.03em] text-slate-950">
            No screenshots uploaded yet
          </h2>
          <p className="mt-3 text-sm font-semibold text-slate-500">
            User ra /trackme route theke capture start korle employee-wise latest
            preview show korbe.
          </p>
        </section>
      )}
    </div>
  );
}
