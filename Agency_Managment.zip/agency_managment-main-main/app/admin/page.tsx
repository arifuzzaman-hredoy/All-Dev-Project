import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";
import { todayDayString } from "../lib/dates";

function MetricCard({
  label,
  value,
  tone = "emerald",
}: {
  label: string;
  value: number;
  tone?: "emerald" | "sky" | "amber" | "violet" | "slate";
}) {
  const toneStyles = {
    emerald: {
      text: "text-emerald-700",
      glow: "bg-emerald-400/20",
      badge: "border-emerald-500/15 bg-emerald-500/10 text-emerald-700",
    },
    sky: {
      text: "text-sky-700",
      glow: "bg-sky-400/20",
      badge: "border-sky-500/15 bg-sky-500/10 text-sky-700",
    },
    amber: {
      text: "text-amber-700",
      glow: "bg-amber-400/20",
      badge: "border-amber-500/15 bg-amber-500/10 text-amber-700",
    },
    violet: {
      text: "text-violet-700",
      glow: "bg-violet-400/20",
      badge: "border-violet-500/15 bg-violet-500/10 text-violet-700",
    },
    slate: {
      text: "text-slate-700",
      glow: "bg-slate-400/16",
      badge: "border-slate-500/15 bg-slate-500/10 text-slate-600",
    },
  };

  return (
    <div className="group relative overflow-hidden rounded-[30px] border border-white/75 bg-white/58 p-5 shadow-[0_22px_65px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-1 hover:bg-white/72 hover:shadow-[0_32px_90px_rgba(15,23,42,0.12)] md:p-6">
      <div
        className={`pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full blur-3xl ${toneStyles[tone].glow}`}
      />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.12))]" />

      <div className="relative z-10">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm font-medium text-slate-500">{label}</p>

          <span
            className={`rounded-full border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] ${toneStyles[tone].badge}`}
          >
            Live
          </span>
        </div>

        <div
          className={`mt-4 text-4xl font-semibold tracking-[-0.055em] md:text-5xl ${toneStyles[tone].text}`}
        >
          {value}
        </div>
      </div>
    </div>
  );
}

function AdminTool({
  href,
  title,
  description,
  tone = "emerald",
}: {
  href: string;
  title: string;
  description: string;
  tone?: "emerald" | "sky" | "amber" | "violet";
}) {
  const toneStyles = {
    emerald: "from-emerald-500/14 to-[#174f3e]/8 text-[#174f3e]",
    sky: "from-sky-500/14 to-blue-500/8 text-sky-700",
    amber: "from-amber-500/16 to-orange-500/8 text-amber-700",
    violet: "from-violet-500/14 to-fuchsia-500/8 text-violet-700",
  };

  return (
    <Link
      href={href}
      className="group relative overflow-hidden rounded-[28px] border border-white/75 bg-white/54 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/72 hover:shadow-[0_24px_70px_rgba(15,23,42,0.10)]"
    >
      <div
        className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${toneStyles[tone]}`}
      />

      <div className="relative z-10 flex items-start justify-between gap-4">
        <div>
          <h3 className="text-base font-semibold tracking-[-0.02em] text-slate-950">
            {title}
          </h3>
          <p className="mt-2 text-sm text-slate-600">{description}</p>
        </div>

        <span
          className={`grid h-10 w-10 shrink-0 place-items-center rounded-full border border-white/80 bg-white/65 shadow-sm ring-1 ring-slate-900/5 transition group-hover:scale-105 ${toneStyles[tone].split(" ").at(-1)}`}
          aria-hidden="true"
        >
          →
        </span>
      </div>
    </Link>
  );
}

function StatusPill({
  children,
  tone = "emerald",
}: {
  children: ReactNode;
  tone?: "emerald" | "sky" | "amber" | "slate";
}) {
  const styles = {
    emerald: "border-emerald-500/15 bg-emerald-500/10 text-emerald-700",
    sky: "border-sky-500/15 bg-sky-500/10 text-sky-700",
    amber: "border-amber-500/15 bg-amber-500/10 text-amber-700",
    slate: "border-slate-900/5 bg-white/60 text-slate-600",
  };

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl ${styles[tone]}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current shadow-[0_0_12px_currentColor]" />
      {children}
    </span>
  );
}

export default async function AdminPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");

  const day = todayDayString();

  const [
    users,
    teams,
    submissions,
    learningSubmissions,
    attendanceCount,
    applications,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.team.count(),
    prisma.dailyUpdate.count({ where: { day } }),
    prisma.learningStatus.count({ where: { day } }),
    prisma.attendance.count({ where: { day, checkInAt: { not: null } } }),
    prisma.application.count(),
  ]);

  const totalTodayActivity = submissions + learningSubmissions;

  return (
    <div className="relative space-y-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.23),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.16))]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-52 w-52 rounded-full bg-sky-300/20 blur-3xl" />

        <div className="relative z-10 grid gap-6 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#174f3e] shadow-sm">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.85)]" />
              Operations view
            </span>

            <h1 className="mt-5 text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
              Admin dashboard
            </h1>

            <div className="mt-5 flex flex-wrap items-center gap-2">
              <StatusPill tone="emerald">Today: {day}</StatusPill>
              <StatusPill tone="sky">Admin access</StatusPill>
              <StatusPill tone="slate">System overview</StatusPill>
            </div>
          </div>

          <div className="flex min-h-[180px] flex-col items-center justify-center rounded-[28px] border border-white/75 bg-white/50 p-4 text-center shadow-[0_20px_60px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-slate-400">
              Today update
            </p>

            <div className=" text-5xl font-semibold tracking-[-0.055em] text-[#174f3e]">
              {totalTodayActivity}
            </div>

            <div className="mt- grid w-full grid-cols-2 gap-3">
              <div className="flex min-h-[92px] flex-col items-center justify-center rounded-3xl border border-white/70 bg-white/55 p-3">
                <p className="text-2xl font-semibold text-slate-950">
                  {submissions}
                </p>
                <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.12em] text-slate-400">
                  Updates
                </p>
              </div>

              <div className="flex min-h-[92px] flex-col items-center justify-center rounded-3xl border border-white/70 bg-white/55 p-3">
                <p className="text-2xl font-semibold text-slate-950">
                  {learningSubmissions}
                </p>
                <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.12em] text-slate-400">
                  Learning
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Metrics */}
      <div className="grid gap-4 grid-cols-2 xl:grid-cols-6">
        <MetricCard label="Users" value={users} tone="emerald" />

        <MetricCard label="Teams" value={teams} tone="sky" />

        <MetricCard label="Attendance" value={attendanceCount} tone="emerald" />

        <MetricCard label="Daily updates" value={submissions} tone="amber" />

        <MetricCard
          label="Learning statuses"
          value={learningSubmissions}
          tone="violet"
        />

        <MetricCard label="Applications" value={applications} tone="slate" />
      </div>

      {/* Admin Tools */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(16,185,129,0.14),transparent_30%),radial-gradient(circle_at_95%_8%,rgba(59,130,246,0.10),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10">
          <div className="grid gap-4 grid-cols-2">
            <AdminTool
              href="/admin/users"
              title="Manage users"
              description="Review employees, admins, leads, roles and account access."
              tone="emerald"
            />

            <AdminTool
              href="/admin/teams"
              title="Manage teams"
              description="Create team structures and connect members with team leads."
              tone="sky"
            />

            <AdminTool
              href="/attendance"
              title="Attendance"
              description="Review attendance and correct employee status, check-in or check-out times."
              tone="emerald"
            />

            <AdminTool
              href="/admin/trackme"
              title="TrackMe screenshots"
              description="View uploaded employee screenshots in serial order."
              tone="sky"
            />

            <AdminTool
              href="/admin/applications"
              title="Applications"
              description="Check submitted applications and review incoming requests."
              tone="amber"
            />

            <AdminTool
              href="/reports"
              title="Reports"
              description="Open reporting dashboard for submissions and task progress."
              tone="violet"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
