"use client";

import { useMemo } from "react";
import { cn } from "../lib/ui";
import { useNow } from "./now-store";

function parseDueDayLocalEnd(dueDay: string) {
  const trimmed = dueDay.trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
  if (!match) return null;

  const year = Number(match[1]);
  const monthIndex = Number(match[2]) - 1;
  const day = Number(match[3]);
  const date = new Date(year, monthIndex, day, 23, 59, 59, 999);
  if (Number.isNaN(date.getTime())) return null;
  return date;
}

function formatDiff(ms: number) {
  const absSeconds = Math.floor(Math.abs(ms) / 1000);
  const days = Math.floor(absSeconds / 86400);
  const hours = Math.floor((absSeconds % 86400) / 3600);
  const minutes = Math.floor((absSeconds % 3600) / 60);

  if (days > 0) return `${days}d ${hours}h ${minutes}m`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

export function DueCountdownPill({
  dueDay,
  className,
  label = "Countdown",
}: {
  dueDay: string;
  className?: string;
  label?: string;
}) {
  const nowMs = useNow();

  const target = useMemo(() => parseDueDayLocalEnd(dueDay), [dueDay]);
  const diffMs = target ? target.getTime() - nowMs : null;

  if (!target) return null;

  const isOverdue = diffMs !== null && diffMs < 0;
  const isSoon =
    diffMs !== null && diffMs >= 0 && diffMs <= 24 * 60 * 60 * 1000;

  const tone = isOverdue ? "red" : isSoon ? "amber" : "slate";

  const toneClassName =
    tone === "red"
      ? "border-red-500/20 bg-red-500/10 text-red-700"
      : tone === "amber"
        ? "border-amber-500/20 bg-amber-500/10 text-amber-700"
        : "border-white/75 bg-white/60 text-slate-600";

  const text =
    diffMs === null
      ? "—"
      : isOverdue
        ? `Overdue ${formatDiff(diffMs)}`
        : formatDiff(diffMs);

  return (
    <span
      className={cn(
        "rounded-full border px-3 py-1.5 text-xs font-medium backdrop-blur-xl",
        toneClassName,
        className,
      )}
      title={`Due day: ${dueDay} (counts down to end of day)`}
    >
      {label}: <span suppressHydrationWarning>{text}</span>
    </span>
  );
}
