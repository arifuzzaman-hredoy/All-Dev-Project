"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { NavLink } from "./nav-link";

type NavItem = {
  href: string;
  label: string;
};

type MobileNavMenuProps = {
  userRole?: string;
  navItems: NavItem[];
  logoutAction: (formData: FormData) => void | Promise<void>;
};

export function MobileNavMenu({
  userRole,
  navItems,
  logoutAction,
}: MobileNavMenuProps) {
  const pathname = usePathname();

  // Remount on route change so `open` reliably resets without needing an effect.
  return (
    <MobileNavMenuInner
      key={pathname}
      userRole={userRole}
      navItems={navItems}
      logoutAction={logoutAction}
    />
  );
}

function MobileNavMenuInner({
  userRole,
  navItems,
  logoutAction,
}: MobileNavMenuProps) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;

    function handleOutsideClick(event: PointerEvent) {
      if (!menuRef.current) return;
      const target = event.target as Node | null;
      if (target && !menuRef.current.contains(target)) {
        setOpen(false);
      }
    }

    function handleEscape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
      }
    }

    document.addEventListener("pointerdown", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("pointerdown", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [open]);

  return (
    <div ref={menuRef} className="relative lg:hidden">
      <button
        type="button"
        aria-label={open ? "Close menu" : "Open menu"}
        aria-expanded={open}
        aria-controls="mobile-nav-menu"
        onClick={() => setOpen((value) => !value)}
        className="grid h-11 w-11 place-items-center rounded-full border border-white/80 bg-white/80 shadow-[0_14px_30px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 transition hover:-translate-y-0.5 hover:bg-white focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25"
      >
        <span className="relative block h-4 w-5">
          <span
            className={`absolute left-0 h-0.5 w-5 rounded-full bg-slate-950 transition ${
              open ? "top-[7px] rotate-45" : "top-0"
            }`}
          />
          <span
            className={`absolute left-0 top-[7px] h-0.5 w-5 rounded-full bg-slate-950 transition ${
              open ? "opacity-0" : "opacity-100"
            }`}
          />
          <span
            className={`absolute left-0 h-0.5 w-5 rounded-full bg-slate-950 transition ${
              open ? "top-[7px] -rotate-45" : "top-[14px]"
            }`}
          />
        </span>
      </button>

      {open ? (
        <div
          id="mobile-nav-menu"
          className="absolute right-0 top-[calc(100%+14px)] grid w-[min(330px,calc(100vw-24px))] gap-2 rounded-[30px] border border-white/80 bg-white/90 p-3 shadow-[0_30px_90px_rgba(15,23,42,0.20)] ring-1 ring-slate-900/5 backdrop-blur-2xl"
          onClick={(event) => {
            const target = event.target as HTMLElement | null;
            if (target?.closest("a") || target?.closest("button")) {
              setOpen(false);
            }
          }}
        >
          {userRole ? (
            <>
              <div className="flex items-center justify-between px-2 pb-1">
                <p className="text-[11px] font-black uppercase tracking-[0.16em] text-slate-400">
                  Menu
                </p>

                <span className="rounded-full border border-emerald-500/15 bg-emerald-500/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-wide text-[#174f3e]">
                  {userRole}
                </span>
              </div>

              {navItems.map((item) => (
                <NavLink key={item.href} href={item.href} variant="mobile">
                  {item.label}
                </NavLink>
              ))}

              <div className="my-1 h-px bg-slate-900/10" />

              <NavLink href="/profile" variant="mobile">
                Profile
              </NavLink>

              <form action={logoutAction} onSubmit={() => setOpen(false)}>
                <button
                  type="submit"
                  className="w-full rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 px-4 py-3 text-left text-sm font-black text-white shadow-[0_14px_32px_rgba(239,68,68,0.22)] transition duration-300 hover:translate-x-1 focus:outline-none focus-visible:ring-4 focus-visible:ring-red-300/30"
                >
                  Logout
                </button>
              </form>
            </>
          ) : (
            <Link
              href="/login"
              className="rounded-2xl bg-gradient-to-br from-[#174f3e] to-[#2ca36f] px-4 py-3 text-center text-sm font-black text-white shadow-[0_16px_34px_rgba(23,79,62,0.28)] transition hover:-translate-y-0.5"
            >
              Login
            </Link>
          )}
        </div>
      ) : null}
    </div>
  );
}
