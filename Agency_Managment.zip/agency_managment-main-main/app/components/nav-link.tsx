"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ComponentProps, ReactNode } from "react";

type NavVariant = "desktop" | "mobile" | "profile";

type NavLinkProps = Omit<ComponentProps<typeof Link>, "className"> & {
  children: ReactNode;
  variant?: NavVariant;
  className?: string;
  activeClassName?: string;
  exact?: boolean;
};

const baseClasses: Record<NavVariant, string> = {
  desktop:
    "relative inline-flex items-center justify-center overflow-hidden rounded-full px-4 py-2.5 text-sm font-extrabold transition-all duration-300 hover:-translate-y-0.5 focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/30",
  mobile:
    "relative flex min-h-12 items-center overflow-hidden rounded-2xl px-4 py-3 text-sm font-extrabold transition-all duration-300 hover:translate-x-1 focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25",
  profile:
    "relative inline-flex items-center justify-center overflow-hidden rounded-full px-4 py-2.5 text-sm font-black transition-all duration-300 hover:-translate-y-0.5 focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/30",
};

const inactiveClasses: Record<NavVariant, string> = {
  desktop:
    "border border-transparent text-slate-600 hover:border-white/70 hover:bg-white/70 hover:text-slate-950 hover:shadow-[0_12px_28px_rgba(15,23,42,0.10)]",
  mobile:
    "border border-slate-900/5 bg-slate-950/[0.035] text-slate-700 hover:border-emerald-500/20 hover:bg-emerald-500/10 hover:text-slate-950",
  profile:
    "border border-emerald-500/15 bg-emerald-500/10 text-[#174f3e] hover:bg-emerald-500/15",
};

const activeClasses: Record<NavVariant, string> = {
  desktop:
    "border border-white/90 bg-white/75 text-[#174f3e] shadow-[0_18px_45px_rgba(23,79,62,0.18),inset_0_1px_0_rgba(255,255,255,0.95)] ring-1 ring-emerald-500/20 backdrop-blur-xl",
  mobile:
    "border border-white/90 bg-white/80 text-[#174f3e] shadow-[0_18px_45px_rgba(23,79,62,0.16),inset_0_1px_0_rgba(255,255,255,0.95)] ring-1 ring-emerald-500/20 backdrop-blur-xl",
  profile:
    "border border-white/90 bg-white/75 text-[#174f3e] shadow-[0_16px_38px_rgba(23,79,62,0.16),inset_0_1px_0_rgba(255,255,255,0.95)] ring-1 ring-emerald-500/20 backdrop-blur-xl",
};

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export function NavLink({
  href,
  children,
  variant = "desktop",
  className = "",
  activeClassName = "",
  exact = false,
  ...props
}: NavLinkProps) {
  const pathname = usePathname();

  const hrefValue =
    typeof href === "string" ? href : typeof href === "object" ? href.pathname ?? "" : "";

  const isActive =
    hrefValue === "/"
      ? pathname === "/"
      : exact
        ? pathname === hrefValue
        : pathname === hrefValue || pathname.startsWith(`${hrefValue}/`);

  return (
    <Link
      href={href}
      aria-current={isActive ? "page" : undefined}
      className={cn(
        baseClasses[variant],
        isActive ? activeClasses[variant] : inactiveClasses[variant],
        isActive && activeClassName,
        className,
      )}
      {...props}
    >
      {isActive ? (
        <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.9),transparent_38%),linear-gradient(135deg,rgba(16,185,129,0.16),rgba(255,255,255,0.18))]" />
      ) : null}

      {isActive ? (
        <span className="pointer-events-none absolute bottom-1.5 left-1/2 h-1 w-6 -translate-x-1/2 rounded-full bg-gradient-to-r from-[#174f3e] to-[#2ca36f] shadow-[0_0_18px_rgba(44,163,111,0.65)]" />
      ) : null}

      <span className="relative z-10">{children}</span>
    </Link>
  );
}