"use client";

import { useMemo, useState } from "react";
import { cn, ui } from "../lib/ui";

type Team = {
  id: string;
  name: string;
};

type Member = {
  id: string;
  name: string;
  email: string;
  role: string;
  team: { id: string; name: string } | null;
};

export function TeamMemberAdder({
  teams,
  members,
}: {
  teams: Team[];
  members: Member[];
}) {
  const [teamId, setTeamId] = useState("");
  const [pendingMemberId, setPendingMemberId] = useState("");
  const [addedMemberIds, setAddedMemberIds] = useState<string[]>([]);

  const memberById = useMemo(() => {
    return new Map(members.map((member) => [member.id, member]));
  }, [members]);

  const availableMembers = useMemo(() => {
    if (!teamId) return members;
    return members.filter((member) => member.team?.id !== teamId);
  }, [members, teamId]);

  const addedMembers = useMemo(() => {
    return addedMemberIds
      .map((id) => memberById.get(id))
      .filter((member): member is Member => Boolean(member));
  }, [addedMemberIds, memberById]);

  function addSelectedMember() {
    if (!pendingMemberId) return;
    setAddedMemberIds((current) =>
      current.includes(pendingMemberId)
        ? current
        : [...current, pendingMemberId],
    );
    setPendingMemberId("");
  }

  function removeMember(id: string) {
    setAddedMemberIds((current) => current.filter((entry) => entry !== id));
  }

  const canSubmit = Boolean(teamId) && addedMemberIds.length > 0;

  return (
    <div className="mt-4 grid gap-4 md:grid-cols-2">
      <label className={ui.fieldLabel}>
        Team
        <select
          name="teamId"
          className={ui.select}
          required
          value={teamId}
          onChange={(event) => {
            setTeamId(event.target.value);
            setAddedMemberIds([]);
            setPendingMemberId("");
          }}
        >
          <option value="" disabled>
            Select a team
          </option>
          {teams.map((team) => (
            <option key={team.id} value={team.id}>
              {team.name}
            </option>
          ))}
        </select>
        <div className={ui.fieldHelp}>
          Changing team will reset the selected members list.
        </div>
      </label>

      <div className="grid gap-3">
        <label className={ui.fieldLabel}>
          Add member (one by one)
          <div className="mt-2 flex gap-2">
            <select
              className={cn(ui.select, "mt-0 flex-1")}
              value={pendingMemberId}
              onChange={(event) => setPendingMemberId(event.target.value)}
              disabled={!teamId}
            >
              <option value="">
                {teamId ? "Select a person" : "Select a team first"}
              </option>
              {availableMembers.map((member) => (
                <option key={member.id} value={member.id}>
                  {member.name} ({member.email}) — {member.role}
                  {member.team ? ` — Team: ${member.team.name}` : " — No team"}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={addSelectedMember}
              disabled={!pendingMemberId || !teamId}
              className={cn(
                ui.actionSecondary,
                "shrink-0 px-4 py-2.5 text-sm disabled:cursor-not-allowed disabled:opacity-60",
              )}
            >
              Add
            </button>
          </div>
        </label>

        <div className="rounded-[24px] border border-stone-900/10 bg-white/70 p-4 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <div className="text-sm font-semibold text-stone-900">
              Selected members
            </div>
            <div className="text-xs text-stone-500">
              {addedMemberIds.length} selected
            </div>
          </div>

          {addedMembers.length === 0 ? (
            <div className="mt-3 text-sm text-stone-500">
              No one selected yet.
            </div>
          ) : (
            <ul className="mt-3 grid gap-2">
              {addedMembers.map((member) => (
                <li
                  key={member.id}
                  className="flex items-center justify-between gap-3 rounded-2xl border border-stone-900/10 bg-white/75 px-3 py-2 text-sm"
                >
                  <div className="min-w-0">
                    <div className="truncate font-medium text-stone-900">
                      {member.name}
                    </div>
                    <div className="truncate text-xs text-stone-500">
                      {member.email}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeMember(member.id)}
                    className="shrink-0 text-xs font-semibold text-red-700 hover:underline"
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {addedMemberIds.map((id) => (
          <input key={id} type="hidden" name="memberIds" value={id} />
        ))}

        <button
          type="submit"
          disabled={!canSubmit}
          className={cn(
            ui.actionPrimary,
            "w-fit disabled:cursor-not-allowed disabled:opacity-60",
          )}
        >
          Add members
        </button>
      </div>
    </div>
  );
}
