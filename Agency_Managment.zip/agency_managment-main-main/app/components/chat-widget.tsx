"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";
import { chipClasses, cn, ui } from "../lib/ui";

type ChatWidgetProps = {
  currentUser: {
    id: string;
    name: string;
    role: string;
    chatBlocked: boolean;
  } | null;
};

type ChatMessage = {
  id: string;
  text: string;
  createdAt: string;
  sender: {
    id: string;
    name: string;
    role: string;
  };
};

type ChatTokenResponse = {
  token?: string;
  blocked?: boolean;
  user?: {
    id: string;
    name: string;
    role: string;
  };
};

type ChatMessagesResponse = {
  blocked?: boolean;
  messages: ChatMessage[];
  hasMore?: boolean;
  nextCursor?: string | null;
};

type TypingUser = {
  id: string;
  name: string;
};

export function ChatWidget({ currentUser }: ChatWidgetProps) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [onlineCount, setOnlineCount] = useState(0);
  const [unreadCount, setUnreadCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [blocked, setBlocked] = useState(Boolean(currentUser?.chatBlocked));
  const [typingUsers, setTypingUsers] = useState<TypingUser[]>([]);
  const [error, setError] = useState<string | null>(null);
  const socketRef = useRef<Socket | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const messageScrollRef = useRef<HTMLDivElement | null>(null);
  const openRef = useRef(open);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isTypingRef = useRef(false);

  useEffect(() => {
    openRef.current = open;
  }, [open]);

  useEffect(() => {
    if (!currentUser) return;

    let mounted = true;

    async function initialize() {
      setLoading(true);
      setError(null);

      try {
        const [messagesRes, tokenRes] = await Promise.all([
          fetch("/api/chat/messages", { cache: "no-store" }),
          fetch("/api/chat-token", { cache: "no-store" }),
        ]);

        if (!messagesRes.ok || !tokenRes.ok) {
          throw new Error("Failed to load chat.");
        }

        const messagesData = (await messagesRes.json()) as ChatMessagesResponse;
        const tokenData = (await tokenRes.json()) as ChatTokenResponse;

        if (!mounted) return;

        setMessages(messagesData.messages);
        setHasMore(Boolean(messagesData.hasMore));
        setNextCursor(messagesData.nextCursor ?? null);
        setBlocked(Boolean(messagesData.blocked || tokenData.blocked));

        if (tokenData.token && !messagesData.blocked && !tokenData.blocked) {
          setConnecting(true);

          const socket = io({
            path: "/socket.io",
            auth: { token: tokenData.token },
          });

          socket.on("connect", () => {
            if (!mounted) return;
            setConnecting(false);
            setError(null);
          });

          socket.on("connect_error", () => {
            if (!mounted) return;
            setConnecting(false);
            setError("Realtime connection failed.");
          });

          socket.on("chat:error", (payload: { message?: string }) => {
            if (!mounted) return;
            setError(payload.message || "Chat error.");
            if (payload.message?.toLowerCase().includes("blocked")) {
              setBlocked(true);
            }
          });

          socket.on("presence:update", (payload: { onlineCount?: number }) => {
            if (!mounted) return;
            setOnlineCount(payload.onlineCount ?? 0);
          });

          socket.on("chat:message:new", (message: ChatMessage) => {
            if (!mounted) return;
            setMessages((current) => [...current, message]);
            if (!openRef.current) {
              setUnreadCount((count) => count + 1);
            }
          });

          socket.on(
            "chat:typing:update",
            (payload: { users?: TypingUser[] }) => {
              if (!mounted) return;
              const users = Array.isArray(payload.users) ? payload.users : [];
              setTypingUsers(
                users.filter((user) => user.id !== currentUser?.id),
              );
            },
          );

          socket.on("chat:message:deleted", (payload: { id?: string }) => {
            if (!mounted || !payload.id) return;
            setMessages((current) =>
              current.filter((message) => message.id !== payload.id),
            );
          });

          socketRef.current = socket;
        }
      } catch {
        if (!mounted) return;
        setError("Unable to load company chat.");
      } finally {
        if (mounted) setLoading(false);
      }
    }

    initialize();

    return () => {
      mounted = false;
      if (isTypingRef.current) {
        socketRef.current?.emit("chat:typing:stop");
      }
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = null;
      }
      socketRef.current?.disconnect();
      socketRef.current = null;
    };
  }, [currentUser]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  const canSend = useMemo(() => {
    return Boolean(input.trim()) && !blocked && !connecting;
  }, [blocked, connecting, input]);

  const typingSummary = useMemo(() => {
    if (typingUsers.length === 0) return null;
    if (typingUsers.length === 1) return `${typingUsers[0].name} is typing...`;
    if (typingUsers.length === 2) {
      return `${typingUsers[0].name} and ${typingUsers[1].name} are typing...`;
    }

    return `${typingUsers.length} people are typing...`;
  }, [typingUsers]);

  if (!currentUser) return null;

  function stopTyping() {
    if (!isTypingRef.current) return;
    socketRef.current?.emit("chat:typing:stop");
    isTypingRef.current = false;
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = null;
    }
  }

  function scheduleTyping() {
    if (blocked || !socketRef.current?.connected) return;

    if (!isTypingRef.current) {
      socketRef.current.emit("chat:typing:start");
      isTypingRef.current = true;
    }

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      stopTyping();
    }, 1400);
  }

  function sendMessage() {
    const text = input.trim();
    if (!text || blocked) return;

    stopTyping();
    socketRef.current?.emit("chat:message:create", { text });
    setInput("");
  }

  function deleteMessage(messageId: string) {
    socketRef.current?.emit("chat:message:delete", { messageId });
  }

  async function loadOlderMessages() {
    if (!nextCursor || loadingOlder) return;

    const container = messageScrollRef.current;
    const previousHeight = container?.scrollHeight ?? 0;

    setLoadingOlder(true);
    setError(null);

    try {
      const response = await fetch(
        `/api/chat/messages?before=${encodeURIComponent(nextCursor)}`,
        {
          cache: "no-store",
        },
      );

      if (!response.ok) {
        throw new Error("Failed to load older messages.");
      }

      const data = (await response.json()) as ChatMessagesResponse;

      setMessages((current) => [...data.messages, ...current]);
      setHasMore(Boolean(data.hasMore));
      setNextCursor(data.nextCursor ?? null);

      requestAnimationFrame(() => {
        if (!container) return;
        const newHeight = container.scrollHeight;
        container.scrollTop += newHeight - previousHeight;
      });
    } catch {
      setError("Unable to load older messages.");
    } finally {
      setLoadingOlder(false);
    }
  }

  return (
    <div className="fixed bottom-3 right-3 z-50 md:bottom-6 md:right-6">
      {open ? (
        <div className={`${ui.panelStrong} flex h-[min(34rem,calc(100vh-6rem))] w-[min(calc(100vw-2rem),24rem)] flex-col overflow-hidden`}>
          <div className="border-b border-stone-900/10 px-4 py-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-sm font-semibold">Company chat</div>
                <div className="mt-1 text-xs text-stone-500">
                  {blocked
                    ? "Chat access blocked"
                    : connecting
                      ? "Connecting..."
                      : `${onlineCount} online`}
                </div>
              </div>
              <button
                type="button"
                className={cn(ui.actionSecondary, "px-3 py-1.5 text-xs")}
                onClick={() => setOpen(false)}
              >
                Close
              </button>
            </div>
          </div>

          <div
            ref={messageScrollRef}
            className="flex-1 space-y-3 overflow-y-auto px-4 py-4"
          >
            {loading ? (
              <div className="text-sm text-stone-500">
                Loading chat...
              </div>
            ) : blocked ? (
              <div className={`${ui.panel} p-4 text-sm text-stone-500`}>
                Chat access has been blocked by an admin.
              </div>
            ) : messages.length === 0 ? (
              <div className={`${ui.panel} p-4 text-sm text-stone-500`}>
                No messages yet. Start the conversation.
              </div>
            ) : (
              <>
                {hasMore ? (
                  <div className="flex justify-center pb-2">
                    <button
                      type="button"
                      className={cn(ui.actionSecondary, "px-3 py-2 text-xs")}
                      onClick={loadOlderMessages}
                      disabled={loadingOlder}
                    >
                      {loadingOlder ? "Loading..." : "Load older messages"}
                    </button>
                  </div>
                ) : null}

                {messages.map((message, index) => {
                  const mine = message.sender.id === currentUser.id;
                  const previous = messages[index - 1];
                  const sameSenderAsPrevious =
                    previous?.sender.id === message.sender.id;
                  const showDateDivider =
                    !previous ||
                    new Date(previous.createdAt).toDateString() !==
                      new Date(message.createdAt).toDateString();

                  return (
                    <div key={message.id}>
                      {showDateDivider ? (
                        <div className="my-3 flex justify-center">
                          <span className={chipClasses("neutral")}>
                            {new Date(message.createdAt).toLocaleDateString(
                              [],
                              {
                                day: "2-digit",
                                month: "short",
                                year: "numeric",
                              },
                            )}
                          </span>
                        </div>
                      ) : null}

                      <div
                        className={`${sameSenderAsPrevious ? "mt-1" : "mt-3"}`}
                      >
                        {!sameSenderAsPrevious ? (
                          <div
                            className={`mb-1 flex items-center gap-2 px-1 text-[11px] font-semibold ${
                              mine
                                ? "justify-end text-emerald-900"
                                : "text-stone-500"
                            }`}
                          >
                            <span>{mine ? "You" : message.sender.name}</span>
                            <span className="rounded-full bg-stone-100 px-2 py-0.5 text-[10px] text-stone-600">
                              {message.sender.role}
                            </span>
                          </div>
                        ) : null}

                        <div
                            className={`max-w-[88%] rounded-3xl px-4 py-3 text-sm ${
                              mine
                                ? "ml-auto bg-emerald-700 text-white"
                                : "bg-white/85 text-stone-900 shadow-sm"
                            }`}
                        >
                          {currentUser.role === "ADMIN" &&
                          !sameSenderAsPrevious ? (
                            <div className="mb-1 flex justify-end">
                              <button
                                type="button"
                                className={`text-[10px] font-semibold ${
                                  mine
                                    ? "text-white/80"
                                    : "text-red-700"
                                }`}
                                onClick={() => deleteMessage(message.id)}
                              >
                                Delete
                              </button>
                            </div>
                          ) : currentUser.role === "ADMIN" ? (
                            <div className="mb-1 flex justify-end">
                              <button
                                type="button"
                                className={`text-[10px] font-semibold ${
                                  mine
                                    ? "text-white/75"
                                    : "text-red-700"
                                }`}
                                onClick={() => deleteMessage(message.id)}
                              >
                                Delete
                              </button>
                            </div>
                          ) : null}
                          <div className="mt-1 whitespace-pre-wrap break-words [overflow-wrap:anywhere]">
                            {message.text}
                          </div>
                          <div
                            className={`mt-2 text-[10px] ${
                              mine
                                ? "text-white/70"
                                : "text-stone-500"
                            }`}
                          >
                            {new Date(message.createdAt).toLocaleTimeString(
                              [],
                              {
                                hour: "2-digit",
                                minute: "2-digit",
                              },
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </>
            )}
            <div ref={bottomRef} />
          </div>

          <div className="border-t border-stone-900/10 px-4 py-4">
            {error ? (
              <div className="mb-3 text-xs text-red-700">
                {error}
              </div>
            ) : null}
            <div className="flex items-end gap-2">
              <textarea
                value={input}
                onChange={(event) => {
                  const nextValue = event.target.value;
                  setInput(nextValue);

                  if (!nextValue.trim()) {
                    stopTyping();
                    return;
                  }

                  scheduleTyping();
                }}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    sendMessage();
                  }
                }}
                onBlur={() => stopTyping()}
                className={cn(ui.textarea, "mt-0 min-h-0 flex-1")}
                rows={2}
                placeholder={
                  blocked
                    ? "Chat blocked"
                    : "Write a message... (Enter to send)"
                }
                disabled={blocked}
              />
              <button
                type="button"
                className={cn(ui.actionPrimary, "px-4 py-3 text-sm disabled:cursor-not-allowed disabled:opacity-50")}
                onClick={sendMessage}
                disabled={!canSend}
              >
                Send
              </button>
            </div>
            {!blocked && typingSummary ? (
              <div className="mt-3 flex items-center gap-2 px-1 text-xs text-stone-500">
                <span className="flex items-center gap-1">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-700" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-700 [animation-delay:120ms]" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-700 [animation-delay:240ms]" />
                </span>
                <span>{typingSummary}</span>
              </div>
            ) : null}
          </div>
        </div>
      ) : (
        <button
          type="button"
          aria-label="Open messages"
          className="
    group relative inline-flex h-12 items-center justify-center overflow-visible rounded-full
    border border-white/25
    bg-[linear-gradient(135deg,#123f33_0%,#1f7a5b_48%,#2aa06f_100%)]
    px-2
    text-white
    shadow-[0_14px_30px_rgba(23,79,62,0.28)]
    ring-1 ring-emerald-200/20
    backdrop-blur-xl
    transition-all duration-300 ease-out
    hover:-translate-y-0.5
    hover:scale-[1.03]
    hover:shadow-[0_24px_65px_rgba(23,79,62,0.48)]
    active:translate-y-0
    active:scale-[0.97]
    focus:outline-none
    focus-visible:ring-4
    focus-visible:ring-emerald-300/35
    md:h-14
    md:shadow-[0_18px_45px_rgba(23,79,62,0.35)]
  "
          onClick={() => {
            setUnreadCount(0);
            setOpen(true);
          }}
        >
          {/* Soft shine layer */}
          <span className="pointer-events-none absolute inset-0 overflow-hidden rounded-full">
            <span
              className="
        absolute inset-0
        bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.38),transparent_34%),linear-gradient(120deg,transparent_0%,rgba(255,255,255,0.22)_45%,transparent_62%)]
        opacity-80
        transition-opacity duration-300
        group-hover:opacity-100
      "
            />

            {/* Moving light */}
            <span
              className="
        absolute -left-10 top-0 h-full w-8 rotate-12
        bg-white/35 blur-sm
        transition-all duration-700 ease-out
        group-hover:left-[120%]
      "
            />
          </span>

          <span
            className="
      relative flex h-9 w-9 items-center justify-center rounded-full
      border border-white/25
      bg-white/15
      shadow-[inset_0_1px_0_rgba(255,255,255,0.35),0_10px_22px_rgba(0,0,0,0.14)]
      transition-all duration-300
      group-hover:bg-white/22
      group-hover:shadow-[inset_0_1px_0_rgba(255,255,255,0.45),0_14px_28px_rgba(0,0,0,0.18)]
      md:h-11 md:w-11
    "
          >
            <svg
              aria-hidden="true"
              viewBox="0 0 24 24"
              className="
        h-4 w-4 fill-none stroke-current stroke-2
        transition-transform duration-300
        group-hover:scale-110
        md:h-5 md:w-5
      "
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M7 10h10M7 14h6m-8 6 2.6-2H18a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h1Z"
              />
            </svg>

            {unreadCount > 0 ? (
              <span
                className="
          absolute -right-2 -top-2
          flex h-5 min-w-5 items-center justify-center rounded-full
          bg-[linear-gradient(135deg,#ff8a3d,#ef4444)]
          px-1.5
          text-[10px] font-black leading-none text-white
          shadow-[0_8px_20px_rgba(239,68,68,0.45)]
          ring-2 ring-white
          animate-pulse
        "
              >
                {unreadCount > 99 ? "99+" : unreadCount}
              </span>
            ) : null}
          </span>
        </button>
      )}
    </div>
  );
}
