import Link from "next/link";
import { redirect } from "next/navigation";
import { login } from "../actions/auth";
import { getSessionUser } from "../lib/auth";
import { noticeClasses, ui } from "../lib/ui";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const user = await getSessionUser();
  if (user) redirect("/dashboard");

  const { error } = await searchParams;
  const message =
    error === "missing"
      ? "Email and password are required."
      : error === "invalid"
        ? "Invalid email or password."
        : error === "reset-success"
          ? "Password reset successful. Please sign in."
          : null;
  const isSuccess = error === "reset-success";

  return (
    <div className="max-w-md mx-auto">
      <section className={`${ui.panelStrong} p-6 md:p-8`}>
        <span className={ui.eyebrow}>Welcome back</span>
        <h2 className="mt-4 text-3xl font-semibold tracking-tight">Login</h2>
        {message ? (
          <div className={`${noticeClasses(isSuccess ? "success" : "error")} mt-5`}>
            {message}
          </div>
        ) : null}
        <form action={login} className="mt-6 space-y-4">
          <label className={ui.fieldLabel}>
            Email
            <input
              name="email"
              type="email"
              autoComplete="email"
              className={ui.input}
              placeholder="you@company.com"
              required
            />
          </label>
          <label className={ui.fieldLabel}>
            Password
            <input
              name="password"
              type="password"
              autoComplete="current-password"
              className={ui.input}
              placeholder="Enter your password"
              required
            />
          </label>
          <button className={`${ui.actionPrimary} mt-2 w-full`}>Sign in</button>
        </form>
        <div className="mt-5 flex items-center justify-between gap-3 text-sm">
          <Link href="/forgot-password" className={ui.linkAccent}>
            Forgot password?
          </Link>
          <Link href="/apply" className="underline">
            Don&apos;t have an account?{" "} Apply...
          </Link>
        </div>
      </section>
    </div>
  );
}
