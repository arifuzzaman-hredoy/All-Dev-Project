import { Role } from "@prisma/client";

export function canAccess(userRole: Role, allowed: Role[]) {
  return allowed.includes(userRole);
}

export function assertRole(userRole: Role, allowed: Role[]) {
  if (!canAccess(userRole, allowed)) {
    throw new Error("Forbidden");
  }
}

export const Roles = Role;

