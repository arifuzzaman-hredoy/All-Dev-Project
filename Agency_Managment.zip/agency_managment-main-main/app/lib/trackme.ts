import { mkdir, readdir, readFile, stat, unlink } from "node:fs/promises";
import path from "node:path";

export type TrackmeScreenshot = {
  fileName: string;
  metadataFileName: string;
  userId: string;
  userName: string;
  userEmail: string;
  capturedAt: string;
  uploadedAt: string;
  count: number;
  size: number;
  mimeType: string;
};

export const TRACKME_UPLOAD_DIR = path.join(process.cwd(), "uploads", "trackme");

export async function ensureTrackmeUploadDir() {
  await mkdir(TRACKME_UPLOAD_DIR, { recursive: true });
}

export function sanitizeTrackmeFilePart(value: string) {
  return value
    .trim()
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

export function getTrackmeImagePath(fileName: string) {
  const safeFileName = sanitizeTrackmeFilePart(fileName);
  if (!safeFileName || safeFileName !== fileName) return null;
  return path.join(TRACKME_UPLOAD_DIR, safeFileName);
}

export function makeLatestTrackmeFileName(userId: string, userName: string, extension: string) {
  const userPart = sanitizeTrackmeFilePart(`${userName}-${userId}`) || userId;
  return `${userPart}-latest.${extension}`;
}

export async function removeTrackmeScreenshotsForUser(userId: string) {
  await ensureTrackmeUploadDir();

  const fileNames = await readdir(TRACKME_UPLOAD_DIR);
  const metadataFiles = fileNames.filter((fileName) => fileName.endsWith(".json"));

  await Promise.all(
    metadataFiles.map(async (metadataFileName) => {
      try {
        const metadataPath = path.join(TRACKME_UPLOAD_DIR, metadataFileName);
        const rawMetadata = await readFile(metadataPath, "utf8");
        const metadata = JSON.parse(rawMetadata) as TrackmeScreenshot;
        if (metadata.userId !== userId) return;

        const imagePath = getTrackmeImagePath(metadata.fileName);
        await Promise.all([
          imagePath ? unlink(imagePath).catch(() => undefined) : Promise.resolve(),
          unlink(metadataPath).catch(() => undefined),
        ]);
      } catch {
        return;
      }
    })
  );
}

export async function listTrackmeScreenshots() {
  await ensureTrackmeUploadDir();

  const fileNames = await readdir(TRACKME_UPLOAD_DIR);
  const metadataFiles = fileNames.filter((fileName) => fileName.endsWith(".json"));

  const metadataEntries = await Promise.all(
    metadataFiles.map(async (metadataFileName) => {
      try {
        const metadataPath = path.join(TRACKME_UPLOAD_DIR, metadataFileName);
        const rawMetadata = await readFile(metadataPath, "utf8");
        const metadata = JSON.parse(rawMetadata) as TrackmeScreenshot;
        const imagePath = getTrackmeImagePath(metadata.fileName);
        if (!imagePath) return null;

        return {
          ...metadata,
          metadataFileName,
        };
      } catch {
        return null;
      }
    })
  );

  const latestByUser = new Map<string, TrackmeScreenshot>();

  metadataEntries
    .filter((entry): entry is TrackmeScreenshot => Boolean(entry))
    .forEach((screenshot) => {
      const current = latestByUser.get(screenshot.userId);
      if (!current || screenshot.capturedAt > current.capturedAt) {
        latestByUser.set(screenshot.userId, screenshot);
      }
    });

  const latestScreenshots = await Promise.all(
    Array.from(latestByUser.values()).map(async (screenshot) => {
      try {
        const imagePath = getTrackmeImagePath(screenshot.fileName);
        if (!imagePath) return null;

        const imageStat = await stat(imagePath);
        return {
          ...screenshot,
          size: imageStat.size,
        };
      } catch {
        return null;
      }
    })
  );

  return latestScreenshots
    .filter((entry): entry is TrackmeScreenshot => Boolean(entry))
    .sort((a, b) => a.userName.localeCompare(b.userName));
}
