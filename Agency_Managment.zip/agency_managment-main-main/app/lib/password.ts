import crypto from "node:crypto";

const SCRYPT_KEYLEN = 64;

export async function hashPassword(password: string) {
  if (password.length < 8) {
    throw new Error("Password must be at least 8 characters.");
  }

  const salt = crypto.randomBytes(16);
  const derivedKey = await scryptAsync(password, salt, SCRYPT_KEYLEN);
  return `scrypt$${salt.toString("base64")}$${derivedKey.toString("base64")}`;
}

export async function verifyPassword(password: string, passwordHash: string) {
  const [algo, saltB64, keyB64] = passwordHash.split("$");
  if (algo !== "scrypt" || !saltB64 || !keyB64) return false;

  const salt = Buffer.from(saltB64, "base64");
  const expectedKey = Buffer.from(keyB64, "base64");
  const actualKey = await scryptAsync(password, salt, expectedKey.length);

  return crypto.timingSafeEqual(expectedKey, actualKey);
}

function scryptAsync(password: string, salt: Buffer, keylen: number) {
  return new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, keylen, (err, derivedKey) => {
      if (err) reject(err);
      else resolve(derivedKey as Buffer);
    });
  });
}

