import { prisma } from "./db";
import { todayDayString } from "./dates";

const DHAKA_OFFSET = "+06:00";
const STALE_SESSION_BATCH_SIZE = 500;

type AttendanceSessionLike = {
  startedAt: Date;
  endedAt: Date | null;
};

function dateTimeForDay(day: string, time: string) {
  return new Date(`${day}T${time}${DHAKA_OFFSET}`);
}

export function attendanceDayEnd(day: string) {
  return dateTimeForDay(day, "23:59:59.999");
}

export function normalizeSessionEndForDisplay(
  session: AttendanceSessionLike,
  currentDay = todayDayString(),
) {
  if (session.endedAt) return session.endedAt;

  const sessionDay = new Intl.DateTimeFormat("en-CA", {
    timeZone: process.env.APP_TZ || "Asia/Dhaka",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  })
    .formatToParts(session.startedAt)
    .reduce<Record<string, string>>((parts, part) => {
      if (part.type !== "literal") parts[part.type] = part.value;
      return parts;
    }, {});

  const startedDay =
    sessionDay.year && sessionDay.month && sessionDay.day
      ? `${sessionDay.year}-${sessionDay.month}-${sessionDay.day}`
      : currentDay;

  if (startedDay >= currentDay) return null;

  const fallbackEnd = attendanceDayEnd(startedDay);
  return fallbackEnd.getTime() > session.startedAt.getTime()
    ? fallbackEnd
    : session.startedAt;
}

export async function closeStaleOpenAttendanceSessions(userId?: string) {
  const today = todayDayString();

  while (true) {
    const staleAttendances = await prisma.attendance.findMany({
      where: {
        day: { lt: today },
        ...(userId ? { userId } : {}),
        sessions: { some: { endedAt: null } },
      },
      select: {
        id: true,
        day: true,
        sessions: {
          where: { endedAt: null },
          select: { id: true, startedAt: true },
        },
      },
      take: STALE_SESSION_BATCH_SIZE,
    });

    if (staleAttendances.length === 0) return;

    await prisma.$transaction(async (tx) => {
      for (const attendance of staleAttendances) {
        const dayEnd = attendanceDayEnd(attendance.day);
        let latestEnd: Date | null = null;

        for (const session of attendance.sessions) {
          const endedAt =
            dayEnd.getTime() > session.startedAt.getTime()
              ? dayEnd
              : session.startedAt;
          latestEnd =
            !latestEnd || endedAt.getTime() > latestEnd.getTime()
              ? endedAt
              : latestEnd;

          await tx.attendanceSession.update({
            where: { id: session.id },
            data: { endedAt },
          });
        }

        if (latestEnd) {
          await tx.attendance.update({
            where: { id: attendance.id },
            data: { checkOutAt: latestEnd },
          });
        }
      }
    });
  }
}
