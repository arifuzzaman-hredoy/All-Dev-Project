export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export const ui = {
  topbar:
    "sticky top-0 z-40 border-b border-stone-900/10 bg-[#fcf9f3]/90 backdrop-blur-xl",
  topbarInner:
    "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 md:flex-row md:items-center md:justify-between md:px-6",
  topbarMenu: "flex min-w-0 flex-col gap-3 md:items-end",
  topbarNav:
    "-mx-1 flex min-w-0 items-center gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden md:mx-0 md:justify-end md:overflow-visible md:px-0 md:pb-0",
  topbarActions: "flex flex-wrap items-center gap-2 md:justify-end",
  brandMark:
    "flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-700 to-orange-700 text-lg font-bold text-white shadow-[0_16px_32px_rgba(53,64,42,0.18)]",
  heroCard:
    "overflow-hidden rounded-[34px] border border-emerald-900/15 bg-[radial-gradient(circle_at_top_right,rgba(216,239,230,0.85),transparent_35%),linear-gradient(135deg,rgba(255,250,241,0.98),rgba(244,237,226,0.94))] px-6 py-6 shadow-[0_28px_50px_rgba(64,44,16,0.1),inset_0_1px_0_rgba(255,255,255,0.75)] md:px-8 md:py-8",
  eyebrow:
    "inline-flex items-center rounded-full bg-emerald-700/8 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.24em] text-emerald-700",
  pageTitle: "mt-4 text-3xl font-semibold tracking-tight text-stone-950 md:text-5xl",
  pageCopy: "mt-3 max-w-2xl text-sm leading-6 text-stone-500 md:text-base",
  panel:
    "rounded-[28px] border border-stone-900/10 bg-white/80 shadow-[0_22px_50px_rgba(57,39,14,0.08)] backdrop-blur-[20px]",
  panelStrong:
    "rounded-[30px] border border-stone-900/15 bg-[linear-gradient(180deg,rgba(255,252,247,0.98),rgba(251,245,236,0.92))] shadow-[0_30px_60px_rgba(53,39,14,0.12),inset_0_1px_0_rgba(255,255,255,0.7)]",
  sectionTitle: "text-lg font-semibold tracking-tight text-stone-950 md:text-xl",
  sectionCopy: "text-sm leading-6 text-stone-500",
  statCard:
    "rounded-[26px] border border-stone-900/10 bg-[rgba(255,251,244,0.88)] p-5 shadow-[0_20px_40px_rgba(49,34,12,0.07)]",
  metric: "mt-4 text-4xl font-semibold tracking-tight text-stone-950",
  navLink:
    "inline-flex shrink-0 items-center whitespace-nowrap rounded-full px-3 py-2 text-sm font-medium text-stone-500 transition hover:bg-emerald-700/5 hover:text-stone-900",
  navLinkActive:
    "bg-emerald-700/10 text-emerald-900 shadow-[inset_0_0_0_1px_rgba(31,106,82,0.08)]",
  actionPrimary:
    "inline-flex items-center justify-center rounded-full bg-gradient-to-br from-emerald-700 to-emerald-900 px-4 py-2.5 text-sm font-semibold text-white shadow-[0_14px_30px_rgba(23,79,62,0.26)] transition hover:-translate-y-0.5 hover:shadow-[0_18px_34px_rgba(23,79,62,0.3)]",
  actionSecondary:
    "inline-flex items-center justify-center rounded-full border border-stone-900/15 bg-[rgba(255,252,247,0.78)] px-4 py-2.5 text-sm font-semibold text-stone-900 transition hover:-translate-y-0.5 hover:bg-white/95",
  fieldLabel: "block text-sm font-semibold text-stone-950",
  fieldHelp: "mt-1 text-xs text-stone-500",
  input:
    "mt-2 w-full rounded-2xl border border-stone-900/10 bg-[rgba(255,252,247,0.95)] px-4 py-3 text-sm outline-none shadow-[inset_0_1px_0_rgba(255,255,255,0.65)] transition focus:border-emerald-700/30 focus:shadow-[0_0_0_5px_rgba(31,106,82,0.16),inset_0_1px_0_rgba(255,255,255,0.72)]",
  textarea:
    "mt-2 w-full resize-y rounded-2xl border border-stone-900/10 bg-[rgba(255,252,247,0.95)] px-4 py-3 text-sm outline-none shadow-[inset_0_1px_0_rgba(255,255,255,0.65)] transition focus:border-emerald-700/30 focus:shadow-[0_0_0_5px_rgba(31,106,82,0.16),inset_0_1px_0_rgba(255,255,255,0.72)]",
  select:
    "mt-2 w-full rounded-2xl border border-stone-900/10 bg-[rgba(255,252,247,0.95)] px-4 py-3 text-sm outline-none shadow-[inset_0_1px_0_rgba(255,255,255,0.65)] transition focus:border-emerald-700/30 focus:shadow-[0_0_0_5px_rgba(31,106,82,0.16),inset_0_1px_0_rgba(255,255,255,0.72)]",
  notice: "rounded-[22px] border px-4 py-3 text-sm",
  noticeSuccess:
    "rounded-[22px] border border-emerald-900/15 bg-emerald-50/90 px-4 py-3 text-sm text-emerald-800",
  noticeError:
    "rounded-[22px] border border-red-900/15 bg-red-50/90 px-4 py-3 text-sm text-red-700",
  listCard:
    "overflow-hidden rounded-[28px] border border-stone-900/10 bg-white/80 shadow-[0_22px_50px_rgba(57,39,14,0.08)]",
  listHeading:
    "border-b border-stone-900/10 bg-[rgba(255,252,247,0.72)] px-5 py-4 text-sm font-semibold text-stone-950",
  emptyState: "px-5 py-8 text-sm text-stone-500",
  proseBlock: "whitespace-pre-wrap text-sm leading-6 text-stone-800/90",
  softDivider: "border-stone-900/10",
  chipBase: "inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold",
  chipSuccess: "bg-emerald-50 text-emerald-800",
  chipWarn: "bg-orange-50 text-orange-700",
  chipNeutral: "bg-stone-900/7 text-stone-500",
  linkAccent: "inline-flex text-sm font-medium text-emerald-700 hover:underline",
} as const;

export function chipClasses(variant: "success" | "warn" | "neutral") {
  return cn(
    ui.chipBase,
    variant === "success" && ui.chipSuccess,
    variant === "warn" && ui.chipWarn,
    variant === "neutral" && ui.chipNeutral
  );
}

export function noticeClasses(variant: "success" | "error" | "neutral" = "neutral") {
  return cn(
    variant === "success"
      ? ui.noticeSuccess
      : variant === "error"
        ? ui.noticeError
        : `${ui.notice} border-stone-900/10 bg-white/80 text-stone-700`
  );
}
