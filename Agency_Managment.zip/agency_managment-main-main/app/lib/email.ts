import nodemailer from "nodemailer";

type ResetEmailInput = {
  email: string;
  name: string;
  resetUrl: string;
};

export async function sendPasswordResetEmail({
  email,
  name,
  resetUrl,
}: ResetEmailInput) {
  const transporter = createTransporter();
  const from = process.env.SMTP_FROM;

  if (!from) {
    throw new Error("SMTP_FROM must be set to send password reset emails.");
  }

  await transporter.sendMail({
    from,
    to: email,
    subject: "Reset your CompanyLearn password",
    text: [
      `Hi ${name},`,
      "",
      "We received a request to reset your CompanyLearn password.",
      `Open this link to continue: ${resetUrl}`,
      "",
      "This link will expire in 30 minutes.",
      "If you did not request this, you can ignore this email.",
    ].join("\n"),
    html: `
      <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f1911;">
        <p>Hi ${escapeHtml(name)},</p>
        <p>We received a request to reset your CompanyLearn password.</p>
        <p>
          <a href="${escapeHtml(resetUrl)}">Reset your password</a>
        </p>
        <p>This link will expire in 30 minutes.</p>
        <p>If you did not request this, you can ignore this email.</p>
      </div>
    `,
  });
}

function createTransporter() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || "587");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    throw new Error("SMTP_HOST, SMTP_USER, and SMTP_PASS must be set.");
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: {
      user,
      pass,
    },
  });
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
