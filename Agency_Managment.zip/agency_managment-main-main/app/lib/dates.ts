const DEFAULT_TZ = process.env.APP_TZ || "Asia/Dhaka";

export function todayDayString() {
  return dayStringForDate(new Date());
}

export function dayStringForDate(date: Date, timeZone = DEFAULT_TZ) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);

  const year = parts.find((p) => p.type === "year")?.value;
  const month = parts.find((p) => p.type === "month")?.value;
  const day = parts.find((p) => p.type === "day")?.value;

  if (!year || !month || !day) throw new Error("Failed to format date.");
  return `${year}-${month}-${day}`;
}

export function lastNDaysDayStrings(n: number) {
  if (n < 1) return [];
  const out: string[] = [];
  const now = new Date();
  for (let i = 0; i < n; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    out.push(dayStringForDate(d));
  }
  return out;
}

