import { redirect } from "next/navigation";
import { getSessionUser } from "../../../../lib/auth";
import { prisma } from "../../../../lib/db";

export default async function ViewUpdatePage({
  params,
}: {
  params: Promise<{ userId: string; day: string }>;
}) {
  const viewer = await getSessionUser();
  if (!viewer) redirect("/login");
  if (viewer.role === "EMPLOYEE") redirect("/dashboard");

  const { userId, day } = await params;

  if (viewer.role === "LEAD") {
    const allowed = await prisma.user.findFirst({
      where: { id: userId, team: { leadId: viewer.id } },
      select: { id: true },
    });
    if (!allowed) redirect("/status?error=forbidden");
  }

  const update = await prisma.dailyUpdate.findUnique({
    where: { userId_day: { userId, day } },
    select: {
      day: true,
      todayPlan: true,
      completedWork: true,
      blockers: true,
      updatedAt: true,
      user: { select: { name: true, email: true } },
    },
  });

  if (!update) {
    return (
      <div className="space-y-2">
        <h1 className="text-2xl font-semibold">Daily update</h1>
        <p className="text-sm text-zinc-600">No submission found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Daily update</h1>
        <p className="mt-1 text-sm text-zinc-600">
          {update.user.name} • {update.user.email}
        </p>
        <p className="mt-1 text-sm text-zinc-600">
          {update.day} • last saved {update.updatedAt.toLocaleString()}
        </p>
      </div>

      <Section title="Today plan">{update.todayPlan}</Section>
      {update.completedWork ? (
        <Section title="Completed work">{update.completedWork}</Section>
      ) : null}
      {update.blockers ? <Section title="Blockers">{update.blockers}</Section> : null}
    </div>
  );
}

function Section({ title, children }: { title: string; children: string }) {
  return (
    <div className="rounded-lg border bg-white p-4 shadow-sm">
      <div className="text-sm font-medium">{title}</div>
      <pre className="mt-2 whitespace-pre-wrap text-sm text-zinc-800">
        {children}
      </pre>
    </div>
  );
}
