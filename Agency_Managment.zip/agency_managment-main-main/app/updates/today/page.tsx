import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { saveTodayUpdate } from "../../actions/dailyUpdate";
import { getSessionUser } from "../../lib/auth";
import { prisma } from "../../lib/db";
import { todayDayString } from "../../lib/dates";

function Notice({
  type,
  children,
}: {
  type: "success" | "error";
  children: ReactNode;
}) {
  const styles = {
    success:
      "border-emerald-500/20 bg-emerald-500/10 text-emerald-700",
    error: "border-red-500/20 bg-red-500/10 text-red-700",
  };

  return (
    <div
      className={`relative overflow-hidden rounded-[24px] border px-4 py-3 text-sm font-medium shadow-sm backdrop-blur-xl ${styles[type]}`}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_10%_0%,rgba(255,255,255,0.65),transparent_35%)]" />
      <div className="relative flex items-center gap-2">
        <span className="h-2 w-2 rounded-full bg-current shadow-[0_0_14px_currentColor]" />
        <span>{children}</span>
      </div>
    </div>
  );
}

function GlassLink({
  href,
  children,
}: {
  href: string;
  children: ReactNode;
}) {
  return (
    <Link
      href={href}
      className="inline-flex min-h-11 items-center justify-center rounded-full border border-white/80 bg-white/60 px-5 text-sm font-medium text-slate-700 shadow-[0_14px_34px_rgba(15,23,42,0.07),inset_0_1px_0_rgba(255,255,255,0.9)] ring-1 ring-slate-900/5 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/85 hover:text-[#174f3e] hover:shadow-[0_18px_42px_rgba(15,23,42,0.10)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25"
    >
      {children}
    </Link>
  );
}

function UpdateField({
  title,
  description,
  name,
  defaultValue,
  rows,
  placeholder,
  required = false,
}: {
  title: string;
  description: string;
  name: string;
  defaultValue?: string | null;
  rows: number;
  placeholder: string;
  required?: boolean;
}) {
  return (
    <label className="group block rounded-[30px] border border-white/75 bg-white/48 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-2xl transition-all duration-300 focus-within:border-emerald-500/25 focus-within:bg-white/68 focus-within:shadow-[0_24px_70px_rgba(15,23,42,0.10)] md:p-5">
      <div className="mb-3">
        <div className="text-base font-semibold tracking-[-0.02em] text-slate-950">
          {title}
        </div>
        <p className="mt-1 text-sm leading-6 text-slate-500">
          {description}
        </p>
      </div>

      <textarea
        name={name}
        defaultValue={defaultValue ?? ""}
        rows={rows}
        required={required}
        placeholder={placeholder}
        className="w-full resize-y rounded-[24px] border border-white/80 bg-white/70 px-4 py-4 text-sm leading-6 text-slate-800 shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_10px_26px_rgba(15,23,42,0.05)] ring-1 ring-slate-900/5 backdrop-blur-xl outline-none transition-all duration-300 placeholder:text-slate-400 focus:border-emerald-500/30 focus:bg-white/90 focus:ring-4 focus:ring-emerald-300/20"
      />
    </label>
  );
}

export default async function TodayUpdatePage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string; error?: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const day = todayDayString();

  const update = await prisma.dailyUpdate.findUnique({
    where: { userId_day: { userId: user.id, day } },
    select: {
      todayPlan: true,
      completedWork: true,
      blockers: true,
      updatedAt: true,
    },
  });

  const { saved, error } = await searchParams;

  return (
    <div className="relative space-y-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.23),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.16))]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-52 w-52 rounded-full bg-amber-300/20 blur-3xl" />

        <div className="relative z-10 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#174f3e] shadow-sm">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.85)]" />
              Daily check-in
            </span>

            <h1 className="mt-5 text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
              Daily update
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
              <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                {day}
              </span>

              {update?.updatedAt ? (
                <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                  Last saved {update.updatedAt.toLocaleString()}
                </span>
              ) : (
                <span className="rounded-full border border-amber-500/20 bg-amber-500/10 px-3 py-1.5 text-amber-700 backdrop-blur-xl">
                  First update today
                </span>
              )}
            </div>
          </div>

          <GlassLink href="/dashboard">Back to dashboard</GlassLink>
        </div>
      </section>

      {saved ? <Notice type="success">Update saved successfully.</Notice> : null}

      {error === "missing" ? (
        <Notice type="error">Please write your today plan before saving.</Notice>
      ) : null}

      {/* Form */}
      <form
        action={saveTodayUpdate}
        className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_28px_80px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6"
      >
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(16,185,129,0.16),transparent_30%),radial-gradient(circle_at_95%_8%,rgba(251,191,36,0.12),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.52),rgba(255,255,255,0.12))]" />

        <div className="relative z-10">
          <div className="mb-6 rounded-[28px] border border-white/70 bg-white/50 p-4 shadow-[0_16px_45px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl md:p-5">
            <h2 className="text-xl font-semibold tracking-[-0.03em] text-slate-950">
              Write your work update in one place
            </h2>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
              Add your plan at the start of the day. Later, update what you
              completed and mention any blocker so your lead can understand the
              progress quickly.
            </p>
          </div>

          <div className="grid gap-5">
            <UpdateField
              title="Today plan"
              description="What are you planning to work on today?"
              name="todayPlan"
              defaultValue={update?.todayPlan}
              rows={5}
              required
              placeholder="Example: Build dashboard UI, fix login issue, review task progress..."
            />

            <UpdateField
              title="Completed work"
              description="What did you finish before ending your work day?"
              name="completedWork"
              defaultValue={update?.completedWork}
              rows={5}
              placeholder="Example: Finished dashboard layout, tested mobile view, fixed API issue..."
            />

            <UpdateField
              title="Blockers"
              description="Anything stopping or slowing down your work?"
              name="blockers"
              defaultValue={update?.blockers}
              rows={4}
              placeholder="Example: Waiting for API access, design approval, database credentials..."
            />
          </div>

          <div className="mt-6 flex flex-col gap-3 rounded-[28px] border border-white/70 bg-white/45 p-4 shadow-[0_14px_40px_rgba(15,23,42,0.06)] ring-1 ring-slate-900/5 backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs leading-5 text-slate-500">
              You can update this anytime during the day. Your latest saved
              version will be shown to your team.
            </p>

            <button
              type="submit"
              className="group relative inline-flex min-h-12 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#174f3e] via-[#1f7a5b] to-[#2ca36f] px-7 text-sm font-semibold text-white shadow-[0_18px_42px_rgba(23,79,62,0.30)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_56px_rgba(23,79,62,0.42)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/35"
            >
              <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.42),transparent_34%)] opacity-80 transition group-hover:opacity-100" />
              <span className="pointer-events-none absolute -left-10 top-0 h-full w-8 rotate-12 bg-white/35 blur-sm transition-all duration-700 group-hover:left-[120%]" />
              <span className="relative z-10">Save update</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}