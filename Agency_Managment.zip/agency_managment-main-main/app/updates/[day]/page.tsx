import { redirect } from "next/navigation";
import { getSessionUser } from "../../lib/auth";
import { prisma } from "../../lib/db";

export default async function UpdateDayPage({
  params,
}: {
  params: Promise<{ day: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const { day } = await params;

  const update = await prisma.dailyUpdate.findUnique({
    where: { userId_day: { userId: user.id, day } },
    select: {
      day: true,
      todayPlan: true,
      completedWork: true,
      blockers: true,
      updatedAt: true,
    },
  });

  if (!update) {
    return (
      <div className="space-y-2">
        <h1 className="text-2xl font-semibold">Daily update</h1>
        <p className="text-sm text-zinc-600">No submission found for {day}.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Daily update</h1>
        <p className="mt-1 text-sm text-zinc-600">
          {update.day} • last saved {update.updatedAt.toLocaleString()}
        </p>
      </div>

      <Section title="Today plan">{update.todayPlan}</Section>
      {update.completedWork ? (
        <Section title="Completed work">{update.completedWork}</Section>
      ) : null}
      {update.blockers ? <Section title="Blockers">{update.blockers}</Section> : null}
    </div>
  );
}

function Section({ title, children }: { title: string; children: string }) {
  return (
    <div className="rounded-lg border bg-white p-4 shadow-sm">
      <div className="text-sm font-medium">{title}</div>
      <pre className="mt-2 whitespace-pre-wrap text-sm text-zinc-800">
        {children}
      </pre>
    </div>
  );
}
