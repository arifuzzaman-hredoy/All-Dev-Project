import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "../lib/auth";
import { prisma } from "../lib/db";
import { todayDayString } from "../lib/dates";

function StatusBadge({
  submitted,
}: {
  submitted: boolean;
}) {
  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium ${
        submitted
          ? "border-emerald-200 bg-emerald-50 text-emerald-700"
          : "border-amber-200 bg-amber-50 text-amber-700"
      }`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {submitted ? "Submitted" : "Missing"}
    </span>
  );
}

function RoleBadge({ role }: { role: string }) {
  const styles =
    role === "ADMIN"
      ? "border-emerald-200 bg-emerald-50 text-emerald-700"
      : role === "LEAD"
        ? "border-sky-200 bg-sky-50 text-sky-700"
        : "border-slate-200 bg-slate-50 text-slate-700";

  return (
    <span
      className={`inline-flex rounded-full border px-2.5 py-1 text-[11px] font-medium ${styles}`}
    >
      {role}
    </span>
  );
}

function ViewLink({ href }: { href: string }) {
  return (
    <Link
      href={href}
      className="inline-flex items-center rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow-sm transition hover:border-emerald-300 hover:text-emerald-700 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
    >
      Open
    </Link>
  );
}

function MetricCard({
  label,
  value,
  helper,
}: {
  label: string;
  value: number;
  helper: string;
}) {
  return (
    <div className="rounded-3xl border border-white/70 bg-white/75 p-5 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <p className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-slate-950">
        {value}
      </p>
      <p className="mt-2 text-xs leading-5 text-slate-500">{helper}</p>
    </div>
  );
}

export default async function StatusPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role === "EMPLOYEE") redirect("/dashboard");

  const day = todayDayString();

  const people = await prisma.user.findMany({
    where:
      user.role === "ADMIN"
        ? {}
        : {
            team: { leadId: user.id },
          },
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      dailyUpdates: {
        where: { day },
        select: { id: true },
        take: 1,
      },
      learningStatuses: {
        where: { day },
        select: { id: true },
        take: 1,
      },
    },
    take: 500,
  });

  const totalPeople = people.length;

  const workSubmittedCount = people.filter(
    (person) => person.dailyUpdates.length > 0,
  ).length;

  const learningSubmittedCount = people.filter(
    (person) => person.learningStatuses.length > 0,
  ).length;

  const fullySubmittedCount = people.filter(
    (person) =>
      person.dailyUpdates.length > 0 && person.learningStatuses.length > 0,
  ).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="rounded-[32px] border border-white/70 bg-white/75 p-5 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl md:p-7">
        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div>
            <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.12em] text-emerald-700">
              Visibility board
            </span>

            <h1 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 md:text-5xl">
              Submission status
            </h1>

            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-600 md:text-base">
              Track who submitted today&apos;s work update and learning status.
              This helps leads and admins follow daily reporting without manual
              checking.
            </p>
          </div>

          <div className="w-fit rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 text-sm text-slate-600 shadow-sm">
            <span className="font-medium text-slate-950">{day}</span>
          </div>
        </div>
      </section>

      {/* Metrics */}
      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard
          label="People"
          value={totalPeople}
          helper={
            user.role === "ADMIN"
              ? "Total users visible to admin."
              : "Team members under your lead."
          }
        />

        <MetricCard
          label="Work updates"
          value={workSubmittedCount}
          helper="Daily work updates submitted today."
        />

        <MetricCard
          label="Learning updates"
          value={learningSubmittedCount}
          helper="Learning statuses submitted today."
        />

        <MetricCard
          label="Fully submitted"
          value={fullySubmittedCount}
          helper="People who submitted both updates."
        />
      </div>

      {/* Mobile Cards */}
      <div className="grid gap-4 md:hidden">
        {people.length === 0 ? (
          <div className="rounded-[28px] border border-white/70 bg-white/75 p-6 text-center text-sm text-slate-500 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl">
            No people found.
          </div>
        ) : (
          people.map((person) => {
            const workSubmitted = person.dailyUpdates.length > 0;
            const learningSubmitted = person.learningStatuses.length > 0;

            return (
              <article
                key={person.id}
                className="rounded-[28px] border border-white/70 bg-white/75 p-4 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="truncate text-base font-semibold tracking-[-0.02em] text-slate-950">
                      {person.name}
                    </h2>
                    <p className="mt-1 break-all text-xs text-slate-500">
                      {person.email}
                    </p>
                  </div>

                  <RoleBadge role={person.role} />
                </div>

                <div className="mt-5 grid gap-3">
                  <div className="rounded-2xl border border-slate-200/70 bg-white/80 p-3">
                    <div className="mb-3 flex items-center justify-between gap-3">
                      <p className="text-xs font-semibold uppercase tracking-[0.12em] text-slate-400">
                        Work update
                      </p>
                      <StatusBadge submitted={workSubmitted} />
                    </div>

                    {workSubmitted ? (
                      <ViewLink href={`/updates/view/${person.id}/${day}`} />
                    ) : (
                      <p className="text-xs text-slate-400">
                        No work update submitted yet.
                      </p>
                    )}
                  </div>

                  <div className="rounded-2xl border border-slate-200/70 bg-white/80 p-3">
                    <div className="mb-3 flex items-center justify-between gap-3">
                      <p className="text-xs font-semibold uppercase tracking-[0.12em] text-slate-400">
                        Learning
                      </p>
                      <StatusBadge submitted={learningSubmitted} />
                    </div>

                    {learningSubmitted ? (
                      <ViewLink href={`/learning/view/${person.id}/${day}`} />
                    ) : (
                      <p className="text-xs text-slate-400">
                        No learning update submitted yet.
                      </p>
                    )}
                  </div>
                </div>
              </article>
            );
          })
        )}
      </div>

      {/* Desktop Table */}
      <section className="hidden overflow-hidden rounded-[32px] border border-white/70 bg-white/75 shadow-sm ring-1 ring-slate-900/5 backdrop-blur-xl md:block">
        <div className="border-b border-slate-200 px-5 py-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="text-lg font-semibold tracking-[-0.02em] text-slate-950">
                Team submission overview
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Review today&apos;s work and learning submission status.
              </p>
            </div>

            <span className="w-fit rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600">
              {totalPeople} people
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left text-sm">
            <thead className="bg-slate-50/80 text-xs uppercase tracking-[0.12em] text-slate-500">
              <tr className="border-b border-slate-200">
                <th className="px-5 py-3 font-medium">Employee</th>
                <th className="px-5 py-3 font-medium">Role</th>
                <th className="px-5 py-3 font-medium">Work update</th>
                <th className="px-5 py-3 font-medium">Learning</th>
              </tr>
            </thead>

            <tbody>
              {people.length === 0 ? (
                <tr>
                  <td
                    colSpan={4}
                    className="px-5 py-10 text-center text-sm text-slate-500"
                  >
                    No people found.
                  </td>
                </tr>
              ) : (
                people.map((person) => {
                  const workSubmitted = person.dailyUpdates.length > 0;
                  const learningSubmitted =
                    person.learningStatuses.length > 0;

                  return (
                    <tr
                      key={person.id}
                      className="border-b border-slate-200 align-middle last:border-b-0 hover:bg-white/70"
                    >
                      <td className="px-5 py-4">
                        <div className="font-medium text-slate-950">
                          {person.name}
                        </div>
                        <div className="mt-1 break-all text-xs text-slate-500">
                          {person.email}
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <RoleBadge role={person.role} />
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex flex-wrap items-center gap-2">
                          <StatusBadge submitted={workSubmitted} />

                          {workSubmitted ? (
                            <ViewLink
                              href={`/updates/view/${person.id}/${day}`}
                            />
                          ) : (
                            <span className="text-xs text-slate-400">—</span>
                          )}
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex flex-wrap items-center gap-2">
                          <StatusBadge submitted={learningSubmitted} />

                          {learningSubmitted ? (
                            <ViewLink
                              href={`/learning/view/${person.id}/${day}`}
                            />
                          ) : (
                            <span className="text-xs text-slate-400">—</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}