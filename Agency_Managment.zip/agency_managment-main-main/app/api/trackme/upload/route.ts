import { writeFile } from "node:fs/promises";
import path from "node:path";
import { getSessionUser } from "../../../lib/auth";
import {
  TRACKME_UPLOAD_DIR,
  ensureTrackmeUploadDir,
  makeLatestTrackmeFileName,
  removeTrackmeScreenshotsForUser,
  type TrackmeScreenshot,
} from "../../../lib/trackme";

export const runtime = "nodejs";

const MAX_FILE_SIZE = 12 * 1024 * 1024;
const MIME_EXTENSIONS: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
};

export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const formData = await request.formData();
  const screenshot = formData.get("screenshot");

  if (!(screenshot instanceof File)) {
    return Response.json({ error: "Screenshot file is required" }, { status: 400 });
  }

  const extension = MIME_EXTENSIONS[screenshot.type];
  if (!extension) {
    return Response.json({ error: "Only PNG, JPG, or WEBP images are allowed" }, { status: 400 });
  }

  if (screenshot.size <= 0 || screenshot.size > MAX_FILE_SIZE) {
    return Response.json({ error: "Screenshot file size is invalid" }, { status: 400 });
  }

  const capturedAtValue = String(formData.get("capturedAt") || "");
  const capturedAtDate = capturedAtValue ? new Date(capturedAtValue) : new Date();
  const capturedAt = Number.isNaN(capturedAtDate.getTime())
    ? new Date().toISOString()
    : capturedAtDate.toISOString();

  const count = Number.parseInt(String(formData.get("count") || "0"), 10) || 0;
  const fileName = makeLatestTrackmeFileName(user.id, user.name, extension);
  const metadataFileName = `${fileName}.json`;

  await ensureTrackmeUploadDir();

  const bytes = Buffer.from(await screenshot.arrayBuffer());
  const imagePath = path.join(TRACKME_UPLOAD_DIR, fileName);
  const metadataPath = path.join(TRACKME_UPLOAD_DIR, metadataFileName);

  const metadata: TrackmeScreenshot = {
    fileName,
    metadataFileName,
    userId: user.id,
    userName: user.name,
    userEmail: user.email,
    capturedAt,
    uploadedAt: new Date().toISOString(),
    count,
    size: screenshot.size,
    mimeType: screenshot.type,
  };

  await removeTrackmeScreenshotsForUser(user.id);
  await writeFile(imagePath, bytes);
  await writeFile(metadataPath, JSON.stringify(metadata, null, 2), "utf8");

  return Response.json({
    ok: true,
    fileName,
    capturedAt,
  });
}
