import { readFile } from "node:fs/promises";
import { getSessionUser } from "../../../../lib/auth";
import { getTrackmeImagePath } from "../../../../lib/trackme";

export const runtime = "nodejs";

const CONTENT_TYPES: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
};

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ fileName: string }> }
) {
  const user = await getSessionUser();
  if (!user || user.role !== "ADMIN") {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { fileName } = await params;
  const imagePath = getTrackmeImagePath(fileName);
  if (!imagePath) {
    return Response.json({ error: "Invalid file name" }, { status: 400 });
  }

  try {
    const image = await readFile(imagePath);
    const extension = fileName.split(".").pop()?.toLowerCase() || "png";

    return new Response(image, {
      headers: {
        "Content-Type": CONTENT_TYPES[extension] || "application/octet-stream",
        "Cache-Control": "private, max-age=60",
      },
    });
  } catch {
    return Response.json({ error: "Screenshot not found" }, { status: 404 });
  }
}
