import { getSessionUser } from "../../../lib/auth";
import { prisma } from "../../../lib/db";

const PAGE_SIZE = 30;

export async function GET(request: Request) {
  const user = await getSessionUser();
  if (!user) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const before = searchParams.get("before");

  const cursorMessage = before
    ? await prisma.chatMessage.findUnique({
        where: { id: before },
        select: { createdAt: true, id: true },
      })
    : null;

  const messages = await prisma.chatMessage.findMany({
    where: cursorMessage
      ? {
          OR: [
            { createdAt: { lt: cursorMessage.createdAt } },
            {
              createdAt: cursorMessage.createdAt,
              id: { lt: cursorMessage.id },
            },
          ],
        }
      : undefined,
    orderBy: { createdAt: "desc" },
    take: PAGE_SIZE + 1,
    select: {
      id: true,
      text: true,
      createdAt: true,
      sender: {
        select: {
          id: true,
          name: true,
          role: true,
        },
      },
    },
  });

  const hasMore = messages.length > PAGE_SIZE;
  const page = hasMore ? messages.slice(0, PAGE_SIZE) : messages;
  const orderedMessages = page.reverse();

  return Response.json({
    blocked: user.chatBlocked,
    messages: orderedMessages,
    hasMore,
    nextCursor: orderedMessages[0]?.id ?? null,
  });
}
