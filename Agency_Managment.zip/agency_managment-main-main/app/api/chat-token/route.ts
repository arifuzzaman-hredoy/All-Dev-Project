import crypto from "node:crypto";
import { getSessionUser } from "../../lib/auth";

export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (user.chatBlocked) {
    return Response.json({ blocked: true });
  }

  const exp = Math.floor(Date.now() / 1000) + 60 * 10;
  const payload = {
    sub: user.id,
    typ: "chat",
    exp,
  };

  const payloadB64 = base64UrlEncode(Buffer.from(JSON.stringify(payload)));
  const token = `${payloadB64}.${base64UrlEncode(sign(payloadB64))}`;

  return Response.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      role: user.role,
    },
  });
}

function sign(payloadB64: string) {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error("AUTH_SECRET must be set.");
  return crypto.createHmac("sha256", secret).update(payloadB64).digest();
}

function base64UrlEncode(buf: Buffer) {
  return buf
    .toString("base64")
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");
}
