import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "../lib/db";
import { getSessionUser } from "../lib/auth";
import { todayDayString } from "../lib/dates";

function StatusBadge({
  type,
  children,
}: {
  type: "success" | "warning" | "info";
  children: React.ReactNode;
}) {
  const styles = {
    success:
      "border-emerald-500/20 bg-emerald-500/10 text-emerald-700 shadow-emerald-500/10",
    warning:
      "border-amber-500/25 bg-amber-500/10 text-amber-700 shadow-amber-500/10",
    info: "border-sky-500/20 bg-sky-500/10 text-sky-700 shadow-sky-500/10",
  };

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-black shadow-sm ${styles[type]}`}
    >
      <span className="h-2 w-2 rounded-full bg-current shadow-[0_0_16px_currentColor]" />
      {children}
    </span>
  );
}

function PrimaryButton({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className="group relative inline-flex min-h-11 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#174f3e] via-[#1f7a5b] to-[#2ca36f] px-5 text-sm font-black text-white shadow-[0_18px_42px_rgba(23,79,62,0.30)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_56px_rgba(23,79,62,0.42)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/35"
    >
      <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_25%_15%,rgba(255,255,255,0.42),transparent_34%)] opacity-80 transition group-hover:opacity-100" />
      <span className="pointer-events-none absolute -left-10 top-0 h-full w-8 rotate-12 bg-white/35 blur-sm transition-all duration-700 group-hover:left-[120%]" />
      <span className="relative z-10">{children}</span>
    </Link>
  );
}

function SecondaryButton({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className="inline-flex min-h-11 items-center justify-center rounded-full border border-white/80 bg-white/60 px-5 text-sm font-black text-slate-700 shadow-[0_14px_34px_rgba(15,23,42,0.08),inset_0_1px_0_rgba(255,255,255,0.9)] ring-1 ring-slate-900/5 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/85 hover:text-[#174f3e] hover:shadow-[0_18px_42px_rgba(15,23,42,0.12)] focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-300/25"
    >
      {children}
    </Link>
  );
}

function StatCard({
  title,
  value,
  badge,
  action,
  accent = "emerald",
}: {
  title: string;
  value: React.ReactNode;
  badge?: React.ReactNode;
  action?: React.ReactNode;
  accent?: "emerald" | "amber" | "sky";
}) {
  const accentStyles = {
    emerald: "from-emerald-500/18 to-[#174f3e]/10",
    amber: "from-amber-500/18 to-orange-500/10",
    sky: "from-sky-500/18 to-blue-500/10",
  };

  return (
    <div className="group relative overflow-hidden rounded-[30px] border border-white/75 bg-white/58 p-5 shadow-[0_24px_70px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-1 hover:bg-white/70 hover:shadow-[0_32px_90px_rgba(15,23,42,0.13)] md:p-6">
      <div
        className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${accentStyles[accent]} opacity-80`}
      />
      <div className="pointer-events-none absolute right-[-40px] top-[-40px] h-32 w-32 rounded-full bg-white/40 blur-2xl" />

      <div className="relative z-10">
        <p className="text-sm font-extrabold text-slate-500">{title}</p>

        <div className="mt-3 text-4xl font-black tracking-[-0.06em] text-slate-950 md:text-5xl">
          {value}
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          {badge}
          {action}
        </div>
      </div>
    </div>
  );
}

export default async function DashboardPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const day = todayDayString();

  const [todayUpdate, todayAttendance, openTasks] = await Promise.all([
    prisma.dailyUpdate.findUnique({
      where: { userId_day: { userId: user.id, day } },
      select: { id: true, day: true },
    }),
    prisma.attendance.findUnique({
      where: { userId_day: { userId: user.id, day } },
      select: {
        status: true,
        sessions: {
          where: { endedAt: null },
          select: { id: true },
          take: 1,
        },
      },
    }),
    prisma.task.count({
      where: { assigneeId: user.id, status: { not: "DONE" } },
    }),
  ]);

  const hasSubmittedToday = Boolean(todayUpdate);
  const hasMarkedPresent = Boolean(todayAttendance);
  const isWorkingNow = Boolean(todayAttendance?.sessions[0]);

  return (
    <div className="relative space-y-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_30px_90px_rgba(15,23,42,0.10)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(44,163,111,0.24),transparent_34%),radial-gradient(circle_at_92%_18%,rgba(59,130,246,0.13),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.58),rgba(255,255,255,0.18))]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-52 w-52 rounded-full bg-amber-300/20 blur-3xl" />

        <div className="relative z-10 grid gap-7 lg:grid-cols-[1.2fr_0.8fr] lg:items-end">
          <div>

            <h1 className="mt-5 text-4xl font-black text-slate-950 md:text-6xl">
              Dashboard
            </h1>

            <p className="mt-4 max-w-2xl text-sm font-semibold leading-7 text-slate-600 md:text-base">
              Welcome back,{" "}
              <span className="font-black text-slate-900">{user.name}</span>.
              Track today’s update, open tasks, learning progress and profile
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-2 text-xs font-bold text-slate-500">
              <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                {user.email}
              </span>
              <span className="rounded-full border border-white/70 bg-white/55 px-3 py-1.5 backdrop-blur-xl">
                Role: {user.role}
              </span>
            </div>

            <div className="mt-7 flex flex-wrap gap-3">
              <PrimaryButton href="/updates/today">
                {hasSubmittedToday
                  ? "Update today’s submission"
                  : "Submit today’s update"}
              </PrimaryButton>

              <SecondaryButton href="/attendance">Attendance</SecondaryButton>
              <SecondaryButton href="/tasks">View tasks</SecondaryButton>
              <SecondaryButton href="/profile">Edit profile</SecondaryButton>
            </div>
          </div>

          <div className="rounded-[28px] border border-white/75 bg-white/50 p-4 shadow-[0_20px_60px_rgba(15,23,42,0.08)] ring-1 ring-slate-900/5 backdrop-blur-2xl">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-3xl border border-white/70 bg-white/55 p-4">
                <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
                  Today
                </p>
                <p className="mt-2 text-lg font-black text-slate-950">{day}</p>
              </div>

              <div className="rounded-3xl border border-white/70 bg-white/55 p-4">
                <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
                  Open Tasks
                </p>
                <p className="mt-2 text-lg font-black text-slate-950">
                  {openTasks}
                </p>
              </div>
            </div>

            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div className="rounded-3xl border border-white/70 bg-white/55 p-4">
                <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
                  Attendance
                </p>
                <div className="mt-3">
                  <StatusBadge type={isWorkingNow ? "success" : "warning"}>
                    {isWorkingNow
                      ? "Working Now"
                      : hasMarkedPresent
                        ? "Present"
                        : "Not Present"}
                  </StatusBadge>
                </div>
              </div>

              <div className="rounded-3xl border border-white/70 bg-white/55 p-4">
                <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">
                  Submission Status
                </p>
                <div className="mt-3">
                  <StatusBadge type={hasSubmittedToday ? "success" : "warning"}>
                    {hasSubmittedToday ? "Submitted Today" : "Not Submitted Yet"}
                  </StatusBadge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard
          title="Today attendance"
          value={
            isWorkingNow ? "In" : hasMarkedPresent ? "Present" : "Missing"
          }
          accent={isWorkingNow || hasMarkedPresent ? "emerald" : "amber"}
          badge={
            <StatusBadge type={isWorkingNow ? "success" : "warning"}>
              {isWorkingNow
                ? "Working now"
                : hasMarkedPresent
                  ? "Present marked"
                  : "Present missing"}
            </StatusBadge>
          }
          action={
            <SecondaryButton href="/attendance">Open attendance</SecondaryButton>
          }
        />

        <StatCard
          title="Today’s update"
          value={day}
          accent={hasSubmittedToday ? "emerald" : "amber"}
          badge={
            <StatusBadge type={hasSubmittedToday ? "success" : "warning"}>
              {hasSubmittedToday ? "Submitted" : "Not submitted"}
            </StatusBadge>
          }
          action={
            <SecondaryButton href="/updates/today">
              {hasSubmittedToday ? "Edit update" : "Submit now"}
            </SecondaryButton>
          }
        />

        <StatCard
          title="Open tasks"
          value={openTasks}
          accent={openTasks > 0 ? "sky" : "emerald"}
          badge={
            <StatusBadge type={openTasks > 0 ? "info" : "success"}>
              {openTasks > 0 ? "Needs attention" : "All clear"}
            </StatusBadge>
          }
          action={<SecondaryButton href="/tasks">View tasks</SecondaryButton>}
        />
      </div>

      {/* Quick Links */}
      <section className="relative overflow-hidden rounded-[34px] border border-white/75 bg-white/55 p-5 shadow-[0_24px_70px_rgba(15,23,42,0.09)] ring-1 ring-slate-900/5 backdrop-blur-2xl md:p-6">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_15%_0%,rgba(16,185,129,0.16),transparent_28%),linear-gradient(135deg,rgba(255,255,255,0.5),rgba(255,255,255,0.14))]" />

        <div className="relative z-10 flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-xl font-black tracking-[-0.04em] text-slate-950">
              Quick links
            </h2>

          </div>

          <div className="flex flex-wrap gap-3">
            <SecondaryButton href="/profile">Profile</SecondaryButton>
            <SecondaryButton href="/attendance">Attendance</SecondaryButton>
            <SecondaryButton href="/learning">Learning</SecondaryButton>

            {user.role === "ADMIN" ? (
              <PrimaryButton href="/admin">Admin dashboard</PrimaryButton>
            ) : null}
          </div>
        </div>
      </section>
    </div>
  );
}
