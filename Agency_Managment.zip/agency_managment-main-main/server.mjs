import "dotenv/config";
import { createServer } from "node:http";
import next from "next";
import { Server as SocketIOServer } from "socket.io";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import crypto from "node:crypto";

const dev = process.env.NODE_ENV !== "production";
const host = process.env.HOSTNAME || "0.0.0.0";
const port = Number(process.env.PORT || 3000);

const app = next({ dev, hostname: host, port });
const handle = app.getRequestHandler();

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error("DATABASE_URL must be set.");
}

const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString }),
});

app.prepare().then(() => {
  const typingUsers = new Map();

  function broadcastTypingUsers(io) {
    const users = [...typingUsers.values()].map((user) => ({
      id: user.id,
      name: user.name,
    }));

    io.emit("chat:typing:update", { users });
  }

  const httpServer = createServer((req, res) => {
    handle(req, res);
  });

  const io = new SocketIOServer(httpServer, {
    path: "/socket.io",
    cors: {
      origin: true,
      credentials: true,
    },
  });

  io.on("connection", async (socket) => {
    const token = socket.handshake.auth?.token;
    const payload = verifyRealtimeToken(token);

    if (!payload) {
      socket.emit("chat:error", { message: "Unauthorized" });
      socket.disconnect(true);
      return;
    }

    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        chatBlocked: true,
      },
    });

    if (!user || user.chatBlocked) {
      socket.emit("chat:error", {
        message: user?.chatBlocked ? "Chat access blocked" : "Unauthorized",
      });
      socket.disconnect(true);
      return;
    }

    socket.data.user = user;

    const onlineCount = io.sockets.sockets.size;
    io.emit("presence:update", { onlineCount });
    broadcastTypingUsers(io);

    socket.on("chat:message:create", async (payload) => {
      const currentUser = socket.data.user;
      if (!currentUser) return;

      const latestUser = await prisma.user.findUnique({
        where: { id: currentUser.id },
        select: { chatBlocked: true, id: true, name: true, role: true },
      });

      if (!latestUser || latestUser.chatBlocked) {
        socket.emit("chat:error", { message: "Chat access blocked" });
        socket.disconnect(true);
        return;
      }

      const text =
        typeof payload?.text === "string" ? payload.text.trim().slice(0, 1000) : "";

      if (!text) return;

      typingUsers.delete(socket.id);
      broadcastTypingUsers(io);

      const message = await prisma.chatMessage.create({
        data: {
          senderId: latestUser.id,
          text,
        },
        select: {
          id: true,
          text: true,
          createdAt: true,
          sender: {
            select: {
              id: true,
              name: true,
              role: true,
            },
          },
        },
      });

      io.emit("chat:message:new", {
        id: message.id,
        text: message.text,
        createdAt: message.createdAt,
        sender: message.sender,
      });
    });

    socket.on("chat:typing:start", () => {
      const currentUser = socket.data.user;
      if (!currentUser) return;

      typingUsers.set(socket.id, {
        id: currentUser.id,
        name: currentUser.name,
      });
      broadcastTypingUsers(io);
    });

    socket.on("chat:typing:stop", () => {
      if (!typingUsers.has(socket.id)) return;
      typingUsers.delete(socket.id);
      broadcastTypingUsers(io);
    });

    socket.on("chat:message:delete", async (payload) => {
      const currentUser = socket.data.user;
      if (!currentUser || currentUser.role !== "ADMIN") return;

      const messageId =
        typeof payload?.messageId === "string" ? payload.messageId : "";

      if (!messageId) return;

      const existing = await prisma.chatMessage.findUnique({
        where: { id: messageId },
        select: { id: true },
      });

      if (!existing) return;

      await prisma.chatMessage.delete({
        where: { id: messageId },
      });

      io.emit("chat:message:deleted", { id: messageId });
    });

    socket.on("disconnect", () => {
      typingUsers.delete(socket.id);
      broadcastTypingUsers(io);
      io.emit("presence:update", { onlineCount: io.sockets.sockets.size });
    });
  });

  httpServer.listen(port, host, () => {
    console.log(
      `> Server listening at http://${host}:${port} as ${dev ? "development" : "production"}`
    );
  });
});

function verifyRealtimeToken(token) {
  if (!token || typeof token !== "string") return null;

  const [payloadB64, sigB64] = token.split(".");
  if (!payloadB64 || !sigB64) return null;

  const expectedSig = sign(payloadB64);
  const actualSig = base64UrlDecode(sigB64);

  if (!timingSafeEqual(expectedSig, actualSig)) return null;

  try {
    const payload = JSON.parse(base64UrlDecode(payloadB64).toString("utf8"));
    if (payload.typ !== "chat") return null;
    if (!payload.sub || typeof payload.exp !== "number") return null;
    if (payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

function sign(payloadB64) {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error("AUTH_SECRET must be set.");
  return crypto.createHmac("sha256", secret).update(payloadB64).digest();
}

function base64UrlDecode(b64url) {
  const pad = b64url.length % 4 === 0 ? "" : "=".repeat(4 - (b64url.length % 4));
  const b64 = b64url.replaceAll("-", "+").replaceAll("_", "/") + pad;
  return Buffer.from(b64, "base64");
}

function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

