CREATE TABLE "LearningStatus" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "day" TEXT NOT NULL,
    "learningPlan" TEXT NOT NULL,
    "completedLearning" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LearningStatus_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "LearningStatus_userId_day_key" ON "LearningStatus"("userId", "day");
CREATE INDEX "LearningStatus_day_idx" ON "LearningStatus"("day");

ALTER TABLE "LearningStatus" ADD CONSTRAINT "LearningStatus_userId_fkey"
FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
