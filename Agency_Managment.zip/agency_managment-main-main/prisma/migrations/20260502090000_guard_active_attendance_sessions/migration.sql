WITH ranked_open_sessions AS (
  SELECT
    "id",
    row_number() OVER (
      PARTITION BY "attendanceId"
      ORDER BY "startedAt" DESC, "id" DESC
    ) AS rn
  FROM "AttendanceSession"
  WHERE "endedAt" IS NULL
)
UPDATE "AttendanceSession" AS session
SET "endedAt" = session."startedAt"
FROM ranked_open_sessions
WHERE session."id" = ranked_open_sessions."id"
  AND ranked_open_sessions.rn > 1;

CREATE UNIQUE INDEX "AttendanceSession_one_open_per_attendance_idx"
ON "AttendanceSession"("attendanceId")
WHERE "endedAt" IS NULL;
