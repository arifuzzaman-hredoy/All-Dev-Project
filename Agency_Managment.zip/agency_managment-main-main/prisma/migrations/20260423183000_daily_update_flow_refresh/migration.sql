ALTER TABLE "DailyUpdate"
RENAME COLUMN "today" TO "todayPlan";

ALTER TABLE "DailyUpdate"
ADD COLUMN "completedWork" TEXT;

ALTER TABLE "DailyUpdate"
DROP COLUMN "yesterday",
DROP COLUMN "tomorrowPlan";
