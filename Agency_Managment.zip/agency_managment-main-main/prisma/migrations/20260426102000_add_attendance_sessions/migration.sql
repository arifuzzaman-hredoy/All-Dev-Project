CREATE TABLE "AttendanceSession" (
    "id" TEXT NOT NULL,
    "attendanceId" TEXT NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "endedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AttendanceSession_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "AttendanceSession_attendanceId_startedAt_idx" ON "AttendanceSession"("attendanceId", "startedAt");

ALTER TABLE "AttendanceSession" ADD CONSTRAINT "AttendanceSession_attendanceId_fkey"
FOREIGN KEY ("attendanceId") REFERENCES "Attendance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

INSERT INTO "AttendanceSession" ("id", "attendanceId", "startedAt", "endedAt", "createdAt", "updatedAt")
SELECT
  'sess_' || md5(random()::text || clock_timestamp()::text || "id"),
  "id",
  "checkInAt",
  "checkOutAt",
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM "Attendance"
WHERE "checkInAt" IS NOT NULL;
