import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  allowedDevOrigins: ["http://localhost:3000","127.0.0.1", "192.168.2.101"],
};

export default nextConfig;
