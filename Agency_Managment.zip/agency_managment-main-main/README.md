CompanyLearn MVP (Next.js + Prisma + Postgres)

## Setup

### 1) Configure env

Copy `.env.example` → `.env` and set:

- `DATABASE_URL`
- `AUTH_SECRET`
- `APP_URL`
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` (for seed)
- `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASS` / `SMTP_FROM` (for password reset email)

### 2) Migrate + seed

```bash
npm run db:migrate
npm run db:seed
```

### 3) Run

```bash
npm run dev
```

Open `http://localhost:3000`.

### 4) How HTTP + WebSocket run together

This project now uses a custom server in `server.mjs`.

- `npm run dev`
  Starts one Node process.
- That process starts Next.js for normal HTTP pages and APIs.
- The same HTTP server also mounts `Socket.IO` at `/socket.io`.
- So you do **not** start a separate websocket server manually.

In short:

- browser pages and APIs run over normal HTTP from the Next handler
- realtime company chat runs over WebSocket/Socket.IO on the same port
- both are served by the single process started from `server.mjs`

Common local startup:

```bash
npm run db:migrate
npm run dev
```

Then open:

- App: `http://localhost:3000`
- Chat socket endpoint is automatically available at: `http://localhost:3000/socket.io`

Production startup:

```bash
npm run build
npm run start
```

Useful env vars for server start:

- `PORT=3000`
- `HOSTNAME=0.0.0.0`

## MVP Routes

- `/login` – login
- `/forgot-password` – request reset email
- `/reset-password` – set new password from email link
- `/dashboard` – home
- `/profile` – employee profile
- `/updates/today` – daily update submit
- `/learning` – learning items
- `/tasks` – tasks
- `/tomorrow` – tomorrow plan
- `/status` – submission status (lead/admin)
- `/lead` – team lead view
- `/admin` – admin dashboard
- `/reports` – basic reports (admin)

## Chat Notes

- Floating common chat is available for logged-in users
- Admin can allow/block chat per user from `/admin/users`
- Admin can delete chat messages from the chat panel
- Press `Enter` to send, `Shift + Enter` for new line
